"use client"

import { use } from "react"
import { notFound } from "next/navigation"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import {
  ArrowLeft, Star, Plus, MessageSquare, Paperclip, Clock, Calendar,
  User, Tag, Link2, Play, MoreHorizontal, CheckCircle2, AlertTriangle,
  GitBranch, RefreshCw, Send,
} from "lucide-react"
import Link from "next/link"
import { tasks, members, labels as allLabels } from "@/lib/data/mock"
import { PriorityBadge, TaskStatusBadge, LabelBadge } from "@/components/common/badges"
import { useTaskStore } from "@/lib/store/task-store"
import { cn, relativeDay, timeAgo, formatDate } from "@/lib/utils"
import { useState } from "react"

export default function TaskDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const storeTask = useTaskStore(s => s.tasks.find(t => t.id === id))
  const toggleSubtask = useTaskStore(s => s.toggleSubtask)
  const toggleStar = useTaskStore(s => s.toggleTaskStar)
  const task = storeTask ?? tasks.find(t => t.id === id)
  const [comment, setComment] = useState("")

  if (!task) notFound()

  const subtasksDone = task.subtasks.filter(s => s.done).length
  const subtaskPct = task.subtasks.length > 0 ? Math.round((subtasksDone / task.subtasks.length) * 100) : 0

  return (
    <DashboardShell
      title={task.title}
      description={`${task.key} · ${task.projectName}`}
      breadcrumbs={[{ label: "Tasks", href: "/tasks" }, { label: task.key }]}
      actions={
        <>
          <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Link href="/tasks"><ArrowLeft className="w-4 h-4" /> Back</Link>
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Play className="w-4 h-4" /> Start timer
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Main column */}
        <div className="lg:col-span-2 space-y-3 md:space-y-4">
          {/* Title card */}
          <Card className="p-4 md:p-5">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded">{task.key}</span>
                <PriorityBadge priority={task.priority} />
                <TaskStatusBadge status={task.status} />
                {task.recurring && task.recurring !== "none" && (
                  <Badge className="bg-violet-500/15 text-violet-600 dark:text-violet-400 text-[10px] gap-1">
                    <RefreshCw className="w-3 h-3" /> {task.recurring}
                  </Badge>
                )}
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStar(task.id)}>
                <Star className={cn("w-4 h-4", task.starred && "fill-amber-500 text-amber-500")} />
              </Button>
            </div>
            <h1 className="text-lg md:text-xl font-bold text-foreground mb-2">{task.title}</h1>
            <p className="text-sm text-muted-foreground leading-relaxed">{task.description}</p>

            {task.labels.length > 0 && (
              <div className="flex items-center gap-1.5 mt-3">
                <Tag className="w-3.5 h-3.5 text-muted-foreground" />
                {task.labels.map(l => <LabelBadge key={l.id} label={l} />)}
              </div>
            )}
          </Card>

          {/* Subtasks */}
          <Card className="p-4 md:p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Subtasks</h3>
                <Badge variant="outline" className="text-[10px]">{subtasksDone}/{task.subtasks.length}</Badge>
              </div>
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <Plus className="w-3 h-3" /> Add
              </Button>
            </div>
            {task.subtasks.length > 0 ? (
              <>
                <Progress value={subtaskPct} className="h-1.5 mb-3" />
                <div className="space-y-1">
                  {task.subtasks.map(st => (
                    <div key={st.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-secondary/30 transition-colors group">
                      <Checkbox checked={st.done} onCheckedChange={() => toggleSubtask(task.id, st.id)} />
                      <span className={cn("text-xs flex-1", st.done && "line-through text-muted-foreground")}>
                        {st.title}
                      </span>
                      {st.assignee && (
                        <span className="text-[10px] text-muted-foreground">{st.assignee.split(" ")[0]}</span>
                      )}
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-xs text-muted-foreground text-center py-4">No subtasks yet — break this task into smaller steps.</p>
            )}
          </Card>

          {/* Comments */}
          <Card className="p-4 md:p-5">
            <div className="flex items-center gap-2 mb-3">
              <MessageSquare className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Comments</h3>
              <Badge variant="outline" className="text-[10px]">{task.comments.length}</Badge>
            </div>
            <div className="space-y-3 mb-4">
              {task.comments.map(c => (
                <div key={c.id} className="flex items-start gap-2.5">
                  <Avatar className="w-7 h-7"><AvatarImage src={c.avatar} alt={c.author} /><AvatarFallback className="text-[10px]">{c.author[0]}</AvatarFallback></Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-semibold text-foreground">{c.author}</p>
                      <p className="text-[10px] text-muted-foreground">{timeAgo(c.createdAt)}</p>
                    </div>
                    <p className="text-xs text-foreground mt-0.5">{c.body}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-start gap-2.5">
              <Avatar className="w-7 h-7"><AvatarImage src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" alt="You" /><AvatarFallback className="text-[10px]">J</AvatarFallback></Avatar>
              <div className="flex-1 space-y-2">
                <Textarea
                  placeholder="Add a comment…"
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  rows={2}
                  className="text-xs resize-none"
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7"><Paperclip className="w-3.5 h-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7"><Tag className="w-3.5 h-3.5" /></Button>
                  </div>
                  <Button size="sm" className="h-7 text-xs gap-1" disabled={!comment.trim()}>
                    <Send className="w-3 h-3" /> Comment
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Activity */}
          <Card className="p-4 md:p-5">
            <h3 className="text-sm font-semibold mb-3">Activity</h3>
            <div className="space-y-3">
              {[
                { actor: task.reporter, avatar: task.reporterAvatar, action: "created this task", time: task.createdAt },
                { actor: task.assignee ?? "Unassigned", avatar: task.assigneeAvatar, action: "was assigned", time: task.updatedAt },
                { actor: task.reporter, avatar: task.reporterAvatar, action: `changed status to ${task.status.replace("_", " ")}`, time: task.updatedAt },
              ].map((a, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <Avatar className="w-6 h-6"><AvatarImage src={a.avatar} alt={a.actor} /><AvatarFallback className="text-[10px]">{a.actor[0]}</AvatarFallback></Avatar>
                  <div>
                    <p className="text-xs text-foreground">
                      <span className="font-semibold">{a.actor}</span> <span className="text-muted-foreground">{a.action}</span>
                    </p>
                    <p className="text-[10px] text-muted-foreground">{timeAgo(a.time)}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Sidebar column */}
        <div className="space-y-3 md:space-y-4">
          {/* Properties */}
          <Card className="p-4 md:p-5">
            <h3 className="text-sm font-semibold mb-3">Properties</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <User className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="text-xs text-muted-foreground w-20">Assignee</span>
                <div className="flex items-center gap-1.5">
                  <Avatar className="w-5 h-5"><AvatarImage src={task.assigneeAvatar} alt={task.assignee ?? ""} /><AvatarFallback className="text-[9px]">{task.assignee?.[0]}</AvatarFallback></Avatar>
                  <span className="text-xs">{task.assignee ?? "Unassigned"}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <User className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="text-xs text-muted-foreground w-20">Reporter</span>
                <div className="flex items-center gap-1.5">
                  <Avatar className="w-5 h-5"><AvatarImage src={task.reporterAvatar} alt={task.reporter} /><AvatarFallback className="text-[9px]">{task.reporter[0]}</AvatarFallback></Avatar>
                  <span className="text-xs">{task.reporter}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="text-xs text-muted-foreground w-20">Due date</span>
                <span className={cn("text-xs", task.dueDate && new Date(task.dueDate).getTime() < Date.now() && task.status !== "done" && "text-rose-600 dark:text-rose-400 font-semibold")}>
                  {task.dueDate ? relativeDay(task.dueDate) : "—"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="text-xs text-muted-foreground w-20">Estimate</span>
                <span className="text-xs">{task.estimateHours ? `${task.estimateHours}h` : "—"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="text-xs text-muted-foreground w-20">Logged</span>
                <span className="text-xs">{task.loggedHours ? `${task.loggedHours}h` : "0h"}</span>
              </div>
              <div className="flex items-center gap-2">
                <GitBranch className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="text-xs text-muted-foreground w-20">Project</span>
                <Link href={`/projects/${task.projectId}`} className="flex items-center gap-1.5 text-xs hover:text-primary transition-colors">
                  <span className={cn("w-2 h-2 rounded-full", task.projectColor)} />
                  {task.projectName}
                </Link>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                <span className="text-xs text-muted-foreground w-20">Created</span>
                <span className="text-xs">{formatDate(task.createdAt)}</span>
              </div>
            </div>
          </Card>

          {/* Blocked by */}
          {task.blockedBy && task.blockedBy.length > 0 && (
            <Card className="p-4 md:p-5 border-rose-500/30">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <h3 className="text-sm font-semibold">Blocked by</h3>
              </div>
              <div className="space-y-1">
                {task.blockedBy.map(b => (
                  <Link key={b} href={`/tasks/${b}`} className="block p-2 rounded-lg bg-rose-500/5 border border-rose-500/20 hover:bg-rose-500/10 transition-colors">
                    <p className="text-xs font-mono text-rose-600 dark:text-rose-400">{b}</p>
                  </Link>
                ))}
              </div>
            </Card>
          )}

          {/* Attachments */}
          <Card className="p-4 md:p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Paperclip className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Attachments</h3>
              </div>
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <Plus className="w-3 h-3" /> Upload
              </Button>
            </div>
            {task.attachments > 0 ? (
              <div className="space-y-2">
                {Array.from({ length: task.attachments }).map((_, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 rounded-lg border border-border hover:bg-secondary/30 transition-colors cursor-pointer">
                    <div className="w-7 h-7 rounded bg-primary/15 flex items-center justify-center">
                      <Paperclip className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">attachment-{i + 1}.pdf</p>
                      <p className="text-[10px] text-muted-foreground">{(Math.random() * 2 + 0.5).toFixed(1)} MB</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground text-center py-4">No attachments yet</p>
            )}
          </Card>

          {/* Quick actions */}
          <Card className="p-4 md:p-5">
            <h3 className="text-sm font-semibold mb-3">Quick actions</h3>
            <div className="space-y-1.5">
              <Button variant="outline" size="sm" className="w-full h-8 justify-start text-xs gap-2 bg-transparent">
                <CheckCircle2 className="w-3.5 h-3.5" /> Mark as done
              </Button>
              <Button variant="outline" size="sm" className="w-full h-8 justify-start text-xs gap-2 bg-transparent">
                <Play className="w-3.5 h-3.5" /> Start timer
              </Button>
              <Button variant="outline" size="sm" className="w-full h-8 justify-start text-xs gap-2 bg-transparent">
                <Link2 className="w-3.5 h-3.5" /> Copy link
              </Button>
              <Button variant="outline" size="sm" className="w-full h-8 justify-start text-xs gap-2 bg-transparent">
                <MoreHorizontal className="w-3.5 h-3.5" /> More
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
