"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, FileBox, Star, Clock, Calendar } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { cn } from "@/lib/utils"

const templates = [
  { id: "tpl1", name: "Bug fix workflow", description: "Reproduce → diagnose → fix → test → deploy", icon: "Bug", color: "bg-rose-500", uses: 42, category: "Engineering", lastUsed: "2 days ago" },
  { id: "tpl2", name: "Feature spec", description: "Problem, users, goals, success metrics, scope", icon: "FileText", color: "bg-emerald-500", uses: 28, category: "Product", lastUsed: "1 week ago" },
  { id: "tpl3", name: "Design review", description: "Share Figma, gather feedback, iterate, sign-off", icon: "Palette", color: "bg-violet-500", uses: 35, category: "Design", lastUsed: "3 days ago" },
  { id: "tpl4", name: "Customer interview", description: "Intro → context → questions → synthesis", icon: "Users", color: "bg-amber-500", uses: 18, category: "Research", lastUsed: "5 days ago" },
  { id: "tpl5", name: "Release checklist", description: "QA, changelog, deploy, monitor, announce", icon: "Rocket", color: "bg-sky-500", uses: 56, category: "Engineering", lastUsed: "1 day ago" },
  { id: "tpl6", name: "Onboarding task", description: "Welcome, setup, first task, check-in", icon: "Sparkles", color: "bg-teal-500", uses: 14, category: "People", lastUsed: "2 weeks ago" },
  { id: "tpl7", name: "Sprint planning", description: "Review, capacity, prioritize, assign, kick-off", icon: "Target", color: "bg-lime-500", uses: 22, category: "Process", lastUsed: "4 days ago" },
  { id: "tpl8", name: "Quarterly review", description: "Recap wins, lessons, set next quarter goals", icon: "TrendingUp", color: "bg-orange-500", uses: 8, category: "Leadership", lastUsed: "1 month ago" },
]

export default function TaskTemplatesPage() {
  return (
    <DashboardShell
      title="Task Templates"
      description="Pre-built task blueprints — spin up new work in seconds."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New template
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Templates" value={templates.length} hint="across all categories" icon={FileBox} trend={{ value: 4, positive: true }} />
        <StatCard label="Most Used" value="Release checklist" hint="56 uses" icon={Star} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Uses" value="28" hint="per template" icon={Clock} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Categories" value={new Set(templates.map(t => t.category)).size} hint="covered" icon={Calendar} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {templates.map(tpl => (
          <Card key={tpl.id} className="p-4 card-lift group cursor-pointer">
            <div className="flex items-start gap-3 mb-3">
              <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:scale-110", tpl.color)}>
                <FileBox className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{tpl.name}</p>
                <Badge variant="outline" className="text-[10px] mt-0.5">{tpl.category}</Badge>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mb-3 leading-relaxed">{tpl.description}</p>
            <div className="flex items-center justify-between pt-3 border-t border-border">
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1"><Star className="w-3 h-3" /> {tpl.uses} uses</span>
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {tpl.lastUsed}</span>
              </div>
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                Use <Plus className="w-3 h-3" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </DashboardShell>
  )
}
