"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { TasksTable } from "@/components/task/tasks-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { Users, Clock, CheckCircle2, Layers } from "lucide-react"
import { useTaskStore } from "@/lib/store/task-store"
import { members } from "@/lib/data/mock"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { cn } from "@/lib/utils"

export default function AssignedTasksPage() {
  const tasks = useTaskStore(s => s.tasks)
  return (
    <DashboardShell
      title="Assigned Tasks"
      description="Tasks assigned across your team — see who has capacity."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> Assign task
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Assigned" value={tasks.filter(t => t.assignee).length} hint="across team" icon={Users} trend={{ value: 8, positive: true }} />
        <StatCard label="Unassigned" value={tasks.filter(t => !t.assignee).length} hint="needs triage" icon={Layers} trend={{ value: 0, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Active Now" value={tasks.filter(t => t.assignee && t.status === "in_progress").length} hint="in progress" icon={Clock} trend={{ value: 4, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Done (sprint)" value={tasks.filter(t => t.assignee && t.status === "done").length} hint="this sprint" icon={CheckCircle2} trend={{ value: 18, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      <Card className="p-4 md:p-5 mb-4 card-lift">
        <h3 className="text-sm font-semibold mb-3">By team member</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
          {members.slice(0, 6).map(m => {
            const count = tasks.filter(t => t.assignee === m.name && t.status !== "done").length
            return (
              <Link
                key={m.id}
                href={`/team/${m.id}`}
                className="flex flex-col items-center p-3 rounded-xl border border-border hover:border-primary/30 hover:shadow-md transition-all duration-300 hover:-translate-y-0.5 group"
              >
                <div className="relative">
                  <Avatar className="w-10 h-10"><AvatarImage src={m.avatar} alt={m.name} /><AvatarFallback>{m.name[0]}</AvatarFallback></Avatar>
                  {m.online && <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-card" />}
                </div>
                <p className="text-xs font-medium text-foreground mt-2 group-hover:text-primary transition-colors">{m.name.split(" ")[0]}</p>
                <p className="text-[10px] text-muted-foreground">{count} active</p>
              </Link>
            )
          })}
        </div>
      </Card>

      <TasksTable />
    </DashboardShell>
  )
}
