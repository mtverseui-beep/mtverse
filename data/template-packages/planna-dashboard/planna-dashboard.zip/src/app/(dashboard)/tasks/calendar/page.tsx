"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, ChevronLeft, ChevronRight, CalendarDays } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { useTaskStore } from "@/lib/store/task-store"
import { cn, isSameDay, isOverdue, relativeDay } from "@/lib/utils"
import { PriorityBadge } from "@/components/common/badges"
import Link from "next/link"
import { useState } from "react"

export default function TaskCalendarPage() {
  const tasks = useTaskStore(s => s.tasks)
  const [cursor, setCursor] = useState(new Date())

  const year = cursor.getFullYear()
  const month = cursor.getMonth()
  const firstDay = new Date(year, month, 1)
  const lastDay = new Date(year, month + 1, 0)
  const daysInMonth = lastDay.getDate()
  const startWeekday = (firstDay.getDay() + 6) % 7 // Mon = 0

  const days: (Date | null)[] = []
  for (let i = 0; i < startWeekday; i++) days.push(null)
  for (let d = 1; d <= daysInMonth; d++) days.push(new Date(year, month, d))
  while (days.length % 7 !== 0) days.push(null)

  const todayStr = new Date().toISOString().slice(0, 10)
  const tasksThisMonth = tasks.filter(t => {
    if (!t.dueDate) return false
    const d = new Date(t.dueDate)
    return d.getFullYear() === year && d.getMonth() === month
  })

  return (
    <DashboardShell
      title="Task Calendar"
      description="See when work is due across the month."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm bg-transparent" onClick={() => setCursor(new Date())}>
            Today
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New task
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Due This Month" value={tasksThisMonth.length} hint="scheduled tasks" icon={CalendarDays} trend={{ value: 8, positive: true }} />
        <StatCard label="Overdue" value={tasks.filter(t => isOverdue(t.dueDate) && t.status !== "done").length} hint="past due" icon={CalendarDays} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Due Today" value={tasks.filter(t => t.dueDate && isSameDay(t.dueDate, todayStr)).length} hint="needs action" icon={CalendarDays} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Completed" value={tasks.filter(t => t.status === "done" && t.dueDate && new Date(t.dueDate).getMonth() === month).length} hint="this month" icon={CalendarDays} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold">
            {cursor.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
          </h3>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(year, month - 1, 1))}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(year, month + 1, 1))}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1 mb-2">
          {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(d => (
            <div key={d} className="text-center text-[10px] font-semibold text-muted-foreground uppercase tracking-wider py-1">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {days.map((d, i) => {
            if (!d) return <div key={i} className="aspect-square md:aspect-[4/3] rounded-lg bg-muted/30" />
            const dateStr = d.toISOString().slice(0, 10)
            const dayTasks = tasks.filter(t => t.dueDate === dateStr)
            const isToday = isSameDay(dateStr, todayStr)
            const isPast = d < new Date() && !isToday
            return (
              <div
                key={i}
                className={cn(
                  "aspect-square md:aspect-[4/3] rounded-lg border p-1.5 overflow-hidden transition-all hover:border-primary/30 hover:shadow-sm",
                  isToday ? "border-primary bg-primary/5" : "border-border",
                  isPast && "opacity-60"
                )}
              >
                <p className={cn("text-[10px] font-semibold mb-0.5", isToday ? "text-primary" : "text-muted-foreground")}>
                  {d.getDate()}
                </p>
                <div className="space-y-0.5">
                  {dayTasks.slice(0, 3).map(t => (
                    <Link
                      key={t.id}
                      href={`/tasks/${t.id}`}
                      className={cn("block text-[9px] px-1 py-0.5 rounded truncate hover:opacity-80 transition-opacity",
                        t.status === "done" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 line-through" :
                        isOverdue(t.dueDate) ? "bg-rose-500/15 text-rose-700 dark:text-rose-400" :
                        "bg-primary/10 text-primary"
                      )}
                    >
                      {t.title}
                    </Link>
                  ))}
                  {dayTasks.length > 3 && (
                    <p className="text-[9px] text-muted-foreground px-1">+{dayTasks.length - 3} more</p>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </Card>
    </DashboardShell>
  )
}
