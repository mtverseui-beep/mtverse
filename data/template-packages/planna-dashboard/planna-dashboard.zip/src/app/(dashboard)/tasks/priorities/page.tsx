"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Flag, Plus, ArrowUpRight, AlertTriangle } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { TasksTable } from "@/components/task/tasks-table"
import { useTaskStore } from "@/lib/store/task-store"
import { cn, pct } from "@/lib/utils"
import { PriorityBadge } from "@/components/common/badges"

const priorities = [
  { key: "urgent", label: "Urgent", color: "bg-rose-500", textColor: "text-rose-600 dark:text-rose-400", bgColor: "bg-rose-500/15" },
  { key: "high", label: "High", color: "bg-orange-500", textColor: "text-orange-600 dark:text-orange-400", bgColor: "bg-orange-500/15" },
  { key: "medium", label: "Medium", color: "bg-amber-500", textColor: "text-amber-600 dark:text-amber-400", bgColor: "bg-amber-500/15" },
  { key: "low", label: "Low", color: "bg-sky-500", textColor: "text-sky-600 dark:text-sky-400", bgColor: "bg-sky-500/15" },
] as const

export default function PrioritiesPage() {
  const tasks = useTaskStore(s => s.tasks)
  const open = tasks.filter(t => t.status !== "done")

  return (
    <DashboardShell
      title="Task Priorities"
      description="What's urgent, what's important, and what can wait."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New task
        </Button>
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        {priorities.map(p => {
          const count = open.filter(t => t.priority === p.key).length
          return (
            <Card key={p.key} className={cn("p-4 card-lift group cursor-pointer border-l-4", p.color.replace("bg-", "border-l-"))}>
              <div className="flex items-start justify-between mb-3">
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", p.bgColor, p.textColor)}>
                  <Flag className="w-4 h-4" />
                </div>
                <Badge className={cn("text-[10px]", p.bgColor, p.textColor)}>{p.label}</Badge>
              </div>
              <p className="text-2xl font-bold text-foreground">{count}</p>
              <p className="text-xs text-muted-foreground">open tasks</p>
              <div className="mt-2 h-1 rounded-full bg-muted overflow-hidden">
                <div className={cn("h-full transition-all duration-500", p.color)} style={{ width: `${pct(count, open.length)}%` }} />
              </div>
            </Card>
          )
        })}
      </div>

      {/* Priority matrix */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <h3 className="text-sm font-semibold mb-4">Priority Breakdown</h3>
        <div className="space-y-3">
          {priorities.map(p => {
            const items = open.filter(t => t.priority === p.key)
            const done = tasks.filter(t => t.priority === p.key && t.status === "done").length
            const total = items.length + done
            return (
              <div key={p.key} className="flex items-center gap-3">
                <div className={cn("w-2 h-12 rounded-full", p.color)} />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">{p.label}</span>
                      <Badge variant="outline" className="text-[10px]">{items.length} open · {done} done</Badge>
                    </div>
                    <span className="text-xs text-muted-foreground">{pct(done, total)}% complete</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div className={cn("h-full transition-all duration-500", p.color)} style={{ width: `${pct(done, total)}%` }} />
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      <TasksTable filterPreset={{ priority: "urgent" }} />
    </DashboardShell>
  )
}
