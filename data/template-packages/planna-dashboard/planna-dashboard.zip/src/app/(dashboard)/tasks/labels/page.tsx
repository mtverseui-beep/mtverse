"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, Tag as TagIcon, Search } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { labels, tasks as seedTasks } from "@/lib/data/mock"
import { useTaskStore } from "@/lib/store/task-store"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { useState } from "react"

export default function LabelsPage() {
  const tasks = useTaskStore(s => s.tasks)
  const [search, setSearch] = useState("")

  return (
    <DashboardShell
      title="Task Labels"
      description="Organize tasks with colored tags — filter, group, and find anything."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New label
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Labels" value={labels.length} hint="across workspace" icon={TagIcon} trend={{ value: 2, positive: true }} />
        <StatCard label="Most Used" value="Backend" hint="42 tasks" icon={TagIcon} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Categories" value={new Set(labels.map(l => l.name)).size} hint="unique tags" icon={TagIcon} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Untagged" value={tasks.filter(t => t.labels.length === 0).length} hint="tasks need tagging" icon={TagIcon} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      <Card className="p-4 md:p-5 mb-4 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">All labels</h3>
          <div className="relative w-64">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input placeholder="Search labels…" value={search} onChange={e => setSearch(e.target.value)} className="h-8 pl-8 text-xs" />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          {labels.filter(l => l.name.toLowerCase().includes(search.toLowerCase())).map(label => {
            const count = tasks.filter(t => t.labels.some(l => l.id === label.id)).length
            return (
              <div key={label.id} className="flex items-center justify-between p-3 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors cursor-pointer group">
                <div className="flex items-center gap-2.5">
                  <div className={cn("w-2 h-2 rounded-full", label.color.split(" ")[0].replace("/15", ""))} />
                  <span className={cn("text-xs font-medium px-2 py-0.5 rounded", label.color)}>{label.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px]">{count} tasks</Badge>
                  <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity">
                    <TagIcon className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      <Card className="p-4 md:p-5 card-lift">
        <h3 className="text-sm font-semibold mb-3">Tasks by label</h3>
        <div className="space-y-3">
          {labels.slice(0, 6).map(label => {
            const labelTasks = tasks.filter(t => t.labels.some(l => l.id === label.id))
            return (
              <div key={label.id} className="flex items-center gap-3">
                <span className={cn("text-xs font-medium px-2 py-0.5 rounded min-w-[80px] text-center", label.color)}>{label.name}</span>
                <div className="flex-1 flex items-center gap-1">
                  {labelTasks.slice(0, 8).map(t => (
                    <div key={t.id} className="w-2 h-2 rounded-full bg-primary/40" title={t.title} />
                  ))}
                  {labelTasks.length > 8 && <span className="text-[10px] text-muted-foreground ml-1">+{labelTasks.length - 8}</span>}
                </div>
                <span className="text-xs font-semibold w-8 text-right">{labelTasks.length}</span>
              </div>
            )
          })}
        </div>
      </Card>
    </DashboardShell>
  )
}
