"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Plus, GitBranch, Flag, Clock } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { useTaskStore } from "@/lib/store/task-store"
import { projects } from "@/lib/data/mock"
import { PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import { cn, relativeDay, isOverdue } from "@/lib/utils"
import Link from "next/link"

export default function TaskTimelinePage() {
  const tasks = useTaskStore(s => s.tasks)
  // Group by week
  const now = new Date()
  const weeks: { label: string; tasks: typeof tasks }[] = []
  for (let w = -2; w <= 4; w++) {
    const weekStart = new Date(now)
    weekStart.setDate(now.getDate() - now.getDay() + 1 + w * 7)
    const weekEnd = new Date(weekStart)
    weekEnd.setDate(weekStart.getDate() + 6)
    const label = w === 0 ? "This week" : w < 0 ? `${-w}w ago` : `In ${w}w`
    const weekTasks = tasks.filter(t => {
      if (!t.dueDate) return false
      const d = new Date(t.dueDate)
      return d >= weekStart && d <= weekEnd
    })
    if (weekTasks.length > 0 || w === 0) weeks.push({ label, tasks: weekTasks })
  }

  return (
    <DashboardShell
      title="Task Timeline"
      description="See work spread across weeks — plan ahead and balance load."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New task
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Tracked" value={tasks.filter(t => t.dueDate).length} hint="with due dates" icon={GitBranch} trend={{ value: 8, positive: true }} />
        <StatCard label="Past Due" value={tasks.filter(t => isOverdue(t.dueDate) && t.status !== "done").length} hint="overdue" icon={Flag} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="This Week" value={weeks.find(w => w.label === "This week")?.tasks.length ?? 0} hint="due this week" icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Next 30 Days" value={tasks.filter(t => t.dueDate && new Date(t.dueDate) > now && new Date(t.dueDate) < new Date(now.getTime() + 30 * 86400000)).length} hint="upcoming" icon={GitBranch} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      <div className="space-y-3">
        {weeks.map(week => (
          <Card key={week.label} className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">{week.label}</h3>
              <Badge variant="outline" className="text-[10px]">{week.tasks.length} tasks</Badge>
            </div>
            {week.tasks.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No tasks scheduled</p>
            ) : (
              <div className="space-y-2">
                {week.tasks.map(t => (
                  <Link
                    key={t.id}
                    href={`/tasks/${t.id}`}
                    className="flex items-center gap-3 p-2.5 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors group"
                  >
                    <div className={cn("w-1 self-stretch rounded-full", t.projectColor)} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1">{t.title}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                        <PriorityBadge priority={t.priority} />
                        <TaskStatusBadge status={t.status} />
                        <span className="text-[10px] text-muted-foreground">{t.projectName}</span>
                      </div>
                    </div>
                    {t.dueDate && (
                      <span className={cn("text-[10px] font-semibold",
                        isOverdue(t.dueDate) && t.status !== "done" ? "text-rose-600 dark:text-rose-400" : "text-muted-foreground"
                      )}>
                        {relativeDay(t.dueDate)}
                      </span>
                    )}
                    {t.assigneeAvatar && <Avatar className="w-5 h-5"><AvatarImage src={t.assigneeAvatar} alt={t.assignee ?? ""} /><AvatarFallback className="text-[9px]">{t.assignee?.[0]}</AvatarFallback></Avatar>}
                  </Link>
                ))}
              </div>
            )}
          </Card>
        ))}
      </div>
    </DashboardShell>
  )
}
