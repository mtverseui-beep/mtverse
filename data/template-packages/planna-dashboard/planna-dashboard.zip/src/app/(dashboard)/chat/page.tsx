"use client"

import { useMemo, useRef, useState, useEffect } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Search, Send, Hash, Lock, Plus, ChevronDown, AtSign, Bell, Bookmark,
  Phone, Video, MoreVertical, Settings, Users, MessageSquare, Reply,
  SmilePlus, Paperclip, Circle, UserPlus, Pin, Volume2,
} from "lucide-react"
import { chatThreads, currentMember, members } from "@/lib/data/mock"
import { cn, timeAgo, initials } from "@/lib/utils"
import { toast } from "sonner"

// ============================================================
// SYNTHETIC CHANNELS / DMs / MESSAGES
// ============================================================

interface ChannelMessage {
  id: string
  channelId: string
  authorId: string
  authorName: string
  authorAvatar: string
  authorRole: string
  body: string
  createdAt: string
  reactions?: { emoji: string; count: number; reacted?: boolean }[]
  threadReplies?: number
}

const channels = [
  { id: "ct2", name: "planna-web", private: false, unread: 5, mention: 1, members: 5, topic: "Planna web app — engineering & design" },
  { id: "ct3", name: "design-system", private: false, unread: 0, mention: 0, members: 4, topic: "DS 2.0 — tokens, components, docs" },
  { id: "ct5", name: "acme-client", private: false, unread: 1, mention: 0, members: 6, topic: "Acme SSO + onboarding project" },
  { id: "ch-general", name: "general", private: false, unread: 0, mention: 0, members: 12, topic: "Company-wide chatter & announcements" },
  { id: "ch-eng", name: "engineering", private: false, unread: 0, mention: 0, members: 8, topic: "Eng team discussions" },
  { id: "ch-random", name: "random", private: false, unread: 0, mention: 0, members: 12, topic: "Off-topic, memes, Friday vibes" },
  { id: "ch-leadership", name: "leadership", private: true, unread: 0, mention: 0, members: 4, topic: "Leadership sync" },
]

const dms = chatThreads.filter(t => !t.isGroup).map(t => ({
  id: t.id,
  name: t.name,
  avatar: t.avatar,
  online: members.find(m => m.name === t.name)?.online ?? false,
  unread: t.unread,
}))

const channelMessages: ChannelMessage[] = [
  // planna-web (ct2)
  { id: "cm-1", channelId: "ct2", authorId: "u4", authorName: "Felix Brandt", authorAvatar: members[4].avatar, authorRole: "Frontend Engineer", body: "Command palette is ready for review :tada: Press ⌘K anywhere — pages, tasks, projects, quick actions.", createdAt: "2026-01-28T09:14:00Z", reactions: [{ emoji: "rocket", count: 4, reacted: true }, { emoji: "eyes", count: 2 }], threadReplies: 3 },
  { id: "cm-2", channelId: "ct2", authorId: "u3", authorName: "Theo Nakamura", authorAvatar: members[2].avatar, authorRole: "Engineering Lead", body: "Nice. Are we keeping ⌘K as the only entry point, or also ⌘P?", createdAt: "2026-01-28T09:22:00Z" },
  { id: "cm-3", channelId: "ct2", authorId: "u4", authorName: "Felix Brandt", authorAvatar: members[4].avatar, authorRole: "Frontend Engineer", body: "⌘K only for now — matches Linear/Notion. ⌘P would conflict with print.", createdAt: "2026-01-28T09:25:00Z", reactions: [{ emoji: "+1", count: 3 }] },
  { id: "cm-4", channelId: "ct2", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, authorRole: currentMember.title, body: "+1 on ⌘K only. Ship it. :ship:", createdAt: "2026-01-28T09:31:00Z", reactions: [{ emoji: "+1", count: 2, reacted: true }] },
  { id: "cm-5", channelId: "ct2", authorId: "u6", authorName: "Amara Okafor", authorAvatar: members[5].avatar, authorRole: "Backend Engineer", body: "WS reconnect logic is in PLN-103 — pairing with Felix today on the offline UI state.", createdAt: "2026-01-28T11:02:00Z", threadReplies: 1 },
  // design-system (ct3)
  { id: "cm-6", channelId: "ct3", authorId: "u4", authorName: "Mira Patel", authorAvatar: members[3].avatar, authorRole: "Senior Designer", body: "New tokens are in the Figma file — emerald family got a refresh for AA contrast. Dark-mode 300/400 ratio is now 4.7:1.", createdAt: "2026-01-27T11:00:00Z", reactions: [{ emoji: "tada", count: 3 }] },
  { id: "cm-7", channelId: "ct3", authorId: "u12", authorName: "Sofia Vargas", authorAvatar: members[11].avatar, authorRole: "Design Engineer", body: "Verified. Passes AA on all body text. AAA fails on 14px secondary text against muted bg.", createdAt: "2026-01-27T11:18:00Z" },
  { id: "cm-8", channelId: "ct3", authorId: "u2", authorName: "Zara Marlowe", authorAvatar: members[1].avatar, authorRole: "Head of Product", body: "AA is fine for body, let's bump key CTAs to AAA.", createdAt: "2026-01-27T11:24:00Z", threadReplies: 2 },
  // acme-client (ct5)
  { id: "cm-9", channelId: "ct5", authorId: "u9", authorName: "Hugo Lindqvist", authorAvatar: members[8].avatar, authorRole: "DevOps Engineer", body: "SSO config doc shared — SAML metadata XML in the linked file. Acme Okta tenant confirmed.", createdAt: "2026-01-26T10:00:00Z", reactions: [{ emoji: "white_check_mark", count: 2 }] },
  { id: "cm-10", channelId: "ct5", authorId: "u5", authorName: "Felix Brandt", authorAvatar: members[4].avatar, authorRole: "Frontend Engineer", body: "Thanks. I'll wire JIT provisioning on top of it — should land by Thu.", createdAt: "2026-01-26T10:20:00Z" },
  // general / eng / random / leadership (synthesized short)
  { id: "cm-11", channelId: "ch-general", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, authorRole: currentMember.title, body: "Morning team! Sprint 48 planning kicks off at 10:00 AM in the main room.", createdAt: "2026-01-28T08:30:00Z", reactions: [{ emoji: "wave", count: 5 }] },
  { id: "cm-12", channelId: "ch-eng", authorId: "u3", authorName: "Theo Nakamura", authorAvatar: members[2].avatar, authorRole: "Engineering Lead", body: "PR review queue is at 4 — please clear by EOD so we can ship 47 cleanly.", createdAt: "2026-01-28T07:45:00Z" },
  { id: "cm-13", channelId: "ch-random", authorId: "u11", authorName: "Ravi Kapoor", authorAvatar: members[10].avatar, authorRole: "Customer Success", body: "Anyone else obsessed with the new Focus mode? Just hit 4h today. :fire:", createdAt: "2026-01-28T12:14:00Z", reactions: [{ emoji: "fire", count: 6, reacted: true }] },
]

// ============================================================
// TYPING DOTS
// ============================================================

function TypingDots() {
  return (
    <span className="inline-flex items-center gap-0.5">
      {[0, 1, 2].map(i => (
        <span
          key={i}
          className="w-1 h-1 rounded-full bg-current animate-bounce"
          style={{ animationDelay: `${i * 0.15}s`, animationDuration: "1s" }}
        />
      ))}
    </span>
  )
}

// ============================================================
// CHANNEL MEMBER STATUS (right sidebar)
// ============================================================

const channelMembers = members.slice(0, 8)

export default function ChatPage() {
  const [activeChannelId, setActiveChannelId] = useState("ct2")
  const [sidebarQuery, setSidebarQuery] = useState("")
  const [draft, setDraft] = useState("")
  const [showMobileSidebar, setShowMobileSidebar] = useState(false)
  const [showMobileMembers, setShowMobileMembers] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const activeChannel = channels.find(c => c.id === activeChannelId) ?? channels[0]

  const messages = useMemo(() => {
    return channelMessages
      .filter(m => m.channelId === activeChannelId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
  }, [activeChannelId])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages.length, activeChannelId])

  const filteredChannels = useMemo(() => {
    const q = sidebarQuery.trim().toLowerCase()
    if (!q) return channels
    return channels.filter(c => c.name.includes(q))
  }, [sidebarQuery])

  const handleSend = () => {
    const text = draft.trim()
    if (!text) return
    channelMessages.push({
      id: `mine-${Date.now()}`,
      channelId: activeChannelId,
      authorId: "u1",
      authorName: currentMember.name,
      authorAvatar: currentMember.avatar,
      authorRole: currentMember.title,
      body: text,
      createdAt: new Date().toISOString(),
    })
    setDraft("")
    toast.success("Message posted", { description: `#${activeChannel.name}` })
  }

  return (
    <DashboardShell
      title="Chat"
      description="Slack-style real-time chat with your team — channels, DMs, and reactions."
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Bookmark className="w-3.5 h-3.5" /> Saved
          </Button>
          <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
            <Plus className="w-4 h-4" /> New channel
          </Button>
        </>
      }
    >
      <Card className="p-0 overflow-hidden border border-border rounded-xl">
        <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] xl:grid-cols-[260px_1fr_240px] h-[calc(100vh-220px)] min-h-[560px]">
          {/* LEFT — channels + DMs */}
          <aside
            className={cn(
              "border-r border-border flex flex-col bg-card",
              showMobileSidebar ? "block" : "hidden lg:flex"
            )}
          >
            {/* Workspace header */}
            <div className="p-3 border-b border-border">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                  P
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">Planna HQ</p>
                  <p className="text-[10px] text-muted-foreground truncate">{currentMember.name}</p>
                </div>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground">
                  <ChevronDown className="w-3.5 h-3.5" />
                </Button>
              </div>
              <div className="relative mt-2">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  value={sidebarQuery}
                  onChange={e => setSidebarQuery(e.target.value)}
                  placeholder="Search conversations…"
                  className="h-8 pl-8 text-xs bg-secondary/50 border-transparent focus-visible:bg-card focus-visible:border-border"
                />
              </div>
            </div>

            <ScrollArea className="flex-1">
              <div className="p-2 space-y-4">
                {/* Quick links */}
                <div className="space-y-0.5">
                  {[
                    { label: "Threads", icon: MessageSquare, count: 4 },
                    { label: "Mentions & reactions", icon: AtSign, count: 2 },
                    { label: "Saved items", icon: Bookmark, count: 8 },
                    { label: "More", icon: MoreVertical },
                  ].map(item => (
                    <button
                      key={item.label}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary/60 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <item.icon className="w-3.5 h-3.5" />
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.count && (
                        <Badge variant="secondary" className="text-[10px] h-4 px-1.5">{item.count}</Badge>
                      )}
                    </button>
                  ))}
                </div>

                {/* Channels */}
                <div>
                  <div className="flex items-center gap-1 px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    <ChevronDown className="w-3 h-3" />
                    Channels
                    <Button variant="ghost" size="icon" className="ml-auto h-5 w-5 hover:bg-secondary">
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="space-y-0.5">
                    {filteredChannels.map(ch => {
                      const isSel = ch.id === activeChannelId
                      return (
                        <button
                          key={ch.id}
                          onClick={() => { setActiveChannelId(ch.id); setShowMobileSidebar(false) }}
                          className={cn(
                            "w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs transition-colors group",
                            isSel ? "bg-primary/10 text-primary font-semibold" : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
                          )}
                        >
                          {ch.private ? <Lock className="w-3 h-3 shrink-0" /> : <Hash className="w-3 h-3 shrink-0" />}
                          <span className="flex-1 text-left truncate">{ch.name}</span>
                          {ch.mention > 0 && (
                            <Badge className="text-[10px] h-4 px-1.5 bg-primary text-primary-foreground">@{ch.mention}</Badge>
                          )}
                          {ch.unread > 0 && ch.mention === 0 && (
                            <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          )}
                        </button>
                      )
                    })}
                  </div>
                </div>

                {/* Direct messages */}
                <div>
                  <div className="flex items-center gap-1 px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    <ChevronDown className="w-3 h-3" />
                    Direct messages
                    <Button variant="ghost" size="icon" className="ml-auto h-5 w-5 hover:bg-secondary">
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="space-y-0.5">
                    {/* You */}
                    <div className="flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs text-muted-foreground">
                      <div className="relative">
                        <Avatar className="w-4 h-4">
                          <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
                          <AvatarFallback className="text-[8px]">{initials(currentMember.name)}</AvatarFallback>
                        </Avatar>
                        <span className="absolute -bottom-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-500 ring-1 ring-card" />
                      </div>
                      <span className="flex-1 text-left italic">You (saved messages)</span>
                    </div>
                    {dms.map(dm => {
                      const isSel = dm.id === activeChannelId
                      return (
                        <button
                          key={dm.id}
                          onClick={() => { setActiveChannelId(dm.id); setShowMobileSidebar(false) }}
                          className={cn(
                            "w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs transition-colors",
                            isSel ? "bg-primary/10 text-primary font-semibold" : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
                          )}
                        >
                          <div className="relative">
                            <Avatar className="w-4 h-4">
                              <AvatarImage src={dm.avatar} alt={dm.name} />
                              <AvatarFallback className="text-[8px]">{initials(dm.name)}</AvatarFallback>
                            </Avatar>
                            <span className={cn(
                              "absolute -bottom-0.5 -right-0.5 w-1.5 h-1.5 rounded-full ring-1 ring-card",
                              dm.online ? "bg-emerald-500" : "bg-muted-foreground/40"
                            )} />
                          </div>
                          <span className="flex-1 text-left truncate">{dm.name}</span>
                          {dm.unread > 0 && (
                            <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          )}
                        </button>
                      )
                    })}
                  </div>
                </div>

                {/* Footer */}
                <div className="pt-2 border-t border-border">
                  <button className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary/60 text-xs text-muted-foreground hover:text-foreground transition-colors">
                    <UserPlus className="w-3.5 h-3.5" /> Invite teammates
                  </button>
                  <button className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary/60 text-xs text-muted-foreground hover:text-foreground transition-colors">
                    <Settings className="w-3.5 h-3.5" /> Preferences
                  </button>
                </div>
              </div>
            </ScrollArea>
          </aside>

          {/* MIDDLE — channel messages + composer */}
          <section className={cn("flex flex-col min-w-0", showMobileSidebar && "hidden lg:flex")}>
            {/* Channel header */}
            <div className="flex items-center gap-2 p-3 border-b border-border bg-card">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 lg:hidden"
                onClick={() => setShowMobileSidebar(true)}
              >
                <ChevronDown className="w-4 h-4" />
              </Button>
              {activeChannel.private ? <Lock className="w-3.5 h-3.5 text-muted-foreground" /> : <Hash className="w-4 h-4 text-muted-foreground" />}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{activeChannel.name}</p>
                <p className="text-[11px] text-muted-foreground truncate">{activeChannel.topic}</p>
              </div>
              <div className="flex items-center gap-0.5">
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <Phone className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <Video className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <Pin className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-foreground xl:hidden"
                  onClick={() => setShowMobileMembers(v => !v)}
                >
                  <Users className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Messages stream */}
            <ScrollArea className="flex-1 bg-secondary/20">
              <div className="px-4 py-4">
                {/* Channel intro */}
                <div className="mb-6 p-4 rounded-xl bg-card border border-border">
                  <div className="w-12 h-12 rounded-xl bg-primary/15 text-primary flex items-center justify-center mb-2">
                    {activeChannel.private ? <Lock className="w-5 h-5" /> : <Hash className="w-5 h-5" />}
                  </div>
                  <p className="text-sm font-bold text-foreground">
                    {activeChannel.private ? "This is a private channel" : `Welcome to #${activeChannel.name}`}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {activeChannel.topic}. {activeChannel.members} members.
                  </p>
                </div>

                {messages.length === 0 ? (
                  <div className="py-12 text-center">
                    <MessageSquare className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
                    <p className="text-sm font-medium text-foreground">No messages yet</p>
                    <p className="text-xs text-muted-foreground mt-1">Be the first to say something.</p>
                  </div>
                ) : (
                  <div className="space-y-0.5">
                    {messages.map((msg, idx) => {
                      const prev = messages[idx - 1]
                      const showHeader = !prev ||
                        prev.authorId !== msg.authorId ||
                        new Date(msg.createdAt).getTime() - new Date(prev.createdAt).getTime() > 5 * 60 * 1000
                      return (
                        <div
                          key={msg.id}
                          className={cn(
                            "group flex gap-2.5 px-2 py-0.5 rounded-md hover:bg-secondary/40 transition-colors animate-fade-in",
                            showHeader ? "mt-3" : "mt-0"
                          )}
                        >
                          <div className="w-9 shrink-0">
                            {showHeader && (
                              <Avatar className="w-9 h-9">
                                <AvatarImage src={msg.authorAvatar} alt={msg.authorName} />
                                <AvatarFallback className="text-[10px]">{initials(msg.authorName)}</AvatarFallback>
                              </Avatar>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            {showHeader && (
                              <div className="flex items-baseline gap-2 mb-0.5">
                                <span className="text-sm font-bold text-foreground">{msg.authorName}</span>
                                {msg.authorName === currentMember.name && (
                                  <Badge variant="outline" className="text-[9px] h-4 px-1 py-0 bg-primary/10 text-primary border-primary/20">You</Badge>
                                )}
                                <span className="text-[10px] text-muted-foreground">
                                  {new Date(msg.createdAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                                </span>
                              </div>
                            )}
                            <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap break-words">
                              {msg.body}
                            </p>
                            {msg.reactions && msg.reactions.length > 0 && (
                              <div className="flex items-center gap-1 mt-1.5">
                                {msg.reactions.map(r => (
                                  <button
                                    key={r.emoji}
                                    className={cn(
                                      "inline-flex items-center gap-1 px-1.5 h-5 rounded-full border text-[11px] transition-colors",
                                      r.reacted
                                        ? "bg-primary/10 border-primary/30 text-primary"
                                        : "bg-card border-border text-muted-foreground hover:border-primary/30 hover:bg-primary/5"
                                    )}
                                  >
                                    <span className="text-[11px]">:{r.emoji}:</span>
                                    <span className="font-semibold">{r.count}</span>
                                  </button>
                                ))}
                                <button className="opacity-0 group-hover:opacity-100 transition-opacity w-5 h-5 rounded-full border border-border bg-card text-muted-foreground hover:bg-secondary flex items-center justify-center">
                                  <SmilePlus className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                            {msg.threadReplies && msg.threadReplies > 0 && (
                              <button className="mt-1.5 flex items-center gap-1.5 text-[11px] text-primary font-medium hover:underline">
                                <Avatar className="w-4 h-4 ring-2 ring-card">
                                  <AvatarImage src={msg.authorAvatar} alt="" />
                                  <AvatarFallback className="text-[7px]">{initials(msg.authorName)}</AvatarFallback>
                                </Avatar>
                                <span className="rounded-full bg-primary/10 px-1.5 py-0.5">{msg.threadReplies} reply{msg.threadReplies > 1 ? "replies" : ""}</span>
                                <Reply className="w-3 h-3" /> View thread
                              </button>
                            )}
                          </div>
                          {/* Hover action bar */}
                          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-start -mt-1">
                            <div className="flex items-center border border-border rounded-md bg-card shadow-sm">
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground">
                                <SmilePlus className="w-3.5 h-3.5" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground">
                                <Reply className="w-3.5 h-3.5" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground">
                                <Bookmark className="w-3.5 h-3.5" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground">
                                <MoreVertical className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      )
                    })}

                    {/* Typing indicator */}
                    <div className="flex items-center gap-2.5 px-2 py-2 mt-2 animate-fade-in">
                      <Avatar className="w-7 h-7">
                        <AvatarImage src={members[4].avatar} alt="Felix Brandt" />
                        <AvatarFallback className="text-[9px]">FB</AvatarFallback>
                      </Avatar>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground font-medium">Felix Brandt is typing</span>
                        <span className="text-primary"><TypingDots /></span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Composer */}
            <div className="p-3 border-t border-border bg-card">
              <div className="rounded-lg border border-border bg-card overflow-hidden focus-within:border-primary/40 focus-within:ring-2 focus-within:ring-primary/15 transition-all">
                <Input
                  value={draft}
                  onChange={e => setDraft(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      handleSend()
                    }
                  }}
                  placeholder={`Message #${activeChannel.name}`}
                  className="border-0 bg-transparent h-9 text-sm focus-visible:ring-0 focus-visible:ring-offset-0"
                />
                <div className="flex items-center justify-between px-2 pb-1.5">
                  <div className="flex items-center gap-0.5">
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground">
                      <Paperclip className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground">
                      <AtSign className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground">
                      <SmilePlus className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                  <Button
                    onClick={handleSend}
                    disabled={!draft.trim()}
                    size="icon"
                    className="h-7 w-7 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5 px-1">
                <strong className="text-foreground">Tip:</strong> Use <kbd className="px-1 py-0.5 rounded bg-muted border border-border text-[9px] font-semibold">@name</kbd> to mention · <kbd className="px-1 py-0.5 rounded bg-muted border border-border text-[9px] font-semibold">:emoji:</kbd> to react
              </p>
            </div>
          </section>

          {/* RIGHT — members / channel info */}
          <aside
            className={cn(
              "border-l border-border flex-col bg-card overflow-y-auto",
              showMobileMembers ? "flex" : "hidden xl:flex"
            )}
          >
            <div className="p-4 border-b border-border">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-3.5 h-3.5 text-muted-foreground" />
                <p className="text-xs font-semibold text-foreground">Members</p>
                <Badge variant="secondary" className="ml-auto text-[10px]">{activeChannel.members}</Badge>
              </div>
            </div>
            <div className="p-3 space-y-1">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 mb-1">Online — {channelMembers.filter(m => m.online).length}</p>
              {channelMembers.filter(m => m.online).map(m => (
                <div key={m.id} className="flex items-center gap-2.5 px-2 py-1.5 rounded-md hover:bg-secondary/60 cursor-pointer transition-colors">
                  <div className="relative">
                    <Avatar className="w-7 h-7">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback className="text-[10px]">{initials(m.name)}</AvatarFallback>
                    </Avatar>
                    <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-card" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">
                      {m.name}{m.id === currentMember.id && " (you)"}
                    </p>
                    <p className="text-[10px] text-muted-foreground truncate">{m.title}</p>
                  </div>
                  <Circle className="w-2 h-2 fill-emerald-500 text-emerald-500" />
                </div>
              ))}
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 mb-1 mt-3">Offline — {channelMembers.filter(m => !m.online).length}</p>
              {channelMembers.filter(m => !m.online).map(m => (
                <div key={m.id} className="flex items-center gap-2.5 px-2 py-1.5 rounded-md hover:bg-secondary/60 cursor-pointer transition-colors opacity-60">
                  <div className="relative">
                    <Avatar className="w-7 h-7 grayscale">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback className="text-[10px]">{initials(m.name)}</AvatarFallback>
                    </Avatar>
                    <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-muted-foreground/40 ring-2 ring-card" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{m.title}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-auto p-3 border-t border-border space-y-1">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 mb-1">Channel actions</p>
              <button className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary/60 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <Bell className="w-3.5 h-3.5" /> Notification settings
              </button>
              <button className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary/60 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <Volume2 className="w-3.5 h-3.5" /> Mute channel
              </button>
              <button className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary/60 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <Bookmark className="w-3.5 h-3.5" /> Save channel
              </button>
            </div>
          </aside>
        </div>
      </Card>
    </DashboardShell>
  )
}
