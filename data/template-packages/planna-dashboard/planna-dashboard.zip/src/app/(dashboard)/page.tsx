"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaAreaChart, PlannaDonutChart, PlannaRadialChart, PlannaBarChart, PlannaHeatmap } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  CheckSquare, Clock, FolderKanban, Users, Plus, Download, Play,
  Pause, Square, Timer as TimerIcon, Sparkles, ArrowUpRight,
  TrendingUp, Calendar, Target, Zap, Flame,
} from "lucide-react"
import {
  dashboardStats, productivityTrend, timeByProject, workloadByMember,
  activities, tasks, projects, members, focusHeatmap, currentMember,
} from "@/lib/data/mock"
import { useTimerStore, formatTimer, getElapsed } from "@/lib/store/timer-store"
import { useTaskStore } from "@/lib/store/task-store"
import { useEffect, useState } from "react"
import Link from "next/link"
import { PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import { cn, timeAgo, relativeDay, pct } from "@/lib/utils"

export default function MainPage() {
  return (
    <DashboardShell
      title="Dashboard"
      description="Plan, prioritize, and accomplish your tasks with ease."
      actions={
        <>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 hover:shadow-lg hover:shadow-primary/30 hover:scale-105 gap-1.5">
            <Plus className="w-4 h-4" /> Add Project
          </Button>
          <Button variant="outline" className="h-9 text-sm transition-all duration-300 hover:shadow-md hover:scale-105 gap-1.5 bg-transparent">
            <Download className="w-4 h-4" /> Import Data
          </Button>
        </>
      }
    >
      {/* Continue where you left off */}
      <ContinueWhereYouLeftOff />

      {/* Top stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard
          label="Total Tasks"
          value={dashboardStats.totalTasks}
          hint={`${dashboardStats.completedTasks} completed`}
          icon={CheckSquare}
          trend={{ value: 12, positive: true }}
        />
        <StatCard
          label="Active Projects"
          value={dashboardStats.activeProjects}
          hint={`of ${dashboardStats.totalProjects} total`}
          icon={FolderKanban}
          trend={{ value: 4, positive: true }}
          iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400"
        />
        <StatCard
          label="Hours This Week"
          value={dashboardStats.hoursThisWeek}
          hint={`${dashboardStats.billableHours}h billable`}
          icon={Clock}
          trend={{ value: 8, positive: true }}
          iconColor="bg-lime-500/15 text-lime-600 dark:text-lime-400"
        />
        <StatCard
          label="Productivity Score"
          value={`${dashboardStats.productivityScore}%`}
          hint="+5% vs last week"
          icon={Sparkles}
          trend={{ value: 5, positive: true }}
          iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
        />
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <div className="lg:col-span-2 space-y-3 md:space-y-4">
          {/* Productivity chart */}
          <ChartCard
            title="Productivity Trend"
            subtitle="Tasks completed vs planned, last 12 weeks"
            action={
              <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px]">
                <TrendingUp className="w-3 h-3 mr-1" /> +18% MoM
              </Badge>
            }
          >
            <PlannaAreaChart
              data={productivityTrend}
              xKey="week"
              series={[
                { key: "completed", name: "Completed" },
                { key: "planned", name: "Planned", color: "var(--chart-4)" },
                { key: "focus", name: "Focus Hours", color: "var(--chart-2)" },
              ]}
              height={260}
            />
          </ChartCard>

          {/* Team collaboration */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Team Collaboration</h3>
                <p className="text-xs text-muted-foreground">Recent activity across your team</p>
              </div>
              <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <Link href="/team/activity">View all <ArrowUpRight className="w-3 h-3" /></Link>
              </Button>
            </div>
            <div className="space-y-3">
              {activities.slice(0, 5).map(a => (
                <div key={a.id} className="flex items-start gap-3 group">
                  <Avatar className="w-8 h-8 ring-2 ring-card shadow-sm">
                    <AvatarImage src={a.actorAvatar} alt={a.actor} />
                    <AvatarFallback className="text-xs">{a.actor[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground">
                      <span className="font-semibold">{a.actor}</span>{" "}
                      <span className="text-muted-foreground">{a.action}</span>{" "}
                      <span className="font-medium">{a.target}</span>
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{timeAgo(a.createdAt)}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right column */}
        <div className="space-y-3 md:space-y-4">
          {/* Reminders / Due today */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Due Today</h3>
              <Badge className="bg-rose-500/15 text-rose-600 dark:text-rose-400 text-[10px]">
                {tasks.filter(t => t.dueDate && relativeDay(t.dueDate) === "Today").length} tasks
              </Badge>
            </div>
            <div className="space-y-2">
              {tasks
                .filter(t => t.status !== "done" && t.dueDate)
                .slice(0, 4)
                .map(t => (
                  <Link
                    key={t.id}
                    href={`/tasks/${t.id}`}
                    className="block p-2 -mx-2 rounded-lg hover:bg-secondary/50 transition-colors group"
                  >
                    <div className="flex items-start gap-2">
                      <div className={cn("w-1 self-stretch rounded-full shrink-0", t.projectColor)} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-foreground line-clamp-1 group-hover:text-primary transition-colors">
                          {t.title}
                        </p>
                        <div className="flex items-center gap-1.5 mt-1">
                          <PriorityBadge priority={t.priority} />
                          <span className="text-[10px] text-muted-foreground">{t.key}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
            </div>
          </Card>

          {/* Project progress */}
          <Card className="p-4 md:p-5 card-lift">
            <h3 className="text-sm font-semibold text-foreground mb-4">Project Progress</h3>
            <div className="space-y-3">
              {projects.filter(p => p.status === "active").slice(0, 4).map(p => (
                <div key={p.id}>
                  <div className="flex items-center justify-between mb-1.5">
                    <Link href={`/projects/${p.id}`} className="text-xs font-medium hover:text-primary transition-colors">
                      {p.name}
                    </Link>
                    <span className="text-[11px] font-semibold text-muted-foreground">{p.progress}%</span>
                  </div>
                  <Progress value={p.progress} className="h-1.5" />
                </div>
              ))}
            </div>
          </Card>

          {/* Mini timer widget */}
          <MiniTimerCard />
        </div>
      </div>

      {/* Bottom grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Project list */}
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-foreground">Active Projects</h3>
            <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
              <Link href="/projects">All</Link>
            </Button>
          </div>
          <div className="space-y-2.5">
            {projects.filter(p => p.status === "active").slice(0, 5).map(p => (
              <Link
                key={p.id}
                href={`/projects/${p.id}`}
                className="flex items-center gap-3 p-2 -mx-2 rounded-lg hover:bg-secondary/50 transition-colors"
              >
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center shrink-0", p.color)}>
                  <FolderKanban className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{p.name}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {p.tasksDone}/{p.tasksTotal} tasks · due {relativeDay(p.dueDate)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-foreground">{p.progress}%</p>
                </div>
              </Link>
            ))}
          </div>
        </Card>

        {/* Workload radial */}
        <ChartCard title="Team Workload" subtitle="This week's utilization" fullscreen={false}>
          <PlannaBarChart
            data={workloadByMember.slice(0, 6).map(w => ({ name: w.name, hours: w.utilized }))}
            xKey="name"
            series={[{ key: "hours", name: "Hours", color: "var(--chart-1)" }]}
            height={220}
            showLegend={false}
          />
        </ChartCard>

        {/* Focus heatmap */}
        <ChartCard title="Focus Sessions" subtitle="When you focus, by hour & day" fullscreen={false}>
          <PlannaHeatmap data={focusHeatmap} />
        </ChartCard>
      </div>
    </DashboardShell>
  )
}

function ContinueWhereYouLeftOff() {
  const tasks = useTaskStore(s => s.tasks)
  const inProgress = tasks.filter(t => t.status === "in_progress" || t.status === "review").slice(0, 3)
  return (
    <Card className="p-4 md:p-5 mb-4 bg-gradient-to-r from-primary/5 via-card to-card border-primary/20 card-lift">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-foreground">Continue where you left off</h3>
            <p className="text-[11px] text-muted-foreground">Pick up your in-progress work</p>
          </div>
        </div>
        <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
          <Link href="/tasks/my">All my tasks <ArrowUpRight className="w-3 h-3" /></Link>
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
        {inProgress.map(t => (
          <Link
            key={t.id}
            href={`/tasks/${t.id}`}
            className="group p-3 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-md transition-all duration-300 hover:-translate-y-0.5"
          >
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
              <PriorityBadge priority={t.priority} />
              <TaskStatusBadge status={t.status} />
            </div>
            <p className="text-xs font-medium text-foreground line-clamp-2 group-hover:text-primary transition-colors mb-2">
              {t.title}
            </p>
            <div className="flex items-center justify-between">
              {t.assigneeAvatar && (
                <Avatar className="w-5 h-5">
                  <AvatarImage src={t.assigneeAvatar} alt={t.assignee ?? ""} />
                  <AvatarFallback className="text-[9px]">{t.assignee?.[0]}</AvatarFallback>
                </Avatar>
              )}
              {t.dueDate && (
                <span className="text-[10px] text-muted-foreground">{relativeDay(t.dueDate)}</span>
              )}
            </div>
          </Link>
        ))}
      </div>
    </Card>
  )
}

function MiniTimerCard() {
  const timer = useTimerStore()
  const [, force] = useState(0)
  useEffect(() => {
    if (!timer.running) return
    const i = setInterval(() => force(x => x + 1), 1000)
    return () => clearInterval(i)
  }, [timer.running])

  const elapsed = getElapsed()
  return (
    <Card className="p-4 md:p-5 card-lift bg-gradient-to-br from-emerald-500/5 to-card">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <TimerIcon className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Time Tracker</h3>
        </div>
        {timer.running && (
          <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Running
          </Badge>
        )}
      </div>
      <div className="text-center my-4">
        <p className="text-3xl font-bold text-foreground tabular-nums tracking-tight">
          {formatTimer(elapsed)}
        </p>
        <p className="text-[11px] text-muted-foreground mt-1">{timer.projectName}</p>
      </div>
      <div className="flex items-center justify-center gap-2">
        {!timer.running ? (
          <Button
            size="sm"
            className="h-8 gap-1.5 bg-primary hover:bg-primary/90"
            onClick={() => timer.start()}
          >
            <Play className="w-3.5 h-3.5" /> Start
          </Button>
        ) : (
          <Button
            size="sm"
            variant="outline"
            className="h-8 gap-1.5"
            onClick={() => timer.pause()}
          >
            <Pause className="w-3.5 h-3.5" /> Pause
          </Button>
        )}
        <Button
          size="sm"
          variant="ghost"
          className="h-8 gap-1.5"
          onClick={() => timer.reset()}
          disabled={elapsed === 0 && !timer.running}
        >
          <Square className="w-3.5 h-3.5" /> Reset
        </Button>
      </div>
      <Button asChild variant="ghost" size="sm" className="w-full h-7 text-xs mt-2 gap-1">
        <Link href="/time">Open tracker <ArrowUpRight className="w-3 h-3" /></Link>
      </Button>
    </Card>
  )
}
