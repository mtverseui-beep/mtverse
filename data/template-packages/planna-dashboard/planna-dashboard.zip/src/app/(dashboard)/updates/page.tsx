"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Rocket, Sparkles, Plus, CheckCircle2, Wrench, Zap, Search, Pin,
  Calendar, Tag, Mail, Bell, BellOff, ChevronDown, ArrowUpRight,
  GitBranch, type LucideIcon,
} from "lucide-react"
import { members, currentMember } from "@/lib/data/mock"
import { cn, formatDate, initials } from "@/lib/utils"
import { toast } from "sonner"

// ============================================================
// RELEASE DATA
// ============================================================

type ChangeType = "added" | "improved" | "fixed"

interface Change {
  type: ChangeType
  text: string
}

interface Release {
  id: string
  version: string
  date: string
  title: string
  summary: string
  author: string
  authorAvatar: string
  pinned?: boolean
  latest?: boolean
  status: "released" | "beta" | "planned"
  changes: Change[]
}

const releases: Release[] = [
  {
    id: "rel-2-4",
    version: "v2.4.0",
    date: "2026-01-28",
    title: "Command Palette & Kanban 2.0",
    summary: "Press ⌘K anywhere to search pages, tasks, projects, and trigger quick actions. Plus a rebuilt Kanban with drag-and-drop, optimistic updates, and WIP limits.",
    author: members[0].name,
    authorAvatar: members[0].avatar,
    pinned: true,
    latest: true,
    status: "released",
    changes: [
      { type: "added", text: "Command palette (⌘K) with fuzzy search across pages, tasks, projects, and quick actions" },
      { type: "added", text: "Kanban drag-and-drop with optimistic updates and rollback on error" },
      { type: "added", text: "WIP limits per column with visual warning when exceeded" },
      { type: "added", text: "Recurring task scheduler — daily, weekly, monthly recurrence with skip-on-holiday" },
      { type: "improved", text: "Notification center with type filters and date grouping" },
      { type: "improved", text: "Sidebar now collapses to icon-only on smaller viewports" },
      { type: "fixed", text: "WebSocket reconnect no longer silently fails after 10 retries — added manual reconnect button" },
      { type: "fixed", text: "IDOR vulnerability in /api/v1/projects/{id} (SEC-901)" },
      { type: "fixed", text: "Theme toggle flash on first page load" },
    ],
  },
  {
    id: "rel-2-3",
    version: "v2.3.0",
    date: "2026-01-14",
    title: "Time tracking 2.0 & Focus mode",
    summary: "A rebuilt time tracking experience with pause/resume, manual entries, and a new Focus mode for distraction-free deep work.",
    author: members[2].name,
    authorAvatar: members[2].avatar,
    status: "released",
    changes: [
      { type: "added", text: "Focus mode with Pomodoro timer (25/5, 50/10, custom)" },
      { type: "added", text: "Pause / resume for running time entries" },
      { type: "added", text: "Manual time entry modal with last-used project pre-selected" },
      { type: "added", text: "Time approval workflow — submit, approve, reject" },
      { type: "improved", text: "Billable vs non-billable split is now visible on every time entry" },
      { type: "improved", text: "Weekly timesheet view prints cleanly to PDF" },
      { type: "fixed", text: "Time entries with midnight crossover no longer split into two entries" },
    ],
  },
  {
    id: "rel-2-2",
    version: "v2.2.0",
    date: "2025-12-22",
    title: "Analytics overhaul & Custom dashboards",
    summary: "Eight new analytics views, custom dashboard builder, and a productivity score that adapts to your team's working patterns.",
    author: members[5].name,
    authorAvatar: members[5].avatar,
    status: "released",
    changes: [
      { type: "added", text: "Custom dashboard builder — drag widgets onto a grid, save layouts per user" },
      { type: "added", text: "Productivity score with daily, weekly, monthly rollups" },
      { type: "added", text: "Workload by member heatmap (capacity vs utilized)" },
      { type: "added", text: "Project completion forecast using 4-week rolling velocity" },
      { type: "improved", text: "Charts now use the green Planna palette throughout" },
      { type: "improved", text: "Analytics pages load 3.2× faster with chart memoization" },
    ],
  },
  {
    id: "rel-2-1",
    version: "v2.1.0",
    date: "2025-12-08",
    title: "Public API platform & Webhooks",
    summary: "Programmatic access to Planna. REST API, signed webhooks, and rate limiting — all documented at /docs.",
    author: members[5].name,
    authorAvatar: members[5].avatar,
    status: "released",
    changes: [
      { type: "added", text: "Public REST API v1 — tasks, projects, time entries, members" },
      { type: "added", text: "Signed webhooks with HMAC verification" },
      { type: "added", text: "API key management with scoped permissions (read/write per resource)" },
      { type: "added", text: "Rate limiting — 1000 req/min per key, configurable bursts" },
      { type: "improved", text: "API reference docs with curl, JS, and Python examples" },
    ],
  },
  {
    id: "rel-2-0",
    version: "v2.0.0",
    date: "2025-11-15",
    title: "Planna 2.0 — A fresh start",
    summary: "A complete redesign with the new green/white identity, faster navigation, and a flexible layout that adapts to your role.",
    author: members[0].name,
    authorAvatar: members[0].avatar,
    status: "released",
    changes: [
      { type: "added", text: "New emerald/white design system with WCAG AA-compliant color tokens" },
      { type: "added", text: "Dark mode with auto system detection" },
      { type: "added", text: "Collapsible sidebar with command-palette-first navigation" },
      { type: "added", text: "Role-based dashboard variants (executive, manager, individual contributor)" },
      { type: "improved", text: "Initial page load reduced from 2.1s to 0.9s via streaming SSR" },
      { type: "fixed", text: "Dozens of accessibility issues identified in the v1 audit" },
    ],
  },
  {
    id: "rel-2-5-beta",
    version: "v2.5.0-beta",
    date: "2026-02-04",
    title: "Calendar 2.0 & Mobile companion",
    summary: "A brand-new calendar with overlapping events, multi-day views, and drag-to-move. Mobile companion enters public beta.",
    author: members[6].name,
    authorAvatar: members[6].avatar,
    status: "beta",
    changes: [
      { type: "added", text: "Calendar month view with overlapping event rendering" },
      { type: "added", text: "Drag-to-move events with conflict resolution" },
      { type: "added", text: "iOS + Android beta program (limited to 50 seats)" },
      { type: "improved", text: "Google Calendar two-way sync reliability (+38% fewer dropped events)" },
    ],
  },
  {
    id: "rel-2-6-planned",
    version: "v2.6.0",
    date: "2026-03-15",
    title: "Roadmap: SOC2 Type 2 & SSO",
    summary: "Enterprise-ready: SAML SSO via Okta/Entra, SCIM provisioning, and SOC2 Type 2 audit completion.",
    author: members[2].name,
    authorAvatar: members[2].avatar,
    status: "planned",
    changes: [
      { type: "added", text: "SAML 2.0 SSO via Okta, Microsoft Entra, and Google Workspace" },
      { type: "added", text: "SCIM 2.0 user provisioning with JIT role mapping" },
      { type: "added", text: "SOC2 Type 2 audit completion (Q1 2026 target)" },
      { type: "added", text: "Audit log retention policy (12 months default, 7 years enterprise)" },
    ],
  },
]

// ============================================================
// CHANGE TYPE CONFIG
// ============================================================

const changeConfig: Record<ChangeType, { label: string; icon: LucideIcon; chip: string; ring: string }> = {
  added:    { label: "Added",    icon: Plus,           chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",  ring: "bg-emerald-500" },
  improved: { label: "Improved", icon: Zap,            chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400",          ring: "bg-teal-500" },
  fixed:    { label: "Fixed",    icon: Wrench,         chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400",      ring: "bg-amber-500" },
}

const statusConfig: Record<Release["status"], { label: string; chip: string }> = {
  released: { label: "Released", chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  beta:     { label: "Beta",     chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  planned:  { label: "Planned",  chip: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
}

// ============================================================
// PAGE
// ============================================================

export default function UpdatesPage() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [subscribed, setSubscribed] = useState(false)

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return releases
      .filter(r => statusFilter === "all" || r.status === statusFilter)
      .filter(r => !q || r.title.toLowerCase().includes(q) || r.summary.toLowerCase().includes(q) || r.changes.some(c => c.text.toLowerCase().includes(q)))
      .sort((a, b) => {
        // Pinned/latest first, then by date desc
        if ((a.pinned ?? false) !== (b.pinned ?? false)) return a.pinned ? -1 : 1
        return new Date(b.date).getTime() - new Date(a.date).getTime()
      })
  }, [search, statusFilter])

  const counts = useMemo(() => ({
    all: releases.length,
    released: releases.filter(r => r.status === "released").length,
    beta: releases.filter(r => r.status === "beta").length,
    planned: releases.filter(r => r.status === "planned").length,
  }), [])

  const pinned = filtered.filter(r => r.pinned)
  const regular = filtered.filter(r => !r.pinned)

  const handleSubscribe = () => {
    setSubscribed(s => !s)
    if (!subscribed) {
      toast.success("Subscribed to product updates", {
        description: "You'll get an email when new releases ship.",
      })
    } else {
      toast.info("Unsubscribed from product updates")
    }
  }

  const filterTabs = [
    { key: "all", label: "All", count: counts.all },
    { key: "released", label: "Released", count: counts.released },
    { key: "beta", label: "Beta", count: counts.beta },
    { key: "planned", label: "Planned", count: counts.planned },
  ]

  return (
    <DashboardShell
      title="What's new"
      description="Product changelog, release notes, and what's coming next. Subscribe to never miss a release."
      actions={
        <>
          <Button
            variant="outline"
            size="sm"
            className={cn("h-9 gap-1.5 bg-transparent", subscribed && "bg-primary/10 text-primary border-primary/30")}
            onClick={handleSubscribe}
          >
            {subscribed ? <Bell className="w-3.5 h-3.5" /> : <BellOff className="w-3.5 h-3.5" />}
            {subscribed ? "Subscribed" : "Subscribe"}
          </Button>
          <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
            <Rocket className="w-4 h-4" /> Release a version
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total releases" value={releases.length} hint="all-time" icon={Rocket} />
        <StatCard label="Latest version" value={releases.find(r => r.latest)?.version ?? "v2.4.0"} hint="shipped today" icon={Tag} iconColor="bg-primary/15 text-primary" />
        <StatCard label="In beta" value={counts.beta} hint="opt-in features" icon={Sparkles} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Planned" value={counts.planned} hint="on the roadmap" icon={GitBranch} iconColor="bg-sky-500/15 text-sky-600 dark:text-sky-400" />
      </div>

      {/* Subscribe banner */}
      {!subscribed && (
        <Card className="p-4 md:p-5 mb-4 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 card-lift">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground">Never miss a release</p>
              <p className="text-xs text-muted-foreground mt-0.5">Get an email when Planna ships new features, fixes, and improvements.</p>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Input placeholder="you@company.com" className="h-9 text-xs flex-1 sm:w-56" />
              <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90 shrink-0" onClick={handleSubscribe}>
                <Bell className="w-3.5 h-3.5" /> Subscribe
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search releases, features, fixes…"
              className="h-9 pl-8 text-xs"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 text-xs w-full md:w-[160px]">
              <SelectValue placeholder="All statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="released">Released</SelectItem>
              <SelectItem value="beta">Beta</SelectItem>
              <SelectItem value="planned">Planned</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar -mx-1 px-1 mt-3">
          {filterTabs.map(tab => {
            const isActive = statusFilter === tab.key
            return (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={cn(
                  "shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-muted-foreground border-border hover:bg-secondary hover:text-foreground"
                )}
              >
                {tab.label}
                <span className={cn(
                  "ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold",
                  isActive ? "bg-primary-foreground/20 text-primary-foreground" : "bg-secondary text-muted-foreground"
                )}>
                  {tab.count}
                </span>
              </button>
            )
          })}
        </div>
      </Card>

      {/* Releases */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Rocket}
          title="No releases match"
          description="Try a different search or filter. New releases will appear here as they ship."
          action={{ label: "Clear filters", onClick: () => { setSearch(""); setStatusFilter("all") } }}
        />
      ) : (
        <div className="space-y-4">
          {/* Pinned / latest */}
          {pinned.length > 0 && (
            <div className="mb-2">
              <div className="flex items-center gap-2 mb-2">
                <Pin className="w-3.5 h-3.5 text-amber-500" />
                <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Latest release</span>
                <div className="flex-1 h-px bg-border" />
              </div>
              <div className="space-y-4">
                {pinned.map((r, idx) => (
                  <ReleaseCard key={r.id} release={r} expanded index={idx} />
                ))}
              </div>
            </div>
          )}

          {/* Regular */}
          {regular.length > 0 && (
            <div>
              {pinned.length > 0 && (
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Earlier releases</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
              )}
              <div className="space-y-4">
                {regular.map((r, idx) => (
                  <ReleaseCard key={r.id} release={r} index={idx} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Footer */}
      {filtered.length > 0 && (
        <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
          <Sparkles className="w-3 h-3" />
          Showing {filtered.length} release{filtered.length !== 1 ? "s" : ""} ·{" "}
          <button onClick={handleSubscribe} className="text-primary hover:underline">
            {subscribed ? "Manage subscription" : "Subscribe to updates"}
          </button>
        </div>
      )}
    </DashboardShell>
  )
}

// ============================================================
// RELEASE CARD
// ============================================================

function ReleaseCard({ release: r, expanded = false, index = 0 }: { release: Release; expanded?: boolean; index?: number }) {
  const [isOpen, setIsOpen] = useState(expanded)
  const status = statusConfig[r.status]
  const groupedChanges = useMemo(() => {
    const map: Record<ChangeType, Change[]> = { added: [], improved: [], fixed: [] }
    r.changes.forEach(c => map[c.type].push(c))
    return map
  }, [r])

  return (
    <Card
      className={cn(
        "p-4 md:p-5 card-lift animate-slide-in-up overflow-hidden",
        r.pinned && "border-l-4 border-l-amber-500",
        r.status === "beta" && "border-l-4 border-l-amber-500/50",
        r.status === "planned" && "border-l-4 border-l-sky-500/50"
      )}
      style={{ animationDelay: `${index * 40}ms` }}
    >
      {/* Header */}
      <div className="flex items-start gap-3 mb-3">
        <div className={cn(
          "w-11 h-11 rounded-xl flex items-center justify-center shrink-0 text-white font-bold",
          r.pinned ? "bg-primary" : r.status === "beta" ? "bg-amber-500" : r.status === "planned" ? "bg-sky-500" : "bg-emerald-500"
        )}>
          <Rocket className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 flex-wrap mb-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm md:text-base font-bold text-foreground">{r.version}</h3>
              <span className={cn("inline-flex items-center text-[10px] font-semibold px-1.5 py-0.5 rounded", status.chip)}>
                {status.label}
              </span>
              {r.pinned && (
                <Badge variant="outline" className="text-[10px] h-5 px-1.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30 gap-1">
                  <Pin className="w-2.5 h-2.5" /> Latest
                </Badge>
              )}
            </div>
            <span className="text-[10px] text-muted-foreground flex items-center gap-1 shrink-0">
              <Calendar className="w-3 h-3" />
              {formatDate(r.date, { month: "short", day: "numeric", year: "numeric" })}
            </span>
          </div>
          <p className="text-sm font-semibold text-foreground">{r.title}</p>
        </div>
      </div>

      {/* Summary */}
      <p className="text-xs text-muted-foreground leading-relaxed mb-3">{r.summary}</p>

      {/* Changes list (collapsible) */}
      {r.changes.length > 0 && (
        <div className="rounded-lg border border-border overflow-hidden">
          <button
            onClick={() => setIsOpen(o => !o)}
            className="w-full flex items-center justify-between gap-2 p-2.5 bg-secondary/30 hover:bg-secondary/50 transition-colors"
          >
            <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground flex items-center gap-2">
              <GitBranch className="w-3 h-3" />
              {r.changes.length} change{r.changes.length !== 1 ? "s" : ""}
              <span className="hidden sm:flex items-center gap-1 ml-1">
                {(["added", "improved", "fixed"] as ChangeType[]).map(t => (
                  <span key={t} className={cn("inline-flex items-center gap-0.5 text-[10px] font-medium px-1.5 py-0.5 rounded", changeConfig[t].chip)}>
                    {groupedChanges[t].length}
                  </span>
                ))}
              </span>
            </span>
            <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform", isOpen && "rotate-180")} />
          </button>

          {isOpen && (
            <div className="p-3 space-y-3 animate-fade-in">
              {(["added", "improved", "fixed"] as ChangeType[]).map(type => {
                const items = groupedChanges[type]
                if (items.length === 0) return null
                const cfg = changeConfig[type]
                return (
                  <div key={type}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded", cfg.chip)}>
                        <cfg.icon className="w-2.5 h-2.5" />
                        {cfg.label}
                      </span>
                      <span className="text-[10px] text-muted-foreground">— {items.length} item{items.length !== 1 ? "s" : ""}</span>
                    </div>
                    <ul className="space-y-1.5 ml-1">
                      {items.map((c, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs text-foreground leading-relaxed">
                          <span className={cn("w-1 h-1 rounded-full mt-1.5 shrink-0", cfg.ring)} />
                          <span>{c.text}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between gap-2 mt-3 pt-3 border-t border-border">
        <div className="flex items-center gap-2">
          <Avatar className="w-6 h-6">
            <AvatarImage src={r.authorAvatar} alt={r.author} />
            <AvatarFallback className="text-[10px]">{initials(r.author)}</AvatarFallback>
          </Avatar>
          <span className="text-[11px] text-muted-foreground">
            Released by <span className="font-medium text-foreground">{r.author}</span>
          </span>
        </div>
        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-muted-foreground hover:text-foreground">
          Full notes <ArrowUpRight className="w-3 h-3" />
        </Button>
      </div>
    </Card>
  )
}
