"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  AtSign, Search, MessageSquare, Send, ChevronRight, Link2, Sparkles,
  CheckCheck, ListTodo, FolderKanban, MessageCircle, Reply, Filter,
} from "lucide-react"
import { notifications as seedNotifications, members, currentMember } from "@/lib/data/mock"
import { cn, timeAgo, formatDate, initials } from "@/lib/utils"
import { toast } from "sonner"
import type { Notification } from "@/types"

// ============================================================
// ENRICH MENTIONS — synthesize extra mention notifications
// (mock only has 1 mention — synthesize richer context)
// ============================================================

interface MentionItem extends Notification {
  contextType: "task" | "project" | "comment"
  contextKey: string
  contextTitle: string
  projectId: string
  projectName: string
  projectColor: string
  excerpt: string
}

const mentionItems: MentionItem[] = [
  {
    id: "mn-1",
    type: "mention",
    title: "Zara mentioned you in PLN-101",
    body: "@jessin can you review the new onboarding flow before EOD?",
    createdAt: "2026-01-28T15:21:00Z",
    read: false,
    actor: { name: members[1].name, avatar: members[1].avatar },
    href: "/tasks/t1",
    contextType: "task",
    contextKey: "PLN-101",
    contextTitle: "Implement command palette keyboard navigation",
    projectId: "p1",
    projectName: "Planna Web App",
    projectColor: "bg-emerald-500",
    excerpt: "Loving the ⌘K shortcut. Can we add arrow-key navigation between sections? @jessin would love your eyes on the focus behavior.",
  },
  {
    id: "mn-2",
    type: "mention",
    title: "Felix mentioned you in a comment on PLN-101",
    body: "@jessin the command palette focus behavior needs your eyes — see PR #284.",
    createdAt: "2026-01-28T14:32:00Z",
    read: false,
    actor: { name: members[4].name, avatar: members[4].avatar },
    href: "/tasks/t1",
    contextType: "comment",
    contextKey: "PLN-101",
    contextTitle: "Implement command palette keyboard navigation",
    projectId: "p1",
    projectName: "Planna Web App",
    projectColor: "bg-emerald-500",
    excerpt: "Pushed arrow-key nav in #284. Wraps around at the top/bottom of each section. @jessin the command palette focus behavior needs your eyes — see PR #284.",
  },
  {
    id: "mn-3",
    type: "mention",
    title: "Zara mentioned you in ARC-601",
    body: "@jessin let's preview the Acme onboarding variant tomorrow.",
    createdAt: "2026-01-27T16:45:00Z",
    read: false,
    actor: { name: members[1].name, avatar: members[1].avatar },
    href: "/tasks/t11",
    contextType: "task",
    contextKey: "ARC-601",
    contextTitle: "Custom onboarding flow for Acme",
    projectId: "p9",
    projectName: "Acme Client Project",
    projectColor: "bg-lime-600",
    excerpt: "Custom steps UI is in. Acme's 5-step variant is feature-flagged behind `onboarding.variant=acme`. @jessin let's preview the Acme onboarding variant tomorrow.",
  },
  {
    id: "mn-4",
    type: "mention",
    title: "Theo mentioned you in Sprint 48 planning",
    body: "@jessin can we lock the sprint 48 scope by Friday?",
    createdAt: "2026-01-26T11:30:00Z",
    read: false,
    actor: { name: members[2].name, avatar: members[2].avatar },
    href: "/planning/sprint-planning",
    contextType: "project",
    contextKey: "Sprint 48",
    contextTitle: "Sprint 48 — Polishing",
    projectId: "p1",
    projectName: "Planna Web App",
    projectColor: "bg-emerald-500",
    excerpt: "Looking at capacity for next sprint. @jessin can we lock the sprint 48 scope by Friday? Want to give the team a clean Monday start.",
  },
  {
    id: "mn-5",
    type: "mention",
    title: "Amara mentioned you in PLN-105",
    body: "@jessin should recurring tasks support skip-on-holiday by default?",
    createdAt: "2026-01-25T09:14:00Z",
    read: true,
    actor: { name: members[5].name, avatar: members[5].avatar },
    href: "/tasks/t17",
    contextType: "task",
    contextKey: "PLN-105",
    contextTitle: "Recurring task scheduler",
    projectId: "p1",
    projectName: "Planna Web App",
    projectColor: "bg-emerald-500",
    excerpt: "Weekly recurrence is in. @jessin should recurring tasks support skip-on-holiday by default? Punting to a follow-up if we need a calendar source.",
  },
  {
    id: "mn-6",
    type: "mention",
    title: "Hugo mentioned you in #acme-client",
    body: "@jessin Acme wants 2FA enforced for all their seats — feasible?",
    createdAt: "2026-01-24T14:00:00Z",
    read: true,
    actor: { name: members[8].name, avatar: members[8].avatar },
    href: "/inbox",
    contextType: "comment",
    contextKey: "#acme-client",
    contextTitle: "Acme client channel",
    projectId: "p9",
    projectName: "Acme Client Project",
    projectColor: "bg-lime-600",
    excerpt: "SSO config doc shared — SAML metadata XML in the linked file. @jessin Acme wants 2FA enforced for all their seats — feasible? Need to scope before the kickoff.",
  },
  {
    id: "mn-7",
    type: "mention",
    title: "Naomi mentioned you in QA-702",
    body: "@jessin found a bug in the invite flow — last admin removal isn't blocked.",
    createdAt: "2026-01-23T10:20:00Z",
    read: true,
    actor: { name: members[7].name, avatar: members[7].avatar },
    href: "/tasks/t24",
    contextType: "comment",
    contextKey: "QA-702",
    contextTitle: "E2E test for invite member flow",
    projectId: "p7",
    projectName: "Test Automation Suite",
    projectColor: "bg-emerald-600",
    excerpt: "Added a test for the role-removal path. Found a bug — removing the last admin doesn't block. @jessin filing separately; want to triage together?",
  },
]

// ============================================================
// CONTEXT TYPE CONFIG
// ============================================================

const contextConfig: Record<MentionItem["contextType"], { label: string; icon: typeof ListTodo; chip: string }> = {
  task:    { label: "Task",       icon: ListTodo,       chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  project: { label: "Project",    icon: FolderKanban,   chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
  comment: { label: "Comment",    icon: MessageCircle,  chip: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
}

// ============================================================
// PAGE
// ============================================================

export default function MentionsPage() {
  const [items, setItems] = useState<MentionItem[]>(mentionItems)
  const [search, setSearch] = useState("")
  const [contextFilter, setContextFilter] = useState<string>("all")
  const [showUnreadOnly, setShowUnreadOnly] = useState(false)
  const [replyTarget, setReplyTarget] = useState<string | null>(null)
  const [replyText, setReplyText] = useState("")

  const counts = useMemo(() => ({
    all: items.length,
    task: items.filter(i => i.contextType === "task").length,
    project: items.filter(i => i.contextType === "project").length,
    comment: items.filter(i => i.contextType === "comment").length,
  }), [items])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return items
      .filter(i => contextFilter === "all" || i.contextType === contextFilter)
      .filter(i => !showUnreadOnly || !i.read)
      .filter(i => !q || i.title.toLowerCase().includes(q) || i.body.toLowerCase().includes(q) || i.contextTitle.toLowerCase().includes(q) || i.actor!.name.toLowerCase().includes(q))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }, [items, search, contextFilter, showUnreadOnly])

  const unreadCount = items.filter(i => !i.read).length

  const markAllRead = () => {
    setItems(prev => prev.map(i => ({ ...i, read: true })))
    toast.success("All mentions marked as read")
  }

  const markRead = (id: string) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, read: true } : i))
  }

  const handleQuickReply = (item: MentionItem) => {
    if (!replyText.trim()) return
    toast.success("Reply sent", {
      description: `To ${item.actor!.name} on ${item.contextKey}`,
    })
    setReplyText("")
    setReplyTarget(null)
    markRead(item.id)
  }

  const filterTabs = [
    { key: "all", label: "All", count: counts.all },
    { key: "task", label: "Tasks", count: counts.task },
    { key: "project", label: "Projects", count: counts.project },
    { key: "comment", label: "Comments", count: counts.comment },
  ]

  return (
    <DashboardShell
      title="Mentions"
      description="Every time someone tags you with @. Reply, jump to context, or mark as read."
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" onClick={markAllRead} disabled={unreadCount === 0}>
            <CheckCheck className="w-3.5 h-3.5" /> Mark all read
          </Button>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" asChild>
            <Link href="/notifications">
              <Sparkles className="w-3.5 h-3.5" /> All notifications
            </Link>
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total mentions" value={items.length} hint="last 30 days" icon={AtSign} />
        <StatCard label="Unread" value={unreadCount} hint="needs your reply" icon={MessageSquare} iconColor="bg-primary/15 text-primary" />
        <StatCard label="In tasks" value={counts.task} hint="task descriptions & titles" icon={ListTodo} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="In comments" value={counts.comment} hint="comment threads" icon={MessageCircle} iconColor="bg-sky-500/15 text-sky-600 dark:text-sky-400" />
      </div>

      {/* Filter pills + search */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search mentions by author, task, or content…"
              className="h-9 pl-8 text-xs"
            />
          </div>
          <Button
            variant={showUnreadOnly ? "default" : "outline"}
            size="sm"
            className={cn("h-9 gap-1.5 shrink-0", showUnreadOnly ? "bg-primary text-primary-foreground" : "bg-transparent")}
            onClick={() => setShowUnreadOnly(v => !v)}
          >
            <Filter className="w-3.5 h-3.5" /> Unread only
          </Button>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar -mx-1 px-1 mt-3">
          {filterTabs.map(tab => {
            const isActive = contextFilter === tab.key
            return (
              <button
                key={tab.key}
                onClick={() => setContextFilter(tab.key)}
                className={cn(
                  "shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-muted-foreground border-border hover:bg-secondary hover:text-foreground"
                )}
              >
                {tab.label}
                <span className={cn(
                  "ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold",
                  isActive ? "bg-primary-foreground/20 text-primary-foreground" : "bg-secondary text-muted-foreground"
                )}>
                  {tab.count}
                </span>
              </button>
            )
          })}
        </div>
      </Card>

      {/* Mentions list */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={AtSign}
          title="No mentions found"
          description="Try adjusting your filters or search. New @mentions will appear here as they happen."
          action={{ label: "Clear filters", onClick: () => { setSearch(""); setContextFilter("all"); setShowUnreadOnly(false) } }}
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((item, idx) => {
            const ctxCfg = contextConfig[item.contextType]
            return (
              <Card
                key={item.id}
                className={cn(
                  "p-4 md:p-5 card-lift animate-slide-in-up",
                  !item.read && "bg-primary/[0.03] border-primary/30"
                )}
                style={{ animationDelay: `${idx * 30}ms` }}
              >
                <div className="flex items-start gap-3">
                  <div className="relative shrink-0">
                    <Avatar className="w-10 h-10 ring-2 ring-card">
                      <AvatarImage src={item.actor!.avatar} alt={item.actor!.name} />
                      <AvatarFallback className="text-xs">{initials(item.actor!.name)}</AvatarFallback>
                    </Avatar>
                    <span className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full bg-primary text-primary-foreground flex items-center justify-center ring-2 ring-card">
                      <AtSign className="w-2.5 h-2.5" />
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold text-foreground">
                          <span className="font-bold">{item.actor!.name}</span>
                          <span className="text-muted-foreground font-normal"> mentioned you</span>
                        </p>
                        {!item.read && (
                          <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                        )}
                      </div>
                      <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">{timeAgo(item.createdAt)}</span>
                    </div>

                    {/* Context link */}
                    <Link
                      href={item.href ?? "#"}
                      onClick={() => markRead(item.id)}
                      className="inline-flex items-center gap-1.5 text-[11px] font-medium text-primary hover:underline mb-2"
                    >
                      <Link2 className="w-3 h-3" />
                      <span className="font-mono">{item.contextKey}</span>
                      <span className="text-muted-foreground font-normal">— {item.contextTitle}</span>
                      <ChevronRight className="w-3 h-3" />
                    </Link>

                    {/* Excerpt */}
                    <div className="rounded-lg border border-border bg-secondary/30 p-3 mb-2">
                      <p className="text-xs text-foreground leading-relaxed">
                        {renderExcerpt(item.excerpt)}
                      </p>
                    </div>

                    {/* Meta */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className={cn("inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded", ctxCfg.chip)}>
                        <ctxCfg.icon className="w-2.5 h-2.5" />
                        {ctxCfg.label}
                      </span>
                      <span className="inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                        <span className={cn("w-1.5 h-1.5 rounded-full", item.projectColor)} />
                        {item.projectName}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        · {formatDate(item.createdAt, { month: "short", day: "numeric" })}
                      </span>
                    </div>

                    {/* Quick reply */}
                    {replyTarget === item.id ? (
                      <div className="mt-3 p-3 rounded-lg border border-border bg-card animate-fade-in">
                        <div className="flex items-start gap-2">
                          <Avatar className="w-7 h-7">
                            <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
                            <AvatarFallback className="text-[10px]">{initials(currentMember.name)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <Textarea
                              value={replyText}
                              onChange={e => setReplyText(e.target.value)}
                              placeholder={`Reply to ${item.actor!.name}…`}
                              rows={2}
                              autoFocus
                              className="text-xs resize-none"
                            />
                            <div className="flex items-center justify-between mt-2">
                              <p className="text-[10px] text-muted-foreground">@mention, :emoji: supported</p>
                              <div className="flex gap-1.5">
                                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => { setReplyTarget(null); setReplyText("") }}>
                                  Cancel
                                </Button>
                                <Button size="sm" className="h-7 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => handleQuickReply(item)} disabled={!replyText.trim()}>
                                  <Send className="w-3 h-3" /> Reply
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 mt-3 -ml-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground"
                          onClick={() => { setReplyTarget(item.id); setReplyText(`@${item.actor!.name.split(" ")[0].toLowerCase()} `) }}
                        >
                          <Reply className="w-3 h-3" /> Quick reply
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground" asChild>
                          <Link href={item.href ?? "#"} onClick={() => markRead(item.id)}>
                            <ChevronRight className="w-3 h-3" /> Open context
                          </Link>
                        </Button>
                        {!item.read && (
                          <Button variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground ml-auto" onClick={() => markRead(item.id)}>
                            <CheckCheck className="w-3 h-3" /> Mark read
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      )}

      {/* Footer */}
      {filtered.length > 0 && (
        <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
          <Sparkles className="w-3 h-3" />
          Showing {filtered.length} of {items.length} mentions ·
          <Link href="/notifications" className="text-primary hover:underline">View all notifications</Link>
        </div>
      )}
    </DashboardShell>
  )
}

// ============================================================
// HELPERS
// ============================================================

function renderExcerpt(text: string): React.ReactNode {
  const parts = text.split(/(@\w+)/g)
  return parts.map((part, i) => {
    if (part.startsWith("@")) {
      return (
        <span key={i} className="inline-flex items-center gap-0.5 px-1 py-0 mx-0.5 rounded bg-primary/15 text-primary font-medium">
          <AtSign className="w-2.5 h-2.5 inline" />
          {part.slice(1)}
        </span>
      )
    }
    return <span key={i}>{part}</span>
  })
}
