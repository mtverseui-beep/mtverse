"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, FileBox, Star, Clock, Users } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { cn } from "@/lib/utils"

const templates = [
  { id: "pt1", name: "Web App Starter", description: "Frontend, backend, design, devops tracks", color: "bg-emerald-500", icon: "LayoutDashboard", uses: 124, category: "Product", tasks: 28, members: 6 },
  { id: "pt2", name: "Mobile App Launch", description: "iOS + Android + backend + marketing", color: "bg-teal-500", icon: "Smartphone", uses: 89, category: "Mobile", tasks: 35, members: 5 },
  { id: "pt3", name: "Client Onboarding", description: "Custom onboarding with SSO + branding", color: "bg-lime-500", icon: "Briefcase", uses: 56, category: "Client", tasks: 22, members: 4 },
  { id: "pt4", name: "Marketing Campaign", description: "Content, ads, social, analytics", color: "bg-cyan-500", icon: "Megaphone", uses: 67, category: "Marketing", tasks: 18, members: 3 },
  { id: "pt5", name: "Design System", description: "Tokens, components, docs, accessibility", color: "bg-green-500", icon: "Palette", uses: 42, category: "Design", tasks: 32, members: 4 },
  { id: "pt6", name: "Infrastructure Migration", description: "Audit, plan, migrate, validate, decommission", color: "bg-sky-500", icon: "Server", uses: 28, category: "Engineering", tasks: 45, members: 5 },
  { id: "pt7", name: "Q1 OKRs Rollout", description: "Goals, KRs, check-ins, scoring", color: "bg-violet-500", icon: "Target", uses: 38, category: "Process", tasks: 14, members: 8 },
  { id: "pt8", name: "Security Audit", description: "Pen test, remediation, compliance, training", color: "bg-rose-500", icon: "ShieldCheck", uses: 22, category: "Security", tasks: 38, members: 6 },
]

export default function ProjectTemplatesPage() {
  return (
    <DashboardShell
      title="Project Templates"
      description="Spin up new projects from proven blueprints."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New template
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Templates" value={templates.length} hint="ready to use" icon={FileBox} trend={{ value: 4, positive: true }} />
        <StatCard label="Most Used" value="Web App Starter" hint="124 uses" icon={Star} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Categories" value={new Set(templates.map(t => t.category)).size} hint="covered" icon={FileBox} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Avg Setup Time" value="< 2 min" hint="to launch a new project" icon={Clock} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        {templates.map(tpl => (
          <Card key={tpl.id} className="p-4 md:p-5 card-lift group cursor-pointer">
            <div className="flex items-start gap-3 mb-3">
              <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110", tpl.color)}>
                <FileBox className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{tpl.name}</p>
                <Badge variant="outline" className="text-[10px] mt-0.5">{tpl.category}</Badge>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mb-3 leading-relaxed">{tpl.description}</p>
            <div className="flex items-center justify-between pt-3 border-t border-border text-[10px] text-muted-foreground">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {tpl.members}</span>
                <span className="flex items-center gap-1"><FileBox className="w-3 h-3" /> {tpl.tasks}</span>
                <span className="flex items-center gap-1"><Star className="w-3 h-3" /> {tpl.uses}</span>
              </div>
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">Use <Plus className="w-3 h-3" /></Button>
            </div>
          </Card>
        ))}
      </div>
    </DashboardShell>
  )
}
