"use client"

import { use } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Calendar, DollarSign, Users, Clock, Flag, AlertTriangle, TrendingUp, Target } from "lucide-react"
import { projects, members, tasks as seedTasks, milestones, activities } from "@/lib/data/mock"
import { ChartCard, PlannaAreaChart, PlannaDonutChart, PlannaRadialChart } from "@/components/charts"
import { PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import { cn, relativeDay, formatCurrency, timeAgo, pct } from "@/lib/utils"
import Link from "next/link"

export default function ProjectOverviewPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)!
  const projectTasks = seedTasks.filter(t => t.projectId === id)
  const projectMembers = project.members.map(mid => members.find(m => m.id === mid)).filter(Boolean)
  const projectMilestones = milestones.filter(m => m.projectId === id)
  const projectActivity = activities.filter(a => a.type === "task" || a.type === "project").slice(0, 5)

  return (
    <div className="space-y-4">
      {/* Hero summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Activity trend */}
        <ChartCard title="Activity" subtitle="Tasks completed over time" className="lg:col-span-2">
          <PlannaAreaChart
            data={Array.from({ length: 14 }).map((_, i) => ({
              day: `D${i + 1}`,
              completed: Math.floor(Math.random() * 8) + 2,
              created: Math.floor(Math.random() * 6) + 3,
            }))}
            xKey="day"
            series={[
              { key: "completed", name: "Completed" },
              { key: "created", name: "Created", color: "var(--chart-4)" },
            ]}
            height={240}
          />
        </ChartCard>

        {/* Health radial */}
        <ChartCard title="Project Health" subtitle="Overall status" fullscreen={false}>
          <div className="flex flex-col items-center gap-3 py-4">
            <PlannaRadialChart value={project.progress} label="progress" size={160} />
            <div className="text-center">
              <HealthBadgeMini health={project.health} />
              <p className="text-[10px] text-muted-foreground mt-1">{project.tasksDone} of {project.tasksTotal} tasks done</p>
            </div>
          </div>
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Recent tasks */}
        <Card className="p-4 md:p-5 lg:col-span-2 card-lift">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold">Recent tasks</h3>
            <Link href={`/projects/${id}/tasks`} className="text-xs text-primary hover:underline">View all</Link>
          </div>
          <div className="space-y-2">
            {projectTasks.slice(0, 6).map(t => (
              <Link key={t.id} href={`/tasks/${t.id}`} className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/30 transition-colors group">
                <div className={cn("w-1 self-stretch rounded-full", t.projectColor)} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1">{t.title}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                    <PriorityBadge priority={t.priority} />
                    <span className="text-[10px] text-muted-foreground">{relativeDay(t.dueDate ?? "")}</span>
                  </div>
                </div>
                <TaskStatusBadge status={t.status} />
              </Link>
            ))}
          </div>
        </Card>

        {/* Quick stats */}
        <Card className="p-4 md:p-5 card-lift">
          <h3 className="text-sm font-semibold mb-3">At a glance</h3>
          <div className="space-y-3">
            <Stat icon={Calendar} label="Started" value={new Date(project.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })} />
            <Stat icon={Flag} label="Due" value={relativeDay(project.dueDate)} />
            <Stat icon={Users} label="Members" value={`${projectMembers.length} people`} />
            <Stat icon={Target} label="Tasks" value={`${project.tasksDone}/${project.tasksTotal}`} />
            <Stat icon={DollarSign} label="Budget" value={`${pct(project.spent, project.budget)}% used`} />
            <Stat icon={Clock} label="Avg task close" value="2.4 days" />
          </div>
        </Card>
      </div>

      {/* Milestones + activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold">Milestones</h3>
            <Link href={`/projects/${id}/timeline`} className="text-xs text-primary hover:underline">Timeline</Link>
          </div>
          <div className="space-y-3">
            {projectMilestones.length > 0 ? projectMilestones.map(m => (
              <div key={m.id} className="relative pl-6 pb-3 border-l-2 border-border last:border-l-0 last:pb-0">
                <div className={cn("absolute -left-[5px] top-0 w-2 h-2 rounded-full ring-2 ring-card",
                  m.status === "done" ? "bg-emerald-500" :
                  m.status === "in_progress" ? "bg-amber-500" :
                  m.status === "overdue" ? "bg-rose-500" : "bg-muted-foreground"
                )} />
                <p className="text-xs font-semibold text-foreground">{m.title}</p>
                <p className="text-[10px] text-muted-foreground">{m.description}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-[9px] capitalize">{m.status.replace("_", " ")}</Badge>
                  <span className="text-[10px] text-muted-foreground">{relativeDay(m.dueDate)}</span>
                </div>
              </div>
            )) : <p className="text-xs text-muted-foreground text-center py-4">No milestones yet</p>}
          </div>
        </Card>

        <Card className="p-4 md:p-5 card-lift">
          <h3 className="text-sm font-semibold mb-3">Recent activity</h3>
          <div className="space-y-3">
            {projectActivity.map(a => (
              <div key={a.id} className="flex items-start gap-2.5">
                <Avatar className="w-6 h-6"><AvatarImage src={a.actorAvatar} alt={a.actor} /><AvatarFallback className="text-[10px]">{a.actor[0]}</AvatarFallback></Avatar>
                <div>
                  <p className="text-xs text-foreground">
                    <span className="font-semibold">{a.actor.split(" ")[0]}</span>{" "}
                    <span className="text-muted-foreground">{a.action}</span>{" "}
                    <span className="font-medium">{a.target}</span>
                  </p>
                  <p className="text-[10px] text-muted-foreground">{timeAgo(a.createdAt)}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}

function Stat({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-7 h-7 rounded-md bg-secondary flex items-center justify-center shrink-0">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
      </div>
      <div className="flex-1 flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold text-foreground">{value}</span>
      </div>
    </div>
  )
}

function HealthBadgeMini({ health }: { health: "on_track" | "at_risk" | "off_track" }) {
  const c = {
    on_track: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
    at_risk: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
    off_track: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  }[health]
  return <Badge className={cn("text-[10px] capitalize", c)}>{health.replace("_", " ")}</Badge>
}
