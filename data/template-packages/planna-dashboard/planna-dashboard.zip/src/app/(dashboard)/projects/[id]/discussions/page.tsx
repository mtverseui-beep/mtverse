"use client"

import { use } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Send, Pin, Heart, MessageSquare } from "lucide-react"
import { members } from "@/lib/data/mock"
import { projects } from "@/lib/data/mock"
import { cn, timeAgo } from "@/lib/utils"
import { notFound } from "next/navigation"
import { useState } from "react"

const discussions = [
  { id: "d1", title: "Sprint 47 retro action items", author: members[1], createdAt: "2026-01-28T10:00:00Z", pinned: true, replies: 8, hearts: 12, body: "Following up on our retro — here are the action items:\n\n1. Reduce WIP limit to 3 per column\n2. Add automated status updates to Slack\n3. Pair-program on WebSocket reconnect\n4. Rotate on-call starting Sprint 48\n\nPlease react with ✅ if you can take one." },
  { id: "d2", title: "Acme onboarding decisions needed", author: members[1], createdAt: "2026-01-25T14:30:00Z", pinned: false, replies: 5, hearts: 4, body: "Acme wants 5-step onboarding instead of 3. They also want SSO via Okta. Need engineering input by EOW." },
  { id: "d3", title: "API deprecation timeline", author: members[5], createdAt: "2026-01-22T09:00:00Z", pinned: false, replies: 3, hearts: 2, body: "Proposing: v1 deprecated 2026-06-30, v2 default 2026-04-15. Notify consumers 60 days in advance." },
]

export default function ProjectDiscussionsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)
  if (!project) notFound()
  const [reply, setReply] = useState("")

  return (
    <div className="space-y-4">
      <Card className="p-4 md:p-5">
        <Textarea placeholder={`Start a discussion in ${project.name}…`} rows={3} className="text-sm resize-none" />
        <div className="flex items-center justify-between mt-2">
          <p className="text-[10px] text-muted-foreground">Be kind and constructive. Markdown supported.</p>
          <Button size="sm" className="h-8 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
            <Send className="w-3.5 h-3.5" /> Post
          </Button>
        </div>
      </Card>

      <div className="space-y-3">
        {discussions.map(d => (
          <Card key={d.id} className={cn("p-4 md:p-5 card-lift", d.pinned && "border-l-4 border-l-amber-500")}>
            <div className="flex items-start gap-3 mb-3">
              <Avatar className="w-9 h-9"><AvatarImage src={d.author.avatar} alt={d.author.name} /><AvatarFallback>{d.author.name[0]}</AvatarFallback></Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-semibold text-foreground">{d.title}</p>
                  {d.pinned && <Pin className="w-3 h-3 text-amber-500" />}
                </div>
                <p className="text-[10px] text-muted-foreground">{d.author.name} · {timeAgo(d.createdAt)}</p>
              </div>
            </div>
            <p className="text-xs text-foreground whitespace-pre-line leading-relaxed mb-3">{d.body}</p>
            <div className="flex items-center gap-3 pt-3 border-t border-border">
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <Heart className="w-3 h-3" /> {d.hearts}
              </Button>
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <MessageSquare className="w-3 h-3" /> {d.replies} replies
              </Button>
              <Button variant="ghost" size="sm" className="h-7 text-xs ml-auto">Reply</Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
