"use client"

import { use } from "react"
import { notFound } from "next/navigation"
import Link from "next/link"
import { projects, members } from "@/lib/data/mock"
import { DashboardShellBare } from "@/components/layout/dashboard-shell"
import { Header } from "@/components/layout/header"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft, Star, MoreHorizontal, Plus, Share2, Settings,
  LayoutDashboard, CheckSquare, FileText, GitBranch, Users,
  MessageSquare, BarChart3,
} from "lucide-react"
import { ProjectStatusBadge, HealthBadge } from "@/components/common/badges"
import { cn, formatCurrency, relativeDay, pct } from "@/lib/utils"
import { usePathname } from "next/navigation"
import * as Icons from "lucide-react"

export default function ProjectDetailLayout({ children, params }: { children: React.ReactNode; params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const pathname = usePathname()
  const project = projects.find(p => p.id === id)
  if (!project) notFound()
  const Icon = (Icons as any)[project.icon] ?? LayoutDashboard
  const projectMembers = project.members.map(mid => members.find(m => m.id === mid)).filter(Boolean)

  const tabs = [
    { label: "Overview", href: `/projects/${id}`, icon: LayoutDashboard },
    { label: "Tasks", href: `/projects/${id}/tasks`, icon: CheckSquare },
    { label: "Files", href: `/projects/${id}/files`, icon: FileText },
    { label: "Timeline", href: `/projects/${id}/timeline`, icon: GitBranch },
    { label: "Members", href: `/projects/${id}/members`, icon: Users },
    { label: "Discussions", href: `/projects/${id}/discussions`, icon: MessageSquare },
    { label: "Reports", href: `/projects/${id}/reports`, icon: BarChart3 },
    { label: "Settings", href: `/projects/${id}/settings`, icon: Settings },
  ]
  // active detection helper
  const isTabActive = (href: string) => {
    if (href === `/projects/${id}`) return pathname === href
    return pathname.startsWith(href)
  }

  return (
    <DashboardShellBare>
      <div className="p-4 md:p-5 lg:p-6 w-full">
        <Header hideTitle />
        {/* Project header */}
        <div className="mb-4 animate-slide-in-up">
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1 mb-3 -ml-2">
            <Link href="/projects"><ArrowLeft className="w-3.5 h-3.5" /> All projects</Link>
          </Button>
          <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
            <div className="flex items-start gap-3">
              <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center shrink-0", project.color)}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded">{project.key}</span>
                  <ProjectStatusBadge status={project.status} />
                  <HealthBadge health={project.health} />
                </div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground tracking-tight">{project.name}</h1>
                <p className="text-xs md:text-sm text-muted-foreground mt-1 max-w-2xl">{project.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <Star className={cn("w-4 h-4", project.starred && "fill-amber-500 text-amber-500")} />
              </Button>
              <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
                <Share2 className="w-4 h-4" /> Share
              </Button>
              <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                <Plus className="w-4 h-4" /> New task
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
          </div>
          {/* Progress strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <Card className="p-3">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Progress</p>
              <p className="text-lg font-bold text-foreground">{project.progress}%</p>
              <Progress value={project.progress} className="h-1 mt-1" />
            </Card>
            <Card className="p-3">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Tasks</p>
              <p className="text-lg font-bold text-foreground">{project.tasksDone}/{project.tasksTotal}</p>
              <p className="text-[10px] text-muted-foreground">{pct(project.tasksDone, project.tasksTotal)}% complete</p>
            </Card>
            <Card className="p-3">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Budget</p>
              <p className="text-lg font-bold text-foreground">{formatCurrency(project.spent)}</p>
              <p className="text-[10px] text-muted-foreground">of {formatCurrency(project.budget)}</p>
            </Card>
            <Card className="p-3">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Due</p>
              <p className="text-lg font-bold text-foreground">{relativeDay(project.dueDate)}</p>
              <p className="text-[10px] text-muted-foreground">{new Date(project.dueDate).toLocaleDateString()}</p>
            </Card>
          </div>
          {/* Tabs */}
          <Tabs value={pathname}>
            <TabsList className="overflow-x-auto no-scrollbar">
              {tabs.map(t => {
                const TabIcon = t.icon
                const isActive = isTabActive(t.href)
                return (
                  <TabsTrigger key={t.href} value={isActive ? pathname : t.href} asChild>
                    <Link href={t.href} className="flex items-center gap-1.5 text-xs data-[state=active]:bg-secondary data-[state=active]:text-foreground">
                      <TabIcon className="w-3.5 h-3.5" />
                      {t.label}
                    </Link>
                  </TabsTrigger>
                )
              })}
            </TabsList>
          </Tabs>
        </div>
        <div className="mt-4">{children}</div>
      </div>
    </DashboardShellBare>
  )
}
