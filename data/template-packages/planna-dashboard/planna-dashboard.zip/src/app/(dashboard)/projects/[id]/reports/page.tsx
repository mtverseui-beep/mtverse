"use client"

import { use } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, FileText, TrendingUp } from "lucide-react"
import { ChartCard, PlannaBarChart, PlannaAreaChart, PlannaDonutChart } from "@/components/charts"
import { projects, tasks as seedTasks } from "@/lib/data/mock"
import { PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import { cn, pct } from "@/lib/utils"
import { notFound } from "next/navigation"

export default function ProjectReportsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)
  if (!project) notFound()
  const projectTasks = seedTasks.filter(t => t.projectId === id)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Project Reports</h3>
        <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent">
          <Download className="w-3.5 h-3.5" /> Export PDF
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="p-3">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Tasks Done</p>
          <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{project.tasksDone}</p>
          <p className="text-[10px] text-muted-foreground">of {project.tasksTotal}</p>
        </Card>
        <Card className="p-3">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">In Progress</p>
          <p className="text-lg font-bold text-amber-600 dark:text-amber-400">{projectTasks.filter(t => t.status === "in_progress").length}</p>
          <p className="text-[10px] text-muted-foreground">active now</p>
        </Card>
        <Card className="p-3">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Blocked</p>
          <p className="text-lg font-bold text-rose-600 dark:text-rose-400">{projectTasks.filter(t => t.status === "blocked").length}</p>
          <p className="text-[10px] text-muted-foreground">needs unblock</p>
        </Card>
        <Card className="p-3">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Budget Used</p>
          <p className="text-lg font-bold text-foreground">{pct(project.spent, project.budget)}%</p>
          <p className="text-[10px] text-muted-foreground">${(project.spent / 1000).toFixed(0)}K of ${(project.budget / 1000).toFixed(0)}K</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Task Completion" subtitle="Last 14 days" fullscreen={false}>
          <PlannaAreaChart
            data={Array.from({ length: 14 }).map((_, i) => ({
              day: `D${i + 1}`,
              completed: Math.floor(Math.random() * 6) + 1,
            }))}
            xKey="day"
            series={[{ key: "completed", name: "Completed" }]}
            height={220}
            showLegend={false}
          />
        </ChartCard>
        <ChartCard title="Tasks by Status" subtitle="Current distribution" fullscreen={false}>
          <PlannaDonutChart
            data={[
              { name: "Done", value: projectTasks.filter(t => t.status === "done").length, color: "var(--chart-1)" },
              { name: "In Progress", value: projectTasks.filter(t => t.status === "in_progress").length, color: "var(--chart-3)" },
              { name: "To Do", value: projectTasks.filter(t => t.status === "todo").length, color: "var(--chart-4)" },
              { name: "Blocked", value: projectTasks.filter(t => t.status === "blocked").length, color: "var(--chart-5)" },
            ]}
            centerValue={String(projectTasks.length)}
            centerLabel="tasks"
            height={220}
          />
        </ChartCard>
      </div>

      <Card className="p-4 md:p-5">
        <h3 className="text-sm font-semibold mb-3">Priority Distribution</h3>
        <PlannaBarChart
          data={[
            { name: "Urgent", count: projectTasks.filter(t => t.priority === "urgent").length },
            { name: "High", count: projectTasks.filter(t => t.priority === "high").length },
            { name: "Medium", count: projectTasks.filter(t => t.priority === "medium").length },
            { name: "Low", count: projectTasks.filter(t => t.priority === "low").length },
          ]}
          xKey="name"
          series={[{ key: "count", name: "Tasks", color: "var(--chart-1)" }]}
          height={200}
          showLegend={false}
        />
      </Card>
    </div>
  )
}
