"use client"

import { use } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Upload, FileText, FileBox, Download, MoreHorizontal, Star, Image as ImageIcon, File, Video, Music, Archive, Code } from "lucide-react"
import { files, members } from "@/lib/data/mock"
import { cn, formatFileSize, timeAgo } from "@/lib/utils"
import { projects } from "@/lib/data/mock"
import { notFound } from "next/navigation"

const fileIcons: Record<string, any> = {
  pdf: FileText, document: FileText, spreadsheet: FileBox, presentation: FileText,
  image: ImageIcon, video: Video, audio: Music, archive: Archive, code: Code,
}

export default function ProjectFilesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)
  if (!project) notFound()
  const projectFiles = files.slice(0, 6)

  return (
    <div className="space-y-4">
      <Card className="p-4 md:p-5 border-dashed border-2 bg-secondary/20">
        <div className="flex flex-col items-center justify-center text-center py-6">
          <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center mb-3">
            <Upload className="w-5 h-5 text-primary" />
          </div>
          <p className="text-sm font-semibold text-foreground">Drop files here</p>
          <p className="text-xs text-muted-foreground mb-3">or click to browse — up to 50MB per file</p>
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Upload className="w-3.5 h-3.5" /> Browse files
          </Button>
        </div>
      </Card>

      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Files ({projectFiles.length})</h3>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent">
            <Download className="w-3.5 h-3.5" /> Download all
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {projectFiles.map(f => {
          const Icon = fileIcons[f.type] ?? File
          return (
            <Card key={f.id} className="p-3 card-lift group cursor-pointer">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">{f.name}</p>
                  <p className="text-[10px] text-muted-foreground">{formatFileSize(f.size)} · {timeAgo(f.modifiedAt)}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Avatar className="w-4 h-4"><AvatarImage src={f.ownerAvatar} alt={f.owner} /><AvatarFallback className="text-[8px]">{f.owner[0]}</AvatarFallback></Avatar>
                    <span className="text-[10px] text-muted-foreground">{f.owner.split(" ")[0]}</span>
                    {f.shared && <Badge variant="outline" className="text-[9px]">Shared</Badge>}
                  </div>
                </div>
                <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" className="h-6 w-6"><Star className="w-3 h-3" /></Button>
                  <Button variant="ghost" size="icon" className="h-6 w-6"><MoreHorizontal className="w-3 h-3" /></Button>
                </div>
              </div>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
