"use client"

import { use } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { UserPlus, MoreHorizontal, Mail, MessageSquare } from "lucide-react"
import { projects, members } from "@/lib/data/mock"
import { RoleBadge } from "@/components/common/badges"
import { cn, pct } from "@/lib/utils"
import { notFound } from "next/navigation"

export default function ProjectMembersPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)
  if (!project) notFound()
  const projectMembers = project.members.map(mid => members.find(m => m.id === mid)!).filter(Boolean)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Project Members ({projectMembers.length})</h3>
          <p className="text-xs text-muted-foreground">People working on this project</p>
        </div>
        <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <UserPlus className="w-3.5 h-3.5" /> Invite
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {projectMembers.map(m => {
          const utilization = Math.round((m.utilized / m.capacity) * 100)
          return (
            <Card key={m.id} className="p-4 card-lift group">
              <div className="flex items-start gap-3 mb-3">
                <Avatar className="w-10 h-10"><AvatarImage src={m.avatar} alt={m.name} /><AvatarFallback>{m.name[0]}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors truncate">{m.name}</p>
                  <p className="text-[11px] text-muted-foreground truncate">{m.title}</p>
                  <RoleBadge role={m.role} />
                </div>
                <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreHorizontal className="w-3.5 h-3.5" />
                </Button>
              </div>
              <div className="space-y-2 pt-3 border-t border-border">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-muted-foreground">Workload</span>
                    <span className={cn("text-[10px] font-semibold",
                      utilization >= 90 ? "text-rose-600 dark:text-rose-400" :
                      utilization >= 70 ? "text-emerald-600 dark:text-emerald-400" :
                      "text-muted-foreground"
                    )}>{utilization}%</span>
                  </div>
                  <Progress value={utilization} className="h-1" />
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 flex-1">
                    <Mail className="w-3 h-3" /> Message
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 flex-1">
                    <MessageSquare className="w-3 h-3" /> Chat
                  </Button>
                </div>
              </div>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
