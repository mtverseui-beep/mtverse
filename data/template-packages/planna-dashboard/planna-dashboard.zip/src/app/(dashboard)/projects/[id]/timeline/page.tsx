"use client"

import { use } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Flag, Plus, Calendar } from "lucide-react"
import { projects, milestones, members, tasks as seedTasks } from "@/lib/data/mock"
import { cn, relativeDay, formatDate } from "@/lib/utils"
import { notFound } from "next/navigation"

export default function ProjectTimelinePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)
  if (!project) notFound()
  const projectMilestones = milestones.filter(m => m.projectId === id)
  const projectTasks = seedTasks.filter(t => t.projectId === id && t.dueDate)

  // Combine milestones and tasks into timeline events
  const events = [
    ...projectMilestones.map(m => ({ ...m, type: "milestone" as const })),
    ...projectTasks.map(t => ({ id: t.id, title: t.title, dueDate: t.dueDate!, status: t.status === "done" ? "done" : "in_progress", description: t.description, progress: t.status === "done" ? 100 : 50, type: "task" as const })),
  ].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())

  return (
    <div className="space-y-4">
      <Card className="p-4 md:p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Project Timeline</h3>
          <Badge variant="outline" className="text-[10px]">{events.length} events</Badge>
        </div>
        {/* Gantt-style bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-2">
            <span>{formatDate(project.startDate, { month: "short", day: "numeric" })}</span>
            <span>{formatDate(project.dueDate, { month: "short", day: "numeric" })}</span>
          </div>
          <div className="relative h-6 rounded-full bg-muted overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-primary/40 to-primary/20" />
            <div className="absolute inset-y-0 left-0 bg-primary rounded-full" style={{ width: `${project.progress}%` }} />
            <div className="absolute inset-y-0 w-0.5 bg-rose-500" style={{ left: "70%" }} title="Today" />
          </div>
        </div>

        <div className="space-y-3">
          {events.map(ev => (
            <div key={ev.id} className="relative pl-8 pb-4 border-l-2 border-border last:border-l-0 last:pb-0">
              <div className={cn("absolute -left-[7px] top-0 w-3 h-3 rounded-full ring-4 ring-card",
                ev.status === "done" || ev.status === "completed" ? "bg-emerald-500" :
                ev.status === "in_progress" ? "bg-amber-500" :
                ev.status === "overdue" ? "bg-rose-500" : "bg-muted-foreground"
              )} />
              <div className="flex items-start justify-between gap-3 mb-1">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    {ev.type === "milestone" ? <Flag className="w-3 h-3 text-amber-500" /> : null}
                    <p className="text-xs font-semibold text-foreground">{ev.title}</p>
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{ev.description}</p>
                </div>
                <div className="text-right">
                  <Badge variant="outline" className={cn("text-[9px] capitalize", 
                    ev.status === "done" || ev.status === "completed" ? "text-emerald-600 dark:text-emerald-400" :
                    ev.status === "in_progress" ? "text-amber-600 dark:text-amber-400" :
                    ev.status === "overdue" ? "text-rose-600 dark:text-rose-400" : ""
                  )}>
                    {ev.status.replace("_", " ")}
                  </Badge>
                  <p className="text-[10px] text-muted-foreground mt-1">{relativeDay(ev.dueDate)}</p>
                </div>
              </div>
              {ev.type === "task" && <Progress value={ev.progress} className="h-1 mt-2" />}
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
