"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus, Search, LayoutGrid, List, Star, MoreHorizontal,
  FolderKanban, Calendar, DollarSign, Filter, Download,
} from "lucide-react"
import { projects, members } from "@/lib/data/mock"
import { ProjectStatusBadge, HealthBadge } from "@/components/common/badges"
import { StatCard } from "@/components/common/stat-card"
import { cn, formatCurrency, relativeDay, pct } from "@/lib/utils"
import Link from "next/link"
import { useState } from "react"
import * as Icons from "lucide-react"

export default function ProjectsPage() {
  const [search, setSearch] = useState("")
  const [view, setView] = useState<"grid" | "list">("grid")
  const [filter, setFilter] = useState<"all" | "active" | "planning" | "completed">("all")
  const [starred, setStarred] = useState<string[]>(projects.filter(p => p.starred).map(p => p.id))

  const filtered = projects.filter(p => {
    if (filter === "active" && p.status !== "active") return false
    if (filter === "planning" && p.status !== "planning") return false
    if (filter === "completed" && p.status !== "completed") return false
    if (search && !p.name.toLowerCase().includes(search.toLowerCase()) && !p.key.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const toggleStar = (id: string) => {
    setStarred(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id])
  }

  return (
    <DashboardShell
      title="Projects"
      description="All your projects in one place — track progress, health, and budget."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Filters
          </Button>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Download className="w-4 h-4" /> Export
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New project
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Projects" value={projects.length} hint="across workspace" icon={FolderKanban} trend={{ value: 8, positive: true }} />
        <StatCard label="Active" value={projects.filter(p => p.status === "active").length} hint="in progress" icon={FolderKanban} trend={{ value: 4, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="At Risk" value={projects.filter(p => p.health === "at_risk").length} hint="needs attention" icon={FolderKanban} trend={{ value: 1, positive: false }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Progress" value={`${Math.round(projects.reduce((s, p) => s + p.progress, 0) / projects.length)}%`} hint="across all projects" icon={FolderKanban} trend={{ value: 6, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Filter bar */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search projects…" value={search} onChange={e => setSearch(e.target.value)} className="h-9 pl-9 text-sm" />
        </div>
        <Tabs value={filter} onValueChange={(v) => setFilter(v as any)}>
          <TabsList>
            <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
            <TabsTrigger value="active" className="text-xs">Active</TabsTrigger>
            <TabsTrigger value="planning" className="text-xs">Planning</TabsTrigger>
            <TabsTrigger value="completed" className="text-xs">Completed</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-0.5 p-0.5 bg-card border border-border rounded-lg ml-auto">
          <Button variant={view === "grid" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("grid")}>
            <LayoutGrid className="w-3.5 h-3.5" />
          </Button>
          <Button variant={view === "list" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("list")}>
            <List className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Grid view */}
      {view === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {filtered.map(p => {
            const Icon = (Icons as any)[p.icon] ?? FolderKanban
            const projectMembers = p.members.map(id => members.find(m => m.id === id)).filter(Boolean)
            return (
              <Card key={p.id} className="p-4 md:p-5 card-lift group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center transition-transform group-hover:scale-110", p.color)}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <Link href={`/projects/${p.id}`}>
                        <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{p.name}</p>
                      </Link>
                      <p className="text-[10px] text-muted-foreground font-mono">{p.key}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => toggleStar(p.id)} className="text-muted-foreground hover:text-amber-500 transition-colors">
                      <Star className={cn("w-4 h-4", starred.includes(p.id) && "fill-amber-500 text-amber-500")} />
                    </button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                      <MoreHorizontal className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground line-clamp-2 mb-3 leading-relaxed">{p.description}</p>

                <div className="flex items-center gap-2 mb-3">
                  <ProjectStatusBadge status={p.status} />
                  <HealthBadge health={p.health} />
                </div>

                <div className="space-y-2 mb-3">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-semibold">{p.progress}%</span>
                  </div>
                  <Progress value={p.progress} className="h-1.5" />
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <div className="flex -space-x-1.5">
                    {projectMembers.slice(0, 4).map(m => (
                      <Avatar key={m!.id} className="w-5 h-5 border-2 border-card"><AvatarImage src={m!.avatar} alt={m!.name} /><AvatarFallback className="text-[9px]">{m!.name[0]}</AvatarFallback></Avatar>
                    ))}
                    {projectMembers.length > 4 && (
                      <div className="w-5 h-5 rounded-full bg-muted border-2 border-card flex items-center justify-center text-[9px] font-semibold text-muted-foreground">
                        +{projectMembers.length - 4}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {relativeDay(p.dueDate)}</span>
                    <span className="flex items-center gap-1"><DollarSign className="w-3 h-3" /> {pct(p.spent, p.budget)}%</span>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border bg-muted/30">
                <th className="py-2.5 px-3 font-medium">Project</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 px-3 font-medium">Health</th>
                <th className="py-2.5 px-3 font-medium">Progress</th>
                <th className="py-2.5 px-3 font-medium">Members</th>
                <th className="py-2.5 px-3 font-medium">Due</th>
                <th className="py-2.5 px-3 font-medium text-right">Budget</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(p => (
                <tr key={p.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="py-3 px-3">
                    <Link href={`/projects/${p.id}`} className="flex items-center gap-2.5">
                      <div className={cn("w-7 h-7 rounded-md flex items-center justify-center", p.color)}>
                        <FolderKanban className="w-3.5 h-3.5 text-white" />
                      </div>
                      <div>
                        <p className="text-xs font-medium hover:text-primary transition-colors">{p.name}</p>
                        <p className="text-[10px] text-muted-foreground">{p.key}</p>
                      </div>
                    </Link>
                  </td>
                  <td className="py-3 px-3"><ProjectStatusBadge status={p.status} /></td>
                  <td className="py-3 px-3"><HealthBadge health={p.health} /></td>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2 min-w-[120px]">
                      <Progress value={p.progress} className="h-1.5 flex-1" />
                      <span className="text-[11px] font-semibold w-8 text-right">{p.progress}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex -space-x-1.5">
                      {p.members.slice(0, 3).map(id => {
                        const m = members.find(x => x.id === id)
                        return m ? <Avatar key={id} className="w-5 h-5 border-2 border-card"><AvatarImage src={m.avatar} alt={m.name} /><AvatarFallback className="text-[9px]">{m.name[0]}</AvatarFallback></Avatar> : null
                      })}
                    </div>
                  </td>
                  <td className="py-3 px-3 text-xs text-muted-foreground">{relativeDay(p.dueDate)}</td>
                  <td className="py-3 px-3 text-right text-xs font-semibold">{formatCurrency(p.spent)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </DashboardShell>
  )
}
