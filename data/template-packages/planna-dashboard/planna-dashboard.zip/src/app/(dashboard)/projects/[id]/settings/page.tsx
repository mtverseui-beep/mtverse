"use client"

import { use } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Archive, Copy, Trash2, Save, Share2, AlertTriangle } from "lucide-react"
import { projects } from "@/lib/data/mock"
import { ProjectStatusBadge } from "@/components/common/badges"
import { notFound } from "next/navigation"

export default function ProjectSettingsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)
  if (!project) notFound()

  return (
    <div className="space-y-4 max-w-3xl">
      <Card className="p-4 md:p-5">
        <h3 className="text-sm font-semibold mb-4">General</h3>
        <div className="space-y-4">
          <div>
            <Label className="text-xs">Project name</Label>
            <Input defaultValue={project.name} className="mt-1 h-9 text-sm" />
          </div>
          <div>
            <Label className="text-xs">Project key</Label>
            <Input defaultValue={project.key} className="mt-1 h-9 text-sm font-mono" />
            <p className="text-[10px] text-muted-foreground mt-1">Used as prefix for task keys (e.g. {project.key}-101)</p>
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea defaultValue={project.description} rows={3} className="mt-1 text-sm resize-none" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Start date</Label>
              <Input type="date" defaultValue={project.startDate} className="mt-1 h-9 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Due date</Label>
              <Input type="date" defaultValue={project.dueDate} className="mt-1 h-9 text-sm" />
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-4 md:p-5">
        <h3 className="text-sm font-semibold mb-4">Access & visibility</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium">Workspace visible</p>
              <p className="text-[10px] text-muted-foreground">Any member can view this project</p>
            </div>
            <Switch defaultChecked />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium">Allow member invites</p>
              <p className="text-[10px] text-muted-foreground">Project admins can invite new members</p>
            </div>
            <Switch defaultChecked />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium">Public share link</p>
              <p className="text-[10px] text-muted-foreground">Anyone with the link can view (read-only)</p>
            </div>
            <Switch />
          </div>
        </div>
      </Card>

      <Card className="p-4 md:p-5">
        <h3 className="text-sm font-semibold mb-4">Actions</h3>
        <div className="space-y-2">
          <Button variant="outline" className="w-full h-9 justify-start gap-2 bg-transparent">
            <Copy className="w-4 h-4" /> Duplicate project
          </Button>
          <Button variant="outline" className="w-full h-9 justify-start gap-2 bg-transparent">
            <Share2 className="w-4 h-4" /> Share project
          </Button>
          <Button variant="outline" className="w-full h-9 justify-start gap-2 bg-transparent">
            <Archive className="w-4 h-4" /> Archive project
          </Button>
        </div>
      </Card>

      <Card className="p-4 md:p-5 border-rose-500/30">
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle className="w-4 h-4 text-rose-500" />
          <h3 className="text-sm font-semibold text-rose-700 dark:text-rose-400">Danger zone</h3>
        </div>
        <p className="text-xs text-muted-foreground mb-3">Once you delete a project, there is no going back. All tasks, files, and history will be permanently removed.</p>
        <Button variant="outline" className="text-rose-600 dark:text-rose-400 border-rose-500/30 hover:bg-rose-500/10 gap-2">
          <Trash2 className="w-4 h-4" /> Delete project
        </Button>
      </Card>

      <div className="flex items-center justify-end gap-2 sticky bottom-3">
        <Button variant="outline" className="bg-card shadow-sm">Cancel</Button>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5 shadow-md">
          <Save className="w-4 h-4" /> Save changes
        </Button>
      </div>
    </div>
  )
}
