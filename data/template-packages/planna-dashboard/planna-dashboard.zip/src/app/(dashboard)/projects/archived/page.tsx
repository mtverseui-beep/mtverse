"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Archive, RotateCcw, Trash2, Search, FolderKanban } from "lucide-react"
import { Input } from "@/components/ui/input"
import { StatCard } from "@/components/common/stat-card"
import { projects, members } from "@/lib/data/mock"
import { cn, formatCurrency, relativeDay } from "@/lib/utils"
import { useState } from "react"

export default function ArchivedProjectsPage() {
  const [search, setSearch] = useState("")
  const archived = [
    ...projects.filter(p => p.status === "completed"),
    ...projects.filter(p => p.status === "on_hold").slice(0, 1),
  ]

  return (
    <DashboardShell
      title="Archived Projects"
      description="Completed and archived projects — kept for reference."
      actions={
        <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
          <Archive className="w-4 h-4" /> Export archive
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Archived" value={archived.length} hint="projects" icon={Archive} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Completed" value={archived.filter(p => p.status === "completed").length} hint="successfully delivered" icon={Archive} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Total Value" value={formatCurrency(archived.reduce((s, p) => s + p.budget, 0))} hint="all-time budget" icon={Archive} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="On Hold" value={archived.filter(p => p.status === "on_hold").length} hint="paused work" icon={Archive} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      <div className="flex items-center justify-between mb-3">
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input placeholder="Search archived…" value={search} onChange={e => setSearch(e.target.value)} className="h-9 pl-9 text-sm" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        {archived.filter(p => p.name.toLowerCase().includes(search.toLowerCase())).map(p => (
          <Card key={p.id} className="p-4 card-lift group opacity-90 hover:opacity-100">
            <div className="flex items-start gap-3 mb-3">
              <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0 grayscale group-hover:grayscale-0 transition-all", p.color)}>
                <FolderKanban className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                <p className="text-[10px] text-muted-foreground font-mono">{p.key}</p>
              </div>
              <Badge variant="outline" className="text-[10px] capitalize">{p.status.replace("_", " ")}</Badge>
            </div>
            <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{p.description}</p>
            <div className="flex items-center justify-between pt-3 border-t border-border">
              <div className="flex -space-x-1.5">
                {p.members.slice(0, 3).map(id => {
                  const m = members.find(x => x.id === id)
                  return m ? <Avatar key={id} className="w-5 h-5 border-2 border-card"><AvatarImage src={m.avatar} alt={m.name} /><AvatarFallback className="text-[9px]">{m.name[0]}</AvatarFallback></Avatar> : null
                })}
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" className="h-7 w-7" title="Restore"><RotateCcw className="w-3.5 h-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" title="Delete permanently"><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </DashboardShell>
  )
}
