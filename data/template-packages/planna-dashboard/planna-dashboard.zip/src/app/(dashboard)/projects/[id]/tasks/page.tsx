"use client"

import { use } from "react"
import { TasksTable } from "@/components/task/tasks-table"
import { projects } from "@/lib/data/mock"
import { notFound } from "next/navigation"

export default function ProjectTasksPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const project = projects.find(p => p.id === id)
  if (!project) notFound()
  return <TasksTable filterPreset={{ projectId: id }} showProject={false} />
}
