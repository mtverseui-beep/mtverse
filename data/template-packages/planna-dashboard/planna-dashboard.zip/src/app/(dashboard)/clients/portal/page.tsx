"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  Briefcase, FileText, MessageSquare, Eye, Clock, CheckCircle2,
  Download, ExternalLink, Calendar, Paperclip, ArrowRight,
  Sparkles, ShieldCheck,
} from "lucide-react"
import { clients, projects, invoices, files, activities } from "@/lib/data/mock"
import { cn, formatCurrency, formatDate, relativeDay, timeAgo } from "@/lib/utils"

const invoiceStatusStyles: Record<string, string> = {
  paid:     "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  sent:     "bg-sky-500/15 text-sky-600 dark:text-sky-400",
  overdue:  "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  draft:    "bg-muted text-muted-foreground",
  cancelled:"bg-muted text-muted-foreground line-through",
}

export default function ClientPortalPage() {
  const [selectedClientId, setSelectedClientId] = useState(clients[0].id)
  const [activeTab, setActiveTab] = useState("projects")

  const client = clients.find(c => c.id === selectedClientId)!
  const clientProjects = useMemo(() => projects.filter(p => p.client === client.name), [client])
  const clientInvoices = useMemo(() => invoices.filter(i => i.clientId === client.id), [client])
  const sharedFiles = useMemo(() => files.filter(f => f.shared && f.project).slice(0, 6), [])
  const clientActivity = useMemo(
    () => activities.filter(a => a.target.toLowerCase().includes(client.name.toLowerCase())).slice(0, 4),
    [client]
  )

  const outstanding = clientInvoices.filter(i => i.status === "sent" || i.status === "overdue").reduce((s, i) => s + i.total, 0)
  const paidCount = clientInvoices.filter(i => i.status === "paid").length

  return (
    <DashboardShell
      title="Client Portal Preview"
      description="See what your clients see when they log into their portal."
      actions={
        <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
          <ExternalLink className="w-4 h-4" /> Open real portal
        </Button>
      }
    >
      {/* Portal banner */}
      <Card className="p-4 md:p-5 mb-4 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center shrink-0">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Previewing as</p>
              <p className="text-sm font-semibold text-foreground">Client portal · {client.name}</p>
            </div>
          </div>
          <div className="md:ml-auto flex items-center gap-3">
            <Select value={selectedClientId} onValueChange={setSelectedClientId}>
              <SelectTrigger className="h-9 w-full md:w-56 text-xs">
                <SelectValue placeholder="Select client" />
              </SelectTrigger>
              <SelectContent>
                {clients.map(c => (
                  <SelectItem key={c.id} value={c.id}>
                    <div className="flex items-center gap-2">
                      <Avatar className="w-4 h-4 rounded">
                        <AvatarImage src={c.logo} alt={c.name} />
                        <AvatarFallback className="text-[8px] rounded">{c.name.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      {c.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* The simulated portal — distinct branded frame */}
      <div className="rounded-2xl border-2 border-border overflow-hidden bg-card">
        {/* Portal top bar */}
        <div className="bg-secondary/60 border-b border-border px-4 md:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Avatar className="w-7 h-7 rounded">
              <AvatarImage src={client.logo} alt={client.name} />
              <AvatarFallback className="text-[10px] rounded">{client.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-xs font-semibold text-foreground">{client.name} Portal</p>
              <p className="text-[10px] text-muted-foreground">Welcome back, {client.contactName.split(" ")[0]}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-[10px] gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
              Secure session
            </Badge>
            <Avatar className="w-7 h-7">
              <AvatarImage src={client.contactAvatar} alt={client.contactName} />
              <AvatarFallback className="text-[10px]">{client.contactName[0]}</AvatarFallback>
            </Avatar>
          </div>
        </div>

        {/* Portal content */}
        <div className="p-4 md:p-6">
          {/* Hero stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
            <PortalStat icon={Briefcase} label="Active projects" value={String(clientProjects.filter(p => p.status === "active").length)} sub={`of ${client.projectsCount} total`} />
            <PortalStat icon={Clock} label="Outstanding" value={formatCurrency(outstanding)} sub={`${clientInvoices.filter(i => i.status === "sent").length} pending invoices`} valueClass={outstanding > 0 ? "text-amber-600 dark:text-amber-400" : ""} />
            <PortalStat icon={CheckCircle2} label="Paid invoices" value={String(paidCount)} sub={formatCurrency(clientInvoices.filter(i => i.status === "paid").reduce((s, i) => s + i.total, 0))} valueClass="text-emerald-600 dark:text-emerald-400" />
            <PortalStat icon={Calendar} label="Next deadline" value={clientProjects.length ? relativeDay(clientProjects[0].dueDate) : "—"} sub={clientProjects.length ? clientProjects[0].name : "No active projects"} />
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="overflow-x-auto no-scrollbar mb-4">
              <TabsTrigger value="projects" className="gap-1.5 text-xs"><Briefcase className="w-3.5 h-3.5" /> Projects</TabsTrigger>
              <TabsTrigger value="invoices" className="gap-1.5 text-xs"><FileText className="w-3.5 h-3.5" /> Invoices</TabsTrigger>
              <TabsTrigger value="files" className="gap-1.5 text-xs"><Paperclip className="w-3.5 h-3.5" /> Shared files</TabsTrigger>
              <TabsTrigger value="messages" className="gap-1.5 text-xs"><MessageSquare className="w-3.5 h-3.5" /> Messages</TabsTrigger>
            </TabsList>

            {/* Projects */}
            <TabsContent value="projects" className="space-y-3">
              {clientProjects.length > 0 ? clientProjects.map(p => (
                <Card key={p.id} className="p-4 card-lift">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", p.color)}>
                        <Briefcase className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">{p.name}</p>
                        <p className="text-[11px] text-muted-foreground">Lead: {p.lead}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[10px] capitalize">{p.status.replace("_", " ")}</Badge>
                  </div>
                  <Progress value={p.progress} className="h-1.5 mb-2" />
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                    <span>{p.progress}% complete</span>
                    <span>{p.tasksDone}/{p.tasksTotal} tasks · due {relativeDay(p.dueDate)}</span>
                  </div>
                </Card>
              )) : (
                <Card className="p-8 text-center">
                  <Briefcase className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">No active projects to display.</p>
                </Card>
              )}
            </TabsContent>

            {/* Invoices */}
            <TabsContent value="invoices">
              <Card className="p-0 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border bg-secondary/30">
                        <th className="py-2.5 px-4 font-medium">Invoice #</th>
                        <th className="py-2.5 px-4 font-medium">Project</th>
                        <th className="py-2.5 px-4 font-medium text-right">Amount</th>
                        <th className="py-2.5 px-4 font-medium">Due</th>
                        <th className="py-2.5 px-4 font-medium">Status</th>
                        <th className="py-2.5 px-4 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {clientInvoices.length > 0 ? clientInvoices.map(inv => (
                        <tr key={inv.id} className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors">
                          <td className="py-2.5 px-4 font-mono font-semibold text-foreground">{inv.number}</td>
                          <td className="py-2.5 px-4 text-muted-foreground">{inv.project ?? "—"}</td>
                          <td className="py-2.5 px-4 text-right font-semibold text-foreground">{formatCurrency(inv.total)}</td>
                          <td className="py-2.5 px-4 text-muted-foreground">{formatDate(inv.dueDate, { month: "short", day: "numeric" })}</td>
                          <td className="py-2.5 px-4">
                            <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded capitalize", invoiceStatusStyles[inv.status])}>{inv.status}</span>
                          </td>
                          <td className="py-2.5 px-4 text-right">
                            {inv.status === "sent" || inv.status === "overdue" ? (
                              <Button size="sm" className="h-6 text-[10px] bg-primary text-primary-foreground hover:bg-primary/90 gap-1">
                                <Download className="w-3 h-3" /> Pay
                              </Button>
                            ) : (
                              <Button variant="ghost" size="sm" className="h-6 text-[10px] gap-1">
                                <Download className="w-3 h-3" /> PDF
                              </Button>
                            )}
                          </td>
                        </tr>
                      )) : (
                        <tr><td colSpan={6} className="py-8 text-center text-xs text-muted-foreground">No invoices yet.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </Card>
            </TabsContent>

            {/* Shared files */}
            <TabsContent value="files">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {sharedFiles.map(f => (
                  <Card key={f.id} className="p-4 card-lift">
                    <div className="flex items-start gap-3 mb-2">
                      <div className="w-9 h-9 rounded-md bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-foreground truncate">{f.name}</p>
                        <p className="text-[10px] text-muted-foreground">Shared by {f.owner.split(" ")[0]} · {timeAgo(f.modifiedAt)}</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="w-full h-7 text-xs bg-transparent gap-1.5">
                      <Download className="w-3 h-3" /> Download
                    </Button>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Messages */}
            <TabsContent value="messages">
              <Card className="p-4 md:p-5">
                <div className="space-y-4">
                  {clientActivity.length > 0 ? clientActivity.map(a => (
                    <div key={a.id} className="flex items-start gap-3">
                      <Avatar className="w-7 h-7">
                        <AvatarImage src={a.actorAvatar} alt={a.actor} />
                        <AvatarFallback className="text-[10px]">{a.actor[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-foreground">
                          <span className="font-semibold">{a.actor}</span>{" "}
                          <span className="text-muted-foreground">{a.action}</span>{" "}
                          <span className="font-medium">{a.target}</span>
                        </p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{timeAgo(a.createdAt)}</p>
                      </div>
                    </div>
                  )) : (
                    <p className="text-xs text-muted-foreground text-center py-6">No messages yet.</p>
                  )}
                  <div className="pt-3 border-t border-border">
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Reply to your account manager..."
                        className="flex-1 h-9 px-3 text-xs rounded-md border border-input bg-card text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring"
                      />
                      <Button size="sm" className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
                        <ArrowRight className="w-3.5 h-3.5" /> Send
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Portal footer */}
        <div className="border-t border-border bg-secondary/40 px-4 md:px-6 py-3 flex items-center justify-between">
          <p className="text-[10px] text-muted-foreground inline-flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-primary" />
            This is a preview. Clients see this view when logged into their portal.
          </p>
          <Button asChild variant="link" size="sm" className="h-6 text-[10px] text-primary">
            <Link href={`/clients/${client.id}`}>View internal record <ArrowRight className="w-3 h-3 ml-1" /></Link>
          </Button>
        </div>
      </div>
    </DashboardShell>
  )
}

function PortalStat({ icon: Icon, label, value, sub, valueClass }: { icon: any; label: string; value: string; sub?: string; valueClass?: string }) {
  return (
    <Card className="p-3 md:p-4">
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      </div>
      <p className={cn("text-lg md:text-xl font-bold text-foreground", valueClass)}>{value}</p>
      {sub && <p className="text-[10px] text-muted-foreground mt-0.5">{sub}</p>}
    </Card>
  )
}
