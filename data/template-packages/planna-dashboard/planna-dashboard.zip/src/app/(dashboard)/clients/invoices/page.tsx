"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  FileText, Search, DollarSign, AlertTriangle, Clock, CheckCircle2,
  Plus, Download, Send, Trash2, MoreHorizontal,
} from "lucide-react"
import { invoices, clients } from "@/lib/data/mock"
import { cn, formatCurrency, formatDate } from "@/lib/utils"
import type { InvoiceStatus } from "@/types"

const statusStyles: Record<InvoiceStatus, string> = {
  paid:      "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  sent:      "bg-sky-500/15 text-sky-600 dark:text-sky-400",
  overdue:   "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  draft:     "bg-muted text-muted-foreground",
  cancelled: "bg-muted text-muted-foreground line-through",
}

const statusFilters: { key: InvoiceStatus | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "draft", label: "Draft" },
  { key: "sent", label: "Sent" },
  { key: "paid", label: "Paid" },
  { key: "overdue", label: "Overdue" },
]

const dateRangeOptions = [
  { key: "all", label: "All time" },
  { key: "30", label: "Last 30 days" },
  { key: "90", label: "Last 90 days" },
  { key: "365", label: "Last year" },
]

export default function InvoicesPage() {
  const [statusFilter, setStatusFilter] = useState<InvoiceStatus | "all">("all")
  const [clientFilter, setClientFilter] = useState<string>("all")
  const [dateRange, setDateRange] = useState<string>("all")
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<string>>(new Set())

  const filtered = useMemo(() => {
    const now = new Date()
    return invoices.filter(inv => {
      const matchStatus = statusFilter === "all" || inv.status === statusFilter
      const matchClient = clientFilter === "all" || inv.clientId === clientFilter
      const matchQuery = !query ||
        inv.number.toLowerCase().includes(query.toLowerCase()) ||
        inv.clientName.toLowerCase().includes(query.toLowerCase()) ||
        (inv.project ?? "").toLowerCase().includes(query.toLowerCase())
      let matchDate = true
      if (dateRange !== "all") {
        const days = parseInt(dateRange, 10)
        const cutoff = new Date(now.getTime() - days * 86400000)
        matchDate = new Date(inv.issueDate) >= cutoff
      }
      return matchStatus && matchClient && matchQuery && matchDate
    })
  }, [statusFilter, clientFilter, dateRange, query])

  const totalPaid = invoices.filter(i => i.status === "paid").reduce((s, i) => s + i.total, 0)
  const totalOutstanding = invoices.filter(i => i.status === "sent").reduce((s, i) => s + i.total, 0)
  const totalOverdue = invoices.filter(i => i.status === "overdue").reduce((s, i) => s + i.total, 0)

  const allSelected = filtered.length > 0 && filtered.every(i => selected.has(i.id))
  const toggleAll = () => {
    if (allSelected) {
      setSelected(new Set())
    } else {
      setSelected(new Set(filtered.map(i => i.id)))
    }
  }
  const toggleOne = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <DashboardShell
      title="Invoices"
      description="Bill clients and track payments across all engagements."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Download className="w-4 h-4" /> Export
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> Create invoice
          </Button>
        </>
      }
    >
      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Paid (all-time)" value={formatCurrency(totalPaid)} hint={`${invoices.filter(i => i.status === "paid").length} invoices`} icon={CheckCircle2} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Outstanding" value={formatCurrency(totalOutstanding)} hint="awaiting payment" icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Overdue" value={formatCurrency(totalOverdue)} hint="past due date" icon={AlertTriangle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar">
            {statusFilters.map(s => (
              <button
                key={s.key}
                onClick={() => setStatusFilter(s.key)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap",
                  statusFilter === s.key
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
          <Select value={clientFilter} onValueChange={setClientFilter}>
            <SelectTrigger className="h-9 w-full md:w-44 text-xs">
              <SelectValue placeholder="All clients" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All clients</SelectItem>
              {clients.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="h-9 w-full md:w-40 text-xs">
              <SelectValue placeholder="Date range" />
            </SelectTrigger>
            <SelectContent>
              {dateRangeOptions.map(o => (
                <SelectItem key={o.key} value={o.key}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="relative md:ml-auto md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search invoice #, client, project..."
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>
      </Card>

      {/* Bulk actions bar */}
      {selected.size > 0 && (
        <Card className="p-3 mb-3 border-primary/30 bg-primary/5 animate-fade-in">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs text-foreground">
              <span className="font-semibold">{selected.size}</span> invoice{selected.size === 1 ? "" : "s"} selected
            </p>
            <div className="flex items-center gap-1.5">
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5 bg-transparent">
                <Send className="w-3 h-3" /> Send reminders
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5 bg-transparent">
                <Download className="w-3 h-3" /> Download
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5 bg-transparent text-rose-600 dark:text-rose-400 hover:bg-rose-500/10">
                <Trash2 className="w-3 h-3" /> Delete
              </Button>
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setSelected(new Set())}>Cancel</Button>
            </div>
          </div>
        </Card>
      )}

      {/* Table */}
      <Card className="p-0 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState compact icon={FileText} title="No invoices found" description="Try adjusting your filters or create a new invoice." action={{ label: "Create invoice" }} />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-10 pl-3">
                    <Checkbox checked={allSelected} onCheckedChange={toggleAll} aria-label="Select all" />
                  </TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Invoice</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Client</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Project</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground text-right">Amount</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Issued</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Due</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Paid</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Status</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(inv => {
                  const isSelected = selected.has(inv.id)
                  const client = clients.find(c => c.id === inv.clientId)
                  return (
                    <TableRow key={inv.id} className={cn("hover:bg-secondary/30 transition-colors", isSelected && "bg-primary/5")}>
                      <TableCell className="pl-3">
                        <Checkbox checked={isSelected} onCheckedChange={() => toggleOne(inv.id)} aria-label={`Select ${inv.number}`} />
                      </TableCell>
                      <TableCell className="py-2.5">
                        <span className="text-xs font-mono font-semibold text-foreground">{inv.number}</span>
                      </TableCell>
                      <TableCell className="py-2.5">
                        {client && (
                          <Link href={`/clients/${client.id}`} className="flex items-center gap-2 group">
                            <Avatar className="w-5 h-5 rounded">
                              <AvatarImage src={inv.clientLogo} alt={inv.clientName} />
                              <AvatarFallback className="text-[8px] rounded">{inv.clientName.slice(0, 2)}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-foreground group-hover:text-primary transition-colors">{inv.clientName}</span>
                          </Link>
                        )}
                      </TableCell>
                      <TableCell className="py-2.5">
                        <span className="text-xs text-muted-foreground truncate block max-w-[160px]">{inv.project ?? "—"}</span>
                      </TableCell>
                      <TableCell className="py-2.5 text-right">
                        <p className="text-xs font-semibold text-foreground">{formatCurrency(inv.total)}</p>
                        <p className="text-[10px] text-muted-foreground">+{formatCurrency(inv.tax)} tax</p>
                      </TableCell>
                      <TableCell className="py-2.5 text-xs text-muted-foreground">{formatDate(inv.issueDate, { month: "short", day: "numeric" })}</TableCell>
                      <TableCell className="py-2.5 text-xs text-muted-foreground">{formatDate(inv.dueDate, { month: "short", day: "numeric" })}</TableCell>
                      <TableCell className="py-2.5 text-xs text-muted-foreground">
                        {inv.paidDate ? formatDate(inv.paidDate, { month: "short", day: "numeric" }) : "—"}
                      </TableCell>
                      <TableCell className="py-2.5">
                        <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize", statusStyles[inv.status])}>{inv.status}</span>
                      </TableCell>
                      <TableCell className="py-2.5">
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <MoreHorizontal className="w-3.5 h-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      {/* Footer summary */}
      <Card className="p-3 md:p-4 mt-3">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">
            Showing <span className="font-semibold text-foreground">{filtered.length}</span> of <span className="font-semibold text-foreground">{invoices.length}</span> invoices
          </span>
          <div className="flex items-center gap-4">
            <span className="text-muted-foreground">
              Filtered total: <span className="font-semibold text-foreground">{formatCurrency(filtered.reduce((s, i) => s + i.total, 0))}</span>
            </span>
            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
              <DollarSign className="w-3 h-3" />
              {formatCurrency(filtered.filter(i => i.status === "paid").reduce((s, i) => s + i.total, 0))} paid
            </span>
          </div>
        </div>
      </Card>
    </DashboardShell>
  )
}
