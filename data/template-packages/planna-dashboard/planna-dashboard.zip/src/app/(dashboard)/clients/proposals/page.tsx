"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  FileText, Plus, Search, DollarSign, TrendingUp, Target,
  Send, Eye, CheckCircle2, XCircle, FileEdit, Clock,
} from "lucide-react"
import { clients } from "@/lib/data/mock"
import { cn, formatCurrency, formatDate, relativeDay } from "@/lib/utils"

type ProposalStatus = "draft" | "sent" | "viewed" | "accepted" | "rejected"

interface Proposal {
  id: string
  title: string
  clientId: string
  value: number
  status: ProposalStatus
  sentDate?: string
  expiryDate: string
  owner: string
  ownerAvatar: string
  services: string[]
}

const proposals: Proposal[] = [
  { id: "pr1", title: "Q2 Mobile App Redesign", clientId: "c1", value: 180000, status: "accepted", sentDate: "2026-01-02", expiryDate: "2026-02-01", owner: "Zara Marlowe", ownerAvatar: clients[0].contactAvatar, services: ["UX/UI", "Mobile Dev", "QA"] },
  { id: "pr2", title: "Cloud Migration Assessment", clientId: "c2", value: 95000, status: "viewed", sentDate: "2026-01-08", expiryDate: "2026-02-08", owner: "Theo Nakamura", ownerAvatar: clients[1].contactAvatar, services: ["DevOps", "Architecture"] },
  { id: "pr3", title: "Brand Refresh & Identity System", clientId: "c3", value: 62000, status: "sent", sentDate: "2026-01-10", expiryDate: "2026-02-10", owner: "Mira Patel", ownerAvatar: clients[2].contactAvatar, services: ["Branding", "Design System"] },
  { id: "pr4", title: "Data Platform Build-out", clientId: "c6", value: 240000, status: "draft", expiryDate: "2026-03-15", owner: "Amara Okafor", ownerAvatar: clients[5].contactAvatar, services: ["Backend", "Data Eng", "Analytics"] },
  { id: "pr5", title: "Onboarding Portal MVP", clientId: "c4", value: 48000, status: "rejected", sentDate: "2025-12-15", expiryDate: "2026-01-15", owner: "Zara Marlowe", ownerAvatar: clients[3].contactAvatar, services: ["Product", "Frontend"] },
  { id: "pr6", title: "SOC2 Readiness Program", clientId: "c5", value: 120000, status: "viewed", sentDate: "2026-01-12", expiryDate: "2026-02-12", owner: "Theo Nakamura", ownerAvatar: clients[4].contactAvatar, services: ["Security", "Compliance"] },
  { id: "pr7", title: "Marketing Site Refresh", clientId: "c1", value: 36000, status: "accepted", sentDate: "2025-12-20", expiryDate: "2026-01-20", owner: "Isla Reyes", ownerAvatar: clients[0].contactAvatar, services: ["Marketing", "Frontend", "CMS"] },
  { id: "pr8", title: "API Platform Design Sprint", clientId: "c2", value: 58000, status: "sent", sentDate: "2026-01-14", expiryDate: "2026-02-14", owner: "Amara Okafor", ownerAvatar: clients[1].contactAvatar, services: ["API Design", "Documentation"] },
]

const statusConfig: Record<ProposalStatus, { label: string; className: string; icon: any }> = {
  draft:    { label: "Draft",    className: "bg-muted text-muted-foreground",                              icon: FileEdit },
  sent:     { label: "Sent",     className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",                 icon: Send },
  viewed:   { label: "Viewed",   className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",           icon: Eye },
  accepted: { label: "Accepted", className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",     icon: CheckCircle2 },
  rejected: { label: "Rejected", className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",              icon: XCircle },
}

const statusTabs: { key: ProposalStatus | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "draft", label: "Draft" },
  { key: "sent", label: "Sent" },
  { key: "viewed", label: "Viewed" },
  { key: "accepted", label: "Accepted" },
  { key: "rejected", label: "Rejected" },
]

export default function ProposalsPage() {
  const [statusFilter, setStatusFilter] = useState<ProposalStatus | "all">("all")
  const [query, setQuery] = useState("")

  const filtered = useMemo(() => {
    return proposals.filter(p => {
      const matchStatus = statusFilter === "all" || p.status === statusFilter
      const client = clients.find(c => c.id === p.clientId)
      const q = query.trim().toLowerCase()
      const matchQuery = !q ||
        p.title.toLowerCase().includes(q) ||
        (client?.name ?? "").toLowerCase().includes(q) ||
        p.owner.toLowerCase().includes(q)
      return matchStatus && matchQuery
    })
  }, [statusFilter, query])

  const pipelineValue = proposals.filter(p => p.status === "sent" || p.status === "viewed").reduce((s, p) => s + p.value, 0)
  const wonValue = proposals.filter(p => p.status === "accepted").reduce((s, p) => s + p.value, 0)
  const closedCount = proposals.filter(p => p.status === "accepted" || p.status === "rejected").length
  const winRate = closedCount > 0 ? Math.round((proposals.filter(p => p.status === "accepted").length / closedCount) * 100) : 0
  const avgValue = proposals.length ? Math.round(proposals.reduce((s, p) => s + p.value, 0) / proposals.length) : 0

  return (
    <DashboardShell
      title="Proposals"
      description="Sales proposals sent to clients and prospects."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> Create proposal
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Open Pipeline" value={formatCurrency(pipelineValue)} hint={`${proposals.filter(p => p.status === "sent" || p.status === "viewed").length} active`} icon={Target} trend={{ value: 12, positive: true }} />
        <StatCard label="Won Value" value={formatCurrency(wonValue)} hint={`${proposals.filter(p => p.status === "accepted").length} accepted`} icon={DollarSign} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" trend={{ value: 8, positive: true }} />
        <StatCard label="Win Rate" value={`${winRate}%`} hint={`${closedCount} closed`} icon={TrendingUp} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Avg Proposal" value={formatCurrency(avgValue)} hint="per engagement" icon={FileText} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar">
            {statusTabs.map(t => (
              <button
                key={t.key}
                onClick={() => setStatusFilter(t.key)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap",
                  statusFilter === t.key
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
          <div className="relative md:ml-auto md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search proposals..."
              className="w-full pl-9 pr-3 h-9 text-sm rounded-md border border-input bg-card text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
            />
          </div>
        </div>
      </Card>

      {/* Grid */}
      {filtered.length === 0 ? (
        <EmptyState icon={FileText} title="No proposals found" description="Try a different filter or create a new proposal." action={{ label: "Create proposal" }} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {filtered.map((p, i) => {
            const client = clients.find(c => c.id === p.clientId)
            const status = statusConfig[p.status]
            const StatusIcon = status.icon
            const isExpired = new Date(p.expiryDate) < new Date() && p.status !== "accepted"
            const daysLeft = Math.ceil((new Date(p.expiryDate).getTime() - Date.now()) / 86400000)
            return (
              <Card key={p.id} className="p-5 card-lift group animate-slide-in-up" style={{ animationDelay: `${i * 40}ms` }}>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <Link href={`/clients/${p.clientId}`} className="flex items-center gap-2.5 min-w-0">
                    <Avatar className="w-9 h-9 rounded-lg">
                      <AvatarImage src={client?.logo} alt={client?.name} />
                      <AvatarFallback className="rounded-lg text-[10px]">{client?.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <p className="text-[10px] text-muted-foreground">{client?.name}</p>
                      <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors">View client</p>
                    </div>
                  </Link>
                  <span className={cn("inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full", status.className)}>
                    <StatusIcon className="w-3 h-3" /> {status.label}
                  </span>
                </div>

                <h3 className="text-sm font-semibold text-foreground mb-2 line-clamp-2">{p.title}</h3>

                <div className="flex flex-wrap gap-1 mb-3">
                  {p.services.map(s => (
                    <Badge key={s} variant="outline" className="text-[9px] py-0 h-4">{s}</Badge>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="p-2 rounded-md bg-secondary/40">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Value</p>
                    <p className="text-base font-bold text-foreground">{formatCurrency(p.value)}</p>
                  </div>
                  <div className="p-2 rounded-md bg-secondary/40">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Owner</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <Avatar className="w-4 h-4">
                        <AvatarImage src={p.ownerAvatar} alt={p.owner} />
                        <AvatarFallback className="text-[8px]">{p.owner[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-[11px] text-foreground truncate">{p.owner.split(" ")[0]}</span>
                    </div>
                  </div>
                </div>

                {/* Expiry indicator */}
                <div className="space-y-1.5 pt-3 border-t border-border">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground inline-flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {p.sentDate ? `Sent ${formatDate(p.sentDate, { month: "short", day: "numeric" })}` : "Not sent"}
                    </span>
                    <span className={cn(
                      "font-semibold",
                      isExpired ? "text-rose-600 dark:text-rose-400" : daysLeft <= 7 ? "text-amber-600 dark:text-amber-400" : "text-muted-foreground"
                    )}>
                      {isExpired ? "Expired" : daysLeft > 0 ? `${daysLeft}d left` : "Expires today"}
                    </span>
                  </div>
                  {!isExpired && p.status !== "accepted" && p.status !== "rejected" && (
                    <Progress
                      value={Math.max(0, Math.min(100, 100 - (daysLeft / 30) * 100))}
                      className="h-1"
                    />
                  )}
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </DashboardShell>
  )
}
