"use client"

import { use, useState, useMemo } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ChartCard, PlannaAreaChart, PlannaDonutChart } from "@/components/charts"
import { ProjectStatusBadge, HealthBadge } from "@/components/common/badges"
import {
  ArrowLeft, Building2, Mail, Phone, MapPin, Briefcase, DollarSign,
  AlertTriangle, Plus, ExternalLink, Activity as ActivityIcon,
  FileText, StickyNote, LayoutDashboard, Calendar, TrendingUp,
  CheckCircle2, Clock, MessageSquare, Eye, Users,
} from "lucide-react"
import { clients, projects, invoices, activities, members } from "@/lib/data/mock"
import { cn, formatCurrency, formatDate, timeAgo, relativeDay, pct } from "@/lib/utils"

const statusConfig: Record<string, { label: string; className: string; dot: string }> = {
  active:   { label: "Active",   className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  lead:     { label: "Lead",     className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",             dot: "bg-sky-500" },
  prospect: { label: "Prospect", className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       dot: "bg-amber-500" },
  churned:  { label: "Churned",  className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",          dot: "bg-rose-500" },
}

const invoiceStatusStyles: Record<string, string> = {
  paid:     "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  sent:     "bg-sky-500/15 text-sky-600 dark:text-sky-400",
  overdue:  "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  draft:    "bg-muted text-muted-foreground",
  cancelled:"bg-muted text-muted-foreground line-through",
}

export default function ClientDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const client = clients.find(c => c.id === id)
  if (!client) notFound()

  const [activeTab, setActiveTab] = useState("overview")
  const [notes, setNotes] = useState([
    { id: "n1", author: "Zara Marlowe", authorAvatar: members[1].avatar, body: "Onboarding kickoff scheduled for next Tuesday. Acme wants custom branding on the onboarding flow — confirm with design.", createdAt: "2026-01-04T10:20:00Z" },
    { id: "n2", author: "Felix Brandt", authorAvatar: members[4].avatar, body: "IT contact confirmed SSO via Okta. Need test tenant credentials from their side.", createdAt: "2026-01-02T14:10:00Z" },
  ])
  const [newNote, setNewNote] = useState("")

  const clientProjects = useMemo(() => projects.filter(p => p.client === client.name), [client])
  const clientInvoices = useMemo(() => invoices.filter(i => i.clientId === client.id), [client])
  const clientActivities = useMemo(
    () => activities.filter(a => a.target.toLowerCase().includes(client.name.toLowerCase()) || a.target.includes("Acme")).slice(0, 6),
    [client]
  )

  const revenueTrend = useMemo(() => [
    { month: "Aug", revenue: 28000 },
    { month: "Sep", revenue: 32000 },
    { month: "Oct", revenue: 30000 },
    { month: "Nov", revenue: 42000 },
    { month: "Dec", revenue: 38000 },
    { month: "Jan", revenue: 48000 },
  ], [])

  const statusDistribution = useMemo(() => {
    const total = clientProjects.length || 1
    const active = clientProjects.filter(p => p.status === "active").length
    const completed = clientProjects.filter(p => p.status === "completed").length
    const planning = clientProjects.filter(p => p.status === "planning").length
    const other = total - active - completed - planning
    return [
      { name: "Active", value: active, color: "var(--chart-1)" },
      { name: "Planning", value: planning, color: "var(--chart-3)" },
      { name: "Completed", value: completed, color: "var(--chart-4)" },
      { name: "Other", value: Math.max(0, other), color: "var(--chart-5)" },
    ].filter(d => d.value > 0)
  }, [clientProjects])

  const status = statusConfig[client.status]
  const totalPaid = clientInvoices.filter(i => i.status === "paid").reduce((s, i) => s + i.total, 0)

  const handleAddNote = () => {
    if (!newNote.trim()) return
    setNotes(prev => [{
      id: `n${Date.now()}`,
      author: members[0].name,
      authorAvatar: members[0].avatar,
      body: newNote.trim(),
      createdAt: new Date().toISOString(),
    }, ...prev])
    setNewNote("")
  }

  return (
    <DashboardShell
      title="Client"
      description={client.company}
      breadcrumbs={[
        { label: "Clients", href: "/clients" },
        { label: client.name, href: `/clients/${client.id}` },
      ]}
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <FileText className="w-4 h-4" /> New invoice
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New project
          </Button>
        </>
      }
    >
      <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1 mb-3 -ml-2">
        <Link href="/clients"><ArrowLeft className="w-3.5 h-3.5" /> All clients</Link>
      </Button>

      {/* Client header */}
      <Card className="p-5 md:p-6 mb-4 animate-slide-in-up">
        <div className="flex flex-col lg:flex-row lg:items-start gap-5">
          <div className="flex items-start gap-4 flex-1">
            <Avatar className="w-16 h-16 rounded-2xl border border-border shrink-0">
              <AvatarImage src={client.logo} alt={client.name} />
              <AvatarFallback className="rounded-2xl text-lg">{client.name.slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", status.className)}>
                  <span className={cn("w-1.5 h-1.5 rounded-full", status.dot)} />
                  {status.label}
                </span>
                <Badge variant="outline" className="text-[10px] gap-1">
                  <Briefcase className="w-3 h-3" /> {client.industry}
                </Badge>
              </div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground tracking-tight">{client.name}</h1>
              <p className="text-xs md:text-sm text-muted-foreground mt-1">{client.company} · Client since {formatDate(client.startDate, { month: "short", year: "numeric" })}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 mt-4">
                <ContactItem icon={Mail} label="Email" value={client.email} href={`mailto:${client.email}`} />
                <ContactItem icon={Phone} label="Phone" value={client.phone} href={`tel:${client.phone.replace(/\s/g, "")}`} />
                <ContactItem icon={MapPin} label="Location" value={client.location} />
                <ContactItem icon={Building2} label="Industry" value={client.industry} />
              </div>
            </div>
          </div>

          {/* Contact card */}
          <Card className="p-4 w-full lg:w-72 border-border bg-secondary/30">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Primary contact</p>
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={client.contactAvatar} alt={client.contactName} />
                <AvatarFallback>{client.contactName[0]}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-semibold text-foreground">{client.contactName}</p>
                <p className="text-[11px] text-muted-foreground">{client.name}</p>
              </div>
            </div>
            <Button asChild variant="outline" size="sm" className="w-full h-8 text-xs bg-transparent">
              <Link href={`/clients/${client.id}#message`}>
                <MessageSquare className="w-3.5 h-3.5 mr-1.5" /> Send message
              </Link>
            </Button>
          </Card>
        </div>

        {/* Stat strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-5 pt-5 border-t border-border">
          <HeaderStat icon={DollarSign} label="Total revenue" value={formatCurrency(client.totalRevenue)} />
          <HeaderStat icon={Briefcase} label="Projects" value={String(client.projectsCount)} />
          <HeaderStat icon={AlertTriangle} label="Outstanding" value={formatCurrency(client.outstanding)} valueClass={client.outstanding > 0 ? "text-amber-600 dark:text-amber-400" : "text-foreground"} />
          <HeaderStat icon={TrendingUp} label="Avg invoice" value={clientInvoices.length ? formatCurrency(Math.round(client.totalRevenue / Math.max(1, clientInvoices.length))) : "—"} />
        </div>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="overflow-x-auto no-scrollbar mb-4">
          <TabsTrigger value="overview" className="gap-1.5 text-xs"><LayoutDashboard className="w-3.5 h-3.5" /> Overview</TabsTrigger>
          <TabsTrigger value="projects" className="gap-1.5 text-xs"><Briefcase className="w-3.5 h-3.5" /> Projects</TabsTrigger>
          <TabsTrigger value="invoices" className="gap-1.5 text-xs"><FileText className="w-3.5 h-3.5" /> Invoices</TabsTrigger>
          <TabsTrigger value="activity" className="gap-1.5 text-xs"><ActivityIcon className="w-3.5 h-3.5" /> Activity</TabsTrigger>
          <TabsTrigger value="notes" className="gap-1.5 text-xs"><StickyNote className="w-3.5 h-3.5" /> Notes</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
            <ChartCard title="Revenue Trend" subtitle="Last 6 months" className="lg:col-span-2">
              <PlannaAreaChart
                data={revenueTrend}
                xKey="month"
                series={[{ key: "revenue", name: "Revenue" }]}
                height={260}
                showLegend={false}
              />
            </ChartCard>
            <ChartCard title="Project Mix" subtitle="By status" fullscreen={false}>
              {statusDistribution.length > 0 ? (
                <PlannaDonutChart
                  data={statusDistribution}
                  height={260}
                  centerValue={String(clientProjects.length)}
                  centerLabel="projects"
                />
              ) : (
                <div className="flex items-center justify-center h-[260px] text-xs text-muted-foreground">No projects yet</div>
              )}
            </ChartCard>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
            {/* Projects list */}
            <Card className="p-4 md:p-5 lg:col-span-2 card-lift">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold">Active projects</h3>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setActiveTab("projects")}>View all</Button>
              </div>
              <div className="space-y-2">
                {clientProjects.length > 0 ? clientProjects.slice(0, 4).map(p => (
                  <Link key={p.id} href={`/projects/${p.id}`} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/30 transition-colors group">
                    <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", p.color)}>
                      <Briefcase className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate group-hover:text-primary transition-colors">{p.name}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Progress value={p.progress} className="h-1 flex-1 max-w-[180px]" />
                        <span className="text-[10px] text-muted-foreground">{p.progress}%</span>
                      </div>
                    </div>
                    <ProjectStatusBadge status={p.status} />
                  </Link>
                )) : <p className="text-xs text-muted-foreground text-center py-6">No active projects</p>}
              </div>
            </Card>

            {/* Recent invoices */}
            <Card className="p-4 md:p-5 card-lift">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold">Recent invoices</h3>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setActiveTab("invoices")}>View all</Button>
              </div>
              <div className="space-y-2">
                {clientInvoices.length > 0 ? clientInvoices.slice(0, 4).map(inv => (
                  <div key={inv.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-secondary/30 transition-colors">
                    <div className="min-w-0">
                      <p className="text-xs font-mono text-foreground truncate">{inv.number}</p>
                      <p className="text-[10px] text-muted-foreground">{formatDate(inv.issueDate, { month: "short", day: "numeric" })}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-foreground">{formatCurrency(inv.total)}</span>
                      <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded capitalize", invoiceStatusStyles[inv.status])}>{inv.status}</span>
                    </div>
                  </div>
                )) : <p className="text-xs text-muted-foreground text-center py-6">No invoices yet</p>}
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Projects */}
        <TabsContent value="projects" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
            {clientProjects.length > 0 ? clientProjects.map(p => (
              <Card key={p.id} className="p-4 md:p-5 card-lift">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", p.color)}>
                      <Briefcase className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <Link href={`/projects/${p.id}`} className="text-sm font-semibold text-foreground hover:text-primary transition-colors">{p.name}</Link>
                      <p className="text-[11px] text-muted-foreground">{p.key} · {p.lead}</p>
                    </div>
                  </div>
                  <ProjectStatusBadge status={p.status} />
                </div>
                <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{p.description}</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-semibold text-foreground">{p.progress}%</span>
                  </div>
                  <Progress value={p.progress} className="h-1.5" />
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3 text-[11px]">
                  <div>
                    <p className="text-muted-foreground">Tasks</p>
                    <p className="font-semibold text-foreground">{p.tasksDone}/{p.tasksTotal}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Budget</p>
                    <p className="font-semibold text-foreground">{formatCurrency(p.spent)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Due</p>
                    <p className="font-semibold text-foreground">{relativeDay(p.dueDate)}</p>
                  </div>
                </div>
              </Card>
            )) : (
              <div className="md:col-span-2">
                <EmptyState icon={Briefcase} title="No projects yet" description="Start a new engagement to see it here." action={{ label: "New project" }} />
              </div>
            )}
          </div>
        </TabsContent>

        {/* Invoices */}
        <TabsContent value="invoices">
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold">All invoices</h3>
              <span className="text-[11px] text-muted-foreground">{clientInvoices.length} invoices · {formatCurrency(totalPaid)} paid</span>
            </div>
            {clientInvoices.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                      <th className="py-2 pr-3 font-medium">Invoice</th>
                      <th className="py-2 px-3 font-medium">Project</th>
                      <th className="py-2 px-3 font-medium text-right">Amount</th>
                      <th className="py-2 px-3 font-medium">Issued</th>
                      <th className="py-2 px-3 font-medium">Due</th>
                      <th className="py-2 pl-3 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {clientInvoices.map(inv => (
                      <tr key={inv.id} className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors">
                        <td className="py-2.5 pr-3 font-mono text-foreground">{inv.number}</td>
                        <td className="py-2.5 px-3 text-muted-foreground">{inv.project ?? "—"}</td>
                        <td className="py-2.5 px-3 text-right font-semibold text-foreground">{formatCurrency(inv.total)}</td>
                        <td className="py-2.5 px-3 text-muted-foreground">{formatDate(inv.issueDate, { month: "short", day: "numeric" })}</td>
                        <td className="py-2.5 px-3 text-muted-foreground">{formatDate(inv.dueDate, { month: "short", day: "numeric" })}</td>
                        <td className="py-2.5 pl-3">
                          <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded capitalize", invoiceStatusStyles[inv.status])}>{inv.status}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState compact icon={FileText} title="No invoices" description="Invoices issued to this client will appear here." />
            )}
          </Card>
        </TabsContent>

        {/* Activity */}
        <TabsContent value="activity">
          <Card className="p-4 md:p-5 card-lift">
            <h3 className="text-sm font-semibold mb-4">Activity timeline</h3>
            {clientActivities.length > 0 ? (
              <div className="space-y-4">
                {clientActivities.map(a => (
                  <div key={a.id} className="flex items-start gap-3">
                    <Avatar className="w-7 h-7">
                      <AvatarImage src={a.actorAvatar} alt={a.actor} />
                      <AvatarFallback className="text-[10px]">{a.actor[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-foreground">
                        <span className="font-semibold">{a.actor}</span>{" "}
                        <span className="text-muted-foreground">{a.action}</span>{" "}
                        <span className="font-medium">{a.target}</span>
                      </p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{timeAgo(a.createdAt)}</p>
                    </div>
                    <ActivityTypeIcon type={a.type} />
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState compact icon={ActivityIcon} title="No activity yet" description="Recent activity for this client will appear here." />
            )}
          </Card>
        </TabsContent>

        {/* Notes */}
        <TabsContent value="notes">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
            <Card className="p-4 md:p-5 lg:col-span-2 card-lift">
              <h3 className="text-sm font-semibold mb-3">Internal notes</h3>
              <div className="flex gap-2 mb-4">
                <Textarea
                  value={newNote}
                  onChange={e => setNewNote(e.target.value)}
                  placeholder="Add an internal note (only visible to your team)..."
                  className="text-xs min-h-[70px] resize-none"
                />
                <Button
                  size="sm"
                  className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 self-end"
                  onClick={handleAddNote}
                  disabled={!newNote.trim()}
                >
                  <Plus className="w-3.5 h-3.5" />
                </Button>
              </div>
              <div className="space-y-3 max-h-96 overflow-y-auto scroll-area-thin pr-1">
                {notes.map(n => (
                  <div key={n.id} className="p-3 rounded-lg bg-secondary/40 border border-border">
                    <div className="flex items-center gap-2 mb-1.5">
                      <Avatar className="w-5 h-5">
                        <AvatarImage src={n.authorAvatar} alt={n.author} />
                        <AvatarFallback className="text-[9px]">{n.author[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-[11px] font-semibold text-foreground">{n.author}</span>
                      <span className="text-[10px] text-muted-foreground">{timeAgo(n.createdAt)}</span>
                    </div>
                    <p className="text-xs text-foreground whitespace-pre-wrap">{n.body}</p>
                  </div>
                ))}
              </div>
            </Card>
            <Card className="p-4 md:p-5 card-lift">
              <h3 className="text-sm font-semibold mb-3">Quick links</h3>
              <div className="space-y-2">
                <QuickLink icon={FileText} label="All invoices" sub={`${clientInvoices.length} records`} href={`/clients/invoices?client=${client.id}`} />
                <QuickLink icon={Briefcase} label="Client projects" sub={`${clientProjects.length} active`} href={`/clients/projects?client=${client.id}`} />
                <QuickLink icon={Eye} label="Client portal preview" sub="See client's view" href={`/clients/portal?client=${client.id}`} />
                <QuickLink icon={CheckCircle2} label="Approvals queue" sub="Pending client sign-off" href="/clients/approvals" />
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}

function ContactItem({ icon: Icon, label, value, href }: { icon: any; label: string; value: string; href?: string }) {
  const content = (
    <div className="flex items-center gap-2">
      <div className="w-7 h-7 rounded-md bg-secondary flex items-center justify-center shrink-0">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className="text-xs font-medium text-foreground truncate">{value}</p>
      </div>
    </div>
  )
  if (href) {
    return <a href={href} className="block hover:opacity-80 transition-opacity">{content}</a>
  }
  return content
}

function HeaderStat({ icon: Icon, label, value, valueClass }: { icon: any; label: string; value: string; valueClass?: string }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-1">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      </div>
      <p className={cn("text-lg font-bold text-foreground", valueClass)}>{value}</p>
    </div>
  )
}

function ActivityTypeIcon({ type }: { type: string }) {
  const map: Record<string, { icon: any; color: string }> = {
    task:     { icon: CheckCircle2, color: "text-emerald-600 dark:text-emerald-400" },
    project:  { icon: Briefcase,    color: "text-sky-600 dark:text-sky-400" },
    comment:  { icon: MessageSquare, color: "text-violet-600 dark:text-violet-400" },
    file:     { icon: FileText,     color: "text-amber-600 dark:text-amber-400" },
    team:     { icon: Users,        color: "text-teal-600 dark:text-teal-400" },
  }
  const { icon: Icon, color } = map[type] ?? map.task
  return <Icon className={cn("w-3.5 h-3.5", color)} />
}

function QuickLink({ icon: Icon, label, sub, href }: { icon: any; label: string; sub: string; href: string }) {
  return (
    <Link href={href} className="flex items-center gap-3 p-2.5 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors group">
      <div className="w-7 h-7 rounded-md bg-primary/10 text-primary flex items-center justify-center">
        <Icon className="w-3.5 h-3.5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors">{label}</p>
        <p className="text-[10px] text-muted-foreground">{sub}</p>
      </div>
      <ExternalLink className="w-3 h-3 text-muted-foreground" />
    </Link>
  )
}
