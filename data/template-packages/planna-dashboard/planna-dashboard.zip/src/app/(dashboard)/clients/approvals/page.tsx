"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  CheckSquare, Clock, FileCheck, GitPullRequest, FileText,
  Check, X, MessageSquare, AlertTriangle, Inbox, Plus, Filter,
} from "lucide-react"
import { clients } from "@/lib/data/mock"
import { cn, formatDate, relativeDay, timeAgo } from "@/lib/utils"

type ApprovalType = "deliverable" | "change_request" | "invoice" | "milestone"
type ApprovalStatus = "pending" | "approved" | "rejected" | "changes_requested"

interface ApprovalItem {
  id: string
  title: string
  clientId: string
  type: ApprovalType
  submittedAt: string
  dueAt: string
  status: ApprovalStatus
  submittedBy: string
  submittedByAvatar: string
  description: string
}

const approvalItems: ApprovalItem[] = [
  { id: "ap1", title: "Q1 Marketing Site Homepage — Final Design", clientId: "c1", type: "deliverable", submittedAt: "2026-01-12T10:00:00Z", dueAt: "2026-01-19", status: "pending", submittedBy: "Mira Patel", submittedByAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=128&h=128&fit=crop", description: "Final homepage design with hero, pricing, and footer sections ready for sign-off." },
  { id: "ap2", title: "Change Request: Add SSO via Okta", clientId: "c1", type: "change_request", submittedAt: "2026-01-11T14:30:00Z", dueAt: "2026-01-18", status: "pending", submittedBy: "Hugo Lindqvist", submittedByAvatar: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=128&h=128&fit=crop", description: "Add SAML 2.0 SSO via Acme's Okta tenant. Scope: 14 day effort, $18K change order." },
  { id: "ap3", title: "Invoice INV-2026-0042 — $34,560", clientId: "c1", type: "invoice", submittedAt: "2026-01-05T09:00:00Z", dueAt: "2026-01-12", status: "pending", submittedBy: "Jessin Sam", submittedByAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop", description: "Q1 services invoice covering December 2025 - January 2026." },
  { id: "ap4", title: "Beta Launch Milestone Acceptance", clientId: "c3", type: "milestone", submittedAt: "2026-01-10T16:45:00Z", dueAt: "2026-01-17", status: "pending", submittedBy: "Zara Marlowe", submittedByAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&h=128&fit=crop", description: "Lumen Beta launch milestone — please review the delivered acceptance criteria." },
  { id: "ap5", title: "API Documentation Update — v2.1", clientId: "c2", type: "deliverable", submittedAt: "2026-01-09T11:15:00Z", dueAt: "2026-01-16", status: "changes_requested", submittedBy: "Sofia Vargas", submittedByAvatar: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=128&h=128&fit=crop", description: "Updated API docs covering new rate-limiting endpoints. Client requested additional examples for webhook retries." },
  { id: "ap6", title: "Cloud Migration Assessment Report", clientId: "c2", type: "deliverable", submittedAt: "2026-01-04T08:00:00Z", dueAt: "2026-01-11", status: "approved", submittedBy: "Theo Nakamura", submittedByAvatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=128&h=128&fit=crop", description: "Comprehensive assessment of Nimbus's existing infrastructure with migration recommendations." },
  { id: "ap7", title: "Change Request: Extended Brand Guidelines", clientId: "c3", type: "change_request", submittedAt: "2026-01-03T13:00:00Z", dueAt: "2026-01-10", status: "rejected", submittedBy: "Mira Patel", submittedByAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=128&h=128&fit=crop", description: "Scope expansion to include motion design guidelines. Rejected due to budget constraints." },
  { id: "ap8", title: "Q4 Invoice — $19,440", clientId: "c2", type: "invoice", submittedAt: "2025-12-22T10:30:00Z", dueAt: "2025-12-29", status: "approved", submittedBy: "Jessin Sam", submittedByAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop", description: "Q4 services invoice for Nimbus migration project." },
]

const typeConfig: Record<ApprovalType, { label: string; icon: any; color: string }> = {
  deliverable:    { label: "Deliverable",     icon: FileCheck,        color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  change_request: { label: "Change Request",  icon: GitPullRequest,   color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  invoice:        { label: "Invoice",          icon: FileText,         color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  milestone:      { label: "Milestone",        icon: CheckSquare,      color: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
}

const statusConfig: Record<ApprovalStatus, { label: string; className: string; dot: string }> = {
  pending:            { label: "Pending",            className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       dot: "bg-amber-500" },
  approved:           { label: "Approved",           className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  rejected:           { label: "Rejected",           className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",          dot: "bg-rose-500" },
  changes_requested:  { label: "Changes Requested",  className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",             dot: "bg-sky-500" },
}

const statusTabs: { key: ApprovalStatus | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "pending", label: "Pending" },
  { key: "changes_requested", label: "Changes Requested" },
  { key: "approved", label: "Approved" },
  { key: "rejected", label: "Rejected" },
]

export default function ApprovalsPage() {
  const [statusFilter, setStatusFilter] = useState<ApprovalStatus | "all">("all")
  const [items, setItems] = useState(approvalItems)

  const filtered = useMemo(() => {
    return items.filter(i => statusFilter === "all" || i.status === statusFilter)
  }, [items, statusFilter])

  const pending = items.filter(i => i.status === "pending")
  const overdue = pending.filter(i => new Date(i.dueAt) < new Date())
  const approvedThisMonth = items.filter(i => i.status === "approved").length
  const avgTurnaround = "2.4 days"

  const handleAction = (id: string, action: ApprovalStatus) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, status: action } : i))
  }

  return (
    <DashboardShell
      title="Approvals Queue"
      description="Items awaiting client review and sign-off."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> Request approval
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Pending" value={pending.length} hint="awaiting client" icon={Inbox} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Overdue" value={overdue.length} hint="past due date" icon={AlertTriangle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Approved (30d)" value={approvedThisMonth} hint="this month" icon={Check} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Avg Turnaround" value={avgTurnaround} hint="submit to approve" icon={Clock} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* Filter tabs */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar w-full md:w-auto md:inline-flex">
          {statusTabs.map(t => {
            const count = t.key === "all" ? items.length : items.filter(i => i.status === t.key).length
            return (
              <button
                key={t.key}
                onClick={() => setStatusFilter(t.key)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5",
                  statusFilter === t.key
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t.label}
                <span className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded-full",
                  statusFilter === t.key ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
                )}>{count}</span>
              </button>
            )
          })}
        </div>
      </Card>

      {/* List */}
      {filtered.length === 0 ? (
        <EmptyState icon={CheckSquare} title="Nothing in the queue" description="All caught up. New approval requests will appear here." action={{ label: "Request approval" }} />
      ) : (
        <div className="space-y-3">
          {filtered.map((item, i) => {
            const client = clients.find(c => c.id === item.clientId)
            const type = typeConfig[item.type]
            const TypeIcon = type.icon
            const status = statusConfig[item.status]
            const isPending = item.status === "pending"
            const isOverdue = isPending && new Date(item.dueAt) < new Date()
            const daysLeft = Math.ceil((new Date(item.dueAt).getTime() - Date.now()) / 86400000)
            return (
              <Card key={item.id} className={cn("p-4 md:p-5 card-lift animate-slide-in-up", isOverdue && "border-rose-500/30")} style={{ animationDelay: `${i * 30}ms` }}>
                <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                  {/* Type icon */}
                  <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0", type.color)}>
                    <TypeIcon className="w-4 h-4" />
                  </div>

                  {/* Body */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3 mb-1.5">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded", type.color)}>{type.label}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">#{item.id.toUpperCase()}</span>
                          {item.status !== "pending" && (
                            <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full", status.className)}>
                              <span className={cn("w-1 h-1 rounded-full", status.dot)} />
                              {status.label}
                            </span>
                          )}
                        </div>
                        <p className="text-sm font-semibold text-foreground">{item.title}</p>
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{item.description}</p>
                      </div>
                    </div>

                    {/* Meta */}
                    <div className="flex items-center gap-4 mt-3 text-[11px] text-muted-foreground flex-wrap">
                      {client && (
                        <Link href={`/clients/${client.id}`} className="inline-flex items-center gap-1.5 hover:text-primary transition-colors">
                          <Avatar className="w-4 h-4 rounded">
                            <AvatarImage src={client.logo} alt={client.name} />
                            <AvatarFallback className="text-[7px] rounded">{client.name.slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          {client.name}
                        </Link>
                      )}
                      <span className="inline-flex items-center gap-1">
                        <Avatar className="w-3.5 h-3.5">
                          <AvatarImage src={item.submittedByAvatar} alt={item.submittedBy} />
                          <AvatarFallback className="text-[8px]">{item.submittedBy[0]}</AvatarFallback>
                        </Avatar>
                        by {item.submittedBy.split(" ")[0]} · {timeAgo(item.submittedAt)}
                      </span>
                      <span className={cn(
                        "inline-flex items-center gap-1 font-medium",
                        isOverdue ? "text-rose-600 dark:text-rose-400" : isPending && daysLeft <= 3 ? "text-amber-600 dark:text-amber-400" : ""
                      )}>
                        {isOverdue ? <AlertTriangle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        {isOverdue ? `Overdue by ${-daysLeft}d` : isPending ? `Due ${relativeDay(item.dueAt)}` : `Closed ${formatDate(item.dueAt, { month: "short", day: "numeric" })}`}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  {isPending && (
                    <div className="flex items-center gap-1.5 lg:flex-col lg:items-stretch shrink-0">
                      <Button
                        size="sm"
                        className="h-8 text-xs bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5 flex-1 lg:flex-none"
                        onClick={() => handleAction(item.id, "approved")}
                      >
                        <Check className="w-3.5 h-3.5" /> Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 text-xs bg-transparent gap-1.5 flex-1 lg:flex-none"
                        onClick={() => handleAction(item.id, "changes_requested")}
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Changes
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 text-xs bg-transparent text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 gap-1.5 flex-1 lg:flex-none"
                        onClick={() => handleAction(item.id, "rejected")}
                      >
                        <X className="w-3.5 h-3.5" /> Reject
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </DashboardShell>
  )
}
