"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users, DollarSign, AlertTriangle, TrendingUp, Plus, Search,
  MapPin, Briefcase, ArrowUpRight, Building2, Filter,
} from "lucide-react"
import { clients } from "@/lib/data/mock"
import { cn, formatCurrency, formatDate } from "@/lib/utils"

type StatusFilter = "all" | "active" | "lead" | "prospect" | "churned"

const statusConfig: Record<string, { label: string; className: string; dot: string }> = {
  active:   { label: "Active",   className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  lead:     { label: "Lead",     className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",             dot: "bg-sky-500" },
  prospect: { label: "Prospect", className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       dot: "bg-amber-500" },
  churned:  { label: "Churned",  className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",          dot: "bg-rose-500" },
}

function ClientStatusBadge({ status }: { status: string }) {
  const c = statusConfig[status] ?? statusConfig.active
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", c.className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot)} />
      {c.label}
    </span>
  )
}

export default function ClientsPage() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all")
  const [query, setQuery] = useState("")

  const filtered = useMemo(() => {
    return clients.filter(c => {
      const matchStatus = statusFilter === "all" || c.status === statusFilter
      const q = query.trim().toLowerCase()
      const matchQuery =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.company.toLowerCase().includes(q) ||
        c.industry.toLowerCase().includes(q) ||
        c.contactName.toLowerCase().includes(q)
      return matchStatus && matchQuery
    })
  }, [statusFilter, query])

  const activeCount = clients.filter(c => c.status === "active").length
  const totalRevenue = clients.reduce((s, c) => s + c.totalRevenue, 0)
  const totalOutstanding = clients.reduce((s, c) => s + c.outstanding, 0)
  const totalProjects = clients.reduce((s, c) => s + c.projectsCount, 0)
  const avgProjectValue = totalProjects > 0 ? Math.round(totalRevenue / totalProjects) : 0

  const statusCounts: Record<StatusFilter, number> = {
    all: clients.length,
    active: clients.filter(c => c.status === "active").length,
    lead: clients.filter(c => c.status === "lead").length,
    prospect: clients.filter(c => c.status === "prospect").length,
    churned: clients.filter(c => c.status === "churned").length,
  }

  const statusTabs: { key: StatusFilter; label: string }[] = [
    { key: "all", label: "All" },
    { key: "active", label: "Active" },
    { key: "lead", label: "Leads" },
    { key: "prospect", label: "Prospects" },
    { key: "churned", label: "Churned" },
  ]

  return (
    <DashboardShell
      title="Clients"
      description="Manage your client relationships, engagements, and revenue."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Export
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> Add client
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Clients" value={activeCount} hint={`${clients.length} total in CRM`} icon={Users} trend={{ value: 12, positive: true }} />
        <StatCard label="Total Revenue" value={formatCurrency(totalRevenue)} hint="lifetime" icon={DollarSign} trend={{ value: 18, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Outstanding" value={formatCurrency(totalOutstanding)} hint="awaiting payment" icon={AlertTriangle} trend={{ value: 4, positive: false }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Project Value" value={formatCurrency(avgProjectValue)} hint={`${totalProjects} projects`} icon={TrendingUp} trend={{ value: 7, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar">
            {statusTabs.map(t => (
              <button
                key={t.key}
                onClick={() => setStatusFilter(t.key)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5",
                  statusFilter === t.key
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t.label}
                <span className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded-full",
                  statusFilter === t.key ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
                )}>
                  {statusCounts[t.key]}
                </span>
              </button>
            ))}
          </div>
          <div className="relative md:ml-auto md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search by name, industry, contact..."
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>
      </Card>

      {/* Grid */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No clients found"
          description="Try adjusting your filters or search query."
          action={{ label: "Add client" }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {filtered.map((c, i) => (
            <Card key={c.id} className={cn("p-5 card-lift group animate-slide-in-up")} style={{ animationDelay: `${i * 40}ms` }}>
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar className="w-11 h-11 rounded-lg border border-border">
                    <AvatarImage src={c.logo} alt={c.name} />
                    <AvatarFallback className="rounded-lg text-xs">{c.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <Link href={`/clients/${c.id}`} className="block">
                      <p className="text-sm font-semibold text-foreground truncate group-hover:text-primary transition-colors">
                        {c.name}
                      </p>
                    </Link>
                    <p className="text-[11px] text-muted-foreground truncate">{c.company}</p>
                  </div>
                </div>
                <ClientStatusBadge status={c.status} />
              </div>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-muted-foreground mb-4">
                <span className="inline-flex items-center gap-1">
                  <Briefcase className="w-3 h-3" /> {c.industry}
                </span>
                <span className="inline-flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {c.location}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-2.5 rounded-lg bg-secondary/60">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Revenue</p>
                  <p className="text-base font-bold text-foreground">{formatCurrency(c.totalRevenue)}</p>
                </div>
                <div className="p-2.5 rounded-lg bg-secondary/60">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Projects</p>
                  <p className="text-base font-bold text-foreground">{c.projectsCount}</p>
                </div>
              </div>

              {c.outstanding > 0 ? (
                <div className="flex items-center gap-2 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 mb-4">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                  <p className="text-[11px] text-amber-700 dark:text-amber-300">
                    <span className="font-semibold">{formatCurrency(c.outstanding)}</span> outstanding
                  </p>
                </div>
              ) : (
                c.status === "active" && (
                  <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 mb-4">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <p className="text-[11px] text-emerald-700 dark:text-emerald-300">All invoices settled</p>
                  </div>
                )
              )}

              <div className="flex items-center justify-between pt-3 border-t border-border">
                <div className="flex items-center gap-2 min-w-0">
                  <Avatar className="w-5 h-5">
                    <AvatarImage src={c.contactAvatar} alt={c.contactName} />
                    <AvatarFallback className="text-[9px]">{c.contactName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <p className="text-[11px] font-medium text-foreground truncate">{c.contactName}</p>
                    <p className="text-[10px] text-muted-foreground">Since {formatDate(c.startDate, { month: "short", year: "numeric" })}</p>
                  </div>
                </div>
                <Button asChild variant="ghost" size="icon" className="h-7 w-7 shrink-0">
                  <Link href={`/clients/${c.id}`}>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </Link>
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </DashboardShell>
  )
}
