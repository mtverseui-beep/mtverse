"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  FileSignature, Plus, Search, DollarSign, Calendar, ShieldCheck,
  ScrollText, FileText, ExternalLink, Clock, CheckCircle2, XCircle,
} from "lucide-react"
import { clients } from "@/lib/data/mock"
import { cn, formatCurrency, formatDate, relativeDay } from "@/lib/utils"

type ContractType = "MSA" | "SOW" | "NDA" | "DPA" | "SLA"
type ContractStatus = "active" | "expiring" | "expired" | "terminated" | "draft"

interface Contract {
  id: string
  title: string
  clientId: string
  type: ContractType
  startDate: string
  endDate: string
  value: number
  status: ContractStatus
  signedBy: string
  signedAt: string
}

const contracts: Contract[] = [
  { id: "ct1", title: "Master Services Agreement — 2026", clientId: "c1", type: "MSA", startDate: "2026-01-01", endDate: "2026-12-31", value: 480000, status: "active", signedBy: "Marie Lopez", signedAt: "2025-12-18" },
  { id: "ct2", title: "Statement of Work — Mobile App", clientId: "c1", type: "SOW", startDate: "2026-01-15", endDate: "2026-06-30", value: 180000, status: "active", signedBy: "Marie Lopez", signedAt: "2026-01-08" },
  { id: "ct3", title: "Non-Disclosure Agreement", clientId: "c2", type: "NDA", startDate: "2025-08-01", endDate: "2027-08-01", value: 0, status: "active", signedBy: "James Wright", signedAt: "2025-07-22" },
  { id: "ct4", title: "SOW — Cloud Migration Phase 2", clientId: "c2", type: "SOW", startDate: "2026-02-01", endDate: "2026-05-15", value: 95000, status: "expiring", signedBy: "James Wright", signedAt: "2026-01-20" },
  { id: "ct5", title: "Master Services Agreement", clientId: "c3", type: "MSA", startDate: "2023-11-21", endDate: "2025-11-21", value: 215000, status: "expired", signedBy: "Sara Jiménez", signedAt: "2023-11-15" },
  { id: "ct6", title: "Data Processing Agreement", clientId: "c6", type: "DPA", startDate: "2025-03-01", endDate: "2027-03-01", value: 0, status: "active", signedBy: "David Park", signedAt: "2025-02-20" },
  { id: "ct7", title: "SOW — Brand Identity System", clientId: "c3", type: "SOW", startDate: "2025-09-01", endDate: "2025-12-31", value: 62000, status: "expired", signedBy: "Sara Jiménez", signedAt: "2025-08-25" },
  { id: "ct8", title: "Service Level Agreement", clientId: "c1", type: "SLA", startDate: "2026-01-01", endDate: "2026-12-31", value: 0, status: "active", signedBy: "Marie Lopez", signedAt: "2025-12-18" },
  { id: "ct9", title: "SOW — Onboarding Portal", clientId: "c4", type: "SOW", startDate: "2025-09-15", endDate: "2025-12-15", value: 48000, status: "terminated", signedBy: "Robert Chen", signedAt: "2025-09-10" },
  { id: "ct10", title: "MSA — Renewal Draft", clientId: "c5", type: "MSA", startDate: "2026-03-01", endDate: "2027-02-28", value: 120000, status: "draft", signedBy: "", signedAt: "" },
]

const typeConfig: Record<ContractType, { label: string; icon: any; color: string }> = {
  MSA: { label: "MSA", icon: ScrollText,   color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  SOW: { label: "SOW", icon: FileText,     color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  NDA: { label: "NDA", icon: ShieldCheck,  color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  DPA: { label: "DPA", icon: ShieldCheck,  color: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
  SLA: { label: "SLA", icon: ScrollText,   color: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
}

const statusConfig: Record<ContractStatus, { label: string; className: string; dot: string }> = {
  active:     { label: "Active",     className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  expiring:   { label: "Expiring",   className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       dot: "bg-amber-500" },
  expired:    { label: "Expired",    className: "bg-muted text-muted-foreground",                            dot: "bg-muted-foreground" },
  terminated: { label: "Terminated", className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",          dot: "bg-rose-500" },
  draft:      { label: "Draft",      className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",             dot: "bg-sky-500" },
}

const statusTabs: { key: ContractStatus | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "active", label: "Active" },
  { key: "expiring", label: "Expiring" },
  { key: "draft", label: "Drafts" },
  { key: "expired", label: "Expired" },
  { key: "terminated", label: "Terminated" },
]

export default function ContractsPage() {
  const [statusFilter, setStatusFilter] = useState<ContractStatus | "all">("all")
  const [query, setQuery] = useState("")

  const filtered = useMemo(() => {
    return contracts.filter(c => {
      const matchStatus = statusFilter === "all" || c.status === statusFilter
      const client = clients.find(cl => cl.id === c.clientId)
      const q = query.trim().toLowerCase()
      const matchQuery = !q ||
        c.title.toLowerCase().includes(q) ||
        (client?.name ?? "").toLowerCase().includes(q) ||
        c.type.toLowerCase().includes(q)
      return matchStatus && matchQuery
    })
  }, [statusFilter, query])

  const activeCount = contracts.filter(c => c.status === "active").length
  const expiringCount = contracts.filter(c => c.status === "expiring").length
  const totalValue = contracts.filter(c => c.status === "active" || c.status === "expiring").reduce((s, c) => s + c.value, 0)
  const totalDuration = contracts.length

  return (
    <DashboardShell
      title="Contracts"
      description="Active and historical agreements with your clients."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New contract
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Contracts" value={activeCount} hint={`${expiringCount} expiring soon`} icon={FileSignature} />
        <StatCard label="Contract Value" value={formatCurrency(totalValue)} hint="active agreements" icon={DollarSign} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Avg Duration" value="14 mo" hint="across all contracts" icon={Calendar} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Total Records" value={totalDuration} hint="including expired" icon={ScrollText} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar">
            {statusTabs.map(t => (
              <button
                key={t.key}
                onClick={() => setStatusFilter(t.key)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap",
                  statusFilter === t.key
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
          <div className="relative md:ml-auto md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search contracts, clients..."
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>
      </Card>

      {/* List */}
      {filtered.length === 0 ? (
        <EmptyState icon={FileSignature} title="No contracts found" description="Try adjusting your filters or create a new contract." action={{ label: "New contract" }} />
      ) : (
        <Card className="p-0 overflow-hidden">
          <div className="divide-y divide-border">
            {filtered.map((c, i) => {
              const client = clients.find(cl => cl.id === c.clientId)
              const type = typeConfig[c.type]
              const TypeIcon = type.icon
              const status = statusConfig[c.status]
              const isExpired = c.status === "expired" || c.status === "terminated"
              return (
                <div
                  key={c.id}
                  className="p-4 md:p-5 hover:bg-secondary/30 transition-colors group animate-slide-in-up"
                  style={{ animationDelay: `${i * 30}ms` }}
                >
                  <div className="flex flex-col md:flex-row md:items-center gap-4">
                    {/* Type icon + title */}
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0", type.color)}>
                        <TypeIcon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className={cn("text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded", type.color)}>{type.label}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">#{c.id.toUpperCase()}</span>
                        </div>
                        <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors truncate">{c.title}</p>
                        {client && (
                          <Link href={`/clients/${client.id}`} className="inline-flex items-center gap-1.5 mt-1">
                            <Avatar className="w-3.5 h-3.5 rounded">
                              <AvatarImage src={client.logo} alt={client.name} />
                              <AvatarFallback className="text-[7px] rounded">{client.name.slice(0, 2)}</AvatarFallback>
                            </Avatar>
                            <span className="text-[11px] text-muted-foreground hover:text-primary transition-colors">{client.name}</span>
                          </Link>
                        )}
                      </div>
                    </div>

                    {/* Term */}
                    <div className="flex items-center gap-6 text-[11px]">
                      <div>
                        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Start</p>
                        <p className="font-semibold text-foreground">{formatDate(c.startDate, { month: "short", day: "numeric", year: "numeric" })}</p>
                      </div>
                      <div>
                        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">End</p>
                        <p className={cn("font-semibold", isExpired ? "text-muted-foreground line-through" : "text-foreground")}>
                          {formatDate(c.endDate, { month: "short", day: "numeric", year: "numeric" })}
                        </p>
                      </div>
                    </div>

                    {/* Value */}
                    <div className="text-right min-w-[100px]">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Value</p>
                      <p className="text-sm font-bold text-foreground">{c.value > 0 ? formatCurrency(c.value) : "—"}</p>
                    </div>

                    {/* Status */}
                    <div className="flex items-center gap-3">
                      <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", status.className)}>
                        <span className={cn("w-1.5 h-1.5 rounded-full", status.dot)} />
                        {status.label}
                      </span>
                      <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                        <ExternalLink className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>

                  {/* Signed-by footer */}
                  {c.signedBy && (
                    <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border text-[11px] text-muted-foreground">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      <span>Signed by <span className="font-medium text-foreground">{c.signedBy}</span> on {formatDate(c.signedAt, { month: "short", day: "numeric", year: "numeric" })}</span>
                      {c.status === "expiring" && (
                        <Badge variant="outline" className="text-[9px] ml-auto text-amber-600 dark:text-amber-400 border-amber-500/30">
                          <Clock className="w-2.5 h-2.5 mr-1" />
                          Expires {relativeDay(c.endDate)}
                        </Badge>
                      )}
                      {c.status === "terminated" && (
                        <Badge variant="outline" className="text-[9px] ml-auto text-rose-600 dark:text-rose-400 border-rose-500/30">
                          <XCircle className="w-2.5 h-2.5 mr-1" />
                          Terminated
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </Card>
      )}
    </DashboardShell>
  )
}
