"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table"
import { PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import {
  CheckSquare, Search, ListChecks, AlertTriangle, Clock,
  Plus, Download,
} from "lucide-react"
import { tasks, projects, clients } from "@/lib/data/mock"
import { cn, relativeDay, formatDate } from "@/lib/utils"
import type { TaskStatus } from "@/types"

const statusFilters: { key: TaskStatus | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "in_progress", label: "In Progress" },
  { key: "todo", label: "To Do" },
  { key: "review", label: "Review" },
  { key: "done", label: "Done" },
  { key: "blocked", label: "Blocked" },
]

export default function ClientTasksPage() {
  const [statusFilter, setStatusFilter] = useState<TaskStatus | "all">("all")
  const [query, setQuery] = useState("")

  // Map of projectName -> client
  const projectToClient = useMemo(() => {
    const map = new Map<string, { id: string; name: string; logo: string }>()
    projects.filter(p => p.client).forEach(p => {
      const c = clients.find(c => c.name === p.client)
      if (c) map.set(p.name, { id: c.id, name: c.name, logo: c.logo })
    })
    return map
  }, [])

  // Tasks belonging to client projects
  const clientTasks = useMemo(() => {
    const clientProjectNames = new Set(projects.filter(p => p.client).map(p => p.name))
    return tasks.filter(t => clientProjectNames.has(t.projectName)).map(t => ({
      ...t,
      client: projectToClient.get(t.projectName),
    }))
  }, [projectToClient])

  const filtered = useMemo(() => {
    return clientTasks.filter(t => {
      const matchStatus = statusFilter === "all" || t.status === statusFilter
      const q = query.trim().toLowerCase()
      const matchQuery = !q ||
        t.title.toLowerCase().includes(q) ||
        t.key.toLowerCase().includes(q) ||
        (t.assignee ?? "").toLowerCase().includes(q) ||
        (t.client?.name ?? "").toLowerCase().includes(q)
      return matchStatus && matchQuery
    })
  }, [clientTasks, statusFilter, query])

  const inProgress = clientTasks.filter(t => t.status === "in_progress").length
  const blocked = clientTasks.filter(t => t.status === "blocked").length
  const overdue = clientTasks.filter(t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== "done").length
  const completed = clientTasks.filter(t => t.status === "done").length

  return (
    <DashboardShell
      title="Client Tasks"
      description="All tasks across billable client engagements."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Download className="w-4 h-4" /> Export
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New task
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Tasks" value={clientTasks.length} hint="across client projects" icon={ListChecks} />
        <StatCard label="In Progress" value={inProgress} hint="active work" icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Overdue" value={overdue} hint="past due date" icon={AlertTriangle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Completed" value={completed} hint="all-time" icon={CheckSquare} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar">
            {statusFilters.map(s => (
              <button
                key={s.key}
                onClick={() => setStatusFilter(s.key)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap",
                  statusFilter === s.key
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
          <div className="relative md:ml-auto md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search tasks, clients, assignees..."
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>
      </Card>

      {/* Table */}
      <Card className="p-0 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState compact icon={CheckSquare} title="No tasks found" description="Try adjusting your filters." />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Task</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Client</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Project</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Assignee</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Priority</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Due</TableHead>
                  <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground text-right">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(t => {
                  const isOverdue = t.dueDate && new Date(t.dueDate) < new Date() && t.status !== "done"
                  return (
                    <TableRow key={t.id} className="hover:bg-secondary/30 transition-colors">
                      <TableCell className="py-2.5">
                        <Link href={`/tasks/${t.id}`} className="block max-w-[260px]">
                          <p className="text-xs font-medium text-foreground hover:text-primary transition-colors line-clamp-1">{t.title}</p>
                          <p className="text-[10px] font-mono text-muted-foreground">{t.key}</p>
                        </Link>
                      </TableCell>
                      <TableCell className="py-2.5">
                        {t.client ? (
                          <Link href={`/clients/${t.client.id}`} className="flex items-center gap-2 group">
                            <Avatar className="w-5 h-5 rounded">
                              <AvatarImage src={t.client.logo} alt={t.client.name} />
                              <AvatarFallback className="text-[8px] rounded">{t.client.name.slice(0, 2)}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-foreground group-hover:text-primary transition-colors">{t.client.name}</span>
                          </Link>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="py-2.5">
                        <div className="flex items-center gap-1.5">
                          <span className={cn("w-1.5 h-1.5 rounded-full", t.projectColor)} />
                          <span className="text-xs text-muted-foreground truncate max-w-[140px]">{t.projectName}</span>
                        </div>
                      </TableCell>
                      <TableCell className="py-2.5">
                        {t.assignee ? (
                          <div className="flex items-center gap-1.5">
                            <Avatar className="w-5 h-5">
                              <AvatarImage src={t.assigneeAvatar} alt={t.assignee} />
                              <AvatarFallback className="text-[9px]">{t.assignee[0]}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-foreground">{t.assignee.split(" ")[0]}</span>
                          </div>
                        ) : <span className="text-xs text-muted-foreground">Unassigned</span>}
                      </TableCell>
                      <TableCell className="py-2.5"><PriorityBadge priority={t.priority} /></TableCell>
                      <TableCell className="py-2.5">
                        <span className={cn(
                          "text-xs",
                          isOverdue ? "text-rose-600 dark:text-rose-400 font-semibold" : "text-muted-foreground"
                        )}>
                          {t.dueDate ? relativeDay(t.dueDate) : "—"}
                        </span>
                      </TableCell>
                      <TableCell className="py-2.5 text-right">
                        <TaskStatusBadge status={t.status} />
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </DashboardShell>
  )
}
