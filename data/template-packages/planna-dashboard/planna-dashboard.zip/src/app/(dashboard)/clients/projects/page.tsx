"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import {
  Briefcase, Plus, Search, DollarSign, Clock, Users,
  Filter, CheckCircle2, AlertTriangle,
} from "lucide-react"
import { projects, clients } from "@/lib/data/mock"
import { ProjectStatusBadge, HealthBadge } from "@/components/common/badges"
import { cn, formatCurrency, relativeDay, pct, formatDate } from "@/lib/utils"

export default function ClientProjectsPage() {
  const [clientFilter, setClientFilter] = useState<string>("all")
  const [query, setQuery] = useState("")

  const clientProjects = useMemo(() => projects.filter(p => p.client), [])
  const clientsWithProjects = useMemo(() => {
    const ids = new Set(clientProjects.map(p => clients.find(c => c.name === p.client)?.id).filter(Boolean))
    return clients.filter(c => ids.has(c.id))
  }, [clientProjects])

  const filtered = useMemo(() => {
    return clientProjects.filter(p => {
      const matchClient = clientFilter === "all" || p.client === clients.find(c => c.id === clientFilter)?.name
      const q = query.trim().toLowerCase()
      const matchQuery = !q || p.name.toLowerCase().includes(q) || (p.client ?? "").toLowerCase().includes(q) || p.lead.toLowerCase().includes(q)
      return matchClient && matchQuery
    })
  }, [clientFilter, query, clientProjects])

  const totalBudget = clientProjects.reduce((s, p) => s + p.budget, 0)
  const totalSpent = clientProjects.reduce((s, p) => s + p.spent, 0)
  const avgProgress = clientProjects.length ? Math.round(clientProjects.reduce((s, p) => s + p.progress, 0) / clientProjects.length) : 0

  return (
    <DashboardShell
      title="Client Projects"
      description="All billable engagements across your clients."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New project
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Client Projects" value={clientProjects.length} hint="billable engagements" icon={Briefcase} />
        <StatCard label="Total Budget" value={formatCurrency(totalBudget)} hint="contracted value" icon={DollarSign} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Spent" value={formatCurrency(totalSpent)} hint={`${pct(totalSpent, totalBudget)}% of budget`} icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Progress" value={`${avgProgress}%`} hint="across engagements" icon={Users} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar">
            <button
              onClick={() => setClientFilter("all")}
              className={cn(
                "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap",
                clientFilter === "all" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              All clients
            </button>
            {clientsWithProjects.map(c => (
              <button
                key={c.id}
                onClick={() => setClientFilter(c.id)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5",
                  clientFilter === c.id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Avatar className="w-4 h-4 rounded">
                  <AvatarImage src={c.logo} alt={c.name} />
                  <AvatarFallback className="text-[8px] rounded">{c.name.slice(0, 2)}</AvatarFallback>
                </Avatar>
                {c.name}
              </button>
            ))}
          </div>
          <div className="relative md:ml-auto md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search projects, leads..."
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>
      </Card>

      {/* Grid */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Briefcase}
          title="No projects found"
          description="Try a different client filter or search."
          action={{ label: "New project" }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {filtered.map((p, i) => {
            const client = clients.find(c => c.name === p.client)
            const budgetUsed = pct(p.spent, p.budget)
            const overBudget = p.spent > p.budget * 0.9
            return (
              <Card key={p.id} className="p-5 card-lift group animate-slide-in-up" style={{ animationDelay: `${i * 40}ms` }}>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <Link href={`/projects/${p.id}`} className="flex items-center gap-3 min-w-0 flex-1">
                    <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0", p.color)}>
                      <Briefcase className="w-4 h-4 text-white" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-foreground truncate group-hover:text-primary transition-colors">{p.name}</p>
                      <p className="text-[10px] font-mono text-muted-foreground">{p.key}</p>
                    </div>
                  </Link>
                  <ProjectStatusBadge status={p.status} />
                </div>

                {/* Client row */}
                {client && (
                  <Link href={`/clients/${client.id}`} className="flex items-center gap-2 p-2 rounded-lg bg-secondary/40 hover:bg-secondary/60 transition-colors mb-3">
                    <Avatar className="w-5 h-5 rounded">
                      <AvatarImage src={client.logo} alt={client.name} />
                      <AvatarFallback className="text-[8px] rounded">{client.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs font-medium text-foreground truncate">{client.name}</span>
                    <span className="text-[10px] text-muted-foreground ml-auto">{client.industry}</span>
                  </Link>
                )}

                <div className="space-y-2 mb-3">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-semibold text-foreground">{p.progress}%</span>
                  </div>
                  <Progress value={p.progress} className="h-1.5" />
                  <div className="flex items-center justify-between">
                    <HealthBadge health={p.health} />
                    <span className="text-[10px] text-muted-foreground">{p.tasksDone}/{p.tasksTotal} tasks</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="p-2 rounded-md bg-secondary/40">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Budget</p>
                    <p className="text-sm font-semibold text-foreground">{formatCurrency(p.spent)}</p>
                    <p className="text-[10px] text-muted-foreground">of {formatCurrency(p.budget)}</p>
                  </div>
                  <div className="p-2 rounded-md bg-secondary/40">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Deadline</p>
                    <p className="text-sm font-semibold text-foreground">{relativeDay(p.dueDate)}</p>
                    <p className="text-[10px] text-muted-foreground">{formatDate(p.dueDate, { month: "short", day: "numeric" })}</p>
                  </div>
                </div>

                {overBudget && (
                  <div className="flex items-center gap-1.5 px-2 py-1.5 rounded-md bg-amber-500/10 border border-amber-500/20 mb-3">
                    <AlertTriangle className="w-3 h-3 text-amber-600 dark:text-amber-400 shrink-0" />
                    <span className="text-[10px] text-amber-700 dark:text-amber-300">{budgetUsed}% budget used</span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-5 h-5">
                      <AvatarImage src={p.leadAvatar} alt={p.lead} />
                      <AvatarFallback className="text-[9px]">{p.lead[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-[11px] text-foreground">{p.lead.split(" ")[0]}</span>
                  </div>
                  <span className="text-[10px] text-muted-foreground inline-flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    {p.members.length} members
                  </span>
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </DashboardShell>
  )
}
