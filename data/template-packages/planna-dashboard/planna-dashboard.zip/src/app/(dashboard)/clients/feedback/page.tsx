"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ChartCard, PlannaDonutChart } from "@/components/charts"
import {
  MessageSquareHeart, Star, Smile, Meh, Frown, Search, Plus,
  TrendingUp, Users, ThumbsUp, Filter, Quote,
} from "lucide-react"
import { clients } from "@/lib/data/mock"
import { cn, formatDate } from "@/lib/utils"

type Sentiment = "positive" | "neutral" | "negative"

interface Feedback {
  id: string
  clientId: string
  score: number // 0-10 NPS
  comment: string
  date: string
  sentiment: Sentiment
  respondent: string
  respondentAvatar: string
  project?: string
}

const feedback: Feedback[] = [
  { id: "fb1", clientId: "c1", score: 9, comment: "The team consistently delivers ahead of schedule. The new onboarding portal has transformed how our customers experience the product.", date: "2026-01-10", sentiment: "positive", respondent: "Marie Lopez", respondentAvatar: clients[0].contactAvatar, project: "Acme Client Project" },
  { id: "fb2", clientId: "c2", score: 10, comment: "Outstanding work on the cloud migration. Zero downtime during cutover and the documentation is excellent. Couldn't ask for more.", date: "2026-01-08", sentiment: "positive", respondent: "James Wright", respondentAvatar: clients[1].contactAvatar, project: "Nimbus Migration" },
  { id: "fb3", clientId: "c3", score: 7, comment: "Design quality is great, but we'd like to see faster turnaround on revision cycles. Otherwise happy with the partnership.", date: "2026-01-05", sentiment: "neutral", respondent: "Sara Jiménez", respondentAvatar: clients[2].contactAvatar, project: "Lumen Rebrand" },
  { id: "fb4", clientId: "c6", score: 9, comment: "The portal build was on time and on budget. The team's responsiveness to feedback was particularly impressive.", date: "2026-01-03", sentiment: "positive", respondent: "David Park", respondentAvatar: clients[5].contactAvatar, project: "Vertex Portal" },
  { id: "fb5", clientId: "c1", score: 6, comment: "Initial scope was unclear, which caused some rework. The team recovered well, but earlier alignment would help.", date: "2025-12-20", sentiment: "neutral", respondent: "Marie Lopez", respondentAvatar: clients[0].contactAvatar, project: "Acme Onboarding" },
  { id: "fb6", clientId: "c3", score: 4, comment: "The last milestone delivery was delayed without prior notice. We need better communication on timeline risks going forward.", date: "2025-12-15", sentiment: "negative", respondent: "Sara Jiménez", respondentAvatar: clients[2].contactAvatar, project: "Lumen Rebrand" },
  { id: "fb7", clientId: "c2", score: 8, comment: "Solid engineering work. Would appreciate more proactive suggestions on architecture trade-offs in future engagements.", date: "2025-12-10", sentiment: "positive", respondent: "James Wright", respondentAvatar: clients[1].contactAvatar, project: "Nimbus Migration" },
  { id: "fb8", clientId: "c6", score: 10, comment: "Best vendor partnership we've had. The team feels like an extension of our own. Highly recommend.", date: "2025-11-28", sentiment: "positive", respondent: "David Park", respondentAvatar: clients[5].contactAvatar, project: "Vertex Portal" },
  { id: "fb9", clientId: "c1", score: 8, comment: "Great collaboration overall. Mobile app delivered as promised with a few minor polish items outstanding.", date: "2025-11-15", sentiment: "positive", respondent: "Marie Lopez", respondentAvatar: clients[0].contactAvatar, project: "Acme Mobile" },
]

const sentimentConfig: Record<Sentiment, { label: string; icon: any; color: string; bg: string }> = {
  positive: { label: "Positive", icon: Smile, color: "text-emerald-600 dark:text-emerald-400",  bg: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  neutral:  { label: "Neutral",  icon: Meh,    color: "text-amber-600 dark:text-amber-400",      bg: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  negative: { label: "Negative", icon: Frown,  color: "text-rose-600 dark:text-rose-400",        bg: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
}

const sentimentTabs: { key: Sentiment | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "positive", label: "Positive" },
  { key: "neutral", label: "Neutral" },
  { key: "negative", label: "Negative" },
]

function npsCategory(score: number): "promoter" | "passive" | "detractor" {
  if (score >= 9) return "promoter"
  if (score >= 7) return "passive"
  return "detractor"
}

function npsColor(score: number): string {
  if (score >= 9) return "text-emerald-600 dark:text-emerald-400"
  if (score >= 7) return "text-amber-600 dark:text-amber-400"
  return "text-rose-600 dark:text-rose-400"
}

export default function FeedbackPage() {
  const [sentimentFilter, setSentimentFilter] = useState<Sentiment | "all">("all")
  const [query, setQuery] = useState("")

  const filtered = useMemo(() => {
    return feedback.filter(f => {
      const matchSentiment = sentimentFilter === "all" || f.sentiment === sentimentFilter
      const client = clients.find(c => c.id === f.clientId)
      const q = query.trim().toLowerCase()
      const matchQuery = !q ||
        f.comment.toLowerCase().includes(q) ||
        (client?.name ?? "").toLowerCase().includes(q) ||
        f.respondent.toLowerCase().includes(q) ||
        (f.project ?? "").toLowerCase().includes(q)
      return matchSentiment && matchQuery
    })
  }, [sentimentFilter, query])

  // NPS calculation: % promoters - % detractors
  const promoters = feedback.filter(f => npsCategory(f.score) === "promoter").length
  const passives = feedback.filter(f => npsCategory(f.score) === "passive").length
  const detractors = feedback.filter(f => npsCategory(f.score) === "detractor").length
  const total = feedback.length
  const nps = total > 0 ? Math.round(((promoters - detractors) / total) * 100) : 0
  const avgScore = total > 0 ? (feedback.reduce((s, f) => s + f.score, 0) / total).toFixed(1) : "0"
  const responseRate = 72 // simulated

  const sentimentDistribution = [
    { name: "Positive", value: feedback.filter(f => f.sentiment === "positive").length, color: "var(--chart-1)" },
    { name: "Neutral",  value: feedback.filter(f => f.sentiment === "neutral").length,  color: "var(--chart-3)" },
    { name: "Negative", value: feedback.filter(f => f.sentiment === "negative").length, color: "var(--chart-5)" },
  ].filter(d => d.value > 0)

  return (
    <DashboardShell
      title="Client Feedback"
      description="NPS scores and qualitative feedback collected from your clients."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Export
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> Send survey
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="NPS Score" value={nps > 0 ? `+${nps}` : String(nps)} hint={`${promoters}P · ${passives}A · ${detractors}D`} icon={TrendingUp} trend={{ value: 8, positive: true }} />
        <StatCard label="Avg Score" value={`${avgScore}/10`} hint="across all responses" icon={Star} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Response Rate" value={`${responseRate}%`} hint="of surveys sent" icon={Users} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Positive" value={`${Math.round((sentimentDistribution[0]?.value ?? 0) / total * 100)}%`} hint="of all responses" icon={ThumbsUp} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Sentiment distribution */}
        <ChartCard title="Sentiment Distribution" subtitle="Across all feedback" fullscreen={false}>
          <PlannaDonutChart
            data={sentimentDistribution}
            height={240}
            centerValue={`${total}`}
            centerLabel="responses"
          />
        </ChartCard>

        {/* NPS breakdown */}
        <Card className="p-4 md:p-5 lg:col-span-2 card-lift">
          <h3 className="text-sm font-semibold mb-4">NPS Breakdown</h3>
          <div className="grid grid-cols-3 gap-3 mb-4">
            <NpsBucket label="Promoters" count={promoters} total={total} color="bg-emerald-500" range="9-10" />
            <NpsBucket label="Passives"  count={passives}  total={total} color="bg-amber-500"   range="7-8" />
            <NpsBucket label="Detractors" count={detractors} total={total} color="bg-rose-500"  range="0-6" />
          </div>
          <div className="p-4 rounded-lg bg-secondary/40 border border-border">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-muted-foreground">Net Promoter Score</p>
              <Badge className={cn(
                "text-[10px]",
                nps >= 50 ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" :
                nps >= 20 ? "bg-amber-500/15 text-amber-600 dark:text-amber-400" :
                "bg-rose-500/15 text-rose-600 dark:text-rose-400"
              )}>
                {nps >= 50 ? "Excellent" : nps >= 20 ? "Good" : "Needs work"}
              </Badge>
            </div>
            <p className={cn("text-3xl font-bold", nps >= 50 ? "text-emerald-600 dark:text-emerald-400" : nps >= 20 ? "text-amber-600 dark:text-amber-400" : "text-rose-600 dark:text-rose-400")}>
              {nps > 0 ? `+${nps}` : nps}
            </p>
            <p className="text-[11px] text-muted-foreground mt-1">
              Calculated as % Promoters − % Detractors
            </p>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary overflow-x-auto no-scrollbar">
            {sentimentTabs.map(t => (
              <button
                key={t.key}
                onClick={() => setSentimentFilter(t.key)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap",
                  sentimentFilter === t.key
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
          <div className="relative md:ml-auto md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search feedback, clients..."
              className="pl-9 h-9 text-sm"
            />
          </div>
        </div>
      </Card>

      {/* Feedback cards */}
      {filtered.length === 0 ? (
        <EmptyState icon={MessageSquareHeart} title="No feedback found" description="Try a different sentiment filter or search." action={{ label: "Send survey" }} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {filtered.map((f, i) => {
            const client = clients.find(c => c.id === f.clientId)
            const sentiment = sentimentConfig[f.sentiment]
            const SentimentIcon = sentiment.icon
            return (
              <Card key={f.id} className="p-5 card-lift group animate-slide-in-up flex flex-col" style={{ animationDelay: `${i * 40}ms` }}>
                {/* Top row: client + sentiment */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  {client && (
                    <Link href={`/clients/${client.id}`} className="flex items-center gap-2 min-w-0">
                      <Avatar className="w-7 h-7 rounded">
                        <AvatarImage src={client.logo} alt={client.name} />
                        <AvatarFallback className="text-[9px] rounded">{client.name.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors truncate">{client.name}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{f.respondent}</p>
                      </div>
                    </Link>
                  )}
                  <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full", sentiment.bg)}>
                    <SentimentIcon className="w-3 h-3" /> {sentiment.label}
                  </span>
                </div>

                {/* Score */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: 10 }).map((_, idx) => (
                      <span
                        key={idx}
                        className={cn(
                          "w-1.5 rounded-sm transition-all",
                          idx < f.score
                            ? f.score >= 9 ? "bg-emerald-500 h-3"
                            : f.score >= 7 ? "bg-amber-500 h-3"
                            : "bg-rose-500 h-3"
                            : "bg-muted h-2.5"
                        )}
                      />
                    ))}
                  </div>
                  <span className={cn("text-lg font-bold ml-auto", npsColor(f.score))}>{f.score}</span>
                  <span className="text-[10px] text-muted-foreground">/10</span>
                </div>

                {/* Quote */}
                <div className="flex-1 mb-3">
                  <Quote className="w-4 h-4 text-primary/40 mb-1.5" />
                  <p className="text-xs text-foreground leading-relaxed line-clamp-4">{f.comment}</p>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-3 border-t border-border text-[10px] text-muted-foreground">
                  <span>{f.project ?? "General"}</span>
                  <span>{formatDate(f.date, { month: "short", day: "numeric", year: "numeric" })}</span>
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </DashboardShell>
  )
}

function NpsBucket({ label, count, total, color, range }: { label: string; count: number; total: number; color: string; range: string }) {
  const pctVal = total > 0 ? Math.round((count / total) * 100) : 0
  return (
    <div className="p-3 rounded-lg bg-secondary/40">
      <div className="flex items-center gap-1.5 mb-1">
        <span className={cn("w-2 h-2 rounded-full", color)} />
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      </div>
      <p className="text-xl font-bold text-foreground">{count}</p>
      <p className="text-[10px] text-muted-foreground">{pctVal}% · score {range}</p>
    </div>
  )
}
