// ============================================================
// PLANNA — Core domain types
// ============================================================

export type ID = string

export type Priority = "low" | "medium" | "high" | "urgent"
export type TaskStatus = "backlog" | "todo" | "in_progress" | "review" | "done" | "blocked"
export type ProjectStatus = "planning" | "active" | "on_hold" | "completed" | "archived"
export type SprintStatus = "planning" | "active" | "completed" | "cancelled"
export type Role = "owner" | "admin" | "manager" | "member" | "viewer" | "guest"
export type InvoiceStatus = "draft" | "sent" | "paid" | "overdue" | "cancelled"
export type TimeEntryType = "billable" | "non_billable"
export type EventCategory = "meeting" | "deadline" | "reminder" | "focus" | "personal" | "external"

export interface TeamMember {
  id: ID
  name: string
  email: string
  role: Role
  avatar: string
  title: string
  department: string
  location: string
  timezone: string
  online: boolean
  capacity: number // hours/week
  utilized: number // hours/week
  completedTasks: number
  activeTasks: number
  joinedAt: string
}

export interface Label {
  id: ID
  name: string
  color: string
}

export interface Project {
  id: ID
  key: string
  name: string
  description: string
  status: ProjectStatus
  progress: number
  health: "on_track" | "at_risk" | "off_track"
  lead: string
  leadAvatar: string
  members: string[]
  startDate: string
  dueDate: string
  tasksTotal: number
  tasksDone: number
  budget: number
  spent: number
  color: string
  icon: string
  tags: string[]
  client?: string
  starred: boolean
}

export interface Subtask {
  id: ID
  title: string
  done: boolean
  assignee?: string
}

export interface Comment {
  id: ID
  author: string
  avatar: string
  body: string
  createdAt: string
}

export interface Task {
  id: ID
  key: string
  title: string
  description: string
  status: TaskStatus
  priority: Priority
  projectId: string
  projectName: string
  projectColor: string
  assignee?: string
  assigneeAvatar?: string
  reporter: string
  reporterAvatar: string
  labels: Label[]
  dueDate?: string
  startDate?: string
  estimateHours?: number
  loggedHours?: number
  subtasks: Subtask[]
  comments: Comment[]
  attachments: number
  recurring?: "none" | "daily" | "weekly" | "monthly"
  createdAt: string
  updatedAt: string
  starred: boolean
  blockedBy?: string[]
}

export interface Column {
  id: ID
  title: string
  color: string
  taskIds: ID[]
}

export interface Sprint {
  id: ID
  name: string
  goal: string
  status: SprintStatus
  startDate: string
  endDate: string
  storyPointsCommitted: number
  storyPointsCompleted: number
  tasksTotal: number
  tasksDone: number
}

export interface CalendarEvent {
  id: ID
  title: string
  description?: string
  category: EventCategory
  start: string
  end: string
  allDay?: boolean
  attendees: string[]
  location?: string
  projectId?: string
  color: string
}

export interface TimeEntry {
  id: ID
  taskId?: string
  taskKey?: string
  taskTitle?: string
  projectId: string
  projectName: string
  memberId: string
  memberName: string
  memberAvatar: string
  description: string
  start: string
  end: string
  duration: number // seconds
  billable: boolean
  status: "running" | "submitted" | "approved" | "rejected"
}

export interface Notification {
  id: ID
  type: "task" | "project" | "mention" | "comment" | "deadline" | "invite" | "system"
  title: string
  body: string
  createdAt: string
  read: boolean
  actor?: {
    name: string
    avatar: string
  }
  href?: string
}

export interface Client {
  id: ID
  name: string
  company: string
  email: string
  phone: string
  logo: string
  industry: string
  status: "active" | "lead" | "churned" | "prospect"
  projectsCount: number
  totalRevenue: number
  outstanding: number
  contactName: string
  contactAvatar: string
  startDate: string
  location: string
}

export interface Invoice {
  id: ID
  number: string
  clientId: string
  clientName: string
  clientLogo: string
  amount: number
  tax: number
  total: number
  status: InvoiceStatus
  issueDate: string
  dueDate: string
  paidDate?: string
  project?: string
}

export interface FileItem {
  id: ID
  name: string
  type: "image" | "document" | "spreadsheet" | "presentation" | "pdf" | "video" | "audio" | "archive" | "code"
  size: number
  mimeType: string
  owner: string
  ownerAvatar: string
  project?: string
  modifiedAt: string
  shared: boolean
  starred: boolean
  url: string
}

export interface Note {
  id: ID
  title: string
  body: string
  tags: string[]
  author: string
  authorAvatar: string
  updatedAt: string
  pinned: boolean
  shared: boolean
  color: string
}

export interface ApiKey {
  id: ID
  name: string
  prefix: string
  created: string
  lastUsed?: string
  scopes: string[]
  revoked: boolean
}

export interface Webhook {
  id: ID
  url: string
  events: string[]
  active: boolean
  createdAt: string
  lastFired?: string
}

export interface Integration {
  id: ID
  name: string
  description: string
  icon: string
  category: string
  connected: boolean
  installedAt?: string
}

export interface AuditLog {
  id: ID
  actor: string
  actorAvatar: string
  action: string
  target: string
  ip: string
  createdAt: string
  metadata?: Record<string, string>
}

export interface Activity {
  id: ID
  actor: string
  actorAvatar: string
  action: string
  target: string
  createdAt: string
  type: "task" | "project" | "comment" | "file" | "team"
}

export interface Milestone {
  id: ID
  title: string
  description: string
  dueDate: string
  status: "planned" | "in_progress" | "done" | "overdue"
  progress: number
  projectId: string
  projectName: string
}

export interface Goal {
  id: ID
  title: string
  description: string
  owner: string
  ownerAvatar: string
  dueDate: string
  progress: number
  status: "on_track" | "at_risk" | "behind" | "done"
  keyResults: { id: ID; title: string; progress: number }[]
}

export interface Announcement {
  id: ID
  title: string
  body: string
  author: string
  authorAvatar: string
  createdAt: string
  pinned: boolean
  audience: string
  read: boolean
}

export interface ChatThread {
  id: ID
  name: string
  avatar?: string
  isGroup: boolean
  lastMessage: string
  lastMessageAt: string
  unread: number
  participants: { name: string; avatar: string }[]
}
