"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

interface TimerState {
  running: boolean
  startedAt: number | null
  elapsedBase: number // seconds accumulated before current run
  taskId: string | null
  projectName: string
  billable: boolean
  start: (taskId?: string, projectName?: string) => void
  pause: () => void
  reset: () => void
  toggleBillable: () => void
  tick: () => void
}

export const useTimerStore = create<TimerState>()(
  persist(
    (set, get) => ({
      running: false,
      startedAt: null,
      elapsedBase: 0,
      taskId: null,
      projectName: "Planna Web App",
      billable: true,
      start: (taskId, projectName) =>
        set(s => ({
          running: true,
          startedAt: Date.now(),
          taskId: taskId ?? s.taskId,
          projectName: projectName ?? s.projectName,
        })),
      pause: () => {
        const s = get()
        if (s.startedAt) {
          const delta = Math.floor((Date.now() - s.startedAt) / 1000)
          set({ running: false, startedAt: null, elapsedBase: s.elapsedBase + delta })
        } else {
          set({ running: false, startedAt: null })
        }
      },
      reset: () => set({ running: false, startedAt: null, elapsedBase: 0, taskId: null }),
      toggleBillable: () => set(s => ({ billable: !s.billable })),
      tick: () => set({}), // force re-render
    }),
    {
      name: "planna-timer",
      // Skip auto-hydration to prevent SSR/client mismatch.
      // Timer is only used on client pages and rehydrates on first interaction.
      skipHydration: true,
    }
  )
)

export const formatTimer = (seconds: number) => {
  const h = Math.floor(seconds / 3600).toString().padStart(2, "0")
  const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, "0")
  const s = Math.floor(seconds % 60).toString().padStart(2, "0")
  return `${h}:${m}:${s}`
}

export const getElapsed = () => {
  const s = useTimerStore.getState()
  if (s.running && s.startedAt) {
    return s.elapsedBase + Math.floor((Date.now() - s.startedAt) / 1000)
  }
  return s.elapsedBase
}
