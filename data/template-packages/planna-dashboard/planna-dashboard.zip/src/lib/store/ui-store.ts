"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

interface UiState {
  sidebarCollapsed: boolean
  sidebarMobileOpen: boolean
  commandPaletteOpen: boolean
  recentPages: { href: string; title: string }[]
  favorites: string[]
  toggleSidebar: () => void
  setSidebarCollapsed: (v: boolean) => void
  setSidebarMobileOpen: (v: boolean) => void
  openCommandPalette: () => void
  closeCommandPalette: () => void
  pushRecentPage: (page: { href: string; title: string }) => void
  toggleFavorite: (href: string) => void
}

export const useUiStore = create<UiState>()(
  persist(
    (set, get) => ({
      sidebarCollapsed: false,
      sidebarMobileOpen: false,
      commandPaletteOpen: false,
      recentPages: [],
      favorites: [],
      toggleSidebar: () => set(s => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
      setSidebarMobileOpen: (v) => set({ sidebarMobileOpen: v }),
      openCommandPalette: () => set({ commandPaletteOpen: true }),
      closeCommandPalette: () => set({ commandPaletteOpen: false }),
      pushRecentPage: (page) => {
        const existing = get().recentPages.filter(p => p.href !== page.href)
        set({ recentPages: [page, ...existing].slice(0, 8) })
      },
      toggleFavorite: (href) => {
        const favs = get().favorites
        set({
          favorites: favs.includes(href) ? favs.filter(f => f !== href) : [...favs, href],
        })
      },
    }),
    {
      name: "planna-ui",
      // Skip automatic hydration to prevent SSR/client mismatch.
      // The store hydrates manually after mount via UiStoreHydration component.
      skipHydration: true,
    }
  )
)
