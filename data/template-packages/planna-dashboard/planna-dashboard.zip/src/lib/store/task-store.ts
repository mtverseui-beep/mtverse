"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { Task, Column } from "@/types"
import { tasks as seedTasks, initialColumns } from "@/lib/data/mock"

interface TaskState {
  tasks: Task[]
  columns: Column[]
  toggleTaskStar: (id: string) => void
  toggleSubtask: (taskId: string, subtaskId: string) => void
  setTaskStatus: (taskId: string, status: Task["status"]) => void
  moveTaskToColumn: (taskId: string, fromColId: string, toColId: string, toIndex?: number) => void
  addTask: (task: Partial<Task> & { title: string }) => void
}

export const useTaskStore = create<TaskState>()(
  persist(
    (set, get) => ({
      tasks: seedTasks,
      columns: initialColumns,
      toggleTaskStar: (id) =>
        set(s => ({
          tasks: s.tasks.map(t => (t.id === id ? { ...t, starred: !t.starred } : t)),
        })),
      toggleSubtask: (taskId, subtaskId) =>
        set(s => ({
          tasks: s.tasks.map(t =>
            t.id === taskId
              ? { ...t, subtasks: t.subtasks.map(st => (st.id === subtaskId ? { ...st, done: !st.done } : st)) }
              : t
          ),
        })),
      setTaskStatus: (taskId, status) =>
        set(s => ({
          tasks: s.tasks.map(t => (t.id === taskId ? { ...t, status } : t)),
        })),
      moveTaskToColumn: (taskId, fromColId, toColId, toIndex) =>
        set(s => {
          const columns = s.columns.map(c => ({ ...c, taskIds: [...c.taskIds] }))
          const from = columns.find(c => c.id === fromColId)
          const to = columns.find(c => c.id === toColId)
          if (!from || !to) return s
          const idx = from.taskIds.indexOf(taskId)
          if (idx >= 0) from.taskIds.splice(idx, 1)
          const targetIdx = toIndex ?? to.taskIds.length
          to.taskIds.splice(targetIdx, 0, taskId)
          // also update task status based on column
          const statusMap: Record<string, Task["status"]> = {
            "col-backlog": "backlog",
            "col-todo": "todo",
            "col-progress": "in_progress",
            "col-review": "review",
            "col-done": "done",
          }
          const newStatus = statusMap[toColId] ?? "todo"
          const tasks = s.tasks.map(t => (t.id === taskId ? { ...t, status: newStatus } : t))
          return { columns, tasks }
        }),
      addTask: (partial) =>
        set(s => {
          const id = `t${Date.now()}`
          const newTask: Task = {
            id,
            key: `PLN-${100 + s.tasks.length + 1}`,
            title: partial.title,
            description: partial.description ?? "",
            status: partial.status ?? "todo",
            priority: partial.priority ?? "medium",
            projectId: partial.projectId ?? "p1",
            projectName: partial.projectName ?? "Planna Web App",
            projectColor: partial.projectColor ?? "bg-emerald-500",
            assignee: partial.assignee,
            assigneeAvatar: partial.assigneeAvatar,
            reporter: "Jessin Sam",
            reporterAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop",
            labels: partial.labels ?? [],
            dueDate: partial.dueDate,
            startDate: new Date().toISOString().slice(0, 10),
            estimateHours: partial.estimateHours,
            loggedHours: 0,
            subtasks: [],
            comments: [],
            attachments: 0,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            starred: false,
          }
          // Add to "todo" column
          const columns = s.columns.map(c =>
            c.id === "col-todo" ? { ...c, taskIds: [id, ...c.taskIds] } : c
          )
          return { tasks: [newTask, ...s.tasks], columns }
        }),
    }),
    {
      name: "planna-tasks",
      // Skip auto-hydration to prevent SSR/client mismatch.
      skipHydration: true,
    }
  )
)
