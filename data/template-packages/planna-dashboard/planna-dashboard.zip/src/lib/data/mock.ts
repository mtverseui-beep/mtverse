import type {
  TeamMember, Project, Task, Sprint, CalendarEvent, TimeEntry,
  Notification, Client, Invoice, FileItem, Note, ApiKey, Webhook,
  Integration, AuditLog, Activity, Milestone, Goal, Announcement,
  ChatThread, Label, Column
} from "@/types"

// ============================================================
// TEAM MEMBERS — using Unsplash HD avatars
// ============================================================

export const members: TeamMember[] = [
  { id: "u1", name: "Jessin Sam", email: "jessin@planna.app", role: "owner", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop", title: "Founder & CEO", department: "Leadership", location: "San Francisco, US", timezone: "America/Los_Angeles", online: true, capacity: 40, utilized: 32, completedTasks: 412, activeTasks: 8, joinedAt: "2021-02-14" },
  { id: "u2", name: "Zara Marlowe", email: "zara@planna.app", role: "admin", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&h=128&fit=crop", title: "Head of Product", department: "Product", location: "London, UK", timezone: "Europe/London", online: true, capacity: 40, utilized: 38, completedTasks: 318, activeTasks: 12, joinedAt: "2021-04-08" },
  { id: "u3", name: "Theo Nakamura", email: "theo@planna.app", role: "manager", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=128&h=128&fit=crop", title: "Engineering Lead", department: "Engineering", location: "Tokyo, JP", timezone: "Asia/Tokyo", online: false, capacity: 40, utilized: 40, completedTasks: 287, activeTasks: 6, joinedAt: "2021-06-21" },
  { id: "u4", name: "Mira Patel", email: "mira@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=128&h=128&fit=crop", title: "Senior Designer", department: "Design", location: "Austin, US", timezone: "America/Chicago", online: true, capacity: 40, utilized: 28, completedTasks: 241, activeTasks: 9, joinedAt: "2021-09-12" },
  { id: "u5", name: "Felix Brandt", email: "felix@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=128&h=128&fit=crop", title: "Frontend Engineer", department: "Engineering", location: "Berlin, DE", timezone: "Europe/Berlin", online: true, capacity: 40, utilized: 34, completedTasks: 198, activeTasks: 11, joinedAt: "2022-01-04" },
  { id: "u6", name: "Amara Okafor", email: "amara@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=128&h=128&fit=crop", title: "Backend Engineer", department: "Engineering", location: "Lagos, NG", timezone: "Africa/Lagos", online: true, capacity: 40, utilized: 30, completedTasks: 167, activeTasks: 7, joinedAt: "2022-03-19" },
  { id: "u7", name: "Leon Cruz", email: "leon@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=128&h=128&fit=crop", title: "Mobile Engineer", department: "Engineering", location: "Madrid, ES", timezone: "Europe/Madrid", online: false, capacity: 40, utilized: 22, completedTasks: 134, activeTasks: 5, joinedAt: "2022-07-22" },
  { id: "u8", name: "Naomi Chen", email: "naomi@planna.app", role: "manager", avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=128&h=128&fit=crop", title: "QA Lead", department: "Quality", location: "Toronto, CA", timezone: "America/Toronto", online: true, capacity: 40, utilized: 36, completedTasks: 389, activeTasks: 14, joinedAt: "2021-11-30" },
  { id: "u9", name: "Hugo Lindqvist", email: "hugo@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=128&h=128&fit=crop", title: "DevOps Engineer", department: "Engineering", location: "Stockholm, SE", timezone: "Europe/Stockholm", online: false, capacity: 40, utilized: 24, completedTasks: 102, activeTasks: 3, joinedAt: "2022-09-05" },
  { id: "u10", name: "Isla Reyes", email: "isla@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=128&h=128&fit=crop", title: "Marketing Manager", department: "Marketing", location: "Manila, PH", timezone: "Asia/Manila", online: true, capacity: 40, utilized: 18, completedTasks: 89, activeTasks: 6, joinedAt: "2023-02-14" },
  { id: "u11", name: "Ravi Kapoor", email: "ravi@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?w=128&h=128&fit=crop", title: "Customer Success", department: "Support", location: "Mumbai, IN", timezone: "Asia/Kolkata", online: true, capacity: 40, utilized: 26, completedTasks: 156, activeTasks: 4, joinedAt: "2022-11-08" },
  { id: "u12", name: "Sofia Vargas", email: "sofia@planna.app", role: "member", avatar: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=128&h=128&fit=crop", title: "Content Designer", department: "Design", location: "Mexico City, MX", timezone: "America/Mexico_City", online: false, capacity: 40, utilized: 20, completedTasks: 73, activeTasks: 8, joinedAt: "2023-04-17" },
]

export const currentMember = members[0]

// ============================================================
// LABELS
// ============================================================

export const labels: Label[] = [
  { id: "l1", name: "Backend", color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  { id: "l2", name: "Frontend", color: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
  { id: "l3", name: "Design", color: "bg-lime-500/15 text-lime-600 dark:text-lime-400" },
  { id: "l4", name: "Bug", color: "bg-red-500/15 text-red-600 dark:text-red-400" },
  { id: "l5", name: "Research", color: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400" },
  { id: "l6", name: "Performance", color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  { id: "l7", name: "Documentation", color: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
  { id: "l8", name: "Security", color: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
  { id: "l9", name: "Marketing", color: "bg-pink-500/15 text-pink-600 dark:text-pink-400" },
  { id: "l10", name: "Mobile", color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
]

// ============================================================
// PROJECTS
// ============================================================

export const projects: Project[] = [
  { id: "p1", key: "PLN", name: "Planna Web App", description: "Core dashboard, tasks, projects, and team collaboration features.", status: "active", progress: 68, health: "on_track", lead: "Zara Marlowe", leadAvatar: members[1].avatar, members: ["u1","u2","u3","u4","u5"], startDate: "2024-09-01", dueDate: "2026-03-15", tasksTotal: 184, tasksDone: 124, budget: 280000, spent: 192000, color: "bg-emerald-500", icon: "LayoutDashboard", tags: ["product", "web"], starred: true },
  { id: "p2", key: "MOB", name: "Mobile Companion", description: "iOS and Android apps for on-the-go task management.", status: "active", progress: 42, health: "at_risk", lead: "Leon Cruz", leadAvatar: members[6].avatar, members: ["u3","u6","u7"], startDate: "2024-11-15", dueDate: "2026-05-30", tasksTotal: 96, tasksDone: 40, budget: 160000, spent: 88000, color: "bg-teal-500", icon: "Smartphone", tags: ["mobile", "ios", "android"], starred: true },
  { id: "p3", key: "API", name: "Public API Platform", description: "REST and webhook platform for third-party integrations.", status: "active", progress: 85, health: "on_track", lead: "Amara Okafor", leadAvatar: members[5].avatar, members: ["u3","u5","u6","u9"], startDate: "2024-06-01", dueDate: "2026-01-20", tasksTotal: 72, tasksDone: 61, budget: 120000, spent: 98000, color: "bg-lime-500", icon: "Code2", tags: ["api", "platform"], starred: false },
  { id: "p4", key: "DSGN", name: "Design System 2.0", description: "Refreshed component library, tokens, and accessibility pass.", status: "active", progress: 55, health: "on_track", lead: "Mira Patel", leadAvatar: members[3].avatar, members: ["u3","u4","u12"], startDate: "2024-10-10", dueDate: "2026-02-28", tasksTotal: 118, tasksDone: 65, budget: 90000, spent: 51000, color: "bg-green-500", icon: "Palette", tags: ["design", "ui"], starred: false },
  { id: "p5", key: "MKT", name: "Launch Campaign Q1", description: "Product hunt launch + content series for Q1 2026.", status: "planning", progress: 18, health: "on_track", lead: "Isla Reyes", leadAvatar: members[9].avatar, members: ["u10","u12"], startDate: "2025-12-01", dueDate: "2026-03-31", tasksTotal: 64, tasksDone: 12, budget: 75000, spent: 14000, color: "bg-cyan-500", icon: "Megaphone", tags: ["marketing", "launch"], starred: false },
  { id: "p6", key: "INF", name: "Infrastructure Migration", description: "Move from monolith to containerized microservices.", status: "on_hold", progress: 35, health: "off_track", lead: "Hugo Lindqvist", leadAvatar: members[8].avatar, members: ["u3","u6","u9"], startDate: "2024-08-01", dueDate: "2026-04-15", tasksTotal: 88, tasksDone: 31, budget: 200000, spent: 154000, color: "bg-sky-500", icon: "Server", tags: ["infra", "devops"], starred: false },
  { id: "p7", key: "QA", name: "Test Automation Suite", description: "End-to-end and visual regression test coverage.", status: "active", progress: 72, health: "on_track", lead: "Naomi Chen", leadAvatar: members[7].avatar, members: ["u7","u8"], startDate: "2024-09-15", dueDate: "2026-02-10", tasksTotal: 54, tasksDone: 39, budget: 60000, spent: 42000, color: "bg-emerald-600", icon: "ShieldCheck", tags: ["qa", "testing"], starred: false },
  { id: "p8", key: "DOC", name: "Documentation Portal", description: "Public docs, API reference, guides, and tutorials.", status: "active", progress: 60, health: "on_track", lead: "Sofia Vargas", leadAvatar: members[11].avatar, members: ["u4","u11","u12"], startDate: "2024-10-01", dueDate: "2026-01-31", tasksTotal: 82, tasksDone: 49, budget: 55000, spent: 32000, color: "bg-teal-600", icon: "BookOpen", tags: ["docs", "content"], starred: false },
  { id: "p9", key: "ARC", name: "Acme Client Project", description: "Custom onboarding portal for Acme Corp.", status: "active", progress: 48, health: "at_risk", lead: "Zara Marlowe", leadAvatar: members[1].avatar, members: ["u2","u4","u5","u10"], startDate: "2024-11-01", dueDate: "2026-04-30", tasksTotal: 110, tasksDone: 53, budget: 320000, spent: 178000, color: "bg-lime-600", icon: "Briefcase", tags: ["client", "agency"], starred: false, client: "Acme Corp" },
  { id: "p10", key: "ANL", name: "Analytics Overhaul", description: "New events pipeline + warehouse + dashboards.", status: "planning", progress: 12, health: "on_track", lead: "Theo Nakamura", leadAvatar: members[2].avatar, members: ["u3","u6","u9"], startDate: "2025-12-15", dueDate: "2026-06-30", tasksTotal: 70, tasksDone: 8, budget: 140000, spent: 18000, color: "bg-green-600", icon: "BarChart3", tags: ["analytics", "data"], starred: false },
  { id: "p11", key: "WEB", name: "Website Redesign", description: "Marketing site refresh with new brand and CMS.", status: "completed", progress: 100, health: "on_track", lead: "Mira Patel", leadAvatar: members[3].avatar, members: ["u4","u10","u12"], startDate: "2024-04-01", dueDate: "2024-09-30", tasksTotal: 96, tasksDone: 96, budget: 80000, spent: 76000, color: "bg-emerald-500", icon: "Globe", tags: ["marketing", "web"], starred: false },
  { id: "p12", key: "SEC", name: "Security Audit", description: "SOC2 readiness + pen test remediation.", status: "active", progress: 64, health: "on_track", lead: "Theo Nakamura", leadAvatar: members[2].avatar, members: ["u3","u6","u8","u9"], startDate: "2024-10-01", dueDate: "2026-03-01", tasksTotal: 58, tasksDone: 37, budget: 110000, spent: 71000, color: "bg-rose-500", icon: "Lock", tags: ["security", "compliance"], starred: false },
]

// ============================================================
// TASKS
// ============================================================

const today = new Date()
const daysFromNow = (n: number) => new Date(today.getTime() + n * 86400000).toISOString().slice(0, 10)
const daysAgo = (n: number) => new Date(today.getTime() - n * 86400000).toISOString().slice(0, 10)

export const tasks: Task[] = [
  { id: "t1", key: "PLN-101", title: "Implement command palette keyboard navigation", description: "Add arrow up/down, enter to select, escape to close, and recents-first ordering. Make sure focus trap works correctly inside the dialog.", status: "in_progress", priority: "high", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Felix Brandt", assigneeAvatar: members[4].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[1]], dueDate: daysFromNow(2), startDate: daysAgo(3), estimateHours: 8, loggedHours: 5, subtasks: [{ id: "s1", title: "Wire keyboard events", done: true }, { id: "s2", title: "Add recents tracking", done: true }, { id: "s3", title: "Test focus trap", done: false, assignee: "Felix Brandt" }], comments: [{ id: "c1", author: "Zara Marlowe", avatar: members[1].avatar, body: "Let's also add a 'recently viewed' section above search results.", createdAt: daysAgo(1) }], attachments: 2, createdAt: daysAgo(5), updatedAt: daysAgo(1), starred: true },
  { id: "t2", key: "PLN-102", title: "Dark mode color contrast audit", description: "Run all surfaces through WCAG AA contrast checker and adjust tokens.", status: "todo", priority: "medium", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Mira Patel", assigneeAvatar: members[3].avatar, reporter: "Jessin Sam", reporterAvatar: members[0].avatar, labels: [labels[2], labels[3]], dueDate: daysFromNow(5), startDate: daysFromNow(1), estimateHours: 6, loggedHours: 0, subtasks: [], comments: [], attachments: 1, createdAt: daysAgo(2), updatedAt: daysAgo(2), starred: false },
  { id: "t3", key: "PLN-103", title: "WebSocket reconnect logic for live presence", description: "Implement exponential backoff, max retries, and offline indicator.", status: "in_progress", priority: "urgent", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Amara Okafor", assigneeAvatar: members[5].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[0], labels[5]], dueDate: daysFromNow(1), startDate: daysAgo(4), estimateHours: 12, loggedHours: 9, subtasks: [{ id: "s4", title: "Backoff strategy", done: true }, { id: "s5", title: "Offline UI state", done: false }], comments: [], attachments: 0, createdAt: daysAgo(6), updatedAt: daysAgo(0), starred: true },
  { id: "t4", key: "MOB-201", title: "iOS push notification payload parsing", description: "Handle deep links and rich media in incoming notifications.", status: "review", priority: "high", projectId: "p2", projectName: "Mobile Companion", projectColor: "bg-teal-500", assignee: "Leon Cruz", assigneeAvatar: members[6].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[9]], dueDate: daysFromNow(3), startDate: daysAgo(7), estimateHours: 10, loggedHours: 11, subtasks: [], comments: [{ id: "c2", author: "Naomi Chen", avatar: members[7].avatar, body: "Tested on iOS 17 and 18 — looks good.", createdAt: daysAgo(1) }], attachments: 3, createdAt: daysAgo(10), updatedAt: daysAgo(1), starred: false },
  { id: "t5", key: "MOB-202", title: "Android widget for today's tasks", description: "Home screen widget showing top 3 tasks due today.", status: "backlog", priority: "low", projectId: "p2", projectName: "Mobile Companion", projectColor: "bg-teal-500", assignee: "Leon Cruz", assigneeAvatar: members[6].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[9], labels[1]], dueDate: daysFromNow(20), estimateHours: 16, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(3), updatedAt: daysAgo(3), starred: false },
  { id: "t6", key: "API-301", title: "Rate limiting middleware for public API", description: "Token bucket per API key, 1000 req/min default, configurable.", status: "done", priority: "high", projectId: "p3", projectName: "Public API Platform", projectColor: "bg-lime-500", assignee: "Amara Okafor", assigneeAvatar: members[5].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[0], labels[7]], dueDate: daysAgo(2), startDate: daysAgo(14), estimateHours: 8, loggedHours: 9, subtasks: [], comments: [], attachments: 1, createdAt: daysAgo(18), updatedAt: daysAgo(2), starred: false },
  { id: "t7", key: "API-302", title: "Webhook delivery retries with backoff", description: "Up to 5 retries, exponential backoff, dead-letter queue.", status: "in_progress", priority: "medium", projectId: "p3", projectName: "Public API Platform", projectColor: "bg-lime-500", assignee: "Hugo Lindqvist", assigneeAvatar: members[8].avatar, reporter: "Amara Okafor", reporterAvatar: members[5].avatar, labels: [labels[0], labels[5]], dueDate: daysFromNow(7), startDate: daysAgo(5), estimateHours: 14, loggedHours: 6, subtasks: [{ id: "s6", title: "Retry queue", done: true }, { id: "s7", title: "Dead-letter UI", done: false }], comments: [], attachments: 0, createdAt: daysAgo(8), updatedAt: daysAgo(0), starred: false },
  { id: "t8", key: "DSGN-401", title: "Refresh button component variants", description: "Add loading, icon-only, and destructive variants with new tokens.", status: "todo", priority: "medium", projectId: "p4", projectName: "Design System 2.0", projectColor: "bg-green-500", assignee: "Mira Patel", assigneeAvatar: members[3].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[2]], dueDate: daysFromNow(8), estimateHours: 5, loggedHours: 0, subtasks: [], comments: [], attachments: 4, createdAt: daysAgo(2), updatedAt: daysAgo(2), starred: false },
  { id: "t9", key: "DSGN-402", title: "Accessibility audit of color tokens", description: "Verify all text/bg combinations meet WCAG AA in light and dark.", status: "in_progress", priority: "high", projectId: "p4", projectName: "Design System 2.0", projectColor: "bg-green-500", assignee: "Sofia Vargas", assigneeAvatar: members[11].avatar, reporter: "Mira Patel", reporterAvatar: members[3].avatar, labels: [labels[2], labels[3]], dueDate: daysFromNow(4), startDate: daysAgo(2), estimateHours: 6, loggedHours: 2, subtasks: [], comments: [], attachments: 1, createdAt: daysAgo(4), updatedAt: daysAgo(1), starred: false },
  { id: "t10", key: "INF-501", title: "Migrate auth service to Kubernetes", description: "Containerize, add Helm chart, blue-green deployment.", status: "blocked", priority: "urgent", projectId: "p6", projectName: "Infrastructure Migration", projectColor: "bg-sky-500", assignee: "Hugo Lindqvist", assigneeAvatar: members[8].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[5], labels[7]], dueDate: daysAgo(1), startDate: daysAgo(20), estimateHours: 24, loggedHours: 18, subtasks: [], comments: [{ id: "c3", author: "Hugo Lindqvist", avatar: members[8].avatar, body: "Blocked on staging cluster quota increase.", createdAt: daysAgo(2) }], attachments: 2, createdAt: daysAgo(25), updatedAt: daysAgo(1), starred: true, blockedBy: ["INF-505"] },
  { id: "t11", key: "ARC-601", title: "Custom onboarding flow for Acme", description: "Brand the onboarding with Acme logo and custom steps.", status: "in_progress", priority: "high", projectId: "p9", projectName: "Acme Client Project", projectColor: "bg-lime-600", assignee: "Felix Brandt", assigneeAvatar: members[4].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[1]], dueDate: daysFromNow(10), startDate: daysAgo(5), estimateHours: 20, loggedHours: 8, subtasks: [{ id: "s8", title: "Brand assets", done: true }, { id: "s9", title: "Custom steps UI", done: false }, { id: "s10", title: "QA pass", done: false }], comments: [], attachments: 5, createdAt: daysAgo(7), updatedAt: daysAgo(0), starred: false },
  { id: "t12", key: "QA-701", title: "Visual regression for dashboard widgets", description: "Add Percy snapshots for all dashboard widget states.", status: "todo", priority: "medium", projectId: "p7", projectName: "Test Automation Suite", projectColor: "bg-emerald-600", assignee: "Naomi Chen", assigneeAvatar: members[7].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[3]], dueDate: daysFromNow(6), estimateHours: 8, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(3), updatedAt: daysAgo(3), starred: false },
  { id: "t13", key: "DOC-801", title: "API reference for tasks endpoint", description: "Document /api/v1/tasks with examples and curl snippets.", status: "in_progress", priority: "low", projectId: "p8", projectName: "Documentation Portal", projectColor: "bg-teal-600", assignee: "Sofia Vargas", assigneeAvatar: members[11].avatar, reporter: "Amara Okafor", reporterAvatar: members[5].avatar, labels: [labels[6]], dueDate: daysFromNow(12), startDate: daysAgo(2), estimateHours: 4, loggedHours: 1, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(4), updatedAt: daysAgo(1), starred: false },
  { id: "t14", key: "SEC-901", title: "Pen test remediation: IDOR in /api/v1/projects/{id}", description: "Add ownership check before returning project data.", status: "review", priority: "urgent", projectId: "p12", projectName: "Security Audit", projectColor: "bg-rose-500", assignee: "Amara Okafor", assigneeAvatar: members[5].avatar, reporter: "Naomi Chen", reporterAvatar: members[7].avatar, labels: [labels[7], labels[3]], dueDate: daysFromNow(1), startDate: daysAgo(6), estimateHours: 6, loggedHours: 7, subtasks: [], comments: [], attachments: 1, createdAt: daysAgo(8), updatedAt: daysAgo(0), starred: true },
  { id: "t15", key: "PLN-104", title: "Kanban drag-and-drop with optimistic updates", description: "Use dnd-kit, persist order, optimistic UI with rollback on error.", status: "todo", priority: "high", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Felix Brandt", assigneeAvatar: members[4].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[1], labels[5]], dueDate: daysFromNow(9), estimateHours: 16, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(1), updatedAt: daysAgo(1), starred: false },
  { id: "t16", key: "MKT-501", title: "Product Hunt launch assets", description: "Gallery images, demo video script, first-comment post.", status: "backlog", priority: "medium", projectId: "p5", projectName: "Launch Campaign Q1", projectColor: "bg-cyan-500", assignee: "Isla Reyes", assigneeAvatar: members[9].avatar, reporter: "Jessin Sam", reporterAvatar: members[0].avatar, labels: [labels[8]], dueDate: daysFromNow(45), estimateHours: 12, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(5), updatedAt: daysAgo(5), starred: false },
  { id: "t17", key: "PLN-105", title: "Recurring task scheduler", description: "Daily/weekly/monthly recurrence with skip-on-holiday option.", status: "in_progress", priority: "medium", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Amara Okafor", assigneeAvatar: members[5].avatar, reporter: "Jessin Sam", reporterAvatar: members[0].avatar, labels: [labels[0]], dueDate: daysFromNow(14), startDate: daysAgo(3), estimateHours: 10, loggedHours: 3, subtasks: [], comments: [], attachments: 0, recurring: "weekly", createdAt: daysAgo(4), updatedAt: daysAgo(1), starred: false },
  { id: "t18", key: "PLN-106", title: "Calendar month view with overlapping events", description: "Render multi-day events, conflict resolution, drag to move.", status: "todo", priority: "high", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Mira Patel", assigneeAvatar: members[3].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[2], labels[1]], dueDate: daysFromNow(18), estimateHours: 18, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(2), updatedAt: daysAgo(2), starred: false },
  { id: "t19", key: "ANL-1001", title: "Define event taxonomy v1", description: "Document all analytics events with properties and triggers.", status: "backlog", priority: "medium", projectId: "p10", projectName: "Analytics Overhaul", projectColor: "bg-green-600", assignee: "Theo Nakamura", assigneeAvatar: members[2].avatar, reporter: "Jessin Sam", reporterAvatar: members[0].avatar, labels: [labels[6], labels[4]], dueDate: daysFromNow(25), estimateHours: 8, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(1), updatedAt: daysAgo(1), starred: false },
  { id: "t20", key: "ARC-602", title: "Acme SSO integration", description: "SAML 2.0 with Acme's Okta tenant, JIT provisioning.", status: "in_progress", priority: "urgent", projectId: "p9", projectName: "Acme Client Project", projectColor: "bg-lime-600", assignee: "Hugo Lindqvist", assigneeAvatar: members[8].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[0], labels[7]], dueDate: daysFromNow(4), startDate: daysAgo(8), estimateHours: 14, loggedHours: 6, subtasks: [], comments: [], attachments: 2, createdAt: daysAgo(10), updatedAt: daysAgo(0), starred: true },
  { id: "t21", key: "PLN-107", title: "Notification preferences UI", description: "Per-channel toggles, digest scheduling, quiet hours.", status: "todo", priority: "low", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Sofia Vargas", assigneeAvatar: members[11].avatar, reporter: "Jessin Sam", reporterAvatar: members[0].avatar, labels: [labels[1], labels[2]], dueDate: daysFromNow(16), estimateHours: 8, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(2), updatedAt: daysAgo(2), starred: false },
  { id: "t22", key: "MOB-203", title: "Offline mode for tasks list", description: "Cache last 100 tasks, sync on reconnect, conflict resolution.", status: "backlog", priority: "medium", projectId: "p2", projectName: "Mobile Companion", projectColor: "bg-teal-500", assignee: "Leon Cruz", assigneeAvatar: members[6].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[9], labels[0]], dueDate: daysFromNow(30), estimateHours: 20, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(6), updatedAt: daysAgo(6), starred: false },
  { id: "t23", key: "DSGN-403", title: "Toast component variants", description: "Success, error, info, warning with icons and action buttons.", status: "done", priority: "low", projectId: "p4", projectName: "Design System 2.0", projectColor: "bg-green-500", assignee: "Mira Patel", assigneeAvatar: members[3].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[2]], dueDate: daysAgo(3), startDate: daysAgo(10), estimateHours: 4, loggedHours: 5, subtasks: [], comments: [], attachments: 2, createdAt: daysAgo(12), updatedAt: daysAgo(3), starred: false },
  { id: "t24", key: "QA-702", title: "E2E test for invite member flow", description: "Covers invitation, accept, role assignment, removal.", status: "in_progress", priority: "medium", projectId: "p7", projectName: "Test Automation Suite", projectColor: "bg-emerald-600", assignee: "Naomi Chen", assigneeAvatar: members[7].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[3]], dueDate: daysFromNow(7), startDate: daysAgo(2), estimateHours: 6, loggedHours: 2, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(4), updatedAt: daysAgo(1), starred: false },
  { id: "t25", key: "INF-502", title: "Set up Prometheus + Grafana for new cluster", description: "Cluster metrics, app metrics, alert rules, on-call rotation.", status: "todo", priority: "high", projectId: "p6", projectName: "Infrastructure Migration", projectColor: "bg-sky-500", assignee: "Hugo Lindqvist", assigneeAvatar: members[8].avatar, reporter: "Theo Nakamura", reporterAvatar: members[2].avatar, labels: [labels[5], labels[0]], dueDate: daysFromNow(11), estimateHours: 12, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(3), updatedAt: daysAgo(3), starred: false },
  { id: "t26", key: "PLN-108", title: "Time tracker widget improvements", description: "Pause, resume, manual entry, project selector.", status: "review", priority: "medium", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", assignee: "Felix Brandt", assigneeAvatar: members[4].avatar, reporter: "Zara Marlowe", reporterAvatar: members[1].avatar, labels: [labels[1]], dueDate: daysFromNow(2), startDate: daysAgo(6), estimateHours: 8, loggedHours: 7, subtasks: [], comments: [], attachments: 1, createdAt: daysAgo(8), updatedAt: daysAgo(0), starred: false },
  { id: "t27", key: "MKT-502", title: "Q1 launch email sequence", description: "5-email drip for trial users with branching logic.", status: "in_progress", priority: "medium", projectId: "p5", projectName: "Launch Campaign Q1", projectColor: "bg-cyan-500", assignee: "Isla Reyes", assigneeAvatar: members[9].avatar, reporter: "Jessin Sam", reporterAvatar: members[0].avatar, labels: [labels[8]], dueDate: daysFromNow(15), startDate: daysAgo(3), estimateHours: 10, loggedHours: 4, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(4), updatedAt: daysAgo(1), starred: false },
  { id: "t28", key: "DOC-802", title: "Getting started guide for new workspaces", description: "10-minute setup walkthrough with embedded videos.", status: "backlog", priority: "low", projectId: "p8", projectName: "Documentation Portal", projectColor: "bg-teal-600", assignee: "Sofia Vargas", assigneeAvatar: members[11].avatar, reporter: "Ravi Kapoor", reporterAvatar: members[10].avatar, labels: [labels[6]], dueDate: daysFromNow(22), estimateHours: 6, loggedHours: 0, subtasks: [], comments: [], attachments: 0, createdAt: daysAgo(2), updatedAt: daysAgo(2), starred: false },
]

// ============================================================
// KANBAN COLUMNS
// ============================================================

export const initialColumns: Column[] = [
  { id: "col-backlog", title: "Backlog", color: "bg-muted-foreground/15", taskIds: ["t5", "t16", "t19", "t22", "t28"] },
  { id: "col-todo", title: "To Do", color: "bg-sky-500/20", taskIds: ["t2", "t8", "t12", "t15", "t18", "t21", "t25"] },
  { id: "col-progress", title: "In Progress", color: "bg-amber-500/20", taskIds: ["t1", "t3", "t7", "t9", "t11", "t17", "t20", "t24", "t27"] },
  { id: "col-review", title: "Review", color: "bg-violet-500/20", taskIds: ["t4", "t14", "t26"] },
  { id: "col-done", title: "Done", color: "bg-emerald-500/20", taskIds: ["t6", "t23"] },
]

// ============================================================
// SPRINTS
// ============================================================

export const sprints: Sprint[] = [
  { id: "sp1", name: "Sprint 47 — Velocity", goal: "Ship command palette + recurring tasks", status: "active", startDate: daysAgo(7), endDate: daysFromNow(7), storyPointsCommitted: 64, storyPointsCompleted: 42, tasksTotal: 28, tasksDone: 19 },
  { id: "sp2", name: "Sprint 46 — Stability", goal: "Fix top 10 bugs + perf pass", status: "completed", startDate: daysAgo(21), endDate: daysAgo(7), storyPointsCommitted: 58, storyPointsCompleted: 54, tasksTotal: 32, tasksDone: 30 },
  { id: "sp3", name: "Sprint 45 — Foundation", goal: "New auth + audit logs", status: "completed", startDate: daysAgo(35), endDate: daysAgo(21), storyPointsCommitted: 52, storyPointsCompleted: 49, tasksTotal: 28, tasksDone: 26 },
  { id: "sp4", name: "Sprint 48 — Polishing", goal: "Mobile beta + design system v2", status: "planning", startDate: daysFromNow(7), endDate: daysFromNow(21), storyPointsCommitted: 60, storyPointsCompleted: 0, tasksTotal: 0, tasksDone: 0 },
]

// ============================================================
// CALENDAR EVENTS
// ============================================================

export const events: CalendarEvent[] = [
  { id: "e1", title: "Sprint Planning", description: "Plan Sprint 48", category: "meeting", start: `${daysFromNow(7)}T10:00:00`, end: `${daysFromNow(7)}T11:30:00`, attendees: [members[1].name, members[2].name, members[4].name], location: "Zoom — Main", color: "bg-emerald-500" },
  { id: "e2", title: "Design Review", description: "Walk through DS 2.0 progress", category: "meeting", start: `${daysFromNow(2)}T14:00:00`, end: `${daysFromNow(2)}T15:00:00`, attendees: [members[3].name, members[1].name, members[11].name], location: "Design Room", color: "bg-lime-500" },
  { id: "e3", title: "API Platform GA", category: "deadline", start: `${daysFromNow(20)}T00:00:00`, end: `${daysFromNow(20)}T23:59:00`, allDay: true, attendees: [members[5].name], color: "bg-rose-500" },
  { id: "e4", title: "1:1 with Zara", category: "meeting", start: `${daysFromNow(1)}T09:00:00`, end: `${daysFromNow(1)}T09:30:00`, attendees: [members[0].name, members[1].name], color: "bg-teal-500" },
  { id: "e5", title: "Focus block — Architecture", category: "focus", start: `${daysFromNow(0)}T13:00:00`, end: `${daysFromNow(0)}T16:00:00`, attendees: [members[2].name], color: "bg-violet-500" },
  { id: "e6", title: "Acme kickoff", category: "external", start: `${daysFromNow(3)}T11:00:00`, end: `${daysFromNow(3)}T12:00:00`, attendees: [members[1].name, members[4].name], location: "Client office", color: "bg-cyan-500" },
  { id: "e7", title: "Submit Q1 invoice", category: "reminder", start: `${daysFromNow(5)}T09:00:00`, end: `${daysFromNow(5)}T09:15:00`, attendees: [members[0].name], color: "bg-amber-500" },
  { id: "e8", title: "Team retro", category: "meeting", start: `${daysFromNow(14)}T16:00:00`, end: `${daysFromNow(14)}T17:00:00`, attendees: members.slice(0, 8).map(m => m.name), location: "Main room", color: "bg-emerald-500" },
  { id: "e9", title: "Dentist", category: "personal", start: `${daysFromNow(4)}T08:00:00`, end: `${daysFromNow(4)}T09:00:00`, attendees: [members[0].name], color: "bg-pink-500" },
  { id: "e10", title: "Pen test results review", category: "meeting", start: `${daysFromNow(6)}T15:00:00`, end: `${daysFromNow(6)}T16:00:00`, attendees: [members[2].name, members[7].name, members[5].name], color: "bg-rose-500" },
]

// ============================================================
// TIME ENTRIES (last 14 days)
// ============================================================

export const timeEntries: TimeEntry[] = Array.from({ length: 28 }).map((_, i) => {
  const m = members[i % members.length]
  const p = projects[i % projects.length]
  const t = tasks[i % tasks.length]
  const day = -Math.floor(i / 3)
  const hour = 9 + (i % 7)
  const duration = (1 + (i % 4)) * 1800
  return {
    id: `te${i + 1}`,
    taskId: t.id,
    taskKey: t.key,
    taskTitle: t.title,
    projectId: p.id,
    projectName: p.name,
    memberId: m.id,
    memberName: m.name,
    memberAvatar: m.avatar,
    description: t.title,
    start: `${daysAgo(-day)}T${hour.toString().padStart(2, "0")}:00:00`,
    end: `${daysAgo(-day)}T${(hour + Math.floor(duration / 3600)).toString().padStart(2, "0")}:00:00`,
    duration,
    billable: i % 3 !== 0,
    status: i % 4 === 0 ? "submitted" : i % 7 === 0 ? "approved" : "running",
  }
})

// ============================================================
// NOTIFICATIONS
// ============================================================

export const notifications: Notification[] = [
  { id: "n1", type: "mention", title: "Zara mentioned you", body: "@jessin can you review the new onboarding flow before EOD?", createdAt: daysAgo(0), read: false, actor: { name: members[1].name, avatar: members[1].avatar }, href: "/tasks/t1" },
  { id: "n2", type: "deadline", title: "Task due tomorrow", body: "PLN-103 — WebSocket reconnect logic for live presence", createdAt: daysAgo(0), read: false, actor: { name: "Planna", avatar: "" }, href: "/tasks/t3" },
  { id: "n3", type: "comment", title: "Naomi commented on MOB-201", body: "Tested on iOS 17 and 18 — looks good.", createdAt: daysAgo(1), read: false, actor: { name: members[7].name, avatar: members[7].avatar }, href: "/tasks/t4" },
  { id: "n4", type: "invite", title: "New invite accepted", body: "Sofia Vargas joined the Design team.", createdAt: daysAgo(2), read: true, actor: { name: members[11].name, avatar: members[11].avatar }, href: "/team" },
  { id: "n5", type: "project", title: "Project health changed", body: "Mobile Companion moved to At Risk.", createdAt: daysAgo(2), read: true, actor: { name: "Planna", avatar: "" }, href: "/projects/p2" },
  { id: "n6", type: "task", title: "Task assigned to you", body: "PLN-105 — Kanban drag-and-drop with optimistic updates", createdAt: daysAgo(3), read: true, actor: { name: members[1].name, avatar: members[1].avatar }, href: "/tasks/t15" },
  { id: "n7", type: "system", title: "Weekly digest ready", body: "Your team completed 47 tasks this week. View report.", createdAt: daysAgo(4), read: true, actor: { name: "Planna", avatar: "" }, href: "/analytics" },
  { id: "n8", type: "deadline", title: "Sprint 47 ends in 7 days", body: "9 tasks still in progress. Plan accordingly.", createdAt: daysAgo(4), read: true, actor: { name: "Planna", avatar: "" }, href: "/planning/sprint-planning" },
]

// ============================================================
// CLIENTS
// ============================================================

export const clients: Client[] = [
  { id: "c1", name: "Acme Corp", company: "Acme Corporation", email: "ops@acme.com", phone: "+1 415 555 0142", logo: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=128&h=128&fit=crop", industry: "Logistics", status: "active", projectsCount: 3, totalRevenue: 480000, outstanding: 32000, contactName: "Marie Lopez", contactAvatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=128&h=128&fit=crop", startDate: "2024-05-12", location: "San Francisco, US" },
  { id: "c2", name: "Nimbus", company: "Nimbus Cloud Inc", email: "hello@nimbus.io", phone: "+44 20 7183 4421", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=128&h=128&fit=crop", industry: "SaaS", status: "active", projectsCount: 2, totalRevenue: 320000, outstanding: 0, contactName: "James Wright", contactAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=128&h=128&fit=crop", startDate: "2024-08-03", location: "London, UK" },
  { id: "c3", name: "Lumen Studio", company: "Lumen Creative Ltd", email: "team@lumen.studio", phone: "+34 91 555 0190", logo: "https://images.unsplash.com/photo-1620281692096-0d89078e4d31?w=128&h=128&fit=crop", industry: "Agency", status: "active", projectsCount: 4, totalRevenue: 215000, outstanding: 18000, contactName: "Sara Jiménez", contactAvatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=128&h=128&fit=crop", startDate: "2023-11-21", location: "Madrid, ES" },
  { id: "c4", name: "Forge Industries", company: "Forge Manufacturing", email: "it@forge.industries", phone: "+1 312 555 0173", logo: "https://images.unsplash.com/photo-1565514020179-026b92b84bb6?w=128&h=128&fit=crop", industry: "Manufacturing", status: "lead", projectsCount: 0, totalRevenue: 0, outstanding: 0, contactName: "Robert Chen", contactAvatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=128&h=128&fit=crop", startDate: daysAgo(14), location: "Chicago, US" },
  { id: "c5", name: "Pulse Health", company: "Pulse Health Systems", email: "engineering@pulse.health", phone: "+1 617 555 0188", logo: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=128&h=128&fit=crop", industry: "Healthcare", status: "prospect", projectsCount: 0, totalRevenue: 0, outstanding: 0, contactName: "Anika Patel", contactAvatar: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=128&h=128&fit=crop", startDate: daysAgo(7), location: "Boston, US" },
  { id: "c6", name: "Vertex Capital", company: "Vertex Capital Partners", email: "ops@vertex.capital", phone: "+1 212 555 0119", logo: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=128&h=128&fit=crop", industry: "Finance", status: "active", projectsCount: 1, totalRevenue: 180000, outstanding: 0, contactName: "David Park", contactAvatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=128&h=128&fit=crop", startDate: "2024-02-18", location: "New York, US" },
]

// ============================================================
// INVOICES
// ============================================================

export const invoices: Invoice[] = [
  { id: "inv1", number: "INV-2026-0042", clientId: "c1", clientName: "Acme Corp", clientLogo: clients[0].logo, amount: 32000, tax: 2560, total: 34560, status: "overdue", issueDate: daysAgo(35), dueDate: daysAgo(5), project: "Acme Client Project" },
  { id: "inv2", number: "INV-2026-0041", clientId: "c2", clientName: "Nimbus", clientLogo: clients[1].logo, amount: 18000, tax: 1440, total: 19440, status: "paid", issueDate: daysAgo(20), dueDate: daysAgo(0), paidDate: daysAgo(2), project: "Nimbus Migration" },
  { id: "inv3", number: "INV-2026-0040", clientId: "c3", clientName: "Lumen Studio", clientLogo: clients[2].logo, amount: 12000, tax: 960, total: 12960, status: "sent", issueDate: daysAgo(7), dueDate: daysFromNow(23), project: "Lumen Rebrand" },
  { id: "inv4", number: "INV-2026-0039", clientId: "c6", clientName: "Vertex Capital", clientLogo: clients[5].logo, amount: 45000, tax: 3600, total: 48600, status: "paid", issueDate: daysAgo(45), dueDate: daysAgo(15), paidDate: daysAgo(12), project: "Vertex Portal" },
  { id: "inv5", number: "INV-2026-0038", clientId: "c1", clientName: "Acme Corp", clientLogo: clients[0].logo, amount: 28000, tax: 2240, total: 30240, status: "paid", issueDate: daysAgo(60), dueDate: daysAgo(30), paidDate: daysAgo(28), project: "Acme Onboarding" },
  { id: "inv6", number: "INV-2026-0043", clientId: "c3", clientName: "Lumen Studio", clientLogo: clients[2].logo, amount: 6000, tax: 480, total: 6480, status: "draft", issueDate: daysFromNow(0), dueDate: daysFromNow(30), project: "Lumen Rebrand" },
]

// ============================================================
// FILES
// ============================================================

export const files: FileItem[] = [
  { id: "f1", name: "Q1 2026 Roadmap.pdf", type: "pdf", size: 2_400_000, mimeType: "application/pdf", owner: "Zara Marlowe", ownerAvatar: members[1].avatar, project: "Planna Web App", modifiedAt: daysAgo(1), shared: true, starred: true, url: "#" },
  { id: "f2", name: "Design System Tokens.fig", type: "document", size: 8_900_000, mimeType: "application/octet-stream", owner: "Mira Patel", ownerAvatar: members[3].avatar, project: "Design System 2.0", modifiedAt: daysAgo(2), shared: true, starred: false, url: "#" },
  { id: "f3", name: "API Spec v3.yaml", type: "code", size: 184_000, mimeType: "text/yaml", owner: "Amara Okafor", ownerAvatar: members[5].avatar, project: "Public API Platform", modifiedAt: daysAgo(3), shared: false, starred: false, url: "#" },
  { id: "f4", name: "Acme Brand Assets.zip", type: "archive", size: 56_000_000, mimeType: "application/zip", owner: "Felix Brandt", ownerAvatar: members[4].avatar, project: "Acme Client Project", modifiedAt: daysAgo(4), shared: true, starred: false, url: "#" },
  { id: "f5", name: "Sprint 47 Review.pptx", type: "presentation", size: 4_200_000, mimeType: "application/vnd.ms-powerpoint", owner: "Theo Nakamura", ownerAvatar: members[2].avatar, project: "Planna Web App", modifiedAt: daysAgo(0), shared: false, starred: false, url: "#" },
  { id: "f6", name: "Burndown Chart.xlsx", type: "spreadsheet", size: 312_000, mimeType: "application/vnd.ms-excel", owner: "Naomi Chen", ownerAvatar: members[7].avatar, project: "Test Automation Suite", modifiedAt: daysAgo(5), shared: true, starred: true, url: "#" },
  { id: "f7", name: "Onboarding Walkthrough.mp4", type: "video", size: 124_000_000, mimeType: "video/mp4", owner: "Sofia Vargas", ownerAvatar: members[11].avatar, project: "Documentation Portal", modifiedAt: daysAgo(7), shared: true, starred: false, url: "#" },
  { id: "f8", name: "Team Photo 2025.jpg", type: "image", size: 3_800_000, mimeType: "image/jpeg", owner: "Jessin Sam", ownerAvatar: members[0].avatar, modifiedAt: daysAgo(20), shared: true, starred: true, url: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=400&h=300&fit=crop" },
  { id: "f9", name: "Pen Test Report.pdf", type: "pdf", size: 1_800_000, mimeType: "application/pdf", owner: "Naomi Chen", ownerAvatar: members[7].avatar, project: "Security Audit", modifiedAt: daysAgo(6), shared: false, starred: false, url: "#" },
  { id: "f10", name: "Mobile Mockups v3.png", type: "image", size: 5_600_000, mimeType: "image/png", owner: "Mira Patel", ownerAvatar: members[3].avatar, project: "Mobile Companion", modifiedAt: daysAgo(2), shared: true, starred: false, url: "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=400&h=300&fit=crop" },
]

// ============================================================
// NOTES
// ============================================================

export const notes: Note[] = [
  { id: "no1", title: "Sprint 47 retro action items", body: "1. Reduce WIP limit to 3 per column\n2. Add automated status updates to Slack\n3. Pair-program on WebSocket reconnect\n4. Rotate on-call starting Sprint 48", tags: ["sprint", "retro"], author: "Zara Marlowe", authorAvatar: members[1].avatar, updatedAt: daysAgo(0), pinned: true, shared: true, color: "bg-emerald-500/10 border-emerald-500/30" },
  { id: "no2", title: "Acme onboarding decisions", body: "Acme wants:\n- Custom branding (logo, colors)\n- 5-step onboarding instead of 3\n- SSO via Okta\n- Role mapping: Admin, Editor, Viewer", tags: ["client", "acme"], author: "Zara Marlowe", authorAvatar: members[1].avatar, updatedAt: daysAgo(3), pinned: false, shared: true, color: "bg-teal-500/10 border-teal-500/30" },
  { id: "no3", title: "Hiring notes — Senior PM", body: "Strong candidates so far:\n- Aisha (ex-Linear) — great product sense\n- Marcus (ex-Notion) — solid execution\nNext step: panel interview next week", tags: ["hiring"], author: "Jessin Sam", authorAvatar: members[0].avatar, updatedAt: daysAgo(2), pinned: false, shared: false, color: "bg-lime-500/10 border-lime-500/30" },
  { id: "no4", title: "API deprecation plan", body: "v1 endpoints deprecated 2026-06-30\nv2 endpoints become default 2026-04-15\nNotify all consumers 60 days in advance\nMaintain v1 in maintenance mode for 12 months", tags: ["api", "platform"], author: "Amara Okafor", authorAvatar: members[5].avatar, updatedAt: daysAgo(5), pinned: false, shared: true, color: "bg-cyan-500/10 border-cyan-500/30" },
  { id: "no5", title: "Personal — weekly review", body: "Wins: shipped command palette, closed 12 tasks\nLearnings: pair programming with Felix sped up WS reconnect\nNext: focus on planning Sprint 48, reduce context switching", tags: ["personal"], author: "Jessin Sam", authorAvatar: members[0].avatar, updatedAt: daysAgo(1), pinned: false, shared: false, color: "bg-violet-500/10 border-violet-500/30" },
  { id: "no6", title: "Competitive analysis", body: "Compared to Linear, Asana, ClickUp:\n- We're faster on small boards\n- Need to improve: bulk actions, advanced filters\n- Opportunity: agency/client mode", tags: ["research"], author: "Isla Reyes", authorAvatar: members[9].avatar, updatedAt: daysAgo(8), pinned: false, shared: true, color: "bg-amber-500/10 border-amber-500/30" },
]

// ============================================================
// API KEYS
// ============================================================

export const apiKeys: ApiKey[] = [
  { id: "ak1", name: "Production Server", prefix: "pk_live_8f2a", created: daysAgo(180), lastUsed: daysAgo(0), scopes: ["tasks:read", "tasks:write", "projects:read", "projects:write"], revoked: false },
  { id: "ak2", name: "Staging CI", prefix: "pk_test_2c91", created: daysAgo(120), lastUsed: daysAgo(1), scopes: ["tasks:read", "projects:read"], revoked: false },
  { id: "ak3", name: "Analytics Pipeline", prefix: "pk_live_a1b9", created: daysAgo(90), lastUsed: daysAgo(0), scopes: ["analytics:read"], revoked: false },
  { id: "ak4", name: "Legacy Webhook", prefix: "pk_live_77de", created: daysAgo(360), lastUsed: daysAgo(45), scopes: ["webhooks:write"], revoked: true },
]

export const webhooks: Webhook[] = [
  { id: "wh1", url: "https://hooks.acme.com/planna", events: ["task.created", "task.completed", "project.updated"], active: true, createdAt: daysAgo(60), lastFired: daysAgo(0) },
  { id: "wh2", url: "https://api.nimbus.io/sync/planna", events: ["task.completed"], active: true, createdAt: daysAgo(45), lastFired: daysAgo(1) },
  { id: "wh3", url: "https://legacy.lumen.studio/wh", events: ["project.created"], active: false, createdAt: daysAgo(120), lastFired: daysAgo(30) },
]

export const integrations: Integration[] = [
  { id: "int1", name: "Slack", description: "Send notifications and create tasks from Slack", icon: "MessageSquare", category: "Communication", connected: true, installedAt: daysAgo(120) },
  { id: "int2", name: "GitHub", description: "Link commits, PRs, and issues to Planna tasks", icon: "Github", category: "Developer", connected: true, installedAt: daysAgo(180) },
  { id: "int3", name: "Google Calendar", description: "Two-way sync of meetings and deadlines", icon: "Calendar", category: "Calendar", connected: true, installedAt: daysAgo(90) },
  { id: "int4", name: "Figma", description: "Embed designs and sync comments", icon: "Figma", category: "Design", connected: false },
  { id: "int5", name: "Linear", description: "Import issues and sync status", icon: "ArrowLeftRight", category: "Project", connected: false },
  { id: "int6", name: "Zapier", description: "Connect Planna to 5,000+ apps", icon: "Zap", category: "Automation", connected: false },
  { id: "int7", name: "Notion", description: "Embed Planna tasks in Notion pages", icon: "FileText", category: "Productivity", connected: false },
  { id: "int8", name: "Loom", description: "Attach video walkthroughs to tasks", icon: "Video", category: "Communication", connected: false },
]

// ============================================================
// AUDIT LOG
// ============================================================

export const auditLogs: AuditLog[] = [
  { id: "al1", actor: "Jessin Sam", actorAvatar: members[0].avatar, action: "Updated workspace settings", target: "Workspace → Appearance", ip: "203.0.113.42", createdAt: daysAgo(0), metadata: { theme: "dark → light" } },
  { id: "al2", actor: "Zara Marlowe", actorAvatar: members[1].avatar, action: "Invited member", target: "sofia@planna.app", ip: "203.0.113.51", createdAt: daysAgo(2) },
  { id: "al3", actor: "Theo Nakamura", actorAvatar: members[2].avatar, action: "Revoked API key", target: "pk_live_77de", ip: "203.0.113.78", createdAt: daysAgo(5) },
  { id: "al4", actor: "Naomi Chen", actorAvatar: members[7].avatar, action: "Changed role", target: "leon@planna.app → Manager", ip: "203.0.113.91", createdAt: daysAgo(7) },
  { id: "al5", actor: "Jessin Sam", actorAvatar: members[0].avatar, action: "Updated billing", target: "Plan → Scale", ip: "203.0.113.42", createdAt: daysAgo(14) },
  { id: "al6", actor: "Amara Okafor", actorAvatar: members[5].avatar, action: "Created webhook", target: "https://hooks.acme.com/planna", ip: "203.0.113.110", createdAt: daysAgo(20) },
  { id: "al7", actor: "Hugo Lindqvist", actorAvatar: members[8].avatar, action: "Exported audit logs", target: "CSV — 1,240 entries", ip: "203.0.113.134", createdAt: daysAgo(28) },
]

// ============================================================
// ACTIVITY FEED
// ============================================================

export const activities: Activity[] = [
  { id: "a1", actor: "Felix Brandt", actorAvatar: members[4].avatar, action: "completed", target: "PLN-101 — Implement command palette keyboard navigation", createdAt: daysAgo(0), type: "task" },
  { id: "a2", actor: "Zara Marlowe", actorAvatar: members[1].avatar, action: "commented on", target: "PLN-103", createdAt: daysAgo(0), type: "comment" },
  { id: "a3", actor: "Amara Okafor", actorAvatar: members[5].avatar, action: "moved", target: "API-302 → In Progress", createdAt: daysAgo(0), type: "task" },
  { id: "a4", actor: "Mira Patel", actorAvatar: members[3].avatar, action: "uploaded", target: "Mobile Mockups v3.png", createdAt: daysAgo(1), type: "file" },
  { id: "a5", actor: "Theo Nakamura", actorAvatar: members[2].avatar, action: "created", target: "Sprint 48 — Polishing", createdAt: daysAgo(1), type: "project" },
  { id: "a6", actor: "Naomi Chen", actorAvatar: members[7].avatar, action: "approved", target: "TE-007 time entry", createdAt: daysAgo(1), type: "task" },
  { id: "a7", actor: "Isla Reyes", actorAvatar: members[9].avatar, action: "joined", target: "Launch Campaign Q1", createdAt: daysAgo(2), type: "team" },
  { id: "a8", actor: "Hugo Lindqvist", actorAvatar: members[8].avatar, action: "blocked", target: "INF-501 — pending staging quota", createdAt: daysAgo(2), type: "task" },
]

// ============================================================
// MILESTONES
// ============================================================

export const milestones: Milestone[] = [
  { id: "m1", title: "Beta launch", description: "Open beta to first 100 users", dueDate: daysFromNow(14), status: "in_progress", progress: 70, projectId: "p1", projectName: "Planna Web App" },
  { id: "m2", title: "GA release", description: "General availability of web app", dueDate: daysFromNow(60), status: "planned", progress: 25, projectId: "p1", projectName: "Planna Web App" },
  { id: "m3", title: "iOS TestFlight", description: "Internal beta on TestFlight", dueDate: daysFromNow(21), status: "in_progress", progress: 55, projectId: "p2", projectName: "Mobile Companion" },
  { id: "m4", title: "API v2 launch", description: "Public v2 endpoints with rate limits", dueDate: daysAgo(7), status: "done", progress: 100, projectId: "p3", projectName: "Public API Platform" },
  { id: "m5", title: "SOC2 Type 1", description: "External audit complete", dueDate: daysFromNow(45), status: "in_progress", progress: 40, projectId: "p12", projectName: "Security Audit" },
  { id: "m6", title: "DS 2.0 release", description: "Publish design system 2.0", dueDate: daysFromNow(35), status: "in_progress", progress: 60, projectId: "p4", projectName: "Design System 2.0" },
]

// ============================================================
// GOALS / OKRs
// ============================================================

export const goals: Goal[] = [
  { id: "g1", title: "Reach 1,000 active workspaces", description: "Q1 2026 north star metric", owner: "Jessin Sam", ownerAvatar: members[0].avatar, dueDate: daysFromNow(88), progress: 62, status: "on_track", keyResults: [
    { id: "kr1", title: "Sign 250 new workspaces", progress: 78 },
    { id: "kr2", title: "Reduce trial churn to <8%", progress: 55 },
    { id: "kr3", title: "Launch referral program", progress: 40 },
  ]},
  { id: "g2", title: "Ship Mobile Companion v1", description: "Public release of iOS and Android apps", owner: "Leon Cruz", ownerAvatar: members[6].avatar, dueDate: daysFromNow(120), progress: 42, status: "at_risk", keyResults: [
    { id: "kr4", title: "iOS App Store submission", progress: 65 },
    { id: "kr5", title: "Android Play Store submission", progress: 38 },
    { id: "kr6", title: "Offline mode parity", progress: 22 },
  ]},
  { id: "g3", title: "Achieve SOC2 Type 2 readiness", description: "All controls in place for Type 2 audit", owner: "Theo Nakamura", ownerAvatar: members[2].avatar, dueDate: daysFromNow(180), progress: 35, status: "on_track", keyResults: [
    { id: "kr7", title: "Complete pen test remediation", progress: 70 },
    { id: "kr8", title: "Document 100% of access controls", progress: 50 },
    { id: "kr9", title: "Implement audit log retention", progress: 80 },
  ]},
  { id: "g4", title: "Increase weekly active users by 40%", description: "Engagement goal for H1 2026", owner: "Zara Marlowe", ownerAvatar: members[1].avatar, dueDate: daysFromNow(150), progress: 28, status: "behind", keyResults: [
    { id: "kr10", title: "Ship notifications center", progress: 60 },
    { id: "kr11", title: "Launch mobile companion", progress: 42 },
    { id: "kr12", title: "Improve onboarding completion", progress: 25 },
  ]},
]

// ============================================================
// ANNOUNCEMENTS
// ============================================================

export const announcements: Announcement[] = [
  { id: "an1", title: "Planna 2.4 is live — Command Palette is here", body: "Press Cmd+K anywhere to search pages, tasks, projects, and trigger quick actions. We've also shipped the new Kanban with drag-and-drop.", author: "Jessin Sam", authorAvatar: members[0].avatar, createdAt: daysAgo(0), pinned: true, audience: "All members", read: false },
  { id: "an2", title: "New security policy: 2FA required for admins", body: "Starting Feb 1, all admin and owner accounts must enable two-factor authentication. Visit Settings → Security to set it up.", author: "Theo Nakamura", authorAvatar: members[2].avatar, createdAt: daysAgo(7), pinned: false, audience: "Admins", read: false },
  { id: "an3", title: "Office closed for Lunar New Year", body: "The Planna office will be closed Feb 8–12. On-call rotation will be active for critical issues only.", author: "Jessin Sam", authorAvatar: members[0].avatar, createdAt: daysAgo(14), pinned: false, audience: "All members", read: true },
]

// ============================================================
// CHAT THREADS
// ============================================================

export const chatThreads: ChatThread[] = [
  { id: "ct1", name: "Zara Marlowe", avatar: members[1].avatar, isGroup: false, lastMessage: "Can you review the onboarding PR before EOD?", lastMessageAt: daysAgo(0), unread: 2, participants: [{ name: "Zara Marlowe", avatar: members[1].avatar }] },
  { id: "ct2", name: "#planna-web", isGroup: true, lastMessage: "Felix: Command palette is ready for review", lastMessageAt: daysAgo(0), unread: 5, participants: members.slice(0, 5).map(m => ({ name: m.name, avatar: m.avatar })) },
  { id: "ct3", name: "#design-system", isGroup: true, lastMessage: "Mira: New tokens are in the Figma file", lastMessageAt: daysAgo(1), unread: 0, participants: [members[3], members[11], members[1]].map(m => ({ name: m.name, avatar: m.avatar })) },
  { id: "ct4", name: "Theo Nakamura", avatar: members[2].avatar, isGroup: false, lastMessage: "Pushed the WS reconnect fix to staging", lastMessageAt: daysAgo(1), unread: 0, participants: [{ name: "Theo Nakamura", avatar: members[2].avatar }] },
  { id: "ct5", name: "#acme-client", isGroup: true, lastMessage: "Hugo: SSO config doc shared", lastMessageAt: daysAgo(2), unread: 1, participants: [members[1], members[4], members[8]].map(m => ({ name: m.name, avatar: m.avatar })) },
  { id: "ct6", name: "Amara Okafor", avatar: members[5].avatar, isGroup: false, lastMessage: "Rate limit middleware deployed to prod", lastMessageAt: daysAgo(3), unread: 0, participants: [{ name: "Amara Okafor", avatar: members[5].avatar }] },
]

// ============================================================
// AGGREGATE STATS / KPIs (for dashboard cards)
// ============================================================

export const dashboardStats = {
  totalTasks: 124,
  completedTasks: 78,
  overdueTasks: 6,
  inProgressTasks: 28,
  totalProjects: 12,
  activeProjects: 8,
  teamMembers: 12,
  hoursThisWeek: 312,
  productivityScore: 87,
  focusHoursToday: 4.2,
  billableHours: 218,
  sprintVelocity: 54,
}

// Productivity trend (last 12 weeks)
export const productivityTrend = [
  { week: "W1", completed: 32, planned: 40, focus: 18 },
  { week: "W2", completed: 38, planned: 42, focus: 22 },
  { week: "W3", completed: 41, planned: 45, focus: 24 },
  { week: "W4", completed: 35, planned: 44, focus: 19 },
  { week: "W5", completed: 44, planned: 48, focus: 26 },
  { week: "W6", completed: 48, planned: 50, focus: 28 },
  { week: "W7", completed: 42, planned: 46, focus: 23 },
  { week: "W8", completed: 51, planned: 52, focus: 30 },
  { week: "W9", completed: 55, planned: 56, focus: 32 },
  { week: "W10", completed: 49, planned: 54, focus: 27 },
  { week: "W11", completed: 58, planned: 60, focus: 33 },
  { week: "W12", completed: 62, planned: 64, focus: 35 },
]

export const burndownData = [
  { day: "Day 1", ideal: 64, actual: 64 },
  { day: "Day 2", ideal: 58, actual: 62 },
  { day: "Day 3", ideal: 52, actual: 58 },
  { day: "Day 4", ideal: 46, actual: 55 },
  { day: "Day 5", ideal: 40, actual: 50 },
  { day: "Day 6", ideal: 34, actual: 44 },
  { day: "Day 7", ideal: 28, actual: 38 },
  { day: "Day 8", ideal: 22, actual: 32 },
  { day: "Day 9", ideal: 16, actual: 26 },
  { day: "Day 10", ideal: 10, actual: 20 },
]

export const timeByProject = projects.slice(0, 6).map((p, i) => ({
  name: p.key,
  fullName: p.name,
  hours: 40 + i * 8 + (i % 3) * 4,
  color: p.color,
}))

export const workloadByMember = members.slice(0, 8).map(m => ({
  name: m.name.split(" ")[0],
  fullName: m.name,
  avatar: m.avatar,
  capacity: m.capacity,
  utilized: m.utilized,
  utilization: Math.round((m.utilized / m.capacity) * 100),
}))

export const sprintVelocityHistory = [
  { sprint: "S42", planned: 48, completed: 44 },
  { sprint: "S43", planned: 52, completed: 50 },
  { sprint: "S44", planned: 50, completed: 51 },
  { sprint: "S45", planned: 52, completed: 49 },
  { sprint: "S46", planned: 58, completed: 54 },
  { sprint: "S47", planned: 64, completed: 42 },
]

// Heatmap: 7 days × 24 hours of focus sessions
export const focusHeatmap = Array.from({ length: 7 }).map((_, day) =>
  Array.from({ length: 24 }).map((_, hour) => {
    // Peak focus 9-12 and 14-17, weekday
    const isWeekday = day < 5
    const isFocusHour = (hour >= 9 && hour <= 12) || (hour >= 14 && hour <= 17)
    if (isWeekday && isFocusHour) return Math.floor(Math.random() * 4) + 2
    if (isWeekday) return Math.floor(Math.random() * 2)
    return 0
  })
)

// Helpers
export const getMemberById = (id: string) => members.find(m => m.id === id)
export const getProjectById = (id: string) => projects.find(p => p.id === id)
export const getTaskById = (id: string) => tasks.find(t => t.id === id)
