import type { LucideIcon } from "lucide-react"
import {
  LayoutDashboard, CheckSquare, FolderKanban, Trello, Calendar, Users,
  Timer, BarChart3, FileText, Briefcase, Settings, LifeBuoy, Zap,
  Activity, Target, Flag, GitBranch, Rocket, ListChecks, ClipboardList,
  Bell, MessageSquare, Megaphone, AtSign, History, RefreshCw,
  CreditCard, Receipt, KeyRound, Webhook, Blocks, ScrollText,
  User, Shield, Monitor, Building2, FileSearch, BookOpen,
  StickyNote, FolderOpen, Image, FileBox, Clock, AlarmClock,
  CalendarDays, CalendarRange, CalendarClock, CalendarCheck, Plus,
  UserPlus, AlertTriangle, TimerReset, AlarmMinus,
  CircleDollarSign, Gauge, Sparkles, TrendingUp,
  Archive as ArchiveIcon, Columns3 as ColumnsIcon, Share2 as ShareIcon,
} from "lucide-react"

export interface NavItem {
  label: string
  href: string
  icon: LucideIcon
  badge?: string
}

export interface NavGroup {
  title: string
  items: NavItem[]
}

// ============================================================
// PRIMARY SIDEBAR NAVIGATION — 12 groups, ~100+ destinations
// ============================================================

export const navGroups: NavGroup[] = [
  {
    title: "Dashboard",
    items: [
      { label: "Overview", href: "/", icon: LayoutDashboard },
      { label: "Productivity", href: "/dashboard/productivity", icon: Gauge },
      { label: "Projects", href: "/dashboard/projects", icon: FolderKanban },
      { label: "Team", href: "/dashboard/team", icon: Users },
      { label: "Sprint", href: "/dashboard/sprint", icon: Rocket },
      { label: "Time Tracking", href: "/dashboard/time-tracking", icon: Timer },
      { label: "Client Work", href: "/dashboard/client-work", icon: Briefcase },
      { label: "Agency", href: "/dashboard/agency", icon: Building2 },
      { label: "Personal", href: "/dashboard/personal", icon: User },
      { label: "Executive", href: "/dashboard/executive", icon: TrendingUp },
    ],
  },
  {
    title: "Tasks",
    items: [
      { label: "All Tasks", href: "/tasks", icon: CheckSquare, badge: "124" },
      { label: "My Tasks", href: "/tasks/my", icon: ListChecks },
      { label: "Assigned", href: "/tasks/assigned", icon: ClipboardList },
      { label: "Completed", href: "/tasks/completed", icon: CheckSquare },
      { label: "Overdue", href: "/tasks/overdue", icon: AlertTriangle, badge: "6" },
      { label: "Recurring", href: "/tasks/recurring", icon: RefreshCw },
      { label: "Templates", href: "/tasks/templates", icon: FileBox },
      { label: "Priorities", href: "/tasks/priorities", icon: Flag },
      { label: "Labels", href: "/tasks/labels", icon: Blocks },
      { label: "Task Calendar", href: "/tasks/calendar", icon: CalendarDays },
      { label: "Timeline", href: "/tasks/timeline", icon: GitBranch },
    ],
  },
  {
    title: "Projects",
    items: [
      { label: "All Projects", href: "/projects", icon: FolderKanban, badge: "12" },
      { label: "Templates", href: "/projects/templates", icon: FileBox },
      { label: "Archived", href: "/projects/archived", icon: ArchiveIcon },
    ],
  },
  {
    title: "Planning",
    items: [
      { label: "Kanban Board", href: "/kanban", icon: Trello },
      { label: "Sprint Board", href: "/planning/sprint-board", icon: ColumnsIcon },
      { label: "Backlog", href: "/planning/backlog", icon: ListChecks },
      { label: "Roadmap", href: "/planning/roadmap", icon: GitBranch },
      { label: "Milestones", href: "/planning/milestones", icon: Flag },
      { label: "Goals", href: "/planning/goals", icon: Target },
      { label: "Releases", href: "/planning/releases", icon: Rocket },
      { label: "Sprint Planning", href: "/planning/sprint-planning", icon: CalendarClock },
      { label: "Sprint Review", href: "/planning/sprint-review", icon: CalendarCheck },
      { label: "Retrospective", href: "/planning/retrospective", icon: RefreshCw },
    ],
  },
  {
    title: "Calendar",
    items: [
      { label: "Month View", href: "/calendar", icon: Calendar },
      { label: "Week View", href: "/calendar/week", icon: CalendarRange },
      { label: "Day View", href: "/calendar/day", icon: CalendarDays },
      { label: "Agenda", href: "/calendar/agenda", icon: ListChecks },
      { label: "Meetings", href: "/calendar/meetings", icon: Users },
      { label: "Reminders", href: "/calendar/reminders", icon: AlarmClock },
      { label: "Deadlines", href: "/calendar/deadlines", icon: AlarmMinus },
    ],
  },
  {
    title: "Team",
    items: [
      { label: "Members", href: "/team", icon: Users },
      { label: "Departments", href: "/team/departments", icon: Building2 },
      { label: "Roles", href: "/team/roles", icon: Shield },
      { label: "Permissions", href: "/team/permissions", icon: KeyRound },
      { label: "Workload", href: "/team/workload", icon: Gauge },
      { label: "Availability", href: "/team/availability", icon: CalendarClock },
      { label: "Activity", href: "/team/activity", icon: Activity },
      { label: "Performance", href: "/team/performance", icon: TrendingUp },
      { label: "Invite", href: "/team/invite", icon: UserPlus },
    ],
  },
  {
    title: "Time",
    items: [
      { label: "Time Tracker", href: "/time", icon: Timer },
      { label: "Timesheets", href: "/time/timesheets", icon: ClipboardList },
      { label: "Time Entries", href: "/time/entries", icon: Clock },
      { label: "Billable Hours", href: "/time/billable", icon: CircleDollarSign },
      { label: "Time Reports", href: "/time/reports", icon: BarChart3 },
      { label: "Focus Sessions", href: "/time/sessions", icon: Sparkles },
      { label: "Focus Timer", href: "/time/focus", icon: TimerReset },
      { label: "Pomodoro", href: "/time/pomodoro", icon: AlarmClock },
      { label: "Manual Entry", href: "/time/manual", icon: Plus },
      { label: "Approvals", href: "/time/approvals", icon: CalendarCheck },
    ],
  },
  {
    title: "Analytics",
    items: [
      { label: "Overview", href: "/analytics", icon: BarChart3 },
      { label: "Tasks", href: "/analytics/tasks", icon: CheckSquare },
      { label: "Projects", href: "/analytics/projects", icon: FolderKanban },
      { label: "Team", href: "/analytics/team", icon: Users },
      { label: "Time", href: "/analytics/time", icon: Timer },
      { label: "Productivity", href: "/analytics/productivity", icon: TrendingUp },
      { label: "Workload", href: "/analytics/workload", icon: Gauge },
      { label: "Completion", href: "/analytics/completion", icon: CheckSquare },
      { label: "Performance", href: "/analytics/performance", icon: Sparkles },
      { label: "Custom Reports", href: "/analytics/custom", icon: FileText },
    ],
  },
  {
    title: "Files & Notes",
    items: [
      { label: "File Manager", href: "/files", icon: FolderOpen },
      { label: "Shared", href: "/files/shared", icon: ShareIcon },
      { label: "Notes", href: "/notes", icon: StickyNote },
      { label: "Documents", href: "/files/documents", icon: FileText },
      { label: "Knowledge Base", href: "/knowledge", icon: BookOpen },
      { label: "Wiki", href: "/knowledge/wiki", icon: FileSearch },
      { label: "Attachments", href: "/files/attachments", icon: Image },
      { label: "Templates Library", href: "/files/templates", icon: FileBox },
    ],
  },
  {
    title: "Communication",
    items: [
      { label: "Inbox", href: "/inbox", icon: MessageSquare, badge: "3" },
      { label: "Chat", href: "/chat", icon: MessageSquare },
      { label: "Notifications", href: "/notifications", icon: Bell, badge: "4" },
      { label: "Announcements", href: "/announcements", icon: Megaphone },
      { label: "Mentions", href: "/mentions", icon: AtSign },
      { label: "Activity Log", href: "/activity-log", icon: History },
      { label: "Updates", href: "/updates", icon: RefreshCw },
    ],
  },
  {
    title: "Clients",
    items: [
      { label: "All Clients", href: "/clients", icon: Briefcase, badge: "6" },
      { label: "Client Projects", href: "/clients/projects", icon: FolderKanban },
      { label: "Client Tasks", href: "/clients/tasks", icon: CheckSquare },
      { label: "Invoices", href: "/clients/invoices", icon: Receipt },
      { label: "Client Portal", href: "/clients/portal", icon: Building2 },
      { label: "Proposals", href: "/clients/proposals", icon: FileText },
      { label: "Contracts", href: "/clients/contracts", icon: ScrollText },
      { label: "Approvals", href: "/clients/approvals", icon: CalendarCheck },
      { label: "Feedback", href: "/clients/feedback", icon: MessageSquare },
    ],
  },
  {
    title: "Account",
    items: [
      { label: "Profile", href: "/settings/profile", icon: User },
      { label: "Account", href: "/settings/account", icon: Settings },
      { label: "Workspace", href: "/settings/workspace", icon: Building2 },
      { label: "Appearance", href: "/settings/appearance", icon: Monitor },
      { label: "Notifications", href: "/settings/notifications", icon: Bell },
      { label: "Security", href: "/settings/security", icon: Shield },
      { label: "Sessions", href: "/settings/sessions", icon: History },
      { label: "Billing", href: "/settings/billing", icon: CreditCard },
      { label: "Subscription", href: "/settings/subscription", icon: Sparkles },
      { label: "Invoices", href: "/settings/invoices", icon: Receipt },
      { label: "API Keys", href: "/settings/api-keys", icon: KeyRound },
      { label: "Webhooks", href: "/settings/webhooks", icon: Webhook },
      { label: "Integrations", href: "/settings/integrations", icon: Blocks },
      { label: "Audit Logs", href: "/settings/audit-logs", icon: ScrollText },
    ],
  },
  {
    title: "Help",
    items: [
      { label: "Help Center", href: "/help", icon: LifeBuoy },
      { label: "Documentation", href: "/help/docs", icon: BookOpen },
      { label: "Getting Started", href: "/help/getting-started", icon: Sparkles },
      { label: "Shortcuts", href: "/help/shortcuts", icon: Zap },
      { label: "Changelog", href: "/help/changelog", icon: History },
      { label: "Contact", href: "/help/contact", icon: MessageSquare },
      { label: "FAQ", href: "/help/faq", icon: FileText },
      { label: "Pricing", href: "/help/pricing", icon: CreditCard },
      { label: "Terms", href: "/help/terms", icon: ScrollText },
      { label: "Privacy", href: "/help/privacy", icon: Shield },
    ],
  },
]

// Flattened for command palette & breadcrumbs
export const allNavItems: NavItem[] = navGroups.flatMap(g => g.items)

export const findNavByHref = (href: string) => allNavItems.find(i => i.href === href)

// ============================================================
// COMMAND PALETTE — Quick actions
// ============================================================

export const quickActions: { label: string; hint: string; href: string; icon: LucideIcon; group: string }[] = [
  { label: "Create new task", hint: "Opens task modal", href: "/tasks", icon: Plus, group: "Create" },
  { label: "Create new project", hint: "Opens project modal", href: "/projects", icon: FolderKanban, group: "Create" },
  { label: "Create new event", hint: "Opens event modal", href: "/calendar", icon: Calendar, group: "Create" },
  { label: "Invite team member", hint: "Opens invite modal", href: "/team/invite", icon: UserPlus, group: "Create" },
  { label: "Start timer", hint: "Begins a focus session", href: "/time", icon: Timer, group: "Actions" },
  { label: "Open settings", hint: "Account preferences", href: "/settings", icon: Settings, group: "Actions" },
  { label: "Open help", hint: "Help center", href: "/help", icon: LifeBuoy, group: "Actions" },
]
