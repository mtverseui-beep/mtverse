"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState, useEffect } from "react"
import {
  Search, Bell, Mail, Plus, Sun, Moon, Menu, ChevronDown,
  Settings, User, LogOut, Sparkles, Check, X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel,
  DropdownMenuGroup, DropdownMenuShortcut,
} from "@/components/ui/dropdown-menu"
import {
  Popover, PopoverContent, PopoverTrigger,
} from "@/components/ui/popover"
import { useTheme } from "next-themes"
import { useUiStore } from "@/lib/store/ui-store"
import { findNavByHref, navGroups } from "@/lib/navigation"
import { notifications as seedNotifications, currentMember } from "@/lib/data/mock"
import { cn, timeAgo } from "@/lib/utils"
import { BrandLogo } from "./brand-logo"

export interface HeaderProps {
  title?: string
  description?: string
  actions?: React.ReactNode
  /** Either an array of {label, href?} OR a custom ReactNode (e.g. <Breadcrumb>) */
  breadcrumbs?: { label: string; href?: string }[] | React.ReactNode
  hideTitle?: boolean
}

export function Header({ title, description, actions, breadcrumbs, hideTitle }: HeaderProps) {
  const pathname = usePathname()
  const openCommandPalette = useUiStore(s => s.openCommandPalette)
  const setSidebarMobileOpen = useUiStore(s => s.setSidebarMobileOpen)
  const { setTheme } = useTheme()
  // Track mounted state for client-only rendering (theme toggle icon).
  // Using useState + useEffect to avoid useSyncExternalStore hydration issues.
  const [mounted, setMounted] = useState(false)
  const [isDark, setIsDark] = useState(false)
  useEffect(() => {
    // Mount-gate: set mounted=true after hydration to enable client-only UI.
    // This is the canonical pattern for avoiding hydration mismatches.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true)
    setIsDark(document.documentElement.classList.contains("dark"))
  }, [])

  // Derive breadcrumbs from pathname if not provided.
  // breadcrumbs may be either an array of {label, href?} OR a custom ReactNode (e.g. <Breadcrumb>).
  const isBreadcrumbsArray = Array.isArray(breadcrumbs)
  const breadcrumbArray = isBreadcrumbsArray ? (breadcrumbs as { label: string; href?: string }[]) : null
  const derivedBreadcrumbs = breadcrumbArray ?? deriveBreadcrumbs(pathname)
  const breadcrumbNode = !isBreadcrumbsArray && breadcrumbs ? breadcrumbs : null

  const toggleTheme = () => {
    const newIsDark = !isDark
    setIsDark(newIsDark)
    setTheme(newIsDark ? "dark" : "light")
  }

  return (
    <>
      {/* Sticky top bar: search + actions.
          This is a FRAGMENT-level element — the actual sticky wrapper is applied
          in DashboardShell so its parent is the full-height content div.
          The Header component returns the sticky bar + title section as siblings. */}
      <div className="sticky top-0 z-30 -mx-4 md:-mx-5 lg:-mx-6 px-4 md:px-5 lg:px-6 py-2 bg-background/80 backdrop-blur-md border-b border-border/50 flex items-center justify-between gap-2 md:gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden h-9 w-9 shrink-0"
            onClick={() => setSidebarMobileOpen(true)}
          >
            <Menu className="w-4 h-4" />
          </Button>

          <button
            onClick={openCommandPalette}
            className="relative flex-1 max-w-md group"
          >
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <div className="pl-9 pr-3 md:pr-16 h-9 flex items-center text-sm text-muted-foreground bg-card border border-border rounded-lg transition-all duration-300 group-hover:shadow-md group-hover:shadow-primary/10 group-focus-within:ring-2 group-focus-within:ring-primary/20 group-focus-within:border-primary/40">
              <span className="truncate">Search pages, tasks, projects…</span>
            </div>
            <kbd className="hidden md:inline-block absolute right-2.5 top-1/2 -translate-y-1/2 px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground bg-muted rounded border border-border pointer-events-none">
              ⌘K
            </kbd>
          </button>
        </div>

        <div className="flex items-center gap-1 md:gap-1.5 shrink-0">
          {/* Quick create */}
          <QuickCreateDropdown />

          {/* Messages */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative hover:bg-secondary transition-all duration-300 hover:scale-110 h-9 w-9"
              >
                <Mail className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-primary rounded-full ring-2 ring-card" />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80 p-0">
              <MessageDropdown />
            </PopoverContent>
          </Popover>

          {/* Notifications */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative hover:bg-secondary transition-all duration-300 hover:scale-110 h-9 w-9"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-destructive rounded-full animate-pulse ring-2 ring-card" />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80 p-0">
              <NotificationDropdown />
            </PopoverContent>
          </Popover>

          {/* Theme toggle — render a neutral icon until mounted to avoid hydration mismatch */}
          <Button
            variant="ghost"
            size="icon"
            className="hover:bg-secondary transition-all duration-300 hover:scale-110 h-9 w-9"
            onClick={toggleTheme}
          >
            {mounted ? (
              isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />
            ) : (
              <Moon className="w-4 h-4" />
            )}
          </Button>

          {/* User menu */}
          <UserMenu />
        </div>
      </div>

      {/* Title section — breadcrumbs, title, description, actions */}
      <div className="space-y-3 md:space-y-4 pt-3 md:pt-4">
        {!hideTitle && (
          <div>
            {breadcrumbNode ? (
              <div className="mb-2">{breadcrumbNode}</div>
            ) : derivedBreadcrumbs.length > 0 ? (
              <nav className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
                {derivedBreadcrumbs.map((b, i) => (
                  <span key={i} className="flex items-center gap-1">
                    {i > 0 && <span className="text-muted-foreground/50">/</span>}
                    {b.href ? (
                      <Link href={b.href} className="hover:text-foreground transition-colors">
                        {b.label}
                      </Link>
                    ) : (
                      <span className="text-foreground font-medium">{b.label}</span>
                    )}
                  </span>
                ))}
              </nav>
            ) : null}
            {title && (
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground mb-1 tracking-tight">
                {title}
              </h1>
            )}
            {description && (
              <p className="text-xs md:text-sm text-muted-foreground">{description}</p>
            )}
          </div>
        )}

        {actions && (
          <div className="flex flex-col sm:flex-row gap-2 flex-wrap">{actions}</div>
        )}
      </div>
    </>
  )
}

function QuickCreateDropdown() {
  const openCommandPalette = useUiStore(s => s.openCommandPalette)
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          size="sm"
          className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 hover:shadow-lg hover:shadow-primary/30 hover:scale-105 gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Create</span>
          <ChevronDown className="w-3 h-3 opacity-70" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>Quick create</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => openCommandPalette()}>
          <Plus className="w-4 h-4 mr-2" /> New task
          <DropdownMenuShortcut>⌘N</DropdownMenuShortcut>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => openCommandPalette()}>
          <Plus className="w-4 h-4 mr-2" /> New project
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => openCommandPalette()}>
          <Plus className="w-4 h-4 mr-2" /> New event
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => openCommandPalette()}>
          <Plus className="w-4 h-4 mr-2" /> New note
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => openCommandPalette()}>
          <Sparkles className="w-4 h-4 mr-2" /> Invite member
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

function NotificationDropdown() {
  const [items, setItems] = useState(seedNotifications)
  const unread = items.filter(n => !n.read).length

  const markAllRead = () => setItems(items.map(n => ({ ...n, read: true })))
  const markRead = (id: string) =>
    setItems(items.map(n => (n.id === id ? { ...n, read: true } : n)))

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <p className="text-sm font-semibold">Notifications</p>
          {unread > 0 && (
            <Badge className="bg-primary/15 text-primary text-[10px] px-1.5">
              {unread} new
            </Badge>
          )}
        </div>
        <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={markAllRead}>
          Mark all read
        </Button>
      </div>
      <div className="max-h-80 overflow-y-auto scroll-area-thin">
        {items.slice(0, 6).map(n => (
          <Link
            key={n.id}
            href={n.href ?? "#"}
            onClick={() => markRead(n.id)}
            className={cn(
              "block px-4 py-3 border-b border-border/50 hover:bg-secondary/50 transition-colors",
              !n.read && "bg-primary/5"
            )}
          >
            <div className="flex items-start gap-3">
              {n.actor?.avatar ? (
                <Avatar className="w-7 h-7 shrink-0">
                  <AvatarImage src={n.actor.avatar} alt={n.actor.name} />
                  <AvatarFallback>{n.actor.name[0]}</AvatarFallback>
                </Avatar>
              ) : (
                <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                  <Bell className="w-3.5 h-3.5 text-primary" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-foreground">{n.title}</p>
                <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{n.body}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{timeAgo(n.createdAt)}</p>
              </div>
              {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />}
            </div>
          </Link>
        ))}
      </div>
      <div className="p-2 border-t border-border">
        <Button asChild variant="ghost" size="sm" className="w-full h-8 text-xs">
          <Link href="/notifications">View all notifications</Link>
        </Button>
      </div>
    </div>
  )
}

function MessageDropdown() {
  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <p className="text-sm font-semibold">Messages</p>
        <Badge className="bg-primary/15 text-primary text-[10px] px-1.5">3 unread</Badge>
      </div>
      <div className="max-h-80 overflow-y-auto scroll-area-thin">
        {[
          { name: "Zara Marlowe", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", msg: "Can you review the onboarding PR before EOD?", time: "2m ago", unread: true },
          { name: "Theo Nakamura", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", msg: "Pushed the WS reconnect fix to staging", time: "1h ago", unread: true },
          { name: "Felix Brandt", avatar: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=64&h=64&fit=crop", msg: "Command palette is ready for review", time: "3h ago", unread: true },
          { name: "Mira Patel", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", msg: "New tokens are in the Figma file", time: "1d ago", unread: false },
        ].map((m, i) => (
          <Link
            key={i}
            href="/inbox"
            className={cn(
              "block px-4 py-3 border-b border-border/50 hover:bg-secondary/50 transition-colors",
              m.unread && "bg-primary/5"
            )}
          >
            <div className="flex items-start gap-3">
              <Avatar className="w-7 h-7 shrink-0">
                <AvatarImage src={m.avatar} alt={m.name} />
                <AvatarFallback>{m.name[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-foreground">{m.name}</p>
                <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{m.msg}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{m.time}</p>
              </div>
              {m.unread && <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />}
            </div>
          </Link>
        ))}
      </div>
      <div className="p-2 border-t border-border">
        <Button asChild variant="ghost" size="sm" className="w-full h-8 text-xs">
          <Link href="/inbox">Open inbox</Link>
        </Button>
      </div>
    </div>
  )
}

function UserMenu() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 pl-1.5 md:pl-2 md:pr-1 py-1 rounded-lg hover:bg-secondary transition-all duration-200">
          <Avatar className="w-7 h-7 md:w-8 md:h-8 ring-2 ring-primary/20 transition-all duration-300 hover:ring-primary/40">
            <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
            <AvatarFallback className="text-xs">{currentMember.name[0]}</AvatarFallback>
          </Avatar>
          <div className="text-xs hidden md:block text-left">
            <p className="font-semibold text-foreground leading-tight">{currentMember.name}</p>
            <p className="text-muted-foreground text-[10px] leading-tight">{currentMember.title}</p>
          </div>
          <ChevronDown className="w-3 h-3 text-muted-foreground hidden md:block" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <div className="px-2 py-1.5">
          <p className="text-sm font-semibold">{currentMember.name}</p>
          <p className="text-xs text-muted-foreground">{currentMember.email}</p>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuItem asChild>
            <Link href="/settings/profile">
              <User className="w-4 h-4 mr-2" /> Profile
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/settings/account">
              <Settings className="w-4 h-4 mr-2" /> Account settings
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/settings/billing">
              <Sparkles className="w-4 h-4 mr-2" /> Upgrade plan
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/help/shortcuts">
              <Sparkles className="w-4 h-4 mr-2" /> Keyboard shortcuts
              <DropdownMenuShortcut>⌘/</DropdownMenuShortcut>
            </Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/sign-in" className="text-destructive focus:text-destructive">
            <LogOut className="w-4 h-4 mr-2" /> Sign out
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

// Helper to derive breadcrumbs from pathname
function deriveBreadcrumbs(pathname: string): { label: string; href?: string }[] {
  if (pathname === "/") return []
  const parts = pathname.split("/").filter(Boolean)
  const crumbs: { label: string; href?: string }[] = [{ label: "Home", href: "/" }]

  let accum = ""
  for (let i = 0; i < parts.length; i++) {
    accum += "/" + parts[i]
    // Try to find this exact href in nav
    const navItem = findNavByHref(accum)
    if (navItem) {
      crumbs.push({
        label: navItem.label,
        href: i < parts.length - 1 ? accum : undefined,
      })
    } else {
      // Try parent + this segment as detail
      const parentHref = "/" + parts.slice(0, i).join("/")
      const parentNav = findNavByHref(parentHref)
      if (parentNav) {
        // It's a detail/child page
        crumbs.push({
          label: parts[i].replace(/-/g, " ").replace(/^\w/, c => c.toUpperCase()),
          href: undefined,
        })
      } else {
        crumbs.push({
          label: parts[i].replace(/-/g, " ").replace(/^\w/, c => c.toUpperCase()),
          href: i < parts.length - 1 ? accum : undefined,
        })
      }
    }
  }
  return crumbs.slice(1) // remove "Home"
}
