"use client"

import { useEffect } from "react"
import { usePathname } from "next/navigation"
import { Sidebar } from "./sidebar"
import { Header, type HeaderProps } from "./header"
import { useUiStore } from "@/lib/store/ui-store"
import { cn } from "@/lib/utils"

interface DashboardShellProps extends HeaderProps {
  children: React.ReactNode
  className?: string
  /** Whether to wrap children in a padded container — default true */
  contained?: boolean
}

/**
 * DashboardShell — the complete page layout: fixed Sidebar + main content area.
 *
 * Structure:
 *   <div min-h-screen>
 *     <Sidebar fixed w-64 />          ← fixed left, full height
 *     <main lg:ml-64>                  ← margin-left = sidebar width
 *       <div p-6 w-full>               ← content padding (24px on desktop)
 *         <Header />
 *         <div mt-5>{children}</div>
 *       </div>
 *     </main>
 *   </div>
 *
 * No max-width centering — content fills available space after sidebar.
 * No double-sidebar nesting — this is the ONLY place Sidebar is rendered for standard pages.
 */
export function DashboardShell({
  children,
  title,
  description,
  actions,
  breadcrumbs,
  hideTitle,
  className,
  contained = true,
}: DashboardShellProps) {
  const pathname = usePathname()
  const collapsed = useUiStore(s => s.sidebarCollapsed)
  const pushRecentPage = useUiStore(s => s.pushRecentPage)

  // Track recent pages on route change
  useEffect(() => {
    import("@/lib/navigation").then(({ findNavByHref }) => {
      const nav = findNavByHref(pathname)
      if (nav) {
        pushRecentPage({ href: pathname, title: nav.label })
      } else if (title) {
        pushRecentPage({ href: pathname, title })
      }
    })
  }, [pathname, pushRecentPage, title])

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main
        className={cn(
          "transition-[margin] duration-300 min-h-screen",
          collapsed ? "lg:ml-[72px]" : "lg:ml-64"
        )}
      >
        <div className={cn(contained && "p-4 md:p-5 lg:p-6", "w-full", className)}>
          <Header
            title={title}
            description={description}
            actions={actions}
            breadcrumbs={breadcrumbs}
            hideTitle={hideTitle}
          />
          <div className="mt-5 md:mt-6">{children}</div>
        </div>
      </main>
    </div>
  )
}

/**
 * DashboardShellBare — sidebar + main content area, NO Header.
 * Used by layouts that render their own custom header (e.g. project detail).
 *
 * Children are rendered directly inside <main> — do NOT wrap in another
 * <Sidebar> or <main> element.
 */
export function DashboardShellBare({ children }: { children: React.ReactNode }) {
  const collapsed = useUiStore(s => s.sidebarCollapsed)
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className={cn("transition-[margin] duration-300 min-h-screen", collapsed ? "lg:ml-[72px]" : "lg:ml-64")}>
        {children}
      </main>
    </div>
  )
}
