"use client"

import { cn } from "@/lib/utils"

interface BrandLogoProps {
  className?: string
  size?: "sm" | "md" | "lg"
  showWordmark?: boolean
}

export function BrandLogo({ className, size = "md", showWordmark = true }: BrandLogoProps) {
  const sizes = {
    sm: { box: "w-7 h-7", dot: "w-1 h-1", text: "text-base" },
    md: { box: "w-8 h-8", dot: "w-1.5 h-1.5", text: "text-lg" },
    lg: { box: "w-10 h-10", dot: "w-2 h-2", text: "text-xl" },
  }
  const s = sizes[size]
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        className={cn(
          "relative rounded-xl bg-primary flex items-center justify-center transition-transform group-hover:scale-110 duration-300 shadow-md shadow-primary/30",
          s.box
        )}
      >
        {/* Stylized "P" mark — two dots + curve */}
        <div
          className={cn("rounded-full bg-primary-foreground absolute", s.dot)}
          style={{ top: "28%", left: "28%" }}
        />
        <div
          className={cn("rounded-full bg-primary-foreground absolute", s.dot)}
          style={{ top: "28%", right: "28%" }}
        />
        <div
          className={cn("border-b-2 border-primary-foreground rounded-full absolute", s.dot)}
          style={{ bottom: "30%" }}
        />
      </div>
      {showWordmark && (
        <span className={cn("font-semibold text-foreground tracking-tight", s.text)}>
          Planna
        </span>
      )}
    </div>
  )
}
