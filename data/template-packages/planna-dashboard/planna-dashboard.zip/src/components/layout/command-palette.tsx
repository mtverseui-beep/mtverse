"use client"

import { useEffect, useState, useMemo } from "react"
import { useRouter } from "next/navigation"
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput,
  CommandItem, CommandList, CommandSeparator, CommandShortcut,
} from "@/components/ui/command"
import { useUiStore } from "@/lib/store/ui-store"
import { allNavItems, quickActions } from "@/lib/navigation"
import { tasks, projects, members, files, notes } from "@/lib/data/mock"
import { Plus, FolderKanban, CheckSquare, User, FileText, Search, Clock, Star } from "lucide-react"

export function CommandPalette() {
  const open = useUiStore(s => s.commandPaletteOpen)
  const setOpen = useUiStore(s => s.closeCommandPalette)
  const openCommandPalette = useUiStore(s => s.openCommandPalette)
  const pushRecentPage = useUiStore(s => s.pushRecentPage)
  const recentPages = useUiStore(s => s.recentPages)
  const favorites = useUiStore(s => s.favorites)
  const router = useRouter()
  // Mount-gate: render null on server, activate on client after hydration.
  // This prevents hydration mismatch from keyboard listeners and DOM APIs.
  const [mounted, setMounted] = useState(false)
  useEffect(() => {
    // Mount-gate: render null on server, activate on client after hydration.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true)
  }, [])

  // Global keyboard shortcut
  useEffect(() => {
    if (!mounted) return
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault()
        openCommandPalette()
      }
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [openCommandPalette])

  const go = (href: string, title: string) => {
    pushRecentPage({ href, title })
    setOpen()
    router.push(href)
  }

  const favItems = useMemo(() =>
    favorites.map(h => allNavItems.find(i => i.href === h)).filter(Boolean) as typeof allNavItems,
    [favorites]
  )

  if (!mounted) return null

  return (
    <CommandDialog open={open} onOpenChange={(o) => !o && setOpen()}>
      <CommandInput placeholder="Search pages, tasks, projects, people, files…" />
      <CommandList className="max-h-[400px]">
        <CommandEmpty>No results found.</CommandEmpty>

        {recentPages.length > 0 && (
          <>
            <CommandGroup heading="Recent">
              {recentPages.slice(0, 5).map(p => (
                <CommandItem
                  key={`r-${p.href}`}
                  value={`recent ${p.title}`}
                  onSelect={() => go(p.href, p.title)}
                >
                  <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                  <span>{p.title}</span>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {favItems.length > 0 && (
          <>
            <CommandGroup heading="Favorites">
              {favItems.map(item => {
                const Icon = item.icon
                return (
                  <CommandItem
                    key={`f-${item.href}`}
                    value={`favorite ${item.label}`}
                    onSelect={() => go(item.href, item.label)}
                  >
                    <Icon className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{item.label}</span>
                    <Star className="ml-auto h-3 w-3 fill-amber-500 text-amber-500" />
                  </CommandItem>
                )
              })}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        <CommandGroup heading="Quick actions">
          {quickActions.map(action => {
            const Icon = action.icon
            return (
              <CommandItem
                key={action.label}
                value={`action ${action.label}`}
                onSelect={() => go(action.href, action.label)}
              >
                <Icon className="mr-2 h-4 w-4 text-primary" />
                <span>{action.label}</span>
                <span className="ml-auto text-xs text-muted-foreground">{action.hint}</span>
              </CommandItem>
            )
          })}
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Pages">
          {allNavItems.slice(0, 30).map(item => {
            const Icon = item.icon
            return (
              <CommandItem
                key={`p-${item.href}`}
                value={`page ${item.label}`}
                onSelect={() => go(item.href, item.label)}
              >
                <Icon className="mr-2 h-4 w-4 text-muted-foreground" />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="ml-auto text-xs text-muted-foreground">{item.badge}</span>
                )}
              </CommandItem>
            )
          })}
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Tasks">
          {tasks.slice(0, 6).map(t => (
            <CommandItem
              key={`t-${t.id}`}
              value={`task ${t.key} ${t.title}`}
              onSelect={() => go(`/tasks/${t.id}`, t.title)}
            >
              <CheckSquare className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="font-mono text-xs text-muted-foreground mr-2">{t.key}</span>
              <span className="truncate">{t.title}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandGroup heading="Projects">
          {projects.slice(0, 6).map(p => (
            <CommandItem
              key={`pr-${p.id}`}
              value={`project ${p.key} ${p.name}`}
              onSelect={() => go(`/projects/${p.id}`, p.name)}
            >
              <FolderKanban className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="font-mono text-xs text-muted-foreground mr-2">{p.key}</span>
              <span className="truncate">{p.name}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandGroup heading="People">
          {members.slice(0, 6).map(m => (
            <CommandItem
              key={`m-${m.id}`}
              value={`person ${m.name} ${m.title}`}
              onSelect={() => go(`/team/${m.id}`, m.name)}
            >
              <User className="mr-2 h-4 w-4 text-muted-foreground" />
              <span>{m.name}</span>
              <span className="ml-2 text-xs text-muted-foreground truncate">{m.title}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandGroup heading="Files">
          {files.slice(0, 5).map(f => (
            <CommandItem
              key={`f-${f.id}`}
              value={`file ${f.name}`}
              onSelect={() => go(`/files`, f.name)}
            >
              <FileText className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="truncate">{f.name}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandGroup heading="Notes">
          {notes.slice(0, 5).map(n => (
            <CommandItem
              key={`n-${n.id}`}
              value={`note ${n.title}`}
              onSelect={() => go(`/notes`, n.title)}
            >
              <FileText className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="truncate">{n.title}</span>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  )
}
