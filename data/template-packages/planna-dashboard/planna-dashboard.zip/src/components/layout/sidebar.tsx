"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import { ChevronDown, Star, Pin, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { navGroups, findNavByHref } from "@/lib/navigation"
import { useUiStore } from "@/lib/store/ui-store"
import { BrandLogo } from "./brand-logo"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function Sidebar() {
  const pathname = usePathname()
  const collapsed = useUiStore(s => s.sidebarCollapsed)
  const mobileOpen = useUiStore(s => s.sidebarMobileOpen)
  const setMobileOpen = useUiStore(s => s.setSidebarMobileOpen)
  const favorites = useUiStore(s => s.favorites)
  const recentPages = useUiStore(s => s.recentPages)
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {}
    navGroups.forEach(g => {
      // open group if any of its items is active
      const hasActive = g.items.some(i => isActive(pathname, i.href))
      init[g.title] = hasActive || ["Dashboard", "Tasks", "Projects"].includes(g.title)
    })
    return init
  })

  const toggleGroup = (title: string) =>
    setOpenGroups(s => ({ ...s, [title]: !s[title] }))

  const favoriteItems = favorites
    .map(h => findNavByHref(h))
    .filter(Boolean)

  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden animate-overlay-in"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed top-0 left-0 z-50 h-screen bg-sidebar border-r border-sidebar-border transition-[width,transform] duration-300 flex flex-col overflow-hidden",
          collapsed ? "w-[72px]" : "w-64",
          "lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Brand */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-border shrink-0">
          <Link href="/" className="group">
            {collapsed ? <BrandLogo showWordmark={false} /> : <BrandLogo />}
          </Link>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden h-8 w-8"
            onClick={() => setMobileOpen(false)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        <ScrollArea className="flex-1 min-h-0 px-3 py-4">
          <nav className="space-y-4">
            {/* Favorites */}
            {!collapsed && favoriteItems.length > 0 && (
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground mb-2 uppercase tracking-wider px-2 flex items-center gap-1">
                  <Star className="w-3 h-3 fill-current text-amber-500" />
                  Favorites
                </p>
                <div className="space-y-0.5">
                  {favoriteItems.map(item => (
                    <SidebarItem
                      key={`fav-${item!.href}`}
                      item={item!}
                      active={isActive(pathname, item!.href)}
                      collapsed={false}
                      isFavorite
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Recent */}
            {!collapsed && recentPages.length > 0 && (
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground mb-2 uppercase tracking-wider px-2 flex items-center gap-1">
                  <Pin className="w-3 h-3" />
                  Recent
                </p>
                <div className="space-y-0.5">
                  {recentPages.slice(0, 4).map(p => (
                    <Link
                      key={`rec-${p.href}`}
                      href={p.href}
                      className="block px-2.5 py-1.5 rounded-lg text-xs text-muted-foreground hover:bg-secondary hover:text-foreground transition-all duration-200"
                    >
                      {p.title}
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Main groups */}
            {navGroups.map(group => (
              <div key={group.title}>
                {collapsed ? (
                  <TooltipProvider delayDuration={0}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => toggleGroup(group.title)}
                          className="w-full flex items-center justify-center py-1.5 mb-1"
                        >
                          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                            {group.title[0]}
                          </span>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent side="right" className="font-medium">
                        {group.title}
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                ) : (
                  <button
                    onClick={() => toggleGroup(group.title)}
                    className="w-full flex items-center justify-between px-2 mb-2 group"
                  >
                    <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                      {group.title}
                    </span>
                    <ChevronDown
                      className={cn(
                        "w-3 h-3 text-muted-foreground transition-transform duration-200",
                        openGroups[group.title] && "rotate-180"
                      )}
                    />
                  </button>
                )}

                {(collapsed || openGroups[group.title]) && (
                  <div className="space-y-0.5">
                    {group.items.map(item => (
                      <SidebarItem
                        key={item.href}
                        item={item}
                        active={isActive(pathname, item.href)}
                        collapsed={collapsed}
                      />
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>
        </ScrollArea>

        {/* Footer upgrade card */}
        {!collapsed && (
          <div className="p-3 border-t border-border shrink-0">
            <div className="rounded-xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 p-3 animate-fade-in">
              <p className="text-xs font-semibold text-foreground mb-1">Planna Scale</p>
              <p className="text-[10px] text-muted-foreground mb-2 leading-relaxed">
                Unlock unlimited projects, advanced analytics, and priority support.
              </p>
              <Button
                size="sm"
                className="w-full h-7 text-[11px] bg-primary hover:bg-primary/90"
                asChild
              >
                <Link href="/settings/billing">Upgrade</Link>
              </Button>
            </div>
          </div>
        )}
      </aside>
    </>
  )
}

function SidebarItem({
  item,
  active,
  collapsed,
  isFavorite,
}: {
  item: { label: string; href: string; icon: any; badge?: string }
  active: boolean
  collapsed: boolean
  isFavorite?: boolean
}) {
  const Icon = item.icon
  const setMobileOpen = useUiStore(s => s.setSidebarMobileOpen)
  const pushRecentPage = useUiStore(s => s.pushRecentPage)

  const handleClick = () => {
    setMobileOpen(false)
    pushRecentPage({ href: item.href, title: item.label })
  }

  if (collapsed) {
    return (
      <TooltipProvider delayDuration={0}>
        <Tooltip>
          <TooltipTrigger asChild>
            <Link
              href={item.href}
              onClick={handleClick}
              className={cn(
                "w-full flex items-center justify-center px-2 py-2 rounded-lg text-sm font-medium transition-all duration-300",
                active
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <Icon className="w-4 h-4" />
              {item.badge && active && (
                <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-destructive rounded-full" />
              )}
            </Link>
          </TooltipTrigger>
          <TooltipContent side="right" className="font-medium">
            <div className="flex items-center gap-2">
              {isFavorite && <Star className="w-3 h-3 fill-amber-500 text-amber-500" />}
              {item.label}
              {item.badge && <span className="text-muted-foreground">({item.badge})</span>}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return (
    <Link
      href={item.href}
      onClick={handleClick}
      className={cn(
        "group w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm font-medium transition-all duration-300",
        active
          ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground hover:translate-x-0.5"
      )}
    >
      <Icon className="w-4 h-4 shrink-0" />
      <span className="flex-1 truncate">{item.label}</span>
      {isFavorite && (
        <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
      )}
      {item.badge && (
        <span
          className={cn(
            "text-[10px] font-semibold px-1.5 py-0.5 rounded-full",
            active
              ? "bg-primary-foreground/20 text-primary-foreground"
              : "bg-secondary text-muted-foreground group-hover:bg-background/60"
          )}
        >
          {item.badge}
        </span>
      )}
    </Link>
  )
}

// Helper: active route detection (also matches /tasks/123 as /tasks)
function isActive(pathname: string, href: string): boolean {
  if (href === "/") return pathname === "/"
  if (href === pathname) return true
  // /tasks should also be active when on /tasks/123
  // But /dashboard/productivity should NOT match /dashboard
  // So we match /tasks/something but not /dashboard/something against /dashboard
  if (pathname === href) return true
  // For task detail pages etc.
  if (href !== "/" && pathname.startsWith(href + "/")) {
    // Don't mark /dashboard as active when on /dashboard/productivity
    const hrefParts = href.split("/").filter(Boolean)
    const pathParts = pathname.split("/").filter(Boolean)
    if (hrefParts.length === 1 && pathParts.length > 1) return false
    return true
  }
  return false
}
