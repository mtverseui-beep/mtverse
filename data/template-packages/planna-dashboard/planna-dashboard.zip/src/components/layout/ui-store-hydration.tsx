"use client"

import { useEffect } from "react"
import { useUiStore } from "@/lib/store/ui-store"

/**
 * Manually rehydrates the Zustand persisted UI store AFTER mount.
 * This prevents SSR/client hydration mismatches because:
 * - Server renders with default store state (no localStorage)
 * - Client first render also uses default state (matches server)
 * - After mount, we rehydrate from localStorage and re-render
 *
 * This component renders nothing — it's purely a side-effect trigger.
 */
export function UiStoreHydration() {
  useEffect(() => {
    // Rehydrate the persisted store from localStorage on the client
    useUiStore.persist.rehydrate()
  }, [])
  return null
}
