"use client"

import { cn } from "@/lib/utils"
import { Card } from "@/components/ui/card"
import type { LucideIcon } from "lucide-react"
import { TrendingUp, TrendingDown } from "lucide-react"

interface StatCardProps {
  label: string
  value: string | number
  hint?: string
  icon: LucideIcon
  trend?: { value: number; positive?: boolean }
  iconColor?: string
  className?: string
  loading?: boolean
}

export function StatCard({
  label, value, hint, icon: Icon, trend, iconColor = "bg-primary/15 text-primary", className, loading,
}: StatCardProps) {
  if (loading) {
    return (
      <Card className={cn("p-4 md:p-5", className)}>
        <div className="space-y-3">
          <div className="h-9 w-9 rounded-lg skeleton-shimmer" />
          <div className="h-3 w-20 skeleton-shimmer rounded" />
          <div className="h-7 w-16 skeleton-shimmer rounded" />
        </div>
      </Card>
    )
  }
  return (
    <Card className={cn("p-4 md:p-5 card-lift group", className)}>
      <div className="flex items-start justify-between mb-3">
        <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center transition-transform duration-300 group-hover:scale-110", iconColor)}>
          <Icon className="w-4 h-4" />
        </div>
        {trend && (
          <div className={cn(
            "flex items-center gap-1 text-[11px] font-semibold px-1.5 py-0.5 rounded-md",
            trend.positive !== false
              ? "text-emerald-600 bg-emerald-500/10 dark:text-emerald-400"
              : "text-rose-600 bg-rose-500/10 dark:text-rose-400"
          )}>
            {trend.positive !== false ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(trend.value)}%
          </div>
        )}
      </div>
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">{value}</p>
      {hint && <p className="text-[11px] text-muted-foreground mt-1">{hint}</p>}
    </Card>
  )
}
