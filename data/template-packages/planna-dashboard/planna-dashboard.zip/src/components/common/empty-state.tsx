"use client"

import { cn } from "@/lib/utils"
import { Card } from "@/components/ui/card"
import type { LucideIcon } from "lucide-react"
import { Button } from "@/components/ui/button"

interface EmptyStateProps {
  icon: LucideIcon
  title: string
  description?: string
  action?: { label: string; onClick?: () => void; href?: string }
  secondaryAction?: { label: string; onClick?: () => void; href?: string }
  className?: string
  iconColor?: string
  compact?: boolean
}

export function EmptyState({
  icon: Icon, title, description, action, secondaryAction, className, iconColor = "bg-primary/15 text-primary", compact,
}: EmptyStateProps) {
  return (
    <Card className={cn("flex flex-col items-center justify-center text-center p-8 md:p-12 border-dashed", className)}>
      <div className={cn("rounded-2xl flex items-center justify-center mb-4 transition-transform duration-300 hover:scale-105", iconColor, compact ? "w-12 h-12" : "w-16 h-16")}>
        <Icon className={compact ? "w-5 h-5" : "w-7 h-7"} />
      </div>
      <h3 className={cn("font-semibold text-foreground mb-1", compact ? "text-sm" : "text-base")}>{title}</h3>
      {description && (
        <p className={cn("text-muted-foreground max-w-sm mb-4", compact ? "text-xs" : "text-sm")}>{description}</p>
      )}
      {(action || secondaryAction) && (
        <div className="flex gap-2 flex-wrap justify-center">
          {action && (
            <Button
              size="sm"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={action.onClick}
              asChild={!!action.href}
            >
              {action.href ? <a href={action.href}>{action.label}</a> : action.label}
            </Button>
          )}
          {secondaryAction && (
            <Button
              size="sm"
              variant="outline"
              onClick={secondaryAction.onClick}
              asChild={!!secondaryAction.href}
            >
              {secondaryAction.href ? <a href={secondaryAction.href}>{secondaryAction.label}</a> : secondaryAction.label}
            </Button>
          )}
        </div>
      )}
    </Card>
  )
}
