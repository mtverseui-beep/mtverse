"use client"

import { cn } from "@/lib/utils"
import type { Priority, TaskStatus, ProjectStatus } from "@/types"

// ============================================================
// PRIORITY BADGE
// ============================================================

const priorityConfig: Record<Priority, { label: string; className: string; dot: string }> = {
  low: { label: "Low", className: "bg-sky-500/15 text-sky-600 dark:text-sky-400", dot: "bg-sky-500" },
  medium: { label: "Medium", className: "bg-amber-500/15 text-amber-600 dark:text-amber-400", dot: "bg-amber-500" },
  high: { label: "High", className: "bg-orange-500/15 text-orange-600 dark:text-orange-400", dot: "bg-orange-500" },
  urgent: { label: "Urgent", className: "bg-rose-500/15 text-rose-600 dark:text-rose-400", dot: "bg-rose-500" },
}

export function PriorityBadge({ priority, className }: { priority: Priority; className?: string }) {
  const c = priorityConfig[priority]
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", c.className, className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot)} />
      {c.label}
    </span>
  )
}

// ============================================================
// TASK STATUS BADGE
// ============================================================

const taskStatusConfig: Record<TaskStatus, { label: string; className: string; dot: string }> = {
  backlog: { label: "Backlog", className: "bg-muted text-muted-foreground", dot: "bg-muted-foreground" },
  todo: { label: "To Do", className: "bg-sky-500/15 text-sky-600 dark:text-sky-400", dot: "bg-sky-500" },
  in_progress: { label: "In Progress", className: "bg-amber-500/15 text-amber-600 dark:text-amber-400", dot: "bg-amber-500" },
  review: { label: "Review", className: "bg-violet-500/15 text-violet-600 dark:text-violet-400", dot: "bg-violet-500" },
  done: { label: "Done", className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  blocked: { label: "Blocked", className: "bg-rose-500/15 text-rose-600 dark:text-rose-400", dot: "bg-rose-500" },
}

export function TaskStatusBadge({ status, className }: { status: TaskStatus; className?: string }) {
  const c = taskStatusConfig[status]
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", c.className, className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot)} />
      {c.label}
    </span>
  )
}

// ============================================================
// PROJECT STATUS BADGE
// ============================================================

const projectStatusConfig: Record<ProjectStatus, { label: string; className: string }> = {
  planning: { label: "Planning", className: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  active: { label: "Active", className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  on_hold: { label: "On Hold", className: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  completed: { label: "Completed", className: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
  archived: { label: "Archived", className: "bg-muted text-muted-foreground" },
}

export function ProjectStatusBadge({ status, className }: { status: ProjectStatus; className?: string }) {
  const c = projectStatusConfig[status]
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", c.className, className)}>
      {c.label}
    </span>
  )
}

// ============================================================
// HEALTH BADGE
// ============================================================

export function HealthBadge({ health }: { health: "on_track" | "at_risk" | "off_track" }) {
  const c = {
    on_track: { label: "On Track", className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
    at_risk: { label: "At Risk", className: "bg-amber-500/15 text-amber-600 dark:text-amber-400", dot: "bg-amber-500" },
    off_track: { label: "Off Track", className: "bg-rose-500/15 text-rose-600 dark:text-rose-400", dot: "bg-rose-500" },
  }[health]
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", c.className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot)} />
      {c.label}
    </span>
  )
}

// ============================================================
// ROLE BADGE
// ============================================================

export function RoleBadge({ role }: { role: string }) {
  const map: Record<string, string> = {
    owner: "bg-violet-500/15 text-violet-600 dark:text-violet-400",
    admin: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
    manager: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
    member: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
    viewer: "bg-sky-500/15 text-sky-600 dark:text-sky-400",
    guest: "bg-muted text-muted-foreground",
  }
  return (
    <span className={cn("inline-flex items-center text-[11px] font-semibold px-2 py-0.5 rounded-full capitalize", map[role] ?? map.member)}>
      {role}
    </span>
  )
}

// ============================================================
// LABEL BADGE
// ============================================================

export function LabelBadge({ label }: { label: { name: string; color: string } }) {
  return (
    <span className={cn("inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded", label.color)}>
      {label.name}
    </span>
  )
}
