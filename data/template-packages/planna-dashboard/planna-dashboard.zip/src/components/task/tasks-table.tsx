"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel,
} from "@/components/ui/dropdown-menu"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Star, MoreHorizontal, Filter, SortDesc, LayoutGrid, List,
  Calendar as CalIcon, Download, ChevronLeft, ChevronRight,
  ArrowUpDown, CheckCircle2, Clock, AlertTriangle, MessageSquare, Paperclip,
} from "lucide-react"
import { useTaskStore } from "@/lib/store/task-store"
import { PriorityBadge, TaskStatusBadge, LabelBadge } from "@/components/common/badges"
import { cn, relativeDay, isOverdue } from "@/lib/utils"
import type { Task, TaskStatus, Priority } from "@/types"
import { EmptyState } from "@/components/common/empty-state"

type ViewMode = "list" | "board"
type SortKey = "due" | "priority" | "title" | "updated"

interface TasksTableProps {
  filterPreset?: {
    status?: TaskStatus | "all"
    assignee?: string
    projectId?: string
    completed?: boolean
    overdue?: boolean
    recurring?: boolean
    priority?: Priority | "all"
  }
  title?: string
  showProject?: boolean
}

const priorityWeight: Record<Priority, number> = { urgent: 0, high: 1, medium: 2, low: 3 }

export function TasksTable({ filterPreset, title, showProject = true }: TasksTableProps) {
  const tasks = useTaskStore(s => s.tasks)
  const toggleStar = useTaskStore(s => s.toggleTaskStar)
  const [view, setView] = useState<ViewMode>("list")
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<TaskStatus | "all">(filterPreset?.status ?? "all")
  const [priorityFilter, setPriorityFilter] = useState<Priority | "all">(filterPreset?.priority ?? "all")
  const [sortKey, setSortKey] = useState<SortKey>("due")
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc")
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [page, setPage] = useState(1)
  const pageSize = 12

  // Apply filters
  const filtered = useMemo(() => {
    let result = [...tasks]
    if (filterPreset?.assignee) result = result.filter(t => t.assignee === filterPreset.assignee)
    if (filterPreset?.projectId) result = result.filter(t => t.projectId === filterPreset.projectId)
    if (filterPreset?.completed) result = result.filter(t => t.status === "done")
    if (filterPreset?.overdue) result = result.filter(t => isOverdue(t.dueDate) && t.status !== "done")
    if (filterPreset?.recurring) result = result.filter(t => t.recurring && t.recurring !== "none")
    if (statusFilter !== "all") result = result.filter(t => t.status === statusFilter)
    if (priorityFilter !== "all") result = result.filter(t => t.priority === priorityFilter)
    if (search) {
      const q = search.toLowerCase()
      result = result.filter(t =>
        t.title.toLowerCase().includes(q) ||
        t.key.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.assignee?.toLowerCase().includes(q)
      )
    }
    // Sort
    result.sort((a, b) => {
      let cmp = 0
      if (sortKey === "due") cmp = (a.dueDate ?? "9999").localeCompare(b.dueDate ?? "9999")
      else if (sortKey === "priority") cmp = priorityWeight[a.priority] - priorityWeight[b.priority]
      else if (sortKey === "title") cmp = a.title.localeCompare(b.title)
      else if (sortKey === "updated") cmp = b.updatedAt.localeCompare(a.updatedAt)
      return sortDir === "asc" ? cmp : -cmp
    })
    return result
  }, [tasks, filterPreset, search, statusFilter, priorityFilter, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize)

  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir(d => d === "asc" ? "desc" : "asc")
    else { setSortKey(k); setSortDir("asc") }
  }

  const toggleSelected = (id: string) => {
    const next = new Set(selected)
    if (next.has(id)) next.delete(id); else next.add(id)
    setSelected(next)
  }

  const allSelected = paged.length > 0 && paged.every(t => selected.has(t.id))
  const toggleAll = () => {
    if (allSelected) setSelected(new Set())
    else setSelected(new Set(paged.map(t => t.id)))
  }

  return (
    <div className="space-y-3">
      {/* Filter bar */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Input
            placeholder="Search tasks…"
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1) }}
            className="h-9 pl-3 text-sm"
          />
        </div>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v as any); setPage(1) }}>
          <SelectTrigger className="h-9 w-[130px] text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All status</SelectItem>
            <SelectItem value="backlog">Backlog</SelectItem>
            <SelectItem value="todo">To Do</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="review">Review</SelectItem>
            <SelectItem value="done">Done</SelectItem>
            <SelectItem value="blocked">Blocked</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={(v) => { setPriorityFilter(v as any); setPage(1) }}>
          <SelectTrigger className="h-9 w-[130px] text-xs"><SelectValue placeholder="Priority" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All priority</SelectItem>
            <SelectItem value="urgent">Urgent</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <Filter className="w-3.5 h-3.5" /> More
        </Button>
        <div className="flex items-center gap-0.5 p-0.5 bg-card border border-border rounded-lg">
          <Button variant={view === "list" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("list")}>
            <List className="w-3.5 h-3.5" />
          </Button>
          <Button variant={view === "board" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("board")}>
            <LayoutGrid className="w-3.5 h-3.5" />
          </Button>
        </div>
        <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <Download className="w-3.5 h-3.5" /> Export
        </Button>
      </div>

      {/* Bulk actions bar */}
      {selected.size > 0 && (
        <div className="flex items-center gap-2 p-2 rounded-lg bg-primary/10 border border-primary/20 animate-fade-in">
          <span className="text-xs font-semibold text-primary">{selected.size} selected</span>
          <div className="h-4 w-px bg-border" />
          <Button size="sm" variant="ghost" className="h-7 text-xs gap-1">
            <CheckCircle2 className="w-3 h-3" /> Mark done
          </Button>
          <Button size="sm" variant="ghost" className="h-7 text-xs gap-1">
            <ArrowUpDown className="w-3 h-3" /> Reassign
          </Button>
          <Button size="sm" variant="ghost" className="h-7 text-xs gap-1 text-destructive">
            <AlertTriangle className="w-3 h-3" /> Delete
          </Button>
          <Button size="sm" variant="ghost" className="h-7 text-xs ml-auto" onClick={() => setSelected(new Set())}>
            Clear
          </Button>
        </div>
      )}

      {/* Content */}
      {paged.length === 0 ? (
        <EmptyState
          icon={CheckCircle2}
          title="No tasks found"
          description="Try adjusting your filters or create a new task to get started."
          action={{ label: "Create task", href: "/tasks" }}
          compact
        />
      ) : view === "list" ? (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border bg-muted/30">
                  <th className="py-2.5 pl-3 pr-2 w-8">
                    <Checkbox checked={allSelected} onCheckedChange={toggleAll} aria-label="Select all" />
                  </th>
                  <th className="py-2.5 px-2 w-8" />
                  <th className="py-2.5 px-2 font-medium cursor-pointer select-none hover:text-foreground" onClick={() => toggleSort("title")}>
                    <div className="flex items-center gap-1">Task <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                  <th className="py-2.5 px-2 font-medium">Status</th>
                  <th className="py-2.5 px-2 font-medium">Priority</th>
                  <th className="py-2.5 px-2 font-medium">Assignee</th>
                  {showProject && <th className="py-2.5 px-2 font-medium">Project</th>}
                  <th className="py-2.5 px-2 font-medium cursor-pointer select-none hover:text-foreground" onClick={() => toggleSort("due")}>
                    <div className="flex items-center gap-1">Due <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                  <th className="py-2.5 px-2 w-10" />
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {paged.map(t => (
                  <tr
                    key={t.id}
                    className={cn(
                      "hover:bg-secondary/30 transition-colors group",
                      selected.has(t.id) && "bg-primary/5"
                    )}
                  >
                    <td className="py-2.5 pl-3 pr-2">
                      <Checkbox
                        checked={selected.has(t.id)}
                        onCheckedChange={() => toggleSelected(t.id)}
                        aria-label={`Select ${t.title}`}
                      />
                    </td>
                    <td className="py-2.5 px-2">
                      <button onClick={() => toggleStar(t.id)} className="text-muted-foreground hover:text-amber-500 transition-colors">
                        <Star className={cn("w-3.5 h-3.5", t.starred && "fill-amber-500 text-amber-500")} />
                      </button>
                    </td>
                    <td className="py-2.5 px-2 max-w-md">
                      <Link href={`/tasks/${t.id}`} className="block">
                        <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1">
                          {t.title}
                        </p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                          {t.labels.slice(0, 2).map(l => <LabelBadge key={l.id} label={l} />)}
                          {t.subtasks.length > 0 && (
                            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                              <CheckCircle2 className="w-2.5 h-2.5" />
                              {t.subtasks.filter(s => s.done).length}/{t.subtasks.length}
                            </span>
                          )}
                          {t.comments.length > 0 && (
                            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                              <MessageSquare className="w-2.5 h-2.5" /> {t.comments.length}
                            </span>
                          )}
                          {t.attachments > 0 && (
                            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                              <Paperclip className="w-2.5 h-2.5" /> {t.attachments}
                            </span>
                          )}
                        </div>
                      </Link>
                    </td>
                    <td className="py-2.5 px-2"><TaskStatusBadge status={t.status} /></td>
                    <td className="py-2.5 px-2"><PriorityBadge priority={t.priority} /></td>
                    <td className="py-2.5 px-2">
                      {t.assigneeAvatar ? (
                        <Avatar className="w-5 h-5"><AvatarImage src={t.assigneeAvatar} alt={t.assignee ?? ""} /><AvatarFallback className="text-[9px]">{t.assignee?.[0]}</AvatarFallback></Avatar>
                      ) : <span className="text-[10px] text-muted-foreground">Unassigned</span>}
                    </td>
                    {showProject && (
                      <td className="py-2.5 px-2">
                        <Link href={`/projects/${t.projectId}`} className="flex items-center gap-1.5">
                          <span className={cn("w-2 h-2 rounded-full", t.projectColor)} />
                          <span className="text-[10px] text-muted-foreground hover:text-foreground transition-colors">{t.projectName}</span>
                        </Link>
                      </td>
                    )}
                    <td className="py-2.5 px-2">
                      {t.dueDate ? (
                        <span className={cn(
                          "text-[10px] font-medium",
                          isOverdue(t.dueDate) && t.status !== "done" ? "text-rose-600 dark:text-rose-400" : "text-muted-foreground"
                        )}>
                          {relativeDay(t.dueDate)}
                        </span>
                      ) : <span className="text-[10px] text-muted-foreground">—</span>}
                    </td>
                    <td className="py-2.5 px-2">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                            <MoreHorizontal className="w-3.5 h-3.5" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild><Link href={`/tasks/${t.id}`}>Open</Link></DropdownMenuItem>
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Assign</DropdownMenuItem>
                          <DropdownMenuItem>Duplicate</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-3 py-2 border-t border-border">
            <p className="text-[11px] text-muted-foreground">
              {filtered.length} tasks · showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, filtered.length)}
            </p>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon" className="h-7 w-7" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
                <ChevronLeft className="w-3.5 h-3.5" />
              </Button>
              <span className="text-xs text-muted-foreground px-2">{page} / {totalPages}</span>
              <Button variant="outline" size="icon" className="h-7 w-7" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>
                <ChevronRight className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        </Card>
      ) : (
        // Board view (compact)
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {(["todo", "in_progress", "review", "done"] as TaskStatus[]).map(col => {
            const colTasks = filtered.filter(t => t.status === col)
            return (
              <div key={col} className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <p className="text-xs font-semibold text-foreground capitalize">{col.replace("_", " ")}</p>
                  <Badge variant="outline" className="text-[10px]">{colTasks.length}</Badge>
                </div>
                <div className="space-y-2">
                  {colTasks.slice(0, 6).map(t => (
                    <Link key={t.id} href={`/tasks/${t.id}`} className="block p-2.5 rounded-lg border border-border bg-card hover:border-primary/30 hover:shadow-sm transition-all group">
                      <p className="text-xs font-medium line-clamp-2 group-hover:text-primary transition-colors">{t.title}</p>
                      <div className="flex items-center gap-1.5 mt-2">
                        <PriorityBadge priority={t.priority} />
                        {t.assigneeAvatar && <Avatar className="w-4 h-4 ml-auto"><AvatarImage src={t.assigneeAvatar} alt={t.assignee ?? ""} /><AvatarFallback className="text-[8px]">{t.assignee?.[0]}</AvatarFallback></Avatar>}
                      </div>
                    </Link>
                  ))}
                  {colTasks.length === 0 && (
                    <div className="p-3 rounded-lg border border-dashed border-border text-center text-[10px] text-muted-foreground">
                      No tasks
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
