"use client"

import { cn } from "@/lib/utils"
import { Card } from "@/components/ui/card"
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  RadialBarChart, RadialBar, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts"
import { useState } from "react"
import { Maximize2, Download, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog"

// Planna green chart palette
export const CHART_COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"]

// ============================================================
// COMMON CHART CARD WRAPPER
// ============================================================

interface ChartCardProps {
  title: string
  subtitle?: string
  action?: React.ReactNode
  className?: string
  children: React.ReactNode
  onExport?: () => void
  fullscreen?: boolean
}

export function ChartCard({ title, subtitle, action, className, children, onExport, fullscreen: canFullscreen = true }: ChartCardProps) {
  const [fs, setFs] = useState(false)
  return (
    <>
      <Card className={cn("p-4 md:p-5 card-lift", className)}>
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground">{title}</h3>
            {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
          </div>
          <div className="flex items-center gap-1">
            {action}
            {onExport && (
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onExport}>
                <Download className="w-3.5 h-3.5" />
              </Button>
            )}
            {canFullscreen && (
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setFs(true)}>
                <Maximize2 className="w-3.5 h-3.5" />
              </Button>
            )}
          </div>
        </div>
        {children}
      </Card>
      <Dialog open={fs} onOpenChange={setFs}>
        <DialogContent className="max-w-5xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
          </DialogHeader>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              {/* children re-rendered at larger size */}
              <></>
            </ResponsiveContainer>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

// ============================================================
// CUSTOM TOOLTIP
// ============================================================

interface TooltipPayloadItem {
  name?: string
  value?: number | string
  color?: string
  dataKey?: string
  payload?: Record<string, any>
}

function PlannaTooltip({ active, payload, label, formatter }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-popover border border-border rounded-lg shadow-lg p-3 text-xs animate-fade-in">
      {label && <p className="font-semibold text-foreground mb-1.5">{label}</p>}
      <div className="space-y-1">
        {payload.map((p: TooltipPayloadItem, i: number) => (
          <div key={i} className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
            <span className="text-muted-foreground capitalize">{p.name ?? p.dataKey}</span>
            <span className="ml-auto font-semibold text-foreground">
              {formatter ? formatter(p.value, p) : p.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

export const plannaTooltip = <PlannaTooltip />

// ============================================================
// AREA CHART (productivity trend)
// ============================================================

interface AreaChartProps {
  data: any[]
  xKey: string
  series: { key: string; name: string; color?: string; gradient?: boolean }[]
  height?: number
  showGrid?: boolean
  showLegend?: boolean
}

export function PlannaAreaChart({ data, xKey, series, height = 280, showGrid = true, showLegend = true }: AreaChartProps) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
        <defs>
          {series.map((s, i) => (
            <linearGradient key={s.key} id={`grad-${s.key}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={s.color ?? CHART_COLORS[i]} stopOpacity={0.3} />
              <stop offset="100%" stopColor={s.color ?? CHART_COLORS[i]} stopOpacity={0} />
            </linearGradient>
          ))}
        </defs>
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />}
        <XAxis dataKey={xKey} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
        <Tooltip content={<PlannaTooltip />} />
        {showLegend && <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />}
        {series.map((s, i) => (
          <Area
            key={s.key}
            type="monotone"
            dataKey={s.key}
            name={s.name}
            stroke={s.color ?? CHART_COLORS[i]}
            strokeWidth={2}
            fill={`url(#grad-${s.key})`}
            animationDuration={600}
            animationBegin={i * 100}
          />
        ))}
      </AreaChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// BAR CHART
// ============================================================

interface BarChartProps {
  data: any[]
  xKey: string
  series: { key: string; name: string; color?: string; stackId?: string }[]
  height?: number
  showGrid?: boolean
  showLegend?: boolean
  horizontal?: boolean
}

export function PlannaBarChart({ data, xKey, series, height = 280, showGrid = true, showLegend = true, horizontal = false }: BarChartProps) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} layout={horizontal ? "vertical" : "horizontal"} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={horizontal} horizontal={!horizontal} />}
        {horizontal ? (
          <>
            <XAxis type="number" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
            <YAxis type="category" dataKey={xKey} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} width={80} />
          </>
        ) : (
          <>
            <XAxis dataKey={xKey} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
          </>
        )}
        <Tooltip content={<PlannaTooltip />} cursor={{ fill: "var(--muted)", opacity: 0.4 }} />
        {showLegend && <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />}
        {series.map((s, i) => (
          <Bar
            key={s.key}
            dataKey={s.key}
            name={s.name}
            stackId={s.stackId}
            fill={s.color ?? CHART_COLORS[i]}
            radius={s.stackId ? [0, 0, 0, 0] : [6, 6, 0, 0]}
            animationDuration={600}
            animationBegin={i * 100}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// LINE CHART
// ============================================================

interface LineChartProps {
  data: any[]
  xKey: string
  series: { key: string; name: string; color?: string; dashed?: boolean }[]
  height?: number
  showGrid?: boolean
  showLegend?: boolean
}

export function PlannaLineChart({ data, xKey, series, height = 280, showGrid = true, showLegend = true }: LineChartProps) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />}
        <XAxis dataKey={xKey} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
        <Tooltip content={<PlannaTooltip />} />
        {showLegend && <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />}
        {series.map((s, i) => (
          <Line
            key={s.key}
            type="monotone"
            dataKey={s.key}
            name={s.name}
            stroke={s.color ?? CHART_COLORS[i]}
            strokeWidth={2}
            strokeDasharray={s.dashed ? "5 5" : undefined}
            dot={{ r: 3, fill: s.color ?? CHART_COLORS[i], strokeWidth: 0 }}
            activeDot={{ r: 5 }}
            animationDuration={600}
            animationBegin={i * 100}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  )
}

// ============================================================
// DONUT / PIE CHART
// ============================================================

interface DonutChartProps {
  data: { name: string; value: number; color?: string }[]
  height?: number
  showLegend?: boolean
  centerLabel?: string
  centerValue?: string
}

export function PlannaDonutChart({ data, height = 280, showLegend = true, centerLabel, centerValue }: DonutChartProps) {
  return (
    <div className="relative">
      <ResponsiveContainer width="100%" height={height}>
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={2}
            animationDuration={600}
          >
            {data.map((d, i) => (
              <Cell key={i} fill={d.color ?? CHART_COLORS[i % CHART_COLORS.length]} stroke="var(--card)" strokeWidth={2} />
            ))}
          </Pie>
          <Tooltip content={<PlannaTooltip />} />
          {showLegend && <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />}
        </PieChart>
      </ResponsiveContainer>
      {(centerLabel || centerValue) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          {centerValue && <p className="text-2xl font-bold text-foreground">{centerValue}</p>}
          {centerLabel && <p className="text-xs text-muted-foreground">{centerLabel}</p>}
        </div>
      )}
    </div>
  )
}

// ============================================================
// RADIAL CHART (progress / single metric)
// ============================================================

interface RadialChartProps {
  value: number // 0-100
  label?: string
  size?: number
  color?: string
}

export function PlannaRadialChart({ value, label, size = 160, color }: RadialChartProps) {
  const data = [{ name: "value", value, fill: color ?? "var(--chart-1)" }]
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart innerRadius="70%" outerRadius="100%" data={data} startAngle={90} endAngle={90 - (360 * value) / 100}>
          <RadialBar background={{ fill: "var(--muted)" }} dataKey="value" cornerRadius={20} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <p className="text-2xl font-bold text-foreground">{value}%</p>
        {label && <p className="text-[10px] text-muted-foreground">{label}</p>}
      </div>
    </div>
  )
}

// ============================================================
// HEATMAP (focus sessions, 7×24)
// ============================================================

export function PlannaHeatmap({
  data,
  xlabel,
}: {
  data: number[][]
  xlabel?: boolean
}) {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  const cellColor = (v: number) => {
    if (v === 0) return "var(--muted)"
    if (v === 1) return "color-mix(in oklch, var(--chart-1) 25%, var(--card))"
    if (v === 2) return "color-mix(in oklch, var(--chart-1) 50%, var(--card))"
    if (v === 3) return "color-mix(in oklch, var(--chart-1) 75%, var(--card))"
    return "var(--chart-1)"
  }
  return (
    <div className="w-full overflow-x-auto no-scrollbar">
      <div className="min-w-[640px]">
        <div className="flex">
          <div className="w-10 shrink-0" />
          <div className="flex-1 grid gap-0.5" style={{ gridTemplateColumns: "repeat(24, minmax(0, 1fr))" }}>
            {Array.from({ length: 24 }).map((_, h) => (
              <div key={h} className="text-[9px] text-muted-foreground text-center">
                {h % 3 === 0 ? `${h}` : ""}
              </div>
            ))}
          </div>
        </div>
        {data.map((row, d) => (
          <div key={d} className="flex items-center mt-0.5">
            <div className="w-10 shrink-0 text-[10px] text-muted-foreground">{days[d]}</div>
            <div className="flex-1 grid gap-0.5" style={{ gridTemplateColumns: "repeat(24, minmax(0, 1fr))" }}>
              {row.map((v, h) => (
                <div
                  key={h}
                  className="aspect-square rounded-sm transition-all duration-200 hover:ring-2 hover:ring-primary/40 hover:scale-110 cursor-pointer"
                  style={{ background: cellColor(v) }}
                  title={`${days[d]} ${h}:00 — ${v} sessions`}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ============================================================
// MINI SPARKLINE
// ============================================================

export function Sparkline({ data, color = "var(--chart-1)", height = 40 }: { data: number[]; color?: string; height?: number }) {
  const chartData = data.map((v, i) => ({ x: i, y: v }))
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={chartData} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id={`spark-${color}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.3} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area type="monotone" dataKey="y" stroke={color} strokeWidth={2} fill={`url(#spark-${color})`} animationDuration={400} />
      </AreaChart>
    </ResponsiveContainer>
  )
}
