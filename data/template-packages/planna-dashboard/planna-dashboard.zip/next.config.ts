import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: false,
  // Allow preview subdomains to access dev server assets
  allowedDevOrigins: [
    "https://preview-chat-e5c93c33-df1a-44c3-b060-190c7af98b86.space-z.ai",
    "*.space-z.ai",
  ],
  // Production: be strict about types — fail build on TS errors
  typescript: {
    ignoreBuildErrors: false,
  },
  // Vercel-friendly image config (allow Unsplash avatars/illustrations)
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "ui-avatars.com" },
    ],
  },
};

export default nextConfig;
