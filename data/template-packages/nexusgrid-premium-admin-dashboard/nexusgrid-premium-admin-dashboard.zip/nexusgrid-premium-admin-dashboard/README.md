# NexusGrid — Premium Next.js Admin Dashboard Kit

> A production-ready, commercial-grade admin dashboard built with Next.js 16, React 19, TypeScript, Tailwind CSS 4, and shadcn/ui. 133+ handcrafted pages, 15 unique dashboards, advanced tables, charts, forms, and full dark/light mode.

## Quick Start

```bash
# Install dependencies (bun recommended, npm/yarn also work)
bun install
# or: npm install

# Start the dev server
bun run dev
# or: npm run dev

# Open http://localhost:3000
```

The app redirects to `/dashboards/ecommerce` on first load. Press **⌘K / Ctrl+K** anywhere to open the command palette and jump to any of the 133 pages.

## Production Build

```bash
bun run build
bun run start
```

## Deploy to Vercel

1. Push this project to a GitHub/GitLab/Bitbucket repository.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Vercel auto-detects Next.js — no extra configuration needed.
4. Click **Deploy**. The build runs `next build` automatically.

The `next.config.ts` is already Vercel-ready (no `output: "standalone"`, image remote patterns for Unsplash, optimized package imports).

## What's Inside

### 15 Unique Dashboards
Ecommerce · Analytics · CRM · Sales Ops · Finance · Marketing · Projects · HR · Logistics · Healthcare · Education · Real Estate · Booking · SaaS Metrics · Support

Each dashboard has a distinct visual identity — unique KPI card motifs, unique chart compositions, domain-specific data, and unique layout patterns. No two dashboards look the same.

### Module Pages (118 pages)

| Module | Pages | Highlights |
|---|---|---|
| **Ecommerce** | 8 | Orders, Products (grid+table), Inventory, Customers, Categories, Coupons, Refunds, Abandoned Carts |
| **CRM & Sales** | 10 | Leads, Deals, Accounts, Contacts, Pipeline Board (Kanban), Forecasting, Quota, Activities, Territories, Commissions |
| **Projects** | 7 | Projects, Tasks, Kanban (DnD), Sprint Board, Roadmap (Gantt), Timesheets, Workload, Files |
| **Apps** | 10 | Calendar (4 views), Chat (3-col), Mailbox, Notes, File Manager, Todo, Invoices, POS (full-screen), Monitoring, Reports |
| **Tables** | 8 | Basic, Advanced, Sortable, Filterable, Data Grid (Excel-like), Editable, Bulk Actions, Export |
| **Forms** | 10 | Elements, Layouts, Validation (RHF+zod), Wizard (4-step), File Upload, Rich Text, Date & Time, Select & Combobox, Payment (3D card flip), Settings |
| **UI Components** | 17 | Buttons, Badges, Alerts, Avatars, Cards, Modals, Drawers, Dropdowns, Tabs, Accordions, Tooltips, Popovers, Progress, Skeletons, Toasts, Charts, Icons (130+) |
| **Account** | 5 | Profile, Settings, Notifications, Security, Sessions |
| **Admin** | 11 | Team, Roles, Permissions, Audit Logs, API Keys, Webhooks, Integrations, Billing, Subscription, Invoices, Workspace |
| **Auth** | 9 | Sign In, Sign Up, Forgot Password, Reset Password, Verify Email (OTP), 2FA, Lock Screen, Invite Team, Onboarding (4-step) |
| **Errors** | 10 | 401, 403, 404, 408, 429, 500, 503, Offline, Maintenance, Coming Soon — each with unique custom SVG illustration |
| **Content** | 11 | Pricing, FAQ, Help Center, Contact Support, Changelog, Documentation, Search Results, Empty States, Loading States, Terms, Privacy |

### Premium Foundation

- **New brand identity**: NexusGrid (custom SVG logo + favicon)
- **New premium color system**: emerald-teal primary, warm-gold accent, custom success/warning/info/destructive tokens, harmonious chart palette
- **Complete dark/light theme**: no hydration flicker, persisted in localStorage, default dark for premium feel
- **Command palette** (⌘K / Ctrl+K): search all 133 pages, quick actions, recent pages, theme switching
- **Premium sidebar**: 13 grouped nav sections, collapsible with tooltips, recent pages, mobile drawer, smooth animations
- **Premium header**: breadcrumbs, command palette trigger, notifications popover, messages, theme toggle, quick create dropdown, user menu
- **Reusable components**: KPI cards with sparklines, StatusBadge, EmptyState/LoadingState/ErrorState, custom DataTable with sort/filter/search/pagination/selection/bulk-actions/export/column-visibility/density
- **Custom chart system**: Area, Line, Bar, Donut, Radial, Radar — all theme-aware
- **Global not-found, loading, error boundaries**

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript 5 (strict) |
| UI | React 19, Tailwind CSS 4, shadcn/ui (New York) |
| Icons | lucide-react |
| Charts | recharts |
| Forms | react-hook-form + zod |
| Tables | custom DataTable (sorting, filtering, selection, export) |
| Notifications | sonner |
| Animations | framer-motion, tw-animate-css, custom CSS |
| Database | Prisma ORM (SQLite client, optional) |
| State | Zustand, TanStack Query (available) |

## Project Structure

```
src/
├── app/
│   ├── (admin)/            # Admin-layout pages (sidebar + header)
│   │   ├── dashboards/     # 15 unique dashboards
│   │   ├── ecommerce/      # 8 ecommerce pages
│   │   ├── crm/            # 10 CRM/sales pages
│   │   ├── projects/       # 7 project pages
│   │   ├── apps/           # 10 app pages
│   │   ├── tables/         # 8 table showcases
│   │   ├── forms/          # 10 form showcases
│   │   ├── ui/             # 17 UI component galleries
│   │   ├── account/        # 5 account pages
│   │   ├── admin/          # 11 admin pages
│   │   ├── pricing/ ...    # 11 content/utility pages
│   │   └── layout.tsx      # Wraps in AdminShell
│   ├── auth/               # 9 full-screen auth pages
│   ├── errors/             # 10 full-screen error pages
│   ├── layout.tsx          # Root layout (theme + providers)
│   ├── page.tsx            # Redirects to /dashboards/ecommerce
│   ├── not-found.tsx       # Custom 404
│   ├── loading.tsx         # Global loading
│   └── error.tsx           # Global error boundary
├── components/
│   ├── providers/          # Theme, CommandPalette, RecentPages
│   ├── layout/             # AdminShell, AppSidebar, AppHeader
│   ├── common/             # PageHeader, KpiCard, StatusBadge, States, BrandLogo
│   ├── charts/             # AreaTrendChart, LineTrendChart, BarTrendChart, DonutChart, RadialProgress, RadarComparison
│   ├── tables/             # DataTable (reusable advanced data table)
│   ├── ui/                 # Full shadcn/ui kit
│   └── auth/               # AuthShell, PasswordStrengthBar
├── config/
│   └── navigation.ts       # Drives sidebar + command palette
├── data/
│   └── mock-data.ts        # Centralized realistic mock data
└── lib/
    └── utils.ts            # cn() helper
```

## Customization Guide

### Change the brand
- Edit `src/components/common/brand-logo.tsx` to change the logo SVG
- Edit `public/favicon.svg` for the favicon
- Edit `src/app/layout.tsx` for metadata (title, description, OG tags)

### Change the color system
All colors live in `src/app/globals.css` under `:root` (light) and `.dark` (dark) blocks. The primary token is `--primary` (emerald by default). Chart colors are `--chart-1` through `--chart-5`.

### Add a new page
1. Create `src/app/(admin)/your-module/your-page/page.tsx`
2. Add a nav item to `src/config/navigation.ts` (under the right group, or create a new group)
3. The sidebar, command palette, and breadcrumbs all update automatically.

### Add a new dashboard
1. Create `src/app/(admin)/dashboards/your-dashboard/page.tsx`
2. Add to the Dashboards group in `src/config/navigation.ts`
3. Use the shared components: `PageHeader`, `KpiCard`, chart components.

## Quality Checklist

- 133 real App Router routes (no fake tab-switching)
- All routes return HTTP 200
- Zero hydration errors (SSR-safe localStorage, deterministic data)
- Zero TypeScript errors in project source
- Mobile responsive on every page
- Dark/light theme works on every page
- Cursor pointer on all interactive elements (CSS-level)
- Realistic mock data (no Lorem Ipsum, no placeholders)
- Lucide SVG icons throughout (no emojis)
- Unsplash HD images for avatars/products/banners
- Premium animations (fade-in, scale-in, shimmer, pulse)
- Global not-found, loading, error boundaries

## License

This is a commercial template. The original TailAdmin free template (in `workspace/`) retains its MIT license. NexusGrid branding, design, and all custom code are proprietary.

## Credits

Built on top of the TailAdmin free Next.js dashboard, completely transformed into NexusGrid — a premium commercial admin dashboard kit.
