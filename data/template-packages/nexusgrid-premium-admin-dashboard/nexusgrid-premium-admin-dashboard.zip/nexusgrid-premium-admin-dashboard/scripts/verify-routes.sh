#!/bin/bash
# Comprehensive route verification for NexusGrid
# Tests all 133 routes and reports failures

BASE_URL="http://localhost:3000"
TOTAL=0
PASSED=0
FAILED=0
EMPTY=0
declare -a FAILED_ROUTES
declare -a EMPTY_ROUTES

# Collect all routes from the app directory
ROUTES=(
  "/"
  # 15 Dashboards
  "/dashboards/ecommerce" "/dashboards/analytics" "/dashboards/crm" "/dashboards/sales-ops"
  "/dashboards/finance" "/dashboards/marketing" "/dashboards/projects" "/dashboards/hr"
  "/dashboards/logistics" "/dashboards/healthcare" "/dashboards/education" "/dashboards/real-estate"
  "/dashboards/booking" "/dashboards/saas" "/dashboards/support"
  # 8 Ecommerce
  "/ecommerce/orders" "/ecommerce/products" "/ecommerce/inventory" "/ecommerce/customers"
  "/ecommerce/categories" "/ecommerce/coupons" "/ecommerce/refunds" "/ecommerce/abandoned-carts"
  # 10 CRM
  "/crm/leads" "/crm/deals" "/crm/accounts" "/crm/contacts" "/crm/pipeline"
  "/crm/forecasting" "/crm/quota" "/crm/activities" "/crm/territories" "/crm/commissions"
  # 7 Projects
  "/projects" "/projects/tasks" "/projects/kanban" "/projects/sprints" "/projects/roadmap"
  "/projects/timesheets" "/projects/workload" "/projects/files"
  # 10 Apps
  "/apps/calendar" "/apps/chat" "/apps/mailbox" "/apps/notes" "/apps/file-manager"
  "/apps/todo" "/apps/invoices" "/apps/pos" "/apps/monitoring" "/apps/reports"
  # 8 Tables
  "/tables/basic" "/tables/advanced" "/tables/sortable" "/tables/filterable"
  "/tables/data-grid" "/tables/editable" "/tables/bulk-actions" "/tables/export"
  # 10 Forms
  "/forms/elements" "/forms/layouts" "/forms/validation" "/forms/wizard" "/forms/file-upload"
  "/forms/rich-text" "/forms/date-time" "/forms/select" "/forms/payment" "/forms/settings"
  # 17 UI
  "/ui/buttons" "/ui/badges" "/ui/alerts" "/ui/avatars" "/ui/cards" "/ui/modals" "/ui/drawers"
  "/ui/dropdowns" "/ui/tabs" "/ui/accordions" "/ui/tooltips" "/ui/popovers" "/ui/progress"
  "/ui/skeletons" "/ui/toasts" "/ui/charts" "/ui/icons"
  # 5 Account
  "/account/profile" "/account/settings" "/account/notifications" "/account/security" "/account/sessions"
  # 11 Admin
  "/admin/team" "/admin/roles" "/admin/permissions" "/admin/audit-logs" "/admin/api-keys"
  "/admin/webhooks" "/admin/integrations" "/admin/billing" "/admin/subscription"
  "/admin/invoices" "/admin/workspace"
  # 9 Auth
  "/auth/signin" "/auth/signup" "/auth/forgot-password" "/auth/reset-password" "/auth/verify-email"
  "/auth/2fa" "/auth/lock-screen" "/auth/invite" "/auth/onboarding"
  # 10 Errors
  "/errors/401" "/errors/403" "/errors/404" "/errors/408" "/errors/429" "/errors/500"
  "/errors/503" "/errors/offline" "/errors/maintenance" "/errors/coming-soon"
  # 11 Content/Utility
  "/pricing" "/faq" "/help-center" "/contact-support" "/changelog" "/documentation"
  "/search-results" "/empty-states" "/loading-states" "/terms" "/privacy"
  # 404
  "/nonexistent-page-xyz"
)

echo "=========================================="
echo "NexusGrid Comprehensive Route Verification"
echo "=========================================="
echo "Testing ${#ROUTES[@]} routes..."
echo ""

for route in "${ROUTES[@]}"; do
  TOTAL=$((TOTAL + 1))
  RESPONSE=$(curl -s -o /tmp/route-test.html -w "%{http_code}|%{size_download}" --max-time 30 "${BASE_URL}${route}")
  HTTP_CODE=$(echo "$RESPONSE" | cut -d'|' -f1)
  SIZE=$(echo "$RESPONSE" | cut -d'|' -f2)

  # 404 for nonexistent page is expected
  if [[ "$route" == "/nonexistent-page-xyz" ]]; then
    if [[ "$HTTP_CODE" == "404" ]]; then
      PASSED=$((PASSED + 1))
      printf "  ✓  %-40s  HTTP %s  (404 expected)\n" "$route" "$HTTP_CODE"
    else
      FAILED=$((FAILED + 1))
      FAILED_ROUTES+=("$route (expected 404, got $HTTP_CODE)")
      printf "  ✗  %-40s  HTTP %s  (expected 404)\n" "$route" "$HTTP_CODE"
    fi
    continue
  fi

  if [[ "$HTTP_CODE" == "200" ]]; then
    # Check for empty page (less than 1500 bytes usually means error/empty)
    if [[ "$SIZE" -lt 1500 ]]; then
      EMPTY=$((EMPTY + 1))
      EMPTY_ROUTES+=("$route (size: ${SIZE}b)")
      printf "  ⚠  %-40s  HTTP %s  size=%sb (suspiciously small)\n" "$route" "$HTTP_CODE" "$SIZE"
    else
      PASSED=$((PASSED + 1))
      printf "  ✓  %-40s  HTTP %s  size=%sb\n" "$route" "$HTTP_CODE" "$SIZE"
    fi
  else
    FAILED=$((FAILED + 1))
    FAILED_ROUTES+=("$route (HTTP $HTTP_CODE)")
    printf "  ✗  %-40s  HTTP %s  size=%sb\n" "$route" "$HTTP_CODE" "$SIZE"
  fi
done

echo ""
echo "=========================================="
echo "Summary"
echo "=========================================="
echo "Total tested: $TOTAL"
echo "Passed:       $PASSED"
echo "Failed:       $FAILED"
echo "Empty:        $EMPTY"
echo ""

if [[ ${#FAILED_ROUTES[@]} -gt 0 ]]; then
  echo "Failed routes:"
  for r in "${FAILED_ROUTES[@]}"; do
    echo "  - $r"
  done
fi

if [[ ${#EMPTY_ROUTES[@]} -gt 0 ]]; then
  echo ""
  echo "Suspiciously small pages (potential empty):"
  for r in "${EMPTY_ROUTES[@]}"; do
    echo "  - $r"
  done
fi

echo ""
if [[ $FAILED -eq 0 && $EMPTY -eq 0 ]]; then
  echo "✓ All routes pass — production ready"
  exit 0
else
  echo "✗ Issues found"
  exit 1
fi
