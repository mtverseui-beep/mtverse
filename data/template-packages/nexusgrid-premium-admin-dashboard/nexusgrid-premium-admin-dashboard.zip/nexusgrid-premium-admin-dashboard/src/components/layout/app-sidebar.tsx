"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronDown, ChevronRight, X, Pin, Sparkles } from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { navigation, type NavItem } from "@/config/navigation";
import { cn } from "@/lib/utils";
import { useRecentPages } from "@/components/providers/recent-pages-provider";

const COLLAPSE_KEY = "nexusgrid-sidebar-collapsed";
const OPEN_GROUPS_KEY = "nexusgrid-sidebar-open-groups";

export function AppSidebar({
  mobileOpen = false,
  onCloseMobile,
  collapsed = false,
  onToggleCollapse,
}: {
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}) {
  const pathname = usePathname();
  const { recentPages } = useRecentPages();
  // SSR-safe defaults: render with defaults on server, hydrate to localStorage on client.
  const [openGroups, setOpenGroups] = React.useState<Record<string, boolean>>({
    Dashboards: true,
    Ecommerce: true,
  });
  const [hydrated, setHydrated] = React.useState(false);

  // Read persisted group state + collapse state once after mount (avoids hydration mismatch)
  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(OPEN_GROUPS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        // Auto-expand current route's group on top of persisted state
        const next = { ...parsed };
        if (pathname) {
          for (const group of navigation) {
            const inGroup = group.items.some(
              (item) => pathname === item.href || pathname.startsWith(item.href + "/")
            );
            if (inGroup) next[group.title] = true;
          }
        }
        setOpenGroups(next);
      } else if (pathname) {
        // No persisted state, just expand current group
        const next: Record<string, boolean> = { Dashboards: true, Ecommerce: true };
        for (const group of navigation) {
          const inGroup = group.items.some(
            (item) => pathname === item.href || pathname.startsWith(item.href + "/")
          );
          if (inGroup) next[group.title] = true;
        }
        setOpenGroups(next);
      }
    } catch {}
    setHydrated(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Persist openGroups to localStorage after hydration only
  React.useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(OPEN_GROUPS_KEY, JSON.stringify(openGroups));
    } catch {}
  }, [openGroups, hydrated]);

  const toggleGroup = (title: string) => {
    setOpenGroups((prev) => ({ ...prev, [title]: !prev[title] }));
  };

  // Auto-expand group when route changes after hydration
  React.useEffect(() => {
    if (!hydrated || !pathname) return;
    setOpenGroups((prev) => {
      let changed = false;
      const next = { ...prev };
      for (const group of navigation) {
        const inGroup = group.items.some(
          (item) => pathname === item.href || pathname.startsWith(item.href + "/")
        );
        if (inGroup && !next[group.title]) {
          next[group.title] = true;
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [pathname, hydrated]);

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
          aria-hidden
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-300 ease-out",
          collapsed ? "w-[76px]" : "w-[264px]",
          // Mobile transform
          "lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
        aria-label="Primary navigation"
      >
        {/* Sidebar header / brand */}
        <div
          className={cn(
            "flex items-center justify-between h-16 px-4 border-b border-sidebar-border shrink-0",
            collapsed && "px-3"
          )}
        >
          {collapsed ? (
            <div className="mx-auto">
              <BrandLogo showText={false} size="sm" />
            </div>
          ) : (
            <Link href="/" className="flex items-center" aria-label="NexusGrid home">
              <BrandLogo />
            </Link>
          )}
          {!collapsed && (
            <button
              type="button"
              onClick={onCloseMobile}
              className="lg:hidden p-1.5 rounded-md hover:bg-sidebar-accent text-muted-foreground"
              aria-label="Close sidebar"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Nav body */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden py-3 px-2">
          {!collapsed && recentPages.length > 0 && (
            <div className="mb-3 px-2">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground/70 font-semibold mb-1 flex items-center gap-1">
                <Sparkles className="h-3 w-3" /> Recent
              </p>
              <div className="flex flex-wrap gap-1">
                {recentPages.slice(0, 3).map((p) => (
                  <Link
                    key={p.path}
                    href={p.path}
                    className="text-xs px-2 py-1 rounded-md bg-sidebar-accent/60 hover:bg-sidebar-accent text-sidebar-foreground truncate max-w-[140px]"
                  >
                    {p.label}
                  </Link>
                ))}
              </div>
            </div>
          )}

          <ul className="space-y-0.5">
            {navigation.map((group) => {
              const isOpen = collapsed || openGroups[group.title];
              return (
                <li key={group.title}>
                  {!collapsed && (
                    <button
                      type="button"
                      onClick={() => toggleGroup(group.title)}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 text-[11px] uppercase tracking-wider font-semibold text-muted-foreground/80 hover:text-sidebar-foreground transition-colors"
                      aria-expanded={isOpen}
                    >
                      <span>{group.title}</span>
                      <ChevronDown
                        className={cn(
                          "h-3 w-3 transition-transform",
                          isOpen && "rotate-180"
                        )}
                      />
                    </button>
                  )}
                  {collapsed && (
                    <div className="my-2 mx-2 h-px bg-sidebar-border/60" />
                  )}
                  {isOpen && (
                    <ul className="space-y-0.5 mt-0.5">
                      {group.items.map((item) => (
                        <SidebarItem
                          key={item.href}
                          item={item}
                          active={
                            pathname === item.href ||
                            pathname.startsWith(item.href + "/")
                          }
                          collapsed={collapsed}
                        />
                      ))}
                    </ul>
                  )}
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Sidebar footer */}
        {!collapsed && (
          <div className="border-t border-sidebar-border p-3 shrink-0">
            <div className="rounded-lg bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-3 text-xs">
              <div className="flex items-center gap-1.5 mb-1">
                <Sparkles className="h-3.5 w-3.5 text-primary" />
                <span className="font-semibold text-sidebar-foreground">Pro Tip</span>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Press{" "}
                <kbd className="rounded bg-sidebar-accent px-1 py-0.5 font-mono text-[10px]">⌘K</kbd>{" "}
                to open the command palette.
              </p>
            </div>
          </div>
        )}

        {/* Collapse toggle (desktop) */}
        <button
          type="button"
          onClick={onToggleCollapse}
          className="hidden lg:flex absolute -right-3 top-20 z-10 h-6 w-6 items-center justify-center rounded-full border border-border bg-card shadow-premium-sm hover:shadow-premium transition-all"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <ChevronRight
            className={cn(
              "h-3.5 w-3.5 transition-transform",
              !collapsed && "rotate-180"
            )}
          />
        </button>
      </aside>
    </>
  );
}

function SidebarItem({
  item,
  active,
  collapsed,
}: {
  item: NavItem;
  active: boolean;
  collapsed: boolean;
}) {
  const Icon = item.icon;
  const [hovered, setHovered] = React.useState(false);

  if (collapsed) {
    return (
      <li>
        <Link
          href={item.href}
          className={cn(
            "relative flex h-9 w-9 mx-auto items-center justify-center rounded-lg transition-colors",
            active
              ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-premium-xs"
              : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground"
          )}
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
          title={item.title}
        >
          {Icon && <Icon className="h-4.5 w-4.5" />}
          {hovered && (
            <span className="absolute left-12 z-50 whitespace-nowrap rounded-md bg-popover px-2 py-1 text-xs text-popover-foreground shadow-premium-md">
              {item.title}
            </span>
          )}
          {item.badge && (
            <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-primary" />
          )}
        </Link>
      </li>
    );
  }

  return (
    <li>
      <Link
        href={item.href}
        className={cn(
          "group relative flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition-all",
          active
            ? "bg-sidebar-primary text-sidebar-primary-foreground font-medium shadow-premium-xs"
            : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground"
        )}
      >
        {Icon && (
          <Icon
            className={cn(
              "h-4.5 w-4.5 shrink-0 transition-colors",
              active ? "text-sidebar-primary-foreground" : "text-muted-foreground group-hover:text-sidebar-foreground"
            )}
          />
        )}
        <span className="flex-1 truncate">{item.title}</span>
        {item.badge && (
          <span
            className={cn(
              "text-[10px] uppercase tracking-wide px-1.5 py-0.5 rounded font-semibold",
              item.badgeTone === "new"
                ? "bg-primary/20 text-primary"
                : "bg-violet-500/20 text-violet-500"
            )}
          >
            {item.badge}
          </span>
        )}
      </Link>
    </li>
  );
}

// Hook for managing collapse state in layout
export function useSidebarCollapse() {
  const [collapsed, setCollapsed] = React.useState(false);

  React.useEffect(() => {
    try {
      const stored = localStorage.getItem(COLLAPSE_KEY);
      if (stored === "true") setCollapsed(true);
    } catch {}
  }, []);

  const toggle = React.useCallback(() => {
    setCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(COLLAPSE_KEY, String(next));
      } catch {}
      return next;
    });
  }, []);

  return { collapsed, toggle };
}
