"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import {
  Menu,
  Search,
  Bell,
  MessageSquare,
  Sun,
  Moon,
  Plus,
  ChevronDown,
  User,
  Settings,
  LogOut,
  CreditCard,
  LifeBuoy,
  Command as CommandIcon,
  CircleUser,
  CheckCircle2,
  AlertTriangle,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
  DropdownMenuShortcut,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useTheme } from "@/components/providers/theme-provider";
import { useCommandPalette } from "@/components/providers/command-palette-provider";
import { useRecentPages } from "@/components/providers/recent-pages-provider";
import { quickActions } from "@/config/navigation";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function AppHeader({ onOpenMobileSidebar }: { onOpenMobileSidebar: () => void }) {
  const pathname = usePathname();
  const { theme, toggleTheme } = useTheme();
  const { setOpen: setCmdOpen } = useCommandPalette();
  const { recordVisit } = useRecentPages();
  const router = useRouter();

  // Build breadcrumb from pathname
  const breadcrumbs = React.useMemo(() => {
    if (!pathname || pathname === "/") return [];
    const segments = pathname.split("/").filter(Boolean);
    const crumbs: { label: string; href?: string }[] = [];
    let acc = "";
    for (let i = 0; i < segments.length; i++) {
      acc += "/" + segments[i];
      const label = segments[i]
        .split("-")
        .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
        .join(" ");
      crumbs.push({
        label,
        href: i === segments.length - 1 ? undefined : acc,
      });
    }
    return crumbs;
  }, [pathname]);

  // Record visit on path change
  React.useEffect(() => {
    if (!pathname || pathname === "/") return;
    const label = breadcrumbs[breadcrumbs.length - 1]?.label || pathname;
    recordVisit(pathname, label);
  }, [pathname, breadcrumbs, recordVisit]);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-2 border-b border-border bg-background/85 backdrop-blur-md px-3 sm:px-4 lg:px-6">
      {/* Mobile menu button */}
      <button
        type="button"
        onClick={onOpenMobileSidebar}
        className="lg:hidden p-2 -ml-1 rounded-lg hover:bg-muted text-muted-foreground"
        aria-label="Open sidebar"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Breadcrumb (desktop) */}
      <nav className="hidden md:flex items-center text-sm text-muted-foreground min-w-0">
        <ol className="flex items-center gap-1.5">
          <li>
            <Link href="/" className="hover:text-foreground transition-colors">
              Home
            </Link>
          </li>
          {breadcrumbs.map((c, i) => (
            <li key={i} className="flex items-center gap-1.5">
              <span className="text-muted-foreground/40">/</span>
              {c.href ? (
                <Link href={c.href} className="hover:text-foreground transition-colors">
                  {c.label}
                </Link>
              ) : (
                <span className="text-foreground font-medium truncate">{c.label}</span>
              )}
            </li>
          ))}
        </ol>
      </nav>

      <div className="flex-1" />

      {/* Search trigger (looks like input, opens palette) */}
      <button
        type="button"
        onClick={() => setCmdOpen(true)}
        className="group hidden sm:flex items-center gap-2 h-9 w-[200px] lg:w-[280px] rounded-lg border border-input bg-muted/40 px-3 text-sm text-muted-foreground hover:bg-muted/70 hover:border-border transition-all"
      >
        <Search className="h-3.5 w-3.5" />
        <span className="flex-1 text-left">Search...</span>
        <kbd className="hidden lg:inline-flex items-center gap-0.5 rounded bg-background border border-border px-1.5 py-0.5 text-[10px] font-mono">
          <CommandIcon className="h-2.5 w-2.5" />K
        </kbd>
      </button>

      {/* Mobile search icon */}
      <button
        type="button"
        onClick={() => setCmdOpen(true)}
        className="sm:hidden p-2 rounded-lg hover:bg-muted text-muted-foreground"
        aria-label="Search"
      >
        <Search className="h-5 w-5" />
      </button>

      {/* Theme toggle */}
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleTheme}
        className="h-9 w-9 text-muted-foreground hover:text-foreground"
        aria-label="Toggle theme"
      >
        {theme === "dark" ? (
          <Sun className="h-4 w-4" />
        ) : (
          <Moon className="h-4 w-4" />
        )}
      </Button>

      {/* Quick create */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button size="sm" className="hidden sm:inline-flex gap-1.5 h-9">
            <Plus className="h-4 w-4" />
            <span className="hidden lg:inline">Create</span>
            <ChevronDown className="h-3.5 w-3.5 opacity-70" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>Quick create</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {quickActions.map((a) => (
            <DropdownMenuItem
              key={a.title}
              onClick={() => router.push(a.href)}
              className="gap-2"
            >
              <a.icon className="h-4 w-4 text-muted-foreground" />
              <span>{a.title}</span>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Mobile create FAB */}
      <Button
        size="icon"
        className="sm:hidden h-9 w-9"
        onClick={() => setCmdOpen(true)}
        aria-label="Quick create"
      >
        <Plus className="h-4 w-4" />
      </Button>

      {/* Notifications */}
      <NotificationsPopover />

      {/* Messages */}
      <Button
        variant="ghost"
        size="icon"
        className="h-9 w-9 text-muted-foreground hover:text-foreground hidden sm:inline-flex relative"
        asChild
      >
        <Link href="/apps/chat" aria-label="Messages">
          <MessageSquare className="h-4 w-4" />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-[color:var(--info)] ring-2 ring-background" />
        </Link>
      </Button>

      {/* User menu */}
      <UserMenu />
    </header>
  );
}

function NotificationsPopover() {
  const [open, setOpen] = React.useState(false);
  const router = useRouter();
  const notifications = [
    {
      id: 1,
      icon: CheckCircle2,
      tone: "text-[color:var(--success)]",
      title: "Order #NX-3948 completed",
      desc: "Payment captured and fulfillment started.",
      time: "2 min ago",
      unread: true,
    },
    {
      id: 2,
      icon: AlertTriangle,
      tone: "text-[color:var(--warning)]",
      title: "Low stock alert: Aether Hoodie",
      desc: "Only 4 units left in warehouse A-12.",
      time: "23 min ago",
      unread: true,
    },
    {
      id: 3,
      icon: Info,
      tone: "text-[color:var(--info)]",
      title: "New lead from enterprise form",
      desc: "Globex Corp submitted a demo request.",
      time: "1 hr ago",
      unread: true,
    },
    {
      id: 4,
      icon: User,
      tone: "text-primary",
      title: "Sarah Chen accepted your invite",
      desc: "She joined the Marketing workspace.",
      time: "3 hr ago",
      unread: false,
    },
  ];
  const unreadCount = notifications.filter((n) => n.unread).length;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 text-muted-foreground hover:text-foreground relative"
          aria-label="Notifications"
        >
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-destructive ring-2 ring-background" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="w-[360px] p-0 shadow-premium-lg"
      >
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold">Notifications</span>
            {unreadCount > 0 && (
              <span className="text-[10px] font-medium bg-primary/15 text-primary rounded-full px-1.5 py-0.5">
                {unreadCount} new
              </span>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            onClick={() => toast.success("All marked as read")}
          >
            Mark all read
          </Button>
        </div>
        <div className="max-h-[360px] overflow-y-auto py-1">
          {notifications.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => {
                setOpen(false);
                toast.info(`Opening: ${n.title}`);
              }}
              className={cn(
                "w-full text-left flex gap-3 px-4 py-3 hover:bg-muted/60 transition-colors relative",
                n.unread && "bg-primary/[0.04]"
              )}
            >
              {n.unread && (
                <span className="absolute left-1.5 top-1/2 -translate-y-1/2 h-1.5 w-1.5 rounded-full bg-primary" />
              )}
              <div className={cn("grid place-items-center h-8 w-8 rounded-lg bg-muted/60 shrink-0", n.tone)}>
                <n.icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-medium truncate">{n.title}</p>
                  <span className="text-[10px] text-muted-foreground shrink-0">{n.time}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.desc}</p>
              </div>
            </button>
          ))}
        </div>
        <div className="border-t border-border p-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-full text-xs h-8"
            onClick={() => {
              setOpen(false);
              router.push("/account/notifications");
            }}
          >
            View all notifications
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

function UserMenu() {
  const router = useRouter();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="flex items-center gap-2 rounded-lg p-1 pr-2 hover:bg-muted transition-colors"
          aria-label="User menu"
        >
          <Avatar className="h-7 w-7 rounded-lg">
            <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop" alt="User avatar" />
            <AvatarFallback>SC</AvatarFallback>
          </Avatar>
          <div className="hidden md:flex flex-col items-start leading-none">
            <span className="text-xs font-medium">Sam Carter</span>
            <span className="text-[10px] text-muted-foreground">Admin</span>
          </div>
          <ChevronDown className="hidden md:block h-3.5 w-3.5 text-muted-foreground" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuLabel>
          <div className="flex flex-col">
            <span className="text-sm font-medium">Sam Carter</span>
            <span className="text-xs text-muted-foreground font-normal">sam.carter@nexusgrid.io</span>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuItem onClick={() => router.push("/account/profile")} className="gap-2">
            <CircleUser className="h-4 w-4" />
            <span>Profile</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => router.push("/account/settings")} className="gap-2">
            <Settings className="h-4 w-4" />
            <span>Account settings</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => router.push("/admin/billing")} className="gap-2">
            <CreditCard className="h-4 w-4" />
            <span>Billing</span>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => router.push("/help-center")} className="gap-2">
            <LifeBuoy className="h-4 w-4" />
            <span>Help & support</span>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={() => {
            toast.success("Signed out");
            router.push("/auth/signin");
          }}
          className="gap-2 text-destructive focus:text-destructive"
        >
          <LogOut className="h-4 w-4" />
          <span>Sign out</span>
          <DropdownMenuShortcut>⇧⌘Q</DropdownMenuShortcut>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
