"use client";

import * as React from "react";
import { AppSidebar, useSidebarCollapse } from "@/components/layout/app-sidebar";
import { AppHeader } from "@/components/layout/app-header";
import { cn } from "@/lib/utils";

export function AdminShell({ children }: { children: React.ReactNode }) {
  const { collapsed, toggle } = useSidebarCollapse();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        collapsed={collapsed}
        onToggleCollapse={toggle}
      />

      <div
        className={cn(
          "flex min-h-screen flex-col transition-[padding] duration-300 ease-out",
          collapsed ? "lg:pl-[76px]" : "lg:pl-[264px]"
        )}
      >
        <AppHeader onOpenMobileSidebar={() => setMobileOpen(true)} />

        <main className="flex-1 px-3 py-5 sm:px-5 lg:px-7 lg:py-7">
          <div className="mx-auto max-w-[1600px] animate-fade-in-up">{children}</div>
        </main>

        <footer className="border-t border-border bg-card/30 px-4 py-4 text-center text-xs text-muted-foreground">
          <div className="mx-auto max-w-[1600px] flex flex-col sm:flex-row items-center justify-between gap-2">
            <p>&copy; {new Date().getFullYear()} NexusGrid Labs. All rights reserved.</p>
            <div className="flex items-center gap-3">
              <a href="/terms" className="hover:text-foreground transition-colors">Terms</a>
              <a href="/privacy" className="hover:text-foreground transition-colors">Privacy</a>
              <a href="/documentation" className="hover:text-foreground transition-colors">Docs</a>
              <span className="text-muted-foreground/60">v1.0.0</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
