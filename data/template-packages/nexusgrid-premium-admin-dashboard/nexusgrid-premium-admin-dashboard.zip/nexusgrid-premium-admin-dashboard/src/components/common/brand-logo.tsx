import * as React from "react";
import { cn } from "@/lib/utils";

export function BrandLogo({
  className,
  showText = true,
  size = "md",
}: {
  className?: string;
  showText?: boolean;
  size?: "sm" | "md" | "lg";
}) {
  const dims = size === "sm" ? 28 : size === "lg" ? 44 : 36;
  const textCls =
    size === "sm" ? "text-base" : size === "lg" ? "text-2xl" : "text-lg";

  return (
    <div className={cn("flex items-center gap-2.5 select-none", className)}>
      <div
        className="relative grid place-items-center rounded-xl brand-gradient shadow-premium-sm"
        style={{ width: dims, height: dims }}
        aria-hidden
      >
        <svg
          width={dims * 0.6}
          height={dims * 0.6}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={2.4}
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-white"
        >
          {/* Nexus mark — interlocking N grid */}
          <path d="M5 19V5l14 14V5" />
          <circle cx="5" cy="5" r="1.4" fill="currentColor" />
          <circle cx="19" cy="19" r="1.4" fill="currentColor" />
          <circle cx="5" cy="19" r="1.4" fill="currentColor" />
          <circle cx="19" cy="5" r="1.4" fill="currentColor" />
        </svg>
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className={cn("font-semibold tracking-tight", textCls)}>
            Nexus<span className="text-primary">Grid</span>
          </span>
          {size !== "sm" && (
            <span className="text-[10px] text-muted-foreground tracking-wider uppercase mt-0.5">
              Admin Suite
            </span>
          )}
        </div>
      )}
    </div>
  );
}
