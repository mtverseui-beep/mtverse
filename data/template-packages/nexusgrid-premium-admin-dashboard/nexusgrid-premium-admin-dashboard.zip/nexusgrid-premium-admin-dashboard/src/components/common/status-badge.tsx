"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export type StatusTone =
  | "success"
  | "warning"
  | "danger"
  | "info"
  | "neutral"
  | "primary"
  | "violet";

export function StatusBadge({
  tone = "neutral",
  children,
  dot = false,
  className,
}: {
  tone?: StatusTone;
  children: React.ReactNode;
  dot?: boolean;
  className?: string;
}) {
  const toneMap: Record<StatusTone, string> = {
    success:
      "bg-[color:var(--success)]/12 text-[color:var(--success)] ring-[color:var(--success)]/20",
    warning:
      "bg-[color:var(--warning)]/15 text-[color:var(--warning)] ring-[color:var(--warning)]/25",
    danger: "bg-destructive/12 text-destructive ring-destructive/20",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)] ring-[color:var(--info)]/20",
    neutral: "bg-muted text-muted-foreground ring-border",
    primary: "bg-primary/12 text-primary ring-primary/20",
    violet: "bg-violet-500/12 text-violet-500 ring-violet-500/20",
  };

  const dotColor: Record<StatusTone, string> = {
    success: "bg-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]",
    danger: "bg-destructive",
    info: "bg-[color:var(--info)]",
    neutral: "bg-muted-foreground",
    primary: "bg-primary",
    violet: "bg-violet-500",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset",
        toneMap[tone],
        className
      )}
    >
      {dot && (
        <span className={cn("h-1.5 w-1.5 rounded-full", dotColor[tone])} />
      )}
      {children}
    </span>
  );
}
