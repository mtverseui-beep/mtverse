"use client";

import * as React from "react";
import Link from "next/link";
import { ChevronRight, MoreHorizontal, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export type BreadcrumbItem = {
  label: string;
  href?: string;
};

export function PageHeader({
  title,
  description,
  breadcrumbs,
  icon: Icon,
  actions,
  className,
}: {
  title: string;
  description?: string;
  breadcrumbs?: BreadcrumbItem[];
  icon?: LucideIcon;
  actions?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-6", className)}>
      <div className="flex flex-col gap-2 min-w-0">
        {breadcrumbs && breadcrumbs.length > 0 && (
          <nav aria-label="Breadcrumb" className="flex items-center text-xs text-muted-foreground">
            <ol className="flex items-center gap-1.5 flex-wrap">
              {breadcrumbs.map((b, i) => {
                const isLast = i === breadcrumbs.length - 1;
                return (
                  <li key={i} className="flex items-center gap-1.5">
                    {b.href && !isLast ? (
                      <Link
                        href={b.href}
                        className="hover:text-foreground transition-colors"
                      >
                        {b.label}
                      </Link>
                    ) : (
                      <span className={cn(isLast && "text-foreground font-medium")}>
                        {b.label}
                      </span>
                    )}
                    {!isLast && <ChevronRight className="h-3 w-3 opacity-50" />}
                  </li>
                );
              })}
            </ol>
          </nav>
        )}
        <div className="flex items-center gap-3">
          {Icon && (
            <div className="hidden sm:grid place-items-center h-10 w-10 rounded-xl bg-primary/10 text-primary shadow-premium-xs">
              <Icon className="h-5 w-5" />
            </div>
          )}
          <div className="min-w-0">
            <h1 className="text-2xl font-semibold tracking-tight truncate">{title}</h1>
            {description && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{description}</p>
            )}
          </div>
        </div>
      </div>
      {actions && (
        <div className="flex flex-wrap items-center gap-2 shrink-0">{actions}</div>
      )}
    </div>
  );
}
