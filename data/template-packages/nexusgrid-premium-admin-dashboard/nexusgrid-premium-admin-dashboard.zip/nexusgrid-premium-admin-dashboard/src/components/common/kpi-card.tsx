"use client";

import * as React from "react";
import { ArrowDownRight, ArrowUpRight, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export type KpiTrend = {
  value: number; // percentage
  direction: "up" | "down";
  label?: string;
  positive?: boolean; // whether trend is good (green) — defaults to direction
};

export function KpiCard({
  label,
  value,
  icon: Icon,
  trend,
  hint,
  accent = "primary",
  className,
  sparkline,
}: {
  label: string;
  value: React.ReactNode;
  icon?: LucideIcon;
  trend?: KpiTrend;
  hint?: string;
  accent?: "primary" | "success" | "warning" | "info" | "destructive";
  className?: string;
  sparkline?: React.ReactNode;
}) {
  const accentMap = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    destructive: "bg-destructive/15 text-destructive",
  } as const;

  const trendPositive =
    trend?.positive ?? (trend?.direction === "up");

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm",
        className
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
            {label}
          </p>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="text-2xl font-semibold tracking-tight tabular-nums">
              {value}
            </span>
          </div>
        </div>
        {Icon && (
          <div
            className={cn(
              "grid place-items-center h-9 w-9 rounded-lg shrink-0",
              accentMap[accent]
            )}
          >
            <Icon className="h-4.5 w-4.5" />
          </div>
        )}
      </div>

      <div className="mt-3 flex items-center gap-2 flex-wrap">
        {trend && (
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium",
              trendPositive
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {trend.direction === "up" ? (
              <ArrowUpRight className="h-3 w-3" />
            ) : (
              <ArrowDownRight className="h-3 w-3" />
            )}
            {Math.abs(trend.value)}%
          </span>
        )}
        {hint && <span className="text-xs text-muted-foreground truncate">{hint}</span>}
      </div>

      {sparkline && <div className="mt-3 -mb-1">{sparkline}</div>}
    </div>
  );
}

// Mini sparkline renderer using SVG
export function Sparkline({
  data,
  color = "var(--primary)",
  width = 120,
  height = 36,
  fill = true,
}: {
  data: number[];
  color?: string;
  width?: number;
  height?: number;
  fill?: boolean;
}) {
  if (!data || data.length < 2) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1);

  const points = data.map((d, i) => {
    const x = i * step;
    const y = height - ((d - min) / range) * (height - 4) - 2;
    return [x, y] as const;
  });

  const pathD = points
    .map((p, i) => (i === 0 ? `M ${p[0]} ${p[1]}` : `L ${p[0]} ${p[1]}`))
    .join(" ");

  const areaD = `${pathD} L ${width} ${height} L 0 ${height} Z`;

  return (
    <svg width={width} height={height} className="overflow-visible">
      {fill && (
        <path d={areaD} fill={color} opacity={0.12} />
      )}
      <path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx={points[points.length - 1][0]}
        cy={points[points.length - 1][1]}
        r={2.5}
        fill={color}
      />
    </svg>
  );
}
