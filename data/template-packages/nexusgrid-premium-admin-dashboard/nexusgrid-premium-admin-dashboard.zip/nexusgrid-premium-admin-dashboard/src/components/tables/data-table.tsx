"use client";

import * as React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import {
  ChevronDown,
  ChevronUp,
  ChevronsUpDown,
  Search,
  SlidersHorizontal,
  Download,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Settings2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export type Column<T> = {
  key: string;
  header: string;
  cell: (row: T) => React.ReactNode;
  sortable?: boolean;
  sortAccessor?: (row: T) => string | number;
  filterable?: boolean;
  filterOptions?: { label: string; value: string }[];
  filterAccessor?: (row: T) => string;
  width?: string;
  align?: "left" | "right" | "center";
  hideable?: boolean;
  defaultHidden?: boolean;
};

export type DataTableProps<T> = {
  data: T[];
  columns: Column<T>[];
  searchable?: boolean;
  searchKeys?: (keyof T)[];
  pageSize?: number;
  emptyMessage?: string;
  getRowId?: (row: T) => string;
  onRowClick?: (row: T) => void;
  enableSelection?: boolean;
  enableExport?: boolean;
  enableDensity?: boolean;
  enableColumnVisibility?: boolean;
  bulkActions?: { label: string; onClick: (selected: T[]) => void; icon?: React.ComponentType<{ className?: string }> }[];
  initialSort?: { key: string; direction: "asc" | "desc" };
  initialFilters?: Record<string, string>;
  toolbarActions?: React.ReactNode;
  title?: string;
};

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  searchable = true,
  searchKeys,
  pageSize = 10,
  emptyMessage = "No records found.",
  getRowId = (row) => String(row.id ?? JSON.stringify(row)),
  onRowClick,
  enableSelection = false,
  enableExport = true,
  enableDensity = true,
  enableColumnVisibility = true,
  bulkActions = [],
  initialSort,
  initialFilters,
  toolbarActions,
  title,
}: DataTableProps<T>) {
  const [search, setSearch] = React.useState("");
  const [sort, setSort] = React.useState<{ key: string; direction: "asc" | "desc" } | null>(
    initialSort ?? null
  );
  const [filters, setFilters] = React.useState<Record<string, string>>(initialFilters ?? {});
  const [page, setPage] = React.useState(0);
  const [density, setDensity] = React.useState<"comfortable" | "compact">("comfortable");
  const [hiddenCols, setHiddenCols] = React.useState<Set<string>>(
    new Set(columns.filter((c) => c.defaultHidden).map((c) => c.key))
  );
  const [selected, setSelected] = React.useState<Set<string>>(new Set());

  // Filtered data
  const filteredData = React.useMemo(() => {
    let result = [...data];

    // Apply search
    if (search && searchable) {
      const q = search.toLowerCase();
      const keys = searchKeys ?? (Object.keys(data[0] ?? {}) as (keyof T)[]);
      result = result.filter((row) =>
        keys.some((k) => String(row[k] ?? "").toLowerCase().includes(q))
      );
    }

    // Apply filters
    for (const [filterKey, filterValue] of Object.entries(filters)) {
      if (!filterValue) continue;
      const col = columns.find((c) => c.key === filterKey);
      if (!col?.filterAccessor) continue;
      result = result.filter((row) => col.filterAccessor!(row) === filterValue);
    }

    // Apply sort
    if (sort) {
      const col = columns.find((c) => c.key === sort.key);
      if (col?.sortAccessor) {
        result.sort((a, b) => {
          const av = col.sortAccessor!(a);
          const bv = col.sortAccessor!(b);
          if (av < bv) return sort.direction === "asc" ? -1 : 1;
          if (av > bv) return sort.direction === "asc" ? 1 : -1;
          return 0;
        });
      }
    }

    return result;
  }, [data, search, filters, sort, columns, searchKeys, searchable]);

  // Paginated data
  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const currentPage = Math.min(page, totalPages - 1);
  const paginatedData = filteredData.slice(currentPage * pageSize, (currentPage + 1) * pageSize);

  // Reset page when filters change
  React.useEffect(() => {
    setPage(0);
  }, [search, filters, sort]);

  const toggleSort = (key: string) => {
    setSort((prev) => {
      if (!prev || prev.key !== key) return { key, direction: "asc" };
      if (prev.direction === "asc") return { key, direction: "desc" };
      return null;
    });
  };

  const toggleSelected = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    setSelected((prev) => {
      if (prev.size === paginatedData.length) return new Set();
      return new Set(paginatedData.map((r) => getRowId(r)));
    });
  };

  const handleExport = (format: "csv" | "json") => {
    const visibleCols = columns.filter((c) => !hiddenCols.has(c.key));
    let blob: Blob;
    if (format === "csv") {
      const header = visibleCols.map((c) => c.header).join(",");
      const rows = filteredData.map((row) =>
        visibleCols.map((c) => {
          const v = c.sortAccessor ? c.sortAccessor(row) : row[c.key];
          return `"${String(v ?? "").replace(/"/g, '""')}"`;
        }).join(",")
      );
      blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv" });
    } else {
      blob = new Blob([JSON.stringify(filteredData, null, 2)], { type: "application/json" });
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title?.toLowerCase().replace(/\s+/g, "-") ?? "export"}-${Date.now()}.${format}`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${filteredData.length} records as ${format.toUpperCase()}`);
  };

  const visibleCols = columns.filter((c) => !hiddenCols.has(c.key));
  const allSelected = paginatedData.length > 0 && paginatedData.every((r) => selected.has(getRowId(r)));
  const someSelected = paginatedData.some((r) => selected.has(getRowId(r)));

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 p-3 sm:p-4 border-b border-border bg-muted/30">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          {title && (
            <h3 className="text-sm font-semibold shrink-0 mr-2">{title}</h3>
          )}
          {searchable && (
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search..."
                className="h-8 pl-8 text-xs"
              />
            </div>
          )}
          <div className="flex-1" />
          <div className="flex items-center gap-1.5">
            {/* Filter dropdown */}
            {columns.some((c) => c.filterable) && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                    <SlidersHorizontal className="h-3.5 w-3.5" /> Filters
                    {Object.values(filters).filter(Boolean).length > 0 && (
                      <span className="bg-primary text-primary-foreground rounded-full text-[10px] px-1.5 py-0.5 ml-0.5">
                        {Object.values(filters).filter(Boolean).length}
                      </span>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>Filter by</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {columns.filter((c) => c.filterable).map((col) => (
                    <div key={col.key} className="px-2 py-1">
                      <p className="text-xs font-medium text-muted-foreground mb-1">{col.header}</p>
                      <select
                        value={filters[col.key] ?? ""}
                        onChange={(e) => setFilters((p) => ({ ...p, [col.key]: e.target.value }))}
                        className="w-full h-7 rounded-md border border-input bg-background px-2 text-xs"
                      >
                        <option value="">All</option>
                        {col.filterOptions?.map((opt) => (
                          <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                  {Object.values(filters).some(Boolean) && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => setFilters({})}
                        className="text-xs gap-1.5 text-destructive focus:text-destructive"
                      >
                        <X className="h-3 w-3" /> Clear all filters
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* Density */}
            {enableDensity && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 text-xs">
                    <Settings2 className="h-3.5 w-3.5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-40">
                  <DropdownMenuLabel>Density</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => setDensity("comfortable")} className="text-xs">
                    Comfortable
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setDensity("compact")} className="text-xs">
                    Compact
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* Column visibility */}
            {enableColumnVisibility && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 text-xs">
                    Columns <ChevronDown className="h-3 w-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuLabel>Toggle columns</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {columns.filter((c) => c.hideable !== false).map((col) => (
                    <DropdownMenuCheckboxItem
                      key={col.key}
                      checked={!hiddenCols.has(col.key)}
                      onCheckedChange={(checked) => {
                        setHiddenCols((prev) => {
                          const next = new Set(prev);
                          if (checked) next.delete(col.key);
                          else next.add(col.key);
                          return next;
                        });
                      }}
                      className="text-xs"
                    >
                      {col.header}
                    </DropdownMenuCheckboxItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {/* Export */}
            {enableExport && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                    <Download className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Export</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => handleExport("csv")} className="text-xs">
                    Export as CSV
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleExport("json")} className="text-xs">
                    Export as JSON
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {toolbarActions}
          </div>
        </div>

        {/* Active filters display */}
        {Object.entries(filters).filter(([, v]) => v).length > 0 && (
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs text-muted-foreground">Active:</span>
            {Object.entries(filters).filter(([, v]) => v).map(([k, v]) => (
              <button
                key={k}
                onClick={() => setFilters((p) => ({ ...p, [k]: "" }))}
                className="inline-flex items-center gap-1 text-xs bg-primary/10 text-primary rounded-full px-2 py-0.5 hover:bg-primary/20"
              >
                {columns.find((c) => c.key === k)?.filterOptions?.find((o) => o.value === v)?.label ?? v}
                <X className="h-3 w-3" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Bulk actions bar */}
      {enableSelection && selected.size > 0 && (
        <div className="flex items-center gap-3 px-4 py-2 bg-primary/5 border-b border-primary/15 animate-fade-in-up">
          <span className="text-xs font-medium text-primary">{selected.size} selected</span>
          <div className="flex-1" />
          {bulkActions.map((a) => (
            <Button
              key={a.label}
              variant="outline"
              size="sm"
              className="h-7 text-xs gap-1.5"
              onClick={() => {
                const selectedRows = filteredData.filter((r) => selected.has(getRowId(r)));
                a.onClick(selectedRows);
              }}
            >
              {a.icon && <a.icon className="h-3 w-3" />} {a.label}
            </Button>
          ))}
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            onClick={() => setSelected(new Set())}
          >
            Clear
          </Button>
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        <Table className={cn(density === "compact" && "[&_td]:py-2 [&_th]:py-2")}>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              {enableSelection && (
                <TableHead className="w-10">
                  <input
                    type="checkbox"
                    checked={allSelected}
                    ref={(el) => {
                      if (el) el.indeterminate = !allSelected && someSelected;
                    }}
                    onChange={toggleSelectAll}
                    className="h-3.5 w-3.5 rounded border-border accent-primary"
                  />
                </TableHead>
              )}
              {visibleCols.map((col) => (
                <TableHead
                  key={col.key}
                  className={cn(
                    "text-xs uppercase tracking-wide font-medium text-muted-foreground",
                    col.align === "right" && "text-right",
                    col.align === "center" && "text-center",
                    col.sortable && "cursor-pointer hover:text-foreground select-none",
                    col.width
                  )}
                  onClick={col.sortable ? () => toggleSort(col.key) : undefined}
                >
                  <div className={cn(
                    "inline-flex items-center gap-1",
                    col.align === "right" && "flex-row-reverse",
                    col.align === "center" && "justify-center"
                  )}>
                    {col.header}
                    {col.sortable && (
                      <span className="ml-0.5">
                        {sort?.key === col.key ? (
                          sort.direction === "asc" ? (
                            <ChevronUp className="h-3 w-3" />
                          ) : (
                            <ChevronDown className="h-3 w-3" />
                          )
                        ) : (
                          <ChevronsUpDown className="h-3 w-3 opacity-40" />
                        )}
                      </span>
                    )}
                  </div>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedData.length === 0 ? (
              <TableRow>
                <TableCell colSpan={visibleCols.length + (enableSelection ? 1 : 0)} className="text-center text-sm text-muted-foreground py-12">
                  {search || Object.values(filters).some(Boolean) ? "No matching records." : emptyMessage}
                </TableCell>
              </TableRow>
            ) : (
              paginatedData.map((row) => {
                const id = getRowId(row);
                const isSelected = selected.has(id);
                return (
                  <TableRow
                    key={id}
                    className={cn(
                      onRowClick && "cursor-pointer",
                      isSelected && "bg-primary/[0.04]"
                    )}
                    onClick={onRowClick ? () => onRowClick(row) : undefined}
                  >
                    {enableSelection && (
                      <TableCell className="w-10" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelected(id)}
                          className="h-3.5 w-3.5 rounded border-border accent-primary"
                        />
                      </TableCell>
                    )}
                    {visibleCols.map((col) => (
                      <TableCell
                        key={col.key}
                        className={cn(
                          "text-sm",
                          col.align === "right" && "text-right tabular-nums",
                          col.align === "center" && "text-center"
                        )}
                      >
                        {col.cell(row)}
                      </TableCell>
                    ))}
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Footer / Pagination */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-2 px-4 py-3 border-t border-border bg-muted/30">
        <div className="text-xs text-muted-foreground">
          {filteredData.length === 0 ? (
            "No records"
          ) : (
            <>
              Showing{" "}
              <span className="font-medium text-foreground">
                {currentPage * pageSize + 1}–{Math.min((currentPage + 1) * pageSize, filteredData.length)}
              </span>{" "}
              of <span className="font-medium text-foreground">{filteredData.length}</span>
            </>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="outline"
            size="icon"
            className="h-7 w-7"
            disabled={currentPage === 0}
            onClick={() => setPage(0)}
          >
            <ChevronsLeft className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-7 w-7"
            disabled={currentPage === 0}
            onClick={() => setPage((p) => Math.max(0, p - 1))}
          >
            <ChevronLeft className="h-3.5 w-3.5" />
          </Button>
          <span className="text-xs text-muted-foreground px-2">
            Page {currentPage + 1} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="icon"
            className="h-7 w-7"
            disabled={currentPage >= totalPages - 1}
            onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
          >
            <ChevronRight className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-7 w-7"
            disabled={currentPage >= totalPages - 1}
            onClick={() => setPage(totalPages - 1)}
          >
            <ChevronsRight className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
