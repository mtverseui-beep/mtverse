"use client";

import * as React from "react";
import Link from "next/link";
import { BrandLogo } from "@/components/common/brand-logo";
import { cn } from "@/lib/utils";
import { ArrowLeft, ShieldCheck, Sparkles, TrendingUp } from "lucide-react";

/**
 * Shared two-column auth layout.
 * Left = premium brand panel (gradient + showcase image + marketing copy + customer logos).
 * Right = the form content (children).
 *
 * On mobile the brand panel collapses to a compact gradient header.
 */

export type AuthBrandConfig = {
  /** Main marketing headline shown over the showcase image. */
  headline: string;
  /** Sub-headline supporting the headline. */
  subheadline: string;
  /** Unsplash showcase image used as the panel backdrop. */
  showcaseImage: string;
  /** Customer logos strip (text-based wordmarks). */
  customers: string[];
  /** Floating testimonial quote shown near the bottom of the brand panel. */
  testimonial?: {
    quote: string;
    author: string;
    role: string;
    avatar: string;
  };
};

export function AuthShell({
  brand,
  children,
  className,
  wide = false,
}: {
  brand: AuthBrandConfig;
  children: React.ReactNode;
  className?: string;
  /** Expand the form content width — used by the onboarding wizard. */
  wide?: boolean;
}) {
  return (
    <div className="min-h-screen w-full bg-background text-foreground grid lg:grid-cols-[1.05fr_1fr]">
      {/* Brand panel — desktop only */}
      <BrandPanel brand={brand} />

      {/* Form panel */}
      <main
        className={cn(
          "relative flex flex-col min-h-screen",
          className
        )}
      >
        {/* Mobile brand header — compressed gradient strip */}
        <div className="lg:hidden brand-gradient px-5 py-5">
          <BrandLogo size="sm" className="[&_*]:!text-white" />
        </div>

        <div className="flex-1 flex flex-col">
          {/* Top bar with back-to-home */}
          <div className="flex items-center justify-between px-6 lg:px-12 pt-6 lg:pt-8">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to home
            </Link>
            <Link
              href="/dashboards/ecommerce"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              View demo
              <TrendingUp className="h-3.5 w-3.5" />
            </Link>
          </div>

          {/* Form content */}
          <div className="flex-1 flex items-center justify-center px-6 lg:px-12 py-8 lg:py-12">
            <div className={cn("w-full animate-fade-in-up", wide ? "max-w-2xl" : "max-w-md")}>
              {children}
            </div>
          </div>

          {/* Footer */}
          <footer className="px-6 lg:px-12 py-6 flex flex-wrap items-center justify-between gap-3 text-[11px] text-muted-foreground border-t">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
              <span>SOC 2 Type II · GDPR · ISO 27001</span>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/auth/signin" className="hover:text-foreground transition-colors">
                Terms
              </Link>
              <Link href="/auth/signin" className="hover:text-foreground transition-colors">
                Privacy
              </Link>
              <span>© 2026 NexusGrid Labs</span>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
}

function BrandPanel({ brand }: { brand: AuthBrandConfig }) {
  return (
    <aside className="relative hidden lg:flex flex-col overflow-hidden">
      {/* Showcase image backdrop */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${brand.showcaseImage})` }}
        aria-hidden
      />
      {/* Dark gradient overlay for legibility */}
      <div
        className="absolute inset-0 bg-gradient-to-br from-emerald-950/85 via-emerald-900/80 to-teal-950/90"
        aria-hidden
      />
      {/* Decorative blobs */}
      <div
        className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-emerald-400/20 blur-3xl"
        aria-hidden
      />
      <div
        className="absolute -bottom-40 -right-20 h-[28rem] w-[28rem] rounded-full bg-teal-300/15 blur-3xl"
        aria-hidden
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col h-full px-10 xl:px-14 py-10">
        {/* Logo */}
        <div className="flex items-center justify-between">
          <BrandLogo size="md" className="[&_*]:!text-white [&_.text-primary]:!text-emerald-200" />
          <div className="inline-flex items-center gap-1.5 rounded-full bg-white/10 backdrop-blur px-3 py-1.5 text-[11px] font-medium text-white ring-1 ring-white/15">
            <Sparkles className="h-3.5 w-3.5 text-emerald-200" />
            Trusted by 14,000+ teams
          </div>
        </div>

        {/* Marketing copy */}
        <div className="mt-16 xl:mt-24 max-w-md">
          <h2 className="text-3xl xl:text-4xl font-semibold leading-tight tracking-tight text-white">
            {brand.headline}
          </h2>
          <p className="mt-4 text-sm xl:text-base leading-relaxed text-emerald-50/80">
            {brand.subheadline}
          </p>

          {/* Stat row */}
          <div className="mt-8 grid grid-cols-3 gap-4 max-w-sm">
            <Stat value="99.99%" label="Uptime SLA" />
            <Stat value="180+" label="Countries" />
            <Stat value="4.9/5" label="G2 rating" />
          </div>
        </div>

        {/* Testimonial card */}
        {brand.testimonial && (
          <figure className="mt-auto rounded-2xl bg-white/10 backdrop-blur-md ring-1 ring-white/15 p-5 shadow-premium-lg">
            <blockquote className="text-sm leading-relaxed text-white/90">
              “{brand.testimonial.quote}”
            </blockquote>
            <figcaption className="mt-4 flex items-center gap-3">
              <img
                src={brand.testimonial.avatar}
                alt={brand.testimonial.author}
                className="h-9 w-9 rounded-full object-cover ring-2 ring-white/20"
              />
              <div className="leading-tight">
                <div className="text-xs font-semibold text-white">
                  {brand.testimonial.author}
                </div>
                <div className="text-[11px] text-emerald-50/70">
                  {brand.testimonial.role}
                </div>
              </div>
            </figcaption>
          </figure>
        )}

        {/* Customer logos strip */}
        <div className="mt-8">
          <p className="text-[10px] uppercase tracking-[0.18em] text-emerald-50/60 mb-3">
            Powering operations at
          </p>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
            {brand.customers.map((c) => (
              <span
                key={c}
                className="text-sm font-semibold text-white/70 tracking-tight"
              >
                {c}
              </span>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <div className="text-xl font-semibold text-white tabular-nums">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-emerald-50/70 mt-0.5">
        {label}
      </div>
    </div>
  );
}

/**
 * Password strength helper — shared by signup, reset-password, invite, onboarding.
 */
export function strengthOf(pwd: string): {
  score: number;
  label: string;
  tone: string;
} {
  let score = 0;
  if (pwd.length >= 8) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^a-zA-Z0-9]/.test(pwd)) score++;
  if (pwd.length >= 12) score++;
  const map = [
    { label: "Too short", tone: "bg-muted" },
    { label: "Weak", tone: "bg-destructive" },
    { label: "Fair", tone: "bg-amber-500" },
    { label: "Good", tone: "bg-sky-500" },
    { label: "Strong", tone: "bg-emerald-500" },
    { label: "Excellent", tone: "bg-emerald-600" },
  ];
  return { score, ...map[score] };
}

/** Password requirement checklist (shared). */
export const PASSWORD_REQUIREMENTS = [
  { key: "length", label: "At least 8 characters", test: (p: string) => p.length >= 8 },
  { key: "upper", label: "One uppercase letter", test: (p: string) => /[A-Z]/.test(p) },
  { key: "number", label: "One number", test: (p: string) => /[0-9]/.test(p) },
  { key: "symbol", label: "One symbol", test: (p: string) => /[^a-zA-Z0-9]/.test(p) },
] as const;

export function PasswordStrengthBar({ password }: { password: string }) {
  const strength = strengthOf(password);
  if (!password) return null;
  return (
    <div className="flex items-center gap-2 mt-1.5">
      <div className="flex-1 grid grid-cols-5 gap-1">
        {[0, 1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={cn(
              "h-1 rounded-full transition-colors",
              i < strength.score ? strength.tone : "bg-muted"
            )}
          />
        ))}
      </div>
      <span className="text-[10px] font-medium text-muted-foreground w-16 text-right">
        {strength.label}
      </span>
    </div>
  );
}

export function PasswordChecklist({ password }: { password: string }) {
  return (
    <ul className="mt-3 grid gap-1.5">
      {PASSWORD_REQUIREMENTS.map((req) => {
        const ok = req.test(password);
        return (
          <li
            key={req.key}
            className="flex items-center gap-2 text-[11px]"
          >
            <span
              className={cn(
                "grid place-items-center h-3.5 w-3.5 rounded-full transition-colors",
                ok
                  ? "bg-emerald-500 text-white"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {ok ? (
                <svg viewBox="0 0 12 12" className="h-2.5 w-2.5" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                  <path d="M2 6.5L5 9.5L10 3" />
                </svg>
              ) : (
                <span className="h-0.5 w-1.5 rounded-full bg-current" />
              )}
            </span>
            <span className={ok ? "text-foreground" : "text-muted-foreground"}>
              {req.label}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
