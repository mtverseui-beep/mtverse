"use client";

import * as React from "react";
import {
  Area,
  AreaChart as ReAreaChart,
  Bar,
  BarChart as ReBarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart as ReLineChart,
  Pie,
  PieChart as RePieChart,
  RadialBar,
  RadialBarChart,
  Radar,
  RadarChart,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { useTheme } from "@/components/providers/theme-provider";

// Theme-aware chart colors
export const CHART_COLORS = {
  primary: "var(--primary)",
  success: "var(--success)",
  warning: "var(--warning)",
  info: "var(--info)",
  destructive: "var(--destructive)",
  chart2: "oklch(0.70 0.15 75)",
  chart3: "oklch(0.62 0.18 25)",
  chart4: "oklch(0.58 0.13 250)",
  chart5: "oklch(0.62 0.18 305)",
};

const PALETTE = [
  CHART_COLORS.primary,
  CHART_COLORS.chart2,
  CHART_COLORS.chart3,
  CHART_COLORS.chart4,
  CHART_COLORS.chart5,
  CHART_COLORS.info,
];

function useChartTheme() {
  const { theme } = useTheme();
  return {
    grid: theme === "dark" ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)",
    axis: theme === "dark" ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.5)",
    tooltipBg: theme === "dark" ? "rgba(20,20,24,0.95)" : "rgba(255,255,255,0.95)",
    tooltipBorder: theme === "dark" ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)",
    tooltipText: theme === "dark" ? "#fff" : "#000",
  };
}

function ChartTooltip({ active, payload, label }: any) {
  const t = useChartTheme();
  if (!active || !payload || !payload.length) return null;
  return (
    <div
      style={{
        background: t.tooltipBg,
        border: `1px solid ${t.tooltipBorder}`,
        color: t.tooltipText,
        borderRadius: 8,
        padding: "8px 12px",
        fontSize: 12,
        boxShadow: "0 8px 24px -4px rgba(0,0,0,0.15)",
        backdropFilter: "blur(8px)",
      }}
    >
      {label && <div className="font-medium mb-1">{label}</div>}
      <div className="space-y-0.5">
        {payload.map((p: any, i: number) => (
          <div key={i} className="flex items-center gap-2">
            <span
              className="inline-block h-2 w-2 rounded-full"
              style={{ background: p.color || p.fill }}
            />
            <span className="opacity-70">{p.name}:</span>
            <span className="font-medium tabular-nums">
              {typeof p.value === "number" ? p.value.toLocaleString() : p.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export type ChartDatum = Record<string, any>;

export function AreaTrendChart({
  data,
  xKey,
  series,
  height = 280,
  showGrid = true,
  showAxis = true,
  stackId,
}: {
  data: ChartDatum[];
  xKey: string;
  series: { key: string; name: string; color?: string }[];
  height?: number;
  showGrid?: boolean;
  showAxis?: boolean;
  stackId?: string;
}) {
  const t = useChartTheme();
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ReAreaChart data={data} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
        <defs>
          {series.map((s, i) => (
            <linearGradient
              key={s.key}
              id={`grad-${s.key}-${i}`}
              x1="0"
              y1="0"
              x2="0"
              y2="1"
            >
              <stop offset="0%" stopColor={s.color || PALETTE[i % PALETTE.length]} stopOpacity={0.35} />
              <stop offset="100%" stopColor={s.color || PALETTE[i % PALETTE.length]} stopOpacity={0} />
            </linearGradient>
          ))}
        </defs>
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke={t.grid} vertical={false} />}
        {showAxis && <XAxis dataKey={xKey} stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />}
        {showAxis && <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />}
        <Tooltip content={<ChartTooltip />} />
        {series.length > 1 && (
          <Legend
            wrapperStyle={{ fontSize: 11, paddingTop: 8 }}
            iconType="circle"
            iconSize={8}
          />
        )}
        {series.map((s, i) => (
          <Area
            key={s.key}
            type="monotone"
            dataKey={s.key}
            name={s.name}
            stroke={s.color || PALETTE[i % PALETTE.length]}
            strokeWidth={2}
            fill={`url(#grad-${s.key}-${i})`}
            stackId={stackId}
            dot={false}
            activeDot={{ r: 4, strokeWidth: 0 }}
          />
        ))}
      </ReAreaChart>
    </ResponsiveContainer>
  );
}

export function LineTrendChart({
  data,
  xKey,
  series,
  height = 280,
  showGrid = true,
  showAxis = true,
}: {
  data: ChartDatum[];
  xKey: string;
  series: { key: string; name: string; color?: string; dashed?: boolean }[];
  height?: number;
  showGrid?: boolean;
  showAxis?: boolean;
}) {
  const t = useChartTheme();
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ReLineChart data={data} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke={t.grid} vertical={false} />}
        {showAxis && <XAxis dataKey={xKey} stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />}
        {showAxis && <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />}
        <Tooltip content={<ChartTooltip />} />
        {series.length > 1 && (
          <Legend wrapperStyle={{ fontSize: 11, paddingTop: 8 }} iconType="circle" iconSize={8} />
        )}
        {series.map((s, i) => (
          <Line
            key={s.key}
            type="monotone"
            dataKey={s.key}
            name={s.name}
            stroke={s.color || PALETTE[i % PALETTE.length]}
            strokeWidth={2}
            strokeDasharray={s.dashed ? "5 4" : undefined}
            dot={false}
            activeDot={{ r: 4, strokeWidth: 0 }}
          />
        ))}
      </ReLineChart>
    </ResponsiveContainer>
  );
}

export function BarTrendChart({
  data,
  xKey,
  series,
  height = 280,
  showGrid = true,
  showAxis = true,
  stacked = false,
  horizontal = false,
}: {
  data: ChartDatum[];
  xKey: string;
  series: { key: string; name: string; color?: string }[];
  height?: number;
  showGrid?: boolean;
  showAxis?: boolean;
  stacked?: boolean;
  horizontal?: boolean;
}) {
  const t = useChartTheme();
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ReBarChart
        data={data}
        layout={horizontal ? "vertical" : "horizontal"}
        margin={{ top: 8, right: 12, left: -12, bottom: 0 }}
        barGap={2}
      >
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke={t.grid} vertical={horizontal} horizontal={!horizontal} />}
        {showAxis && !horizontal && <XAxis dataKey={xKey} stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />}
        {showAxis && horizontal && <XAxis type="number" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />}
        {showAxis && !horizontal && <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />}
        {showAxis && horizontal && <YAxis dataKey={xKey} type="category" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={80} />}
        <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(127,127,127,0.06)" }} />
        {series.length > 1 && (
          <Legend wrapperStyle={{ fontSize: 11, paddingTop: 8 }} iconType="circle" iconSize={8} />
        )}
        {series.map((s, i) => (
          <Bar
            key={s.key}
            dataKey={s.key}
            name={s.name}
            fill={s.color || PALETTE[i % PALETTE.length]}
            stackId={stacked ? "stack" : undefined}
            radius={stacked ? 0 : [4, 4, 0, 0]}
            maxBarSize={48}
          />
        ))}
      </ReBarChart>
    </ResponsiveContainer>
  );
}

export function DonutChart({
  data,
  height = 240,
  centerLabel,
  centerValue,
  innerRadius = 60,
  outerRadius = 90,
}: {
  data: { name: string; value: number; color?: string }[];
  height?: number;
  centerLabel?: string;
  centerValue?: string | number;
  innerRadius?: number;
  outerRadius?: number;
}) {
  return (
    <div className="relative" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RePieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            innerRadius={innerRadius}
            outerRadius={outerRadius}
            paddingAngle={2}
            stroke="none"
          >
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.color || PALETTE[i % PALETTE.length]} />
            ))}
          </Pie>
          <Tooltip content={<ChartTooltip />} />
          {data.length > 1 && (
            <Legend
              wrapperStyle={{ fontSize: 11, paddingTop: 8 }}
              iconType="circle"
              iconSize={8}
              verticalAlign="bottom"
            />
          )}
        </RePieChart>
      </ResponsiveContainer>
      {(centerLabel || centerValue) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none -mt-12">
          {centerValue && (
            <span className="text-2xl font-semibold tabular-nums">{centerValue}</span>
          )}
          {centerLabel && (
            <span className="text-xs text-muted-foreground mt-0.5">{centerLabel}</span>
          )}
        </div>
      )}
    </div>
  );
}

export function RadialProgress({
  value,
  size = 160,
  color = CHART_COLORS.primary,
  label,
  sublabel,
}: {
  value: number; // 0-100
  size?: number;
  color?: string;
  label?: string;
  sublabel?: string;
}) {
  const data = [{ name: "progress", value, fill: color }];
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart
          data={data}
          startAngle={90}
          endAngle={90 - 360 * (value / 100)}
          innerRadius="70%"
          outerRadius="100%"
          cx="50%"
          cy="50%"
        >
          <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
          <RadialBar background={{ fill: "var(--muted)" }} dataKey="value" cornerRadius={20} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <span className="text-2xl font-semibold tabular-nums">{value}%</span>
        {label && <span className="text-xs text-muted-foreground mt-0.5">{label}</span>}
        {sublabel && <span className="text-[10px] text-muted-foreground">{sublabel}</span>}
      </div>
    </div>
  );
}

export function RadarComparison({
  data,
  axisKey,
  series,
  height = 280,
}: {
  data: ChartDatum[];
  axisKey: string;
  series: { key: string; name: string; color?: string }[];
  height?: number;
}) {
  const t = useChartTheme();
  return (
    <ResponsiveContainer width="100%" height={height}>
      <RadarChart data={data} cx="50%" cy="50%" outerRadius="70%">
        <PolarGrid stroke={t.grid} />
        <PolarAngleAxis dataKey={axisKey} stroke={t.axis} fontSize={11} />
        <PolarRadiusAxis stroke={t.axis} fontSize={10} angle={90} />
        {series.map((s, i) => (
          <Radar
            key={s.key}
            name={s.name}
            dataKey={s.key}
            stroke={s.color || PALETTE[i % PALETTE.length]}
            fill={s.color || PALETTE[i % PALETTE.length]}
            fillOpacity={0.15}
            strokeWidth={2}
          />
        ))}
        <Tooltip content={<ChartTooltip />} />
        {series.length > 1 && (
          <Legend wrapperStyle={{ fontSize: 11, paddingTop: 8 }} iconType="circle" iconSize={8} />
        )}
      </RadarChart>
    </ResponsiveContainer>
  );
}

export { PALETTE };
