"use client";

import * as React from "react";

const STORAGE_KEY = "nexusgrid-recent-pages";
const MAX_RECENT = 12;

type RecentPage = {
  path: string;
  label: string;
  visitedAt: number;
};

type RecentPagesContextValue = {
  recentPages: RecentPage[];
  recordVisit: (path: string, label: string) => void;
  clearRecent: () => void;
};

const RecentPagesContext = React.createContext<RecentPagesContextValue | undefined>(undefined);

export function RecentPagesProvider({ children }: { children: React.ReactNode }) {
  const [recentPages, setRecentPages] = React.useState<RecentPage[]>([]);

  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setRecentPages(JSON.parse(raw));
    } catch {}
  }, []);

  const recordVisit = React.useCallback((path: string, label: string) => {
    setRecentPages((prev) => {
      const filtered = prev.filter((p) => p.path !== path);
      const next = [{ path, label, visitedAt: Date.now() }, ...filtered].slice(0, MAX_RECENT);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
  }, []);

  const clearRecent = React.useCallback(() => {
    setRecentPages([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
  }, []);

  return (
    <RecentPagesContext.Provider value={{ recentPages, recordVisit, clearRecent }}>
      {children}
    </RecentPagesContext.Provider>
  );
}

export function useRecentPages() {
  const ctx = React.useContext(RecentPagesContext);
  if (!ctx) throw new Error("useRecentPages must be used within RecentPagesProvider");
  return ctx;
}
