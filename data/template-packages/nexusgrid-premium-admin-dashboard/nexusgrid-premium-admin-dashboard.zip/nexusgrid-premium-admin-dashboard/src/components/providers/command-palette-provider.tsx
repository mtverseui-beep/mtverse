"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useTheme } from "@/components/providers/theme-provider";
import { useRecentPages } from "@/components/providers/recent-pages-provider";
import { navigation, flatNav, quickActions } from "@/config/navigation";
import { Moon, Sun, Search, ArrowUp, History, Star, Plus, FileText } from "lucide-react";

type CommandPaletteContextValue = {
  open: boolean;
  setOpen: (o: boolean) => void;
  toggle: () => void;
};

const Ctx = React.createContext<CommandPaletteContextValue | undefined>(undefined);

export function CommandPaletteProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, []);

  const value = React.useMemo(
    () => ({ open, setOpen, toggle: () => setOpen((o) => !o) }),
    [open]
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      <CommandPaletteInner />
    </Ctx.Provider>
  );
}

export function useCommandPalette() {
  const ctx = React.useContext(Ctx);
  if (!ctx) throw new Error("useCommandPalette must be used within CommandPaletteProvider");
  return ctx;
}

function CommandPaletteInner() {
  const { open, setOpen } = useCommandPalette();
  const router = useRouter();
  const { theme, toggleTheme } = useTheme();
  const { recentPages } = useRecentPages();

  const go = React.useCallback(
    (href: string) => {
      setOpen(false);
      // Use a small delay to allow dialog to close smoothly
      setTimeout(() => router.push(href), 50);
    },
    [router, setOpen]
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="overflow-hidden p-0 shadow-premium-lg max-w-2xl">
        <DialogTitle className="sr-only">Command palette</DialogTitle>
        <DialogDescription className="sr-only">
          Search pages, run quick actions, and navigate NexusGrid.
        </DialogDescription>
        <Command className="rounded-xl">
          <div className="flex items-center border-b border-border px-3" cmdk-input-wrapper="">
            <Search className="mr-2 h-4 w-4 shrink-0 text-muted-foreground" />
            <CommandInput
              placeholder="Search pages, actions, records..."
              className="h-12 border-0 ring-0 focus:ring-0 focus-visible:ring-0"
            />
          </div>
          <CommandList className="max-h-[420px] overflow-y-auto">
            <CommandEmpty>
              <div className="py-8 text-center">
                <p className="text-sm font-medium">No results found</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try a different query or browse the sidebar.
                </p>
              </div>
            </CommandEmpty>

            {recentPages.length > 0 && (
              <CommandGroup heading="Recently visited">
                {recentPages.slice(0, 5).map((p) => (
                  <CommandItem
                    key={p.path}
                    value={`recent ${p.label} ${p.path}`}
                    onSelect={() => go(p.path)}
                    className="gap-2"
                  >
                    <History className="h-4 w-4 text-muted-foreground" />
                    <span className="flex-1">{p.label}</span>
                    <span className="text-xs text-muted-foreground">{p.path}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}

            <CommandGroup heading="Quick actions">
              {quickActions.map((a) => (
                <CommandItem
                  key={a.title}
                  value={`action ${a.title}`}
                  onSelect={() => go(a.href)}
                  className="gap-2"
                >
                  <Plus className="h-4 w-4 text-primary" />
                  <span className="flex-1">{a.title}</span>
                </CommandItem>
              ))}
            </CommandGroup>

            <CommandSeparator />

            {navigation.map((group) => (
              <CommandGroup key={group.title} heading={group.title}>
                {group.items.map((item) => (
                  <CommandItem
                    key={item.href}
                    value={`${item.title} ${group.title} ${item.href}`}
                    onSelect={() => go(item.href)}
                    className="gap-2"
                  >
                    {item.icon ? (
                      <item.icon className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <FileText className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className="flex-1">{item.title}</span>
                    {item.badge && (
                      <span className="text-[10px] uppercase tracking-wide text-primary font-medium">
                        {item.badge}
                      </span>
                    )}
                  </CommandItem>
                ))}
              </CommandGroup>
            ))}

            <CommandSeparator />

            <CommandGroup heading="Preferences">
              <CommandItem
                value="toggle theme dark light"
                onSelect={() => {
                  toggleTheme();
                  setOpen(false);
                }}
                className="gap-2"
              >
                {theme === "dark" ? (
                  <Sun className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <Moon className="h-4 w-4 text-muted-foreground" />
                )}
                <span>Switch to {theme === "dark" ? "light" : "dark"} theme</span>
                <CommandShortcut>⌘D</CommandShortcut>
              </CommandItem>
            </CommandGroup>
          </CommandList>

          <div className="flex items-center justify-between border-t border-border bg-muted/30 px-3 py-2 text-[11px] text-muted-foreground">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <kbd className="rounded bg-background border border-border px-1.5 py-0.5 font-mono">↑↓</kbd>
                Navigate
              </span>
              <span className="flex items-center gap-1">
                <kbd className="rounded bg-background border border-border px-1.5 py-0.5 font-mono">↵</kbd>
                Select
              </span>
              <span className="flex items-center gap-1">
                <kbd className="rounded bg-background border border-border px-1.5 py-0.5 font-mono">esc</kbd>
                Close
              </span>
            </div>
            <span className="hidden sm:flex items-center gap-1">
              <Star className="h-3 w-3" />
              NexusGrid v1.0
            </span>
          </div>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
