// Centralized mock data for dashboards. Realistic fake data.

export const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export const weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

// Helper to generate revenue-like series
function genSeries(base: number, variance: number, count: number, trend = 0) {
  return Array.from({ length: count }, (_, i) => {
    const noise = (Math.sin(i * 0.7) + Math.cos(i * 1.3)) * variance;
    return Math.max(0, Math.round(base + noise + trend * i));
  });
}

// ECOMMERCE DATA
export const ecommerceRevenueData = months.map((m, i) => ({
  month: m,
  revenue: 42000 + Math.round(Math.sin(i * 0.8) * 8000 + i * 2200),
  orders: 320 + Math.round(Math.cos(i * 0.6) * 60 + i * 18),
  refunds: 28 + Math.round(Math.sin(i * 1.1) * 8),
}));

export const ecommerceFunnel = [
  { stage: "Visitors", value: 84520, color: "var(--info)" },
  { stage: "Product Views", value: 52340, color: "oklch(0.58 0.13 250)" },
  { stage: "Add to Cart", value: 18920, color: "var(--primary)" },
  { stage: "Checkout", value: 9540, color: "oklch(0.70 0.15 75)" },
  { stage: "Purchased", value: 6210, color: "var(--success)" },
];

export const topProducts = [
  { id: "NX-1001", name: "Aether Wireless Headphones", sku: "AET-WH-BLK", sold: 1842, revenue: 184200, stock: 124, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=80&h=80&fit=crop", trend: 12.4 },
  { id: "NX-1002", name: "Lumen Smart Desk Lamp", sku: "LUM-SDL-WHT", sold: 1620, revenue: 97200, stock: 86, image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=80&h=80&fit=crop", trend: 8.2 },
  { id: "NX-1003", name: "Vertex Mechanical Keyboard", sku: "VRT-MK-87", sold: 1456, revenue: 218400, stock: 42, image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=80&h=80&fit=crop", trend: -3.1 },
  { id: "NX-1004", name: "Pulse Fitness Tracker", sku: "PLS-FT-GRN", sold: 1284, revenue: 89880, stock: 218, image: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=80&h=80&fit=crop", trend: 18.6 },
  { id: "NX-1005", name: "Nova Travel Backpack", sku: "NOV-TB-40L", sold: 1142, revenue: 91360, stock: 9, image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=80&h=80&fit=crop", trend: 5.4 },
];

export const recentOrders = [
  { id: "NX-3948", customer: "Sarah Chen", email: "sarah@example.com", total: 428.50, status: "completed", payment: "paid", date: "2026-07-01", items: 3 },
  { id: "NX-3947", customer: "Marcus Reyes", email: "marcus@example.com", total: 186.00, status: "processing", payment: "paid", date: "2026-07-01", items: 1 },
  { id: "NX-3946", customer: "Elena Petrov", email: "elena@example.com", total: 742.25, status: "shipped", payment: "paid", date: "2026-06-30", items: 5 },
  { id: "NX-3945", customer: "James Okoro", email: "james@example.com", total: 96.99, status: "completed", payment: "refunded", date: "2026-06-30", items: 2 },
  { id: "NX-3944", customer: "Aiko Tanaka", email: "aiko@example.com", total: 312.00, status: "pending", payment: "pending", date: "2026-06-30", items: 2 },
  { id: "NX-3943", customer: "David Kim", email: "david@example.com", total: 528.75, status: "completed", payment: "paid", date: "2026-06-29", items: 4 },
  { id: "NX-3942", customer: "Lena Hoffmann", email: "lena@example.com", total: 144.50, status: "cancelled", payment: "refunded", date: "2026-06-29", items: 1 },
];

export const customerSegments = [
  { name: "VIP Customers", value: 1840, color: "var(--primary)" },
  { name: "Repeat Buyers", value: 8420, color: "oklch(0.70 0.15 75)" },
  { name: "New Customers", value: 12680, color: "var(--info)" },
  { name: "At-Risk", value: 3210, color: "var(--warning)" },
  { name: "Churned", value: 1840, color: "var(--destructive)" },
];

// ANALYTICS DATA
export const analyticsTraffic = [
  { date: "Jul 01", users: 8420, sessions: 11240, pageviews: 28430, newUsers: 3120 },
  { date: "Jul 02", users: 9210, sessions: 12480, pageviews: 31250, newUsers: 3420 },
  { date: "Jul 03", users: 8890, sessions: 11820, pageviews: 29870, newUsers: 3180 },
  { date: "Jul 04", users: 10240, sessions: 13960, pageviews: 35120, newUsers: 4280 },
  { date: "Jul 05", users: 11320, sessions: 15280, pageviews: 38940, newUsers: 4920 },
  { date: "Jul 06", users: 12480, sessions: 16820, pageviews: 42380, newUsers: 5680 },
  { date: "Jul 07", users: 11840, sessions: 16120, pageviews: 40280, newUsers: 5240 },
];

export const analyticsSources = [
  { name: "Organic Search", value: 38420, color: "var(--primary)" },
  { name: "Direct", value: 21840, color: "oklch(0.70 0.15 75)" },
  { name: "Social", value: 14820, color: "var(--info)" },
  { name: "Referral", value: 9420, color: "oklch(0.62 0.18 25)" },
  { name: "Email", value: 6280, color: "oklch(0.58 0.13 250)" },
  { name: "Paid", value: 4820, color: "oklch(0.62 0.18 305)" },
];

export const analyticsDevices = [
  { name: "Desktop", value: 58, color: "var(--primary)" },
  { name: "Mobile", value: 34, color: "oklch(0.70 0.15 75)" },
  { name: "Tablet", value: 8, color: "var(--info)" },
];

export const topPages = [
  { path: "/dashboard", views: 8420, bounce: 32, avgTime: "2m 18s" },
  { path: "/pricing", views: 6820, bounce: 41, avgTime: "1m 52s" },
  { path: "/features/analytics", views: 5240, bounce: 28, avgTime: "3m 12s" },
  { path: "/blog/scaling-saas", views: 4180, bounce: 22, avgTime: "4m 38s" },
  { path: "/docs/quickstart", views: 3920, bounce: 18, avgTime: "5m 24s" },
  { path: "/changelog", views: 2840, bounce: 35, avgTime: "2m 06s" },
];

// CRM DATA
export const crmPipeline = [
  { stage: "Lead", value: 124, amount: 248000, color: "var(--info)" },
  { stage: "Qualified", value: 86, amount: 412000, color: "oklch(0.58 0.13 250)" },
  { stage: "Proposal", value: 42, amount: 384000, color: "var(--primary)" },
  { stage: "Negotiation", value: 28, amount: 312000, color: "oklch(0.70 0.15 75)" },
  { stage: "Won", value: 18, amount: 248000, color: "var(--success)" },
];

export const crmActivities = [
  { type: "call", title: "Discovery call with Globex Corp", owner: "Sarah Chen", time: "10 min ago", tone: "primary" },
  { type: "email", title: "Sent proposal to Initech", owner: "Marcus Reyes", time: "32 min ago", tone: "info" },
  { type: "meeting", title: "Demo scheduled with Hooli", owner: "Elena Petrov", time: "1 hr ago", tone: "violet" },
  { type: "note", title: "Added follow-up reminder for Acme", owner: "James Okoro", time: "2 hr ago", tone: "neutral" },
  { type: "won", title: "Closed deal with Umbrella Inc", owner: "Aiko Tanaka", time: "3 hr ago", tone: "success" },
];

export const dealsByStage = months.slice(0, 6).map((m, i) => ({
  month: m,
  won: 12 + i * 2 + Math.round(Math.sin(i) * 3),
  lost: 4 + Math.round(Math.cos(i) * 2),
  open: 28 + i * 3,
}));

// SALES OPS DATA
export const salesReps = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", quota: 240000, attainment: 286000, deals: 24, winRate: 68 },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", quota: 240000, attainment: 218000, deals: 19, winRate: 58 },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", quota: 240000, attainment: 312000, deals: 28, winRate: 72 },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", quota: 240000, attainment: 194000, deals: 16, winRate: 52 },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", quota: 240000, attainment: 268000, deals: 22, winRate: 64 },
];

// FINANCE DATA
export const financeCashflow = months.map((m, i) => ({
  month: m,
  inflow: 280000 + Math.round(Math.sin(i * 0.8) * 42000 + i * 8000),
  outflow: 198000 + Math.round(Math.cos(i * 0.6) * 28000 + i * 4200),
}));

export const financeExpenses = [
  { name: "Payroll", value: 142000, color: "var(--primary)" },
  { name: "Infrastructure", value: 48000, color: "oklch(0.70 0.15 75)" },
  { name: "Marketing", value: 38000, color: "var(--info)" },
  { name: "Operations", value: 28000, color: "oklch(0.62 0.18 25)" },
  { name: "Other", value: 18000, color: "oklch(0.58 0.13 250)" },
];

// MARKETING DATA
export const marketingCampaigns = [
  { name: "Summer Launch 2026", channel: "Email", impressions: 142000, clicks: 8400, conversions: 1280, roas: 4.8, status: "active" },
  { name: "Retargeting Q3", channel: "Meta Ads", impressions: 384000, clicks: 12400, conversions: 2180, roas: 3.2, status: "active" },
  { name: "Google Search - Brand", channel: "Google Ads", impressions: 92000, clicks: 6800, conversions: 1840, roas: 8.4, status: "active" },
  { name: "YouTube Pre-roll", channel: "YouTube", impressions: 524000, clicks: 4200, conversions: 480, roas: 1.8, status: "paused" },
  { name: "LinkedIn Outreach", channel: "LinkedIn", impressions: 38000, clicks: 2100, conversions: 320, roas: 5.2, status: "active" },
];

export const marketingChannels = [
  { name: "Organic", value: 38, color: "var(--primary)" },
  { name: "Paid Search", value: 24, color: "oklch(0.70 0.15 75)" },
  { name: "Social", value: 18, color: "var(--info)" },
  { name: "Email", value: 12, color: "oklch(0.62 0.18 25)" },
  { name: "Direct", value: 8, color: "oklch(0.58 0.13 250)" },
];

// PROJECTS DATA
export const projectHealth = [
  { name: "On Track", value: 18, color: "var(--success)" },
  { name: "At Risk", value: 6, color: "var(--warning)" },
  { name: "Delayed", value: 3, color: "var(--destructive)" },
  { name: "Completed", value: 12, color: "var(--primary)" },
];

export const projectWorkload = [
  { name: "Sarah", design: 32, dev: 12, review: 8 },
  { name: "Marcus", design: 12, dev: 38, review: 14 },
  { name: "Elena", design: 24, dev: 28, review: 18 },
  { name: "James", design: 8, dev: 42, review: 6 },
  { name: "Aiko", design: 18, dev: 22, review: 24 },
];

// HR DATA
export const hrHeadcount = [
  { dept: "Engineering", current: 84, openRoles: 6 },
  { dept: "Sales", current: 42, openRoles: 4 },
  { dept: "Marketing", current: 28, openRoles: 2 },
  { dept: "Support", current: 36, openRoles: 8 },
  { dept: "Operations", current: 22, openRoles: 1 },
  { dept: "Finance", current: 14, openRoles: 0 },
];

export const hrAttrition = months.map((m, i) => ({
  month: m,
  hires: 8 + Math.round(Math.sin(i * 0.7) * 4 + 2),
  departures: 4 + Math.round(Math.cos(i * 0.5) * 2 + 1),
}));

// LOGISTICS DATA
export const shipments = [
  { id: "SHP-94821", carrier: "DHL", origin: "Shanghai", destination: "Los Angeles", status: "in-transit", eta: "2026-07-04", weight: "2.4t" },
  { id: "SHP-94820", carrier: "FedEx", origin: "Hamburg", destination: "New York", status: "delivered", eta: "2026-07-01", weight: "1.2t" },
  { id: "SHP-94819", carrier: "Maersk", origin: "Singapore", destination: "Rotterdam", status: "in-transit", eta: "2026-07-12", weight: "18.6t" },
  { id: "SHP-94818", carrier: "UPS", origin: "Tokyo", destination: "Sydney", status: "delayed", eta: "2026-07-03", weight: "0.8t" },
  { id: "SHP-94817", carrier: "DHL", origin: "Mumbai", destination: "Dubai", status: "customs", eta: "2026-07-02", weight: "4.2t" },
];

// HEALTHCARE DATA
export const patientFlow = [
  { hour: "06h", admissions: 8, discharges: 4 },
  { hour: "08h", admissions: 14, discharges: 6 },
  { hour: "10h", admissions: 22, discharges: 12 },
  { hour: "12h", admissions: 18, discharges: 18 },
  { hour: "14h", admissions: 24, discharges: 16 },
  { hour: "16h", admissions: 16, discharges: 22 },
  { hour: "18h", admissions: 12, discharges: 14 },
  { hour: "20h", admissions: 8, discharges: 10 },
];

// EDUCATION DATA
export const courseEnrollment = [
  { name: "Computer Science 101", students: 248, completion: 78, color: "var(--primary)" },
  { name: "Design Systems", students: 184, completion: 84, color: "oklch(0.70 0.15 75)" },
  { name: "Data Analytics", students: 162, completion: 71, color: "var(--info)" },
  { name: "Marketing Strategy", students: 128, completion: 88, color: "oklch(0.62 0.18 25)" },
  { name: "Product Management", students: 112, completion: 82, color: "oklch(0.58 0.13 250)" },
];

// REAL ESTATE DATA
export const propertyListings = [
  { id: "PROP-4821", address: "1284 Pacific Ave, San Francisco", type: "Condo", price: 1280000, status: "active", beds: 2, baths: 2, sqft: 1240 },
  { id: "PROP-4820", address: "47 Birchwood Drive, Austin", type: "Single Family", price: 685000, status: "pending", beds: 4, baths: 3, sqft: 2840 },
  { id: "PROP-4819", address: "92 Riverside Lane, Boston", type: "Townhouse", price: 920000, status: "active", beds: 3, baths: 2, sqft: 1860 },
  { id: "PROP-4818", address: "1405 Sunset Blvd, Los Angeles", type: "Condo", price: 745000, status: "sold", beds: 1, baths: 1, sqft: 820 },
];

// BOOKING DATA
export const bookings = [
  { id: "BKG-9210", customer: "Olivia Bennett", service: "Spa Day Package", date: "2026-07-02", time: "10:00", status: "confirmed", amount: 280 },
  { id: "BKG-9209", customer: "Ethan Wright", service: "Personal Training", date: "2026-07-02", time: "11:30", status: "confirmed", amount: 90 },
  { id: "BKG-9208", customer: "Sophia Martinez", service: "Conference Room A", date: "2026-07-02", time: "14:00", status: "pending", amount: 240 },
  { id: "BKG-9207", customer: "Liam Anderson", service: "Yoga Class", date: "2026-07-02", time: "08:00", status: "completed", amount: 35 },
  { id: "BKG-9206", customer: "Ava Thompson", service: "Massage Therapy", date: "2026-07-01", time: "16:00", status: "cancelled", amount: 120 },
];

// SAAS DATA
export const saasMrr = months.map((m, i) => ({
  month: m,
  mrr: 84000 + i * 4200 + Math.round(Math.sin(i * 0.8) * 6000),
  churn: 1800 + Math.round(Math.cos(i * 0.6) * 600),
}));

export const saasCohorts = [
  { cohort: "Jan 2026", m0: 100, m1: 92, m2: 86, m3: 82, m4: 78, m5: 76, m6: 74 },
  { cohort: "Feb 2026", m0: 100, m1: 94, m2: 88, m3: 84, m4: 80, m5: 78, m6: null },
  { cohort: "Mar 2026", m0: 100, m1: 91, m2: 85, m3: 81, m4: 79, m5: null, m6: null },
  { cohort: "Apr 2026", m0: 100, m1: 95, m2: 89, m3: 86, m4: null, m5: null, m6: null },
  { cohort: "May 2026", m0: 100, m1: 93, m2: 88, m3: null, m4: null, m5: null, m6: null },
  { cohort: "Jun 2026", m0: 100, m1: 96, m2: null, m3: null, m4: null, m5: null, m6: null },
];

// SUPPORT DATA
export const supportTickets = [
  { id: "TKT-4821", subject: "Cannot import CSV file", priority: "high", status: "open", customer: "Globex Corp", agent: "Sarah C.", created: "2 hr ago" },
  { id: "TKT-4820", subject: "Billing discrepancy on invoice", priority: "urgent", status: "open", customer: "Initech", agent: "Marcus R.", created: "4 hr ago" },
  { id: "TKT-4819", subject: "Feature request: dark mode", priority: "low", status: "pending", customer: "Hooli", agent: "—", created: "6 hr ago" },
  { id: "TKT-4818", subject: "API rate limit question", priority: "medium", status: "resolved", customer: "Umbrella Inc", agent: "Elena P.", created: "8 hr ago" },
  { id: "TKT-4817", subject: "Login 2FA not working", priority: "high", status: "resolved", customer: "Acme Corp", agent: "James O.", created: "12 hr ago" },
];

export const supportSla = [
  { name: "Resolved < 1h", value: 68, color: "var(--success)" },
  { name: "Resolved < 4h", value: 22, color: "var(--primary)" },
  { name: "Resolved < 24h", value: 8, color: "var(--warning)" },
  { name: "Breached SLA", value: 2, color: "var(--destructive)" },
];
