"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { AdminShell } from "@/components/layout/admin-shell";
import { Loader2 } from "lucide-react";

export default function Home() {
  const router = useRouter();
  React.useEffect(() => {
    router.replace("/dashboards/ecommerce");
  }, [router]);

  return (
    <AdminShell>
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <p className="text-sm">Loading NexusGrid...</p>
        </div>
      </div>
    </AdminShell>
  );
}
