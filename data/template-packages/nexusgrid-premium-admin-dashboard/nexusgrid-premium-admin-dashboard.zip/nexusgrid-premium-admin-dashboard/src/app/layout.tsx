import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/providers/theme-provider";
import { CommandPaletteProvider } from "@/components/providers/command-palette-provider";
import { RecentPagesProvider } from "@/components/providers/recent-pages-provider";

const interSans = Inter({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "NexusGrid — Premium Admin Dashboard",
    template: "%s · NexusGrid",
  },
  description:
    "NexusGrid is a premium, production-ready Next.js admin dashboard kit for SaaS, CRM, ecommerce, analytics, finance, HR, logistics, healthcare, and operations teams.",
  keywords: [
    "NexusGrid",
    "admin dashboard",
    "Next.js dashboard",
    "premium admin template",
    "SaaS dashboard",
    "CRM",
    "analytics",
  ],
  authors: [{ name: "NexusGrid Labs" }],
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "NexusGrid — Premium Admin Dashboard Kit",
    description:
      "A premium commercial Next.js admin dashboard with 100+ pages, 15 dashboards, advanced tables, charts, forms, and full dark/light mode.",
    siteName: "NexusGrid",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "NexusGrid — Premium Admin Dashboard Kit",
    description: "A premium commercial Next.js admin dashboard with 100+ pages.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <head>
        {/* Prevent hydration flicker: apply persisted theme before React hydrates */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('nexusgrid-theme');var m=window.matchMedia('(prefers-color-scheme: light)').matches;if(t==='light'){document.documentElement.classList.remove('dark');}else if(t==='dark'){document.documentElement.classList.add('dark');}else if(!m){document.documentElement.classList.add('dark');}else{document.documentElement.classList.remove('dark');}}catch(e){}})();`,
          }}
        />
      </head>
      <body
        className={`${interSans.variable} ${jetbrainsMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider>
          <RecentPagesProvider>
            <CommandPaletteProvider>
              {children}
              <Toaster />
              <SonnerToaster richColors closeButton position="bottom-right" />
            </CommandPaletteProvider>
          </RecentPagesProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
