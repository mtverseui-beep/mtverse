"use client";

import * as React from "react";
import {
  Shield,
  Lock,
  Key,
  Smartphone,
  Laptop,
  Monitor,
  Tablet,
  LogOut,
  Eye,
  EyeOff,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Trash2,
  QrCode,
  Fingerprint,
  Download,
  MapPin,
  Clock,
  Copy,
  RefreshCw,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function strengthOf(pw: string) {
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^a-zA-Z0-9]/.test(pw)) score++;
  return score;
}

const STRENGTH_LABELS = ["Too short", "Weak", "Fair", "Good", "Strong", "Excellent"];
const STRENGTH_COLORS = [
  "bg-muted",
  "bg-destructive",
  "bg-[color:var(--warning)]",
  "bg-[color:var(--info)]",
  "bg-[color:var(--success)]",
  "bg-[color:var(--success)]",
];

type Session = {
  id: string;
  device: "laptop" | "monitor" | "tablet" | "smartphone";
  browser: string;
  location: string;
  ip: string;
  lastActive: string;
  current: boolean;
  trusted: boolean;
};

const SESSIONS: Session[] = [
  { id: "s1", device: "laptop", browser: "Chrome 126 · macOS 14.5", location: "San Francisco, CA", ip: "73.158.42.10", lastActive: "Active now", current: true, trusted: true },
  { id: "s2", device: "smartphone", browser: "Safari Mobile · iOS 17.5", location: "San Francisco, CA", ip: "73.158.42.11", lastActive: "12 min ago", current: false, trusted: true },
  { id: "s3", device: "laptop", browser: "Firefox 127 · Ubuntu 24.04", location: "Berlin, DE", ip: "85.214.132.88", lastActive: "3 hours ago", current: false, trusted: true },
  { id: "s4", device: "tablet", browser: "Safari · iPadOS 17.5", location: "San Francisco, CA", ip: "73.158.42.18", lastActive: "Yesterday", current: false, trusted: false },
  { id: "s5", device: "monitor", browser: "Edge 126 · Windows 11", location: "New York, NY", ip: "108.19.44.201", lastActive: "2 days ago", current: false, trusted: false },
];

const deviceIcon = { laptop: Laptop, monitor: Monitor, tablet: Tablet, smartphone: Smartphone };

type LogEntry = {
  id: string;
  event: string;
  detail: string;
  ip: string;
  time: string;
  status: "success" | "warning" | "danger";
};

const LOGS: LogEntry[] = [
  { id: "l1", event: "Sign-in", detail: "Two-factor verified via authenticator app", ip: "73.158.42.10", time: "Today, 9:14 AM", status: "success" },
  { id: "l2", event: "Password changed", detail: "Password rotated from Settings", ip: "73.158.42.10", time: "Today, 8:02 AM", status: "success" },
  { id: "l3", event: "Failed sign-in", detail: "Incorrect password (1 attempt)", ip: "193.32.162.44", time: "Yesterday, 11:48 PM", status: "danger" },
  { id: "l4", event: "Recovery codes generated", detail: "10 single-use codes issued", ip: "73.158.42.10", time: "Yesterday, 6:30 PM", status: "warning" },
  { id: "l5", event: "Sign-in", detail: "New device · MacBook Pro", ip: "73.158.42.10", time: "Yesterday, 2:15 PM", status: "success" },
  { id: "l6", event: "API key revoked", detail: "Key “legacy-cron” terminated", ip: "73.158.42.10", time: "2 days ago", status: "warning" },
  { id: "l7", event: "Sign-in", detail: "Two-factor verified via SMS", ip: "85.214.132.88", time: "3 days ago", status: "success" },
];

export default function SecurityPage() {
  const [pw, setPw] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [showPw, setShowPw] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [twoFA, setTwoFA] = React.useState(false);
  const [sms2FA, setSms2FA] = React.useState(false);
  const [recoveryDownloaded, setRecoveryDownloaded] = React.useState(false);
  const [deleteTyped, setDeleteTyped] = React.useState("");

  const strength = strengthOf(pw);
  const matches = pw && confirm && pw === confirm;

  const deviceCount = SESSIONS.filter((s) => !s.current).length;

  return (
    <>
      <PageHeader
        title="Security"
        description="Protect your account with strong authentication, monitor active sessions, and review the security log."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Account" }, { label: "Security" }]}
        icon={Shield}
        actions={
          <StatusBadge tone="success" dot>Protected</StatusBadge>
        }
      />

      {/* TOP SUMMARY STRIP */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { icon: Shield, tone: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Security score", value: "92 / 100", hint: "Strong" },
          { icon: Key, tone: "bg-primary/12 text-primary", label: "Password age", value: "42 days", hint: "Rotate in 48d" },
          { icon: Laptop, tone: "bg-[color:var(--info)]/12 text-[color:var(--info)]", label: "Active sessions", value: String(SESSIONS.length), hint: `${deviceCount} other devices` },
          { icon: Fingerprint, tone: "bg-violet-500/12 text-violet-500", label: "2FA status", value: twoFA ? "Enabled" : "Disabled", hint: twoFA ? "Authenticator" : "Recommended" },
        ].map((s) => (
          <Card key={s.label} className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("grid place-items-center h-7 w-7 rounded-md", s.tone)}><s.icon className="h-3.5 w-3.5" /></div>
              <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</span>
            </div>
            <p className="text-xl font-semibold tabular-nums leading-tight">{s.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.hint}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* PASSWORD CHANGE */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Lock className="h-4 w-4 text-primary" /> Change password
            </CardTitle>
            <CardDescription>Use 12+ characters with letters, numbers, and symbols.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="grid gap-1.5">
              <Label className="text-xs">Current password</Label>
              <Input type="password" placeholder="••••••••••••" />
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">New password</Label>
              <div className="relative">
                <Input
                  type={showPw ? "text" : "password"}
                  value={pw}
                  onChange={(e) => setPw(e.target.value)}
                  placeholder="Enter new password"
                  className="pr-9"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPw ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              {/* Strength meter */}
              {pw && (
                <div className="mt-2">
                  <div className="flex gap-1">
                    {[0, 1, 2, 3, 4].map((i) => (
                      <div key={i} className="h-1.5 flex-1 rounded-full bg-muted overflow-hidden">
                        <div
                          className={cn("h-full transition-all", i < strength ? STRENGTH_COLORS[strength] : "bg-transparent")}
                          style={{ width: i < strength ? "100%" : "0%" }}
                        />
                      </div>
                    ))}
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-1.5">
                    Strength: <span className={cn("font-medium", strength <= 1 ? "text-destructive" : strength === 2 ? "text-[color:var(--warning)]" : "text-[color:var(--success)]")}>{STRENGTH_LABELS[strength]}</span>
                  </p>
                  <ul className="mt-2 space-y-1 text-[11px]">
                    <Requirement ok={pw.length >= 12} label="At least 12 characters" />
                    <Requirement ok={/[a-z]/.test(pw) && /[A-Z]/.test(pw)} label="Mix of upper and lowercase letters" />
                    <Requirement ok={/\d/.test(pw)} label="At least one number" />
                    <Requirement ok={/[^a-zA-Z0-9]/.test(pw)} label="At least one symbol" />
                  </ul>
                </div>
              )}
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">Confirm new password</Label>
              <div className="relative">
                <Input
                  type={showConfirm ? "text" : "password"}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="Re-enter new password"
                  className="pr-9"
                />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showConfirm ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              {confirm && (
                <p className={cn("text-[11px] mt-1 flex items-center gap-1", matches ? "text-[color:var(--success)]" : "text-destructive")}>
                  {matches ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                  {matches ? "Passwords match" : "Passwords don't match"}
                </p>
              )}
            </div>
            <Button
              className="gap-1.5"
              disabled={!pw || !matches || strength < 3}
              onClick={() => toast.success("Password updated", { description: "Use your new password the next time you sign in." })}
            >
              <Lock className="h-3.5 w-3.5" /> Update password
            </Button>
          </CardContent>
        </Card>

        {/* 2FA SETUP */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-primary" /> Two-factor authentication
            </CardTitle>
            <CardDescription>Require a second factor at every sign-in.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="flex items-center gap-2.5">
                <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary"><Key className="h-4 w-4" /></div>
                <div>
                  <p className="text-sm font-medium">Authenticator app</p>
                  <p className="text-xs text-muted-foreground">Google Authenticator, 1Password, Authy</p>
                </div>
              </div>
              <Switch checked={twoFA} onCheckedChange={setTwoFA} />
            </div>
            {twoFA && (
              <div className="grid sm:grid-cols-[auto_1fr] gap-4 items-center p-4 rounded-lg border border-primary/20 bg-primary/[0.03]">
                {/* SVG placeholder QR */}
                <div className="grid place-items-center h-36 w-36 rounded-lg bg-white p-2 shrink-0">
                  <svg viewBox="0 0 100 100" className="h-full w-full" aria-label="QR code">
                    <rect width="100" height="100" fill="#ffffff" />
                    {/* position markers */}
                    {[[5,5],[75,5],[5,75]].map(([x,y],i) => (
                      <g key={i}>
                        <rect x={x} y={y} width="20" height="20" fill="#000" />
                        <rect x={x+3} y={y+3} width="14" height="14" fill="#fff" />
                        <rect x={x+6} y={y+6} width="8" height="8" fill="#000" />
                      </g>
                    ))}
                    {/* pseudo-random dots */}
                    {Array.from({ length: 120 }).map((_, i) => {
                      const x = 8 + (i % 12) * 7 + ((i * 13) % 4);
                      const y = 30 + Math.floor(i / 12) * 6;
                      if (y > 70 || (x > 70 && y < 25) || (y > 70 && x < 25)) return null;
                      return <rect key={i} x={x} y={y} width="3" height="3" fill="#000" />;
                    })}
                    {Array.from({ length: 80 }).map((_, i) => {
                      const x = 30 + (i % 8) * 7;
                      const y = 8 + Math.floor(i / 8) * 7;
                      if (y > 22) return null;
                      return <rect key={`b${i}`} x={x} y={y} width="3" height="3" fill="#000" />;
                    })}
                  </svg>
                </div>
                <div className="space-y-2">
                  <p className="text-xs font-medium flex items-center gap-1.5"><QrCode className="h-3.5 w-3.5" /> Scan with your authenticator</p>
                  <p className="text-xs text-muted-foreground">Or enter this code manually:</p>
                  <div className="flex items-center gap-1.5">
                    <code className="font-mono text-xs bg-muted px-2 py-1.5 rounded border border-border flex-1 break-all">
                      JBSWY3DPEHPK3PXPABCDEFGH4567
                    </code>
                    <Button variant="outline" size="icon" className="h-7 w-7 shrink-0" onClick={() => { navigator.clipboard?.writeText("JBSWY3DPEHPK3PXPABCDEFGH4567"); toast.success("Code copied"); }}>
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <Button size="sm" className="text-xs gap-1.5" onClick={() => toast.success("2FA verified", { description: "Two-factor is now active." })}>
                      <CheckCircle2 className="h-3.5 w-3.5" /> Verify code
                    </Button>
                    <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={() => { setRecoveryDownloaded(true); toast.success("Recovery codes downloaded"); }}>
                      <Download className="h-3.5 w-3.5" /> Recovery codes
                    </Button>
                  </div>
                  {recoveryDownloaded && (
                    <p className="text-[11px] text-[color:var(--success)] flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" /> 10 recovery codes saved to your device.
                    </p>
                  )}
                </div>
              </div>
            )}
            <Separator />
            <div className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="flex items-center gap-2.5">
                <div className="grid place-items-center h-9 w-9 rounded-lg bg-muted"><Smartphone className="h-4 w-4 text-muted-foreground" /></div>
                <div>
                  <p className="text-sm font-medium">SMS fallback</p>
                  <p className="text-xs text-muted-foreground">+1 (415) ••• 0182</p>
                </div>
              </div>
              <Switch checked={sms2FA} onCheckedChange={setSms2FA} />
            </div>
          </CardContent>
        </Card>

        {/* ACTIVE SESSIONS */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Laptop className="h-4 w-4 text-primary" /> Active sessions
              </CardTitle>
              <CardDescription>Devices currently signed into your account.</CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 text-xs"
              disabled={deviceCount === 0}
              onClick={() => toast.success("Signed out of other sessions", { description: `${deviceCount} device${deviceCount > 1 ? "s" : ""} revoked.` })}
            >
              <LogOut className="h-3.5 w-3.5" /> Sign out all others
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {SESSIONS.map((s) => {
                const Icon = deviceIcon[s.device];
                return (
                  <div key={s.id} className="flex items-center gap-3 p-3 sm:p-4 hover:bg-muted/30 transition-colors">
                    <div className={cn("grid place-items-center h-10 w-10 rounded-lg shrink-0", s.current ? "bg-primary/12 text-primary" : "bg-muted text-muted-foreground")}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-medium truncate">{s.browser}</p>
                        {s.current ? (
                          <StatusBadge tone="success" dot>This device</StatusBadge>
                        ) : s.trusted ? (
                          <StatusBadge tone="info">Trusted</StatusBadge>
                        ) : (
                          <StatusBadge tone="neutral">Untrusted</StatusBadge>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5 flex-wrap">
                        <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> {s.location}</span>
                        <span className="inline-flex items-center gap-1 font-mono"><span className="text-muted-foreground/60">IP</span> {s.ip}</span>
                        <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" /> {s.lastActive}</span>
                      </div>
                    </div>
                    {!s.current && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-xs text-destructive hover:text-destructive hover:bg-destructive/10 shrink-0">
                            <LogOut className="h-3.5 w-3.5" /> Revoke
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Revoke this session?</AlertDialogTitle>
                            <AlertDialogDescription>
                              The device at <span className="font-medium text-foreground">{s.location}</span> ({s.ip}) will be signed out immediately and required to authenticate again.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => toast.success("Session revoked", { description: `${s.browser} signed out.` })}>
                              Revoke session
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* SECURITY LOG */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="h-4 w-4 text-primary" /> Security log
              </CardTitle>
              <CardDescription>The last 7 days of security-relevant events.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1.5"><RefreshCw className="h-3.5 w-3.5" /> Refresh</Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border max-h-80 overflow-y-auto">
              {LOGS.map((l) => (
                <div key={l.id} className="flex items-start gap-3 p-3 sm:p-4 hover:bg-muted/30 transition-colors">
                  <div className={cn(
                    "grid place-items-center h-7 w-7 rounded-full shrink-0 mt-0.5",
                    l.status === "success" ? "bg-[color:var(--success)]/12 text-[color:var(--success)]" :
                    l.status === "warning" ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" :
                    "bg-destructive/12 text-destructive"
                  )}>
                    {l.status === "success" ? <CheckCircle2 className="h-3.5 w-3.5" /> : l.status === "warning" ? <AlertTriangle className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{l.event}</p>
                    <p className="text-xs text-muted-foreground">{l.detail}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs text-muted-foreground font-mono">{l.ip}</p>
                    <p className="text-[11px] text-muted-foreground/80">{l.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* DANGER ZONE */}
        <Card className="lg:col-span-2 border-destructive/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-4 w-4" /> Danger zone
            </CardTitle>
            <CardDescription>Irreversible actions. Proceed with caution.</CardDescription>
          </CardHeader>
          <CardContent className="grid sm:grid-cols-2 gap-4">
            <div className="flex items-center justify-between gap-3 p-4 rounded-lg border border-destructive/20 bg-destructive/[0.02]">
              <div className="min-w-0">
                <p className="text-sm font-medium">Export account data</p>
                <p className="text-xs text-muted-foreground mt-0.5">Download a JSON archive of your profile, settings, and activity.</p>
              </div>
              <Button variant="outline" size="sm" className="gap-1.5 text-xs shrink-0" onClick={() => toast.success("Export started", { description: "We'll email you when it's ready." })}>
                <Download className="h-3.5 w-3.5" /> Export
              </Button>
            </div>
            <AlertDialog>
              <div className="flex items-center justify-between gap-3 p-4 rounded-lg border border-destructive/30 bg-destructive/[0.04]">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-destructive">Delete account</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Permanently erase your account and all associated data.</p>
                </div>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" size="sm" className="gap-1.5 text-xs shrink-0">
                    <Trash2 className="h-3.5 w-3.5" /> Delete
                  </Button>
                </AlertDialogTrigger>
              </div>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-destructive">Delete your account?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action is permanent. All repositories, projects, comments, and billing history will be erased within 30 days. To confirm, type <span className="font-mono font-semibold text-foreground">DELETE</span> below.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <Input
                  value={deleteTyped}
                  onChange={(e) => setDeleteTyped(e.target.value)}
                  placeholder="Type DELETE to confirm"
                  className="font-mono"
                />
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setDeleteTyped("")}>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    disabled={deleteTyped !== "DELETE"}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    onClick={() => { setDeleteTyped(""); toast.error("Account deletion scheduled", { description: "Your account will be removed in 30 days." }); }}
                  >
                    Permanently delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>
      </div>
    </>
  );
}

function Requirement({ ok, label }: { ok: boolean; label: string }) {
  return (
    <li className={cn("flex items-center gap-1.5", ok ? "text-[color:var(--success)]" : "text-muted-foreground")}>
      {ok ? <CheckCircle2 className="h-3 w-3 shrink-0" /> : <XCircle className="h-3 w-3 shrink-0 text-muted-foreground/60" />}
      {label}
    </li>
  );
}
