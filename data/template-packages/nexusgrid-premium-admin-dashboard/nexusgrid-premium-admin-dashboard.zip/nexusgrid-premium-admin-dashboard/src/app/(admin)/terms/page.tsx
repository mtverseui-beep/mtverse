"use client";

import * as React from "react";
import {
  Scale,
  Printer,
  Download,
  ChevronRight,
  FileText,
  Shield,
  AlertTriangle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

const SECTIONS = [
  { id: "acceptance", title: "1. Acceptance of Terms" },
  { id: "eligibility", title: "2. Eligibility & Account Registration" },
  { id: "license", title: "3. License to Use the Service" },
  { id: "acceptable-use", title: "4. Acceptable Use Policy" },
  { id: "payment", title: "5. Payment, Billing & Refunds" },
  { id: "ip", title: "6. Intellectual Property Rights" },
  { id: "data", title: "7. Your Content & Data" },
  { id: "termination", title: "8. Suspension & Termination" },
  { id: "disclaimer", title: "9. Disclaimers & Limitation of Liability" },
  { id: "governing", title: "10. Governing Law & Dispute Resolution" },
  { id: "changes", title: "11. Changes to These Terms" },
  { id: "contact", title: "12. Contact Information" },
];

export default function TermsPage() {
  const handlePrint = () => {
    if (typeof window !== "undefined") window.print();
    toast.success("Opening print dialog");
  };

  return (
    <>
      <PageHeader
        title="Terms of Service"
        description="The terms and conditions that govern your use of NexusGrid. Please read them carefully — they affect your legal rights."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Terms" }]}
        icon={Scale}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handlePrint}>
              <Printer className="h-3.5 w-3.5" /> Print
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Downloading terms.pdf")}>
              <Download className="h-3.5 w-3.5" /> Download PDF
            </Button>
          </>
        }
      />

      {/* META CARD */}
      <Card className="mb-6 border-primary/20">
        <CardContent className="p-5 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/10 text-primary shrink-0">
            <FileText className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <h2 className="text-base font-semibold">NexusGrid Terms of Service</h2>
              <Badge variant="outline" className="text-[10px] gap-1 border-primary/30 text-primary bg-primary/5">
                Version 4.2
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">
              Last updated: <span className="font-medium text-foreground">June 28, 2026</span> · Effective from: <span className="font-medium text-foreground">July 1, 2026</span>
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0 text-xs text-muted-foreground">
            <Shield className="h-3.5 w-3.5" />
            <span>Reviewed by legal counsel</span>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_240px] gap-6">
        {/* CONTENT */}
        <article className="min-w-0 space-y-8">
          <Card>
            <CardContent className="p-6 sm:p-8 prose prose-sm max-w-none">
              <p className="text-sm text-muted-foreground italic leading-relaxed">
                These Terms of Service ("Terms") form a legally binding agreement between you (either as an individual or
                on behalf of an entity, "you" or "Customer") and NexusGrid, Inc. ("NexusGrid", "we", "us", or "our")
                governing your access to and use of the NexusGrid web application, mobile apps, application programming
                interfaces (APIs), documentation, and any related services (collectively, the "Service"). By accessing or
                using the Service, you agree to be bound by these Terms. If you do not agree, you may not access or use
                the Service.
              </p>
            </CardContent>
          </Card>

          {SECTIONS.map((s) => (
            <Card key={s.id} id={s.id} className="scroll-mt-4">
              <CardContent className="p-6 sm:p-8">
                <h2 className="text-lg font-semibold tracking-tight mb-3">{s.title}</h2>
                <div className="space-y-3 text-sm leading-relaxed text-foreground/85">
                  {SECTIONS_CONTENT[s.id]}
                </div>
              </CardContent>
            </Card>
          ))}

          <Card className="border-[color:var(--warning)]/30 bg-[color:var(--warning)]/[0.03]">
            <CardContent className="p-6 flex items-start gap-3">
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--warning)]/15 text-[color:var(--warning)] shrink-0">
                <AlertTriangle className="h-4 w-4" />
              </div>
              <div className="text-sm">
                <p className="font-semibold mb-1">Questions about these terms?</p>
                <p className="text-muted-foreground">
                  If you have any questions or concerns about these Terms, contact our legal team at{" "}
                  <a href="mailto:legal@nexusgrid.io" className="text-primary font-medium hover:underline">legal@nexusgrid.io</a>{" "}
                  or write to us at NexusGrid Legal, 548 Market St #62114, San Francisco, CA 94104.
                </p>
              </div>
            </CardContent>
          </Card>
        </article>

        {/* TABLE OF CONTENTS */}
        <aside className="hidden lg:block lg:sticky lg:top-4 lg:self-start lg:max-h-[calc(100vh-2rem)] lg:overflow-y-auto">
          <Card>
            <CardContent className="p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-1.5">Table of contents</p>
              <nav className="space-y-0.5">
                {SECTIONS.map((s, i) => (
                  <a
                    key={s.id}
                    href={`#${s.id}`}
                    className="flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors group"
                  >
                    <span className="text-[10px] tabular-nums text-muted-foreground/60 w-4">{i + 1}</span>
                    <span className="flex-1 line-clamp-1">{s.title.replace(/^\d+\.\s/, "")}</span>
                    <ChevronRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                ))}
              </nav>
              <Separator className="my-3" />
              <div className="px-2.5 py-1.5 space-y-2">
                <p className="text-[11px] text-muted-foreground">Related documents</p>
                <a href="/privacy" className="block text-xs text-primary hover:underline">Privacy Policy</a>
                <a href="/pricing" className="block text-xs text-primary hover:underline">Pricing & Plans</a>
                <a href="/documentation" className="block text-xs text-primary hover:underline">Documentation</a>
              </div>
            </CardContent>
          </Card>
        </aside>
      </div>
    </>
  );
}

const SECTIONS_CONTENT: Record<string, React.ReactNode[]> = {
  acceptance: [
    <p key="p1">By creating an account, accessing, or otherwise using the Service, you acknowledge that you have read, understood, and agree to be bound by these Terms, our Privacy Policy, and any other applicable policies or guidelines incorporated by reference. If you are entering into these Terms on behalf of a company or other legal entity, you represent that you have the authority to bind that entity and its affiliates to these Terms, in which case "you" and "Customer" will refer to that entity.</p>,
    <p key="p2">We may modify these Terms from time to time in accordance with Section 11 (Changes to These Terms). Your continued use of the Service after the effective date of any revised Terms constitutes your acceptance of the updated agreement.</p>,
  ],
  eligibility: [
    <p key="p1">You must be at least sixteen (16) years of age, or the age of legal majority in your jurisdiction of residence, to use the Service. By using the Service, you represent and warrant that: (a) you meet the foregoing age requirement; (b) you have not been previously suspended or removed from the Service; (c) your use of the Service does not violate any applicable law or regulation; and (d) you will provide accurate and current information for all required fields.</p>,
    <p key="p2">You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use or security breach. NexusGrid reserves the right to refuse service, terminate accounts, or remove content in its sole discretion.</p>,
  ],
  license: [
    <p key="p1">Subject to your continued compliance with these Terms and any applicable payment obligations, NexusGrid grants you a limited, non-exclusive, non-transferable, non-sublicensable, revocable license to access and use the Service for your internal business or personal use during the subscription term. This license does not include any right to resell, white-label, or commercially redistribute the Service without our prior written consent.</p>,
    <p key="p2">All right, title, and interest in and to the Service, including all intellectual property rights therein, remain the sole and exclusive property of NexusGrid and its licensors. Nothing in these Terms grants you any right to use the NexusGrid name, trademarks, service marks, or other branding without our prior written permission.</p>,
  ],
  "acceptable-use": [
    <p key="p1">You agree not to, and not to permit others to, use the Service to:</p>,
    <ul key="ul" className="list-disc pl-5 space-y-1.5">
      <li>Upload, store, or transmit any content that is unlawful, harmful, defamatory, infringing, or otherwise objectionable;</li>
      <li>Distribute spam, phishing attempts, malware, or any other malicious code;</li>
      <li>Attempt to gain unauthorized access to any portion of the Service, other accounts, or the systems or networks connected to the Service;</li>
      <li>Use the Service to build a competitive product or service, or to reverse engineer, decompile, or disassemble any part of the Service;</li>
      <li>Interfere with or disrupt the Service, its servers, or the networks and services connected to it;</li>
      <li>Use the Service in violation of applicable export control laws, sanctions, or other regulatory restrictions.</li>
    </ul>,
    <p key="p3">Violations of this Acceptable Use Policy may result in immediate suspension or termination of your account and may expose you to civil or criminal liability.</p>,
  ],
  payment: [
    <p key="p1">Paid plans are billed in advance on a recurring monthly or annual basis depending on the plan you select. All fees are stated in United States dollars (USD) and are exclusive of applicable taxes, which you are responsible for paying unless you have provided a valid tax-exemption certificate. We may change our fees upon at least thirty (30) days' prior written notice.</p>,
    <p key="p2">You authorize us to charge your designated payment method for all fees incurred under your account. If a payment fails, we may suspend access to the Service until the outstanding balance is paid. Refunds are governed by our refund policy: new subscriptions are eligible for a full refund within fourteen (14) days; renewals and partial periods are evaluated on a case-by-case basis.</p>,
  ],
  ip: [
    <p key="p1">NexusGrid and its licensors retain all right, title, and interest in and to the Service, including all software, documentation, design assets, trademarks, trade names, and any derivative works thereof. The Service is licensed, not sold, and these Terms do not convey to you any rights of ownership in or to the Service except for the limited license expressly granted in Section 3.</p>,
    <p key="p2">We welcome feedback, suggestions, and ideas about the Service. If you provide feedback, you grant us a perpetual, irrevocable, worldwide, royalty-free license to use, reproduce, modify, and incorporate that feedback into the Service without obligation or compensation to you.</p>,
  ],
  data: [
    <p key="p1">You retain all right, title, and interest in and to any content, data, files, or information you upload, submit, or store in the Service ("Customer Content"). You grant NexusGrid a worldwide, non-exclusive license to use, process, and transmit your Customer Content solely as necessary to provide, maintain, and improve the Service.</p>,
    <p key="p2">You are solely responsible for ensuring that you have all necessary rights, consents, and permissions to upload Customer Content to the Service and that doing so does not violate any third-party rights or applicable law. You agree that NexusGrid may access, use, or disclose Customer Content when required by law or to comply with legal process, or to protect the rights, property, or safety of NexusGrid, our users, or others.</p>,
  ],
  termination: [
    <p key="p1">You may terminate your account at any time from the account settings page or by contacting support. Upon termination, your right to access the Service ceases immediately. We will retain your Customer Content for thirty (30) days following termination, after which it will be permanently deleted unless required by law to retain it longer.</p>,
    <p key="p2">NexusGrid may suspend or terminate your account immediately, without prior notice, if: (a) you materially breach these Terms and fail to cure the breach within seven (7) days of notice; (b) we are required to do so by law; (c) we determine in our sole discretion that your conduct poses a risk to the Service or other users; or (d) your account becomes inactive for more than twelve (12) consecutive months on a free plan.</p>,
  ],
  disclaimer: [
    <p key="p1">THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE," WITH ALL FAULTS AND WITHOUT WARRANTY OF ANY KIND. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, NEXUSGRID AND ITS LICENSORS DISCLAIM ALL WARRANTIES, WHETHER EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. WE DO NOT WARRANT THAT THE SERVICE WILL BE UNINTERRUPTED, ERROR-FREE, OR SECURE.</p>,
    <p key="p2">TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT WILL NEXUSGRID BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS, DATA, OR GOODWILL, ARISING OUT OF OR RELATED TO YOUR USE OF THE SERVICE, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE), OR ANY OTHER LEGAL THEORY. OUR TOTAL AGGREGATE LIABILITY FOR ALL CLAIMS ARISING OUT OF OR RELATED TO THESE TERMS WILL NOT EXCEED THE GREATER OF (A) THE AMOUNTS YOU HAVE PAID US IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM, OR (B) ONE HUNDRED U.S. DOLLARS ($100).</p>,
  ],
  governing: [
    <p key="p1">These Terms and any dispute arising out of or related to them will be governed by and construed in accordance with the laws of the State of California, without regard to its conflict of laws provisions. The parties submit to the exclusive jurisdiction of the state and federal courts located in San Francisco County, California, for any action arising out of or related to these Terms.</p>,
    <p key="p2">Before filing a claim, both parties agree to attempt in good faith to resolve any dispute through informal negotiation within thirty (30) days of written notice. Any claim or action must be brought within one (1) year after the cause of action accrues, regardless of any statute of limitations to the contrary.</p>,
  ],
  changes: [
    <p key="p1">We may modify these Terms at any time. If we make material changes, we will notify you by email and by prominent notice within the Service at least thirty (30) days before the changes take effect. Material changes include any modification to billing terms, liability, intellectual property, or dispute resolution provisions.</p>,
    <p key="p2">Your continued use of the Service after the effective date of any revised Terms constitutes your acceptance of the updated agreement. If you do not agree to the revised Terms, you may terminate your account as described in Section 8.</p>,
  ],
  contact: [
    <p key="p1">If you have any questions, comments, or concerns about these Terms or the Service, please contact us at:</p>,
    <p key="p2" className="rounded-lg border border-border bg-muted/30 p-3 font-medium">
      NexusGrid, Inc.<br />
      Legal Department<br />
      548 Market Street, #62114<br />
      San Francisco, CA 94104<br />
      Email: <a href="mailto:legal@nexusgrid.io" className="text-primary hover:underline">legal@nexusgrid.io</a><br />
      Phone: +1 (415) 555-0142
    </p>,
  ],
};
