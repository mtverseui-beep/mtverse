"use client";

import * as React from "react";
import {
  Filter,
  Plus,
  GripVertical,
  DollarSign,
  TrendingUp,
  Calendar,
  Tag,
  MoreHorizontal,
  Eye,
  Mail,
  Trash2,
  Users,
  Target,
  Scale,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type StageKey = "lead" | "qualified" | "proposal" | "negotiation" | "won";

type DealCard = {
  id: string;
  company: string;
  logo: string;
  value: number;
  probability: number;
  owner: string;
  ownerAvatar: string;
  expectedClose: string;
  tags: string[];
  stage: StageKey;
};

const allDeals: DealCard[] = [
  // Lead
  { id: "DL-5005", company: "Plaid", logo: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop", value: 72400, probability: 20, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", expectedClose: "Aug 22", tags: ["Fintech", "Outbound"], stage: "lead" },
  { id: "DL-5001", company: "Freshworks", logo: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=64&h=64&fit=crop", value: 67800, probability: 15, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", expectedClose: "Sep 01", tags: ["SaaS", "Inbound"], stage: "lead" },
  { id: "DL-4990", company: "Mercari", logo: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=64&h=64&fit=crop", value: 53400, probability: 18, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", expectedClose: "Sep 04", tags: ["Ecommerce", "Referral"], stage: "lead" },
  { id: "DL-4985", company: "Notion", logo: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=64&h=64&fit=crop", value: 48200, probability: 22, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Aug 28", tags: ["SaaS", "Inbound"], stage: "lead" },

  // Qualified
  { id: "DL-5009", company: "Umbrella Inc", logo: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=64&h=64&fit=crop", value: 48200, probability: 35, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", expectedClose: "Aug 02", tags: ["Healthcare"], stage: "qualified" },
  { id: "DL-5006", company: "Stripe", logo: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=64&h=64&fit=crop", value: 38400, probability: 40, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Aug 10", tags: ["Fintech", "Expansion"], stage: "qualified" },
  { id: "DL-5003", company: "Ro Health", logo: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=64&h=64&fit=crop", value: 91500, probability: 45, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Aug 05", tags: ["Healthcare", "Hot"], stage: "qualified" },
  { id: "DL-4998", company: "Careem", logo: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=64&h=64&fit=crop", value: 88600, probability: 50, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", expectedClose: "Aug 14", tags: ["Logistics"], stage: "qualified" },
  { id: "DL-4992", company: "Patreon", logo: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=64&h=64&fit=crop", value: 56200, probability: 42, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", expectedClose: "Aug 18", tags: ["SaaS", "Inbound"], stage: "qualified" },

  // Proposal
  { id: "DL-5011", company: "Initech", logo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=64&h=64&fit=crop", value: 62500, probability: 60, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", expectedClose: "Jul 18", tags: ["SaaS"], stage: "proposal" },
  { id: "DL-5008", company: "Acme Corp", logo: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=64&h=64&fit=crop", value: 96800, probability: 55, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", expectedClose: "Jul 28", tags: ["Manufacturing", "Hot"], stage: "proposal" },
  { id: "DL-5004", company: "Rakuten", logo: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=64&h=64&fit=crop", value: 58300, probability: 50, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", expectedClose: "Jul 31", tags: ["Ecommerce"], stage: "proposal" },
  { id: "DL-4999", company: "Doctolib", logo: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=64&h=64&fit=crop", value: 102500, probability: 65, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Jul 25", tags: ["Healthcare", "Hot"], stage: "proposal" },

  // Negotiation
  { id: "DL-5012", company: "Globex Corp", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=64&h=64&fit=crop", value: 84000, probability: 75, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Jul 14", tags: ["SaaS", "Critical"], stage: "negotiation" },
  { id: "DL-5010", company: "Hooli", logo: "https://images.unsplash.com/photo-1620288627229-c5b1d2f80c8f?w=64&h=64&fit=crop", value: 124000, probability: 80, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Jul 22", tags: ["SaaS", "Critical"], stage: "negotiation" },
  { id: "DL-5002", company: "Cloudflare", logo: "https://images.unsplash.com/photo-1551803091-e20673f15770?w=64&h=64&fit=crop", value: 184000, probability: 85, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Jul 12", tags: ["Infrastructure", "Critical"], stage: "negotiation" },

  // Won
  { id: "DL-5007", company: "Soylent", logo: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop", value: 152000, probability: 100, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Jul 01", tags: ["Ecommerce"], stage: "won" },
  { id: "DL-4997", company: "Klarna", logo: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=64&h=64&fit=crop", value: 142000, probability: 100, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Jul 03", tags: ["Fintech"], stage: "won" },
  { id: "DL-4980", company: "Cloudflare", logo: "https://images.unsplash.com/photo-1551803091-e20673f15770?w=64&h=64&fit=crop", value: 98000, probability: 100, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Jun 28", tags: ["Infrastructure"], stage: "won" },
];

const stageConfig: Record<StageKey, { label: string; color: string; tone: StatusTone }> = {
  lead: { label: "Lead", color: "var(--info)", tone: "info" },
  qualified: { label: "Qualified", color: "var(--primary)", tone: "primary" },
  proposal: { label: "Proposal", color: "oklch(0.62 0.18 305)", tone: "violet" },
  negotiation: { label: "Negotiation", color: "oklch(0.70 0.15 75)", tone: "warning" },
  won: { label: "Won", color: "var(--success)", tone: "success" },
};

const stageOrder: StageKey[] = ["lead", "qualified", "proposal", "negotiation", "won"];

export default function PipelineBoardPage() {
  const totalPipelineValue = allDeals.reduce((s, d) => s + d.value, 0);
  const weightedForecast = allDeals.reduce((s, d) => s + (d.value * d.probability) / 100, 0);

  return (
    <>
      <PageHeader
        title="Pipeline Board"
        description="Visualize deals across every stage. Drag cards between columns to update their stage."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Pipeline Board" }]}
        icon={Filter}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Pipeline exported")}>
              <Filter className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Create deal form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Deal
            </Button>
          </>
        }
      />

      {/* Summary bar — total pipeline value + weighted forecast */}
      <Card className="mb-6 overflow-hidden">
        <CardContent className="p-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-border">
            <div className="p-5">
              <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wide mb-1.5">
                <DollarSign className="h-3.5 w-3.5" /> Total Pipeline Value
              </div>
              <p className="text-2xl font-semibold tabular-nums tracking-tight">${(totalPipelineValue / 1000).toFixed(0)}K</p>
              <p className="text-xs text-muted-foreground mt-1">{allDeals.length} active deals</p>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wide mb-1.5">
                <TrendingUp className="h-3.5 w-3.5" /> Weighted Forecast
              </div>
              <p className="text-2xl font-semibold tabular-nums tracking-tight text-primary">${(weightedForecast / 1000).toFixed(0)}K</p>
              <p className="text-xs text-muted-foreground mt-1">{((weightedForecast / totalPipelineValue) * 100).toFixed(0)}% of total value</p>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wide mb-1.5">
                <Users className="h-3.5 w-3.5" /> Active Owners
              </div>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex -space-x-2">
                  {Array.from(new Set(allDeals.map((d) => d.ownerAvatar))).slice(0, 5).map((a, i) => (
                    <Avatar key={i} className="h-7 w-7 border-2 border-card">
                      <AvatarImage src={a} alt="" />
                      <AvatarFallback className="text-[9px]">?</AvatarFallback>
                    </Avatar>
                  ))}
                </div>
                <p className="text-sm font-medium">{new Set(allDeals.map((d) => d.owner)).size} reps</p>
              </div>
              <p className="text-xs text-muted-foreground mt-1">across all stages</p>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wide mb-1.5">
                <Target className="h-3.5 w-3.5" /> Avg. Probability
              </div>
              <p className="text-2xl font-semibold tabular-nums tracking-tight">
                {Math.round(allDeals.reduce((s, d) => s + d.probability, 0) / allDeals.length)}%
              </p>
              <p className="text-xs text-muted-foreground mt-1">weighted across pipeline</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Drag-to-reorder hint */}
      <div className="mb-3 flex items-center justify-between flex-wrap gap-2">
        <div className="inline-flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/60 rounded-md px-2.5 py-1.5">
          <GripVertical className="h-3.5 w-3.5" />
          Drag cards between columns to update stage. Click a card to edit details.
        </div>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <Scale className="h-3.5 w-3.5" /> Forecast = value × probability
          </span>
        </div>
      </div>

      {/* Kanban board */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
        {stageOrder.map((stage) => {
          const cfg = stageConfig[stage];
          const stageDeals = allDeals.filter((d) => d.stage === stage);
          const stageValue = stageDeals.reduce((s, d) => s + d.value, 0);
          return (
            <div key={stage} className="flex flex-col min-w-0">
              {/* Stage header */}
              <div className="rounded-t-lg border border-border border-b-0 bg-muted/40 p-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="h-2 w-2 rounded-full shrink-0" style={{ background: cfg.color }} />
                    <span className="text-sm font-medium text-foreground truncate">{cfg.label}</span>
                  </div>
                  <StatusBadge tone={cfg.tone}>{stageDeals.length}</StatusBadge>
                </div>
                <p className="text-xs text-muted-foreground tabular-nums">
                  ${(stageValue / 1000).toFixed(0)}K total
                </p>
              </div>
              {/* Stage body */}
              <div
                className="flex-1 rounded-b-lg border border-border border-t-0 bg-muted/20 p-2 min-h-[400px] space-y-2"
                style={{ borderTopColor: cfg.color, borderTopWidth: 2 }}
              >
                {stageDeals.map((d) => (
                  <div
                    key={d.id}
                    onClick={() => toast.message(`Editing deal ${d.id}`)}
                    className="group relative rounded-lg border border-border bg-card p-3 cursor-pointer hover:border-primary/40 hover:shadow-premium-sm transition-all"
                  >
                    {/* Drag handle */}
                    <div className="absolute right-1.5 top-1.5 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground/60">
                      <GripVertical className="h-3.5 w-3.5" />
                    </div>
                    {/* Company */}
                    <div className="flex items-center gap-2 mb-2 pr-4">
                      <img src={d.logo} alt={`${d.company} logo`} className="h-7 w-7 rounded-md object-cover bg-muted shrink-0" />
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{d.company}</p>
                        <p className="text-[10px] text-muted-foreground font-mono">{d.id}</p>
                      </div>
                    </div>
                    {/* Value + probability */}
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-base font-semibold tabular-nums">${(d.value / 1000).toFixed(0)}K</span>
                      <span
                        className={cn(
                          "text-[10px] font-semibold tabular-nums px-1.5 py-0.5 rounded",
                          d.probability >= 75
                            ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                            : d.probability >= 50
                            ? "bg-primary/12 text-primary"
                            : d.probability >= 25
                            ? "bg-[color:var(--warning)]/12 text-[color:var(--warning)]"
                            : "bg-muted text-muted-foreground"
                        )}
                      >
                        {d.probability}%
                      </span>
                    </div>
                    {/* Probability bar */}
                    <div className="h-1 w-full rounded-full bg-muted overflow-hidden mb-2.5">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all duration-500",
                          d.probability >= 75
                            ? "bg-[color:var(--success)]"
                            : d.probability >= 50
                            ? "bg-primary"
                            : d.probability >= 25
                            ? "bg-[color:var(--warning)]"
                            : "bg-muted-foreground"
                        )}
                        style={{ width: `${d.probability}%` }}
                      />
                    </div>
                    {/* Footer: owner + close date */}
                    <div className="flex items-center justify-between mb-2">
                      <Avatar className="h-5 w-5">
                        <AvatarImage src={d.ownerAvatar} alt={d.owner} />
                        <AvatarFallback className="text-[8px]">
                          {d.owner.split(" ").map((p) => p[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground font-mono">
                        <Calendar className="h-2.5 w-2.5" />
                        {d.expectedClose}
                      </span>
                    </div>
                    {/* Tags */}
                    <div className="flex flex-wrap gap-1">
                      {d.tags.map((t) => (
                        <span
                          key={t}
                          className={cn(
                            "inline-flex items-center gap-0.5 text-[9px] font-medium px-1.5 py-0.5 rounded ring-1 ring-inset",
                            t === "Critical" || t === "Hot"
                              ? "bg-destructive/10 text-destructive ring-destructive/20"
                              : "bg-muted text-muted-foreground ring-border"
                          )}
                        >
                          <Tag className="h-2 w-2" />
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
                {/* Add deal button */}
                <button
                  onClick={() => toast.success(`Add deal to ${cfg.label}`)}
                  className="w-full rounded-lg border border-dashed border-border p-2 text-xs text-muted-foreground hover:border-primary/40 hover:text-primary hover:bg-primary/5 transition-colors flex items-center justify-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Add deal
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom: stage totals + insights */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Stage Conversion Rates</p>
                <p className="text-sm font-medium mt-1">How deals flow through the pipeline</p>
              </div>
              <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.message("Opening analytics")}>
                View analytics
              </Button>
            </div>
            <div className="space-y-2.5">
              {[
                { from: "Lead", to: "Qualified", rate: 38, tone: "warning" as const },
                { from: "Qualified", to: "Proposal", rate: 64, tone: "success" as const },
                { from: "Proposal", to: "Negotiation", rate: 52, tone: "primary" as const },
                { from: "Negotiation", to: "Won", rate: 78, tone: "success" as const },
              ].map((c, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground w-32 truncate">{c.from} → {c.to}</span>
                  <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-700",
                        c.tone === "success" && "bg-[color:var(--success)]",
                        c.tone === "primary" && "bg-primary",
                        c.tone === "warning" && "bg-[color:var(--warning)]"
                      )}
                      style={{ width: `${c.rate}%` }}
                    />
                  </div>
                  <span className="text-xs font-semibold tabular-nums w-10 text-right">{c.rate}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">Pipeline Health</p>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Bottleneck Stage</span>
                <StatusBadge tone="warning">Proposal</StatusBadge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Stalest Deal</span>
                <span className="text-sm font-medium font-mono">DL-4985 · 18d</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Largest Open Deal</span>
                <span className="text-sm font-semibold tabular-nums">$184K</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Closing This Week</span>
                <span className="text-sm font-semibold tabular-nums">3 deals</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Avg. Days in Stage</span>
                <span className="text-sm font-semibold tabular-nums">12 days</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
