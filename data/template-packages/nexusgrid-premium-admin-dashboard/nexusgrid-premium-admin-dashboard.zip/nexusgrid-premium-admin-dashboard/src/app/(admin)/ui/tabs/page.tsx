"use client";

import * as React from "react";
import {
  SquareStack,
  User,
  Lock,
  Bell,
  CreditCard,
  Globe,
  Database,
  Settings,
  Mail,
  Star,
  Cloud,
  Server,
  Shield,
  CheckCircle2,
  Clock,
  AlertTriangle,
  LayoutGrid,
  List,
  KanbanSquare,
  Calendar as CalendarIcon,
  Table2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StatusBadge } from "@/components/common/status-badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function TabsPage() {
  const [controlledTab, setControlledTab] = React.useState("overview");
  const [view, setView] = React.useState("list");

  return (
    <div className="space-y-6">
      <PageHeader
        title="Tabs"
        description="Switch between related views — underline, pills, segmented, vertical and controlled patterns."
        icon={SquareStack}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/tabs" },
          { label: "Tabs" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Tabs spec sheet copied")}>
            <Settings /> Spec sheet
          </Button>
        }
      />

      {/* Underline tabs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Underline tabs</CardTitle>
          <CardDescription>
            Borderless list with a subtle bottom border on the active tab. Common in dashboards.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="bg-transparent border-b rounded-none w-full justify-start h-auto p-0">
              {[
                { value: "overview", label: "Overview" },
                { value: "analytics", label: "Analytics" },
                { value: "members", label: "Members", badge: "8" },
                { value: "billing", label: "Billing" },
                { value: "settings", label: "Settings" },
              ].map((t) => (
                <TabsTrigger
                  key={t.value}
                  value={t.value}
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-4 py-2.5"
                >
                  {t.label}
                  {t.badge && (
                    <Badge variant="secondary" className="ml-2 text-[10px] h-4 px-1.5">
                      {t.badge}
                    </Badge>
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
            <TabsContent value="overview" className="mt-4">
              <div className="rounded-lg border bg-muted/30 p-4 text-sm text-muted-foreground">
                <p className="font-medium text-foreground mb-1">Workspace overview</p>
                The Acme Corp workspace has 8 active members, 24 projects and 3 connected integrations. Storage usage is 32.4 GB of 50 GB.
              </div>
            </TabsContent>
            <TabsContent value="analytics" className="mt-4">
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "Active members", value: "8" },
                  { label: "Avg session", value: "42m" },
                  { label: "PRs merged", value: "184" },
                ].map((s) => (
                  <div key={s.label} className="rounded-lg border p-3">
                    <p className="text-xl font-semibold">{s.value}</p>
                    <p className="text-xs text-muted-foreground">{s.label}</p>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="members" className="mt-4 space-y-2">
              {[
                { name: "Amara Reyes", role: "Designer", email: "amara@nexusgrid.io" },
                { name: "Devon Park", role: "Engineer", email: "devon@nexusgrid.io" },
                { name: "Priya Shah", role: "CS", email: "priya@nexusgrid.io" },
              ].map((m) => (
                <div key={m.email} className="flex items-center gap-3 rounded-md border p-2.5">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{m.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{m.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{m.email}</p>
                  </div>
                  <Badge variant="secondary">{m.role}</Badge>
                </div>
              ))}
            </TabsContent>
            <TabsContent value="billing" className="mt-4">
              <div className="rounded-lg border bg-muted/30 p-4 text-sm">
                <p className="font-medium">Pro plan · $36/mo</p>
                <p className="text-muted-foreground mt-1">Next invoice $648.00 on August 1, 2026.</p>
              </div>
            </TabsContent>
            <TabsContent value="settings" className="mt-4">
              <div className="rounded-lg border bg-muted/30 p-4 text-sm text-muted-foreground">
                Workspace settings — name, default permissions, retention policy.
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Pills + segmented */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Pills tabs</CardTitle>
            <CardDescription>
              Rounded pill-shaped tabs that fill with primary on the active state.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="bg-transparent gap-1 h-auto p-0">
                {[
                  { value: "all", label: "All", count: 24 },
                  { value: "open", label: "Open", count: 12 },
                  { value: "review", label: "In review", count: 5 },
                  { value: "done", label: "Done", count: 7 },
                ].map((t) => (
                  <TabsTrigger
                    key={t.value}
                    value={t.value}
                    className="rounded-full data-[state=active]:bg-primary data-[state=active]:text-primary-foreground border border-border px-3 py-1.5 text-xs"
                  >
                    {t.label}
                    <span className="ml-1.5 rounded-full bg-foreground/10 px-1.5 text-[10px]">
                      {t.count}
                    </span>
                  </TabsTrigger>
                ))}
              </TabsList>
              <TabsContent value="all" className="mt-3 text-sm text-muted-foreground">
                Showing all 24 issues across every status.
              </TabsContent>
              <TabsContent value="open" className="mt-3 text-sm text-muted-foreground">
                12 issues currently open and assigned.
              </TabsContent>
              <TabsContent value="review" className="mt-3 text-sm text-muted-foreground">
                5 issues waiting for code review.
              </TabsContent>
              <TabsContent value="done" className="mt-3 text-sm text-muted-foreground">
                7 issues closed this sprint.
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Segmented tabs</CardTitle>
            <CardDescription>
              Equal-width segments with icons — used as view switchers (list / grid / kanban).
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={view} onValueChange={setView}>
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="list"><List /> List</TabsTrigger>
                <TabsTrigger value="grid"><LayoutGrid /> Grid</TabsTrigger>
                <TabsTrigger value="kanban"><KanbanSquare /> Kanban</TabsTrigger>
                <TabsTrigger value="calendar"><CalendarIcon /> Cal</TabsTrigger>
              </TabsList>
              <TabsContent value="list" className="mt-3">
                <div className="space-y-1.5">
                  {["NG-2041 Implement SSO", "NG-2042 Refactor billing", "NG-2043 Audit log export"].map((t) => (
                    <div key={t} className="rounded-md border p-2 text-sm flex items-center justify-between">
                      <span>{t}</span>
                      <StatusBadge tone="primary" dot>Open</StatusBadge>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="grid" className="mt-3">
                <div className="grid grid-cols-3 gap-2">
                  {["NG-2041", "NG-2042", "NG-2043", "NG-2044", "NG-2045", "NG-2046"].map((t) => (
                    <div key={t} className="rounded-md border p-3 text-xs">
                      <p className="font-semibold">{t}</p>
                      <p className="text-muted-foreground mt-0.5">3 subtasks</p>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="kanban" className="mt-3">
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {["To do", "In progress", "Done"].map((col, i) => (
                    <div key={col} className="rounded-md border bg-muted/30 p-2">
                      <p className="font-semibold mb-1.5">{col}</p>
                      {[1, 2, 3].slice(0, [2, 3, 1][i]).map((n) => (
                        <div key={n} className="rounded bg-card border p-1.5 mb-1">
                          Task #{n}
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="calendar" className="mt-3">
                <div className="rounded-md border bg-muted/30 p-4 text-xs text-center text-muted-foreground">
                  Calendar view placeholder
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* With icons + badges */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">With icons & badges</CardTitle>
          <CardDescription>
            Tab triggers can carry icons and badges to communicate state at a glance.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="general">
            <TabsList>
              <TabsTrigger value="general">
                <Settings /> General
              </TabsTrigger>
              <TabsTrigger value="notifications">
                <Bell /> Notifications
                <Badge className="ml-1 bg-primary text-primary-foreground h-4 px-1 text-[10px]">3</Badge>
              </TabsTrigger>
              <TabsTrigger value="security">
                <Shield /> Security
              </TabsTrigger>
              <TabsTrigger value="integrations">
                <Globe /> Integrations
                <Badge variant="secondary" className="ml-1 h-4 px-1 text-[10px]">12</Badge>
              </TabsTrigger>
              <TabsTrigger value="advanced">
                <Database /> Advanced
              </TabsTrigger>
            </TabsList>
            <TabsContent value="general" className="mt-4">
              <div className="rounded-md border bg-muted/30 p-3 text-sm">Workspace name, default permissions, retention policy.</div>
            </TabsContent>
            <TabsContent value="notifications" className="mt-4">
              <div className="space-y-2">
                {[
                  { title: "New comment on PR", on: true },
                  { title: "Mention in review", on: true },
                  { title: "Build status changed", on: false },
                ].map((n) => (
                  <div key={n.title} className="flex items-center justify-between rounded-md border p-2.5">
                    <span className="text-sm">{n.title}</span>
                    <StatusBadge tone={n.on ? "success" : "neutral"} dot>{n.on ? "On" : "Off"}</StatusBadge>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="security" className="mt-4">
              <div className="rounded-md border bg-muted/30 p-3 text-sm">2FA enforcement, session timeout, IP allowlist.</div>
            </TabsContent>
            <TabsContent value="integrations" className="mt-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {["Slack", "GitHub", "Stripe", "Zapier", "Linear", "Notion"].map((i) => (
                  <div key={i} className="rounded-md border p-3 flex items-center gap-2">
                    <div className="grid h-7 w-7 place-items-center rounded-md bg-muted">
                      <Globe className="h-3.5 w-3.5" />
                    </div>
                    <div className="text-sm font-medium">{i}</div>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="advanced" className="mt-4">
              <div className="rounded-md border bg-muted/30 p-3 text-sm">API rate limits, audit log retention, data residency.</div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Vertical tabs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Vertical tabs</CardTitle>
          <CardDescription>
            Side-by-side tabs used for settings pages with many sections.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="profile" className="flex flex-col md:flex-row gap-4">
            <TabsList className="bg-transparent flex-col h-auto items-stretch p-0 md:w-52 shrink-0 border-b md:border-b-0 md:border-r">
              {[
                { value: "profile", label: "Profile", icon: User },
                { value: "account", label: "Account", icon: Settings },
                { value: "notifications", label: "Notifications", icon: Bell },
                { value: "security", label: "Security", icon: Lock },
                { value: "billing", label: "Billing", icon: CreditCard },
                { value: "integrations", label: "Integrations", icon: Globe },
              ].map((t) => (
                <TabsTrigger
                  key={t.value}
                  value={t.value}
                  className="justify-start rounded-md data-[state=active]:bg-accent data-[state=active]:shadow-none px-3 py-2 text-sm"
                >
                  <t.icon className="h-4 w-4" /> {t.label}
                </TabsTrigger>
              ))}
            </TabsList>
            <div className="flex-1 min-w-0">
              <TabsContent value="profile">
                <div className="space-y-3">
                  <p className="text-sm font-medium">Profile settings</p>
                  <div className="flex items-center gap-3 rounded-md border p-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" alt="Amara" />
                      <AvatarFallback>AR</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Amara Reyes</p>
                      <p className="text-xs text-muted-foreground">amara@nexusgrid.io</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="account">
                <p className="text-sm font-medium mb-2">Account settings</p>
                <p className="text-sm text-muted-foreground">Workspace name, default landing page, timezone.</p>
              </TabsContent>
              <TabsContent value="notifications">
                <p className="text-sm font-medium mb-2">Notifications</p>
                <p className="text-sm text-muted-foreground">Choose how and when we contact you.</p>
              </TabsContent>
              <TabsContent value="security">
                <p className="text-sm font-medium mb-2">Security</p>
                <p className="text-sm text-muted-foreground">Password, 2FA, sessions, API keys.</p>
              </TabsContent>
              <TabsContent value="billing">
                <p className="text-sm font-medium mb-2">Billing</p>
                <p className="text-sm text-muted-foreground">Plan, payment method, invoices, usage.</p>
              </TabsContent>
              <TabsContent value="integrations">
                <p className="text-sm font-medium mb-2">Integrations</p>
                <p className="text-sm text-muted-foreground">Connected apps and webhooks.</p>
              </TabsContent>
            </div>
          </Tabs>
        </CardContent>
      </Card>

      {/* Controlled vs uncontrolled */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Controlled vs uncontrolled</CardTitle>
          <CardDescription>
            This example is fully controlled — the active tab is set via React state, with external buttons to switch.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 mb-3">
            <Button size="sm" variant="outline" onClick={() => setControlledTab("overview")}>
              Overview
            </Button>
            <Button size="sm" variant="outline" onClick={() => setControlledTab("activity")}>
              Activity
            </Button>
            <Button size="sm" variant="outline" onClick={() => setControlledTab("files")}>
              Files
            </Button>
            <Badge variant="secondary" className="ml-2">Active: {controlledTab}</Badge>
          </div>
          <Tabs value={controlledTab} onValueChange={setControlledTab}>
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="files">Files</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="mt-3">
              <div className="rounded-md border p-4 text-sm">
                Controlled overview tab. Clicking the buttons above updates this content via state.
              </div>
            </TabsContent>
            <TabsContent value="activity" className="mt-3">
              <div className="space-y-1.5">
                {[
                  { icon: CheckCircle2, color: "text-[color:var(--success)]", text: "Devon merged PR #1284", time: "12m ago" },
                  { icon: Clock, color: "text-[color:var(--info)]", text: "Priya opened ticket NG-2041", time: "1h ago" },
                  { icon: AlertTriangle, color: "text-[color:var(--warning)]", text: "Build #4291 failed on main", time: "2h ago" },
                ].map((a, i) => (
                  <div key={i} className="flex items-center gap-3 rounded-md border p-2.5">
                    <a.icon className={cn("h-4 w-4", a.color)} />
                    <span className="text-sm flex-1">{a.text}</span>
                    <span className="text-xs text-muted-foreground">{a.time}</span>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="files" className="mt-3">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {["README.md", "spec.pdf", "roadmap.xlsx", "design.fig", "data.csv", "notes.txt"].map((f) => (
                  <div key={f} className="rounded-md border p-3 text-sm flex items-center gap-2">
                    <Star className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="truncate">{f}</span>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Tabs page · underline · pills · segmented · icons + badges · vertical · controlled
      </p>
    </div>
  );
}
