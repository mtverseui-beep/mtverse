"use client";

import * as React from "react";
import {
  MapPin,
  Globe2,
  DollarSign,
  TrendingUp,
  Users,
  Trophy,
  Plus,
  MoreHorizontal,
  Eye,
  ArrowUpRight,
  Building2,
  Briefcase,
  Crown,
  Download,
  Target,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BarTrendChart } from "@/components/charts";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Territory = {
  id: string;
  name: string;
  region: string;
  leadAvatar: string;
  leadName: string;
  reps: number;
  revenue: number;
  deals: number;
  attainment: number;
  quota: number;
  color: string;
  topAccount: string;
};

const territories: Territory[] = [
  { id: "TR-NA-W", name: "NA-West", region: "North America", leadAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", leadName: "Sarah Chen", reps: 8, revenue: 1840000, deals: 42, attainment: 112, quota: 1640000, color: "var(--primary)", topAccount: "Cloudflare" },
  { id: "TR-NA-E", name: "NA-East", region: "North America", leadAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", leadName: "Marcus Reyes", reps: 7, revenue: 1420000, deals: 36, attainment: 94, quota: 1510000, color: "var(--info)", topAccount: "Stripe" },
  { id: "TR-EMEA", name: "EMEA", region: "Europe / MEA", leadAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", leadName: "Elena Petrov", reps: 9, revenue: 1680000, deals: 48, attainment: 105, quota: 1600000, color: "oklch(0.70 0.15 75)", topAccount: "Klarna" },
  { id: "TR-APAC", name: "APAC", region: "Asia Pacific", leadAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", leadName: "Aiko Tanaka", reps: 6, revenue: 1240000, deals: 32, attainment: 89, quota: 1390000, color: "oklch(0.62 0.18 305)", topAccount: "Rakuten" },
  { id: "TR-LATAM", name: "LATAM", region: "Latin America", leadAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", leadName: "Carlos Mendez", reps: 4, revenue: 620000, deals: 18, attainment: 78, quota: 795000, color: "oklch(0.62 0.18 25)", topAccount: "Mercado Libre" },
  { id: "TR-INDIA", name: "India", region: "South Asia", leadAvatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=40&h=40&fit=crop", leadName: "Priya Sharma", reps: 5, revenue: 840000, deals: 24, attainment: 102, quota: 824000, color: "var(--success)", topAccount: "Freshworks" },
  { id: "TR-MENA", name: "MENA", region: "Middle East / NA", leadAvatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=40&h=40&fit=crop", leadName: "Rashid Al-Mansour", reps: 3, revenue: 480000, deals: 14, attainment: 96, quota: 500000, color: "oklch(0.58 0.13 250)", topAccount: "Careem" },
  { id: "TR-ANZ", name: "ANZ", region: "Australia / NZ", leadAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=40&h=40&fit=crop", leadName: "Olivia Bennett", reps: 3, revenue: 540000, deals: 16, attainment: 84, quota: 643000, color: "var(--warning)", topAccount: "Atlassian" },
];

const territoryComparison = territories.map((t) => ({
  name: t.name,
  revenue: Math.round(t.revenue / 1000),
  quota: Math.round(t.quota / 1000),
}));

/* TerritoryKpi — globe+region-strip motif: large globe icon with a small horizontal region color bar */
function TerritoryKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive,
  regionStrip,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  trend: string;
  trendPositive: boolean;
  regionStrip: { pct: number; color: string }[];
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-full shrink-0", accentMap[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* Region color strip motif — distinct */}
        <div className="flex h-1.5 w-full rounded-full overflow-hidden bg-muted mb-3">
          {regionStrip.map((r, i) => (
            <div key={i} className="h-full transition-all duration-500" style={{ width: `${r.pct}%`, background: r.color }} />
          ))}
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground truncate">{hint}</span>
          <span className={cn("inline-flex items-center gap-0.5 font-medium shrink-0", trendPositive ? "text-[color:var(--success)]" : "text-destructive")}>
            <ArrowUpRight className="h-3 w-3" />
            {trend}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function TerritoriesPage() {
  const totalRevenue = territories.reduce((s, t) => s + t.revenue, 0);
  const totalReps = territories.reduce((s, t) => s + t.reps, 0);
  const topTerritory = territories.reduce((max, t) => (t.revenue > max.revenue ? t : max), territories[0]);

  return (
    <>
      <PageHeader
        title="Territories"
        description="Balance rep coverage, revenue distribution, and quota attainment across regions."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Territories" }]}
        icon={MapPin}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Territory report exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add territory form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Territory
            </Button>
          </>
        }
      />

      {/* KPI Row — globe+region-strip motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <TerritoryKpi label="Total Territories" value="8" hint="across 6 regions" icon={Globe2} accent="primary" trend="+1 new region" trendPositive={true} regionStrip={territories.slice(0, 6).map((t) => ({ pct: 100 / 6, color: t.color }))} />
        <TerritoryKpi label="Total Revenue" value={`$${(totalRevenue / 1000000).toFixed(1)}M`} hint="across all territories" icon={DollarSign} accent="success" trend="+14.2% YoY" trendPositive={true} regionStrip={territories.map((t) => ({ pct: (t.revenue / totalRevenue) * 100, color: t.color }))} />
        <TerritoryKpi label="Top Territory" value={topTerritory.name} hint={`$${(topTerritory.revenue / 1000000).toFixed(1)}M revenue`} icon={Crown} accent="warning" trend={`${topTerritory.attainment}% attainment`} trendPositive={true} regionStrip={[{ pct: topTerritory.attainment >= 100 ? 100 : topTerritory.attainment, color: topTerritory.color }, { pct: 100 - (topTerritory.attainment >= 100 ? 100 : topTerritory.attainment), color: "var(--muted)" }]} />
        <TerritoryKpi label="Reps Assigned" value={totalReps.toString()} hint="across 8 territories" icon={Users} accent="info" trend="+4 hires this Q" trendPositive={true} regionStrip={territories.slice(0, 6).map((t) => ({ pct: (t.reps / totalReps) * 100, color: t.color }))} />
      </div>

      {/* Territory performance comparison */}
      <Card className="mb-6">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Territory Performance Comparison
            </CardTitle>
            <CardDescription>Revenue vs. quota by territory — in $K.</CardDescription>
          </div>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <span className="h-2 w-3 rounded-full bg-primary" /> Revenue
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="h-2 w-3 rounded-full bg-muted-foreground/40" /> Quota
            </span>
          </div>
        </CardHeader>
        <CardContent>
          <BarTrendChart
            data={territoryComparison}
            xKey="name"
            series={[
              { key: "revenue", name: "Revenue", color: "var(--primary)" },
              { key: "quota", name: "Quota", color: "var(--muted-foreground)" },
            ]}
            height={280}
          />
        </CardContent>
      </Card>

      {/* Territory cards grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {territories.map((t, i) => {
          const attainmentTone: StatusTone =
            t.attainment >= 100 ? "success" : t.attainment >= 80 ? "primary" : "warning";
          return (
            <Card key={t.id} className="group relative overflow-hidden">
              {/* Top color accent strip */}
              <div className="h-1 w-full" style={{ background: t.color }} />
              <CardContent className="pt-5 pb-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className="grid place-items-center h-10 w-10 rounded-lg shrink-0"
                      style={{ background: `color-mix(in srgb, ${t.color} 14%, transparent)`, color: t.color }}
                    >
                      <Globe2 className="h-5 w-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-foreground truncate">{t.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{t.region}</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7 -mr-1 -mt-1 shrink-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-44">
                      <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening territory ${t.id}`)}>
                        <Eye className="h-3.5 w-3.5" /> View details
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Reassigning ${t.name} reps`)}>
                        <Users className="h-3.5 w-3.5" /> Reassign reps
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Editing ${t.name} quota`)}>
                        <Target className="h-3.5 w-3.5" /> Edit quota
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`${t.name} report exported`)}>
                        <Download className="h-3.5 w-3.5" /> Export report
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Lead rep */}
                <div className="flex items-center gap-2 mb-3 p-2 rounded-md bg-muted/40">
                  <Avatar className="h-7 w-7 shrink-0">
                    <AvatarImage src={t.leadAvatar} alt={t.leadName} />
                    <AvatarFallback className="text-[9px]">
                      {t.leadName.split(" ").map((p) => p[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium text-foreground truncate">{t.leadName}</p>
                    <p className="text-[10px] text-muted-foreground">Territory Lead · {t.reps} reps</p>
                  </div>
                  {i === 0 && (
                    <Crown className="h-3.5 w-3.5 text-[color:var(--warning)] shrink-0" />
                  )}
                </div>

                {/* Stats grid */}
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="rounded-md border border-border p-2">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                      <DollarSign className="h-2.5 w-2.5" /> Revenue
                    </p>
                    <p className="text-sm font-semibold tabular-nums mt-0.5">${(t.revenue / 1000000).toFixed(1)}M</p>
                  </div>
                  <div className="rounded-md border border-border p-2">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                      <Briefcase className="h-2.5 w-2.5" /> Deals
                    </p>
                    <p className="text-sm font-semibold tabular-nums mt-0.5">{t.deals}</p>
                  </div>
                </div>

                {/* Attainment with mini progress */}
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-muted-foreground">Quota Attainment</span>
                    <StatusBadge tone={attainmentTone} className="tabular-nums">
                      {t.attainment}%
                    </StatusBadge>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-700",
                        t.attainment >= 100
                          ? "bg-[color:var(--success)]"
                          : t.attainment >= 80
                          ? "bg-primary"
                          : "bg-[color:var(--warning)]"
                      )}
                      style={{ width: `${Math.min(100, t.attainment)}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1 tabular-nums">
                    ${(t.revenue / 1000).toFixed(0)}K of ${(t.quota / 1000).toFixed(0)}K
                  </p>
                </div>

                {/* Top account */}
                <div className="pt-3 border-t border-border flex items-center gap-1.5 text-xs">
                  <Building2 className="h-3 w-3 text-muted-foreground shrink-0" />
                  <span className="text-muted-foreground">Top account:</span>
                  <span className="font-medium text-foreground truncate">{t.topAccount}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Bottom insight row */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Top Performer</p>
                <p className="text-lg font-semibold mt-1">{topTerritory.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{topTerritory.leadName}'s team</p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--warning)]/15 text-[color:var(--warning)]">
                <Trophy className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-3">
              <ArrowUpRight className="h-3 w-3" /> {topTerritory.attainment}% of quota · ${(topTerritory.revenue / 1000000).toFixed(1)}M
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Underperformer</p>
                <p className="text-lg font-semibold mt-1">LATAM</p>
                <p className="text-xs text-muted-foreground mt-0.5">Carlos Mendez's team</p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--warning)]/15 text-[color:var(--warning)]">
                <MapPin className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xs text-[color:var(--warning)] inline-flex items-center gap-0.5 mt-3">
              <ArrowUpRight className="h-3 w-3 rotate-90" /> 78% of quota · needs $175K to close gap
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Avg. Rep Coverage</p>
                <p className="text-lg font-semibold tabular-nums mt-1">{(totalReps / territories.length).toFixed(1)}</p>
                <p className="text-xs text-muted-foreground mt-0.5">reps per territory</p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                <Users className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-3">
              <ArrowUpRight className="h-3 w-3" /> within target range (3–10)
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
