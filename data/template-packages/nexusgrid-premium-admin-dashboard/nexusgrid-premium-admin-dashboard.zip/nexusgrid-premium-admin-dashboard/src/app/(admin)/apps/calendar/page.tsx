"use client";

import * as React from "react";
import {
  Calendar as CalendarIcon,
  Plus,
  ChevronLeft,
  ChevronRight,
  Clock,
  MapPin,
  Users,
  Video,
  Bell,
  Search,
  MoreHorizontal,
  Pencil,
  Trash2,
  CalendarDays,
  List,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type Category = "work" | "personal" | "family" | "important" | "holiday";

type CalEvent = {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  start: string; // HH:MM
  end: string; // HH:MM
  category: Category;
  location?: string;
  description?: string;
  attendees?: string[];
  meetingUrl?: string;
};

const categoryConfig: Record<Category, { label: string; color: string; bg: string; text: string; tone: StatusTone }> = {
  work: { label: "Work", color: "var(--primary)", bg: "bg-primary/12", text: "text-primary", tone: "primary" },
  personal: { label: "Personal", color: "oklch(0.70 0.15 75)", bg: "bg-[color:var(--warning)]/15", text: "text-[color:var(--warning)]", tone: "warning" },
  family: { label: "Family", color: "oklch(0.62 0.18 140)", bg: "bg-[color:var(--success)]/12", text: "text-[color:var(--success)]", tone: "success" },
  important: { label: "Important", color: "var(--destructive)", bg: "bg-destructive/12", text: "text-destructive", tone: "danger" },
  holiday: { label: "Holiday", color: "oklch(0.62 0.18 305)", bg: "bg-violet-500/12", text: "text-violet-500", tone: "violet" },
};

// July 2026
const events: CalEvent[] = [
  { id: "ev1", title: "Product Strategy Sync", date: "2026-07-02", start: "09:30", end: "10:30", category: "work", location: "Conference Room A · 4F", description: "Quarterly product roadmap alignment with the platform team and design leads. Bring the latest research findings from the Q2 customer interviews.", attendees: ["Marcus Reyes", "Sarah Chen", "James Okoro"], meetingUrl: "https://meet.nexusgrid.io/strategy-sync" },
  { id: "ev2", title: "Lunch with Priya", date: "2026-07-02", start: "12:30", end: "13:30", category: "personal", location: "Olive & Oak, downtown", description: "Catch up after the move to Austin." },
  { id: "ev3", title: "Q3 Sales Kickoff", date: "2026-07-07", start: "10:00", end: "12:00", category: "important", location: "Grand Ballroom · 1F", description: "All-hands sales kickoff for Q3 targets. Coverage of new pricing model, territory realignment, and enablement tracks.", attendees: ["Elena Petrov", "Aiko Tanaka", "Marcus Reyes", "Sarah Chen"] },
  { id: "ev4", title: "Dentist Appointment", date: "2026-07-08", start: "14:00", end: "15:00", category: "personal", location: "Riverside Dental", description: "6-month cleaning and check-up." },
  { id: "ev5", title: "Sophia's Recital", date: "2026-07-10", start: "18:00", end: "19:30", category: "family", location: "Lincoln Middle School Auditorium", description: "Spring violin recital. Bring the camera." },
  { id: "ev6", title: "Board Review", date: "2026-07-14", start: "13:00", end: "14:30", category: "important", location: "Boardroom · 12F", description: "H1 performance review and capital allocation discussion with the board.", attendees: ["Elena Petrov", "Marcus Reyes"] },
  { id: "ev7", title: "Engineering 1:1", date: "2026-07-15", start: "11:00", end: "11:30", category: "work", location: "Zoom", attendees: ["Aiko Tanaka"] },
  { id: "ev8", title: "Independence Day", date: "2026-07-03", start: "00:00", end: "23:59", category: "holiday", description: "Company holiday — offices closed." },
  { id: "ev9", title: "Vendor Demo: Stripe", date: "2026-07-16", start: "15:00", end: "16:00", category: "work", location: "Conference Room B · 4F", description: "Payments integration demo with Stripe platform team.", attendees: ["James Okoro"], meetingUrl: "https://meet.nexusgrid.io/stripe-demo" },
  { id: "ev10", title: "Marketing Offsite", date: "2026-07-21", start: "09:00", end: "17:00", category: "work", location: "Cedar Ridge Lodge", description: "Full-day offsite with the marketing team. Brand refresh planning + Q4 campaign roadmap." },
  { id: "ev11", title: "Anniversary Dinner", date: "2026-07-22", start: "19:30", end: "22:00", category: "family", location: "The Marlowe", description: "Reservation under Reyes." },
  { id: "ev12", title: "Customer Advisory Board", date: "2026-07-23", start: "10:00", end: "13:00", category: "important", location: "Boardroom · 12F", attendees: ["Sarah Chen", "Elena Petrov", "Marcus Reyes"] },
  { id: "ev13", title: "Yoga Class", date: "2026-07-29", start: "07:00", end: "08:00", category: "personal", location: "Studio One" },
  { id: "ev14", title: "Annual Leave", date: "2026-07-30", start: "00:00", end: "23:59", category: "holiday", description: "Taking the day off." },
];

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const WEEKDAY_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const CURRENT_YEAR = 2026;
const CURRENT_MONTH = 6; // July (0-indexed)

function pad(n: number) { return n.toString().padStart(2, "0"); }
function fmtDate(y: number, m: number, d: number) { return `${y}-${pad(m + 1)}-${pad(d)}`; }

export default function CalendarPage() {
  const [view, setView] = React.useState<"month" | "week" | "day" | "agenda">("month");
  const [selectedDate, setSelectedDate] = React.useState<string>("2026-07-15");
  const [activeEvent, setActiveEvent] = React.useState<CalEvent | null>(null);
  const [newEventOpen, setNewEventOpen] = React.useState(false);
  const [search, setSearch] = React.useState("");
  const [activeCategories, setActiveCategories] = React.useState<Set<Category>>(new Set(["work", "personal", "family", "important", "holiday"]));

  const today = new Date(CURRENT_YEAR, CURRENT_MONTH, 15);

  const visibleEvents = events.filter((e) => activeCategories.has(e.category));

  function toggleCategory(c: Category) {
    setActiveCategories((prev) => {
      const next = new Set(prev);
      if (next.has(c)) next.delete(c); else next.add(c);
      return next;
    });
  }

  // Build month grid
  const firstDay = new Date(CURRENT_YEAR, CURRENT_MONTH, 1);
  const startWeekday = firstDay.getDay();
  const daysInMonth = new Date(CURRENT_YEAR, CURRENT_MONTH + 1, 0).getDate();
  const trailingDays = 42 - (startWeekday + daysInMonth);

  const monthCells: { date: Date | null; day: number | null; iso: string | null }[] = [];
  // Leading blanks (previous month tail) — render previous month days
  for (let i = 0; i < startWeekday; i++) {
    const d = new Date(CURRENT_YEAR, CURRENT_MONTH, -(startWeekday - 1 - i));
    monthCells.push({ date: d, day: d.getDate(), iso: fmtDate(d.getFullYear(), d.getMonth(), d.getDate()) });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    monthCells.push({ date: new Date(CURRENT_YEAR, CURRENT_MONTH, d), day: d, iso: fmtDate(CURRENT_YEAR, CURRENT_MONTH, d) });
  }
  // Trailing days
  let nextDay = 1;
  while (monthCells.length < 42) {
    const d = new Date(CURRENT_YEAR, CURRENT_MONTH + 1, nextDay);
    monthCells.push({ date: d, day: d.getDate(), iso: fmtDate(d.getFullYear(), d.getMonth(), d.getDate()) });
    nextDay++;
  }

  // Upcoming events (sorted)
  const upcomingEvents = [...visibleEvents]
    .filter((e) => e.date >= "2026-07-15")
    .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start))
    .slice(0, 5);

  // Agenda list (all upcoming sorted)
  const agendaList = [...visibleEvents].sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));

  // Day events
  const dayEvents = visibleEvents.filter((e) => e.date === selectedDate).sort((a, b) => a.start.localeCompare(b.start));

  // Week computation (week of selectedDate)
  const selectedDateObj = new Date(selectedDate + "T00:00:00");
  const weekStart = new Date(selectedDateObj);
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    return d;
  });

  function isToday(iso: string) { return iso === "2026-07-15"; }
  function eventsOn(iso: string) {
    return visibleEvents
      .filter((e) => e.date === iso)
      .sort((a, b) => a.start.localeCompare(b.start));
  }

  function handleSaveEvent() {
    toast.success("Event saved", { description: "Your calendar has been updated." });
    setNewEventOpen(false);
    setActiveEvent(null);
  }

  return (
    <>
      <PageHeader
        title="Calendar"
        description="Schedule meetings, appointments and reminders across your team."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "Calendar" }]}
        icon={CalendarIcon}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => { setSelectedDate("2026-07-15"); toast.message("Jumped to today"); }}>
              <CalendarDays className="h-3.5 w-3.5" /> Today
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => setNewEventOpen(true)}>
              <Plus className="h-3.5 w-3.5" /> New Event
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 xl:grid-cols-[280px_1fr_320px] gap-4">
        {/* LEFT — mini calendar + categories */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">{MONTH_NAMES[CURRENT_MONTH]} {CURRENT_YEAR}</CardTitle>
                <div className="flex items-center gap-0.5">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.message("Previous month")}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.message("Next month")}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-0.5 text-center">
                {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
                  <div key={i} className="text-[10px] font-medium text-muted-foreground py-1">{d}</div>
                ))}
                {monthCells.slice(0, 35).map((c, i) => {
                  const isCurMonth = c.date?.getMonth() === CURRENT_MONTH;
                  const selected = c.iso === selectedDate;
                  const todayCls = c.iso && isToday(c.iso);
                  const hasEvents = c.iso ? eventsOn(c.iso).length > 0 : false;
                  return (
                    <button
                      key={i}
                      disabled={!c.iso}
                      onClick={() => c.iso && setSelectedDate(c.iso)}
                      className={cn(
                        "aspect-square text-xs rounded-md transition-colors relative grid place-items-center",
                        !isCurMonth && "text-muted-foreground/40",
                        isCurMonth && "text-foreground hover:bg-muted",
                        selected && "bg-primary text-primary-foreground hover:bg-primary",
                        todayCls && !selected && "ring-1 ring-inset ring-primary/40"
                      )}
                    >
                      {c.day}
                      {hasEvents && !selected && (
                        <span className="absolute bottom-1 h-1 w-1 rounded-full bg-primary" />
                      )}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Categories</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1.5">
              {Object.entries(categoryConfig).map(([key, cfg]) => {
                const active = activeCategories.has(key as Category);
                const count = events.filter((e) => e.category === key).length;
                return (
                  <button
                    key={key}
                    onClick={() => toggleCategory(key as Category)}
                    className={cn(
                      "w-full flex items-center justify-between rounded-md px-2 py-1.5 text-sm transition-colors",
                      active ? "hover:bg-muted" : "opacity-40 hover:opacity-70"
                    )}
                  >
                    <span className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: cfg.color }} />
                      <span className="text-foreground">{cfg.label}</span>
                    </span>
                    <span className="text-xs text-muted-foreground tabular-nums">{count}</span>
                  </button>
                );
              })}
            </CardContent>
          </Card>
        </div>

        {/* CENTER — main calendar */}
        <Card className="flex flex-col min-h-[640px]">
          <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b pb-4">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <CalendarIcon className="h-4 w-4 text-primary" />
                {MONTH_NAMES[CURRENT_MONTH]} {CURRENT_YEAR}
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-1">{visibleEvents.length} events scheduled · {activeCategories.size} of {Object.keys(categoryConfig).length} categories visible</p>
            </div>
            <Tabs value={view} onValueChange={(v) => setView(v as any)}>
              <TabsList className="h-8">
                <TabsTrigger value="month" className="text-xs gap-1"><CalendarDays className="h-3.5 w-3.5" /> Month</TabsTrigger>
                <TabsTrigger value="week" className="text-xs">Week</TabsTrigger>
                <TabsTrigger value="day" className="text-xs">Day</TabsTrigger>
                <TabsTrigger value="agenda" className="text-xs gap-1"><List className="h-3.5 w-3.5" /> Agenda</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>

          <CardContent className="flex-1 p-0">
            {/* MONTH VIEW */}
            {view === "month" && (
              <div className="flex flex-col h-full">
                <div className="grid grid-cols-7 border-b">
                  {WEEKDAY_SHORT.map((d) => (
                    <div key={d} className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2 text-center border-r last:border-r-0">{d}</div>
                  ))}
                </div>
                <div className="grid grid-cols-7 grid-rows-6 flex-1">
                  {monthCells.map((c, i) => {
                    const dayEvents = c.iso ? eventsOn(c.iso) : [];
                    const isCurMonth = c.date?.getMonth() === CURRENT_MONTH;
                    const selected = c.iso === selectedDate;
                    const todayCls = c.iso && isToday(c.iso);
                    return (
                      <div
                        key={i}
                        onClick={() => c.iso && setSelectedDate(c.iso)}
                        className={cn(
                          "border-r border-b last-of-type:border-r-0 p-1.5 min-h-[92px] cursor-pointer transition-colors hover:bg-muted/40 flex flex-col gap-1",
                          !isCurMonth && "bg-muted/20",
                          selected && "bg-primary/[0.04] ring-1 ring-inset ring-primary/30",
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span className={cn(
                            "text-xs font-medium grid place-items-center h-6 w-6 rounded-full",
                            todayCls ? "bg-primary text-primary-foreground" : isCurMonth ? "text-foreground" : "text-muted-foreground/50"
                          )}>
                            {c.day}
                          </span>
                          {dayEvents.length > 3 && (
                            <span className="text-[10px] text-muted-foreground">+{dayEvents.length - 3}</span>
                          )}
                        </div>
                        <div className="space-y-0.5 overflow-hidden">
                          {dayEvents.slice(0, 3).map((e) => {
                            const cfg = categoryConfig[e.category];
                            const allDay = e.start === "00:00";
                            return (
                              <button
                                key={e.id}
                                onClick={(ev) => { ev.stopPropagation(); setActiveEvent(e); }}
                                className={cn(
                                  "w-full text-left text-[10px] leading-tight rounded px-1.5 py-0.5 truncate font-medium hover:opacity-80 transition-opacity",
                                  cfg.bg, cfg.text
                                )}
                                title={e.title}
                              >
                                {!allDay && <span className="opacity-70 mr-1 tabular-nums">{e.start}</span>}
                                {e.title}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* WEEK VIEW */}
            {view === "week" && (
              <div className="flex flex-col">
                <div className="grid grid-cols-[60px_repeat(7,1fr)] border-b">
                  <div className="border-r" />
                  {weekDays.map((d, i) => {
                    const iso = fmtDate(d.getFullYear(), d.getMonth(), d.getDate());
                    const isTodayCls = isToday(iso);
                    const selected = iso === selectedDate;
                    return (
                      <div key={i} className={cn("text-center py-2 border-r last:border-r-0 cursor-pointer", selected && "bg-primary/[0.06]")} onClick={() => setSelectedDate(iso)}>
                        <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{WEEKDAY_SHORT[d.getDay()]}</div>
                        <div className={cn(
                          "text-lg font-semibold mt-0.5 grid place-items-center mx-auto h-8 w-8 rounded-full",
                          isTodayCls ? "bg-primary text-primary-foreground" : "text-foreground"
                        )}>{d.getDate()}</div>
                      </div>
                    );
                  })}
                </div>
                <ScrollArea className="h-[520px]">
                  <div className="grid grid-cols-[60px_repeat(7,1fr)]">
                    {Array.from({ length: 24 }).map((_, hour) => (
                      <React.Fragment key={hour}>
                        <div className="text-[10px] text-muted-foreground text-right pr-2 pt-1 h-12 border-r border-b">{pad(hour)}:00</div>
                        {weekDays.map((d, di) => {
                          const iso = fmtDate(d.getFullYear(), d.getMonth(), d.getDate());
                          const hourEvents = eventsOn(iso).filter((e) => parseInt(e.start.split(":")[0]) === hour && e.start !== "00:00");
                          return (
                            <div key={di} className="border-r border-b last:border-r-0 h-12 p-0.5 relative hover:bg-muted/30">
                              {hourEvents.map((e) => {
                                const cfg = categoryConfig[e.category];
                                const mins = parseInt(e.start.split(":")[1]);
                                const top = (mins / 60) * 100;
                                return (
                                  <button
                                    key={e.id}
                                    onClick={() => setActiveEvent(e)}
                                    className={cn("absolute inset-x-0.5 rounded px-1.5 py-0.5 text-[10px] font-medium text-left truncate", cfg.bg, cfg.text)}
                                    style={{ top: `${top}%`, height: 36 }}
                                  >
                                    {e.start} {e.title}
                                  </button>
                                );
                              })}
                            </div>
                          );
                        })}
                      </React.Fragment>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {/* DAY VIEW */}
            {view === "day" && (
              <div className="flex flex-col">
                <div className="px-4 py-3 border-b bg-muted/30">
                  <div className="text-xs text-muted-foreground uppercase tracking-wide">{new Date(selectedDate + "T00:00:00").toLocaleDateString("en-US", { weekday: "long" })}</div>
                  <div className="text-xl font-semibold mt-0.5">{new Date(selectedDate + "T00:00:00").toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</div>
                  <div className="text-xs text-muted-foreground mt-1">{dayEvents.length} events scheduled</div>
                </div>
                <ScrollArea className="h-[500px]">
                  <div className="relative">
                    {Array.from({ length: 24 }).map((_, hour) => (
                      <div key={hour} className="grid grid-cols-[60px_1fr] h-14 border-b">
                        <div className="text-[10px] text-muted-foreground text-right pr-2 pt-1 border-r">{pad(hour)}:00</div>
                        <div className="relative p-1 hover:bg-muted/30">
                          {dayEvents.filter((e) => parseInt(e.start.split(":")[0]) === hour).map((e) => {
                            const cfg = categoryConfig[e.category];
                            return (
                              <button
                                key={e.id}
                                onClick={() => setActiveEvent(e)}
                                className={cn("w-full text-left rounded-md px-2 py-1 hover:opacity-80 transition-opacity")}
                                style={{ background: `color-mix(in srgb, ${cfg.color} 12%, transparent)` }}
                              >
                                <div className="flex items-center gap-2">
                                  <span className={cn("h-2 w-2 rounded-full", cfg.bg)} style={{ background: cfg.color }} />
                                  <span className="text-xs font-medium text-foreground">{e.start} – {e.end}</span>
                                </div>
                                <p className="text-xs text-foreground mt-0.5 font-medium truncate">{e.title}</p>
                                {e.location && <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5"><MapPin className="h-2.5 w-2.5" />{e.location}</p>}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {/* AGENDA VIEW */}
            {view === "agenda" && (
              <ScrollArea className="h-[560px]">
                <div className="divide-y">
                  {agendaList.map((e) => {
                    const cfg = categoryConfig[e.category];
                    return (
                      <button
                        key={e.id}
                        onClick={() => setActiveEvent(e)}
                        className="w-full text-left flex items-center gap-4 px-4 py-3 hover:bg-muted/40 transition-colors"
                      >
                        <div className="w-20 text-center shrink-0">
                          <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{new Date(e.date + "T00:00:00").toLocaleDateString("en-US", { month: "short" })}</div>
                          <div className="text-lg font-semibold">{new Date(e.date + "T00:00:00").getDate()}</div>
                        </div>
                        <div className={cn("w-1 self-stretch rounded-full")} style={{ background: cfg.color }} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium text-foreground truncate">{e.title}</p>
                            <StatusBadge tone={cfg.tone} className="text-[9px]">{cfg.label}</StatusBadge>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                            <span className="flex items-center gap-1 tabular-nums"><Clock className="h-3 w-3" />{e.start === "00:00" ? "All day" : `${e.start} – ${e.end}`}</span>
                            {e.location && <span className="flex items-center gap-1 truncate"><MapPin className="h-3 w-3" />{e.location}</span>}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* RIGHT — upcoming */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">Upcoming Events</CardTitle>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setView("agenda")}>All</Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {upcomingEvents.length === 0 && (
                <div className="text-xs text-muted-foreground text-center py-6">No upcoming events.</div>
              )}
              {upcomingEvents.map((e) => {
                const cfg = categoryConfig[e.category];
                const d = new Date(e.date + "T00:00:00");
                return (
                  <button
                    key={e.id}
                    onClick={() => setActiveEvent(e)}
                    className="w-full text-left rounded-lg border border-border p-3 hover:border-primary/40 hover:shadow-premium-xs transition-all"
                  >
                    <div className="flex items-start gap-3">
                      <div className="shrink-0 text-center w-12">
                        <div className="text-[10px] uppercase text-muted-foreground">{d.toLocaleDateString("en-US", { month: "short" })}</div>
                        <div className="text-lg font-semibold leading-tight">{d.getDate()}</div>
                      </div>
                      <div className="w-px self-stretch rounded-full" style={{ background: cfg.color }} />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-foreground truncate">{e.title}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] text-muted-foreground tabular-nums flex items-center gap-0.5">
                            <Clock className="h-2.5 w-2.5" />{e.start === "00:00" ? "All day" : e.start}
                          </span>
                          <StatusBadge tone={cfg.tone} className="text-[9px] px-1.5 py-0">{cfg.label}</StatusBadge>
                        </div>
                        {e.location && (
                          <p className="text-[10px] text-muted-foreground mt-1 truncate flex items-center gap-0.5">
                            <MapPin className="h-2.5 w-2.5" />{e.location}
                          </p>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Day at a Glance</CardTitle>
              <p className="text-xs text-muted-foreground">{new Date(selectedDate + "T00:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</p>
            </CardHeader>
            <CardContent className="space-y-2">
              {dayEvents.length === 0 ? (
                <div className="text-xs text-muted-foreground text-center py-4">No events this day.</div>
              ) : dayEvents.map((e) => {
                const cfg = categoryConfig[e.category];
                return (
                  <button
                    key={e.id}
                    onClick={() => setActiveEvent(e)}
                    className="w-full text-left flex items-center gap-3 rounded-md px-2 py-2 hover:bg-muted/50 transition-colors"
                  >
                    <div className="text-[10px] text-muted-foreground tabular-nums w-12 shrink-0">{e.start}</div>
                    <span className="h-8 w-1 rounded-full" style={{ background: cfg.color }} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium truncate">{e.title}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{e.location ?? cfg.label}</p>
                    </div>
                  </button>
                );
              })}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Event detail dialog */}
      <Dialog open={!!activeEvent} onOpenChange={(o) => !o && setActiveEvent(null)}>
        <DialogContent className="sm:max-w-[520px]">
          {activeEvent && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-2 mb-2">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: categoryConfig[activeEvent.category].color }} />
                  <StatusBadge tone={categoryConfig[activeEvent.category].tone}>{categoryConfig[activeEvent.category].label}</StatusBadge>
                </div>
                <DialogTitle className="text-xl">{activeEvent.title}</DialogTitle>
                <DialogDescription>
                  {new Date(activeEvent.date + "T00:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="tabular-nums">{activeEvent.start === "00:00" ? "All day" : `${activeEvent.start} – ${activeEvent.end}`}</span>
                  </div>
                  {activeEvent.location && (
                    <div className="flex items-center gap-2 col-span-2">
                      <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                      <span className="truncate">{activeEvent.location}</span>
                    </div>
                  )}
                </div>
                {activeEvent.description && (
                  <div className="rounded-md bg-muted/50 p-3 text-sm text-muted-foreground leading-relaxed">
                    {activeEvent.description}
                  </div>
                )}
                {activeEvent.attendees && activeEvent.attendees.length > 0 && (
                  <div>
                    <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1.5"><Users className="h-3.5 w-3.5" />Attendees ({activeEvent.attendees.length})</div>
                    <div className="flex flex-wrap gap-2">
                      {activeEvent.attendees.map((a, i) => (
                        <div key={a} className="flex items-center gap-2 rounded-full bg-muted/60 py-0.5 pl-0.5 pr-3">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={`https://i.pravatar.cc/40?u=${a}`} alt={a} />
                            <AvatarFallback className="text-[9px]">{a.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                          </Avatar>
                          <span className="text-xs">{a}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {activeEvent.meetingUrl && (
                  <Button variant="outline" size="sm" className="w-full gap-2" onClick={() => toast.message("Opening video call")}>
                    <Video className="h-4 w-4" /> Join meeting
                  </Button>
                )}
              </div>
              <DialogFooter className="gap-2">
                <Button variant="ghost" size="sm" className="gap-1.5 text-destructive" onClick={() => { toast.success("Event deleted"); setActiveEvent(null); }}>
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </Button>
                <div className="flex-1" />
                <Button variant="outline" size="sm" onClick={() => setActiveEvent(null)}>Close</Button>
                <Button size="sm" className="gap-1.5" onClick={() => toast.success("Changes saved")}>
                  <Pencil className="h-3.5 w-3.5" /> Edit
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* New event dialog */}
      <Dialog open={newEventOpen} onOpenChange={setNewEventOpen}>
        <DialogContent className="sm:max-w-[520px]">
          <DialogHeader>
            <DialogTitle>New Event</DialogTitle>
            <DialogDescription>Add a new event to your calendar.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Title</Label>
              <Input placeholder="Event title" className="text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Date</Label>
                <Input type="date" defaultValue="2026-07-15" className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Category</Label>
                <Select defaultValue="work">
                  <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(categoryConfig).map(([k, cfg]) => (
                      <SelectItem key={k} value={k} className="text-sm">
                        <span className="flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full" style={{ background: cfg.color }} />
                          {cfg.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Start time</Label>
                <Input type="time" defaultValue="09:00" className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">End time</Label>
                <Input type="time" defaultValue="10:00" className="text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Location</Label>
              <Input placeholder="Add location or meeting link" className="text-sm" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Description</Label>
              <Textarea placeholder="Add description" rows={3} className="text-sm" />
            </div>
            <div className="flex items-center gap-2 rounded-md bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
              <Bell className="h-3.5 w-3.5" /> Reminder: 15 minutes before
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setNewEventOpen(false)}>Cancel</Button>
            <Button size="sm" onClick={handleSaveEvent} className="gap-1.5"><Plus className="h-3.5 w-3.5" /> Create Event</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
