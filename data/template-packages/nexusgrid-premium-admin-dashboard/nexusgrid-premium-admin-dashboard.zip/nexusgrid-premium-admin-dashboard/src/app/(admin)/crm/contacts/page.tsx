"use client";

import * as React from "react";
import {
  Contact,
  Mail,
  Phone,
  Building2,
  MapPin,
  Linkedin,
  Twitter,
  Globe,
  Search,
  Grid3x3,
  Table as TableIcon,
  MoreHorizontal,
  Eye,
  Trash2,
  Plus,
  MessageSquare,
  Bell,
  BellOff,
  TrendingUp,
  ArrowUpRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type ContactStatus = "subscribed" | "engaged" | "inactive" | "bounced";

type ContactItem = {
  id: string;
  name: string;
  avatar: string;
  title: string;
  company: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  twitter: string | null;
  website: string;
  status: ContactStatus;
  lastEngaged: string;
};

const contacts: ContactItem[] = [
  { id: "CT-3101", name: "Daniela Pierce", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&h=120&fit=crop", title: "VP of Operations", company: "Globex Corp", email: "daniela@globex.com", phone: "+1 (415) 555-0142", location: "San Francisco, US", linkedin: "daniela-pierce", twitter: "danielap", website: "globex.com", status: "engaged", lastEngaged: "2 hr ago" },
  { id: "CT-3102", name: "Bill Lumbergh", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop", title: "Director of IT", company: "Initech", email: "bill@initech.io", phone: "+1 (512) 555-0184", location: "Austin, US", linkedin: "bill-lumbergh", twitter: null, website: "initech.io", status: "subscribed", lastEngaged: "Yesterday" },
  { id: "CT-3103", name: "Gavin Belson", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop", title: "Chief Innovation Officer", company: "Hooli", email: "gavin@hooli.com", phone: "+1 (650) 555-0192", location: "Palo Alto, US", linkedin: "gavin-belson", twitter: "gbelson", website: "hooli.com", status: "engaged", lastEngaged: "3 hr ago" },
  { id: "CT-3104", name: "Alice Margolis", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop", title: "Head of Procurement", company: "Umbrella Inc", email: "alice@umbrellahealth.com", phone: "+1 (212) 555-0173", location: "New York, US", linkedin: "alice-margolis", twitter: null, website: "umbrellahealth.com", status: "inactive", lastEngaged: "2 weeks ago" },
  { id: "CT-3105", name: "Wile Coyote", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&fit=crop", title: "VP Manufacturing", company: "Acme Corp", email: "wile@acme.com", phone: "+1 (505) 555-0124", location: "Albuquerque, US", linkedin: "wile-coyote", twitter: "acmewile", website: "acme.com", status: "subscribed", lastEngaged: "5 days ago" },
  { id: "CT-3106", name: "Sophie Lambert", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop", title: "VP Partnerships", company: "Stripe", email: "sophie@stripe.com", phone: "+1 (415) 555-0231", location: "San Francisco, US", linkedin: "sophie-lambert", twitter: "sophiel", website: "stripe.com", status: "engaged", lastEngaged: "Today" },
  { id: "CT-3107", name: "Marcus Halberd", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop", title: "CTO", company: "Plaid", email: "marcus@plaid.com", phone: "+1 (415) 555-0298", location: "San Francisco, US", linkedin: "marcus-halberd", twitter: "mhalberd", website: "plaid.com", status: "subscribed", lastEngaged: "4 hr ago" },
  { id: "CT-3108", name: "Yuki Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&h=120&fit=crop", title: "Head of Digital", company: "Rakuten", email: "yuki@rakuten.com", phone: "+81 3-5555-0184", location: "Tokyo, JP", linkedin: "yuki-tanaka", twitter: null, website: "rakuten.com", status: "engaged", lastEngaged: "1 day ago" },
  { id: "CT-3109", name: "Olivia Hartwell", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=120&h=120&fit=crop", title: "Director of Engineering", company: "Ro Health", email: "olivia@ro.co", phone: "+1 (646) 555-0156", location: "New York, US", linkedin: "olivia-hartwell", twitter: "oliviah", website: "ro.co", status: "engaged", lastEngaged: "6 hr ago" },
  { id: "CT-3110", name: "Daniel Whitmore", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop", title: "VP Sales", company: "Cloudflare", email: "daniel@cloudflare.com", phone: "+1 (415) 555-0312", location: "San Francisco, US", linkedin: "daniel-whitmore", twitter: "dwhitmore", website: "cloudflare.com", status: "subscribed", lastEngaged: "Today" },
  { id: "CT-3111", name: "Priya Iyer", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=120&h=120&fit=crop", title: "Head of Customer Success", company: "Freshworks", email: "priya@freshworks.com", phone: "+91 44-5555-0184", location: "Chennai, IN", linkedin: "priya-iyer", twitter: null, website: "freshworks.com", status: "inactive", lastEngaged: "1 week ago" },
  { id: "CT-3112", name: "Camille Dubois", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop", title: "VP Product", company: "Doctolib", email: "camille@doctolib.fr", phone: "+33 1-5555-0142", location: "Paris, FR", linkedin: "camille-dubois", twitter: "camilled", website: "doctolib.fr", status: "engaged", lastEngaged: "Today" },
  { id: "CT-3113", name: "Rashid Al-Mansour", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&fit=crop", title: "VP Operations", company: "Careem", email: "rashid@careem.com", phone: "+971 4-555-0184", location: "Dubai, AE", linkedin: "rashid-almansour", twitter: "rashidam", website: "careem.com", status: "subscribed", lastEngaged: "2 hr ago" },
  { id: "CT-3114", name: "Mira Sundqvist", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop", title: "Head of Growth", company: "Klarna", email: "mira@klarna.com", phone: "+46 8-555-0142", location: "Stockholm, SE", linkedin: "mira-sundqvist", twitter: "miras", website: "klarna.com", status: "engaged", lastEngaged: "Today" },
  { id: "CT-3115", name: "Hiroshi Nakamura", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop", title: "Director of Marketplace", company: "Mercari", email: "hiroshi@mercari.com", phone: "+81 3-5555-0248", location: "Tokyo, JP", linkedin: "hiroshi-nakamura", twitter: null, website: "mercari.com", status: "bounced", lastEngaged: "3 weeks ago" },
];

const statusToneMap: Record<ContactStatus, StatusTone> = {
  subscribed: "success",
  engaged: "primary",
  inactive: "warning",
  bounced: "danger",
};

/* ContactKpi — communication-icon-strip motif: a row of small channel icons with active state */
function ContactKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  trend: string;
  trendPositive: boolean;
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* Channel strip — distinct motif: shows which comms channels are active for this segment */}
        <div className="flex items-center gap-1 mb-3">
          {[
            { Icon: Mail, active: true, color: "var(--primary)" },
            { Icon: Phone, active: true, color: "var(--success)" },
            { Icon: MessageSquare, active: true, color: "var(--info)" },
            { Icon: Linkedin, active: true, color: "oklch(0.58 0.13 250)" },
            { Icon: Twitter, active: false, color: "var(--muted-foreground)" },
          ].map((c, i) => (
            <div
              key={i}
              className={cn(
                "grid place-items-center h-7 w-7 rounded-md transition-all",
                c.active ? "ring-1 ring-inset" : "opacity-30"
              )}
              style={
                c.active
                  ? { background: `color-mix(in srgb, ${c.color} 14%, transparent)`, color: c.color, "--tw-ring-color": `color-mix(in srgb, ${c.color} 25%, transparent)` } as React.CSSProperties
                  : { color: "var(--muted-foreground)" }
              }
            >
              <c.Icon className="h-3.5 w-3.5" />
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground truncate">{hint}</span>
          <span className={cn("inline-flex items-center gap-0.5 font-medium shrink-0", trendPositive ? "text-[color:var(--success)]" : "text-destructive")}>
            {trendPositive ? <TrendingUp className="h-3 w-3" /> : <ArrowUpRight className="h-3 w-3 rotate-45" />}
            {trend}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ContactsPage() {
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState<string>("all");

  const filtered = React.useMemo(() => {
    return contacts.filter((c) => {
      const matchesSearch =
        !search ||
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.email.toLowerCase().includes(search.toLowerCase()) ||
        c.company.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === "all" || c.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [search, statusFilter]);

  return (
    <>
      <PageHeader
        title="Contacts"
        description="Your rolodex of decision-makers, champions, and influencers across all accounts."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Contacts" }]}
        icon={Contact}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Contacts exported")}>
              <Contact className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add contact form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Contact
            </Button>
          </>
        }
      />

      {/* KPI Row — communication-channel strip motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <ContactKpi label="Total Contacts" value="3,842" hint="across 412 accounts" icon={Contact} accent="primary" trend="+186 this month" trendPositive={true} />
        <ContactKpi label="Subscribed" value="2,184" hint="opted into emails" icon={Mail} accent="success" trend="+4.2% opt-in rate" trendPositive={true} />
        <ContactKpi label="Engaged" value="1,246" hint="active in last 30d" icon={MessageSquare} accent="info" trend="+12.4% engagement" trendPositive={true} />
        <ContactKpi label="Inactive" value="412" hint="no activity 60d+" icon={BellOff} accent="warning" trend="−8 reactivated" trendPositive={true} />
      </div>

      {/* Directory with Grid/Table toggle */}
      <Card>
        <CardHeader className="pb-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Contact className="h-4 w-4 text-primary" />
              Contact Directory
            </CardTitle>
            <CardDescription>{filtered.length} of {contacts.length} contacts shown</CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                placeholder="Search name, email, company…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="h-9 pl-8 w-[200px] sm:w-[260px] text-xs"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-9 w-[130px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="subscribed">Subscribed</SelectItem>
                <SelectItem value="engaged">Engaged</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="bounced">Bounced</SelectItem>
              </SelectContent>
            </Select>
            <Tabs defaultValue="grid" className="ml-1">
              <TabsList className="h-9">
                <TabsTrigger value="grid" className="text-xs gap-1 px-2.5">
                  <Grid3x3 className="h-3.5 w-3.5" /> Grid
                </TabsTrigger>
                <TabsTrigger value="table" className="text-xs gap-1 px-2.5">
                  <TableIcon className="h-3.5 w-3.5" /> Table
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="grid">
            {/* Grid View */}
            <TabsContent value="grid">
              {filtered.length === 0 ? (
                <div className="py-12 text-center">
                  <Contact className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No contacts match your filters.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {filtered.map((c) => (
                    <div
                      key={c.id}
                      className="group relative rounded-xl border border-border bg-card p-4 hover:border-primary/40 hover:shadow-premium-sm transition-all cursor-pointer"
                      onClick={() => toast.message(`Opening contact ${c.id}`)}
                    >
                      <div className="flex items-start gap-3 mb-3">
                        <Avatar className="h-12 w-12 shrink-0 ring-2 ring-border">
                          <AvatarImage src={c.avatar} alt={c.name} />
                          <AvatarFallback className="text-sm">
                            {c.name.split(" ").map((p) => p[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-sm text-foreground truncate">{c.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{c.title}</p>
                          <p className="text-xs text-primary truncate">{c.company}</p>
                        </div>
                        <div onClick={(e) => e.stopPropagation()}>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7 -mr-1 -mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-44">
                              <DropdownMenuLabel className="text-xs font-mono">{c.id}</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Email drafted to ${c.email}`)}>
                                <Mail className="h-3.5 w-3.5" /> Send email
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Call initiated to ${c.phone}`)}>
                                <Phone className="h-3.5 w-3.5" /> Call
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening ${c.linkedin} on LinkedIn`)}>
                                <Linkedin className="h-3.5 w-3.5" /> View LinkedIn
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${c.name} removed`)}>
                                <Trash2 className="h-3.5 w-3.5" /> Remove
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                      <div className="space-y-1.5 text-xs">
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <Mail className="h-3 w-3 shrink-0" />
                          <span className="truncate">{c.email}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <Phone className="h-3 w-3 shrink-0" />
                          <span className="font-mono tabular-nums">{c.phone}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <MapPin className="h-3 w-3 shrink-0" />
                          <span className="truncate">{c.location}</span>
                        </div>
                      </div>
                      <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
                        <StatusBadge tone={statusToneMap[c.status]} dot className="capitalize">
                          {c.status}
                        </StatusBadge>
                        <div className="flex items-center gap-1">
                          <a
                            href={`https://${c.website}`}
                            target="_blank"
                            rel="noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                            title="Website"
                          >
                            <Globe className="h-3 w-3" />
                          </a>
                          <a
                            href={`https://linkedin.com/in/${c.linkedin}`}
                            target="_blank"
                            rel="noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                            title="LinkedIn"
                          >
                            <Linkedin className="h-3 w-3" />
                          </a>
                          {c.twitter && (
                            <a
                              href={`https://twitter.com/${c.twitter}`}
                              target="_blank"
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                              title="Twitter"
                            >
                              <Twitter className="h-3 w-3" />
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Table View */}
            <TabsContent value="table">
              <div className="overflow-x-auto rounded-lg border border-border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/40 hover:bg-muted/40">
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Contact</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground hidden md:table-cell">Title</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Email</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground hidden lg:table-cell">Phone</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground hidden xl:table-cell">Location</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground hidden sm:table-cell">Last Engaged</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Status</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((c) => (
                      <TableRow
                        key={c.id}
                        className="cursor-pointer hover:bg-muted/30"
                        onClick={() => toast.message(`Opening contact ${c.id}`)}
                      >
                        <TableCell>
                          <div className="flex items-center gap-2.5 min-w-0">
                            <Avatar className="h-8 w-8 shrink-0">
                              <AvatarImage src={c.avatar} alt={c.name} />
                              <AvatarFallback className="text-[10px]">
                                {c.name.split(" ").map((p) => p[0]).join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">{c.name}</p>
                              <p className="text-xs text-muted-foreground truncate">{c.company}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground hidden md:table-cell">{c.title}</TableCell>
                        <TableCell className="text-xs font-mono text-primary truncate max-w-[180px]">{c.email}</TableCell>
                        <TableCell className="text-xs font-mono tabular-nums hidden lg:table-cell">{c.phone}</TableCell>
                        <TableCell className="text-xs text-muted-foreground hidden xl:table-cell">{c.location}</TableCell>
                        <TableCell className="text-xs text-muted-foreground hidden sm:table-cell">{c.lastEngaged}</TableCell>
                        <TableCell>
                          <StatusBadge tone={statusToneMap[c.status]} dot className="capitalize">
                            {c.status}
                          </StatusBadge>
                        </TableCell>
                        <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-44">
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening contact ${c.id}`)}>
                                <Eye className="h-3.5 w-3.5" /> View
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Email drafted to ${c.email}`)}>
                                <Mail className="h-3.5 w-3.5" /> Email
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Call initiated to ${c.phone}`)}>
                                <Phone className="h-3.5 w-3.5" /> Call
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${c.name} removed`)}>
                                <Trash2 className="h-3.5 w-3.5" /> Remove
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </>
  );
}
