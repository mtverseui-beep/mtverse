"use client";

import * as React from "react";
import {
  ShoppingCart,
  Search,
  Plus,
  Minus,
  Trash2,
  X,
  CreditCard,
  Banknote,
  Wallet,
  Receipt,
  User,
  Percent,
  Tag,
  Check,
  Coffee,
  Croissant,
  Sandwich,
  Cookie,
  Apple,
  Soup,
  IceCream,
  Pizza,
  Salad,
  Wine,
  CupSoda,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type Product = {
  id: string;
  name: string;
  price: number;
  category: "Coffee" | "Pastries" | "Sandwiches" | "Desserts" | "Cold Drinks";
  image: string;
  stock: number;
};

const products: Product[] = [
  { id: "p1", name: "Flat White", price: 4.50, category: "Coffee", image: "https://images.unsplash.com/photo-1561047029-3000c68339ca?w=200&h=200&fit=crop", stock: 99 },
  { id: "p2", name: "Cappuccino", price: 4.20, category: "Coffee", image: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=200&h=200&fit=crop", stock: 99 },
  { id: "p3", name: "Cold Brew", price: 4.80, category: "Coffee", image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=200&h=200&fit=crop", stock: 24 },
  { id: "p4", name: "Pour Over", price: 5.20, category: "Coffee", image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=200&h=200&fit=crop", stock: 99 },
  { id: "p5", name: "Almond Croissant", price: 3.80, category: "Pastries", image: "https://images.unsplash.com/photo-1555507036-ab1f404860ab?w=200&h=200&fit=crop", stock: 18 },
  { id: "p6", name: "Pain au Chocolat", price: 3.60, category: "Pastries", image: "https://images.unsplash.com/photo-1623334044303-241021148842?w=200&h=200&fit=crop", stock: 12 },
  { id: "p7", name: "Cinnamon Roll", price: 4.20, category: "Pastries", image: "https://images.unsplash.com/photo-1509365465985-25d11c17e812?w=200&h=200&fit=crop", stock: 8 },
  { id: "p8", name: "Blueberry Muffin", price: 3.40, category: "Pastries", image: "https://images.unsplash.com/photo-1607958996333-41aef7caefaa?w=200&h=200&fit=crop", stock: 15 },
  { id: "p9", name: "Turkey Club", price: 9.80, category: "Sandwiches", image: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=200&h=200&fit=crop", stock: 14 },
  { id: "p10", name: "Caprese Panini", price: 8.50, category: "Sandwiches", image: "https://images.unsplash.com/photo-1528736235302-36529291154d?w=200&h=200&fit=crop", stock: 11 },
  { id: "p11", name: "Avocado Toast", price: 7.90, category: "Sandwiches", image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=200&h=200&fit=crop", stock: 16 },
  { id: "p12", name: "Grilled Cheese", price: 6.80, category: "Sandwiches", image: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=200&h=200&fit=crop", stock: 99 },
  { id: "p13", name: "Tiramisu", price: 5.80, category: "Desserts", image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=200&h=200&fit=crop", stock: 9 },
  { id: "p14", name: "Lemon Tart", price: 4.90, category: "Desserts", image: "https://images.unsplash.com/photo-1519915028121-7d3463d20b13?w=200&h=200&fit=crop", stock: 7 },
  { id: "p15", name: "Cheesecake", price: 5.40, category: "Desserts", image: "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=200&h=200&fit=crop", stock: 6 },
  { id: "p16", name: "Sparkling Water", price: 2.80, category: "Cold Drinks", image: "https://images.unsplash.com/photo-1523362628745-0c100150b504?w=200&h=200&fit=crop", stock: 48 },
  { id: "p17", name: "Fresh OJ", price: 4.20, category: "Cold Drinks", image: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=200&h=200&fit=crop", stock: 22 },
  { id: "p18", name: "Iced Matcha", price: 5.20, category: "Cold Drinks", image: "https://images.unsplash.com/photo-1515823064-d6e0c04616a7?w=200&h=200&fit=crop", stock: 0 },
];

const categories = ["All", "Coffee", "Pastries", "Sandwiches", "Desserts", "Cold Drinks"];

const customers = [
  { name: "Walk-in Customer", email: "" },
  { name: "Sarah Chen", email: "sarah.chen@example.com" },
  { name: "Marcus Reyes", email: "marcus.reyes@example.com" },
  { name: "Elena Petrov", email: "elena.petrov@example.com" },
  { name: "James Okoro", email: "james.okoro@example.com" },
];

type CartItem = { product: Product; qty: number };

export default function POSPage() {
  const [activeCategory, setActiveCategory] = React.useState("All");
  const [search, setSearch] = React.useState("");
  const [cart, setCart] = React.useState<CartItem[]>([
    { product: products[0], qty: 1 },
    { product: products[4], qty: 2 },
    { product: products[8], qty: 1 },
  ]);
  const [customer, setCustomer] = React.useState("Walk-in Customer");
  const [discount, setDiscount] = React.useState(0);
  const [discountType, setDiscountType] = React.useState<"%" | "$">("%");
  const [receiptOpen, setReceiptOpen] = React.useState(false);
  const [lastSale, setLastSale] = React.useState<{ total: number; method: string; items: number; orderId: string; date: string } | null>(null);

  const filteredProducts = products.filter((p) => {
    if (activeCategory !== "All" && p.category !== activeCategory) return false;
    if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  function addToCart(p: Product) {
    if (p.stock === 0) {
      toast.error("Out of stock", { description: p.name });
      return;
    }
    setCart((prev) => {
      const existing = prev.find((c) => c.product.id === p.id);
      if (existing) return prev.map((c) => (c.product.id === p.id ? { ...c, qty: c.qty + 1 } : c));
      return [...prev, { product: p, qty: 1 }];
    });
  }

  function updateQty(id: string, delta: number) {
    setCart((prev) => prev
      .map((c) => (c.product.id === id ? { ...c, qty: c.qty + delta } : c))
      .filter((c) => c.qty > 0));
  }

  function removeFromCart(id: string) {
    setCart((prev) => prev.filter((c) => c.product.id !== id));
  }

  function clearCart() {
    setCart([]);
    setDiscount(0);
    toast.success("Cart cleared");
  }

  const subtotal = cart.reduce((s, c) => s + c.product.price * c.qty, 0);
  const discountAmount = discountType === "%" ? (subtotal * discount) / 100 : discount;
  const taxedAmount = Math.max(0, subtotal - discountAmount);
  const tax = taxedAmount * 0.0875;
  const total = taxedAmount + tax;

  function pay(method: string) {
    if (cart.length === 0) {
      toast.error("Cart is empty");
      return;
    }
    setLastSale({
      total,
      method,
      items: cart.reduce((s, c) => s + c.qty, 0),
      orderId: `ORD-${Math.floor(Math.random() * 9000) + 1000}`,
      date: new Date().toLocaleString(),
    });
    setReceiptOpen(true);
    toast.success("Payment processed", { description: `$${total.toFixed(2)} via ${method}` });
  }

  function completeSale() {
    setCart([]);
    setDiscount(0);
    setCustomer("Walk-in Customer");
    setReceiptOpen(false);
    toast.success("Sale completed");
  }

  return (
    <>
      <PageHeader
        title="Point of Sale"
        description="Process in-store orders quickly with the touch-enabled POS register."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "POS" }]}
        icon={ShoppingCart}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Register closed")}>
              <Receipt className="h-3.5 w-3.5" /> Close Register
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Shift opened")}>
              <User className="h-3.5 w-3.5" /> Cashier: Marcus R.
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-4">
        {/* LEFT — CATALOG */}
        <Card className="overflow-hidden">
          <CardContent className="p-0 flex flex-col h-[calc(100vh-220px)] min-h-[560px]">
            {/* Search + categories */}
            <div className="p-3 border-b space-y-3">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products or scan barcode..." className="h-10 pl-9 text-sm" />
              </div>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {categories.map((c) => (
                  <button
                    key={c}
                    onClick={() => setActiveCategory(c)}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors",
                      activeCategory === c
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:bg-muted/70"
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Product grid */}
            <ScrollArea className="flex-1">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 p-3">
                {filteredProducts.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => addToCart(p)}
                    disabled={p.stock === 0}
                    className={cn(
                      "group relative rounded-lg border border-border bg-card overflow-hidden text-left transition-all",
                      p.stock === 0 ? "opacity-50 cursor-not-allowed" : "hover:border-primary/40 hover:shadow-premium-sm active:scale-[0.98]"
                    )}
                  >
                    <div className="aspect-square bg-muted relative overflow-hidden">
                      <img src={p.image} alt={p.name} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                      {p.stock === 0 && (
                        <div className="absolute inset-0 grid place-items-center bg-background/80">
                          <span className="text-xs font-semibold text-destructive">Out of stock</span>
                        </div>
                      )}
                      {p.stock > 0 && p.stock < 10 && (
                        <Badge variant="outline" className="absolute top-1.5 left-1.5 text-[9px] bg-card/90 backdrop-blur">Only {p.stock} left</Badge>
                      )}
                      <div className="absolute top-1.5 right-1.5 grid place-items-center h-6 w-6 rounded-full bg-primary text-primary-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                        <Plus className="h-3.5 w-3.5" />
                      </div>
                    </div>
                    <div className="p-2">
                      <p className="text-xs font-medium truncate">{p.name}</p>
                      <p className="text-sm font-semibold tabular-nums mt-0.5">${p.price.toFixed(2)}</p>
                    </div>
                  </button>
                ))}
              </div>
              {filteredProducts.length === 0 && (
                <div className="py-16 text-center text-sm text-muted-foreground">No products found.</div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* RIGHT — CART & PAYMENT */}
        <Card className="overflow-hidden flex flex-col h-[calc(100vh-220px)] min-h-[560px]">
          <CardContent className="p-0 flex flex-col h-full">
            {/* Cart header */}
            <div className="flex items-center justify-between p-3 border-b">
              <div className="flex items-center gap-2">
                <ShoppingCart className="h-4 w-4 text-primary" />
                <span className="text-sm font-semibold">Current Order</span>
                <Badge variant="secondary" className="text-[10px] tabular-nums">{cart.reduce((s, c) => s + c.qty, 0)} items</Badge>
              </div>
              {cart.length > 0 && (
                <Button variant="ghost" size="sm" className="h-7 text-xs text-destructive hover:text-destructive gap-1" onClick={clearCart}>
                  <Trash2 className="h-3.5 w-3.5" /> Clear
                </Button>
              )}
            </div>

            {/* Customer */}
            <div className="p-3 border-b">
              <div className="flex items-center gap-2">
                <User className="h-3.5 w-3.5 text-muted-foreground" />
                <Select value={customer} onValueChange={setCustomer}>
                  <SelectTrigger className="h-8 text-xs flex-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {customers.map((c) => <SelectItem key={c.name} value={c.name} className="text-xs">{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Cart items */}
            <ScrollArea className="flex-1">
              <div className="p-3 space-y-2">
                {cart.length === 0 ? (
                  <div className="py-12 text-center">
                    <div className="grid place-items-center h-12 w-12 rounded-full bg-muted mx-auto mb-3">
                      <ShoppingCart className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <p className="text-sm font-medium">Cart is empty</p>
                    <p className="text-xs text-muted-foreground mt-1">Tap a product to add it to the order.</p>
                  </div>
                ) : cart.map((c) => (
                  <div key={c.product.id} className="flex items-center gap-3 rounded-lg border border-border p-2">
                    <img src={c.product.image} alt={c.product.name} className="h-12 w-12 rounded-md object-cover shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{c.product.name}</p>
                      <p className="text-xs text-muted-foreground tabular-nums">${c.product.price.toFixed(2)} each</p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQty(c.product.id, -1)}><Minus className="h-3 w-3" /></Button>
                      <span className="text-sm font-semibold tabular-nums w-6 text-center">{c.qty}</span>
                      <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => updateQty(c.product.id, 1)}><Plus className="h-3 w-3" /></Button>
                    </div>
                    <div className="text-right shrink-0 w-16">
                      <p className="text-sm font-semibold tabular-nums">${(c.product.price * c.qty).toFixed(2)}</p>
                      <button onClick={() => removeFromCart(c.product.id)} className="text-[10px] text-destructive hover:underline mt-0.5">Remove</button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Totals + payment */}
            {cart.length > 0 && (
              <div className="border-t bg-muted/20 p-3 space-y-3">
                {/* Discount */}
                <div className="flex items-center gap-2">
                  <Tag className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <Input
                    type="number"
                    value={discount || ""}
                    onChange={(e) => setDiscount(Number(e.target.value))}
                    placeholder="0"
                    className="h-8 text-sm w-20"
                  />
                  <Select value={discountType} onValueChange={(v) => setDiscountType(v as any)}>
                    <SelectTrigger className="h-8 text-xs w-20"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="%" className="text-xs">Percent %</SelectItem>
                      <SelectItem value="$" className="text-xs">Amount $</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="ghost" size="sm" className="h-8 text-xs ml-auto" onClick={() => setDiscount(0)}>Reset</Button>
                </div>

                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="tabular-nums font-medium">${subtotal.toFixed(2)}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-[color:var(--success)]">
                      <span>Discount {discountType === "%" ? `(${discount}%)` : ""}</span>
                      <span className="tabular-nums">−${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tax (8.75%)</span>
                    <span className="tabular-nums">${tax.toFixed(2)}</span>
                  </div>
                  <Separator className="my-1.5" />
                  <div className="flex justify-between items-baseline">
                    <span className="text-sm font-medium">Total</span>
                    <span className="text-xl font-bold tabular-nums">${total.toFixed(2)}</span>
                  </div>
                </div>

                {/* Payment buttons */}
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="h-14 flex-col gap-0.5" onClick={() => pay("Cash")}>
                    <Banknote className="h-4 w-4" />
                    <span className="text-[10px] font-medium">Cash</span>
                  </Button>
                  <Button variant="outline" className="h-14 flex-col gap-0.5" onClick={() => pay("Card")}>
                    <CreditCard className="h-4 w-4" />
                    <span className="text-[10px] font-medium">Card</span>
                  </Button>
                  <Button variant="outline" className="h-14 flex-col gap-0.5" onClick={() => pay("Wallet")}>
                    <Wallet className="h-4 w-4" />
                    <span className="text-[10px] font-medium">Wallet</span>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Receipt dialog */}
      <Dialog open={receiptOpen} onOpenChange={setReceiptOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <div className="grid place-items-center h-10 w-10 rounded-full bg-[color:var(--success)]/12 text-[color:var(--success)]">
                <Check className="h-5 w-5" />
              </div>
              <div>
                <DialogTitle>Payment Successful</DialogTitle>
                <p className="text-xs text-muted-foreground mt-0.5">Order #{lastSale?.orderId ?? "ORD-0000"}</p>
              </div>
            </div>
          </DialogHeader>
          {lastSale && (
            <div className="space-y-3">
              <div className="rounded-lg border border-dashed border-border p-4 font-mono text-xs space-y-2">
                <div className="text-center">
                  <p className="font-semibold">NexusGrid Coffee Co.</p>
                  <p className="text-[10px] text-muted-foreground">123 Market Street · San Francisco</p>
                  <p className="text-[10px] text-muted-foreground">+1 (415) 555-0142</p>
                </div>
                <Separator />
                <div className="flex justify-between"><span>Date</span><span>{lastSale.date}</span></div>
                <div className="flex justify-between"><span>Cashier</span><span>Marcus R.</span></div>
                <div className="flex justify-between"><span>Customer</span><span>{customer}</span></div>
                <Separator />
                <div className="space-y-1">
                  {cart.map((c) => (
                    <div key={c.product.id} className="flex justify-between">
                      <span>{c.qty}× {c.product.name}</span>
                      <span>${(c.product.price * c.qty).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                <Separator />
                <div className="flex justify-between"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
                {discountAmount > 0 && <div className="flex justify-between text-[color:var(--success)]"><span>Discount</span><span>−${discountAmount.toFixed(2)}</span></div>}
                <div className="flex justify-between"><span>Tax</span><span>${tax.toFixed(2)}</span></div>
                <Separator />
                <div className="flex justify-between font-bold text-sm"><span>TOTAL</span><span>${lastSale.total.toFixed(2)}</span></div>
                <Separator />
                <div className="flex justify-between"><span>Payment</span><span>{lastSale.method}</span></div>
                <div className="text-center pt-2 text-[10px] text-muted-foreground">Thank you for your purchase!</div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => toast.success("Receipt emailed")}><Receipt className="h-3.5 w-3.5" /> Email Receipt</Button>
            <Button size="sm" className="gap-1.5 flex-1" onClick={completeSale}>
              <Check className="h-3.5 w-3.5" /> New Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}


