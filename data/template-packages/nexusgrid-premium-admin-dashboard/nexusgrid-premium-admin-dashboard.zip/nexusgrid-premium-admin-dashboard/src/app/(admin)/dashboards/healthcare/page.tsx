"use client";

import * as React from "react";
import {
  HeartPulse,
  CalendarCheck,
  Users,
  BedDouble,
  Clock,
  Stethoscope,
  Activity,
  Microscope,
  Video,
  User,
  Filter,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BarTrendChart, RadialProgress } from "@/components/charts";
import { patientFlow } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline healthcare data ---------- */

// Ward breakdown for bed occupancy — counts add up sensibly against 78% overall.
const wards = [
  { name: "ICU",         occupied: 18, capacity: 20, tone: "danger"  as StatusTone, color: "var(--destructive)" },
  { name: "Emergency",   occupied: 22, capacity: 28, tone: "warning" as StatusTone, color: "var(--warning)"     },
  { name: "General",     occupied: 96, capacity: 120, tone: "info"   as StatusTone, color: "var(--info)"        },
  { name: "Maternity",   occupied: 14, capacity: 20, tone: "success" as StatusTone, color: "var(--success)"     },
];

// Today's appointments — 6 entries. Distinct from order/deal tables.
type ApptType = "in-person" | "telehealth";
type ApptStatus = "confirmed" | "checked-in" | "waiting" | "completed" | "cancelled";
const appointments: Array<{
  patient: string; avatar: string; doctor: string; dept: string; deptTone: StatusTone;
  time: string; status: ApptStatus; type: ApptType;
}> = [
  { patient: "Eleanor Hayes",   avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", doctor: "Dr. Sarah Chen",   dept: "Cardiology", deptTone: "danger",  time: "09:00", status: "checked-in", type: "in-person"  },
  { patient: "Marcus Whitfield",avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", doctor: "Dr. James Okoro",  dept: "Neurology",  deptTone: "violet",  time: "09:30", status: "confirmed",  type: "telehealth"  },
  { patient: "Priya Raman",     avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", doctor: "Dr. Aiko Tanaka",  dept: "Pediatrics", deptTone: "info",    time: "10:15", status: "waiting",    type: "in-person"  },
  { patient: "David Okafor",    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", doctor: "Dr. Elena Petrov", dept: "Orthopedics",deptTone: "warning", time: "11:00", status: "completed",  type: "in-person"  },
  { patient: "Lena Hoffmann",   avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", doctor: "Dr. Sarah Chen",   dept: "Cardiology", deptTone: "danger",  time: "13:30", status: "confirmed",  type: "telehealth"  },
  { patient: "Hugo Martinez",   avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", doctor: "Dr. Marcus Reyes", dept: "General",    deptTone: "primary", time: "14:45", status: "cancelled",  type: "in-person"  },
];

const apptStatusTone: Record<ApptStatus, StatusTone> = {
  "confirmed":   "info",
  "checked-in":  "primary",
  "waiting":     "warning",
  "completed":   "success",
  "cancelled":   "danger",
};

// Department load — 5 entries with current load %.
const departments = [
  { name: "Cardiology",  load: 92, doctors: 8, tone: "danger"  as StatusTone },
  { name: "Emergency",   load: 88, doctors: 12, tone: "warning" as StatusTone },
  { name: "Pediatrics",  load: 64, doctors: 6, tone: "info"    as StatusTone },
  { name: "Neurology",   load: 56, doctors: 5, tone: "violet"  as StatusTone },
  { name: "Orthopedics", load: 42, doctors: 4, tone: "success" as StatusTone },
];

// Recent lab results — 5 entries.
type LabResult = "normal" | "abnormal" | "critical";
const labResults: Array<{
  patient: string; test: string; result: LabResult; value: string; time: string;
}> = [
  { patient: "Eleanor Hayes",   test: "Complete Blood Count",  result: "normal",   value: "WBC 7.2",  time: "10 min ago" },
  { patient: "Marcus Whitfield",test: "Lipid Panel",           result: "abnormal", value: "LDL 162",  time: "32 min ago" },
  { patient: "Priya Raman",     test: "Glucose (Fasting)",     result: "normal",   value: "92 mg/dL", time: "1 hr ago"   },
  { patient: "David Okafor",    test: "Troponin I",            result: "critical", value: "0.84 ng/mL", time: "2 hr ago" },
  { patient: "Lena Hoffmann",   test: "Thyroid Panel (TSH)",   result: "abnormal", value: "5.8 mIU/L", time: "3 hr ago"  },
];

const labTone: Record<LabResult, StatusTone> = { normal: "success", abnormal: "warning", critical: "danger" };

/* ---------- Healthcare KPI card — clinical / vital-signs feel ---------- */
// Distinct from all prior KPI cards:
// - Top ECG-style pulse line decoration (a literal SVG heartbeat line)
// - Calm clinical palette (teal / emerald / sky / cyan)
// - Mini vital-signs bar strip below the value instead of sparkline/quota/sprint
// - "vital reading" subline (e.g. "312 admitted this week") and trend pill

function VitalCard({
  label,
  value,
  unit,
  icon: Icon,
  accent,
  trend,
  trendLabel,
  vitalBars,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  accent: "teal" | "emerald" | "sky" | "cyan";
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  trendLabel: string;
  vitalBars: number[];
}) {
  // Static accent maps so Tailwind v4 can detect them
  const accentStroke: Record<string, string> = {
    teal:    "stroke-teal-500",
    emerald: "stroke-emerald-500",
    sky:     "stroke-sky-500",
    cyan:    "stroke-cyan-500",
  };
  const accentTile: Record<string, string> = {
    teal:    "bg-teal-500/12 text-teal-600 dark:text-teal-400",
    emerald: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400",
    sky:     "bg-sky-500/12 text-sky-600 dark:text-sky-400",
    cyan:    "bg-cyan-500/12 text-cyan-600 dark:text-cyan-400",
  };
  const accentBar: Record<string, string> = {
    teal:    "bg-teal-500",
    emerald: "bg-emerald-500",
    sky:     "bg-sky-500",
    cyan:    "bg-cyan-500",
  };
  const accentText: Record<string, string> = {
    teal:    "text-teal-600 dark:text-teal-400",
    emerald: "text-emerald-600 dark:text-emerald-400",
    sky:     "text-sky-600 dark:text-sky-400",
    cyan:    "text-cyan-600 dark:text-cyan-400",
  };

  const isUp = trend.direction === "up";
  const max = Math.max(...vitalBars);
  const min = Math.min(...vitalBars);
  const range = max - min || 1;

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card transition-all hover:shadow-premium-sm">
      {/* Top ECG / pulse line decoration — distinct from HR's gradient strip, logistics' route line */}
      <svg
        viewBox="0 0 200 14"
        preserveAspectRatio="none"
        className="absolute inset-x-0 top-0 h-3 w-full opacity-50"
        aria-hidden
      >
        <path
          d="M0 7 L40 7 L48 7 L54 2 L62 12 L70 7 L92 7 L100 7 L108 4 L116 10 L124 7 L160 7 L168 7 L176 1 L184 13 L192 7 L200 7"
          fill="none"
          strokeWidth="1.5"
          className={accentStroke[accent]}
        />
      </svg>

      <div className="p-5 pt-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
              {label}
            </p>
            <div className="mt-1.5 flex items-baseline gap-1">
              <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
              {unit && <span className="text-sm font-semibold text-muted-foreground tabular-nums">{unit}</span>}
            </div>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentTile[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>

        {/* Mini vital-signs bar strip — distinct from sparkline / quota bar / sprint strip / HR bar trend */}
        <div className="mt-3 flex items-end gap-[3px] h-7" aria-hidden>
          {vitalBars.map((v, i) => {
            const h = ((v - min) / range) * 100;
            const opacity = 0.30 + (i / (vitalBars.length - 1)) * 0.70;
            return (
              <div
                key={i}
                className={cn("flex-1 rounded-sm transition-all", accentBar[accent])}
                style={{ height: `${Math.max(8, h)}%`, opacity }}
              />
            );
          })}
        </div>

        {/* Trend pill + caption */}
        <div className="mt-3 flex items-center gap-1.5">
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
              trend.positive
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {Math.abs(trend.value)}%
          </span>
          <span className={cn("text-xs font-medium truncate", accentText[accent])}>{trendLabel}</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function HealthcareDashboardPage() {
  const totalAdmissions = patientFlow.reduce((s, x) => s + x.admissions, 0);
  const totalDischarges = patientFlow.reduce((s, x) => s + x.discharges, 0);
  const totalBeds = wards.reduce((s, w) => s + w.capacity, 0);
  const totalOccupied = wards.reduce((s, w) => s + w.occupied, 0);

  return (
    <>
      <PageHeader
        title="Healthcare Dashboard"
        description="Patient flow, bed occupancy, and clinical operations across your facility."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Healthcare" }]}
        icon={HeartPulse}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Today
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5 bg-teal-600 text-white hover:bg-teal-600/90">
              <Plus className="h-3.5 w-3.5" /> New appointment
            </Button>
          </>
        }
      />

      {/* KPI Row — VitalCard with ECG pulse line + clinical palette */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <VitalCard
          label="Appointments Today"
          value="142"
          icon={CalendarCheck}
          accent="teal"
          trend={{ value: 8, direction: "up", positive: true }}
          trendLabel="vs. yesterday"
          vitalBars={[8, 12, 10, 14, 18, 16, 20, 22, 19]}
        />
        <VitalCard
          label="Active Patients"
          value="8,420"
          icon={Users}
          accent="emerald"
          trend={{ value: 4.2, direction: "up", positive: true }}
          trendLabel="312 admitted this week"
          vitalBars={[120, 140, 135, 160, 175, 168, 190, 205, 220]}
        />
        <VitalCard
          label="Bed Occupancy"
          value="78"
          unit="%"
          icon={BedDouble}
          accent="sky"
          trend={{ value: 2.4, direction: "up", positive: true }}
          trendLabel="150 of 192 beds in use"
          vitalBars={[60, 65, 70, 68, 72, 75, 74, 76, 78]}
        />
        <VitalCard
          label="Avg Wait Time"
          value="24"
          unit="min"
          icon={Clock}
          accent="cyan"
          trend={{ value: 3.1, direction: "down", positive: true }}
          trendLabel="3 min faster vs. avg"
          vitalBars={[34, 32, 30, 28, 29, 27, 26, 25, 24]}
        />
      </div>

      {/* Patient flow + Bed occupancy */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="h-4 w-4 text-teal-600 dark:text-teal-400" />
                Patient Flow
              </CardTitle>
              <CardDescription>
                Hourly admissions vs. discharges · {totalAdmissions + totalDischarges} total movements today.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-teal-500" /> Admissions
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-500" /> Discharges
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={patientFlow}
              xKey="hour"
              series={[
                { key: "admissions", name: "Admissions", color: "oklch(0.68 0.13 195)" },
                { key: "discharges", name: "Discharges", color: "oklch(0.70 0.15 160)" },
              ]}
              height={300}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Admissions</p>
                <p className="text-sm font-semibold text-teal-600 dark:text-teal-400 tabular-nums mt-0.5">{totalAdmissions}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Discharges</p>
                <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">{totalDischarges}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Net Change</p>
                <p className={cn(
                  "text-sm font-semibold tabular-nums mt-0.5",
                  totalAdmissions - totalDischarges >= 0 ? "text-teal-600 dark:text-teal-400" : "text-emerald-600 dark:text-emerald-400"
                )}>
                  {totalAdmissions - totalDischarges > 0 ? "+" : ""}{totalAdmissions - totalDischarges}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bed occupancy radial + ward breakdown */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <BedDouble className="h-4 w-4 text-sky-600 dark:text-sky-400" />
              Bed Occupancy
            </CardTitle>
            <CardDescription>{totalOccupied} of {totalBeds} beds in use across 4 wards.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center mb-2">
              <RadialProgress
                value={78}
                size={150}
                color="oklch(0.68 0.13 230)"
                label="Occupied"
                sublabel="of capacity"
              />
            </div>
            <div className="space-y-2 pt-3 border-t border-border">
              {wards.map((w) => {
                const pct = Math.round((w.occupied / w.capacity) * 100);
                return (
                  <div key={w.name} className="flex items-center gap-3">
                    <span className="text-xs font-medium text-foreground w-20 shrink-0">{w.name}</span>
                    <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700 ease-out"
                        style={{ width: `${pct}%`, background: w.color }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground tabular-nums w-12 text-right shrink-0">
                      {w.occupied}/{w.capacity}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's appointments table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Stethoscope className="h-4 w-4 text-teal-600 dark:text-teal-400" />
              Today&apos;s Appointments
            </CardTitle>
            <CardDescription>Scheduled visits across all departments.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            View schedule <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Patient</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Doctor</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Department</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Time</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Type</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {appointments.map((a, i) => (
                  <tr key={i} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar className="h-9 w-9 shrink-0">
                          <AvatarImage src={a.avatar} alt={a.patient} />
                          <AvatarFallback className="text-[10px]">
                            {a.patient.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="font-medium text-foreground truncate">{a.patient}</p>
                          <p className="text-xs text-muted-foreground sm:hidden truncate">{a.doctor}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className="text-sm text-foreground">{a.doctor}</span>
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge tone={a.deptTone} dot>{a.dept}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-medium text-foreground">{a.time}</td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={apptStatusTone[a.status]} className="capitalize">{a.status}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-center hidden md:table-cell">
                      <span
                        className={cn(
                          "inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset",
                          a.type === "telehealth"
                            ? "bg-violet-500/10 text-violet-600 dark:text-violet-400 ring-violet-500/20"
                            : "bg-muted text-muted-foreground ring-border"
                        )}
                      >
                        {a.type === "telehealth" ? <Video className="h-3 w-3" /> : <User className="h-3 w-3" />}
                        <span className="capitalize">{a.type}</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Department load + Recent lab results */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="h-4 w-4 text-teal-600 dark:text-teal-400" />
                Department Load
              </CardTitle>
              <CardDescription>Current patient load by department.</CardDescription>
            </div>
            <StatusBadge tone="info" dot>Live</StatusBadge>
          </CardHeader>
          <CardContent className="space-y-4">
            {departments.map((d) => (
              <div key={d.name} className="group">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-sm font-medium text-foreground truncate">{d.name}</span>
                    <span className="text-xs text-muted-foreground shrink-0">{d.doctors} doctors</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-semibold tabular-nums"
                      style={{ color: d.load >= 85 ? "var(--destructive)" : d.load >= 70 ? "var(--warning)" : "var(--success)" }}
                    >
                      {d.load}%
                    </span>
                  </div>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-700 ease-out",
                      d.tone === "danger"  && "bg-[color:var(--destructive)]",
                      d.tone === "warning" && "bg-[color:var(--warning)]",
                      d.tone === "info"    && "bg-[color:var(--info)]",
                      d.tone === "violet"  && "bg-violet-500",
                      d.tone === "success" && "bg-[color:var(--success)]"
                    )}
                    style={{ width: `${d.load}%` }}
                  />
                </div>
              </div>
            ))}
            <div className="pt-3 mt-2 border-t border-border flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Overall load</span>
              <span className="font-semibold text-teal-600 dark:text-teal-400 tabular-nums">
                {Math.round(departments.reduce((s, x) => s + x.load, 0) / departments.length)}%
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Microscope className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                Recent Lab Results
              </CardTitle>
              <CardDescription>Latest processed tests with result flags.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              All results <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Patient</th>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Test</th>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Result</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {labResults.map((r, i) => (
                    <tr key={i} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="min-w-0">
                          <p className="font-medium text-foreground truncate">{r.patient}</p>
                          <p className="text-xs text-muted-foreground sm:hidden truncate">{r.test}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden sm:table-cell">
                        <p className="text-sm text-foreground">{r.test}</p>
                        <p className="text-xs text-muted-foreground tabular-nums">{r.value}</p>
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge tone={labTone[r.result]} dot className="capitalize">{r.result}</StatusBadge>
                      </td>
                      <td className="px-4 py-3 text-right text-xs text-muted-foreground tabular-nums hidden md:table-cell">
                        {r.time}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
