"use client";

import * as React from "react";
import {
  Webhook,
  Plus,
  Copy,
  Trash2,
  Send,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Activity,
  Eye,
  EyeOff,
  RefreshCw,
  Zap,
  MoreHorizontal,
  Shield,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Webhook_ = {
  id: string;
  url: string;
  events: string[];
  secretMasked: string;
  lastDelivery: string;
  lastStatus: number;
  status: "active" | "paused" | "failing";
  successRate: number;
  totalDelivered: number;
};

const WEBHOOKS: Webhook_[] = [
  { id: "wh1", url: "https://hooks.nexusgrid.io/slack/notify", events: ["order.created", "order.refunded", "incident.sev1"], secretMasked: "whsec_••••••8f2a", lastDelivery: "2 min ago", lastStatus: 200, status: "active", successRate: 99.8, totalDelivered: 18420 },
  { id: "wh2", url: "https://api.zapier.com/hooks/catch/8429/nexusgrid", events: ["customer.created", "customer.updated"], secretMasked: "whsec_••••••a1b9", lastDelivery: "12 min ago", lastStatus: 200, status: "active", successRate: 100, totalDelivered: 4280 },
  { id: "wh3", url: "https://internal.acme.corp/webhooks/orders", events: ["order.created", "order.shipped", "order.delivered"], secretMasked: "whsec_••••••c3d7", lastDelivery: "1 hour ago", lastStatus: 500, status: "failing", successRate: 87.2, totalDelivered: 92840 },
  { id: "wh4", url: "https://make.com/webhook/9182734", events: ["invoice.paid", "invoice.failed"], secretMasked: "whsec_••••••e5f2", lastDelivery: "Yesterday", lastStatus: 200, status: "active", successRate: 99.4, totalDelivered: 14200 },
  { id: "wh5", url: "https://legacy.crm.example.com/hook", events: ["customer.deleted"], secretMasked: "whsec_••••••g7h8", lastDelivery: "4 days ago", lastStatus: 0, status: "paused", successRate: 0, totalDelivered: 0 },
];

type Delivery = {
  id: string;
  webhookId: string;
  webhookUrl: string;
  event: string;
  status: number;
  duration: number;
  attempt: number;
  time: string;
};

const DELIVERIES: Delivery[] = [
  { id: "d1", webhookId: "wh1", webhookUrl: "hooks.nexusgrid.io/slack/notify", event: "order.created", status: 200, duration: 142, attempt: 1, time: "10:42:18 AM" },
  { id: "d2", webhookId: "wh3", webhookUrl: "internal.acme.corp/webhooks/orders", event: "order.shipped", status: 500, duration: 5024, attempt: 3, time: "10:38:04 AM" },
  { id: "d3", webhookId: "wh2", webhookUrl: "api.zapier.com/hooks/catch/8429", event: "customer.created", status: 200, duration: 284, attempt: 1, time: "10:24:51 AM" },
  { id: "d4", webhookId: "wh1", webhookUrl: "hooks.nexusgrid.io/slack/notify", event: "incident.sev1", status: 200, duration: 96, attempt: 1, time: "10:18:33 AM" },
  { id: "d5", webhookId: "wh4", webhookUrl: "make.com/webhook/9182734", event: "invoice.paid", status: 200, duration: 318, attempt: 1, time: "09:54:12 AM" },
  { id: "d6", webhookId: "wh3", webhookUrl: "internal.acme.corp/webhooks/orders", event: "order.created", status: 503, duration: 4012, attempt: 2, time: "09:42:08 AM" },
  { id: "d7", webhookId: "wh2", webhookUrl: "api.zapier.com/hooks/catch/8429", event: "customer.updated", status: 200, duration: 198, attempt: 1, time: "09:21:45 AM" },
  { id: "d8", webhookId: "wh1", webhookUrl: "hooks.nexusgrid.io/slack/notify", event: "order.refunded", status: 200, duration: 124, attempt: 1, time: "08:58:22 AM" },
  { id: "d9", webhookId: "wh3", webhookUrl: "internal.acme.corp/webhooks/orders", event: "order.delivered", status: 408, duration: 10000, attempt: 3, time: "08:42:11 AM" },
  { id: "d10", webhookId: "wh4", webhookUrl: "make.com/webhook/9182734", event: "invoice.failed", status: 422, duration: 142, attempt: 1, time: "08:30:09 AM" },
];

const ALL_EVENTS = [
  "order.created", "order.updated", "order.shipped", "order.delivered", "order.refunded", "order.cancelled",
  "customer.created", "customer.updated", "customer.deleted",
  "invoice.paid", "invoice.failed", "invoice.created",
  "incident.sev1", "incident.sev2", "incident.resolved",
  "user.invited", "user.removed", "role.changed",
];

const statusTone = (code: number): "success" | "warning" | "danger" => {
  if (code === 0) return "neutral" as any;
  if (code >= 200 && code < 300) return "success";
  if (code >= 400 && code < 500) return "warning";
  return "danger";
};

const whStatusTone: Record<Webhook_["status"], "success" | "warning" | "danger"> = {
  active: "success",
  paused: "warning",
  failing: "danger",
};

export default function WebhooksPage() {
  const [revealed, setRevealed] = React.useState<Set<string>>(new Set());
  const [createOpen, setCreateOpen] = React.useState(false);
  const [newUrl, setNewUrl] = React.useState("");
  const [newEvents, setNewEvents] = React.useState<Set<string>>(new Set(["order.created"]));
  const [filterWh, setFilterWh] = React.useState("all");

  const toggleReveal = (id: string) =>
    setRevealed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const toggleEvent = (e: string) =>
    setNewEvents((prev) => {
      const next = new Set(prev);
      if (next.has(e)) next.delete(e);
      else next.add(e);
      return next;
    });

  const filteredDeliveries = filterWh === "all" ? DELIVERIES : DELIVERIES.filter((d) => d.webhookId === filterWh);

  return (
    <>
      <PageHeader
        title="Webhooks"
        description="Outbound HTTP notifications when events happen. Subscribe, test, and monitor every delivery."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Webhooks" }]}
        icon={Webhook}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setCreateOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> Add webhook
          </Button>
        }
      />

      {/* SUMMARY STRIP */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { icon: Webhook, tone: "bg-primary/12 text-primary", label: "Endpoints", value: String(WEBHOOKS.length), hint: `${WEBHOOKS.filter((w) => w.status === "active").length} active` },
          { icon: Send, tone: "bg-[color:var(--info)]/12 text-[color:var(--info)]", label: "Deliveries (24h)", value: "1,284", hint: "Across all endpoints" },
          { icon: CheckCircle2, tone: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Success rate", value: "97.4%", hint: "Last 24 hours" },
          { icon: AlertTriangle, tone: "bg-destructive/12 text-destructive", label: "Failing", value: String(WEBHOOKS.filter((w) => w.status === "failing").length), hint: "Needs attention" },
        ].map((s) => (
          <Card key={s.label} className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("grid place-items-center h-7 w-7 rounded-md", s.tone)}><s.icon className="h-3.5 w-3.5" /></div>
              <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</span>
            </div>
            <p className="text-xl font-semibold tabular-nums leading-tight">{s.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.hint}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* WEBHOOKS LIST */}
        <div className="xl:col-span-2 space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Endpoints</CardTitle>
              <CardDescription>{WEBHOOKS.length} webhook endpoints configured.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {WEBHOOKS.map((w) => (
                  <div key={w.id} className="p-4 hover:bg-muted/30 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className={cn("grid place-items-center h-10 w-10 rounded-lg shrink-0",
                        w.status === "active" ? "bg-primary/12 text-primary" :
                        w.status === "failing" ? "bg-destructive/12 text-destructive" :
                        "bg-[color:var(--warning)]/15 text-[color:var(--warning)]"
                      )}>
                        <Webhook className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <code className="font-mono text-sm font-medium truncate max-w-full">{w.url}</code>
                          <StatusBadge tone={whStatusTone[w.status]} dot>{w.status}</StatusBadge>
                        </div>

                        {/* Events */}
                        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                          {w.events.map((e) => (
                            <code key={e} className="font-mono text-[10px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground">{e}</code>
                          ))}
                          {w.events.length === 0 && <span className="text-[10px] text-muted-foreground italic">No events subscribed</span>}
                        </div>

                        {/* Secret */}
                        <div className="flex items-center gap-2 mt-2.5">
                          <Shield className="h-3 w-3 text-muted-foreground shrink-0" />
                          <code className="font-mono text-[11px] text-muted-foreground flex-1 min-w-0 truncate">
                            {revealed.has(w.id) ? `whsec_${w.id}_8f2a9c1b3d7e5f2a${w.id}` : w.secretMasked}
                          </code>
                          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => toggleReveal(w.id)}>
                            {revealed.has(w.id) ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                          </Button>
                          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => { navigator.clipboard?.writeText(w.secretMasked); toast.success("Secret copied"); }}>
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>

                        {/* Meta */}
                        <div className="flex items-center gap-4 mt-2.5 text-[11px] text-muted-foreground flex-wrap">
                          <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" /> Last: {w.lastDelivery}</span>
                          <span className="inline-flex items-center gap-1">
                            <Activity className="h-3 w-3" />
                            {w.lastStatus === 0 ? "No response" : <span className={cn("font-mono font-medium", w.lastStatus >= 200 && w.lastStatus < 300 ? "text-[color:var(--success)]" : "text-destructive")}>HTTP {w.lastStatus}</span>}
                          </span>
                          <span className="inline-flex items-center gap-1"><Send className="h-3 w-3" /> <span className="tabular-nums font-mono">{w.totalDelivered.toLocaleString()}</span> delivered</span>
                          <span className="inline-flex items-center gap-1">
                            <CheckCircle2 className="h-3 w-3" />
                            <span className={cn("tabular-nums font-medium", w.successRate >= 99 ? "text-[color:var(--success)]" : w.successRate >= 90 ? "text-[color:var(--warning)]" : "text-destructive")}>{w.successRate}%</span>
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={() => toast.success("Test event sent", { description: `Ping delivered to ${new URL(w.url).hostname}.` })}>
                          <Send className="h-3 w-3" /> Test
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message("Editing webhook")}>
                              <RefreshCw className="h-3.5 w-3.5" /> Rotate secret
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message("View delivery log")}>
                              <Activity className="h-3.5 w-3.5" /> Delivery log
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(w.status === "paused" ? "Webhook resumed" : "Webhook paused")}>
                              <Zap className="h-3.5 w-3.5" /> {w.status === "paused" ? "Resume" : "Pause"}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onSelect={(e) => e.preventDefault()}>
                                  <Trash2 className="h-3.5 w-3.5" /> Delete
                                </DropdownMenuItem>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete this webhook?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    The endpoint at <span className="font-mono text-foreground">{w.url}</span> will stop receiving events immediately. Existing delivery logs are retained for 30 days.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => toast.success("Webhook deleted")}>
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* RECENT DELIVERIES */}
        <div className="xl:col-span-1">
          <Card className="xl:sticky xl:top-4">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" /> Recent deliveries
                </CardTitle>
                <Badge variant="outline" className="text-[10px]">{filteredDeliveries.length}</Badge>
              </div>
              <select
                value={filterWh}
                onChange={(e) => setFilterWh(e.target.value)}
                className="w-full h-8 rounded-md border border-input bg-background px-2 text-xs"
              >
                <option value="all">All endpoints</option>
                {WEBHOOKS.map((w) => (
                  <option key={w.id} value={w.id}>{new URL(w.url).hostname}</option>
                ))}
              </select>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-[640px] overflow-y-auto divide-y divide-border">
                {filteredDeliveries.map((d) => {
                  const tone = statusTone(d.status);
                  return (
                    <div key={d.id} className="p-3 hover:bg-muted/30 transition-colors cursor-pointer">
                      <div className="flex items-start gap-2.5">
                        <div className={cn("grid place-items-center h-7 w-7 rounded-md shrink-0 mt-0.5",
                          tone === "success" ? "bg-[color:var(--success)]/12 text-[color:var(--success)]" :
                          tone === "warning" ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" :
                          "bg-destructive/12 text-destructive"
                        )}>
                          {tone === "success" ? <CheckCircle2 className="h-3.5 w-3.5" /> : tone === "warning" ? <AlertTriangle className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <code className="font-mono text-[11px] font-medium truncate">{d.event}</code>
                            <span className={cn("font-mono text-[10px] font-semibold shrink-0",
                              tone === "success" ? "text-[color:var(--success)]" : tone === "warning" ? "text-[color:var(--warning)]" : "text-destructive"
                            )}>{d.status === 0 ? "—" : d.status}</span>
                          </div>
                          <p className="text-[10px] text-muted-foreground truncate font-mono mt-0.5">{d.webhookUrl}</p>
                          <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                            <span>{d.time}</span>
                            <span>·</span>
                            <span className="font-mono">{d.duration}ms</span>
                            {d.attempt > 1 && (
                              <>
                                <span>·</span>
                                <span className="text-[color:var(--warning)]">attempt {d.attempt}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="p-2 border-t border-border">
                <Button variant="ghost" size="sm" className="w-full text-xs gap-1">View full delivery log <ChevronRight className="h-3 w-3" /></Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CREATE WEBHOOK DIALOG */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Add webhook endpoint</DialogTitle>
            <DialogDescription>We'll POST a signed JSON payload to this URL when subscribed events fire.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-xs">Endpoint URL</Label>
              <Input type="url" placeholder="https://your-service.com/webhooks/nexusgrid" value={newUrl} onChange={(e) => setNewUrl(e.target.value)} />
              <p className="text-[11px] text-muted-foreground">Must be HTTPS. We'll sign each request with HMAC-SHA256.</p>
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">Events to subscribe</Label>
              <div className="max-h-56 overflow-y-auto rounded-lg border border-border p-2 grid grid-cols-2 gap-1">
                {ALL_EVENTS.map((e) => (
                  <label key={e} className="flex items-center gap-2 p-1.5 rounded hover:bg-muted/40 cursor-pointer">
                    <Switch checked={newEvents.has(e)} onCheckedChange={() => toggleEvent(e)} />
                    <code className="font-mono text-[11px] truncate">{e}</code>
                  </label>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground">{newEvents.size} event{newEvents.size === 1 ? "" : "s"} selected.</p>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="min-w-0">
                <p className="text-sm font-medium">Auto-retry failed deliveries</p>
                <p className="text-xs text-muted-foreground">Exponential backoff · up to 3 attempts over 24h.</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button className="gap-1.5" onClick={() => {
              if (!newUrl) { toast.error("URL required"); return; }
              if (newEvents.size === 0) { toast.error("Select at least one event"); return; }
              setCreateOpen(false);
              setNewUrl("");
              setNewEvents(new Set(["order.created"]));
              toast.success("Webhook added", { description: "A test ping is on its way to your endpoint." });
            }}>
              <Plus className="h-3.5 w-3.5" /> Create webhook
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
