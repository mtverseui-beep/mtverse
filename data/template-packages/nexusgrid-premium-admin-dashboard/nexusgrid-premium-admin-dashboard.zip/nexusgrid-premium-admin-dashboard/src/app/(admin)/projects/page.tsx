"use client";

import * as React from "react";
import {
  FolderKanban,
  Plus,
  LayoutGrid,
  Table2,
  GanttChart,
  Download,
  MoreHorizontal,
  Eye,
  Pencil,
  Archive,
  Calendar,
  Users,
  ArrowUpRight,
  ArrowDownRight,
  Flag,
  TrendingUp,
  CircleDollarSign,
  CheckCircle2,
  AlertTriangle,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & inline data ---------- */

type ProjectStatus = "on-track" | "at-risk" | "delayed" | "completed" | "planning";
type Priority = "low" | "medium" | "high" | "critical";

type TeamMember = { name: string; avatar: string };
type Project = {
  id: string;
  name: string;
  client: string;
  ownerId: string;
  owner: string;
  ownerAvatar: string;
  progress: number;
  due: string;
  status: ProjectStatus;
  priority: Priority;
  budget: number;
  spent: number;
  team: TeamMember[];
  phase: string;
  startDate: string;
  // timeline phase positions (in % of a year, used in timeline view)
  phases: { name: string; start: number; end: number; done: boolean }[];
};

const teamPool: TeamMember[] = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop" },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop" },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop" },
  { name: "David Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
  { name: "Priya Sharma", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop" },
];

const projects: Project[] = [
  {
    id: "PRJ-014",
    name: "Atlas Mobile Redesign",
    client: "Globex Corp",
    ownerId: "u1",
    owner: "Sarah Chen",
    ownerAvatar: teamPool[0].avatar,
    progress: 78,
    due: "Jul 14, 2026",
    startDate: "Apr 02, 2026",
    status: "on-track",
    priority: "high",
    budget: 284000,
    spent: 218400,
    team: [teamPool[0], teamPool[1], teamPool[2], teamPool[3]],
    phase: "Development",
    phases: [
      { name: "Discovery", start: 25, end: 30, done: true },
      { name: "Design", start: 30, end: 38, done: true },
      { name: "Dev", start: 38, end: 52, done: false },
      { name: "QA", start: 52, end: 56, done: false },
    ],
  },
  {
    id: "PRJ-013",
    name: "Pulse Analytics Platform",
    client: "Initech",
    ownerId: "u2",
    owner: "Marcus Reyes",
    ownerAvatar: teamPool[1].avatar,
    progress: 42,
    due: "Aug 02, 2026",
    startDate: "May 12, 2026",
    status: "at-risk",
    priority: "medium",
    budget: 196000,
    spent: 94300,
    team: [teamPool[1], teamPool[4], teamPool[5]],
    phase: "Design",
    phases: [
      { name: "Discovery", start: 35, end: 42, done: true },
      { name: "Design", start: 42, end: 55, done: false },
      { name: "Dev", start: 55, end: 70, done: false },
    ],
  },
  {
    id: "PRJ-012",
    name: "Vertex Payment Gateway",
    client: "Hooli",
    ownerId: "u3",
    owner: "Elena Petrov",
    ownerAvatar: teamPool[2].avatar,
    progress: 28,
    due: "Sep 10, 2026",
    startDate: "Jun 18, 2026",
    status: "delayed",
    priority: "critical",
    budget: 348000,
    spent: 89200,
    team: [teamPool[2], teamPool[3], teamPool[5], teamPool[6]],
    phase: "Discovery",
    phases: [
      { name: "Discovery", start: 45, end: 55, done: false },
      { name: "Design", start: 55, end: 65, done: false },
      { name: "Dev", start: 65, end: 80, done: false },
      { name: "Audit", start: 80, end: 86, done: false },
    ],
  },
  {
    id: "PRJ-011",
    name: "Nimbus Cloud Migration",
    client: "Acme Corp",
    ownerId: "u4",
    owner: "James Okoro",
    ownerAvatar: teamPool[3].avatar,
    progress: 92,
    due: "Jul 08, 2026",
    startDate: "Mar 01, 2026",
    status: "on-track",
    priority: "high",
    budget: 412000,
    spent: 387800,
    team: [teamPool[3], teamPool[0], teamPool[4]],
    phase: "Cutover",
    phases: [
      { name: "Plan", start: 18, end: 24, done: true },
      { name: "Migrate", start: 24, end: 48, done: true },
      { name: "Test", start: 48, end: 54, done: false },
      { name: "Cutover", start: 54, end: 56, done: false },
    ],
  },
  {
    id: "PRJ-010",
    name: "Quasar Mobile SDK",
    client: "Umbrella Inc",
    ownerId: "u5",
    owner: "Aiko Tanaka",
    ownerAvatar: teamPool[4].avatar,
    progress: 100,
    due: "Jun 30, 2026",
    startDate: "Feb 14, 2026",
    status: "completed",
    priority: "medium",
    budget: 158000,
    spent: 152400,
    team: [teamPool[4], teamPool[5], teamPool[6]],
    phase: "Delivered",
    phases: [
      { name: "Discovery", start: 12, end: 18, done: true },
      { name: "Build", start: 18, end: 42, done: true },
      { name: "Ship", start: 42, end: 48, done: true },
    ],
  },
  {
    id: "PRJ-009",
    name: "Orbit Data Pipeline",
    client: "Soylent",
    ownerId: "u6",
    owner: "David Kim",
    ownerAvatar: teamPool[5].avatar,
    progress: 56,
    due: "Jul 22, 2026",
    startDate: "Apr 22, 2026",
    status: "on-track",
    priority: "high",
    budget: 224000,
    spent: 124800,
    team: [teamPool[5], teamPool[2], teamPool[6]],
    phase: "Development",
    phases: [
      { name: "Plan", start: 30, end: 36, done: true },
      { name: "Build", start: 36, end: 56, done: false },
      { name: "Test", start: 56, end: 60, done: false },
    ],
  },
  {
    id: "PRJ-008",
    name: "Helix CRM Integration",
    client: "Stark Industries",
    ownerId: "u1",
    owner: "Sarah Chen",
    ownerAvatar: teamPool[0].avatar,
    progress: 64,
    due: "Aug 18, 2026",
    startDate: "May 04, 2026",
    status: "on-track",
    priority: "medium",
    budget: 178000,
    spent: 108400,
    team: [teamPool[0], teamPool[3], teamPool[4], teamPool[6]],
    phase: "Development",
    phases: [
      { name: "Discovery", start: 34, end: 40, done: true },
      { name: "Design", start: 40, end: 50, done: true },
      { name: "Build", start: 50, end: 70, done: false },
    ],
  },
  {
    id: "PRJ-007",
    name: "Aurora Brand Refresh",
    client: "Wayne Enterprises",
    ownerId: "u7",
    owner: "Priya Sharma",
    ownerAvatar: teamPool[6].avatar,
    progress: 18,
    due: "Oct 02, 2026",
    startDate: "Jun 25, 2026",
    status: "planning",
    priority: "low",
    budget: 96000,
    spent: 14200,
    team: [teamPool[6], teamPool[0]],
    phase: "Discovery",
    phases: [
      { name: "Discovery", start: 48, end: 58, done: false },
      { name: "Design", start: 58, end: 75, done: false },
      { name: "Rollout", start: 75, end: 82, done: false },
    ],
  },
];

const statusTone: Record<ProjectStatus, StatusTone> = {
  "on-track": "success",
  "at-risk": "warning",
  delayed: "danger",
  completed: "primary",
  planning: "info",
};
const priorityTone: Record<Priority, StatusTone> = {
  low: "neutral",
  medium: "info",
  high: "warning",
  critical: "danger",
};

/* ---------- ProjectKpi — milestone diamond strip motif ---------- */
// Distinct from ProjectKpiCard (sprint-day dots), LeadKpi (score-ring),
// DealKpi (stage mini-bars), ForecastKpi (delta panel), QuotaKpi (bullseye).

function ProjectKpi({
  label,
  value,
  icon: Icon,
  accent,
  phaseCount,
  phaseDone,
  trend,
  caption,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  accent: "primary" | "success" | "warning" | "danger" | "info";
  phaseCount: number;
  phaseDone: number;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  caption: string;
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/12 text-primary",
    success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/12 text-[color:var(--warning)]",
    danger: "bg-destructive/12 text-destructive",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
  };
  const accentBar: Record<string, string> = {
    primary: "bg-primary",
    success: "bg-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]",
    danger: "bg-destructive",
    info: "bg-[color:var(--info)]",
  };
  const accentRing: Record<string, string> = {
    primary: "ring-primary/30 text-primary",
    success: "ring-[color:var(--success)]/30 text-[color:var(--success)]",
    warning: "ring-[color:var(--warning)]/30 text-[color:var(--warning)]",
    danger: "ring-destructive/30 text-destructive",
    info: "ring-[color:var(--info)]/30 text-[color:var(--info)]",
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
            {label}
          </p>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
            <span
              className={cn(
                "inline-flex items-center gap-0.5 text-xs font-medium tabular-nums",
                trend.positive ? "text-[color:var(--success)]" : "text-destructive"
              )}
            >
              {trend.direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {Math.abs(trend.value)}%
            </span>
          </div>
        </div>
        <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
          <Icon className="h-4.5 w-4.5" />
        </div>
      </div>

      {/* Milestone phase diamond strip */}
      <div className="mt-4 flex items-center gap-1">
        {Array.from({ length: phaseCount }).map((_, i) => {
          const done = i < phaseDone;
          const current = i === phaseDone;
          return (
            <div
              key={i}
              className={cn(
                "h-2 flex-1 rounded-sm rotate-45 transition-all",
                done ? accentBar[accent] : current ? cn("bg-card ring-1 ring-inset", accentRing[accent]) : "bg-muted"
              )}
            />
          );
        })}
        <span className="text-[10px] font-semibold text-muted-foreground tabular-nums ml-2 whitespace-nowrap">
          {phaseDone}/{phaseCount}
        </span>
      </div>

      <p className="mt-2 text-[11px] text-muted-foreground truncate">{caption}</p>
    </div>
  );
}

/* ---------- Project Card (Grid view) ---------- */

function ProjectCard({ p }: { p: Project }) {
  const spentPct = Math.round((p.spent / p.budget) * 100);
  return (
    <Card className="group relative overflow-hidden hover:shadow-premium-sm transition-all">
      {/* Status accent strip */}
      <div
        className={cn(
          "absolute top-0 left-0 right-0 h-1",
          p.status === "on-track" && "bg-[color:var(--success)]",
          p.status === "at-risk" && "bg-[color:var(--warning)]",
          p.status === "delayed" && "bg-destructive",
          p.status === "completed" && "bg-primary",
          p.status === "planning" && "bg-[color:var(--info)]"
        )}
      />
      <CardContent className="pt-5">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-[10px] text-muted-foreground">{p.id}</span>
              <StatusBadge tone={priorityTone[p.priority]} className="capitalize">{p.priority}</StatusBadge>
            </div>
            <h3 className="font-semibold text-foreground truncate">{p.name}</h3>
            <p className="text-xs text-muted-foreground truncate flex items-center gap-1">
              <span className="h-1 w-1 rounded-full bg-muted-foreground/60" />
              {p.client}
            </p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel className="text-xs">{p.id}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening ${p.id}`)}>
                <Eye className="h-3.5 w-3.5" /> View details
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Editing ${p.id}`)}>
                <Pencil className="h-3.5 w-3.5" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`${p.id} archived`)}>
                <Archive className="h-3.5 w-3.5" /> Archive
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Owner row */}
        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="h-7 w-7">
              <AvatarImage src={p.ownerAvatar} alt={p.owner} />
              <AvatarFallback className="text-[10px]">{p.owner.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground leading-none">Owner</p>
              <p className="text-xs font-medium truncate">{p.owner}</p>
            </div>
          </div>
          <StatusBadge tone={statusTone[p.status]} dot className="capitalize">
            {p.status.replace("-", " ")}
          </StatusBadge>
        </div>

        {/* Progress */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-muted-foreground">Progress · {p.phase}</span>
            <span className="font-semibold tabular-nums">{p.progress}%</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full transition-all duration-700 ease-out",
                p.progress === 100
                  ? "bg-primary"
                  : p.progress >= 75
                  ? "bg-[color:var(--success)]"
                  : p.progress >= 50
                  ? "bg-violet-500"
                  : p.progress >= 30
                  ? "bg-[color:var(--warning)]"
                  : "bg-destructive"
              )}
              style={{ width: `${p.progress}%` }}
            />
          </div>
        </div>

        {/* Budget + due row */}
        <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
          <div>
            <p className="text-muted-foreground">Budget</p>
            <p className="font-semibold tabular-nums">${(p.budget / 1000).toFixed(0)}K</p>
            <div className="mt-1 h-1 w-full rounded-full bg-muted overflow-hidden">
              <div
                className={cn("h-full rounded-full", spentPct > 90 ? "bg-destructive" : spentPct > 70 ? "bg-[color:var(--warning)]" : "bg-primary")}
                style={{ width: `${Math.min(spentPct, 100)}%` }}
              />
            </div>
            <p className="text-[10px] text-muted-foreground mt-0.5 tabular-nums">${(p.spent / 1000).toFixed(0)}K spent · {spentPct}%</p>
          </div>
          <div>
            <p className="text-muted-foreground">Due date</p>
            <p className="font-semibold tabular-nums">{p.due}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-0.5">
              <Calendar className="h-2.5 w-2.5" /> started {p.startDate}
            </p>
          </div>
        </div>

        {/* Team avatars */}
        <div className="mt-4 pt-3 border-t border-border flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex -space-x-2">
              {p.team.slice(0, 4).map((m, i) => (
                <Avatar key={i} className="h-6 w-6 border-2 border-card">
                  <AvatarImage src={m.avatar} alt={m.name} />
                  <AvatarFallback className="text-[8px]">{m.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                </Avatar>
              ))}
              {p.team.length > 4 && (
                <div className="grid place-items-center h-6 w-6 rounded-full border-2 border-card bg-muted text-[9px] font-semibold text-muted-foreground">
                  +{p.team.length - 4}
                </div>
              )}
            </div>
            <span className="ml-2 text-[10px] text-muted-foreground inline-flex items-center gap-0.5">
              <Users className="h-2.5 w-2.5" /> {p.team.length}
            </span>
          </div>
          <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.message(`Opening ${p.id}`)}>
            Open <ArrowUpRight className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Timeline view ---------- */

function TimelineView() {
  // 12 months Jan-Dec 2026
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const quarters = [
    { label: "Q1", range: [0, 3] },
    { label: "Q2", range: [3, 6] },
    { label: "Q3", range: [6, 9] },
    { label: "Q4", range: [9, 12] },
  ];
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <GanttChart className="h-4 w-4 text-violet-500" />
          Project Timeline — Fiscal Year 2026
        </CardTitle>
        <CardDescription>Phase spans across active engagements. Today is Jul 06, 2026 (week 28).</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <div className="min-w-[860px]">
            {/* Quarter header */}
            <div className="grid grid-cols-12 border-b border-border bg-muted/30">
              {quarters.map((q) => (
                <div key={q.label} className="col-span-3 px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground border-r border-border last:border-r-0">
                  {q.label} 2026
                </div>
              ))}
            </div>
            {/* Month header */}
            <div className="grid grid-cols-12 border-b border-border">
              {months.map((m, i) => (
                <div key={m} className={cn("px-2 py-1.5 text-[10px] font-medium text-muted-foreground text-center border-r border-border last:border-r-0", i === 6 && "bg-primary/5 text-primary font-semibold")}>
                  {m}
                </div>
              ))}
            </div>
            {/* Today line overlay container */}
            <div className="relative">
              {/* Today line — Jul 6 ~ 6.2/12 */}
              <div className="absolute top-0 bottom-0 z-10 pointer-events-none" style={{ left: "51.6%" }}>
                <div className="h-full w-px bg-primary/50 border-dashed" />
                <div className="absolute -top-1 -translate-x-1/2 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-primary text-primary-foreground">TODAY</div>
              </div>
              {/* Project rows */}
              <div className="divide-y divide-border">
                {projects.map((p) => {
                  const firstStart = Math.min(...p.phases.map((ph) => ph.start));
                  const lastEnd = Math.max(...p.phases.map((ph) => ph.end));
                  const spanWidth = lastEnd - firstStart;
                  return (
                    <div key={p.id} className="grid grid-cols-12 relative h-12 hover:bg-muted/20 transition-colors">
                      {/* Project name (left-aligned overlay) */}
                      <div className="absolute left-2 top-1/2 -translate-y-1/2 z-20 max-w-[160px]">
                        <p className="text-xs font-medium text-foreground truncate">{p.name}</p>
                        <p className="text-[10px] text-muted-foreground font-mono">{p.id} · {p.client}</p>
                      </div>
                      {/* Phase bars positioned absolutely */}
                      <div className="col-span-12 relative">
                        {p.phases.map((ph, i) => {
                          const left = (ph.start / 12) * 100;
                          const width = ((ph.end - ph.start) / 12) * 100;
                          const phaseColors = ["bg-[color:var(--info)]/70", "bg-violet-500/70", "bg-primary/70", "bg-[color:var(--warning)]/70", "bg-[color:var(--success)]/70"];
                          return (
                            <div
                              key={i}
                              className={cn(
                                "absolute top-1/2 -translate-y-1/2 h-5 rounded-md flex items-center px-1.5 text-[9px] font-medium text-white shadow-sm",
                                ph.done ? phaseColors[i % phaseColors.length] : cn(phaseColors[i % phaseColors.length].split("/")[0], "/30 border border-dashed")
                              )}
                              style={{ left: `${left}%`, width: `${width}%` }}
                              title={`${ph.name} · ${ph.done ? "done" : "in progress"}`}
                            >
                              <span className="truncate">{ph.name}</span>
                              {ph.done && <CheckCircle2 className="h-2.5 w-2.5 ml-auto shrink-0" />}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
        {/* Legend */}
        <div className="px-4 py-3 border-t border-border flex items-center gap-4 flex-wrap text-xs">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2 w-4 rounded-sm bg-[color:var(--info)]/70" /> Discovery
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2 w-4 rounded-sm bg-violet-500/70" /> Design
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2 w-4 rounded-sm bg-primary/70" /> Development
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2 w-4 rounded-sm bg-[color:var(--warning)]/70" /> QA / Audit
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2 w-4 rounded-sm bg-[color:var(--success)]/70" /> Ship
          </span>
          <span className="ml-auto text-muted-foreground">Dashed border = pending phase</span>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------- Page ---------- */

export default function ProjectsPage() {
  const [view, setView] = React.useState<"grid" | "table" | "timeline">("grid");

  const totalBudget = projects.reduce((s, p) => s + p.budget, 0);
  const activeCount = projects.filter((p) => p.status !== "completed").length;
  const completedCount = projects.filter((p) => p.status === "completed").length;
  const atRiskCount = projects.filter((p) => p.status === "at-risk" || p.status === "delayed").length;

  const columns: Column<Project>[] = React.useMemo(() => [
    {
      key: "name",
      header: "Project",
      sortable: true,
      sortAccessor: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <div className="grid place-items-center h-8 w-8 rounded-lg bg-violet-500/12 text-violet-500 shrink-0">
            <FolderKanban className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <p className="font-medium text-foreground text-sm truncate">{r.name}</p>
            <p className="text-xs text-muted-foreground truncate">
              <span className="font-mono">{r.id}</span> · {r.client}
            </p>
          </div>
        </div>
      ),
    },
    {
      key: "owner",
      header: "Owner",
      sortable: true,
      sortAccessor: (r) => r.owner,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7">
            <AvatarImage src={r.ownerAvatar} alt={r.owner} />
            <AvatarFallback className="text-[10px]">{r.owner.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
          </Avatar>
          <span className="text-xs text-muted-foreground truncate">{r.owner}</span>
        </div>
      ),
      width: "w-40",
    },
    {
      key: "progress",
      header: "Progress",
      sortable: true,
      sortAccessor: (r) => r.progress,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <div className="h-1.5 w-24 rounded-full bg-muted overflow-hidden shrink-0">
            <div
              className={cn(
                "h-full rounded-full transition-all",
                r.progress === 100 ? "bg-primary" : r.progress >= 75 ? "bg-[color:var(--success)]" : r.progress >= 50 ? "bg-violet-500" : r.progress >= 30 ? "bg-[color:var(--warning)]" : "bg-destructive"
              )}
              style={{ width: `${r.progress}%` }}
            />
          </div>
          <span className="text-xs font-semibold tabular-nums w-9 shrink-0">{r.progress}%</span>
        </div>
      ),
      width: "w-44",
    },
    {
      key: "team",
      header: "Team",
      cell: (r) => (
        <div className="flex -space-x-2">
          {r.team.slice(0, 3).map((m, i) => (
            <Avatar key={i} className="h-6 w-6 border-2 border-card">
              <AvatarImage src={m.avatar} alt={m.name} />
              <AvatarFallback className="text-[8px]">{m.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
            </Avatar>
          ))}
          {r.team.length > 3 && (
            <div className="grid place-items-center h-6 w-6 rounded-full border-2 border-card bg-muted text-[9px] font-semibold">+{r.team.length - 3}</div>
          )}
        </div>
      ),
      width: "w-28",
    },
    {
      key: "budget",
      header: "Budget",
      sortable: true,
      sortAccessor: (r) => r.budget,
      align: "right",
      cell: (r) => (
        <div className="text-right">
          <p className="font-medium tabular-nums text-sm">${(r.budget / 1000).toFixed(0)}K</p>
          <p className="text-[10px] text-muted-foreground tabular-nums">${(r.spent / 1000).toFixed(0)}K spent</p>
        </div>
      ),
      width: "w-28",
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "On Track", value: "on-track" },
        { label: "At Risk", value: "at-risk" },
        { label: "Delayed", value: "delayed" },
        { label: "Completed", value: "completed" },
        { label: "Planning", value: "planning" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={statusTone[r.status]} dot className="capitalize">{r.status.replace("-", " ")}</StatusBadge>
      ),
      width: "w-32",
    },
    {
      key: "due",
      header: "Due Date",
      sortable: true,
      sortAccessor: (r) => r.due,
      cell: (r) => <span className="font-mono text-xs text-muted-foreground">{r.due}</span>,
      width: "w-32",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div onClick={(e) => e.stopPropagation()}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel className="text-xs">{r.id}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening ${r.id}`)}>
                <Eye className="h-3.5 w-3.5" /> View
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Editing ${r.id}`)}>
                <Pencil className="h-3.5 w-3.5" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`${r.id} archived`)}>
                <Archive className="h-3.5 w-3.5" /> Archive
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      width: "w-16",
    },
  ], []);

  return (
    <>
      <PageHeader
        title="Projects"
        description="Plan, track, and deliver client engagements across the portfolio."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects" }]}
        icon={FolderKanban}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Project portfolio exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New project wizard opened")}>
              <Plus className="h-3.5 w-3.5" /> New Project
            </Button>
          </>
        }
      />

      {/* KPI row — ProjectKpi with milestone diamond strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <ProjectKpi
          label="Active Projects"
          value={String(activeCount)}
          icon={FolderKanban}
          accent="primary"
          phaseCount={5}
          phaseDone={3}
          trend={{ value: 8, direction: "up", positive: true }}
          caption={`${projects.length} total in portfolio`}
        />
        <ProjectKpi
          label="Completed (YTD)"
          value={String(completedCount + 7)}
          icon={CheckCircle2}
          accent="success"
          phaseCount={5}
          phaseDone={5}
          trend={{ value: 12, direction: "up", positive: true }}
          caption="Shipped ahead of schedule"
        />
        <ProjectKpi
          label="At Risk / Delayed"
          value={String(atRiskCount)}
          icon={AlertTriangle}
          accent="warning"
          phaseCount={4}
          phaseDone={1}
          trend={{ value: 4, direction: "down", positive: true }}
          caption="2 critical path slips"
        />
        <ProjectKpi
          label="Total Budget"
          value={`$${(totalBudget / 1000000).toFixed(1)}M`}
          icon={CircleDollarSign}
          accent="info"
          phaseCount={4}
          phaseDone={2}
          trend={{ value: 6, direction: "up", positive: true }}
          caption="62% allocated · 38% available"
        />
      </div>

      {/* View toggle */}
      <div className="mb-4 flex items-center justify-between gap-3 flex-wrap">
        <Tabs value={view} onValueChange={(v) => setView(v as typeof view)}>
          <TabsList className="h-9">
            <TabsTrigger value="grid" className="gap-1.5 text-xs">
              <LayoutGrid className="h-3.5 w-3.5" /> Grid
            </TabsTrigger>
            <TabsTrigger value="table" className="gap-1.5 text-xs">
              <Table2 className="h-3.5 w-3.5" /> Table
            </TabsTrigger>
            <TabsTrigger value="timeline" className="gap-1.5 text-xs">
              <GanttChart className="h-3.5 w-3.5" /> Timeline
            </TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Flag className="h-3.5 w-3.5" />
          <span>Showing {projects.length} projects · sorted by start date</span>
        </div>
      </div>

      {/* View body */}
      {view === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {projects.map((p) => (
            <ProjectCard key={p.id} p={p} />
          ))}
        </div>
      )}

      {view === "table" && (
        <DataTable
          title="All Projects"
          data={projects}
          columns={columns}
          searchKeys={["name", "client", "id", "owner"]}
          getRowId={(r) => r.id}
          onRowClick={(r) => toast.message(`Opening ${r.id}`)}
          enableSelection
          enableExport
          enableDensity
          enableColumnVisibility
          pageSize={10}
          initialSort={{ key: "due", direction: "asc" }}
          bulkActions={[
            {
              label: "Archive",
              icon: Archive,
              onClick: (sel) => toast.success(`Archived ${sel.length} project${sel.length > 1 ? "s" : ""}`),
            },
            {
              label: "Export selected",
              icon: Download,
              onClick: (sel) => toast.success(`Exported ${sel.length} project${sel.length > 1 ? "s" : ""}`),
            },
          ]}
        />
      )}

      {view === "timeline" && <TimelineView />}

      {/* Footer insight band */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Avg. Health Score</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">82 / 100</p>
                <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1.5">
                  <TrendingUp className="h-3 w-3" /> +3 pts vs last month
                </p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--success)]/12 text-[color:var(--success)]">
                <TrendingUp className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">On-Time Delivery</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">94%</p>
                <p className="text-xs text-muted-foreground mt-1.5">12 of 13 milestones met this quarter</p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/12 text-primary">
                <CheckCircle2 className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Budget Utilization</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">62%</p>
                <Progress value={62} className="h-1.5 mt-2" />
                <p className="text-[10px] text-muted-foreground mt-1.5 tabular-nums">$1.4M of $2.3M spent</p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
                <CircleDollarSign className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
