"use client";

import * as React from "react";
import {
  Users,
  UserPlus,
  Mail,
  MoreHorizontal,
  Search,
  Filter,
  Shield,
  Crown,
  Briefcase,
  MapPin,
  Clock,
  Trash2,
  UserCog,
  MessageSquare,
  Download,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Member = {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: "Owner" | "Admin" | "Manager" | "Editor" | "Viewer" | "Guest";
  department: "Engineering" | "Design" | "Product" | "Sales" | "Marketing" | "Operations";
  status: "active" | "away" | "offline" | "invited";
  lastActive: string;
  location: string;
  joined: string;
};

const MEMBERS: Member[] = [
  { id: "m1", name: "Amara Okafor", email: "amara.okafor@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=200&q=80&auto=format&fit=crop", role: "Owner", department: "Engineering", status: "active", lastActive: "Active now", location: "San Francisco, CA", joined: "Mar 2022" },
  { id: "m2", name: "Daniel Kim", email: "daniel.kim@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80&auto=format&fit=crop", role: "Admin", department: "Engineering", status: "active", lastActive: "5 min ago", location: "Seattle, WA", joined: "Jun 2022" },
  { id: "m3", name: "Priya Sharma", email: "priya.sharma@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80&auto=format&fit=crop", role: "Manager", department: "Product", status: "active", lastActive: "Active now", location: "Austin, TX", joined: "Aug 2022" },
  { id: "m4", name: "Marcus Johnson", email: "marcus.j@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80&auto=format&fit=crop", role: "Editor", department: "Design", status: "away", lastActive: "2 hours ago", location: "Brooklyn, NY", joined: "Oct 2022" },
  { id: "m5", name: "Sofia Reyes", email: "sofia.reyes@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80&auto=format&fit=crop", role: "Editor", department: "Marketing", status: "active", lastActive: "18 min ago", location: "Miami, FL", joined: "Jan 2023" },
  { id: "m6", name: "Lukas Bergmann", email: "lukas.b@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&q=80&auto=format&fit=crop", role: "Manager", department: "Sales", status: "offline", lastActive: "Yesterday", location: "Berlin, DE", joined: "Feb 2023" },
  { id: "m7", name: "Yuki Tanaka", email: "yuki.tanaka@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&q=80&auto=format&fit=crop", role: "Editor", department: "Engineering", status: "active", lastActive: "Active now", location: "Tokyo, JP", joined: "Apr 2023" },
  { id: "m8", name: "Olivia Chen", email: "olivia.chen@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&q=80&auto=format&fit=crop", role: "Viewer", department: "Operations", status: "offline", lastActive: "3 days ago", location: "Toronto, CA", joined: "Jul 2023" },
  { id: "m9", name: "Marcus Brown", email: "marcus.brown@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=200&q=80&auto=format&fit=crop", role: "Editor", department: "Engineering", status: "away", lastActive: "1 hour ago", location: "Atlanta, GA", joined: "Sep 2023" },
  { id: "m10", name: "Hana Park", email: "hana.park@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&q=80&auto=format&fit=crop", role: "Manager", department: "Design", status: "active", lastActive: "30 min ago", location: "Seoul, KR", joined: "Nov 2023" },
  { id: "m11", name: "Ethan Wright", email: "ethan.wright@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&q=80&auto=format&fit=crop", role: "Guest", department: "Operations", status: "invited", lastActive: "Pending", location: "—", joined: "Invited 2d ago" },
  { id: "m12", name: "Aisha Mwangi", email: "aisha.m@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80&auto=format&fit=crop", role: "Viewer", department: "Marketing", status: "invited", lastActive: "Pending", location: "—", joined: "Invited 5d ago" },
];

const roleTone: Record<Member["role"], "warning" | "danger" | "primary" | "info" | "neutral" | "violet"> = {
  Owner: "warning",
  Admin: "danger",
  Manager: "primary",
  Editor: "info",
  Viewer: "neutral",
  Guest: "violet",
};

const statusTone: Record<Member["status"], "success" | "warning" | "neutral" | "info"> = {
  active: "success",
  away: "warning",
  offline: "neutral",
  invited: "info",
};

const statusDot: Record<Member["status"], string> = {
  active: "bg-[color:var(--success)]",
  away: "bg-[color:var(--warning)]",
  offline: "bg-muted-foreground",
  invited: "bg-[color:var(--info)]",
};

export default function TeamPage() {
  const [search, setSearch] = React.useState("");
  const [deptFilter, setDeptFilter] = React.useState<string>("all");
  const [roleFilter, setRoleFilter] = React.useState<string>("all");
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [inviteOpen, setInviteOpen] = React.useState(false);
  const [inviteEmail, setInviteEmail] = React.useState("");
  const [inviteRole, setInviteRole] = React.useState("Editor");

  const filtered = MEMBERS.filter((m) => {
    const s = search.toLowerCase();
    const matchSearch = !s || m.name.toLowerCase().includes(s) || m.email.toLowerCase().includes(s);
    const matchDept = deptFilter === "all" || m.department === deptFilter;
    const matchRole = roleFilter === "all" || m.role === roleFilter;
    return matchSearch && matchDept && matchRole;
  });

  const toggleSelect = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const toggleAll = () => {
    if (selected.size === filtered.length) setSelected(new Set());
    else setSelected(new Set(filtered.map((m) => m.id)));
  };

  const sendInvite = () => {
    if (!inviteEmail) {
      toast.error("Email required");
      return;
    }
    setInviteOpen(false);
    setInviteEmail("");
    toast.success("Invitation sent", { description: `${inviteEmail} invited as ${inviteRole}.` });
  };

  const depts = Array.from(new Set(MEMBERS.map((m) => m.department)));
  const roles = Array.from(new Set(MEMBERS.map((m) => m.role)));

  return (
    <>
      <PageHeader
        title="Team Members"
        description="Everyone with access to this workspace — their role, department, and presence."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Team" }]}
        icon={Users}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Member directory exported", { description: "CSV downloaded." })}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => setInviteOpen(true)}>
              <UserPlus className="h-3.5 w-3.5" /> Invite member
            </Button>
          </div>
        }
      />

      {/* DEPT SUMMARY TILES */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {depts.map((d) => {
          const count = MEMBERS.filter((m) => m.department === d).length;
          const active = MEMBERS.filter((m) => m.department === d && m.status === "active").length;
          return (
            <Card key={d} className="p-3 hover:shadow-premium-xs transition-shadow cursor-pointer" onClick={() => setDeptFilter(deptFilter === d ? "all" : d)}>
              <div className={cn("text-[10px] font-semibold uppercase tracking-wide mb-1", deptFilter === d ? "text-primary" : "text-muted-foreground")}>{d}</div>
              <p className="text-xl font-semibold tabular-nums leading-tight">{count}</p>
              <p className="text-[11px] text-[color:var(--success)] mt-0.5">{active} active</p>
            </Card>
          );
        })}
      </div>

      {/* FILTER BAR + BULK ACTIONS */}
      <Card className="mb-4">
        <CardContent className="p-3">
          <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name or email…"
                className="pl-8 h-9 text-sm"
              />
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Select value={deptFilter} onValueChange={setDeptFilter}>
                <SelectTrigger className="h-9 w-[150px] text-xs gap-1.5"><Filter className="h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All departments</SelectItem>
                  {depts.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="h-9 w-[130px] text-xs gap-1.5"><Shield className="h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All roles</SelectItem>
                  {roles.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectContent>
              </Select>
              {(search || deptFilter !== "all" || roleFilter !== "all") && (
                <Button variant="ghost" size="sm" className="text-xs" onClick={() => { setSearch(""); setDeptFilter("all"); setRoleFilter("all"); }}>Clear</Button>
              )}
            </div>
          </div>

          {/* Bulk actions bar */}
          {selected.size > 0 && (
            <div className="mt-3 pt-3 border-t border-border flex items-center gap-3 animate-fade-in-up">
              <span className="text-xs font-medium text-primary">{selected.size} selected</span>
              <div className="flex-1" />
              <Button variant="outline" size="sm" className="text-xs gap-1.5 h-7" onClick={() => toast.success(`Email sent to ${selected.size} members`)}>
                <Mail className="h-3 w-3" /> Email
              </Button>
              <Button variant="outline" size="sm" className="text-xs gap-1.5 h-7" onClick={() => toast.success(`Role changed for ${selected.size} members`)}>
                <UserCog className="h-3 w-3" /> Change role
              </Button>
              <Button variant="outline" size="sm" className="text-xs gap-1.5 h-7 text-destructive hover:text-destructive" onClick={() => { setSelected(new Set()); toast.success("Members removed"); }}>
                <Trash2 className="h-3 w-3" /> Remove
              </Button>
              <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => setSelected(new Set())}>Clear</Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* TEAM GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((m) => (
          <Card
            key={m.id}
            className={cn(
              "p-4 transition-all hover:shadow-premium-sm group cursor-pointer",
              selected.has(m.id) && "ring-2 ring-primary/40 border-primary/40"
            )}
            onClick={() => toggleSelect(m.id)}
          >
            <div className="flex items-start gap-3">
              <div className="relative shrink-0">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={m.avatar} alt={m.name} />
                  <AvatarFallback>{m.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                </Avatar>
                {m.status !== "invited" && (
                  <span className={cn("absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full ring-2 ring-card", statusDot[m.status])} />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-semibold truncate">{m.name}</p>
                  {m.role === "Owner" && <Crown className="h-3.5 w-3.5 text-[color:var(--warning)] shrink-0" />}
                </div>
                <p className="text-xs text-muted-foreground truncate">{m.email}</p>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                  <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                    <MoreHorizontal className="h-3.5 w-3.5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-44">
                  <DropdownMenuLabel className="text-xs">Actions</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-xs gap-2" onClick={(e) => { e.stopPropagation(); toast.success(`Message sent to ${m.name}`); }}>
                    <MessageSquare className="h-3.5 w-3.5" /> Message
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-xs gap-2" onClick={(e) => { e.stopPropagation(); toast.success(`Role editor opened for ${m.name}`); }}>
                    <UserCog className="h-3.5 w-3.5" /> Change role
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-xs gap-2" onClick={(e) => { e.stopPropagation(); toast.success(`Email composed to ${m.name}`); }}>
                    <Mail className="h-3.5 w-3.5" /> Email
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={(e) => { e.stopPropagation(); toast.success(`${m.name} removed from workspace`); }}>
                    <Trash2 className="h-3.5 w-3.5" /> Remove
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="mt-3 flex items-center gap-1.5 flex-wrap">
              <StatusBadge tone={roleTone[m.role]}>{m.role}</StatusBadge>
              <StatusBadge tone={statusTone[m.status]} dot>{m.status}</StatusBadge>
            </div>

            <div className="mt-3 pt-3 border-t border-border grid grid-cols-2 gap-2 text-xs">
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1"><Briefcase className="h-2.5 w-2.5" /> Dept</p>
                <p className="font-medium truncate">{m.department}</p>
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1"><MapPin className="h-2.5 w-2.5" /> Location</p>
                <p className="font-medium truncate">{m.location}</p>
              </div>
              <div className="min-w-0 col-span-2">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1"><Clock className="h-2.5 w-2.5" /> Last active</p>
                <p className="font-medium">{m.lastActive} · joined {m.joined}</p>
              </div>
            </div>
          </Card>
        ))}

        {/* INVITE CARD */}
        <Card
          className="p-4 border-dashed border-2 hover:border-primary/40 hover:bg-primary/[0.02] transition-colors cursor-pointer grid place-items-center min-h-[220px]"
          onClick={() => setInviteOpen(true)}
        >
          <div className="text-center">
            <div className="mx-auto grid place-items-center h-12 w-12 rounded-full bg-primary/10 text-primary mb-2">
              <UserPlus className="h-5 w-5" />
            </div>
            <p className="text-sm font-medium">Invite a teammate</p>
            <p className="text-xs text-muted-foreground mt-1 max-w-[180px]">Send an invitation by email with a role and department.</p>
          </div>
        </Card>
      </div>

      {/* INVITE DIALOG */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Invite a team member</DialogTitle>
            <DialogDescription>They'll receive an email with a link to join the workspace.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-xs">Email address</Label>
              <Input type="email" placeholder="teammate@company.com" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-xs">Role</Label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Admin", "Manager", "Editor", "Viewer", "Guest"].map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Department</Label>
                <Select defaultValue="Engineering">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {depts.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground flex items-start gap-2">
              <Mail className="h-3.5 w-3.5 text-primary mt-0.5 shrink-0" />
              <p>An invitation email will be sent to <span className="font-medium text-foreground">{inviteEmail || "this address"}</span>. The link expires in 7 days.</p>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button onClick={sendInvite} className="gap-1.5"><UserPlus className="h-3.5 w-3.5" /> Send invite</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
