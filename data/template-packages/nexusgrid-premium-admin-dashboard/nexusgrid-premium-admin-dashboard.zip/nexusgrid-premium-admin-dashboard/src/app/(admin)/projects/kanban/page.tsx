"use client";

import * as React from "react";
import {
  KanbanSquare,
  Plus,
  ChevronDown,
  Search,
  MessageSquare,
  Paperclip,
  Calendar,
  GripVertical,
  Filter,
  MoreHorizontal,
  Eye,
  Pencil,
  Trash2,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type ColumnKey = "backlog" | "todo" | "in-progress" | "review" | "done";
type Priority = "low" | "medium" | "high" | "critical";

type KanbanTask = {
  id: string;
  title: string;
  project: string;
  projectColor: string;
  priority: Priority;
  assignee: string;
  assigneeAvatar: string;
  due: string;
  overdue: boolean;
  comments: number;
  attachments: number;
  column: ColumnKey;
};

const columnConfig: Record<ColumnKey, { label: string; color: string; tone: StatusTone }> = {
  backlog: { label: "Backlog", color: "var(--muted-foreground)", tone: "neutral" },
  todo: { label: "To Do", color: "var(--info)", tone: "info" },
  "in-progress": { label: "In Progress", color: "var(--primary)", tone: "primary" },
  review: { label: "Review", color: "oklch(0.62 0.18 305)", tone: "violet" },
  done: { label: "Done", color: "var(--success)", tone: "success" },
};
const columnOrder: ColumnKey[] = ["backlog", "todo", "in-progress", "review", "done"];
const priorityTone: Record<Priority, StatusTone> = {
  low: "neutral",
  medium: "info",
  high: "warning",
  critical: "danger",
};

const projList = [
  { id: "PRJ-014", name: "Atlas Mobile Redesign", color: "var(--primary)" },
  { id: "PRJ-013", name: "Pulse Analytics Platform", color: "var(--info)" },
  { id: "PRJ-012", name: "Vertex Payment Gateway", color: "var(--destructive)" },
  { id: "PRJ-011", name: "Nimbus Cloud Migration", color: "var(--success)" },
  { id: "PRJ-009", name: "Orbit Data Pipeline", color: "oklch(0.62 0.18 305)" },
  { id: "PRJ-008", name: "Helix CRM Integration", color: "oklch(0.70 0.15 75)" },
];

const team = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop" },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop" },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop" },
  { name: "David Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
];

const initialTasks: KanbanTask[] = [
  // Backlog (5)
  { id: "TSK-2051", title: "Webhook retry backoff strategy", project: "Pulse Analytics Platform", projectColor: "var(--info)", priority: "low", assignee: team[1].name, assigneeAvatar: team[1].avatar, due: "Jul 15", overdue: false, comments: 2, attachments: 0, column: "backlog" },
  { id: "TSK-2052", title: "Onboarding tour redesign", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", priority: "low", assignee: team[4].name, assigneeAvatar: team[4].avatar, due: "Jul 18", overdue: false, comments: 5, attachments: 3, column: "backlog" },
  { id: "TSK-2053", title: "Push notification A/B framework", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", priority: "medium", assignee: team[0].name, assigneeAvatar: team[0].avatar, due: "Jul 20", overdue: false, comments: 1, attachments: 1, column: "backlog" },
  { id: "TSK-2054", title: "CSP header hardening", project: "Nimbus Cloud Migration", projectColor: "var(--success)", priority: "medium", assignee: team[3].name, assigneeAvatar: team[3].avatar, due: "Jul 14", overdue: false, comments: 0, attachments: 0, column: "backlog" },
  { id: "TSK-2055", title: "Lead dedup rules engine", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", priority: "medium", assignee: team[5].name, assigneeAvatar: team[5].avatar, due: "Jul 22", overdue: false, comments: 3, attachments: 2, column: "backlog" },

  // To Do (5)
  { id: "TSK-2041", title: "Cohort retention query opt", project: "Pulse Analytics Platform", projectColor: "var(--info)", priority: "medium", assignee: team[5].name, assigneeAvatar: team[5].avatar, due: "Jul 12", overdue: false, comments: 4, attachments: 1, column: "todo" },
  { id: "TSK-2042", title: "DNS failover drill prep", project: "Nimbus Cloud Migration", projectColor: "var(--success)", priority: "high", assignee: team[3].name, assigneeAvatar: team[3].avatar, due: "Jul 09", overdue: false, comments: 2, attachments: 4, column: "todo" },
  { id: "TSK-2043", title: "Mobile crash symbolication", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", priority: "high", assignee: team[1].name, assigneeAvatar: team[1].avatar, due: "Jul 05", overdue: true, comments: 6, attachments: 2, column: "todo" },
  { id: "TSK-2044", title: "Pipeline replay tests", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", priority: "high", assignee: team[5].name, assigneeAvatar: team[5].avatar, due: "Jul 10", overdue: false, comments: 1, attachments: 0, column: "todo" },
  { id: "TSK-2045", title: "Hubspot contact sync job", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", priority: "medium", assignee: team[0].name, assigneeAvatar: team[0].avatar, due: "Jul 11", overdue: false, comments: 3, attachments: 1, column: "todo" },

  // In Progress (6)
  { id: "TSK-2031", title: "Implement biometric login", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", priority: "high", assignee: team[0].name, assigneeAvatar: team[0].avatar, due: "Jul 08", overdue: false, comments: 8, attachments: 3, column: "in-progress" },
  { id: "TSK-2032", title: "Migrate analytics to v2 schema", project: "Pulse Analytics Platform", projectColor: "var(--info)", priority: "high", assignee: team[2].name, assigneeAvatar: team[2].avatar, due: "Jul 10", overdue: false, comments: 5, attachments: 2, column: "in-progress" },
  { id: "TSK-2033", title: "PCI-DSS audit prep", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", priority: "critical", assignee: team[3].name, assigneeAvatar: team[3].avatar, due: "Jul 06", overdue: false, comments: 12, attachments: 7, column: "in-progress" },
  { id: "TSK-2034", title: "Kafka topic backfill job", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", priority: "high", assignee: team[5].name, assigneeAvatar: team[5].avatar, due: "Jul 12", overdue: false, comments: 4, attachments: 1, column: "in-progress" },
  { id: "TSK-2035", title: "Salesforce OAuth2 connector", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", priority: "high", assignee: team[0].name, assigneeAvatar: team[0].avatar, due: "Jul 09", overdue: false, comments: 6, attachments: 4, column: "in-progress" },
  { id: "TSK-2036", title: "Wire fraud detection alerts", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", priority: "critical", assignee: team[2].name, assigneeAvatar: team[2].avatar, due: "Jul 04", overdue: true, comments: 9, attachments: 5, column: "in-progress" },

  // Review (4)
  { id: "TSK-2021", title: "Design token refresh rate limit", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", priority: "medium", assignee: team[1].name, assigneeAvatar: team[1].avatar, due: "Jul 07", overdue: false, comments: 3, attachments: 1, column: "review" },
  { id: "TSK-2022", title: "Cutover runbook", project: "Nimbus Cloud Migration", projectColor: "var(--success)", priority: "critical", assignee: team[3].name, assigneeAvatar: team[3].avatar, due: "Jul 06", overdue: false, comments: 7, attachments: 6, column: "review" },
  { id: "TSK-2023", title: "Field-level PII encryption", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", priority: "high", assignee: team[3].name, assigneeAvatar: team[3].avatar, due: "Jul 08", overdue: false, comments: 4, attachments: 2, column: "review" },
  { id: "TSK-2024", title: "Schema validation upgrade", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", priority: "low", assignee: team[5].name, assigneeAvatar: team[5].avatar, due: "Jul 09", overdue: false, comments: 1, attachments: 0, column: "review" },

  // Done (4)
  { id: "TSK-2011", title: "Refactor checkout reducer", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", priority: "medium", assignee: team[0].name, assigneeAvatar: team[0].avatar, due: "Jul 04", overdue: false, comments: 2, attachments: 0, column: "done" },
  { id: "TSK-2012", title: "DNS failover documentation", project: "Nimbus Cloud Migration", projectColor: "var(--success)", priority: "medium", assignee: team[3].name, assigneeAvatar: team[3].avatar, due: "Jul 02", overdue: false, comments: 1, attachments: 3, column: "done" },
  { id: "TSK-2013", title: "Refund webhook idempotency", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", priority: "critical", assignee: team[2].name, assigneeAvatar: team[2].avatar, due: "Jun 28", overdue: false, comments: 5, attachments: 2, column: "done" },
  { id: "TSK-2014", title: "Schema validation library", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", priority: "low", assignee: team[5].name, assigneeAvatar: team[5].avatar, due: "Jun 30", overdue: false, comments: 0, attachments: 1, column: "done" },
];

/* ---------- Page ---------- */

export default function KanbanBoardPage() {
  const [tasks, setTasks] = React.useState<KanbanTask[]>(initialTasks);
  const [activeProject, setActiveProject] = React.useState<string>("all");
  const [assigneeFilter, setAssigneeFilter] = React.useState<string>("all");
  const [priorityFilter, setPriorityFilter] = React.useState<string>("all");
  const [search, setSearch] = React.useState("");
  const [dragId, setDragId] = React.useState<string | null>(null);
  const [dragOverCol, setDragOverCol] = React.useState<ColumnKey | null>(null);

  const filteredTasks = React.useMemo(() => {
    return tasks.filter((t) => {
      if (activeProject !== "all") {
        const proj = projList.find((p) => p.id === activeProject);
        if (!proj || t.project !== proj.name) return false;
      }
      if (assigneeFilter !== "all" && t.assignee !== assigneeFilter) return false;
      if (priorityFilter !== "all" && t.priority !== priorityFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        if (!t.title.toLowerCase().includes(q) && !t.id.toLowerCase().includes(q) && !t.project.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [tasks, activeProject, assigneeFilter, priorityFilter, search]);

  const handleDragStart = (id: string) => {
    setDragId(id);
  };
  const handleDragOver = (e: React.DragEvent, col: ColumnKey) => {
    e.preventDefault();
    if (dragOverCol !== col) setDragOverCol(col);
  };
  const handleDrop = (col: ColumnKey) => {
    if (!dragId) return;
    const task = tasks.find((t) => t.id === dragId);
    if (!task) return;
    if (task.column === col) {
      setDragId(null);
      setDragOverCol(null);
      return;
    }
    setTasks((prev) => prev.map((t) => (t.id === dragId ? { ...t, column: col } : t)));
    toast.success(`${task.id} moved to ${columnConfig[col].label}`, {
      description: task.title,
    });
    setDragId(null);
    setDragOverCol(null);
  };

  return (
    <>
      <PageHeader
        title="Kanban Board"
        description="Drag tasks across stages to update their workflow status in real time."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: "Kanban Board" }]}
        icon={KanbanSquare}
        actions={
          <>
            <Select value={activeProject} onValueChange={setActiveProject}>
              <SelectTrigger className="h-9 w-[210px] text-xs gap-1.5">
                <Filter className="h-3.5 w-3.5" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projList.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    <span className="inline-flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full" style={{ background: p.color }} />
                      {p.name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New task drawer opened")}>
              <Plus className="h-3.5 w-3.5" /> New Task
            </Button>
          </>
        }
      />

      {/* Filter bar */}
      <Card className="mb-4">
        <CardContent className="p-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                placeholder="Search by task title, ID, or project…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="h-9 pl-8 text-xs"
              />
            </div>
            <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
              <SelectTrigger className="h-9 w-[160px] text-xs gap-1.5">
                <Avatar className="h-4 w-4">
                  <AvatarFallback className="text-[8px]">A</AvatarFallback>
                </Avatar>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Assignees</SelectItem>
                {team.map((m) => (
                  <SelectItem key={m.name} value={m.name}>{m.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="h-9 w-[140px] text-xs gap-1.5">
                <Filter className="h-3.5 w-3.5" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
            <div className="text-xs text-muted-foreground ml-auto hidden sm:inline-flex items-center gap-1.5">
              <GripVertical className="h-3.5 w-3.5" />
              Drag cards between columns
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Kanban board */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
        {columnOrder.map((col) => {
          const cfg = columnConfig[col];
          const colTasks = filteredTasks.filter((t) => t.column === col);
          const isOver = dragOverCol === col;
          return (
            <div key={col} className="flex flex-col min-w-0">
              {/* Column header */}
              <div className="rounded-t-lg border border-border border-b-0 bg-muted/40 p-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="h-2 w-2 rounded-full shrink-0" style={{ background: cfg.color }} />
                    <span className="text-sm font-medium text-foreground truncate">{cfg.label}</span>
                  </div>
                  <StatusBadge tone={cfg.tone}>{colTasks.length}</StatusBadge>
                </div>
                <p className="text-[10px] text-muted-foreground">{colTasks.length} task{colTasks.length !== 1 ? "s" : ""} in this stage</p>
              </div>
              {/* Column body — drop target */}
              <div
                onDragOver={(e) => handleDragOver(e, col)}
                onDragLeave={() => setDragOverCol(null)}
                onDrop={() => handleDrop(col)}
                className={cn(
                  "flex-1 rounded-b-lg border border-border border-t-0 bg-muted/20 p-2 min-h-[480px] space-y-2 transition-all",
                  isOver && "bg-primary/5 border-primary/40 border-t-2",
                  cfg.color !== "var(--muted-foreground)" && !isOver && "border-t-2"
                )}
                style={isOver ? { borderTopColor: cfg.color } : !isOver && cfg.color !== "var(--muted-foreground)" ? { borderTopColor: cfg.color } : undefined}
              >
                {colTasks.map((t) => (
                  <div
                    key={t.id}
                    draggable
                    onDragStart={() => handleDragStart(t.id)}
                    onDragEnd={() => { setDragId(null); setDragOverCol(null); }}
                    onClick={() => toast.message(`Opening ${t.id}`, { description: t.title })}
                    className={cn(
                      "group relative rounded-lg border border-border bg-card p-3 cursor-grab active:cursor-grabbing hover:border-primary/40 hover:shadow-premium-sm transition-all",
                      dragId === t.id && "opacity-50 ring-2 ring-primary/40"
                    )}
                  >
                    {/* Drag handle */}
                    <div className="absolute right-1.5 top-1.5 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground/60">
                      <GripVertical className="h-3.5 w-3.5" />
                    </div>

                    {/* Project tag + priority */}
                    <div className="flex items-center gap-1.5 mb-2 pr-5">
                      <span
                        className="inline-flex items-center gap-1 text-[9px] font-medium px-1.5 py-0.5 rounded ring-1 ring-inset"
                        style={{
                          color: t.projectColor,
                          background: `color-mix(in srgb, ${t.projectColor} 12%, transparent)`,
                          borderColor: `color-mix(in srgb, ${t.projectColor} 25%, transparent)`,
                        }}
                      >
                        <span className="h-1 w-1 rounded-full" style={{ background: t.projectColor }} />
                        <span className="truncate max-w-[80px]">{t.project}</span>
                      </span>
                      <StatusBadge tone={priorityTone[t.priority]} className="capitalize text-[9px] px-1.5 py-0">
                        {t.priority}
                      </StatusBadge>
                    </div>

                    {/* Title */}
                    <p className="text-sm font-medium text-foreground leading-snug mb-2 line-clamp-2">{t.title}</p>
                    <p className="text-[9px] text-muted-foreground font-mono mb-2.5">{t.id}</p>

                    {/* Footer: assignee + due + counts */}
                    <div className="flex items-center justify-between gap-2">
                      <Avatar className="h-5 w-5">
                        <AvatarImage src={t.assigneeAvatar} alt={t.assignee} />
                        <AvatarFallback className="text-[8px]">{t.assignee.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                      </Avatar>
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground ml-auto">
                        {t.comments > 0 && (
                          <span className="inline-flex items-center gap-0.5">
                            <MessageSquare className="h-3 w-3" />
                            <span className="tabular-nums">{t.comments}</span>
                          </span>
                        )}
                        {t.attachments > 0 && (
                          <span className="inline-flex items-center gap-0.5">
                            <Paperclip className="h-3 w-3" />
                            <span className="tabular-nums">{t.attachments}</span>
                          </span>
                        )}
                        <span className={cn("inline-flex items-center gap-0.5 tabular-nums font-mono", t.overdue ? "text-destructive font-semibold" : "")}>
                          <Calendar className="h-3 w-3" />
                          {t.due}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
                {colTasks.length === 0 && (
                  <div className="rounded-lg border border-dashed border-border p-4 text-center text-[11px] text-muted-foreground">
                    Drop tasks here
                  </div>
                )}
                {/* Add task button */}
                <button
                  onClick={() => toast.success(`Add task to ${cfg.label}`)}
                  className="w-full rounded-lg border border-dashed border-border p-2 text-xs text-muted-foreground hover:border-primary/40 hover:text-primary hover:bg-primary/5 transition-colors flex items-center justify-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Add task
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom row: column totals + quick actions */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Board Flow Summary</p>
                <p className="text-sm font-medium mt-1">Task distribution across the workflow</p>
              </div>
              <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.message("Opening analytics")}>
                View analytics <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </div>
            <div className="space-y-2.5">
              {columnOrder.map((col) => {
                const count = tasks.filter((t) => t.column === col).length;
                const pct = Math.round((count / tasks.length) * 100);
                const cfg = columnConfig[col];
                return (
                  <div key={col} className="flex items-center gap-3">
                    <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground w-28 shrink-0">
                      <span className="h-2 w-2 rounded-full" style={{ background: cfg.color }} />
                      {cfg.label}
                    </span>
                    <div className="flex-1 h-2.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ background: cfg.color, width: `${pct}%` }}
                      />
                    </div>
                    <span className="text-xs font-semibold tabular-nums w-16 text-right shrink-0">{count} · {pct}%</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">Quick Actions</p>
            <div className="space-y-2">
              <button
                onClick={() => toast.success("Bulk complete dialog opened")}
                className="w-full rounded-lg border border-border p-2.5 text-xs text-left hover:bg-muted/40 transition-colors flex items-center gap-2"
              >
                <div className="grid place-items-center h-7 w-7 rounded-md bg-[color:var(--success)]/12 text-[color:var(--success)] shrink-0">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-foreground">Mark all in Review as Done</p>
                  <p className="text-[10px] text-muted-foreground">4 tasks ready to ship</p>
                </div>
              </button>
              <button
                onClick={() => toast.message("Reassignment assistant opened")}
                className="w-full rounded-lg border border-border p-2.5 text-xs text-left hover:bg-muted/40 transition-colors flex items-center gap-2"
              >
                <div className="grid place-items-center h-7 w-7 rounded-md bg-[color:var(--warning)]/12 text-[color:var(--warning)] shrink-0">
                  <ArrowRight className="h-3.5 w-3.5" />
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-foreground">Reassign overdue tasks</p>
                  <p className="text-[10px] text-muted-foreground">2 tasks past due date</p>
                </div>
              </button>
              <button
                onClick={() => toast.success("Board exported as PDF")}
                className="w-full rounded-lg border border-border p-2.5 text-xs text-left hover:bg-muted/40 transition-colors flex items-center gap-2"
              >
                <div className="grid place-items-center h-7 w-7 rounded-md bg-primary/12 text-primary shrink-0">
                  <KanbanSquare className="h-3.5 w-3.5" />
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-foreground">Export board snapshot</p>
                  <p className="text-[10px] text-muted-foreground">PDF · last exported 3d ago</p>
                </div>
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
