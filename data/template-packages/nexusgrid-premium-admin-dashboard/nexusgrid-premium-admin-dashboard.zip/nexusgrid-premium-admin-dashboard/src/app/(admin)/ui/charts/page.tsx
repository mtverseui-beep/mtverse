"use client";

import * as React from "react";
import {
  PieChart,
  TrendingUp,
  BarChart3,
  Activity,
  Target,
  Radar as RadarIcon,
  Download,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AreaTrendChart,
  LineTrendChart,
  BarTrendChart,
  DonutChart,
  RadialProgress,
  RadarComparison,
  CHART_COLORS,
} from "@/components/charts";
import { toast } from "sonner";

const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const areaSingleSeries = months.map((m, i) => ({
  month: m,
  revenue: Math.round(22000 + i * 1800 + Math.sin(i) * 3200 + Math.random() * 1200),
}));

const areaMultiSeries = months.map((m, i) => ({
  month: m,
  users: Math.round(8400 + i * 920 + Math.sin(i) * 1100),
  sessions: Math.round(12400 + i * 1400 + Math.sin(i) * 1900),
  pageviews: Math.round(28400 + i * 2800 + Math.sin(i) * 4200),
}));

const lineComparison = months.map((m, i) => ({
  month: m,
  current: Math.round(42000 + i * 2400 + Math.sin(i) * 4200),
  previous: Math.round(38000 + i * 1800 + Math.sin(i) * 3800),
}));

const barVertical = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d, i) => ({
  day: d,
  visitors: Math.round(2400 + Math.sin(i * 0.9) * 800 + Math.random() * 600),
}));

const barHorizontal = [
  { region: "North America", value: 48200 },
  { region: "Europe", value: 39400 },
  { region: "Asia Pacific", value: 32100 },
  { region: "Latin America", value: 14800 },
  { region: "Middle East", value: 9200 },
  { region: "Africa", value: 5400 },
];

const barStacked = ["Q1", "Q2", "Q3", "Q4"].map((q, i) => ({
  quarter: q,
  starter: Math.round(8000 + i * 600),
  pro: Math.round(18000 + i * 1800),
  enterprise: Math.round(12000 + i * 2400),
}));

const barGrouped = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"].map((m, i) => ({
  month: m,
  web: Math.round(8000 + i * 600 + Math.sin(i) * 1200),
  mobile: Math.round(6400 + i * 800 + Math.sin(i) * 900),
  api: Math.round(4200 + i * 500 + Math.sin(i) * 600),
}));

const donutData = [
  { name: "Organic search", value: 38, color: "var(--primary)" },
  { name: "Direct", value: 24, color: "var(--info)" },
  { name: "Social", value: 18, color: "oklch(0.70 0.15 75)" },
  { name: "Email", value: 12, color: "oklch(0.62 0.18 305)" },
  { name: "Paid", value: 8, color: "oklch(0.62 0.18 25)" },
];

const radarData = ["Speed", "Reliability", "Security", "Pricing", "Support", "Features"].map((axis) => ({
  metric: axis,
  nexusgrid: Math.round(70 + Math.random() * 28),
  competitor: Math.round(60 + Math.random() * 28),
}));

function ChartCard({
  title,
  description,
  badge,
  children,
  action,
}: {
  title: string;
  description: string;
  badge?: string;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-1">
            <CardTitle className="text-base flex items-center gap-2">
              {title}
              {badge && <Badge variant="secondary" className="text-[10px]">{badge}</Badge>}
            </CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          {action}
        </div>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export default function ChartsPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Charts Showcase"
        description="All six shared chart components — area, line, bar, donut, radial and radar — with realistic data."
        icon={PieChart}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/charts" },
          { label: "Charts" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Chart data exported as CSV")}>
            <Download /> Export data
          </Button>
        }
      />

      {/* Intro strip */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
        <CardContent className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 py-4">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <p className="font-semibold">6 chart components, 9 demo configurations</p>
              <p className="text-sm text-muted-foreground">
                All charts are theme-aware and re-render on dark/light toggle.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">recharts</Badge>
            <Badge variant="secondary">responsive</Badge>
            <Badge variant="secondary">theme-aware</Badge>
          </div>
        </CardContent>
      </Card>

      {/* AreaTrendChart */}
      <div className="grid gap-6 lg:grid-cols-2">
        <ChartCard
          title="Area trend — single series"
          description="Monthly revenue with a gradient fill. Useful for showing growth over time."
          badge="AreaTrendChart"
        >
          <AreaTrendChart
            data={areaSingleSeries}
            xKey="month"
            series={[{ key: "revenue", name: "Revenue", color: "var(--primary)" }]}
            height={240}
          />
        </ChartCard>

        <ChartCard
          title="Area trend — multi series"
          description="Users, sessions and pageviews stacked with shared x-axis."
          badge="AreaTrendChart"
        >
          <AreaTrendChart
            data={areaMultiSeries}
            xKey="month"
            series={[
              { key: "users", name: "Users" },
              { key: "sessions", name: "Sessions" },
              { key: "pageviews", name: "Page views" },
            ]}
            height={240}
            stackId="stack"
          />
        </ChartCard>
      </div>

      {/* LineTrendChart */}
      <ChartCard
        title="Line trend — current vs previous"
        description="Compare this year to last year. The previous series uses a dashed line for visual distinction."
        badge="LineTrendChart"
        action={<Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent">+11.4% YoY</Badge>}
      >
        <LineTrendChart
          data={lineComparison}
          xKey="month"
          series={[
            { key: "current", name: "2026", color: "var(--primary)" },
            { key: "previous", name: "2025", color: "var(--muted-foreground)", dashed: true },
          ]}
          height={280}
        />
      </ChartCard>

      {/* BarTrendChart - 4 variants */}
      <div className="grid gap-6 lg:grid-cols-2">
        <ChartCard
          title="Bar chart — vertical"
          description="Daily visitors for the last week. Default rounded-top bars."
          badge="BarTrendChart"
        >
          <BarTrendChart
            data={barVertical}
            xKey="day"
            series={[{ key: "visitors", name: "Visitors", color: "var(--primary)" }]}
            height={240}
          />
        </ChartCard>

        <ChartCard
          title="Bar chart — horizontal"
          description="Revenue by region. Layout swaps to vertical with horizontal bars."
          badge="BarTrendChart"
        >
          <BarTrendChart
            data={barHorizontal}
            xKey="region"
            series={[{ key: "value", name: "Revenue", color: "var(--info)" }]}
            height={240}
            horizontal
          />
        </ChartCard>

        <ChartCard
          title="Bar chart — stacked"
          description="Quarterly revenue broken down by plan tier, stacked into a single column."
          badge="BarTrendChart"
        >
          <BarTrendChart
            data={barStacked}
            xKey="quarter"
            series={[
              { key: "starter", name: "Starter", color: "oklch(0.70 0.15 75)" },
              { key: "pro", name: "Pro", color: "var(--primary)" },
              { key: "enterprise", name: "Enterprise", color: "oklch(0.62 0.18 305)" },
            ]}
            height={240}
            stacked
          />
        </ChartCard>

        <ChartCard
          title="Bar chart — grouped"
          description="Web, mobile and API traffic grouped side by side for easy comparison."
          badge="BarTrendChart"
        >
          <BarTrendChart
            data={barGrouped}
            xKey="month"
            series={[
              { key: "web", name: "Web", color: "var(--primary)" },
              { key: "mobile", name: "Mobile", color: "var(--info)" },
              { key: "api", name: "API", color: "oklch(0.62 0.18 25)" },
            ]}
            height={240}
          />
        </ChartCard>
      </div>

      {/* DonutChart */}
      <div className="grid gap-6 lg:grid-cols-2">
        <ChartCard
          title="Donut chart — with center label"
          description="Traffic sources breakdown with a centered total in the middle."
          badge="DonutChart"
        >
          <DonutChart
            data={donutData}
            height={260}
            centerLabel="total visits"
            centerValue="284k"
          />
        </ChartCard>

        <ChartCard
          title="Donut chart — with legend"
          description="Same data, with the legend rendered below the donut for clarity."
          badge="DonutChart"
        >
          <div className="space-y-3">
            <DonutChart
              data={donutData}
              height={200}
              innerRadius={48}
              outerRadius={78}
            />
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              {donutData.map((d) => (
                <div key={d.name} className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-sm" style={{ background: d.color }} />
                  <span className="text-muted-foreground flex-1 truncate">{d.name}</span>
                  <span className="font-medium tabular-nums">{d.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </ChartCard>
      </div>

      {/* RadialProgress - multiple */}
      <ChartCard
        title="Radial progress — multiple values"
        description="Four circular meters for KPIs. Each can have a unique color, label and sublabel."
        badge="RadialProgress"
      >
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={84} color="var(--primary)" label="onboarding" sublabel="4/5 steps" size={140} />
            <p className="text-xs text-muted-foreground">Onboarding complete</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={62} color="var(--success)" label="quota" sublabel="this month" size={140} />
            <p className="text-xs text-muted-foreground">Quota attainment</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={28} color="var(--warning)" label="storage" sublabel="of 50 GB" size={140} />
            <p className="text-xs text-muted-foreground">Storage used</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={99} color="var(--info)" label="uptime" sublabel="30-day avg" size={140} />
            <p className="text-xs text-muted-foreground">Service uptime</p>
          </div>
        </div>
      </ChartCard>

      {/* RadarComparison */}
      <ChartCard
        title="Radar comparison — NexusGrid vs competitor"
        description="Six-axis comparison of product dimensions. Two overlapping polygons highlight strengths."
        badge="RadarComparison"
      >
        <RadarComparison
          data={radarData}
          axisKey="metric"
          series={[
            { key: "nexusgrid", name: "NexusGrid", color: "var(--primary)" },
            { key: "competitor", name: "Competitor A", color: "oklch(0.62 0.18 25)" },
          ]}
          height={320}
        />
      </ChartCard>

      {/* Combined mini-dashboard */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" /> Combined mini-dashboard
          </CardTitle>
          <CardDescription>
            All chart types composed into a single analytical surface — the typical real-world use case.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-baseline justify-between">
              <p className="text-sm font-medium">Revenue & sessions (12 months)</p>
              <Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent gap-1">
                <TrendingUp className="h-3 w-3" /> +12.4%
              </Badge>
            </div>
            <AreaTrendChart
              data={areaMultiSeries}
              xKey="month"
              series={[
                { key: "users", name: "Users" },
                { key: "sessions", name: "Sessions" },
                { key: "pageviews", name: "Page views" },
              ]}
              height={200}
            />
          </div>
          <div className="space-y-3">
            <p className="text-sm font-medium">Channel mix</p>
            <DonutChart data={donutData} height={180} innerRadius={40} outerRadius={70} centerLabel="visits" centerValue="284k" />
          </div>
          <div className="space-y-3">
            <p className="text-sm font-medium">Weekly visitors</p>
            <BarTrendChart
              data={barVertical}
              xKey="day"
              series={[{ key: "visitors", name: "Visitors", color: "var(--info)" }]}
              height={160}
              showAxis={false}
            />
          </div>
          <div className="space-y-3">
            <p className="text-sm font-medium">Quarterly by plan</p>
            <BarTrendChart
              data={barStacked}
              xKey="quarter"
              series={[
                { key: "starter", name: "Starter", color: "oklch(0.70 0.15 75)" },
                { key: "pro", name: "Pro", color: "var(--primary)" },
                { key: "enterprise", name: "Enterprise", color: "oklch(0.62 0.18 305)" },
              ]}
              height={160}
              stacked
            />
          </div>
          <div className="space-y-3">
            <p className="text-sm font-medium">Quota attainment</p>
            <div className="flex items-center justify-center py-2">
              <RadialProgress value={62} color="var(--success)" label="of target" size={130} />
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Charts page · AreaTrendChart · LineTrendChart · BarTrendChart (4 variants) · DonutChart · RadialProgress · RadarComparison
      </p>
    </div>
  );
}
