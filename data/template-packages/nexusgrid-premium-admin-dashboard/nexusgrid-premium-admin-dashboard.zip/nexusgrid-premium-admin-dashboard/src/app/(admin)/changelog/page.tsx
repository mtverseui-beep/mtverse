"use client";

import * as React from "react";
import {
  GitBranch,
  Bell,
  Sparkles,
  Wrench,
  ShieldCheck,
  Filter,
  ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type ChangeType = "new" | "improved" | "fixed" | "security";

type Change = { type: ChangeType; text: string };
type Release = {
  version: string;
  date: string;
  tag?: "major" | "minor" | "patch";
  summary: string;
  changes: Change[];
};

const RELEASES: Release[] = [
  {
    version: "v3.8.0",
    date: "Jul 1, 2026",
    tag: "minor",
    summary: "Real-time collaboration, redesigned dashboards, and 30+ performance improvements.",
    changes: [
      { type: "new", text: "Live cursors and presence indicators on dashboards — see where teammates are clicking in real time." },
      { type: "new", text: "Formula fields now support regex matching and array operations." },
      { type: "improved", text: "Dashboard load time reduced by 42% on average through query batching and caching." },
      { type: "improved", text: "Search index now updates within 2 seconds of record changes (down from 15s)." },
      { type: "fixed", text: "Resolved an issue where custom field dropdowns lost their value after sorting." },
      { type: "fixed", text: "Fixed timezone display for audit log entries when the browser tz differed from the workspace tz." },
      { type: "security", text: "Hardened session token rotation on device fingerprint change." },
    ],
  },
  {
    version: "v3.7.2",
    date: "Jun 18, 2026",
    tag: "patch",
    summary: "Bug fixes and stability improvements following the v3.7 release.",
    changes: [
      { type: "fixed", text: "CSV exports now correctly escape commas inside quoted string fields." },
      { type: "fixed", text: "Restored keyboard shortcut for 'collapse all' on Kanban view (Shift+Esc)." },
      { type: "fixed", text: "Email notifications no longer mark tasks as read when opened from the preview pane." },
      { type: "improved", text: "Webhook payload signing now includes a timestamp header for replay protection." },
    ],
  },
  {
    version: "v3.7.0",
    date: "Jun 2, 2026",
    tag: "minor",
    summary: "Workflows automation, Slack two-way sync, and a brand new reporting engine.",
    changes: [
      { type: "new", text: "Workflows builder with 18 triggers and 32 actions — automate any repetitive process visually." },
      { type: "new", text: "Two-way Slack sync: reply to NexusGrid threads directly from Slack channels." },
      { type: "new", text: "Reporting engine with pivot tables, cross-project aggregation, and scheduled exports." },
      { type: "improved", text: "Sidebar navigation now remembers your last position per workspace." },
      { type: "improved", text: "Reduced bundle size of the web app by 18% via tree-shaking and code-splitting." },
      { type: "fixed", text: "Resolved a race condition that could cause duplicate webhook deliveries under load." },
    ],
  },
  {
    version: "v3.6.0",
    date: "May 14, 2026",
    tag: "minor",
    summary: "Custom roles, granular permissions, and a redesigned account settings experience.",
    changes: [
      { type: "new", text: "Custom roles with per-resource permissions (view, edit, delete, share, export)." },
      { type: "new", text: "SSO with SAML 2.0 for Pro and Enterprise plans." },
      { type: "improved", text: "Account settings redesigned with clearer sections and inline help." },
      { type: "improved", text: "Audit log now supports full-text search and CSV export." },
      { type: "fixed", text: "Fixed an issue where guest users could see internal-only custom fields." },
      { type: "security", text: "Enforced CSP and added Subresource Integrity hashes for all third-party scripts." },
    ],
  },
  {
    version: "v3.5.3",
    date: "Apr 28, 2026",
    tag: "patch",
    summary: "Hotfix for webhook delivery failures and several UI polish items.",
    changes: [
      { type: "fixed", text: "Resolved webhook delivery failures for payloads exceeding 256 KB by switching to chunked transfer encoding." },
      { type: "fixed", text: "Fixed misaligned columns on the contacts table in Safari 17." },
      { type: "improved", text: "Empty states across the app now have clearer illustrations and CTAs." },
    ],
  },
  {
    version: "v3.5.0",
    date: "Apr 9, 2026",
    tag: "minor",
    summary: "Mobile app 2.0, dark mode refinements, and faster Kanban interactions.",
    changes: [
      { type: "new", text: "Native mobile app rebuilt from scratch for iOS and Android — offline-first with two-way sync." },
      { type: "new", text: "Dark mode now follows system theme by default with per-workspace overrides." },
      { type: "improved", text: "Kanban drag-and-drop is 3x more responsive on touch devices." },
      { type: "improved", text: "Notifications grouped by project to reduce inbox clutter." },
      { type: "fixed", text: "Resolved a memory leak in long-running browser sessions (>24h)." },
    ],
  },
  {
    version: "v3.4.0",
    date: "Mar 12, 2026",
    tag: "minor",
    summary: "AI-powered insights, smart task assignment, and natural language search.",
    changes: [
      { type: "new", text: "Ask the assistant: query your workspace in plain English — 'show overdue tasks assigned to me this week'." },
      { type: "new", text: "Smart assignment suggests the best teammate based on workload, skills, and recent activity." },
      { type: "improved", text: "Search ranking improved with semantic similarity and recent-activity boosting." },
      { type: "improved", text: "Calendar view supports drag-to-create with smart defaults (title, duration, assignee)." },
      { type: "security", text: "Rotated all signing keys for session tokens; previous tokens invalidated after 30-day grace period." },
    ],
  },
  {
    version: "v3.3.0",
    date: "Feb 18, 2026",
    tag: "minor",
    summary: "Project templates marketplace, time tracking, and resource planning.",
    changes: [
      { type: "new", text: "Templates marketplace with 80+ pre-built project templates from the community." },
      { type: "new", text: "Native time tracking with start/stop timers, manual entry, and weekly timesheets." },
      { type: "new", text: "Resource planning view to balance team capacity across projects." },
      { type: "improved", text: "Bulk edit now supports up to 500 records at once (up from 100)." },
      { type: "fixed", text: "Resolved an issue where date filters used the wrong timezone for end-of-day boundaries." },
    ],
  },
];

const TYPE_META: Record<ChangeType, { label: string; tone: "primary" | "success" | "warning" | "danger" | "violet"; icon: React.ElementType }> = {
  new: { label: "New", tone: "violet", icon: Sparkles },
  improved: { label: "Improved", tone: "primary", icon: ArrowRight },
  fixed: { label: "Fixed", tone: "success", icon: Wrench },
  security: { label: "Security", tone: "warning", icon: ShieldCheck },
};

const FILTERS: { id: ChangeType | "all"; label: string }[] = [
  { id: "all", label: "All updates" },
  { id: "new", label: "New" },
  { id: "improved", label: "Improved" },
  { id: "fixed", label: "Fixed" },
  { id: "security", label: "Security" },
];

export default function ChangelogPage() {
  const [filter, setFilter] = React.useState<ChangeType | "all">("all");

  const filteredReleases = React.useMemo(() => {
    if (filter === "all") return RELEASES;
    return RELEASES.map((r) => ({ ...r, changes: r.changes.filter((c) => c.type === filter) })).filter((r) => r.changes.length > 0);
  }, [filter]);

  return (
    <>
      <PageHeader
        title="Changelog"
        description="Every improvement, fix, and new feature we ship. Subscribe to never miss an update."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Changelog" }]}
        icon={GitBranch}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Subscribed to changelog", { description: "You'll get an email for every new release." })}>
            <Bell className="h-3.5 w-3.5" /> Subscribe to updates
          </Button>
        }
      />

      {/* FILTERS */}
      <Card className="mb-6">
        <CardContent className="p-3 flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground pl-1.5">
            <Filter className="h-3.5 w-3.5" /> Filter:
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-medium transition-all",
                  filter === f.id ? "bg-primary text-primary-foreground shadow-premium-xs" : "text-muted-foreground hover:text-foreground hover:bg-muted/60"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="ml-auto text-xs text-muted-foreground tabular-nums">{filteredReleases.length} releases</div>
        </CardContent>
      </Card>

      {/* TIMELINE */}
      <div className="relative">
        <div className="absolute left-[15px] sm:left-[19px] top-2 bottom-2 w-px bg-border" aria-hidden />
        <div className="space-y-6">
          {filteredReleases.map((r, idx) => (
            <div key={r.version} className="relative pl-12 sm:pl-16">
              {/* Version node */}
              <div className={cn(
                "absolute left-0 top-1 grid place-items-center h-8 w-8 sm:h-10 sm:w-10 rounded-full border-2 bg-card shadow-premium-xs",
                idx === 0 ? "border-primary text-primary" : "border-border text-muted-foreground"
              )}>
                <GitBranch className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                {idx === 0 && (
                  <span className="absolute -top-1.5 -right-1.5 grid place-items-center h-4 w-4 rounded-full bg-[color:var(--success)] text-white">
                    <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                  </span>
                )}
              </div>

              <Card className={cn(idx === 0 && "ring-1 ring-primary/30")}>
                <CardContent className="p-5">
                  {/* Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mb-3">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <h3 className="text-lg font-semibold tracking-tight tabular-nums">{r.version}</h3>
                      {r.tag && (
                        <StatusBadge tone={r.tag === "major" ? "violet" : r.tag === "minor" ? "primary" : "neutral"}>
                          {r.tag}
                        </StatusBadge>
                      )}
                      {idx === 0 && (
                        <Badge className="text-[10px] gap-1 bg-[color:var(--success)] text-white hover:bg-[color:var(--success)]">
                          <span className="h-1.5 w-1.5 rounded-full bg-white" /> Latest
                        </Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground sm:ml-auto flex items-center gap-1.5">
                      <span className="h-1 w-1 rounded-full bg-muted-foreground/50" /> {r.date}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{r.summary}</p>

                  {/* Changes */}
                  <ul className="space-y-2">
                    {r.changes.map((c, i) => {
                      const meta = TYPE_META[c.type];
                      return (
                        <li key={i} className="flex items-start gap-2.5 text-sm">
                          <span className={cn(
                            "inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wide shrink-0 mt-0.5 ring-1 ring-inset",
                            meta.tone === "violet" ? "bg-violet-500/12 text-violet-500 ring-violet-500/20" :
                            meta.tone === "primary" ? "bg-primary/12 text-primary ring-primary/20" :
                            meta.tone === "success" ? "bg-[color:var(--success)]/12 text-[color:var(--success)] ring-[color:var(--success)]/20" :
                            "bg-[color:var(--warning)]/15 text-[color:var(--warning)] ring-[color:var(--warning)]/25"
                          )}>
                            <meta.icon className="h-2.5 w-2.5" /> {meta.label}
                          </span>
                          <span className="text-foreground/90 leading-relaxed">{c.text}</span>
                        </li>
                      );
                    })}
                  </ul>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      {/* SUBSCRIBE CTA */}
      <Card className="mt-8 overflow-hidden relative border-primary/30">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/[0.06] via-violet-500/[0.03] to-transparent" aria-hidden />
        <CardContent className="relative p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/12 text-primary shrink-0">
            <Bell className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-semibold">Never miss a release</h3>
            <p className="text-sm text-muted-foreground mt-0.5">Get an email the moment we ship something new. No spam, unsubscribe anytime.</p>
          </div>
          <Button className="gap-1.5 shrink-0" onClick={() => toast.success("Subscribed to changelog", { description: "You'll get an email for every new release." })}>
            <Bell className="h-3.5 w-3.5" /> Subscribe
          </Button>
        </CardContent>
      </Card>
    </>
  );
}
