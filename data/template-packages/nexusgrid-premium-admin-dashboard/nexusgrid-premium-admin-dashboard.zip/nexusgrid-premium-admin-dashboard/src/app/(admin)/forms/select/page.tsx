"use client";

import * as React from "react";
import {
  ListChecks,
  Globe,
  Check,
  ChevronsUpDown,
  Search,
  X,
  Loader2,
  CornerDownLeft,
  Building2,
  User,
  Tag,
  Flag,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const COUNTRIES = [
  { code: "US", name: "United States", region: "Americas", dial: "+1" },
  { code: "CA", name: "Canada", region: "Americas", dial: "+1" },
  { code: "BR", name: "Brazil", region: "Americas", dial: "+55" },
  { code: "MX", name: "Mexico", region: "Americas", dial: "+52" },
  { code: "GB", name: "United Kingdom", region: "Europe", dial: "+44" },
  { code: "DE", name: "Germany", region: "Europe", dial: "+49" },
  { code: "FR", name: "France", region: "Europe", dial: "+33" },
  { code: "ES", name: "Spain", region: "Europe", dial: "+34" },
  { code: "IT", name: "Italy", region: "Europe", dial: "+39" },
  { code: "NL", name: "Netherlands", region: "Europe", dial: "+31" },
  { code: "SE", name: "Sweden", region: "Europe", dial: "+46" },
  { code: "JP", name: "Japan", region: "Asia", dial: "+81" },
  { code: "CN", name: "China", region: "Asia", dial: "+86" },
  { code: "IN", name: "India", region: "Asia", dial: "+91" },
  { code: "SG", name: "Singapore", region: "Asia", dial: "+65" },
  { code: "KR", name: "South Korea", region: "Asia", dial: "+82" },
  { code: "AU", name: "Australia", region: "Oceania", dial: "+61" },
  { code: "NZ", name: "New Zealand", region: "Oceania", dial: "+64" },
  { code: "ZA", name: "South Africa", region: "Africa", dial: "+27" },
  { code: "AE", name: "United Arab Emirates", region: "Middle East", dial: "+971" },
];

const TECH_TAGS = [
  "React", "TypeScript", "Next.js", "Tailwind CSS", "Node.js", "PostgreSQL",
  "Redis", "GraphQL", "Prisma", "tRPC", "Vite", "Zustand", "TanStack Query",
  "Vitest", "Playwright", "Docker", "Kubernetes", "AWS", "GCP", "Vercel",
];

const PROJECTS = [
  { id: "p1", name: "Aurora Dashboard", owner: "Sarah Chen" },
  { id: "p2", name: "Quantum API Gateway", owner: "Marcus Reyes" },
  { id: "p3", name: "Stellar Mobile App", owner: "Elena Petrov" },
  { id: "p4", name: "Nebula Analytics", owner: "James Okoro" },
  { id: "p5", name: "Pulsar Auth Service", owner: "Aiko Tanaka" },
  { id: "p6", name: "Orbit Design System", owner: "David Kim" },
  { id: "p7", name: "Cosmos Email Platform", owner: "Lena Hoffmann" },
  { id: "p8", name: "Vortex Streaming Engine", owner: "Raj Patel" },
];

function CountryGlyph({ code }: { code: string }) {
  return (
    <span className="inline-grid place-items-center h-4 w-6 rounded-sm bg-muted text-[8px] font-bold text-muted-foreground border">
      {code}
    </span>
  );
}

export default function SelectComboboxPage() {
  const [basic, setBasic] = React.useState("express");
  const [grouped, setGrouped] = React.useState("us");
  const [combo, setCombo] = React.useState("JP");
  const [comboOpen, setComboOpen] = React.useState(false);
  const [multi, setMulti] = React.useState<string[]>(["React", "TypeScript", "Tailwind CSS"]);
  const [multiInput, setMultiInput] = React.useState("");
  const [asyncOpen, setAsyncOpen] = React.useState(false);
  const [asyncQuery, setAsyncQuery] = React.useState("");
  const [asyncLoading, setAsyncLoading] = React.useState(false);
  const [asyncItems, setAsyncItems] = React.useState<typeof PROJECTS>([]);
  const [asyncSelected, setAsyncSelected] = React.useState<(typeof PROJECTS)[number] | null>(null);

  // Simulate async loading
  React.useEffect(() => {
    if (!asyncOpen) return;
    setAsyncLoading(true);
    setAsyncItems([]);
    const t = setTimeout(() => {
      const q = asyncQuery.toLowerCase();
      const filtered = PROJECTS.filter(
        (p) => p.name.toLowerCase().includes(q) || p.owner.toLowerCase().includes(q)
      );
      setAsyncItems(filtered);
      setAsyncLoading(false);
    }, 650);
    return () => clearTimeout(t);
  }, [asyncOpen, asyncQuery]);

  const addMulti = (t: string) => {
    if (!multi.includes(t)) setMulti([...multi, t]);
  };
  const removeMulti = (t: string) => setMulti(multi.filter((x) => x !== t));

  const filteredTags = TECH_TAGS.filter((t) => !multi.includes(t)).filter((t) =>
    multiInput ? t.toLowerCase().includes(multiInput.toLowerCase()) : true
  );

  return (
    <>
      <PageHeader
        title="Select & Combobox"
        description="Five selection patterns — from a basic dropdown to async comboboxes with remote data."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Select & Combobox" }]}
        icon={ListChecks}
        actions={<Badge variant="secondary" className="text-[10px] uppercase tracking-wide">5 patterns</Badge>}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* BASIC */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">1</span>
              Basic Select
            </CardTitle>
            <CardDescription>A native-feeling dropdown with keyboard navigation and search.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="grid gap-1.5">
              <Label className="text-xs">Shipping method</Label>
              <Select value={basic} onValueChange={setBasic}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard shipping (3-5 days)</SelectItem>
                  <SelectItem value="express">Express shipping (1-2 days)</SelectItem>
                  <SelectItem value="overnight">Overnight (next day)</SelectItem>
                  <SelectItem value="pickup">Local pickup</SelectItem>
                  <SelectItem value="digital" disabled>Digital delivery (out of stock)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Selected value</span><span className="font-mono">{basic}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Label</span><span className="font-medium capitalize">{basic}</span></div>
            </div>
          </CardContent>
        </Card>

        {/* COMBOBOX */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">2</span>
              Searchable Combobox
            </CardTitle>
            <CardDescription>Popover + Command palette with fuzzy search across 20 countries.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="grid gap-1.5">
              <Label className="text-xs flex items-center gap-1.5">
                <Globe className="h-3.5 w-3.5 text-muted-foreground" /> Country
              </Label>
              <Popover open={comboOpen} onOpenChange={setComboOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={comboOpen}
                    className="w-full justify-between font-normal"
                  >
                    {combo ? (
                      <span className="flex items-center gap-2">
                        <CountryGlyph code={combo} />
                        {COUNTRIES.find((c) => c.code === combo)?.name}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">Select country…</span>
                    )}
                    <ChevronsUpDown className="h-4 w-4 opacity-50 shrink-0" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[var(--radix-popover-trigger-width)] min-w-[260px] p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search country…" />
                    <CommandList className="max-h-64">
                      <CommandEmpty>No country found.</CommandEmpty>
                      {["Americas", "Europe", "Asia", "Oceania", "Africa", "Middle East"].map((region) => {
                        const items = COUNTRIES.filter((c) => c.region === region);
                        if (items.length === 0) return null;
                        return (
                          <CommandGroup key={region} heading={region}>
                            {items.map((c) => (
                              <CommandItem
                                key={c.code}
                                value={`${c.name} ${c.code} ${c.region}`}
                                onSelect={() => {
                                  setCombo(c.code);
                                  setComboOpen(false);
                                  toast.success(`Selected ${c.name}`);
                                }}
                                className="gap-2"
                              >
                                <CountryGlyph code={c.code} />
                                <span className="flex-1">{c.name}</span>
                                <span className="text-[10px] text-muted-foreground font-mono">{c.dial}</span>
                                <Check className={cn("h-4 w-4", combo === c.code ? "opacity-100" : "opacity-0")} />
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        );
                      })}
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Country code</span><span className="font-mono">{combo}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Dial code</span><span className="font-mono">{COUNTRIES.find((c) => c.code === combo)?.dial}</span></div>
            </div>
          </CardContent>
        </Card>

        {/* MULTI-SELECT TAGS */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">3</span>
              Multi-Select with Tags
            </CardTitle>
            <CardDescription>Chip-based multi selection with type-ahead filtering.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="grid gap-1.5">
              <Label className="text-xs flex items-center gap-1.5">
                <Tag className="h-3.5 w-3.5 text-muted-foreground" /> Technology stack
              </Label>
              <div className="flex flex-wrap items-center gap-1.5 rounded-md border bg-background p-2 min-h-9">
                {multi.map((t) => (
                  <Badge key={t} variant="secondary" className="gap-1 pr-1 text-[11px]">
                    {t}
                    <button
                      type="button"
                      onClick={() => removeMulti(t)}
                      className="grid place-items-center h-4 w-4 rounded-sm hover:bg-background/80"
                      aria-label={`Remove ${t}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
                <div className="relative flex-1 min-w-[120px]">
                  <input
                    value={multiInput}
                    onChange={(e) => setMultiInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && multiInput) {
                        e.preventDefault();
                        const match = TECH_TAGS.find(
                          (t) => t.toLowerCase() === multiInput.toLowerCase() && !multi.includes(t)
                        );
                        if (match) {
                          addMulti(match);
                          setMultiInput("");
                        }
                      }
                      if (e.key === "Backspace" && !multiInput && multi.length > 0) {
                        removeMulti(multi[multi.length - 1]);
                      }
                    }}
                    placeholder={multi.length === 0 ? "Add a technology…" : "Add more…"}
                    className="w-full bg-transparent outline-none text-sm placeholder:text-muted-foreground"
                  />
                </div>
              </div>
              {multiInput && filteredTags.length > 0 && (
                <div className="rounded-md border bg-popover p-1 shadow-sm grid gap-0.5 max-h-44 overflow-y-auto">
                  {filteredTags.slice(0, 6).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => { addMulti(t); setMultiInput(""); }}
                      className="flex items-center justify-between gap-2 text-xs rounded-sm px-2 py-1.5 hover:bg-accent text-left"
                    >
                      <span>{t}</span>
                      <CornerDownLeft className="h-3 w-3 text-muted-foreground" />
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Selected count</span><span className="font-mono">{multi.length} / 20</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Available</span><span className="font-mono">{TECH_TAGS.length - multi.length}</span></div>
            </div>
          </CardContent>
        </Card>

        {/* GROUPED SELECT */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">4</span>
              Grouped Select
            </CardTitle>
            <CardDescription>Options organised by region with labels and separators.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="grid gap-1.5">
              <Label className="text-xs flex items-center gap-1.5">
                <Flag className="h-3.5 w-3.5 text-muted-foreground" /> Country
              </Label>
              <Select value={grouped} onValueChange={setGrouped}>
                <SelectTrigger className="w-full">
                  <span className="flex items-center gap-2">
                    <CountryGlyph code={grouped} />
                    <SelectValue />
                  </span>
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Americas</SelectLabel>
                    <SelectItem value="us"><CountryGlyph code="US" /> United States</SelectItem>
                    <SelectItem value="ca"><CountryGlyph code="CA" /> Canada</SelectItem>
                    <SelectItem value="br"><CountryGlyph code="BR" /> Brazil</SelectItem>
                    <SelectItem value="mx"><CountryGlyph code="MX" /> Mexico</SelectItem>
                  </SelectGroup>
                  <SelectSeparator />
                  <SelectGroup>
                    <SelectLabel>Europe</SelectLabel>
                    <SelectItem value="gb"><CountryGlyph code="GB" /> United Kingdom</SelectItem>
                    <SelectItem value="de"><CountryGlyph code="DE" /> Germany</SelectItem>
                    <SelectItem value="fr"><CountryGlyph code="FR" /> France</SelectItem>
                    <SelectItem value="nl"><CountryGlyph code="NL" /> Netherlands</SelectItem>
                  </SelectGroup>
                  <SelectSeparator />
                  <SelectGroup>
                    <SelectLabel>Asia &amp; Oceania</SelectLabel>
                    <SelectItem value="jp"><CountryGlyph code="JP" /> Japan</SelectItem>
                    <SelectItem value="sg"><CountryGlyph code="SG" /> Singapore</SelectItem>
                    <SelectItem value="au"><CountryGlyph code="AU" /> Australia</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Country code</span><span className="font-mono">{grouped.toUpperCase()}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Region</span><span className="font-medium">
                {COUNTRIES.find((c) => c.code === grouped.toUpperCase())?.region ?? "—"}
              </span></div>
            </div>
          </CardContent>
        </Card>

        {/* ASYNC COMBOBOX */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">5</span>
              Async Combobox
            </CardTitle>
            <CardDescription>Simulates fetching options from a remote API with loading and empty states.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label className="text-xs flex items-center gap-1.5">
                <Search className="h-3.5 w-3.5 text-muted-foreground" /> Search projects
              </Label>
              <Popover open={asyncOpen} onOpenChange={setAsyncOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" className="w-full justify-between font-normal">
                    {asyncSelected ? (
                      <span className="flex items-center gap-2 min-w-0">
                        <Building2 className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <span className="truncate">{asyncSelected.name}</span>
                      </span>
                    ) : (
                      <span className="text-muted-foreground">Search for a project…</span>
                    )}
                    <ChevronsUpDown className="h-4 w-4 opacity-50 shrink-0" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[var(--radix-popover-trigger-width)] min-w-[320px] p-0" align="start">
                  <Command shouldFilter={false}>
                    <CommandInput
                      placeholder="Type to search…"
                      value={asyncQuery}
                      onValueChange={setAsyncQuery}
                    />
                    <CommandList className="max-h-64">
                      {asyncLoading ? (
                        <div className="py-8 grid place-items-center gap-2 text-xs text-muted-foreground">
                          <Loader2 className="h-5 w-5 animate-spin text-primary" />
                          Loading projects…
                        </div>
                      ) : asyncItems.length === 0 ? (
                        <div className="py-8 grid place-items-center gap-2 text-xs text-muted-foreground">
                          <Search className="h-5 w-5 opacity-50" />
                          No projects match "{asyncQuery}"
                        </div>
                      ) : (
                        <CommandGroup heading={`${asyncItems.length} result${asyncItems.length > 1 ? "s" : ""}`}>
                          {asyncItems.map((p) => (
                            <CommandItem
                              key={p.id}
                              value={p.id}
                              onSelect={() => {
                                setAsyncSelected(p);
                                setAsyncOpen(false);
                                toast.success(`Selected ${p.name}`);
                              }}
                              className="gap-2"
                            >
                              <div className="grid place-items-center h-7 w-7 rounded-md bg-primary/10 text-primary shrink-0">
                                <Building2 className="h-3.5 w-3.5" />
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="text-xs font-medium truncate">{p.name}</p>
                                <p className="text-[10px] text-muted-foreground truncate flex items-center gap-1">
                                  <User className="h-2.5 w-2.5" /> {p.owner}
                                </p>
                              </div>
                              <Check className={cn("h-4 w-4", asyncSelected?.id === p.id ? "opacity-100" : "opacity-0")} />
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      )}
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Selected</span><span className="font-medium truncate max-w-[60%]">{asyncSelected?.name ?? "—"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Owner</span><span className="font-medium">{asyncSelected?.owner ?? "—"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Project ID</span><span className="font-mono">{asyncSelected?.id ?? "—"}</span></div>
              <Separator className="my-1" />
              <p className="text-[10px] text-muted-foreground">Tip: open the dropdown and type "aurora" or "auth" to filter results.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
