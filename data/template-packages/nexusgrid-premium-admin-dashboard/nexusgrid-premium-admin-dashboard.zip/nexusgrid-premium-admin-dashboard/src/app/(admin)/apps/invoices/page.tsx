"use client";

import * as React from "react";
import {
  FileSpreadsheet,
  Plus,
  Eye,
  Download,
  Send,
  XCircle,
  DollarSign,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Trash2,
  MoreHorizontal,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { KpiCard, Sparkline } from "@/components/common/kpi-card";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { AreaTrendChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type InvoiceStatus = "paid" | "pending" | "overdue" | "draft";

type Invoice = {
  id: string;
  client: string;
  clientAvatar: string;
  issueDate: string;
  dueDate: string;
  amount: number;
  tax: number;
  status: InvoiceStatus;
};

const invoices: Invoice[] = [
  { id: "INV-20841", client: "Cloudflare Inc", clientAvatar: "https://images.unsplash.com/photo-1551803091-e20673f15770?w=40&h=40&fit=crop", issueDate: "Jul 14, 2026", dueDate: "Aug 13, 2026", amount: 4820, tax: 385.6, status: "pending" },
  { id: "INV-20840", client: "Stripe", clientAvatar: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=40&h=40&fit=crop", issueDate: "Jul 12, 2026", dueDate: "Aug 11, 2026", amount: 12400, tax: 992, status: "pending" },
  { id: "INV-20839", client: "Notion", clientAvatar: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=40&h=40&fit=crop", issueDate: "Jul 10, 2026", dueDate: "Aug 09, 2026", amount: 3600, tax: 288, status: "pending" },
  { id: "INV-20838", client: "Freshworks", clientAvatar: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=40&h=40&fit=crop", issueDate: "Jul 08, 2026", dueDate: "Aug 07, 2026", amount: 7820, tax: 625.6, status: "pending" },
  { id: "INV-20837", client: "Hooli", clientAvatar: "https://images.unsplash.com/photo-1620288627229-c5b1d2f80c8f?w=40&h=40&fit=crop", issueDate: "Jul 05, 2026", dueDate: "Jul 20, 2026", amount: 18920, tax: 1513.6, status: "overdue" },
  { id: "INV-20836", client: "Acme Corp", clientAvatar: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=40&h=40&fit=crop", issueDate: "Jul 03, 2026", dueDate: "Aug 02, 2026", amount: 6240, tax: 499.2, status: "pending" },
  { id: "INV-20835", client: "Globex Corp", clientAvatar: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=40&h=40&fit=crop", issueDate: "Jul 01, 2026", dueDate: "Jul 16, 2026", amount: 9420, tax: 753.6, status: "overdue" },
  { id: "INV-20834", client: "Initech", clientAvatar: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=40&h=40&fit=crop", issueDate: "Jun 28, 2026", dueDate: "Jul 28, 2026", amount: 5120, tax: 409.6, status: "paid" },
  { id: "INV-20833", client: "Klarna", clientAvatar: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=40&h=40&fit=crop", issueDate: "Jun 25, 2026", dueDate: "Jul 25, 2026", amount: 14200, tax: 1136, status: "paid" },
  { id: "INV-20832", client: "Rakuten", clientAvatar: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=40&h=40&fit=crop", issueDate: "Jun 22, 2026", dueDate: "Jul 22, 2026", amount: 6840, tax: 547.2, status: "paid" },
  { id: "INV-20831", client: "Doctolib", clientAvatar: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=40&h=40&fit=crop", issueDate: "Jun 20, 2026", dueDate: "Jul 20, 2026", amount: 11420, tax: 913.6, status: "paid" },
  { id: "INV-20830", client: "Soylent", clientAvatar: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=40&h=40&fit=crop", issueDate: "Jun 18, 2026", dueDate: "Jul 18, 2026", amount: 8800, tax: 704, status: "paid" },
  { id: "INV-20829", client: "Careem", clientAvatar: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=40&h=40&fit=crop", issueDate: "Jun 15, 2026", dueDate: "Jul 15, 2026", amount: 4280, tax: 342.4, status: "paid" },
  { id: "INV-20828", client: "Patreon", clientAvatar: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=40&h=40&fit=crop", issueDate: "Jun 12, 2026", dueDate: "Jul 12, 2026", amount: 3640, tax: 291.2, status: "paid" },
  { id: "INV-DRAFT-001", client: "Mercari", clientAvatar: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=40&h=40&fit=crop", issueDate: "—", dueDate: "—", amount: 0, tax: 0, status: "draft" },
];

const statusConfig: Record<InvoiceStatus, { tone: StatusTone; label: string; color: string }> = {
  paid: { tone: "success", label: "Paid", color: "var(--success)" },
  pending: { tone: "info", label: "Pending", color: "var(--info)" },
  overdue: { tone: "danger", label: "Overdue", color: "var(--destructive)" },
  draft: { tone: "neutral", label: "Draft", color: "var(--muted-foreground)" },
};

const monthlyData = [
  { month: "Jan", total: 38400, paid: 32200 },
  { month: "Feb", total: 42100, paid: 39800 },
  { month: "Mar", total: 51800, paid: 44200 },
  { month: "Apr", total: 47600, paid: 45000 },
  { month: "May", total: 58200, paid: 51200 },
  { month: "Jun", total: 63900, paid: 58100 },
  { month: "Jul", total: 71820, paid: 38860 },
];

const clients = ["Cloudflare Inc", "Stripe", "Notion", "Freshworks", "Hooli", "Acme Corp", "Globex Corp", "Initech", "Klarna", "Rakuten"];

export default function InvoicesPage() {
  const [createOpen, setCreateOpen] = React.useState(false);
  const [lineItems, setLineItems] = React.useState([
    { id: "1", description: "Platform subscription — Enterprise", qty: 1, rate: 4200 },
    { id: "2", description: "Premium support package", qty: 1, rate: 1200 },
  ]);

  const totalPaid = invoices.filter((i) => i.status === "paid").reduce((s, i) => s + i.amount + i.tax, 0);
  const totalOutstanding = invoices.filter((i) => i.status === "pending").reduce((s, i) => s + i.amount + i.tax, 0);
  const totalOverdue = invoices.filter((i) => i.status === "overdue").reduce((s, i) => s + i.amount + i.tax, 0);

  function addLineItem() {
    setLineItems((prev) => [...prev, { id: `${prev.length + 1}`, description: "", qty: 1, rate: 0 }]);
  }
  function removeLineItem(id: string) {
    setLineItems((prev) => prev.filter((l) => l.id !== id));
  }
  function updateLineItem(id: string, field: string, value: any) {
    setLineItems((prev) => prev.map((l) => (l.id === id ? { ...l, [field]: value } : l)));
  }

  const subtotal = lineItems.reduce((s, l) => s + l.qty * l.rate, 0);
  const taxAmount = subtotal * 0.08;
  const grandTotal = subtotal + taxAmount;

  const columns: Column<Invoice>[] = [
    {
      key: "id",
      header: "Invoice #",
      sortable: true,
      sortAccessor: (r) => r.id,
      cell: (r) => <span className="font-mono text-xs font-medium">{r.id}</span>,
    },
    {
      key: "client",
      header: "Client",
      sortable: true,
      sortAccessor: (r) => r.client,
      filterable: true,
      filterAccessor: (r) => r.client,
      filterOptions: clients.map((c) => ({ label: c, value: c })),
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7">
            <AvatarImage src={r.clientAvatar} alt={r.client} />
            <AvatarFallback className="text-[10px]">{r.client.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium">{r.client}</span>
        </div>
      ),
    },
    {
      key: "issueDate",
      header: "Issue Date",
      sortable: true,
      sortAccessor: (r) => r.issueDate,
      cell: (r) => <span className="text-xs text-muted-foreground tabular-nums">{r.issueDate}</span>,
      hideable: true,
    },
    {
      key: "dueDate",
      header: "Due Date",
      sortable: true,
      sortAccessor: (r) => r.dueDate,
      cell: (r) => <span className={cn("text-xs tabular-nums", r.status === "overdue" ? "text-destructive font-medium" : "text-muted-foreground")}>{r.dueDate}</span>,
    },
    {
      key: "amount",
      header: "Amount",
      sortable: true,
      sortAccessor: (r) => r.amount,
      align: "right",
      cell: (r) => <span className="text-sm tabular-nums font-medium">${r.amount.toLocaleString()}</span>,
    },
    {
      key: "tax",
      header: "Tax",
      sortable: true,
      sortAccessor: (r) => r.tax,
      align: "right",
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">${r.tax.toFixed(2)}</span>,
      hideable: true,
    },
    {
      key: "total",
      header: "Total",
      sortable: true,
      sortAccessor: (r) => r.amount + r.tax,
      align: "right",
      cell: (r) => <span className="text-sm tabular-nums font-semibold">${(r.amount + r.tax).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>,
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Paid", value: "paid" },
        { label: "Pending", value: "pending" },
        { label: "Overdue", value: "overdue" },
        { label: "Draft", value: "draft" },
      ],
      align: "center",
      cell: (r) => <StatusBadge tone={statusConfig[r.status].tone} dot>{statusConfig[r.status].label}</StatusBadge>,
    },
    {
      key: "actions",
      header: "",
      align: "right",
      hideable: false,
      cell: (r) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={(e) => e.stopPropagation()}><MoreHorizontal className="h-3.5 w-3.5" /></Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => toast.message(`Viewing ${r.id}`)}><Eye className="h-3.5 w-3.5 mr-2" />View</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast.success(`Downloading ${r.id}`)}><Download className="h-3.5 w-3.5 mr-2" />Download PDF</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast.success(`Sent ${r.id} to client`)}><Send className="h-3.5 w-3.5 mr-2" />Send to client</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => toast.success("Invoice voided")}><XCircle className="h-3.5 w-3.5 mr-2" />Void invoice</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  return (
    <>
      <PageHeader
        title="Invoices"
        description="Create, track, and manage customer invoices with one-click exports."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "Invoices" }]}
        icon={FileSpreadsheet}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setCreateOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> Create Invoice
          </Button>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Total Invoices"
          value={invoices.length.toString()}
          icon={FileSpreadsheet}
          accent="primary"
          trend={{ value: 12.4, direction: "up" }}
          hint="vs last month"
          sparkline={<Sparkline data={monthlyData.map((d) => d.total / 1000)} color="var(--primary)" />}
        />
        <KpiCard
          label="Paid"
          value={`$${(totalPaid / 1000).toFixed(1)}K`}
          icon={CheckCircle2}
          accent="success"
          trend={{ value: 18.2, direction: "up" }}
          hint={`${invoices.filter((i) => i.status === "paid").length} invoices`}
        />
        <KpiCard
          label="Outstanding"
          value={`$${(totalOutstanding / 1000).toFixed(1)}K`}
          icon={Clock}
          accent="info"
          trend={{ value: 4.6, direction: "down" }}
          hint="due in 30 days"
          positive
        />
        <KpiCard
          label="Overdue"
          value={`$${(totalOverdue / 1000).toFixed(1)}K`}
          icon={AlertTriangle}
          accent="warning"
          trend={{ value: 2.1, direction: "up" }}
          hint={`${invoices.filter((i) => i.status === "overdue").length} invoices`}
        />
      </div>

      {/* Revenue chart */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
          <div>
            <CardTitle className="text-base">Invoice Revenue</CardTitle>
            <CardDescription>Billed vs. collected amounts over the last 7 months.</CardDescription>
          </div>
          <StatusBadge tone="success" dot>+18.2% MoM</StatusBadge>
        </CardHeader>
        <CardContent>
          <AreaTrendChart
            data={monthlyData}
            xKey="month"
            series={[
              { key: "total", name: "Billed ($)", color: "var(--primary)" },
              { key: "paid", name: "Collected ($)", color: "var(--success)" },
            ]}
            height={280}
          />
        </CardContent>
      </Card>

      {/* Table */}
      <DataTable
        title="All Invoices"
        data={invoices}
        columns={columns}
        pageSize={10}
        getRowId={(r) => r.id}
        initialSort={{ key: "issueDate", direction: "desc" }}
        onRowClick={(r) => toast.message(`Viewing ${r.id}`)}
      />

      {/* Create invoice dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-[680px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Invoice</DialogTitle>
            <DialogDescription>Build a new invoice with line items and tax calculation.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Client + dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Client</Label>
                <Select defaultValue="Cloudflare Inc">
                  <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {clients.map((c) => <SelectItem key={c} value={c} className="text-sm">{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Issue Date</Label>
                <Input type="date" defaultValue="2026-07-14" className="h-9 text-sm" />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Due Date</Label>
                <Input type="date" defaultValue="2026-08-13" className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Tax Rate (%)</Label>
                <Input type="number" defaultValue="8" className="h-9 text-sm" />
              </div>
            </div>

            {/* Line items */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-xs">Line Items</Label>
                <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={addLineItem}><Plus className="h-3 w-3" /> Add item</Button>
              </div>
              <div className="rounded-lg border border-border overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-muted/40">
                    <tr>
                      <th className="text-left font-medium uppercase tracking-wide text-muted-foreground px-3 py-2">Description</th>
                      <th className="text-right font-medium uppercase tracking-wide text-muted-foreground px-3 py-2 w-16">Qty</th>
                      <th className="text-right font-medium uppercase tracking-wide text-muted-foreground px-3 py-2 w-24">Rate</th>
                      <th className="text-right font-medium uppercase tracking-wide text-muted-foreground px-3 py-2 w-24">Total</th>
                      <th className="w-10" />
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {lineItems.map((l) => (
                      <tr key={l.id}>
                        <td className="px-2 py-1.5">
                          <Input
                            value={l.description}
                            onChange={(e) => updateLineItem(l.id, "description", e.target.value)}
                            placeholder="Item description"
                            className="h-7 text-xs border-0 bg-transparent focus-visible:ring-1"
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <Input
                            type="number"
                            value={l.qty}
                            onChange={(e) => updateLineItem(l.id, "qty", Number(e.target.value))}
                            className="h-7 text-xs text-right border-0 bg-transparent focus-visible:ring-1"
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <Input
                            type="number"
                            value={l.rate}
                            onChange={(e) => updateLineItem(l.id, "rate", Number(e.target.value))}
                            className="h-7 text-xs text-right border-0 bg-transparent focus-visible:ring-1"
                          />
                        </td>
                        <td className="px-3 py-1.5 text-right tabular-nums font-medium">${(l.qty * l.rate).toLocaleString()}</td>
                        <td className="px-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => removeLineItem(l.id)}><Trash2 className="h-3 w-3 text-muted-foreground" /></Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label className="text-xs">Notes (optional)</Label>
              <Textarea placeholder="Thank you for your business. Payment due within 30 days." rows={2} className="text-sm" />
            </div>

            {/* Totals */}
            <div className="rounded-lg bg-muted/40 p-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="tabular-nums font-medium">${subtotal.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Tax (8%)</span>
                <span className="tabular-nums font-medium">${taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <Separator className="my-1" />
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Total</span>
                <span className="text-lg font-semibold tabular-nums">${grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => { toast.success("Saved as draft"); setCreateOpen(false); }}>Save Draft</Button>
            <div className="flex-1" />
            <Button variant="outline" size="sm" onClick={() => toast.success("Preview opened")}>Preview</Button>
            <Button size="sm" className="gap-1.5" onClick={() => { toast.success("Invoice created and sent"); setCreateOpen(false); }}>
              <Send className="h-3.5 w-3.5" /> Create & Send
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}


