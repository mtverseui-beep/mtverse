"use client";

import * as React from "react";
import {
  Filter,
  Search,
  X,
  Calendar,
  ChevronDown,
  Check,
  CalendarDays,
  Hash,
  SlidersHorizontal,
  Users,
  Tag,
  RotateCcw,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type OrderStatus = "delivered" | "shipped" | "processing" | "pending" | "cancelled";
type PaymentStatus = "paid" | "pending" | "refunded" | "failed";
type Channel = "web" | "mobile" | "in_store" | "marketplace";

type Customer = {
  id: string;
  name: string;
  email: string;
  city: string;
  orders: number;
  totalSpent: number;
  lastOrder: string; // ISO date
  status: OrderStatus;
  payment: PaymentStatus;
  channel: Channel;
  tags: string[];
};

const customers: Customer[] = [
  { id: "CUS-501", name: "Sarah Chen", email: "sarah.chen@example.com", city: "San Francisco", orders: 24, totalSpent: 4892.5, lastOrder: "2026-07-12", status: "delivered", payment: "paid", channel: "web", tags: ["VIP", "Newsletter"] },
  { id: "CUS-502", name: "Marcus Reyes", email: "marcus.r@example.com", city: "Austin", orders: 8, totalSpent: 1240.0, lastOrder: "2026-07-10", status: "shipped", payment: "paid", channel: "mobile", tags: ["Newsletter"] },
  { id: "CUS-503", name: "Elena Petrov", email: "elena.petrov@example.com", city: "Seattle", orders: 42, totalSpent: 12480.75, lastOrder: "2026-07-13", status: "delivered", payment: "paid", channel: "web", tags: ["VIP", "Wholesale"] },
  { id: "CUS-504", name: "James Okoro", email: "j.okoro@example.com", city: "New York", orders: 3, totalSpent: 312.0, lastOrder: "2026-07-08", status: "cancelled", payment: "refunded", channel: "marketplace", tags: [] },
  { id: "CUS-505", name: "Aiko Tanaka", email: "aiko.t@example.com", city: "Portland", orders: 17, totalSpent: 3284.4, lastOrder: "2026-07-11", status: "processing", payment: "pending", channel: "web", tags: ["VIP"] },
  { id: "CUS-506", name: "David Kim", email: "d.kim@example.com", city: "Los Angeles", orders: 12, totalSpent: 2104.0, lastOrder: "2026-07-09", status: "delivered", payment: "paid", channel: "mobile", tags: ["Newsletter"] },
  { id: "CUS-507", name: "Lena Hoffmann", email: "lena.h@example.com", city: "Chicago", orders: 29, totalSpent: 6782.0, lastOrder: "2026-07-13", status: "shipped", payment: "paid", channel: "in_store", tags: ["VIP", "Wholesale"] },
  { id: "CUS-508", name: "Raj Patel", email: "raj.patel@example.com", city: "Houston", orders: 6, totalSpent: 742.5, lastOrder: "2026-07-07", status: "pending", payment: "pending", channel: "web", tags: [] },
  { id: "CUS-509", name: "Mei Lin", email: "mei.lin@example.com", city: "Boston", orders: 38, totalSpent: 9842.0, lastOrder: "2026-07-12", status: "delivered", payment: "paid", channel: "mobile", tags: ["VIP", "Newsletter"] },
  { id: "CUS-510", name: "Carlos Mendez", email: "c.mendez@example.com", city: "Miami", orders: 4, totalSpent: 588.2, lastOrder: "2026-07-06", status: "delivered", payment: "paid", channel: "in_store", tags: [] },
  { id: "CUS-511", name: "Priya Sharma", email: "priya.s@example.com", city: "Dallas", orders: 51, totalSpent: 15240.0, lastOrder: "2026-07-13", status: "shipped", payment: "paid", channel: "web", tags: ["VIP", "Wholesale", "Newsletter"] },
  { id: "CUS-512", name: "Noah Williams", email: "noah.w@example.com", city: "Denver", orders: 2, totalSpent: 144.99, lastOrder: "2026-07-04", status: "cancelled", payment: "failed", channel: "marketplace", tags: [] },
  { id: "CUS-513", name: "Sofia Rossi", email: "sofia.rossi@example.com", city: "Phoenix", orders: 21, totalSpent: 4128.0, lastOrder: "2026-07-11", status: "delivered", payment: "paid", channel: "mobile", tags: ["Newsletter"] },
  { id: "CUS-514", name: "Ahmed Hassan", email: "ahmed.h@example.com", city: "Atlanta", orders: 9, totalSpent: 1845.5, lastOrder: "2026-07-10", status: "processing", payment: "pending", channel: "web", tags: [] },
  { id: "CUS-515", name: "Yuki Sato", email: "yuki.sato@example.com", city: "San Diego", orders: 16, totalSpent: 3692.25, lastOrder: "2026-07-09", status: "delivered", payment: "paid", channel: "in_store", tags: ["VIP"] },
  { id: "CUS-516", name: "Olivia Bennett", email: "olivia.b@example.com", city: "Washington", orders: 33, totalSpent: 7984.0, lastOrder: "2026-07-12", status: "shipped", payment: "paid", channel: "web", tags: ["VIP", "Newsletter"] },
  { id: "CUS-517", name: "Lucas Moreau", email: "lucas.m@example.com", city: "Las Vegas", orders: 7, totalSpent: 1218.0, lastOrder: "2026-07-08", status: "delivered", payment: "paid", channel: "marketplace", tags: [] },
  { id: "CUS-518", name: "Isabella Costa", email: "i.costa@example.com", city: "Orlando", orders: 26, totalSpent: 5612.0, lastOrder: "2026-07-13", status: "delivered", payment: "paid", channel: "mobile", tags: ["Newsletter"] },
];

const statusToneMap: Record<OrderStatus, "success" | "info" | "primary" | "warning" | "danger"> = {
  delivered: "success",
  shipped: "primary",
  processing: "info",
  pending: "warning",
  cancelled: "danger",
};
const paymentToneMap: Record<PaymentStatus, "success" | "warning" | "neutral" | "danger"> = {
  paid: "success",
  pending: "warning",
  refunded: "neutral",
  failed: "danger",
};
const channelToneMap: Record<Channel, "primary" | "info" | "violet" | "neutral"> = {
  web: "primary",
  mobile: "info",
  in_store: "violet",
  marketplace: "neutral",
};
const channelLabelMap: Record<Channel, string> = {
  web: "Web",
  mobile: "Mobile",
  in_store: "In-store",
  marketplace: "Marketplace",
};

const ALL_TAGS = ["VIP", "Newsletter", "Wholesale"];

export default function FilterableTablesPage() {
  // ----- Combined filters state -----
  const [search, setSearch] = React.useState("");
  const [colFilters, setColFilters] = React.useState<Record<string, string>>({
    name: "",
    city: "",
    email: "",
  });
  const [statusFilter, setStatusFilter] = React.useState<OrderStatus | "">("");
  const [paymentFilter, setPaymentFilter] = React.useState<PaymentStatus | "">("");
  const [channelFilter, setChannelFilter] = React.useState<Channel | "">("");
  const [tagFilter, setTagFilter] = React.useState<string[]>([]);
  const [dateFrom, setDateFrom] = React.useState<string>("");
  const [dateTo, setDateTo] = React.useState<string>("");

  const filtered = React.useMemo(() => {
    let result = [...customers];
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((r) =>
        r.name.toLowerCase().includes(q) ||
        r.email.toLowerCase().includes(q) ||
        r.id.toLowerCase().includes(q)
      );
    }
    if (colFilters.name) {
      const q = colFilters.name.toLowerCase();
      result = result.filter((r) => r.name.toLowerCase().includes(q));
    }
    if (colFilters.email) {
      const q = colFilters.email.toLowerCase();
      result = result.filter((r) => r.email.toLowerCase().includes(q));
    }
    if (colFilters.city) {
      const q = colFilters.city.toLowerCase();
      result = result.filter((r) => r.city.toLowerCase().includes(q));
    }
    if (statusFilter) result = result.filter((r) => r.status === statusFilter);
    if (paymentFilter) result = result.filter((r) => r.payment === paymentFilter);
    if (channelFilter) result = result.filter((r) => r.channel === channelFilter);
    if (tagFilter.length > 0) result = result.filter((r) => tagFilter.every((t) => r.tags.includes(t)));
    if (dateFrom) result = result.filter((r) => r.lastOrder >= dateFrom);
    if (dateTo) result = result.filter((r) => r.lastOrder <= dateTo);
    return result;
  }, [search, colFilters, statusFilter, paymentFilter, channelFilter, tagFilter, dateFrom, dateTo]);

  const activeFilterCount =
    (statusFilter ? 1 : 0) +
    (paymentFilter ? 1 : 0) +
    (channelFilter ? 1 : 0) +
    tagFilter.length +
    (dateFrom ? 1 : 0) +
    (dateTo ? 1 : 0);

  const clearAll = () => {
    setSearch("");
    setColFilters({ name: "", city: "", email: "" });
    setStatusFilter("");
    setPaymentFilter("");
    setChannelFilter("");
    setTagFilter([]);
    setDateFrom("");
    setDateTo("");
    toast.message("All filters cleared");
  };

  const toggleTag = (t: string) => {
    setTagFilter((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  };

  return (
    <>
      <PageHeader
        title="Filterable Tables"
        description="Five filter patterns side-by-side — per-column text inputs, status dropdowns, date-range pickers, multi-select tag chips, and a combined search + filter bar with live active-filter chips."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Filterable Tables" }]}
        icon={Filter}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={clearAll}>
            <RotateCcw className="h-3.5 w-3.5" /> Reset filters
          </Button>
        }
      />

      {/* Active filter chips strip — unique visual element */}
      <Card className="mb-6">
        <CardContent className="pt-5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide mr-1 inline-flex items-center gap-1.5">
              <SlidersHorizontal className="h-3.5 w-3.5" />
              Active filters:
            </span>
            {activeFilterCount === 0 && !search && (
              <span className="text-xs text-muted-foreground italic">none — showing all {customers.length} customers</span>
            )}
            {search && (
              <FilterChip label={`Search: "${search}"`} onClear={() => setSearch("")} />
            )}
            {colFilters.name && <FilterChip label={`Name: ${colFilters.name}`} onClear={() => setColFilters((p) => ({ ...p, name: "" }))} />}
            {colFilters.email && <FilterChip label={`Email: ${colFilters.email}`} onClear={() => setColFilters((p) => ({ ...p, email: "" }))} />}
            {colFilters.city && <FilterChip label={`City: ${colFilters.city}`} onClear={() => setColFilters((p) => ({ ...p, city: "" }))} />}
            {statusFilter && <FilterChip label={`Status: ${statusFilter}`} onClear={() => setStatusFilter("")} tone="warning" />}
            {paymentFilter && <FilterChip label={`Payment: ${paymentFilter}`} onClear={() => setPaymentFilter("")} tone="success" />}
            {channelFilter && <FilterChip label={`Channel: ${channelLabelMap[channelFilter]}`} onClear={() => setChannelFilter("")} tone="info" />}
            {tagFilter.map((t) => (
              <FilterChip key={t} label={`Tag: ${t}`} onClear={() => toggleTag(t)} tone="violet" />
            ))}
            {dateFrom && <FilterChip label={`From: ${dateFrom}`} onClear={() => setDateFrom("")} tone="primary" />}
            {dateTo && <FilterChip label={`To: ${dateTo}`} onClear={() => setDateTo("")} tone="primary" />}
            {activeFilterCount + (search ? 1 : 0) + (colFilters.name ? 1 : 0) + (colFilters.email ? 1 : 0) + (colFilters.city ? 1 : 0) > 0 && (
              <Button variant="ghost" size="sm" className="h-7 text-xs ml-1" onClick={clearAll}>
                Clear all
              </Button>
            )}
            <span className="ml-auto text-xs text-muted-foreground">
              Showing <span className="font-semibold text-foreground tabular-nums">{filtered.length}</span> of {customers.length}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Main combined filter card with the table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <span className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
              <Users className="h-4 w-4" />
            </span>
            Customers & Orders — All Filters Combined
          </CardTitle>
          <CardDescription className="text-xs">
            Search + per-column inputs + status / payment / channel dropdowns + multi-select tags + date range — all applied together with live count.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Toolbar: search + column filters */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2 mb-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name, email, or customer ID…"
                className="h-8 pl-8 text-xs"
              />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {/* a) Status dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                    <Hash className="h-3.5 w-3.5" />
                    Status
                    {statusFilter && <span className="bg-primary text-primary-foreground rounded-full text-[10px] px-1.5 py-0.5">1</span>}
                    <ChevronDown className="h-3 w-3 opacity-60" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-44">
                  <DropdownMenuLabel className="text-xs">Order status</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-xs" onClick={() => setStatusFilter("")}>All</DropdownMenuItem>
                  {(["delivered", "shipped", "processing", "pending", "cancelled"] as OrderStatus[]).map((s) => (
                    <DropdownMenuItem key={s} className="text-xs capitalize" onClick={() => setStatusFilter(s)}>
                      {statusFilter === s && <Check className="h-3 w-3 mr-1.5" />}
                      {s}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Payment dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                    <Tag className="h-3.5 w-3.5" />
                    Payment
                    {paymentFilter && <span className="bg-primary text-primary-foreground rounded-full text-[10px] px-1.5 py-0.5">1</span>}
                    <ChevronDown className="h-3 w-3 opacity-60" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-44">
                  <DropdownMenuLabel className="text-xs">Payment status</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-xs" onClick={() => setPaymentFilter("")}>All</DropdownMenuItem>
                  {(["paid", "pending", "refunded", "failed"] as PaymentStatus[]).map((s) => (
                    <DropdownMenuItem key={s} className="text-xs capitalize" onClick={() => setPaymentFilter(s)}>
                      {paymentFilter === s && <Check className="h-3 w-3 mr-1.5" />}
                      {s}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Channel dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                    <Filter className="h-3.5 w-3.5" />
                    Channel
                    {channelFilter && <span className="bg-primary text-primary-foreground rounded-full text-[10px] px-1.5 py-0.5">1</span>}
                    <ChevronDown className="h-3 w-3 opacity-60" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-44">
                  <DropdownMenuLabel className="text-xs">Sales channel</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-xs" onClick={() => setChannelFilter("")}>All</DropdownMenuItem>
                  {(["web", "mobile", "in_store", "marketplace"] as Channel[]).map((s) => (
                    <DropdownMenuItem key={s} className="text-xs" onClick={() => setChannelFilter(s)}>
                      {channelFilter === s && <Check className="h-3 w-3 mr-1.5" />}
                      {channelLabelMap[s]}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* d) Multi-select tag filter */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                    <Tag className="h-3.5 w-3.5" />
                    Tags
                    {tagFilter.length > 0 && <span className="bg-primary text-primary-foreground rounded-full text-[10px] px-1.5 py-0.5">{tagFilter.length}</span>}
                    <ChevronDown className="h-3 w-3 opacity-60" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-48">
                  <DropdownMenuLabel className="text-xs">Multi-select tags</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {ALL_TAGS.map((t) => (
                    <DropdownMenuCheckboxItem
                      key={t}
                      checked={tagFilter.includes(t)}
                      onCheckedChange={() => toggleTag(t)}
                      className="text-xs"
                    >
                      {t}
                    </DropdownMenuCheckboxItem>
                  ))}
                  {tagFilter.length > 0 && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-xs text-destructive focus:text-destructive" onClick={() => setTagFilter([])}>
                        Clear tags
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* c) Date range filter */}
              <div className="inline-flex items-center gap-1.5 rounded-md border border-input bg-background h-8 px-2">
                <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="bg-transparent text-xs outline-none w-[120px]"
                  aria-label="From date"
                />
                <span className="text-xs text-muted-foreground">→</span>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="bg-transparent text-xs outline-none w-[120px]"
                  aria-label="To date"
                />
                {(dateFrom || dateTo) && (
                  <button
                    onClick={() => { setDateFrom(""); setDateTo(""); }}
                    className="grid place-items-center h-5 w-5 rounded hover:bg-muted text-muted-foreground"
                    aria-label="Clear date range"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Table with per-column filter row */}
          <div className="rounded-lg border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full caption-bottom text-sm">
                <thead>
                  <tr className="bg-muted/40 border-b">
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Customer ID</th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2">
                      <div>Name</div>
                      <input
                        value={colFilters.name}
                        onChange={(e) => setColFilters((p) => ({ ...p, name: e.target.value }))}
                        placeholder="Filter name…"
                        className="mt-1 w-full h-6 rounded border border-input bg-background px-1.5 text-[11px] font-normal outline-none focus:ring-1 focus:ring-primary"
                      />
                    </th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2">
                      <div>Email</div>
                      <input
                        value={colFilters.email}
                        onChange={(e) => setColFilters((p) => ({ ...p, email: e.target.value }))}
                        placeholder="Filter email…"
                        className="mt-1 w-full h-6 rounded border border-input bg-background px-1.5 text-[11px] font-normal outline-none focus:ring-1 focus:ring-primary"
                      />
                    </th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2">
                      <div>City</div>
                      <input
                        value={colFilters.city}
                        onChange={(e) => setColFilters((p) => ({ ...p, city: e.target.value }))}
                        placeholder="Filter city…"
                        className="mt-1 w-full h-6 rounded border border-input bg-background px-1.5 text-[11px] font-normal outline-none focus:ring-1 focus:ring-primary"
                      />
                    </th>
                    <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-20">Orders</th>
                    <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Total Spent</th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Last Order</th>
                    <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Status</th>
                    <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Payment</th>
                    <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Channel</th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-32">Tags</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={11} className="text-center text-sm text-muted-foreground py-12">
                        No customers match the current filters.
                      </td>
                    </tr>
                  ) : (
                    filtered.map((c) => (
                      <tr key={c.id} className="border-b last:border-0 hover:bg-muted/40 transition-colors">
                        <td className="font-mono text-xs text-primary px-3 py-2">{c.id}</td>
                        <td className="font-medium text-sm px-3 py-2">{c.name}</td>
                        <td className="text-xs text-muted-foreground px-3 py-2">{c.email}</td>
                        <td className="text-sm text-muted-foreground px-3 py-2">{c.city}</td>
                        <td className="text-right tabular-nums text-sm px-3 py-2">{c.orders}</td>
                        <td className="text-right tabular-nums text-sm font-medium px-3 py-2">${c.totalSpent.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className="font-mono text-[11px] text-muted-foreground px-3 py-2">{c.lastOrder}</td>
                        <td className="text-center px-3 py-2">
                          <StatusBadge tone={statusToneMap[c.status]} dot className="capitalize">{c.status}</StatusBadge>
                        </td>
                        <td className="text-center px-3 py-2">
                          <StatusBadge tone={paymentToneMap[c.payment]} className="capitalize">{c.payment}</StatusBadge>
                        </td>
                        <td className="text-center px-3 py-2">
                          <StatusBadge tone={channelToneMap[c.channel]}>{channelLabelMap[c.channel]}</StatusBadge>
                        </td>
                        <td className="px-3 py-2">
                          <div className="flex flex-wrap gap-1">
                            {c.tags.length === 0 ? (
                              <span className="text-[11px] text-muted-foreground/60 italic">—</span>
                            ) : (
                              c.tags.map((t) => (
                                <span
                                  key={t}
                                  className={cn(
                                    "inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset",
                                    t === "VIP" && "bg-[color:var(--warning)]/15 text-[color:var(--warning)] ring-[color:var(--warning)]/25",
                                    t === "Newsletter" && "bg-[color:var(--info)]/12 text-[color:var(--info)] ring-[color:var(--info)]/20",
                                    t === "Wholesale" && "bg-violet-500/12 text-violet-500 ring-violet-500/20"
                                  )}
                                >
                                  {t}
                                </span>
                              ))
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2.5">
            {filtered.length} of {customers.length} customers · try combining a Status filter with a multi-tag selection and a date range to see live filtering in action.
          </p>
        </CardContent>
      </Card>

      {/* Filter patterns reference card */}
      <Card className="mt-6">
        <CardContent className="pt-5">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {[
              { icon: Search, label: "Per-column inputs", desc: "Text box under each header" },
              { icon: Hash, label: "Status dropdown", desc: "Single-select enum" },
              { icon: CalendarDays, label: "Date range", desc: "From → To picker" },
              { icon: Tag, label: "Multi-select", desc: "Checkbox tag picker" },
              { icon: SlidersHorizontal, label: "Combined search", desc: "All filters stack" },
            ].map((p, i) => (
              <div key={p.label} className="rounded-lg border border-border p-3 bg-muted/20">
                <div className="flex items-center gap-2 mb-1">
                  <span className="grid place-items-center h-6 w-6 rounded bg-primary/10 text-primary">
                    <p.icon className="h-3.5 w-3.5" />
                  </span>
                  <span className="text-[10px] font-mono text-muted-foreground">{String.fromCharCode(97 + i)})</span>
                </div>
                <p className="text-sm font-medium">{p.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{p.desc}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </>
  );
}

function FilterChip({
  label,
  onClear,
  tone = "neutral",
}: {
  label: string;
  onClear: () => void;
  tone?: "neutral" | "primary" | "success" | "warning" | "info" | "violet";
}) {
  const toneClass: Record<string, string> = {
    neutral: "bg-muted text-foreground ring-border",
    primary: "bg-primary/10 text-primary ring-primary/20",
    success: "bg-[color:var(--success)]/12 text-[color:var(--success)] ring-[color:var(--success)]/20",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)] ring-[color:var(--warning)]/25",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)] ring-[color:var(--info)]/20",
    violet: "bg-violet-500/12 text-violet-500 ring-violet-500/20",
  };
  return (
    <button
      onClick={onClear}
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset transition-colors hover:opacity-80",
        toneClass[tone]
      )}
    >
      {label}
      <X className="h-3 w-3" />
    </button>
  );
}
