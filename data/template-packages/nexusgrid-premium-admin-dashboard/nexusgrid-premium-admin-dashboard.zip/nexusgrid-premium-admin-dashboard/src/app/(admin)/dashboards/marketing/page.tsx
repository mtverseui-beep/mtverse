"use client";

import * as React from "react";
import {
  Megaphone,
  Target,
  Users,
  Eye,
  Filter,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  TrendingUp,
  MousePointerClick,
  Image as ImageIcon,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AreaTrendChart, DonutChart } from "@/components/charts";
import { marketingCampaigns, marketingChannels } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline marketing data ---------- */

// 8 weeks of campaign performance data
const campaignPerformance = Array.from({ length: 8 }, (_, i) => {
  const week = `W${i + 1}`;
  const base = 1000 + i * 80;
  return {
    week,
    clicks: base + Math.round(Math.sin(i * 0.9) * 120),
    conversions: Math.round((base + Math.round(Math.sin(i * 0.9) * 120)) * 0.18),
    spend: 4200 + Math.round(Math.cos(i * 0.7) * 600 + i * 120),
    revenue: (4200 + Math.round(Math.cos(i * 0.7) * 600 + i * 120)) * 4,
  };
});

// ROAS per channel (table below donut)
const channelRoas = [
  { name: "Organic", share: 38, roas: 0, color: "var(--primary)" }, // organic doesn't have spend-based ROAS
  { name: "Paid Search", share: 24, roas: 5.8, color: "oklch(0.70 0.15 75)" },
  { name: "Social", share: 18, roas: 3.4, color: "var(--info)" },
  { name: "Email", share: 12, roas: 12.2, color: "oklch(0.62 0.18 25)" },
  { name: "Direct", share: 8, roas: 0, color: "oklch(0.58 0.13 250)" },
];

// Attribution models with conversion credit %
const attributionModels = [
  { model: "First-touch", credit: 38, color: "var(--primary)" },
  { model: "Last-touch", credit: 32, color: "var(--info)" },
  { model: "Linear", credit: 18, color: "oklch(0.70 0.15 75)" },
  { model: "Time-decay", credit: 22, color: "oklch(0.62 0.18 25)" },
  { model: "Position-based", credit: 26, color: "oklch(0.58 0.13 250)" },
];

// Top creatives
const topCreatives = [
  { name: "Summer Sale Hero", image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=200&h=120&fit=crop", impressions: 384000, ctr: 4.2, conversions: 1280 },
  { name: "Product Launch Teaser", image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=200&h=120&fit=crop", impressions: 248000, ctr: 3.6, conversions: 842 },
  { name: "Customer Story — Aiko", image: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=200&h=120&fit=crop", impressions: 192000, ctr: 5.1, conversions: 968 },
  { name: "Flash Discount Carousel", image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=200&h=120&fit=crop", impressions: 156000, ctr: 2.8, conversions: 412 },
];

/* ---------- Marketing KPI card — creative energy vibe ---------- */
// Distinct: bold gradient tinted background, large icon top-right,
// big value, accent-colored trend pill. Visually more vibrant than
// the analytics/CRM/finance cards.

function MarketingKpiCard({
  label,
  value,
  icon: Icon,
  trend,
  trendLabel,
  accent,
  positive,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  trend: number;
  trendLabel: string;
  accent: "info" | "primary" | "success" | "warning";
  positive: boolean;
}) {
  const accentGradient: Record<string, string> = {
    info: "from-[color:var(--info)]/10 via-card to-card",
    primary: "from-primary/10 via-card to-card",
    success: "from-[color:var(--success)]/10 via-card to-card",
    warning: "from-[color:var(--warning)]/10 via-card to-card",
  };
  const accentIcon: Record<string, string> = {
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    primary: "bg-primary/15 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  const direction = positive ? "up" : "down";

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border border-border bg-gradient-to-br p-5 transition-all hover:shadow-premium-sm",
        accentGradient[accent]
      )}
    >
      {/* Decorative blob — creative energy vibe */}
      <div
        className="absolute -right-6 -top-6 h-20 w-20 rounded-full opacity-20 blur-2xl"
        style={{
          background:
            accent === "info"
              ? "var(--info)"
              : accent === "primary"
              ? "var(--primary)"
              : accent === "success"
              ? "var(--success)"
              : "var(--warning)",
        }}
      />
      <div className="relative">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">{label}</p>
            <p className="mt-1.5 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-10 w-10 rounded-lg shrink-0", accentIcon[accent])}>
            <Icon className="h-5 w-5" />
          </div>
        </div>

        <div className="mt-3 flex items-center gap-1.5 flex-wrap">
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
              positive
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {Math.abs(trend)}
          </span>
          <span className="text-xs text-muted-foreground">{trendLabel}</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function MarketingDashboardPage() {
  const totalChannelShare = marketingChannels.reduce((s, x) => s + x.value, 0);

  return (
    <>
      <PageHeader
        title="Marketing Dashboard"
        description="Campaign performance, channel mix, and attribution across paid and organic spend."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Marketing" }]}
        icon={Megaphone}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Last 8 weeks
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5 bg-[color:var(--info)] text-[color:var(--info-foreground)] hover:bg-[color:var(--info)]/90">
              <Sparkles className="h-3.5 w-3.5" /> New campaign
            </Button>
          </>
        }
      />

      {/* KPI Row — MarketingKpiCard with gradient + creative energy */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MarketingKpiCard
          label="ROAS"
          value="4.2x"
          icon={Target}
          accent="info"
          trend={0.8}
          trendLabel="vs. 3.4x last Q"
          positive
        />
        <MarketingKpiCard
          label="CAC"
          value="$84"
          icon={Users}
          accent="success"
          trend={12}
          trendLabel="lower is better"
          positive
        />
        <MarketingKpiCard
          label="Impressions"
          value="1.2M"
          icon={Eye}
          accent="primary"
          trend={24}
          trendLabel="vs. last 8 weeks"
          positive
        />
        <MarketingKpiCard
          label="Conversions"
          value="4,280"
          icon={MousePointerClick}
          accent="warning"
          trend={18}
          trendLabel="vs. last 8 weeks"
          positive
        />
      </div>

      {/* Campaign performance chart + Channel mix */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Megaphone className="h-4 w-4 text-[color:var(--info)]" />
                Campaign Performance
              </CardTitle>
              <CardDescription>Weekly clicks, conversions, spend, and revenue across all live campaigns.</CardDescription>
            </div>
            <div className="flex items-center gap-2 text-xs flex-wrap justify-end">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--info)]" /> Clicks
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)]" /> Conv.
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--warning)]" /> Spend
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" /> Revenue
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={campaignPerformance}
              xKey="week"
              series={[
                { key: "clicks", name: "Clicks", color: "var(--info)" },
                { key: "conversions", name: "Conversions", color: "var(--success)" },
                { key: "spend", name: "Spend ($)", color: "var(--warning)" },
                { key: "revenue", name: "Revenue ($)", color: "var(--primary)" },
              ]}
              height={300}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-[color:var(--info)]" />
              Channel Mix
            </CardTitle>
            <CardDescription>Conversion share by acquisition channel.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={marketingChannels}
              centerLabel="Conversions"
              centerValue="4,280"
              height={180}
              innerRadius={48}
              outerRadius={72}
            />
            {/* ROAS per channel table */}
            <div className="mt-4 pt-3 border-t border-border">
              <div className="grid grid-cols-[1fr_auto_auto] gap-x-2 gap-y-1.5 text-xs">
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">Channel</p>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium text-right">Share</p>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium text-right">ROAS</p>
                {channelRoas.map((c) => (
                  <React.Fragment key={c.name}>
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="h-2 w-2 rounded-full shrink-0" style={{ background: c.color }} />
                      <span className="text-muted-foreground truncate">{c.name}</span>
                    </div>
                    <span className="text-right tabular-nums font-medium">{c.share}%</span>
                    <span className="text-right tabular-nums font-medium">
                      {c.roas === 0 ? <span className="text-muted-foreground">—</span> : `${c.roas}x`}
                    </span>
                  </React.Fragment>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active campaigns table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Megaphone className="h-4 w-4 text-[color:var(--info)]" />
              Active Campaigns
            </CardTitle>
            <CardDescription>Performance across all live and paused campaigns.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            View all <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Campaign</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Channel</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Impressions</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Clicks</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Conversions</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">ROAS</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {marketingCampaigns.map((c) => {
                  const roasTone: StatusTone = c.roas >= 5 ? "success" : c.roas >= 3 ? "primary" : c.roas >= 2 ? "warning" : "danger";
                  const isActive = c.status === "active";
                  return (
                    <tr key={c.name} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-medium text-foreground">{c.name}</td>
                      <td className="px-4 py-3 hidden sm:table-cell">
                        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--info)]" />
                          {c.channel}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums">{c.impressions.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right tabular-nums hidden md:table-cell">{c.clicks.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right tabular-nums font-medium hidden lg:table-cell">{c.conversions.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right">
                        <StatusBadge tone={roasTone} className="tabular-nums">{c.roas}x</StatusBadge>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <StatusBadge tone={isActive ? "success" : "neutral"} dot>
                          {c.status}
                        </StatusBadge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Attribution model + Top creatives */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Attribution model — 5 touchpoints with bars */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="h-4 w-4 text-[color:var(--info)]" />
              Attribution Models
            </CardTitle>
            <CardDescription>Conversion credit % by attribution methodology.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3.5">
            {attributionModels.map((a) => {
              const maxCredit = Math.max(...attributionModels.map((x) => x.credit));
              const widthPct = (a.credit / maxCredit) * 100;
              return (
                <div key={a.model}>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium text-foreground">{a.model}</span>
                    <span className="font-semibold tabular-nums text-muted-foreground">{a.credit}%</span>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700 ease-out"
                      style={{ width: `${widthPct}%`, background: a.color, opacity: 0.9 }}
                    />
                  </div>
                </div>
              );
            })}
            <div className="mt-4 pt-3 border-t border-border">
              <p className="text-xs text-muted-foreground">
                <span className="font-medium text-foreground">First-touch</span> credits the most (38%) — top-of-funnel
                awareness is driving initial demand. Consider shifting budget toward upper-funnel channels.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Top creatives — 4 thumbnails with stats */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <ImageIcon className="h-4 w-4 text-[color:var(--info)]" />
                Top Creatives
              </CardTitle>
              <CardDescription>Best performing ad creatives this period.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y divide-border">
              {topCreatives.map((c, i) => (
                <li key={c.name} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors">
                  <div className="relative h-14 w-20 rounded-md overflow-hidden shrink-0 bg-muted">
                    <img
                      src={c.image}
                      alt={c.name}
                      className="h-full w-full object-cover"
                    />
                    <span className="absolute top-1 left-1 grid place-items-center h-4 w-4 rounded bg-black/60 text-[9px] font-bold text-white tabular-nums">
                      {i + 1}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{c.name}</p>
                    <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                      <span className="inline-flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        <span className="tabular-nums">{(c.impressions / 1000).toFixed(0)}K</span>
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <MousePointerClick className="h-3 w-3" />
                        <span className="tabular-nums">{c.ctr}% CTR</span>
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <TrendingUp className="h-3 w-3 text-[color:var(--success)]" />
                        <span className="tabular-nums text-[color:var(--success)] font-medium">{c.conversions.toLocaleString()}</span>
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
