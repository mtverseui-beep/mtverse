"use client";

import * as React from "react";
import {
  Receipt,
  Download,
  CheckCircle2,
  Clock,
  XCircle,
  Calendar,
  CreditCard,
  TrendingUp,
  Filter,
  Search,
  Eye,
  ArrowUpDown,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DataTable, type Column } from "@/components/tables/data-table";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Invoice = {
  id: string;
  number: string;
  date: string;
  dateISO: string;
  amount: number;
  tax: number;
  total: number;
  status: "paid" | "pending" | "failed";
  method: string;
  description: string;
};

const INVOICES: Invoice[] = [
  { id: "i1", number: "INV-2026-0714", date: "Jul 14, 2026", dateISO: "2026-07-14", amount: 226.36, tax: 22.64, total: 249.00, status: "paid", method: "Visa •••• 4242", description: "Pro plan · monthly" },
  { id: "i2", number: "INV-2026-0614", date: "Jun 14, 2026", dateISO: "2026-06-14", amount: 226.36, tax: 22.64, total: 249.00, status: "paid", method: "Visa •••• 4242", description: "Pro plan · monthly" },
  { id: "i3", number: "INV-2026-0514", date: "May 14, 2026", dateISO: "2026-05-14", amount: 226.36, tax: 22.64, total: 249.00, status: "paid", method: "Visa •••• 4242", description: "Pro plan · monthly" },
  { id: "i4", number: "INV-2026-0414", date: "Apr 14, 2026", dateISO: "2026-04-14", amount: 226.36, tax: 22.64, total: 249.00, status: "paid", method: "Visa •••• 4242", description: "Pro plan · monthly" },
  { id: "i5", number: "INV-2026-0314", date: "Mar 14, 2026", dateISO: "2026-03-14", amount: 226.36, tax: 22.64, total: 249.00, status: "paid", method: "Visa •••• 4242", description: "Pro plan · monthly" },
  { id: "i6", number: "INV-2026-0214", date: "Feb 14, 2026", dateISO: "2026-02-14", amount: 180.91, tax: 18.09, total: 199.00, status: "paid", method: "Visa •••• 4242", description: "Starter plan · monthly" },
  { id: "i7", number: "INV-2026-0114", date: "Jan 14, 2026", dateISO: "2026-01-14", amount: 180.91, tax: 18.09, total: 199.00, status: "paid", method: "Visa •••• 4242", description: "Starter plan · monthly" },
  { id: "i8", number: "INV-2025-1214", date: "Dec 14, 2025", dateISO: "2025-12-14", amount: 180.91, tax: 18.09, total: 199.00, status: "paid", method: "Visa •••• 4242", description: "Starter plan · monthly" },
  { id: "i9", number: "INV-2025-1114", date: "Nov 14, 2025", dateISO: "2025-11-14", amount: 180.91, tax: 18.09, total: 199.00, status: "paid", method: "Visa •••• 4242", description: "Starter plan · monthly" },
  { id: "i10", number: "INV-2025-1014", date: "Oct 14, 2025", dateISO: "2025-10-14", amount: 90.00, tax: 9.00, total: 99.00, status: "paid", method: "Visa •••• 4242", description: "Free trial → Starter · prorated" },
  { id: "i11", number: "INV-2025-0914", date: "Sep 14, 2025", dateISO: "2025-09-14", amount: 90.00, tax: 9.00, total: 99.00, status: "failed", method: "Visa •••• 8888", description: "Starter plan · monthly · card declined" },
  { id: "i12", number: "INV-2025-0814", date: "Aug 14, 2025", dateISO: "2025-08-14", amount: 90.00, tax: 9.00, total: 99.00, status: "paid", method: "Visa •••• 8888", description: "Starter plan · monthly" },
  { id: "i13", number: "INV-2025-0714", date: "Jul 14, 2025", dateISO: "2025-07-14", amount: 90.00, tax: 9.00, total: 99.00, status: "paid", method: "Visa •••• 8888", description: "Starter plan · monthly" },
  { id: "i14", number: "INV-2025-0614", date: "Jun 14, 2025", dateISO: "2025-06-14", amount: 0, tax: 0, total: 0, status: "paid", method: "—", description: "Free plan · no charge" },
];

const statusMeta: Record<Invoice["status"], { tone: "success" | "warning" | "danger"; icon: React.ElementType; label: string }> = {
  paid: { tone: "success", icon: CheckCircle2, label: "Paid" },
  pending: { tone: "warning", icon: Clock, label: "Pending" },
  failed: { tone: "danger", icon: XCircle, label: "Failed" },
};

export default function InvoicesPage() {
  const [statusFilter, setStatusFilter] = React.useState("all");
  const [dateFilter, setDateFilter] = React.useState("all");
  const [search, setSearch] = React.useState("");

  const filtered = INVOICES.filter((i) => {
    if (statusFilter !== "all" && i.status !== statusFilter) return false;
    if (dateFilter === "2026" && !i.dateISO.startsWith("2026")) return false;
    if (dateFilter === "2025" && !i.dateISO.startsWith("2025")) return false;
    if (search) {
      const s = search.toLowerCase();
      if (!i.number.toLowerCase().includes(s) && !i.description.toLowerCase().includes(s) && !i.method.toLowerCase().includes(s)) return false;
    }
    return true;
  });

  const totalPaid = INVOICES.filter((i) => i.status === "paid").reduce((acc, i) => acc + i.total, 0);
  const totalPending = INVOICES.filter((i) => i.status === "pending").reduce((acc, i) => acc + i.total, 0);
  const totalFailed = INVOICES.filter((i) => i.status === "failed").reduce((acc, i) => acc + i.total, 0);

  const columns: Column<Invoice>[] = [
    {
      key: "number",
      header: "Invoice",
      sortable: true,
      sortAccessor: (r) => r.number,
      cell: (r) => (
        <div className="flex items-center gap-3">
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0",
            r.status === "paid" ? "bg-[color:var(--success)]/12 text-[color:var(--success)]" :
            r.status === "pending" ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" :
            "bg-destructive/12 text-destructive"
          )}>
            <Receipt className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <p className="font-mono text-sm font-medium">{r.number}</p>
            <p className="text-xs text-muted-foreground truncate">{r.description}</p>
          </div>
        </div>
      ),
    },
    {
      key: "date",
      header: "Date",
      sortable: true,
      sortAccessor: (r) => r.dateISO,
      cell: (r) => (
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Calendar className="h-3.5 w-3.5" /> {r.date}
        </div>
      ),
    },
    {
      key: "method",
      header: "Payment method",
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <CreditCard className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-xs font-mono text-muted-foreground">{r.method}</span>
        </div>
      ),
    },
    {
      key: "amount",
      header: "Subtotal",
      align: "right",
      cell: (r) => <span className="text-xs text-muted-foreground tabular-nums">${r.amount.toFixed(2)}</span>,
    },
    {
      key: "tax",
      header: "Tax",
      align: "right",
      cell: (r) => <span className="text-xs text-muted-foreground tabular-nums">${r.tax.toFixed(2)}</span>,
    },
    {
      key: "total",
      header: "Total",
      align: "right",
      sortable: true,
      sortAccessor: (r) => r.total,
      cell: (r) => <span className="font-mono font-semibold tabular-nums">${r.total.toFixed(2)}</span>,
    },
    {
      key: "status",
      header: "Status",
      align: "center",
      sortable: true,
      sortAccessor: (r) => r.status,
      cell: (r) => {
        const m = statusMeta[r.status];
        return <StatusBadge tone={m.tone} dot>{m.label}</StatusBadge>;
      },
    },
    {
      key: "actions",
      header: "",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div className="flex items-center justify-end gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.message(`Previewing ${r.number}`)}>
            <Eye className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="sm" className="text-xs gap-1.5 h-7" onClick={() => toast.success(`Downloading ${r.number}.pdf`)}>
            <Download className="h-3 w-3" /> PDF
          </Button>
        </div>
      ),
    },
  ];

  return (
    <>
      <PageHeader
        title="Invoices"
        description="Every invoice we've ever issued you. Download, preview, or reconcile from one place."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Invoices" }]}
        icon={Receipt}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Statement exported", { description: "All invoices bundled into a single ZIP." })}>
            <Download className="h-3.5 w-3.5" /> Export all
          </Button>
        }
      />

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        {[
          { icon: CheckCircle2, tone: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Total paid", value: `$${totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, hint: `${INVOICES.filter((i) => i.status === "paid").length} invoices · all time`, trend: "+12% YoY" },
          { icon: Clock, tone: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]", label: "Pending", value: `$${totalPending.toFixed(2)}`, hint: `${INVOICES.filter((i) => i.status === "pending").length} invoice${INVOICES.filter((i) => i.status === "pending").length === 1 ? "" : "s"} awaiting payment`, trend: "Auto-retries active" },
          { icon: XCircle, tone: "bg-destructive/12 text-destructive", label: "Failed", value: `$${totalFailed.toFixed(2)}`, hint: `${INVOICES.filter((i) => i.status === "failed").length} invoice${INVOICES.filter((i) => i.status === "failed").length === 1 ? "" : "s"} · needs attention`, trend: "Update payment" },
        ].map((s) => (
          <Card key={s.label} className="p-5">
            <div className="flex items-start justify-between mb-3">
              <div className={cn("grid place-items-center h-10 w-10 rounded-lg", s.tone)}>
                <s.icon className="h-5 w-5" />
              </div>
              <Badge variant="outline" className="text-[10px] gap-1 text-muted-foreground">
                <TrendingUp className="h-2.5 w-2.5" /> {s.trend}
              </Badge>
            </div>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1">{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.hint}</p>
          </Card>
        ))}
      </div>

      {/* FILTERS */}
      <Card className="mb-4">
        <CardContent className="p-3">
          <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by invoice #, description, or card…"
                className="pl-8 h-9 text-sm"
              />
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="h-9 w-[140px] text-xs gap-1.5"><Filter className="h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All status</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="h-9 w-[140px] text-xs gap-1.5"><Calendar className="h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All time</SelectItem>
                  <SelectItem value="2026">2026</SelectItem>
                  <SelectItem value="2025">2025</SelectItem>
                </SelectContent>
              </Select>
              {(statusFilter !== "all" || dateFilter !== "all" || search) && (
                <Button variant="ghost" size="sm" className="text-xs h-9" onClick={() => { setStatusFilter("all"); setDateFilter("all"); setSearch(""); }}>Clear</Button>
              )}
              <span className="text-xs text-muted-foreground shrink-0 hidden sm:inline">{filtered.length} of {INVOICES.length}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* TABLE */}
      <Card>
        <CardContent className="p-0">
          <DataTable
            data={filtered}
            columns={columns}
            pageSize={10}
            searchable={false}
            title="Invoice history"
            getRowId={(r) => r.id}
            enableExport
            enableSelection
            bulkActions={[
              { label: "Download PDFs", icon: Download, onClick: (sel) => toast.success(`Downloading ${sel.length} PDFs`) },
            ]}
            initialSort={{ key: "date", direction: "desc" }}
          />
        </CardContent>
      </Card>

      {/* Footer note */}
      <p className="text-xs text-muted-foreground mt-4 flex items-center gap-1.5">
        <ArrowUpDown className="h-3 w-3" />
        Invoices are retained for 7 years for tax and compliance purposes. Need a custom statement? <button className="text-primary hover:underline" onClick={() => toast.message("Contacting finance")}>Contact finance</button>.
      </p>
    </>
  );
}
