"use client";

import * as React from "react";
import {
  CheckSquare,
  Sun,
  Star,
  Calendar as CalendarIcon,
  ListTodo,
  CheckCheck,
  Briefcase,
  Home,
  ShoppingCart,
  Plus,
  Check,
  Trash2,
  Flag,
  MoreHorizontal,
  SortAsc,
  Clock,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type Priority = "low" | "medium" | "high";
type ListKey = "my-day" | "important" | "planned" | "tasks" | "completed" | "work" | "personal" | "shopping";

type Todo = {
  id: string;
  title: string;
  notes?: string;
  completed: boolean;
  priority: Priority;
  due?: string;
  list: "work" | "personal" | "shopping";
  starred: boolean;
  steps?: { id: string; label: string; done: boolean }[];
  created: string;
};

const initialTodos: Todo[] = [
  { id: "t1", title: "Finalize Q3 board deck", notes: "Pre-read due Monday 9am. Include updated ARR projection.", completed: false, priority: "high", due: "Today", list: "work", starred: true, steps: [{ id: "s1", label: "Pull latest revenue numbers", done: true }, { id: "s2", label: "Update competitive landscape slide", done: true }, { id: "s3", label: "Add updated org chart", done: false }, { id: "s4", label: "Final review with Elena", done: false }], created: "Jul 14" },
  { id: "t2", title: "1:1 with Aiko — career conversation", notes: "Prep: review peer feedback, promotion case.", completed: false, priority: "medium", due: "Today", list: "work", starred: false, created: "Jul 14" },
  { id: "t3", title: "Review PR #2841 — payment retry refactor", completed: false, priority: "medium", due: "Today", list: "work", starred: false, created: "Jul 14" },
  { id: "t4", title: "Reply to Cloudflare customer escalation", notes: "EOD response. Loop in Marcus.", completed: false, priority: "high", due: "Today", list: "work", starred: true, created: "Jul 14" },
  { id: "t5", title: "Book flights for Denver offsite", completed: false, priority: "medium", due: "Tomorrow", list: "personal", starred: false, created: "Jul 13" },
  { id: "t6", title: "Order anniversary gift", notes: "Reservation at The Marlowe already booked.", completed: false, priority: "low", due: "Jul 22", list: "personal", starred: false, created: "Jul 13" },
  { id: "t7", title: "Sprint 24 retro prep", notes: "Compile metrics + sentiment survey results.", completed: false, priority: "medium", due: "Tomorrow", list: "work", starred: false, created: "Jul 13" },
  { id: "t8", title: "Pick up dry cleaning", completed: false, priority: "low", due: "Tomorrow", list: "personal", starred: false, created: "Jul 13" },
  { id: "t9", title: "Weekly groceries", notes: "Olive oil, coffee beans, sourdough, eggs, yogurt.", completed: false, priority: "low", due: "Jul 18", list: "shopping", starred: false, created: "Jul 12" },
  { id: "t10", title: "Sign Stripe partnership MOU", completed: false, priority: "high", due: "Jul 19", list: "work", starred: true, created: "Jul 12" },
  { id: "t11", title: "Renew gym membership", completed: false, priority: "low", due: "Jul 21", list: "personal", starred: false, created: "Jul 12" },
  { id: "t12", title: "Refactor auth middleware", notes: "Cleanup after Stripe integration. Add tests.", completed: true, priority: "medium", due: "Yesterday", list: "work", starred: false, created: "Jul 11" },
  { id: "t13", title: "Schedule dentist appointment", completed: true, priority: "low", due: "Yesterday", list: "personal", starred: false, created: "Jul 11" },
  { id: "t14", title: "Submit Q3 OKRs", completed: true, priority: "high", due: "Jul 9", list: "work", starred: false, created: "Jul 8" },
  { id: "t15", title: "Buy birthday card for Mom", completed: true, priority: "low", due: "Jul 8", list: "personal", starred: false, created: "Jul 7" },
];

const smartLists = [
  { key: "my-day" as ListKey, label: "My Day", icon: Sun, count: 4 },
  { key: "important" as ListKey, label: "Important", icon: Star, count: 3 },
  { key: "planned" as ListKey, label: "Planned", icon: CalendarIcon, count: 8 },
  { key: "tasks" as ListKey, label: "Tasks", icon: ListTodo, count: 11 },
  { key: "completed" as ListKey, label: "Completed", icon: CheckCheck, count: 4 },
];

const customLists = [
  { key: "work" as ListKey, label: "Work", icon: Briefcase, color: "var(--primary)", count: 7 },
  { key: "personal" as ListKey, label: "Personal", icon: Home, color: "oklch(0.62 0.18 140)", count: 5 },
  { key: "shopping" as ListKey, label: "Shopping", icon: ShoppingCart, color: "oklch(0.70 0.15 75)", count: 1 },
];

const priorityConfig: Record<Priority, { tone: StatusTone; color: string; label: string }> = {
  low: { tone: "neutral", color: "var(--muted-foreground)", label: "Low" },
  medium: { tone: "warning", color: "var(--warning)", label: "Medium" },
  high: { tone: "danger", color: "var(--destructive)", label: "High" },
};

const listColorMap: Record<string, string> = {
  work: "var(--primary)",
  personal: "oklch(0.62 0.18 140)",
  shopping: "oklch(0.70 0.15 75)",
};

export default function TodoPage() {
  const [activeList, setActiveList] = React.useState<ListKey>("my-day");
  const [filter, setFilter] = React.useState<"all" | "active" | "completed">("all");
  const [todos, setTodos] = React.useState(initialTodos);
  const [newTitle, setNewTitle] = React.useState("");
  const [newPriority, setNewPriority] = React.useState<Priority>("medium");
  const [newList, setNewList] = React.useState<"work" | "personal" | "shopping">("work");
  const [newDue, setNewDue] = React.useState("Today");
  const [showAddOpts, setShowAddOpts] = React.useState(false);

  function visibleTodos() {
    return todos.filter((t) => {
      // list filter
      if (activeList === "my-day" && !(t.due === "Today" || t.due === "Tomorrow")) return false;
      if (activeList === "my-day" && t.due !== "Today" && t.due !== "Tomorrow") return false;
      if (activeList === "my-day" && !t.completed === false) return true;
      if (activeList === "important" && !t.starred) return false;
      if (activeList === "planned" && !t.due) return false;
      if (activeList === "tasks" && t.completed) return true;
      if (activeList === "completed" && !t.completed) return false;
      if (activeList === "work" && t.list !== "work") return false;
      if (activeList === "personal" && t.list !== "personal") return false;
      if (activeList === "shopping" && t.list !== "shopping") return false;
      // filter tab
      if (filter === "active" && t.completed) return false;
      if (filter === "completed" && !t.completed) return false;
      return true;
    });
  }

  const myDayList = visibleTodos();

  function toggleComplete(id: string) {
    setTodos((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));
    const t = todos.find((x) => x.id === id);
    if (t && !t.completed) toast.success("Task completed", { description: t.title });
  }

  function toggleStar(id: string) {
    setTodos((prev) => prev.map((t) => (t.id === id ? { ...t, starred: !t.starred } : t)));
  }

  function deleteTodo(id: string) {
    setTodos((prev) => prev.filter((t) => t.id !== id));
    toast.success("Task deleted");
  }

  function addTodo() {
    if (!newTitle.trim()) return;
    const id = `t${Date.now()}`;
    setTodos((prev) => [{
      id, title: newTitle, completed: false, priority: newPriority, due: newDue, list: newList, starred: false, created: "just now",
    }, ...prev]);
    toast.success("Task added");
    setNewTitle("");
    setShowAddOpts(false);
  }

  const allCounts = {
    "my-day": todos.filter((t) => !t.completed && (t.due === "Today" || t.due === "Tomorrow")).length,
    important: todos.filter((t) => !t.completed && t.starred).length,
    planned: todos.filter((t) => !t.completed && t.due).length,
    tasks: todos.filter((t) => !t.completed).length,
    completed: todos.filter((t) => t.completed).length,
    work: todos.filter((t) => !t.completed && t.list === "work").length,
    personal: todos.filter((t) => !t.completed && t.list === "personal").length,
    shopping: todos.filter((t) => !t.completed && t.list === "shopping").length,
  };

  const activeListMeta = [...smartLists, ...customLists].find((l) => l.key === activeList)!;

  return (
    <>
      <PageHeader
        title="To-Do"
        description="Plan your day, prioritize what matters, and stay on top of deadlines."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "To-Do" }]}
        icon={CheckSquare}
      />

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] h-[calc(100vh-220px)] min-h-[560px]">
            {/* SIDEBAR */}
            <div className="border-r flex flex-col">
              <div className="p-3 border-b">
                <div className="rounded-lg bg-gradient-to-br from-primary/10 to-transparent p-3">
                  <p className="text-xs text-muted-foreground">Tuesday</p>
                  <p className="text-lg font-semibold">July 14</p>
                  <p className="text-xs text-muted-foreground mt-1">{allCounts["my-day"]} tasks today</p>
                </div>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-2">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5">Smart Lists</p>
                  {smartLists.map((l) => {
                    const Icon = l.icon;
                    const active = activeList === l.key;
                    const count = allCounts[l.key];
                    return (
                      <button
                        key={l.key}
                        onClick={() => { setActiveList(l.key); setFilter("all"); }}
                        className={cn(
                          "w-full flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm transition-colors",
                          active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground"
                        )}
                      >
                        <span className="flex items-center gap-2">
                          <Icon className={cn("h-3.5 w-3.5", l.key === "important" && "text-[color:var(--warning)]", l.key === "my-day" && "text-[color:var(--warning)]")} />
                          {l.label}
                        </span>
                        {count > 0 && <span className="text-[10px] tabular-nums text-muted-foreground">{count}</span>}
                      </button>
                    );
                  })}

                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5 mt-3">My Lists</p>
                  {customLists.map((l) => {
                    const Icon = l.icon;
                    const active = activeList === l.key;
                    const count = allCounts[l.key];
                    return (
                      <button
                        key={l.key}
                        onClick={() => { setActiveList(l.key); setFilter("all"); }}
                        className={cn(
                          "w-full flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm transition-colors",
                          active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground"
                        )}
                      >
                        <span className="flex items-center gap-2">
                          <Icon className="h-3.5 w-3.5" style={{ color: l.color }} />
                          {l.label}
                        </span>
                        {count > 0 && <span className="text-[10px] tabular-nums text-muted-foreground">{count}</span>}
                      </button>
                    );
                  })}
                  <button
                    onClick={() => toast.success("New list created")}
                    className="w-full flex items-center gap-2 rounded-md px-2 py-1.5 text-sm text-muted-foreground hover:bg-muted/60 transition-colors mt-1"
                  >
                    <Plus className="h-3.5 w-3.5" /> New list
                  </button>
                </div>
              </ScrollArea>
            </div>

            {/* MAIN */}
            <div className="flex flex-col min-w-0">
              {/* Header */}
              <div className="px-4 py-3 border-b">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <activeListMeta.icon className={cn("h-4 w-4", activeList === "important" && "text-[color:var(--warning)]", activeList === "my-day" && "text-[color:var(--warning)]")} style={(activeList === "work" || activeList === "personal" || activeList === "shopping") ? { color: listColorMap[activeList] } : undefined} />
                    <h2 className="text-base font-semibold">{activeListMeta.label}</h2>
                    <span className="text-xs text-muted-foreground">· {myDayList.length} items</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tabs value={filter} onValueChange={(v) => setFilter(v as any)}>
                      <TabsList className="h-8">
                        <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                        <TabsTrigger value="active" className="text-xs">Active</TabsTrigger>
                        <TabsTrigger value="completed" className="text-xs">Done</TabsTrigger>
                      </TabsList>
                    </Tabs>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><SortAsc className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => toast.success("Sorted by importance")}>Sort by importance</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast.success("Sorted by due date")}>Sort by due date</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast.success("Sorted by created date")}>Sort by created date</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => toast.success("Sorted alphabetically")}>Sort A → Z</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>

              {/* Add new task */}
              <div className="p-3 border-b bg-muted/20">
                <div className="rounded-md border border-border bg-card p-2 focus-within:border-primary/40 transition-colors">
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 rounded-full border border-dashed border-border" onClick={() => setShowAddOpts((s) => !s)}>
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                    <Input
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") addTodo(); }}
                      placeholder="Add a task..."
                      className="border-0 px-0 text-sm focus-visible:ring-0 h-7 bg-transparent"
                    />
                    <Button size="sm" className="h-7 gap-1" onClick={addTodo} disabled={!newTitle.trim()}>
                      <Plus className="h-3.5 w-3.5" /> Add
                    </Button>
                  </div>
                  {showAddOpts && (
                    <div className="flex flex-wrap items-center gap-2 mt-2 pt-2 border-t">
                      <Select value={newPriority} onValueChange={(v) => setNewPriority(v as Priority)}>
                        <SelectTrigger className="h-7 w-[120px] text-xs gap-1"><Flag className="h-3 w-3" /><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low" className="text-xs">Low priority</SelectItem>
                          <SelectItem value="medium" className="text-xs">Medium priority</SelectItem>
                          <SelectItem value="high" className="text-xs">High priority</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select value={newList} onValueChange={(v) => setNewList(v as any)}>
                        <SelectTrigger className="h-7 w-[120px] text-xs gap-1"><Briefcase className="h-3 w-3" /><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="work" className="text-xs">Work</SelectItem>
                          <SelectItem value="personal" className="text-xs">Personal</SelectItem>
                          <SelectItem value="shopping" className="text-xs">Shopping</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input value={newDue} onChange={(e) => setNewDue(e.target.value)} placeholder="Due date" className="h-7 w-[120px] text-xs" />
                    </div>
                  )}
                </div>
              </div>

              {/* Todo list */}
              <ScrollArea className="flex-1">
                <div className="p-2 space-y-0.5">
                  {myDayList.length === 0 && (
                    <div className="py-16 text-center">
                      <div className="grid place-items-center h-12 w-12 rounded-full bg-muted mx-auto mb-3">
                        <CheckCheck className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <p className="text-sm font-medium">All clear</p>
                      <p className="text-xs text-muted-foreground mt-1">No tasks in this view.</p>
                    </div>
                  )}
                  {myDayList.map((t) => {
                    const stepsDone = t.steps?.filter((s) => s.done).length ?? 0;
                    const stepsTotal = t.steps?.length ?? 0;
                    return (
                      <div key={t.id} className="group flex items-start gap-2 rounded-md p-2 hover:bg-muted/40 transition-colors">
                        <button
                          onClick={() => toggleComplete(t.id)}
                          className={cn(
                            "shrink-0 mt-0.5 grid place-items-center h-5 w-5 rounded-full border-2 transition-all",
                            t.completed
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-muted-foreground/40 hover:border-primary"
                          )}
                        >
                          {t.completed && <Check className="h-3 w-3" strokeWidth={3} />}
                        </button>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <p className={cn("text-sm leading-snug", t.completed ? "line-through text-muted-foreground" : "text-foreground")}>{t.title}</p>
                            <div className="flex items-center gap-0.5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button onClick={() => toggleStar(t.id)} className="grid place-items-center h-6 w-6 rounded hover:bg-muted">
                                <Star className={cn("h-3.5 w-3.5", t.starred ? "text-[color:var(--warning)] fill-current" : "text-muted-foreground")} />
                              </button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <button className="grid place-items-center h-6 w-6 rounded hover:bg-muted"><MoreHorizontal className="h-3.5 w-3.5 text-muted-foreground" /></button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => toast.success("Step added")}>Add step</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => toast.success("Reminder set")}>Set reminder</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => toast.success("Due date changed")}>Change due date</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => toggleStar(t.id)}>{t.starred ? "Remove from important" : "Mark important"}</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => deleteTodo(t.id)}><Trash2 className="h-3.5 w-3.5 mr-2" />Delete task</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </div>
                          {t.notes && <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{t.notes}</p>}
                          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                            <StatusBadge tone={priorityConfig[t.priority].tone} className="text-[9px] px-1.5 py-0">
                              <Flag className="h-2 w-2" />{priorityConfig[t.priority].label}
                            </StatusBadge>
                            {t.due && (
                              <span className={cn(
                                "inline-flex items-center gap-1 text-[10px] tabular-nums",
                                t.due === "Today" || t.due === "Yesterday" ? "text-[color:var(--warning)] font-medium" : "text-muted-foreground"
                              )}>
                                <CalendarIcon className="h-2.5 w-2.5" />{t.due}
                              </span>
                            )}
                            <span className="inline-flex items-center gap-1 text-[10px]" style={{ color: listColorMap[t.list] }}>
                              <span className="h-1.5 w-1.5 rounded-full" style={{ background: listColorMap[t.list] }} />
                              {t.list}
                            </span>
                            {stepsTotal > 0 && (
                              <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground tabular-nums">
                                <CheckSquare className="h-2.5 w-2.5" />{stepsDone}/{stepsTotal}
                              </span>
                            )}
                            {t.starred && <Star className="h-2.5 w-2.5 text-[color:var(--warning)] fill-current md:hidden" />}
                          </div>
                          {t.steps && t.steps.length > 0 && (
                            <div className="mt-2 pl-1 space-y-1">
                              {t.steps.map((s) => (
                                <div key={s.id} className="flex items-center gap-2">
                                  <Checkbox checked={s.done} className="h-3.5 w-3.5" onCheckedChange={() => toast.success("Step toggled")} />
                                  <span className={cn("text-xs", s.done ? "line-through text-muted-foreground" : "text-foreground/80")}>{s.label}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>

              {/* Footer */}
              <div className="border-t p-3 flex items-center justify-between text-xs text-muted-foreground">
                <span>{allCounts.tasks} active · {allCounts.completed} completed</span>
                <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Synced just now</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
