"use client";

import * as React from "react";
import {
  ArrowUpDown,
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Server,
  Layers,
  RefreshCw,
  ArrowUp,
  ArrowDown,
  Hash,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type TxStatus = "completed" | "pending" | "failed" | "refunded";
type TxType = "payment" | "payout" | "refund" | "fee" | "transfer";

type Transaction = {
  id: string;
  reference: string;
  customer: string;
  type: TxType;
  method: string;
  amount: number;
  currency: string;
  date: string;
  status: TxStatus;
};

const transactions: Transaction[] = [
  { id: "TX-9842", reference: "ch_3Pq4Xf2eZvKYlo3C", customer: "Sarah Chen", type: "payment", method: "Visa •• 4242", amount: 428.5, currency: "USD", date: "2026-07-14 10:42", status: "completed" },
  { id: "TX-9841", reference: "po_1Pq4Wd8Hk2Nm4QzA", customer: "Marcus Reyes", type: "payout", method: "Bank •• 8821", amount: 2400.0, currency: "USD", date: "2026-07-14 09:58", status: "pending" },
  { id: "TX-9840", reference: "re_2Pq4Vc6Jm3Lp5RxT", customer: "Elena Petrov", type: "refund", method: "Visa •• 1182", amount: -96.99, currency: "USD", date: "2026-07-14 09:32", status: "refunded" },
  { id: "TX-9839", reference: "ch_3Pq4Ub1Xy7ZkWn4F", customer: "James Okoro", type: "payment", method: "MC •• 5500", amount: 186.0, currency: "USD", date: "2026-07-14 08:14", status: "completed" },
  { id: "TX-9838", reference: "fe_4Pq4Ta9Kp2Vm6QyB", customer: "Stripe Fee", type: "fee", method: "Auto-deduct", amount: -12.42, currency: "USD", date: "2026-07-14 08:14", status: "completed" },
  { id: "TX-9837", reference: "tr_5Pq4Sz8Lm3Wn7RxA", customer: "Internal Sweep", type: "transfer", method: "Ledger", amount: 18400.0, currency: "USD", date: "2026-07-14 07:00", status: "completed" },
  { id: "TX-9836", reference: "ch_3Pq4Ry7Xz1YkVn6G", customer: "Aiko Tanaka", type: "payment", method: "Amex •• 1004", amount: 312.0, currency: "USD", date: "2026-07-13 22:48", status: "completed" },
  { id: "TX-9835", reference: "ch_3Pq4Qx6Wz2JlUm7H", customer: "David Kim", type: "payment", method: "Visa •• 7781", amount: 528.75, currency: "USD", date: "2026-07-13 19:22", status: "failed" },
  { id: "TX-9834", reference: "po_1Pq4Pw5Vy3KnTm8I", customer: "Lena Hoffmann", type: "payout", method: "Bank •• 4407", amount: 1820.0, currency: "USD", date: "2026-07-13 17:05", status: "pending" },
  { id: "TX-9833", reference: "re_2Pq4Ov4Ux4LmSn9J", customer: "Raj Patel", type: "refund", method: "MC •• 2299", amount: -144.5, currency: "USD", date: "2026-07-13 14:51", status: "refunded" },
  { id: "TX-9832", reference: "ch_3Pq4Nu3Tw5MmRo0K", customer: "Mei Lin", type: "payment", method: "Visa •• 4242", amount: 287.4, currency: "USD", date: "2026-07-13 12:38", status: "completed" },
  { id: "TX-9831", reference: "fe_4Pq4Mv2Sv6LnSp1L", customer: "Stripe Fee", type: "fee", method: "Auto-deduct", amount: -8.62, currency: "USD", date: "2026-07-13 12:38", status: "completed" },
  { id: "TX-9830", reference: "ch_3Pq4Lu1Rq7KnTq2M", customer: "Carlos Mendez", type: "payment", method: "Visa •• 9981", amount: 178.2, currency: "USD", date: "2026-07-13 11:14", status: "completed" },
  { id: "TX-9829", reference: "tr_5Pq4Ku0Pp8LmUr3N", customer: "Internal Sweep", type: "transfer", method: "Ledger", amount: -9600.0, currency: "USD", date: "2026-07-13 09:00", status: "completed" },
  { id: "TX-9828", reference: "ch_3Pq4Jt9On1MnVs4O", customer: "Priya Sharma", type: "payment", method: "MC •• 5500", amount: 1840.0, currency: "USD", date: "2026-07-12 23:42", status: "completed" },
  { id: "TX-9827", reference: "po_1Pq4Is8Nm2LoWt5P", customer: "Noah Williams", type: "payout", method: "Bank •• 8821", amount: 640.0, currency: "USD", date: "2026-07-12 21:08", status: "pending" },
  { id: "TX-9826", reference: "ch_3Pq4Hr7Ml3PnXu6Q", customer: "Sofia Rossi", type: "payment", method: "Amex •• 1004", amount: 612.3, currency: "USD", date: "2026-07-12 18:55", status: "completed" },
  { id: "TX-9825", reference: "re_2Pq4Gq6Kj4QoYv7R", customer: "Ahmed Hassan", type: "refund", method: "Visa •• 1182", amount: -245.0, currency: "USD", date: "2026-07-12 16:22", status: "refunded" },
  { id: "TX-9824", reference: "ch_3Pq4Fp5Jh5RpZw8S", customer: "Yuki Sato", type: "payment", method: "Visa •• 4242", amount: 398.75, currency: "USD", date: "2026-07-12 14:09", status: "completed" },
  { id: "TX-9823", reference: "fe_4Pq4Eo4Ig6SqAx9T", customer: "Stripe Fee", type: "fee", method: "Auto-deduct", amount: -11.96, currency: "USD", date: "2026-07-12 14:09", status: "completed" },
  { id: "TX-9822", reference: "ch_3Pq4Dn3Hf7TrBy0U", customer: "Olivia Bennett", type: "payment", method: "MC •• 5500", amount: 824.5, currency: "USD", date: "2026-07-12 10:47", status: "completed" },
  { id: "TX-9821", reference: "po_1Pq4Cm2Gd8UsCz1V", customer: "Lucas Moreau", type: "payout", method: "Bank •• 4407", amount: 3200.0, currency: "USD", date: "2026-07-12 08:32", status: "failed" },
];

const statusToneMap: Record<TxStatus, "success" | "warning" | "danger" | "neutral"> = {
  completed: "success",
  pending: "warning",
  failed: "danger",
  refunded: "neutral",
};

const typeToneMap: Record<TxType, "primary" | "info" | "violet" | "warning" | "neutral"> = {
  payment: "primary",
  payout: "info",
  refund: "violet",
  fee: "warning",
  transfer: "neutral",
};

type SortDirection = "asc" | "desc" | null;
type SingleSort = { key: keyof Transaction; direction: "asc" | "desc" } | null;
type MultiSort = { key: keyof Transaction; direction: "asc" | "desc"; priority: number }[];

function getSortValue(row: Transaction, key: keyof Transaction): string | number {
  return row[key] as string | number;
}

function SortIcon({ direction, active }: { direction: SortDirection; active: boolean }) {
  if (!active || !direction) return <ChevronsUpDown className="h-3 w-3 opacity-40" />;
  return direction === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />;
}

export default function SortableTablesPage() {
  // ----- Single-column sort -----
  const [singleSort, setSingleSort] = React.useState<SingleSort>({ key: "date", direction: "desc" });

  const toggleSingleSort = (key: keyof Transaction) => {
    setSingleSort((prev) => {
      if (!prev || prev.key !== key) return { key, direction: "asc" };
      if (prev.direction === "asc") return { key, direction: "desc" };
      return null;
    });
  };

  const singleSorted = React.useMemo(() => {
    if (!singleSort) return transactions;
    return [...transactions].sort((a, b) => {
      const av = getSortValue(a, singleSort.key);
      const bv = getSortValue(b, singleSort.key);
      if (av < bv) return singleSort.direction === "asc" ? -1 : 1;
      if (av > bv) return singleSort.direction === "asc" ? 1 : -1;
      return 0;
    });
  }, [singleSort]);

  // ----- Multi-column sort -----
  const [multiSort, setMultiSort] = React.useState<MultiSort>([
    { key: "status", direction: "asc", priority: 1 },
    { key: "amount", direction: "desc", priority: 2 },
  ]);
  const cycleMultiSort = (key: keyof Transaction) => {
    setMultiSort((prev) => {
      const existing = prev.find((s) => s.key === key);
      if (!existing) {
        const next = [...prev, { key, direction: "asc" as const, priority: prev.length + 1 }];
        return next;
      }
      if (existing.direction === "asc") {
        return prev.map((s) => (s.key === key ? { ...s, direction: "desc" as const } : s));
      }
      // remove and re-prioritize
      const filtered = prev.filter((s) => s.key !== key);
      return filtered.map((s, i) => ({ ...s, priority: i + 1 }));
    });
  };

  const multiSorted = React.useMemo(() => {
    if (multiSort.length === 0) return transactions;
    return [...transactions].sort((a, b) => {
      for (const s of multiSort) {
        const av = getSortValue(a, s.key);
        const bv = getSortValue(b, s.key);
        if (av < bv) return s.direction === "asc" ? -1 : 1;
        if (av > bv) return s.direction === "asc" ? 1 : -1;
      }
      return 0;
    });
  }, [multiSort]);

  // ----- Server-side sort placeholder -----
  const [serverSort, setServerSort] = React.useState<SingleSort>({ key: "date", direction: "desc" });
  const [serverLoading, setServerLoading] = React.useState(false);
  const [serverQuery, setServerQuery] = React.useState(0);

  const triggerServerSort = (key: keyof Transaction) => {
    const newDir = !serverSort || serverSort.key !== key ? "asc" : serverSort.direction === "asc" ? "desc" : null;
    setServerLoading(true);
    setServerSort(newDir ? { key, direction: newDir } : null);
    // Simulate server roundtrip
    setTimeout(() => {
      setServerLoading(false);
      setServerQuery((q) => q + 1);
      toast.success(`Server query #${serverQuery + 1} · sorted by ${key} ${newDir ?? "(cleared)"}`);
    }, 650);
  };

  const serverSorted = React.useMemo(() => {
    if (!serverSort) return transactions;
    return [...transactions].sort((a, b) => {
      const av = getSortValue(a, serverSort.key);
      const bv = getSortValue(b, serverSort.key);
      if (av < bv) return serverSort.direction === "asc" ? -1 : 1;
      if (av > bv) return serverSort.direction === "asc" ? 1 : -1;
      return 0;
    });
  }, [serverSort]);

  // ----- Common column definitions -----
  const sortableColumns: { key: keyof Transaction; label: string; align?: "left" | "right" }[] = [
    { key: "id", label: "Tx ID" },
    { key: "reference", label: "Reference" },
    { key: "customer", label: "Customer" },
    { key: "type", label: "Type" },
    { key: "amount", label: "Amount", align: "right" },
    { key: "date", label: "Date" },
    { key: "status", label: "Status" },
  ];

  return (
    <>
      <PageHeader
        title="Sortable Tables"
        description="Three sort patterns — single-column click-to-toggle, multi-column with priority badges, and a server-side roundtrip with loading state — using a 22-row transactions dataset."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Sortable Tables" }]}
        icon={ArrowUpDown}
      />

      <div className="grid grid-cols-1 gap-6">
        {/* a) Single-column sort */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between text-base">
              <span className="flex items-center gap-2">
                <span className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
                  <Hash className="h-4 w-4" />
                </span>
                Single-Column Sort
              </span>
              {singleSort && (
                <Badge variant="outline" className="text-[11px] font-mono gap-1">
                  <ArrowUp className={cn("h-3 w-3", singleSort.direction === "desc" && "rotate-180")} />
                  {singleSort.key} · {singleSort.direction}
                </Badge>
              )}
            </CardTitle>
            <CardDescription className="text-xs">
              Click any column header to sort ascending → descending → cleared. Only one column can be sorted at a time.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-transparent">
                    {sortableColumns.map((c) => (
                      <TableHead
                        key={c.key}
                        className={cn(
                          "text-xs uppercase tracking-wide font-semibold text-muted-foreground cursor-pointer hover:text-foreground select-none",
                          c.align === "right" && "text-right"
                        )}
                        onClick={() => toggleSingleSort(c.key)}
                      >
                        <span className={cn("inline-flex items-center gap-1", c.align === "right" && "flex-row-reverse")}>
                          {c.label}
                          <SortIcon
                            active={singleSort?.key === c.key}
                            direction={singleSort?.key === c.key ? singleSort.direction : null}
                          />
                        </span>
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {singleSorted.slice(0, 10).map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="font-mono text-xs text-primary">{tx.id}</TableCell>
                      <TableCell className="font-mono text-[11px] text-muted-foreground">{tx.reference}</TableCell>
                      <TableCell className="text-sm font-medium">{tx.customer}</TableCell>
                      <TableCell>
                        <StatusBadge tone={typeToneMap[tx.type]} className="capitalize">{tx.type}</StatusBadge>
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-sm font-medium">
                        <span className={tx.amount < 0 ? "text-[color:var(--danger)]" : ""}>
                          {tx.amount < 0 ? "−" : ""}${Math.abs(tx.amount).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="font-mono text-[11px] text-muted-foreground">{tx.date}</TableCell>
                      <TableCell>
                        <StatusBadge tone={statusToneMap[tx.status]} dot className="capitalize">{tx.status}</StatusBadge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <p className="text-xs text-muted-foreground mt-2.5">
              Showing first 10 of {singleSorted.length} sorted rows · click header again to reverse · click third time to clear sort.
            </p>
          </CardContent>
        </Card>

        {/* b) Multi-column sort */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between text-base">
              <span className="flex items-center gap-2">
                <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
                  <Layers className="h-4 w-4" />
                </span>
                Multi-Column Sort
              </span>
              <div className="flex items-center gap-1.5">
                {multiSort.length === 0 ? (
                  <span className="text-xs text-muted-foreground">No sort applied</span>
                ) : (
                  multiSort.map((s) => (
                    <Badge key={s.key} variant="outline" className="text-[11px] font-mono gap-1">
                      <span className="grid place-items-center h-4 w-4 rounded-full bg-primary/15 text-primary text-[9px] font-bold">{s.priority}</span>
                      {s.key}
                      {s.direction === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                    </Badge>
                  ))
                )}
                {multiSort.length > 0 && (
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setMultiSort([])}>
                    Clear
                  </Button>
                )}
              </div>
            </CardTitle>
            <CardDescription className="text-xs">
              Sort by up to 3 columns. Numbered badges show sort priority. Click a header to add to sort, click again to flip direction, click third time to remove.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-transparent">
                    {sortableColumns.map((c) => {
                      const sorted = multiSort.find((s) => s.key === c.key);
                      return (
                        <TableHead
                          key={c.key}
                          className={cn(
                            "text-xs uppercase tracking-wide font-semibold text-muted-foreground cursor-pointer hover:text-foreground select-none",
                            c.align === "right" && "text-right"
                          )}
                          onClick={() => cycleMultiSort(c.key)}
                        >
                          <span className={cn("inline-flex items-center gap-1", c.align === "right" && "flex-row-reverse")}>
                            {c.label}
                            {sorted ? (
                              <span className="inline-flex items-center gap-0.5">
                                <span className="grid place-items-center h-3.5 w-3.5 rounded-full bg-primary text-primary-foreground text-[9px] font-bold leading-none">
                                  {sorted.priority}
                                </span>
                                {sorted.direction === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                              </span>
                            ) : (
                              <ChevronsUpDown className="h-3 w-3 opacity-40" />
                            )}
                          </span>
                        </TableHead>
                      );
                    })}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {multiSorted.slice(0, 10).map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="font-mono text-xs text-primary">{tx.id}</TableCell>
                      <TableCell className="font-mono text-[11px] text-muted-foreground">{tx.reference}</TableCell>
                      <TableCell className="text-sm font-medium">{tx.customer}</TableCell>
                      <TableCell>
                        <StatusBadge tone={typeToneMap[tx.type]} className="capitalize">{tx.type}</StatusBadge>
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-sm font-medium">
                        <span className={tx.amount < 0 ? "text-[color:var(--danger)]" : ""}>
                          {tx.amount < 0 ? "−" : ""}${Math.abs(tx.amount).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="font-mono text-[11px] text-muted-foreground">{tx.date}</TableCell>
                      <TableCell>
                        <StatusBadge tone={statusToneMap[tx.status]} dot className="capitalize">{tx.status}</StatusBadge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <p className="text-xs text-muted-foreground mt-2.5">
              Current sort: {multiSort.length === 0 ? "none" : multiSort.map((s) => `${s.key} ${s.direction}`).join(", then ")}.
              Each click adds a level — useful for "group by status, then sort by amount within each group".
            </p>
          </CardContent>
        </Card>

        {/* c) Server-side sort */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between text-base">
              <span className="flex items-center gap-2">
                <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--success)]/12 text-[color:var(--success)]">
                  <Server className="h-4 w-4" />
                </span>
                Server-Side Sort
              </span>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-[11px] font-mono">
                  Query #{serverQuery}
                </Badge>
                {serverLoading && (
                  <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                    <RefreshCw className="h-3 w-3 animate-spin" /> Fetching…
                  </span>
                )}
              </div>
            </CardTitle>
            <CardDescription className="text-xs">
              Sort is delegated to the server — clicking a header triggers a loading state, then a network roundtrip is simulated (650 ms) before results re-render.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden relative">
              {serverLoading && (
                <div className="absolute inset-0 z-10 bg-background/60 backdrop-blur-[1px] grid place-items-center">
                  <span className="inline-flex items-center gap-2 text-xs font-medium text-muted-foreground">
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" /> Querying server…
                  </span>
                </div>
              )}
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-transparent">
                    {sortableColumns.map((c) => (
                      <TableHead
                        key={c.key}
                        className={cn(
                          "text-xs uppercase tracking-wide font-semibold text-muted-foreground cursor-pointer hover:text-foreground select-none",
                          c.align === "right" && "text-right",
                          serverSort?.key === c.key && "text-foreground"
                        )}
                        onClick={() => triggerServerSort(c.key)}
                      >
                        <span className={cn("inline-flex items-center gap-1", c.align === "right" && "flex-row-reverse")}>
                          {c.label}
                          <SortIcon
                            active={serverSort?.key === c.key}
                            direction={serverSort?.key === c.key ? serverSort.direction : null}
                          />
                        </span>
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {serverSorted.slice(0, 8).map((tx) => (
                    <TableRow key={tx.id} className={cn(serverLoading && "opacity-50")}>
                      <TableCell className="font-mono text-xs text-primary">{tx.id}</TableCell>
                      <TableCell className="font-mono text-[11px] text-muted-foreground">{tx.reference}</TableCell>
                      <TableCell className="text-sm font-medium">{tx.customer}</TableCell>
                      <TableCell>
                        <StatusBadge tone={typeToneMap[tx.type]} className="capitalize">{tx.type}</StatusBadge>
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-sm font-medium">
                        <span className={tx.amount < 0 ? "text-[color:var(--danger)]" : ""}>
                          {tx.amount < 0 ? "−" : ""}${Math.abs(tx.amount).toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="font-mono text-[11px] text-muted-foreground">{tx.date}</TableCell>
                      <TableCell>
                        <StatusBadge tone={statusToneMap[tx.status]} dot className="capitalize">{tx.status}</StatusBadge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="flex items-center justify-between mt-2.5">
              <p className="text-xs text-muted-foreground">
                {serverSort ? `Last query: ORDER BY ${serverSort.key} ${serverSort.direction.toUpperCase()}` : "No active sort — click a header to query the server."}
              </p>
              <p className="text-xs font-mono text-muted-foreground">{serverSorted.length} rows · 8 shown</p>
            </div>
          </CardContent>
        </Card>

        {/* Sort legend strip — unique visual element */}
        <Card>
          <CardContent className="pt-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-start gap-3">
                <span className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary shrink-0">
                  <ChevronUp className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-medium">Click to cycle</p>
                  <p className="text-xs text-muted-foreground mt-0.5">No sort → ascending → descending → cleared. Visual chevron rotates to match direction.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)] shrink-0">
                  <Layers className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-medium">Stack with Shift-click</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Each header click in multi-sort mode adds a level. Numbered badges show which column wins ties.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--success)]/12 text-[color:var(--success)] shrink-0">
                  <Server className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-medium">Server-side roundtrip</p>
                  <p className="text-xs text-muted-foreground mt-0.5">For huge datasets the actual sort happens on the server. Loading state blocks interactions until results arrive.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
