"use client";

import * as React from "react";
import {
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  Info,
  X,
  Bell,
  Rocket,
  ShieldCheck,
  RefreshCw,
  ArrowRight,
  Terminal,
  CircleAlert,
  OctagonAlert,
  CircleX,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const successTone = "bg-[color:var(--success)]/15 text-[color:var(--success)] border-[color:var(--success)]/25 [&>svg]:text-[color:var(--success)]";
const warningTone = "bg-[color:var(--warning)]/15 text-[color:var(--warning)] border-[color:var(--warning)]/25 [&>svg]:text-[color:var(--warning)]";
const infoTone = "bg-[color:var(--info)]/15 text-[color:var(--info)] border-[color:var(--info)]/25 [&>svg]:text-[color:var(--info)]";
const dangerTone = "bg-destructive/10 text-destructive border-destructive/25 [&>svg]:text-destructive";

export default function AlertsPage() {
  const [dismissed, setDismissed] = React.useState<Record<string, boolean>>({});

  const dismiss = (id: string) => setDismissed((d) => ({ ...d, [id]: true }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Alerts"
        description="Inline contextual feedback — variants, titles, actions, dismissible state and live toast triggers."
        icon={AlertCircle}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/alerts" },
          { label: "Alerts" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.info("All alerts restored")}>
            <RefreshCw /> Restore alerts
          </Button>
        }
      />

      {/* Banner alert */}
      {!dismissed.banner && (
        <div className="relative rounded-xl border bg-gradient-to-r from-primary/10 via-primary/5 to-transparent p-4 pr-12">
          <button
            type="button"
            onClick={() => dismiss("banner")}
            aria-label="Dismiss banner"
            className="absolute right-3 top-3 grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-foreground/5"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/15 text-primary">
                <Rocket className="h-4 w-4" />
              </div>
              <div>
                <p className="text-sm font-semibold">NexusGrid 4.2 is now available</p>
                <p className="text-sm text-muted-foreground mt-0.5">
                  New billing engine, audit log exports, and 14 fresh dashboard templates. Rollout is gradual over the next 48 hours.
                </p>
              </div>
            </div>
            <div className="flex shrink-0 gap-2">
              <Button size="sm" variant="outline" onClick={() => toast.message("Changelog opened in a new tab")}>
                Read changelog
              </Button>
              <Button size="sm" onClick={() => toast.success("Update scheduled — you will be notified")}>
                Update now
              </Button>
            </div>
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Variants</CardTitle>
          <CardDescription>
            Five semantic tones for default, success, warning, info, and destructive feedback.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Alert>
            <Terminal className="h-4 w-4" />
            <AlertTitle>Heads up</AlertTitle>
            <AlertDescription>
              Your workspace trial expires in 6 days. Add a payment method to keep your data after the trial ends.
            </AlertDescription>
          </Alert>

          <Alert className={successTone}>
            <CheckCircle2 className="h-4 w-4" />
            <AlertTitle>Payment received</AlertTitle>
            <AlertDescription>
              Invoice INV-2041 has been paid in full by Globex Industries. Receipt sent to billing@nexusgrid.io.
            </AlertDescription>
          </Alert>

          <Alert className={warningTone}>
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Storage almost full</AlertTitle>
            <AlertDescription>
              You have used 92% of your 50 GB storage quota. Consider archiving old projects or upgrading your plan.
            </AlertDescription>
          </Alert>

          <Alert className={infoTone}>
            <Info className="h-4 w-4" />
            <AlertTitle>Scheduled maintenance</AlertTitle>
            <AlertDescription>
              The analytics service will be unavailable on Sunday, July 6 between 02:00 and 04:00 UTC for database upgrades.
            </AlertDescription>
          </Alert>

          <Alert variant="destructive">
            <OctagonAlert className="h-4 w-4" />
            <AlertTitle>Failed to publish release</AlertTitle>
            <AlertDescription>
              Build step exited with code 1. The deployment to production was cancelled. Check the build log for details.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">With actions</CardTitle>
            <CardDescription>
              Alert actions give the user a clear next step without leaving the context.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Alert className={warningTone}>
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Unsaved changes</AlertTitle>
              <AlertDescription className="space-y-3">
                You have 4 unsaved edits on the pricing page. They will be lost if you navigate away.
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => toast.message("Draft saved")}>
                    Save draft
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => toast.error("Discarded unsaved edits")}>
                    Discard
                  </Button>
                </div>
              </AlertDescription>
            </Alert>

            <Alert className={infoTone}>
              <ShieldCheck className="h-4 w-4" />
              <AlertTitle>Enable two-factor authentication</AlertTitle>
              <AlertDescription className="space-y-3">
                Add an extra layer of security to your account. We strongly recommend enabling 2FA for all admins.
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" onClick={() => toast.success("2FA setup wizard launched")}>
                    Enable 2FA <ArrowRight />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => toast.message("Reminder snoozed for 7 days")}>
                    Remind me later
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Dismissible</CardTitle>
            <CardDescription>
              Inline alerts with a close button — useful for transient system messages.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {!dismissed.a1 && (
              <div className="relative">
                <Alert className={cn(successTone, "pr-10")}>
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>Email verified</AlertTitle>
                  <AlertDescription>
                    Your address amara@nexusgrid.io is now verified. You can enable SSO from security settings.
                  </AlertDescription>
                </Alert>
                <button
                  type="button"
                  aria-label="Dismiss"
                  onClick={() => dismiss("a1")}
                  className="absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-foreground/5"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {!dismissed.a2 && (
              <div className="relative">
                <Alert className={cn(infoTone, "pr-10")}>
                  <Info className="h-4 w-4" />
                  <AlertTitle>New comment on API Keys</AlertTitle>
                  <AlertDescription>
                    Devon Park mentioned you in the API Keys documentation. Click to view the thread.
                  </AlertDescription>
                </Alert>
                <button
                  type="button"
                  aria-label="Dismiss"
                  onClick={() => dismiss("a2")}
                  className="absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-foreground/5"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {!dismissed.a3 && (
              <div className="relative">
                <Alert variant="destructive" className="pr-10">
                  <CircleAlert className="h-4 w-4" />
                  <AlertTitle>Webhook delivery failed</AlertTitle>
                  <AlertDescription>
                    The endpoint https://api.acme.io/hooks/billing returned 503. Retrying in 5 minutes.
                  </AlertDescription>
                </Alert>
                <button
                  type="button"
                  aria-label="Dismiss"
                  onClick={() => dismiss("a3")}
                  className="absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-foreground/5"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {(dismissed.a1 && dismissed.a2 && dismissed.a3) && (
              <p className="text-sm text-muted-foreground py-6 text-center">
                All alerts dismissed. Use "Restore alerts" in the header to bring them back.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Live toast triggers</CardTitle>
          <CardDescription>
            Inline alerts are great for persistent context, but transient feedback should use Sonner toasts.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => toast.success("Settings saved successfully.")}>
            <CheckCircle2 className="text-[color:var(--success)]" /> Trigger success
          </Button>
          <Button variant="outline" onClick={() => toast.error("Could not connect to the database.")}>
            <CircleX className="text-destructive" /> Trigger error
          </Button>
          <Button variant="outline" onClick={() => toast.warning("Your session will expire in 5 minutes.")}>
            <AlertTriangle className="text-[color:var(--warning)]" /> Trigger warning
          </Button>
          <Button variant="outline" onClick={() => toast.info("A new version of the docs is available.")}>
            <Info className="text-[color:var(--info)]" /> Trigger info
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast("Workspace archived", {
                description: "Acme Corp has been moved to the archived list.",
                action: { label: "Undo", onClick: () => toast.success("Workspace restored.") },
              })
            }
          >
            <Bell /> Trigger default with action
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Inline alerts in a form context</CardTitle>
          <CardDescription>
            Compact form-level alerts rendered above inputs to surface validation errors or context.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Alert className={dangerTone + " py-2.5"}>
            <CircleAlert className="h-4 w-4" />
            <AlertDescription>
              <span className="font-medium">3 fields need attention:</span> email format invalid, password too short, and the
              billing address ZIP code is missing.
            </AlertDescription>
          </Alert>
          <Alert className={successTone + " py-2.5"}>
            <CheckCircle2 className="h-4 w-4" />
            <AlertDescription>
              Your profile is 100% complete. Profiles with photos receive up to 36% more inbound requests.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Alerts page · 5 variants · banner · with actions · dismissible · live toast triggers
      </p>
    </div>
  );
}
