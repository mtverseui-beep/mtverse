"use client";

import * as React from "react";
import {
  Key,
  KeyRound,
  Plus,
  Copy,
  Eye,
  EyeOff,
  Trash2,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Activity,
  Shield,
  Zap,
  TrendingUp,
  MoreHorizontal,
  RefreshCw,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { AreaTrendChart } from "@/components/charts";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type ApiKey = {
  id: string;
  name: string;
  prefix: string;
  masked: string;
  created: string;
  lastUsed: string;
  permissions: string[];
  status: "active" | "revoked" | "expiring";
  env: "production" | "staging" | "development";
  calls: number;
};

const KEYS: ApiKey[] = [
  { id: "k1", name: "production-read-only", prefix: "nxg_live_", masked: "nxg_live_••••••••••••••8f2a", created: "Jul 12, 2026", lastUsed: "2 min ago", permissions: ["read:orders", "read:customers", "read:reports"], status: "active", env: "production", calls: 184200 },
  { id: "k2", name: "billing-webhook-handler", prefix: "nxg_live_", masked: "nxg_live_••••••••••••••a1b9", created: "Jun 28, 2026", lastUsed: "12 min ago", permissions: ["read:invoices", "write:invoices", "read:billing"], status: "active", env: "production", calls: 42800 },
  { id: "k3", name: "analytics-pipeline", prefix: "nxg_live_", masked: "nxg_live_••••••••••••••c3d7", created: "Jun 14, 2026", lastUsed: "1 hour ago", permissions: ["read:reports", "read:metrics"], status: "active", env: "production", calls: 928400 },
  { id: "k4", name: "staging-integration-tests", prefix: "nxg_test_", masked: "nxg_test_••••••••••••••e5f2", created: "May 30, 2026", lastUsed: "Yesterday", permissions: ["read:*", "write:*"], status: "active", env: "staging", calls: 14200 },
  { id: "k5", name: "mobile-app-backend", prefix: "nxg_live_", masked: "nxg_live_••••••••••••••g7h8", created: "Apr 18, 2026", lastUsed: "5 min ago", permissions: ["read:customers", "write:orders", "read:products"], status: "active", env: "production", calls: 1284000 },
  { id: "k6", name: "legacy-cron-sync", prefix: "nxg_live_", masked: "nxg_live_••••••••••••••i9j0", created: "Jan 03, 2026", lastUsed: "47 days ago", permissions: ["read:customers"], status: "expiring", env: "production", calls: 8420 },
  { id: "k7", name: "dev-local-amara", prefix: "nxg_test_", masked: "nxg_test_••••••••••••••k1l2", created: "Dec 12, 2025", lastUsed: "3 hours ago", permissions: ["read:*", "write:*", "admin:*"], status: "active", env: "development", calls: 2840 },
  { id: "k8", name: "deprecated-zapier", prefix: "nxg_live_", masked: "nxg_live_••••••••••••••m3n4", created: "Sep 04, 2025", lastUsed: "Never", permissions: ["read:orders"], status: "revoked", env: "production", calls: 0 },
];

const USAGE_DATA = [
  { day: "Jul 8", calls: 42800, errors: 12 },
  { day: "Jul 9", calls: 51400, errors: 4 },
  { day: "Jul 10", calls: 48200, errors: 18 },
  { day: "Jul 11", calls: 62800, errors: 2 },
  { day: "Jul 12", calls: 71400, errors: 8 },
  { day: "Jul 13", calls: 68200, errors: 24 },
  { day: "Jul 14", calls: 54800, errors: 6 },
];

const envTone: Record<ApiKey["env"], "success" | "warning" | "neutral"> = {
  production: "success",
  staging: "warning",
  development: "neutral",
};

const statusTone: Record<ApiKey["status"], "success" | "danger" | "warning"> = {
  active: "success",
  revoked: "danger",
  expiring: "warning",
};

const ALL_PERMS = [
  { id: "read:orders", label: "Read orders", group: "Orders" },
  { id: "write:orders", label: "Create/update orders", group: "Orders" },
  { id: "read:customers", label: "Read customers", group: "Customers" },
  { id: "write:customers", label: "Create/update customers", group: "Customers" },
  { id: "read:invoices", label: "Read invoices", group: "Billing" },
  { id: "write:invoices", label: "Create/update invoices", group: "Billing" },
  { id: "read:reports", label: "Read reports", group: "Analytics" },
  { id: "read:metrics", label: "Read metrics", group: "Analytics" },
  { id: "read:products", label: "Read products", group: "Catalog" },
  { id: "write:products", label: "Create/update products", group: "Catalog" },
];

export default function ApiKeysPage() {
  const [revealed, setRevealed] = React.useState<Set<string>>(new Set());
  const [createOpen, setCreateOpen] = React.useState(false);
  const [newKeyName, setNewKeyName] = React.useState("");
  const [newKeyPerms, setNewKeyPerms] = React.useState<Set<string>>(new Set(["read:orders"]));
  const [newKeyEnv, setNewKeyEnv] = React.useState<ApiKey["env"]>("production");
  const [newKeyValue, setNewKeyValue] = React.useState<string | null>(null);

  const toggleReveal = (id: string) =>
    setRevealed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const copyKey = (id: string, val: string) => {
    navigator.clipboard?.writeText(val);
    toast.success("API key copied", { description: "Paste it into your service now — it won't be shown again." });
  };

  const togglePerm = (p: string) =>
    setNewKeyPerms((prev) => {
      const next = new Set(prev);
      if (next.has(p)) next.delete(p);
      else next.add(p);
      return next;
    });

  const createKey = () => {
    if (!newKeyName.trim()) {
      toast.error("Name required");
      return;
    }
    const generated = `nxg_${newKeyEnv === "production" ? "live" : "test"}_${Math.random().toString(36).slice(2, 18)}${Math.random().toString(36).slice(2, 6)}`;
    setNewKeyValue(generated);
    toast.success("API key created", { description: "Copy it now — you won't see it again." });
  };

  const closeCreate = () => {
    setCreateOpen(false);
    setNewKeyName("");
    setNewKeyPerms(new Set(["read:orders"]));
    setNewKeyEnv("production");
    setNewKeyValue(null);
  };

  const totalCalls = KEYS.reduce((acc, k) => acc + k.calls, 0);
  const activeKeys = KEYS.filter((k) => k.status === "active").length;

  return (
    <>
      <PageHeader
        title="API Keys"
        description="Programmatic access tokens for your services. Rotate often, scope narrowly, revoke ruthlessly."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "API Keys" }]}
        icon={Key}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setCreateOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> Create key
          </Button>
        }
      />

      {/* SUMMARY + USAGE CHART */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-1 grid grid-cols-2 lg:grid-cols-1 gap-3">
          {[
            { icon: Key, tone: "bg-primary/12 text-primary", label: "Total keys", value: String(KEYS.length), hint: `${activeKeys} active` },
            { icon: Activity, tone: "bg-[color:var(--info)]/12 text-[color:var(--info)]", label: "Calls (7d)", value: (totalCalls / 1000).toFixed(0) + "K", hint: "Across all keys" },
            { icon: AlertTriangle, tone: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]", label: "Expiring", value: String(KEYS.filter((k) => k.status === "expiring").length), hint: "Rotate within 14d" },
            { icon: TrendingUp, tone: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Success rate", value: "99.94%", hint: "Last 7 days" },
          ].map((s) => (
            <Card key={s.label} className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className={cn("grid place-items-center h-7 w-7 rounded-md", s.tone)}><s.icon className="h-3.5 w-3.5" /></div>
                <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</span>
              </div>
              <p className="text-xl font-semibold tabular-nums leading-tight">{s.value}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{s.hint}</p>
            </Card>
          ))}
        </div>

        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" /> API usage
                </CardTitle>
                <CardDescription>Total calls and errors across all keys · last 7 days.</CardDescription>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary" /> Calls</span>
                <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-destructive" /> Errors</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={USAGE_DATA}
              xKey="day"
              series={[
                { key: "calls", name: "API calls", color: "var(--primary)" },
                { key: "errors", name: "Errors", color: "var(--destructive)" },
              ]}
              height={240}
            />
          </CardContent>
        </Card>
      </div>

      {/* KEYS LIST */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Your API keys</CardTitle>
          <CardDescription>{KEYS.length} keys configured · sorted by last used.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {KEYS.map((k) => (
              <div key={k.id} className="p-4 hover:bg-muted/30 transition-colors">
                <div className="flex items-start gap-3">
                  <div className={cn("grid place-items-center h-10 w-10 rounded-lg shrink-0",
                    k.status === "revoked" ? "bg-destructive/12 text-destructive" :
                    k.status === "expiring" ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" :
                    "bg-primary/12 text-primary"
                  )}>
                    <KeyRound className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold">{k.name}</p>
                      <StatusBadge tone={statusTone[k.status]} dot>{k.status}</StatusBadge>
                      <StatusBadge tone={envTone[k.env]}>{k.env}</StatusBadge>
                      {k.calls > 1000000 && (
                        <Badge variant="outline" className="text-[9px] gap-1 border-[color:var(--success)]/40 text-[color:var(--success)] bg-[color:var(--success)]/5">
                          <Zap className="h-2.5 w-2.5" /> High traffic
                        </Badge>
                      )}
                    </div>

                    {/* Key value with copy + reveal */}
                    <div className="flex items-center gap-2 mt-2">
                      <code className="font-mono text-xs bg-muted px-2 py-1.5 rounded border border-border flex-1 min-w-0 truncate">
                        {revealed.has(k.id) ? `nxg_${k.env === "production" ? "live" : "test"}_sk_live_8f2a9c1b3d7e5f2a${k.id}` : k.masked}
                      </code>
                      <Button variant="outline" size="icon" className="h-7 w-7 shrink-0" onClick={() => toggleReveal(k.id)}>
                        {revealed.has(k.id) ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </Button>
                      <Button variant="outline" size="icon" className="h-7 w-7 shrink-0" onClick={() => copyKey(k.id, k.masked)}>
                        <Copy className="h-3.5 w-3.5" />
                      </Button>
                    </div>

                    {/* Permissions */}
                    <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                      <Shield className="h-3 w-3 text-muted-foreground shrink-0" />
                      {k.permissions.slice(0, 4).map((p) => (
                        <code key={p} className="font-mono text-[10px] bg-muted px-1.5 py-0.5 rounded text-muted-foreground">{p}</code>
                      ))}
                      {k.permissions.length > 4 && (
                        <span className="text-[10px] text-muted-foreground">+{k.permissions.length - 4} more</span>
                      )}
                    </div>

                    {/* Meta */}
                    <div className="flex items-center gap-4 mt-2.5 text-[11px] text-muted-foreground flex-wrap">
                      <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" /> Created {k.created}</span>
                      <span className="inline-flex items-center gap-1"><Activity className="h-3 w-3" /> Last used {k.lastUsed}</span>
                      <span className="inline-flex items-center gap-1"><TrendingUp className="h-3 w-3" /> <span className="tabular-nums font-mono">{k.calls.toLocaleString()}</span> calls</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    {k.status !== "revoked" ? (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-xs text-destructive hover:text-destructive hover:bg-destructive/10 gap-1.5">
                            <Trash2 className="h-3.5 w-3.5" /> Revoke
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Revoke “{k.name}”?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This permanently destroys the key. Any service using it will receive 401 Unauthorized immediately. This cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => toast.success("Key revoked", { description: `${k.name} no longer accepts requests.` })}>
                              Revoke key
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    ) : (
                      <span className="text-[11px] text-muted-foreground pr-2">Revoked</span>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message("Edit permissions")}>
                          <Shield className="h-3.5 w-3.5" /> Edit permissions
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success("Key rotated", { description: "A new value has been generated." })}>
                          <RefreshCw className="h-3.5 w-3.5" /> Rotate key
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.message("View usage logs")}>
                          <Activity className="h-3.5 w-3.5" /> View usage logs
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* CREATE KEY DIALOG */}
      <Dialog open={createOpen} onOpenChange={(o) => !o && closeCreate()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{newKeyValue ? "Key created — copy it now" : "Create new API key"}</DialogTitle>
            <DialogDescription>
              {newKeyValue
                ? "This is the only time the full key will be shown. Store it securely."
                : "Generate a scoped token for a service or integration."}
            </DialogDescription>
          </DialogHeader>

          {newKeyValue ? (
            <div className="grid gap-4 py-2">
              <div className="rounded-lg border border-[color:var(--success)]/30 bg-[color:var(--success)]/[0.04] p-3">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="h-4 w-4 text-[color:var(--success)]" />
                  <p className="text-sm font-medium">Key ready</p>
                </div>
                <code className="block font-mono text-xs bg-background border border-border rounded p-2 break-all">{newKeyValue}</code>
              </div>
              <Button className="gap-1.5" onClick={() => { navigator.clipboard?.writeText(newKeyValue); toast.success("Copied to clipboard"); }}>
                <Copy className="h-3.5 w-3.5" /> Copy key
              </Button>
            </div>
          ) : (
            <div className="grid gap-4 py-2">
              <div className="grid gap-1.5">
                <Label className="text-xs">Key name</Label>
                <Input placeholder="e.g. production-read-only" value={newKeyName} onChange={(e) => setNewKeyName(e.target.value)} />
                <p className="text-[11px] text-muted-foreground">A descriptive name to identify this key later.</p>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Environment</Label>
                <div className="grid grid-cols-3 gap-2">
                  {(["production", "staging", "development"] as const).map((env) => (
                    <button
                      key={env}
                      type="button"
                      onClick={() => setNewKeyEnv(env)}
                      className={cn(
                        "rounded-lg border p-2 text-xs font-medium capitalize transition-colors",
                        newKeyEnv === env ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "border-border hover:bg-accent/40"
                      )}
                    >
                      {env}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Permissions</Label>
                <div className="max-h-44 overflow-y-auto rounded-lg border border-border divide-y divide-border">
                  {Object.entries(
                    ALL_PERMS.reduce((acc, p) => {
                      (acc[p.group] = acc[p.group] || []).push(p);
                      return acc;
                    }, {} as Record<string, typeof ALL_PERMS>)
                  ).map(([group, perms]) => (
                    <div key={group} className="p-2">
                      <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-1 mb-1">{group}</p>
                      {perms.map((p) => (
                        <label key={p.id} className="flex items-center gap-2 p-1.5 rounded hover:bg-muted/40 cursor-pointer">
                          <Switch checked={newKeyPerms.has(p.id)} onCheckedChange={() => togglePerm(p.id)} />
                          <span className="text-xs">{p.label}</span>
                          <code className="font-mono text-[10px] text-muted-foreground ml-auto">{p.id}</code>
                        </label>
                      ))}
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground">{newKeyPerms.size} permission{newKeyPerms.size === 1 ? "" : "s"} selected.</p>
              </div>
            </div>
          )}

          <DialogFooter>
            {newKeyValue ? (
              <Button onClick={closeCreate}>Done</Button>
            ) : (
              <>
                <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                <Button className="gap-1.5" onClick={createKey}><Plus className="h-3.5 w-3.5" /> Generate key</Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
