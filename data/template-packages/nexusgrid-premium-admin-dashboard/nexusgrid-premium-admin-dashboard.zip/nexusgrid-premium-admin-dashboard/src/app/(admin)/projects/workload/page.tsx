"use client";

import * as React from "react";
import {
  Users,
  Plus,
  Download,
  Gauge,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ArrowRight,
  ArrowLeftRight,
  Layers,
  Sparkles,
  MoreHorizontal,
  CheckCircle2,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RadarComparison } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Data ---------- */

const projects = [
  { id: "PRJ-014", name: "Atlas", color: "var(--primary)" },
  { id: "PRJ-013", name: "Pulse", color: "var(--info)" },
  { id: "PRJ-012", name: "Vertex", color: "var(--destructive)" },
  { id: "PRJ-011", name: "Nimbus", color: "var(--success)" },
  { id: "PRJ-009", name: "Orbit", color: "oklch(0.62 0.18 305)" },
];

type Member = {
  name: string;
  avatar: string;
  role: string;
  capacity: number;
  allocated: number;
  hours: Record<string, number>;
  skills: { name: string; frontend: number; backend: number; design: number; devops: number; data: number };
};

const members: Member[] = [
  {
    name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop",
    role: "Frontend Lead", capacity: 40, allocated: 38,
    hours: { "PRJ-014": 18, "PRJ-013": 4, "PRJ-012": 0, "PRJ-011": 8, "PRJ-009": 8 },
    skills: { name: "Sarah", frontend: 92, backend: 40, design: 70, devops: 30, data: 45 },
  },
  {
    name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop",
    role: "iOS Engineer", capacity: 40, allocated: 36,
    hours: { "PRJ-014": 22, "PRJ-013": 6, "PRJ-012": 0, "PRJ-011": 4, "PRJ-009": 4 },
    skills: { name: "Marcus", frontend: 75, backend: 50, design: 35, devops: 40, data: 30 },
  },
  {
    name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop",
    role: "Backend Lead", capacity: 40, allocated: 44,
    hours: { "PRJ-014": 6, "PRJ-013": 18, "PRJ-012": 14, "PRJ-011": 4, "PRJ-009": 2 },
    skills: { name: "Elena", frontend: 35, backend: 95, design: 25, devops: 65, data: 70 },
  },
  {
    name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop",
    role: "DevOps Engineer", capacity: 40, allocated: 30,
    hours: { "PRJ-014": 2, "PRJ-013": 4, "PRJ-012": 8, "PRJ-011": 14, "PRJ-009": 2 },
    skills: { name: "James", frontend: 30, backend: 55, design: 20, devops: 95, data: 40 },
  },
  {
    name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop",
    role: "Product Designer", capacity: 40, allocated: 28,
    hours: { "PRJ-014": 16, "PRJ-013": 4, "PRJ-012": 2, "PRJ-011": 4, "PRJ-009": 2 },
    skills: { name: "Aiko", frontend: 60, backend: 20, design: 95, devops: 15, data: 35 },
  },
  {
    name: "David Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop",
    role: "Data Engineer", capacity: 32, allocated: 22,
    hours: { "PRJ-014": 0, "PRJ-013": 6, "PRJ-012": 0, "PRJ-011": 2, "PRJ-009": 14 },
    skills: { name: "David", frontend: 25, backend: 65, design: 15, devops: 55, data: 92 },
  },
];

const radarSkills = [
  { name: "Frontend", Sarah: 92, team: 53 },
  { name: "Backend", Sarah: 40, team: 60 },
  { name: "Design", Sarah: 70, team: 43 },
  { name: "DevOps", Sarah: 30, team: 50 },
  { name: "Data", Sarah: 45, team: 52 },
];

const rebalanceSuggestions = [
  {
    from: "Elena Petrov",
    fromAvatar: members[2].avatar,
    to: "David Kim",
    toAvatar: members[5].avatar,
    task: "Orbit Kafka backfill job",
    points: 8,
    reason: "Elena is 4h over capacity · David has 10h available",
  },
  {
    from: "Sarah Chen",
    fromAvatar: members[0].avatar,
    to: "Aiko Tanaka",
    toAvatar: members[4].avatar,
    task: "Atlas onboarding tour mockups",
    points: 5,
    reason: "Sarah near burnout · Aiko has 12h free design capacity",
  },
  {
    from: "Marcus Reyes",
    fromAvatar: members[1].avatar,
    to: "James Okoro",
    toAvatar: members[3].avatar,
    task: "Nimbus CI pipeline setup",
    points: 3,
    reason: "Marcus at 90% · James at 75% with DevOps bandwidth",
  },
];

/* ---------- WorkloadKpi — capacity gauge motif ---------- */

function WorkloadKpi({
  label,
  value,
  unit,
  icon: Icon,
  accent,
  capacity,
  allocated,
  available,
  trend,
  caption,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  accent: "primary" | "success" | "warning" | "danger";
  capacity: number;
  allocated: number;
  available: number;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  caption: string;
}) {
  const colorMap: Record<string, string> = {
    primary: "var(--primary)",
    success: "var(--success)",
    warning: "var(--warning)",
    danger: "var(--destructive)",
  };
  const bgMap: Record<string, string> = {
    primary: "bg-primary/12 text-primary",
    success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/12 text-[color:var(--warning)]",
    danger: "bg-destructive/12 text-destructive",
  };
  const color = colorMap[accent];
  const allocatedPct = (allocated / capacity) * 100;
  const availablePct = (available / capacity) * 100;

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">{label}</p>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
            {unit && <span className="text-sm font-medium text-muted-foreground">{unit}</span>}
            <span className={cn("inline-flex items-center gap-0.5 text-xs font-medium tabular-nums ml-1", trend.positive ? "text-[color:var(--success)]" : "text-destructive")}>
              {trend.direction === "up" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              {Math.abs(trend.value)}%
            </span>
          </div>
        </div>
        <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", bgMap[accent])}>
          <Icon className="h-4.5 w-4.5" />
        </div>
      </div>

      {/* 3-segment stacked capacity gauge */}
      <div className="mb-1.5">
        <div className="flex h-3 w-full rounded-full overflow-hidden ring-1 ring-inset ring-border">
          <div className="h-full bg-primary" style={{ width: `${allocatedPct}%` }} title={`Allocated: ${allocated}h`} />
          <div className="h-full bg-[color:var(--success)]/40" style={{ width: `${availablePct}%` }} title={`Available: ${available}h`} />
        </div>
      </div>
      <div className="flex items-center justify-between text-[10px] text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-sm bg-primary" /> {allocated}h alloc
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-sm bg-[color:var(--success)]/40" /> {available}h free
        </span>
        <span className="tabular-nums">/ {capacity}h</span>
      </div>

      <p className="mt-2 text-[11px] text-muted-foreground truncate">{caption}</p>
    </div>
  );
}

/* ---------- Page ---------- */

export default function TeamWorkloadPage() {
  const totalCapacity = members.reduce((s, m) => s + m.capacity, 0);
  const totalAllocated = members.reduce((s, m) => s + m.allocated, 0);
  const totalAvailable = totalCapacity - totalAllocated;
  const overloadedCount = members.filter((m) => m.allocated > m.capacity).length;
  const utilizationPct = Math.round((totalAllocated / totalCapacity) * 100);

  return (
    <>
      <PageHeader
        title="Team Workload"
        description="Visualize capacity allocation across projects and rebalance before burnout."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: "Team Workload" }]}
        icon={Users}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Workload report exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Rebalance assistant opened")}>
              <Sparkles className="h-3.5 w-3.5" /> Auto-rebalance
            </Button>
          </>
        }
      />

      {/* KPI row — WorkloadKpi with 3-segment capacity gauge */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <WorkloadKpi
          label="Total Capacity"
          value={String(totalCapacity)}
          unit="h/wk"
          icon={Gauge}
          accent="primary"
          capacity={totalCapacity}
          allocated={totalAllocated}
          available={totalAvailable}
          trend={{ value: 4, direction: "up", positive: true }}
          caption={`${members.length} team members`}
        />
        <WorkloadKpi
          label="Allocated"
          value={String(totalAllocated)}
          unit="h"
          icon={Layers}
          accent="success"
          capacity={totalCapacity}
          allocated={totalAllocated}
          available={totalAvailable}
          trend={{ value: 8, direction: "up", positive: true }}
          caption={`${utilizationPct}% utilization`}
        />
        <WorkloadKpi
          label="Available"
          value={String(totalAvailable)}
          unit="h"
          icon={TrendingDown}
          accent="warning"
          capacity={totalCapacity}
          allocated={totalAllocated}
          available={totalAvailable}
          trend={{ value: 6, direction: "down", positive: false }}
          caption="across 4 under-utilized members"
        />
        <WorkloadKpi
          label="Overloaded"
          value={String(overloadedCount)}
          icon={AlertTriangle}
          accent="danger"
          capacity={totalCapacity}
          allocated={totalAllocated}
          available={totalAvailable}
          trend={{ value: 2, direction: "up", positive: false }}
          caption="members above capacity"
        />
      </div>

      {/* Workload matrix + skill radar */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        {/* Matrix grid */}
        <Card className="xl:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Layers className="h-4 w-4 text-violet-500" />
              Workload Matrix — Hours per Project
            </CardTitle>
            <CardDescription>Each cell shows weekly hours allocated to a project. Color intensity = load.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-y border-border bg-muted/40">
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 min-w-[180px]">Team Member</th>
                    {projects.map((p) => (
                      <th key={p.id} className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-2 py-2.5 min-w-[80px]">
                        <div className="flex items-center justify-center gap-1.5">
                          <span className="h-2 w-2 rounded-full" style={{ background: p.color }} />
                          {p.name}
                        </div>
                      </th>
                    ))}
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 min-w-[80px]">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {members.map((m) => {
                    const rowTotal = m.allocated;
                    const pct = (m.allocated / m.capacity) * 100;
                    return (
                      <tr key={m.name} className="hover:bg-muted/20 transition-colors">
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-7 w-7">
                              <AvatarImage src={m.avatar} alt={m.name} />
                              <AvatarFallback className="text-[10px]">{m.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                              <p className="text-[10px] text-muted-foreground truncate">{m.role}</p>
                            </div>
                          </div>
                        </td>
                        {projects.map((p) => {
                          const h = m.hours[p.id] || 0;
                          const intensity = h / 24;
                          return (
                            <td key={p.id} className="px-1 py-1.5 text-center">
                              {h > 0 ? (
                                <div
                                  className="grid place-items-center mx-auto h-8 w-12 rounded-md text-xs font-semibold tabular-nums"
                                  style={{
                                    background: `color-mix(in srgb, ${p.color} ${8 + intensity * 30}%, transparent)`,
                                    color: h > 14 ? p.color : "var(--foreground)",
                                  }}
                                  title={`${m.name} · ${p.name}: ${h}h`}
                                >
                                  {h}h
                                </div>
                              ) : (
                                <span className="text-muted-foreground/30 text-xs">—</span>
                              )}
                            </td>
                          );
                        })}
                        <td className="px-4 py-2.5 text-right">
                          <div className="inline-flex flex-col items-end gap-0.5">
                            <span className={cn(
                              "text-sm font-bold tabular-nums",
                              pct > 100 ? "text-destructive" : pct >= 90 ? "text-[color:var(--warning)]" : "text-foreground"
                            )}>
                              {rowTotal}h
                            </span>
                            <span className="text-[10px] text-muted-foreground tabular-nums">/ {m.capacity}h</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-border bg-muted/40">
                    <td className="px-4 py-2.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Project Total</td>
                    {projects.map((p) => {
                      const colTotal = members.reduce((s, m) => s + (m.hours[p.id] || 0), 0);
                      return (
                        <td key={p.id} className="px-2 py-2.5 text-center">
                          <span className="inline-block text-xs font-bold tabular-nums px-1.5 py-0.5 rounded" style={{ background: `color-mix(in srgb, ${p.color} 12%, transparent)`, color: p.color }}>
                            {colTotal}h
                          </span>
                        </td>
                      );
                    })}
                    <td className="px-4 py-2.5 text-right">
                      <span className="text-sm font-bold tabular-nums text-primary">{totalAllocated}h</span>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Skill distribution radar */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-violet-500" />
              Skill Distribution
            </CardTitle>
            <CardDescription>Sarah Chen vs. team average across skill areas.</CardDescription>
          </CardHeader>
          <CardContent>
            <RadarComparison
              data={radarSkills}
              axisKey="name"
              series={[
                { key: "Sarah", name: "Sarah Chen", color: "var(--primary)" },
                { key: "team", name: "Team Avg", color: "var(--info)" },
              ]}
              height={280}
            />
            <div className="mt-3 pt-3 border-t border-border space-y-2">
              {[
                { skill: "Frontend", sarah: 92, team: 53, gap: "+39" },
                { skill: "Backend", sarah: 40, team: 60, gap: "−20" },
                { skill: "Design", sarah: 70, team: 43, gap: "+27" },
              ].map((s) => (
                <div key={s.skill} className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{s.skill}</span>
                  <div className="flex items-center gap-3">
                    <span className="tabular-nums text-primary font-medium">{s.sarah}</span>
                    <span className="text-muted-foreground">vs</span>
                    <span className="tabular-nums text-[color:var(--info)] font-medium">{s.team}</span>
                    <span className={cn("tabular-nums font-semibold w-10 text-right", s.gap.startsWith("+") ? "text-[color:var(--success)]" : "text-[color:var(--warning)]")}>
                      {s.gap}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Per-member workload bars + suggested rebalancing */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Per-member bars */}
        <Card className="xl:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Gauge className="h-4 w-4 text-violet-500" />
              Capacity vs. Allocated — Per Member
            </CardTitle>
            <CardDescription>Bars show weekly capacity with allocated overlay. Red = over capacity.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {members.map((m) => {
              const pct = (m.allocated / m.capacity) * 100;
              const over = m.allocated > m.capacity;
              const remaining = m.capacity - m.allocated;
              return (
                <div key={m.name} className="flex items-center gap-3">
                  <div className="flex items-center gap-2 w-44 shrink-0">
                    <Avatar className="h-7 w-7">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback className="text-[10px]">{m.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <p className="text-xs font-medium truncate">{m.name}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{m.role}</p>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="relative h-6 rounded-full bg-muted overflow-hidden ring-1 ring-inset ring-border">
                      {/* Capacity baseline marker at 100% */}
                      <div
                        className={cn(
                          "absolute inset-y-0 left-0 rounded-full transition-all duration-700",
                          over ? "bg-destructive/80" : pct >= 90 ? "bg-[color:var(--warning)]" : "bg-primary"
                        )}
                        style={{ width: `${Math.min(pct, 100)}%` }}
                      />
                      {/* Over-capacity overflow indicator */}
                      {over && (
                        <div className="absolute inset-y-0 right-0 flex items-center pr-2">
                          <span className="text-[10px] font-bold text-destructive-foreground tabular-nums">
                            +{m.allocated - m.capacity}h
                          </span>
                        </div>
                      )}
                      {/* 100% capacity tick */}
                      <div className="absolute inset-y-0 w-px bg-border/80" style={{ left: "100%" }} />
                    </div>
                  </div>
                  <div className="text-right shrink-0 w-24">
                    <p className={cn("text-xs font-bold tabular-nums", over ? "text-destructive" : "text-foreground")}>
                      {m.allocated}h / {m.capacity}h
                    </p>
                    <StatusBadge tone={over ? "danger" : pct >= 90 ? "warning" : "success"} className="text-[9px] mt-0.5">
                      {over ? "Overloaded" : pct >= 90 ? "Near limit" : "Healthy"}
                    </StatusBadge>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Suggested rebalancing panel */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <ArrowLeftRight className="h-4 w-4 text-violet-500" />
              Suggested Rebalancing
            </CardTitle>
            <CardDescription>AI-suggested task moves to balance the team.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1 custom-scroll">
            {rebalanceSuggestions.map((s, i) => (
              <div key={i} className="rounded-lg border border-border p-3 hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={s.fromAvatar} alt={s.from} />
                    <AvatarFallback className="text-[9px]">{s.from.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                  </Avatar>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={s.toAvatar} alt={s.to} />
                    <AvatarFallback className="text-[9px]">{s.to.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                  </Avatar>
                  <div className="ml-auto">
                    <StatusBadge tone="primary" className="text-[9px]">{s.points} pts</StatusBadge>
                  </div>
                </div>
                <p className="text-xs font-medium text-foreground mb-1">{s.task}</p>
                <p className="text-[10px] text-muted-foreground line-clamp-2 mb-2">{s.reason}</p>
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 text-[10px] gap-1 flex-1"
                    onClick={() => toast.success(`Reassigned "${s.task}" to ${s.to}`)}
                  >
                    <CheckCircle2 className="h-3 w-3" /> Apply
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-[10px] px-2"
                    onClick={() => toast.message("Suggestion dismissed")}
                  >
                    <MoreHorizontal className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
            <div className="rounded-lg border border-dashed border-violet-500/30 bg-violet-500/[0.03] p-3 text-center">
              <Sparkles className="h-4 w-4 text-violet-500 mx-auto mb-1" />
              <p className="text-[11px] font-medium text-foreground">3 more suggestions available</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Apply all to balance team in 1 click</p>
              <Button
                variant="outline"
                size="sm"
                className="mt-2 h-7 text-[10px] gap-1 w-full"
                onClick={() => toast.success("Applying all 6 rebalance suggestions")}
              >
                Apply All <ArrowRight className="h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
