"use client";

import * as React from "react";
import {
  Mail,
  Phone,
  Clock,
  Send,
  Paperclip,
  MessageSquare,
  Users,
  Activity,
  ArrowUpRight,
  Search,
  X,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const RECENT_TICKETS = [
  { id: "TKT-4821", subject: "Cannot invite user to workspace", status: "open", priority: "high", updated: "2h ago", category: "Account" },
  { id: "TKT-4798", subject: "Webhook delivery failures from Stripe", status: "in_progress", priority: "medium", updated: "1d ago", category: "API" },
  { id: "TKT-4772", subject: "Invoice PDF missing VAT number", status: "resolved", priority: "low", updated: "3d ago", category: "Billing" },
  { id: "TKT-4751", subject: "Custom field formula not evaluating", status: "resolved", priority: "medium", updated: "5d ago", category: "Features" },
];

const CATEGORIES = [
  { value: "account", label: "Account & Login" },
  { value: "billing", label: "Billing & Invoices" },
  { value: "features", label: "Features & How-to" },
  { value: "integrations", label: "Integrations" },
  { value: "api", label: "API & Developers" },
  { value: "security", label: "Security & Privacy" },
  { value: "bug", label: "Bug Report" },
  { value: "other", label: "Other" },
];

export default function ContactSupportPage() {
  const [files, setFiles] = React.useState<string[]>([]);
  const [submitting, setSubmitting] = React.useState(false);

  const onPickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newFiles = Array.from(e.target.files ?? []).map((f) => f.name);
    setFiles((prev) => [...prev, ...newFiles].slice(0, 5));
    e.target.value = "";
  };

  const removeFile = (name: string) => setFiles((prev) => prev.filter((f) => f !== name));

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Ticket submitted", { description: "We'll respond within 4 hours. Reference ID: TKT-4845." });
      setFiles([]);
      (e.target as HTMLFormElement).reset();
    }, 900);
  };

  return (
    <>
      <PageHeader
        title="Contact Support"
        description="Reach out to our team — we typically reply within 4 hours during business days."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Contact Support" }]}
        icon={Mail}
      />

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6 mb-6">
        {/* CONTACT FORM */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Submit a support request</CardTitle>
            <CardDescription>Fill out the form and our team will get back to you by email.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Full name</Label>
                  <Input id="name" placeholder="Jordan Avery" required />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email address</Label>
                  <Input id="email" type="email" placeholder="jordan@company.com" required />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="subject">Subject</Label>
                <Input id="subject" placeholder="Brief summary of the issue" required />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Category</Label>
                  <Select required>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Pick a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((c) => (
                        <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Priority</Label>
                  <RadioGroup defaultValue="medium" className="grid grid-cols-3 gap-2 pt-1.5">
                    {[
                      { value: "low", label: "Low", tone: "success" as const },
                      { value: "medium", label: "Medium", tone: "warning" as const },
                      { value: "high", label: "High", tone: "danger" as const },
                    ].map((p) => (
                      <label
                        key={p.value}
                        htmlFor={`p-${p.value}`}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-md border border-border cursor-pointer hover:bg-muted/40 transition-colors has-[:checked]:border-primary has-[:checked]:bg-primary/5"
                      >
                        <RadioGroupItem value={p.value} id={`p-${p.value}`} className="h-3.5 w-3.5" />
                        <span className="text-xs font-medium">{p.label}</span>
                        <span className={cn("ml-auto h-1.5 w-1.5 rounded-full", p.tone === "success" ? "bg-[color:var(--success)]" : p.tone === "warning" ? "bg-[color:var(--warning)]" : "bg-destructive")} />
                      </label>
                    ))}
                  </RadioGroup>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Describe the issue, what you expected, and what actually happened. Include URLs, error messages, and timestamps where possible."
                  className="min-h-[140px] resize-y"
                  required
                />
                <p className="text-[11px] text-muted-foreground">Be specific — the more context you provide, the faster we can help.</p>
              </div>

              {/* Attachments */}
              <div className="space-y-1.5">
                <Label>Attachments <span className="text-muted-foreground font-normal">(optional, up to 5)</span></Label>
                <label className="flex flex-col items-center justify-center gap-1.5 px-4 py-6 rounded-lg border border-dashed border-border bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer">
                  <Paperclip className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Click to upload screenshots or logs</span>
                  <span className="text-[10px] text-muted-foreground/70">PNG, JPG, PDF, TXT up to 10MB</span>
                  <input type="file" multiple accept=".png,.jpg,.jpeg,.pdf,.txt,.log" className="hidden" onChange={onPickFile} />
                </label>
                {files.length > 0 && (
                  <ul className="space-y-1.5 mt-2">
                    {files.map((f) => (
                      <li key={f} className="flex items-center gap-2 px-2.5 py-1.5 rounded-md bg-muted/60 text-xs">
                        <Paperclip className="h-3 w-3 text-muted-foreground shrink-0" />
                        <span className="flex-1 truncate">{f}</span>
                        <button type="button" onClick={() => removeFile(f)} className="text-muted-foreground hover:text-destructive">
                          <X className="h-3 w-3" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button type="button" variant="outline">Cancel</Button>
                <Button type="submit" disabled={submitting} className="gap-1.5">
                  {submitting ? (
                    <>
                      <span className="h-3.5 w-3.5 rounded-full border-2 border-primary-foreground/40 border-t-primary-foreground animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="h-3.5 w-3.5" /> Submit ticket
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* CONTACT INFO + CHANNELS */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Contact information</CardTitle>
              <CardDescription>Reach us directly.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3.5">
              <div className="flex items-start gap-3">
                <div className="grid place-items-center h-8 w-8 rounded-lg bg-primary/10 text-primary shrink-0">
                  <Mail className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">Email</p>
                  <a href="mailto:support@nexusgrid.io" className="text-sm font-medium hover:text-primary transition-colors">support@nexusgrid.io</a>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="grid place-items-center h-8 w-8 rounded-lg bg-[color:var(--success)]/12 text-[color:var(--success)] shrink-0">
                  <Phone className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">Phone (Enterprise only)</p>
                  <p className="text-sm font-medium tabular-nums">+1 (415) 555-0142</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="grid place-items-center h-8 w-8 rounded-lg bg-violet-500/12 text-violet-500 shrink-0">
                  <Clock className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">Hours</p>
                  <p className="text-sm font-medium">Mon-Fri, 9 AM - 6 PM EST</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="grid place-items-center h-8 w-8 rounded-lg bg-[color:var(--warning)]/15 text-[color:var(--warning)] shrink-0">
                  <Activity className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">Avg. response time</p>
                  <p className="text-sm font-medium">~4 hours (business hours)</p>
                </div>
              </div>
              <Separator />
              <div className="rounded-lg bg-[color:var(--success)]/[0.06] border border-[color:var(--success)]/20 p-3 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)] animate-pulse" />
                <span className="text-xs font-medium text-[color:var(--success)]">All systems operational</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Other channels</CardTitle>
              <CardDescription>Pick what works best for you.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                { icon: MessageSquare, title: "Live chat", desc: "Mon-Fri, 9 AM - 6 PM EST", tone: "primary" as const },
                { icon: Users, title: "Community forum", desc: "12,000+ members helping each other", tone: "violet" as const },
                { icon: Activity, title: "Status page", desc: "Real-time uptime and incidents", tone: "success" as const },
              ].map((c) => (
                <button key={c.title} className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/60 transition-colors text-left group">
                  <div className={cn(
                    "grid place-items-center h-9 w-9 rounded-lg shrink-0",
                    c.tone === "primary" ? "bg-primary/12 text-primary" :
                    c.tone === "violet" ? "bg-violet-500/12 text-violet-500" :
                    "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                  )}>
                    <c.icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{c.title}</p>
                    <p className="text-[11px] text-muted-foreground line-clamp-1">{c.desc}</p>
                  </div>
                  <ArrowUpRight className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* RECENT TICKETS */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base">Your recent tickets</CardTitle>
            <CardDescription>Track the status of your support requests.</CardDescription>
          </div>
          <Button variant="outline" size="sm" className="gap-1.5">
            <Search className="h-3.5 w-3.5" /> Find a ticket
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-y border-border bg-muted/40">
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">ID</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Subject</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Category</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Priority</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Updated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {RECENT_TICKETS.map((t) => (
                  <tr key={t.id} className="hover:bg-muted/30 transition-colors cursor-pointer">
                    <td className="px-4 py-3 font-mono text-xs">{t.id}</td>
                    <td className="px-4 py-3 font-medium">{t.subject}</td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <Badge variant="outline" className="text-[10px]">{t.category}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge
                        tone={t.status === "open" ? "info" : t.status === "in_progress" ? "warning" : "success"}
                        dot
                      >
                        {t.status === "in_progress" ? "In progress" : t.status.charAt(0).toUpperCase() + t.status.slice(1)}
                      </StatusBadge>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className={cn(
                        "text-xs font-medium capitalize",
                        t.priority === "high" ? "text-destructive" : t.priority === "medium" ? "text-[color:var(--warning)]" : "text-[color:var(--success)]"
                      )}>
                        {t.priority}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground hidden lg:table-cell">{t.updated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
