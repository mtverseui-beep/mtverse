"use client";

import * as React from "react";
import {
  Users,
  UserPlus,
  UserCheck,
  Crown,
  MoreHorizontal,
  Mail,
  MapPin,
  ShoppingBag,
  Download,
  Plus,
  Search,
  Eye,
  TrendingUp,
  Star,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DonutChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Segment = "VIP" | "Repeat" | "New" | "At-Risk" | "Churned";

type Customer = {
  id: string;
  name: string;
  email: string;
  avatar: string;
  location: string;
  orders: number;
  totalSpent: number;
  lastOrder: string;
  segment: Segment;
};

const customers: Customer[] = [
  { id: "C-1001", name: "Sarah Chen", email: "sarah.chen@example.com", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop", location: "San Francisco, US", orders: 48, totalSpent: 4820.50, lastOrder: "2026-07-01", segment: "VIP" },
  { id: "C-1002", name: "Marcus Reyes", email: "marcus.r@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop", location: "Austin, US", orders: 32, totalSpent: 2184.00, lastOrder: "2026-07-01", segment: "Repeat" },
  { id: "C-1003", name: "Elena Petrov", email: "elena.petrov@example.com", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop", location: "Berlin, DE", orders: 64, totalSpent: 8420.75, lastOrder: "2026-06-30", segment: "VIP" },
  { id: "C-1004", name: "James Okoro", email: "j.okoro@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop", location: "Lagos, NG", orders: 4, totalSpent: 286.99, lastOrder: "2026-06-28", segment: "New" },
  { id: "C-1005", name: "Aiko Tanaka", email: "aiko.t@example.com", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=80&h=80&fit=crop", location: "Tokyo, JP", orders: 28, totalSpent: 3120.00, lastOrder: "2026-06-30", segment: "Repeat" },
  { id: "C-1006", name: "David Kim", email: "d.kim@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop", location: "Seoul, KR", orders: 42, totalSpent: 5280.75, lastOrder: "2026-06-29", segment: "VIP" },
  { id: "C-1007", name: "Lena Hoffmann", email: "lena.h@example.com", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&h=80&fit=crop", location: "Munich, DE", orders: 2, totalSpent: 144.50, lastOrder: "2026-05-12", segment: "At-Risk" },
  { id: "C-1008", name: "Raj Patel", email: "raj.patel@example.com", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=80&h=80&fit=crop", location: "Mumbai, IN", orders: 18, totalSpent: 1848.00, lastOrder: "2026-06-29", segment: "Repeat" },
  { id: "C-1009", name: "Mei Lin", email: "mei.lin@example.com", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&h=80&fit=crop", location: "Shanghai, CN", orders: 6, totalSpent: 587.40, lastOrder: "2026-06-28", segment: "New" },
  { id: "C-1010", name: "Carlos Mendez", email: "c.mendez@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop", location: "Mexico City, MX", orders: 1, totalSpent: 178.20, lastOrder: "2026-06-20", segment: "At-Risk" },
  { id: "C-1011", name: "Priya Sharma", email: "priya.s@example.com", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=80&h=80&fit=crop", location: "Delhi, IN", orders: 56, totalSpent: 9840.00, lastOrder: "2026-06-27", segment: "VIP" },
  { id: "C-1012", name: "Noah Williams", email: "noah.w@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop", location: "London, UK", orders: 0, totalSpent: 0, lastOrder: "—", segment: "Churned" },
  { id: "C-1013", name: "Sofia Rossi", email: "sofia.rossi@example.com", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=80&h=80&fit=crop", location: "Milan, IT", orders: 22, totalSpent: 2612.30, lastOrder: "2026-06-26", segment: "Repeat" },
  { id: "C-1014", name: "Ahmed Hassan", email: "ahmed.h@example.com", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=80&h=80&fit=crop", location: "Cairo, EG", orders: 3, totalSpent: 245.00, lastOrder: "2026-06-26", segment: "New" },
  { id: "C-1015", name: "Yuki Sato", email: "yuki.sato@example.com", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=80&h=80&fit=crop", location: "Osaka, JP", orders: 38, totalSpent: 4398.75, lastOrder: "2026-06-25", segment: "VIP" },
  { id: "C-1016", name: "Olivia Bennett", email: "olivia.b@example.com", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&h=80&fit=crop", location: "Sydney, AU", orders: 14, totalSpent: 1824.50, lastOrder: "2026-06-25", segment: "Repeat" },
  { id: "C-1017", name: "Lucas Moreau", email: "lucas.m@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop", location: "Paris, FR", orders: 1, totalSpent: 119.00, lastOrder: "2026-04-18", segment: "Churned" },
  { id: "C-1018", name: "Isabella Costa", email: "i.costa@example.com", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&h=80&fit=crop", location: "São Paulo, BR", orders: 46, totalSpent: 6428.00, lastOrder: "2026-06-24", segment: "VIP" },
];

const segmentToneMap: Record<Segment, "primary" | "info" | "success" | "warning" | "danger"> = {
  VIP: "primary",
  Repeat: "info",
  New: "success",
  "At-Risk": "warning",
  Churned: "danger",
};

const segmentsData = [
  { name: "VIP Customers", value: 1840, color: "var(--primary)" },
  { name: "Repeat Buyers", value: 8420, color: "oklch(0.58 0.13 250)" },
  { name: "New Customers", value: 12680, color: "var(--success)" },
  { name: "At-Risk", value: 3210, color: "var(--warning)" },
  { name: "Churned", value: 1840, color: "var(--destructive)" },
];

// People-centric KPI card — distinct from KpiCard: big avatar-stack decoration
function CustomerKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  avatars,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  trend: string;
  avatars: string[];
}) {
  const accentIcon = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentIcon[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* avatar stack decoration */}
        <div className="flex items-center gap-1.5">
          <div className="flex -space-x-2">
            {avatars.map((a, i) => (
              <Avatar key={i} className="h-6 w-6 border-2 border-card">
                <AvatarImage src={a} alt="" />
                <AvatarFallback className="text-[9px] bg-muted">?</AvatarFallback>
              </Avatar>
            ))}
          </div>
          <span className="text-xs text-muted-foreground">{hint}</span>
        </div>
        <div className="flex items-center gap-1 mt-2.5 text-xs">
          <span className={cn(
            "inline-flex items-center gap-0.5 font-medium",
            accent === "warning" ? "text-[color:var(--warning)]" : "text-[color:var(--success)]"
          )}>
            <TrendingUp className="h-3 w-3" /> {trend}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function CustomersPage() {
  const [search, setSearch] = React.useState("");
  const [segment, setSegment] = React.useState<string>("all");
  const [page, setPage] = React.useState(0);
  const pageSize = 8;

  const filtered = React.useMemo(() => {
    return customers.filter((c) => {
      const matchesSearch =
        !search ||
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.email.toLowerCase().includes(search.toLowerCase()) ||
        c.location.toLowerCase().includes(search.toLowerCase());
      const matchesSegment = segment === "all" || c.segment === segment;
      return matchesSearch && matchesSegment;
    });
  }, [search, segment]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages - 1);
  const paginated = filtered.slice(currentPage * pageSize, (currentPage + 1) * pageSize);

  React.useEffect(() => { setPage(0); }, [search, segment]);

  return (
    <>
      <PageHeader
        title="Customers"
        description="Understand your customer base, segment by lifecycle stage, and identify opportunities."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Customers" }]}
        icon={Users}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Customer list exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add customer form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Customer
            </Button>
          </>
        }
      />

      {/* Customer KPI cards — people-centric with avatar stacks */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <CustomerKpi
          label="Total Customers"
          value="27,990"
          hint="across 42 countries"
          icon={Users}
          accent="primary"
          trend="+4.6% this month"
          avatars={[
            "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop",
          ]}
        />
        <CustomerKpi
          label="New This Month"
          value="1,284"
          hint="joined in June"
          icon={UserPlus}
          accent="success"
          trend="+18.2% vs May"
          avatars={[
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop",
          ]}
        />
        <CustomerKpi
          label="Active"
          value="22,140"
          hint="ordered in last 90 days"
          icon={UserCheck}
          accent="info"
          trend="+2.8% engagement"
          avatars={[
            "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop",
          ]}
        />
        <CustomerKpi
          label="VIP"
          value="1,840"
          hint="6.6% of base · $4.2M LTV"
          icon={Crown}
          accent="warning"
          trend="+12 VIP upgrades"
          avatars={[
            "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop",
            "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=40&h=40&fit=crop",
          ]}
        />
      </div>

      {/* Segments donut + top spenders */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Customer Segments</CardTitle>
            <CardDescription>Distribution by lifecycle stage.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={segmentsData}
              centerLabel="Customers"
              centerValue="27,990"
              height={220}
            />
            <div className="mt-3 space-y-1.5">
              {segmentsData.map((s) => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                    <span className="text-muted-foreground">{s.name}</span>
                  </div>
                  <span className="font-medium tabular-nums">{s.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Crown className="h-4 w-4 text-[color:var(--warning)]" />
                Top Spenders
              </CardTitle>
              <CardDescription>Highest lifetime value customers.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.message("Opening VIP program")}>
              View VIP <Eye className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {customers
                .filter((c) => c.segment === "VIP")
                .sort((a, b) => b.totalSpent - a.totalSpent)
                .slice(0, 5)
                .map((c, idx) => (
                  <div
                    key={c.id}
                    className="flex items-center gap-3 p-3 hover:bg-muted/40 transition-colors cursor-pointer"
                    onClick={() => toast.message(`Opening customer profile for ${c.name}`)}
                  >
                    <div className={cn(
                      "grid place-items-center h-7 w-7 rounded-full text-xs font-semibold shrink-0",
                      idx === 0 ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" : "bg-muted text-muted-foreground"
                    )}>
                      {idx === 0 ? <Crown className="h-3.5 w-3.5" /> : idx + 1}
                    </div>
                    <Avatar className="h-9 w-9 shrink-0">
                      <AvatarImage src={c.avatar} alt={c.name} />
                      <AvatarFallback className="text-xs">{c.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{c.name}</p>
                      <p className="text-xs text-muted-foreground truncate flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {c.location}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-semibold tabular-nums">${c.totalSpent.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                      <p className="text-[10px] text-muted-foreground">{c.orders} orders</p>
                    </div>
                    <StatusBadge tone="primary" className="hidden sm:inline-flex">VIP</StatusBadge>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customer table (custom) */}
      <Card>
        <CardContent className="p-0">
          {/* Toolbar */}
          <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center p-3 sm:p-4 border-b border-border bg-muted/30">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, email, or location..."
                className="h-9 pl-8 text-sm"
              />
            </div>
            <div className="flex-1" />
            <Select value={segment} onValueChange={setSegment}>
              <SelectTrigger className="h-9 w-[160px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All segments</SelectItem>
                <SelectItem value="VIP">VIP</SelectItem>
                <SelectItem value="Repeat">Repeat</SelectItem>
                <SelectItem value="New">New</SelectItem>
                <SelectItem value="At-Risk">At-Risk</SelectItem>
                <SelectItem value="Churned">Churned</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Customer</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Location</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Orders</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Total Spent</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Last Order</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Segment</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-12">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {paginated.map((c) => (
                  <tr
                    key={c.id}
                    className="hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => toast.message(`Opening customer profile for ${c.name}`)}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <Avatar className="h-9 w-9 shrink-0">
                          <AvatarImage src={c.avatar} alt={c.name} />
                          <AvatarFallback className="text-xs">{c.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="font-medium text-foreground text-sm truncate flex items-center gap-1.5">
                            {c.name}
                            {c.segment === "VIP" && <Crown className="h-3 w-3 text-[color:var(--warning)]" />}
                          </p>
                          <p className="text-xs text-muted-foreground truncate flex items-center gap-1">
                            <Mail className="h-3 w-3" /> {c.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {c.location}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">
                      <span className="inline-flex items-center gap-1 text-xs">
                        <ShoppingBag className="h-3 w-3 text-muted-foreground" /> {c.orders}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-medium">${c.totalSpent.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground font-mono hidden sm:table-cell">{c.lastOrder}</td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={segmentToneMap[c.segment]} dot>{c.segment}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-44">
                          <DropdownMenuLabel className="text-xs">{c.name}</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening customer profile for ${c.name}`)}>
                            <Eye className="h-3.5 w-3.5" /> View profile
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Email composed to ${c.email}`)}>
                            <Mail className="h-3.5 w-3.5" /> Send email
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Promoted ${c.name} to next tier`)}>
                            <Star className="h-3.5 w-3.5" /> Promote tier
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
                {paginated.length === 0 && (
                  <tr>
                    <td colSpan={7} className="text-center text-sm text-muted-foreground py-12">
                      No customers match your filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between p-3 border-t border-border bg-muted/30">
            <span className="text-xs text-muted-foreground">
              Showing <span className="font-medium text-foreground">{filtered.length === 0 ? 0 : currentPage * pageSize + 1}–{Math.min((currentPage + 1) * pageSize, filtered.length)}</span> of{" "}
              <span className="font-medium text-foreground">{filtered.length}</span>
            </span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={currentPage === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>
                Previous
              </Button>
              <span className="text-xs text-muted-foreground px-2">Page {currentPage + 1} of {totalPages}</span>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={currentPage >= totalPages - 1} onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}>
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
