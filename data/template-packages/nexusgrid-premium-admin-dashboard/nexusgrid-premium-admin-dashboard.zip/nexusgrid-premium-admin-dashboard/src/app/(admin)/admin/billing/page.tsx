"use client";

import * as React from "react";
import {
  CreditCard,
  Receipt,
  Download,
  Crown,
  Users,
  HardDrive,
  Activity,
  Zap,
  TrendingUp,
  ArrowUpRight,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DataTable, type Column } from "@/components/tables/data-table";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Invoice = {
  id: string;
  number: string;
  date: string;
  amount: number;
  status: "paid" | "pending" | "failed";
  method: string;
};

const INVOICES: Invoice[] = [
  { id: "i1", number: "INV-2026-0714", date: "Jul 14, 2026", amount: 249.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i2", number: "INV-2026-0614", date: "Jun 14, 2026", amount: 249.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i3", number: "INV-2026-0514", date: "May 14, 2026", amount: 249.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i4", number: "INV-2026-0414", date: "Apr 14, 2026", amount: 249.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i5", number: "INV-2026-0314", date: "Mar 14, 2026", amount: 249.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i6", number: "INV-2026-0214", date: "Feb 14, 2026", amount: 199.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i7", number: "INV-2026-0114", date: "Jan 14, 2026", amount: 199.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i8", number: "INV-2025-1214", date: "Dec 14, 2025", amount: 199.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i9", number: "INV-2025-1114", date: "Nov 14, 2025", amount: 199.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i10", number: "INV-2025-1014", date: "Oct 14, 2025", amount: 99.00, status: "paid", method: "Visa •••• 4242" },
  { id: "i11", number: "INV-2025-0914", date: "Sep 14, 2025", amount: 99.00, status: "failed", method: "Visa •••• 8888" },
  { id: "i12", number: "INV-2025-0814", date: "Aug 14, 2025", amount: 99.00, status: "paid", method: "Visa •••• 8888" },
];

const USAGE_BARS = [
  { icon: Users, label: "Team seats", current: 14, limit: 20, unit: "", tone: "primary" },
  { icon: HardDrive, label: "Storage", current: 84, limit: 250, unit: " GB", tone: "info" },
  { icon: Activity, label: "API calls", current: 428, limit: 1000, unit: "K", tone: "success" },
  { icon: Zap, label: "Webhook deliveries", current: 184, limit: 500, unit: "K", tone: "warning" },
];

const toneBar: Record<string, string> = {
  primary: "bg-primary",
  info: "bg-[color:var(--info)]",
  success: "bg-[color:var(--success)]",
  warning: "bg-[color:var(--warning)]",
};

const toneTile: Record<string, string> = {
  primary: "bg-primary/12 text-primary",
  info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
  success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
};

export default function BillingPage() {
  const totalPaid = INVOICES.filter((i) => i.status === "paid").reduce((acc, i) => acc + i.amount, 0);
  const pending = INVOICES.filter((i) => i.status === "pending").reduce((acc, i) => acc + i.amount, 0);
  const failed = INVOICES.filter((i) => i.status === "failed").reduce((acc, i) => acc + i.amount, 0);

  const columns: Column<Invoice>[] = [
    {
      key: "number",
      header: "Invoice",
      sortable: true,
      sortAccessor: (r) => r.number,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <div className="grid place-items-center h-8 w-8 rounded-md bg-muted text-muted-foreground shrink-0">
            <Receipt className="h-4 w-4" />
          </div>
          <span className="font-mono text-sm font-medium">{r.number}</span>
        </div>
      ),
    },
    {
      key: "date",
      header: "Date",
      sortable: true,
      sortAccessor: (r) => r.date,
      cell: (r) => <span className="text-sm text-muted-foreground">{r.date}</span>,
    },
    {
      key: "method",
      header: "Payment method",
      cell: (r) => <span className="text-xs text-muted-foreground font-mono">{r.method}</span>,
    },
    {
      key: "amount",
      header: "Amount",
      align: "right",
      sortable: true,
      sortAccessor: (r) => r.amount,
      cell: (r) => <span className="font-mono font-medium tabular-nums">${r.amount.toFixed(2)}</span>,
    },
    {
      key: "status",
      header: "Status",
      align: "center",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Paid", value: "paid" },
        { label: "Pending", value: "pending" },
        { label: "Failed", value: "failed" },
      ],
      cell: (r) => (
        <StatusBadge tone={r.status === "paid" ? "success" : r.status === "pending" ? "warning" : "danger"} dot>
          {r.status}
        </StatusBadge>
      ),
    },
    {
      key: "actions",
      header: "",
      align: "right",
      hideable: false,
      cell: (r) => (
        <Button variant="ghost" size="sm" className="text-xs gap-1.5 h-7" onClick={() => toast.success(`Downloading ${r.number}`, { description: "PDF invoice saved to your device." })}>
          <Download className="h-3 w-3" /> PDF
        </Button>
      ),
    },
  ];

  return (
    <>
      <PageHeader
        title="Billing"
        description="Your subscription, usage, payment method, and full invoice history — all in one place."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Billing" }]}
        icon={CreditCard}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening plan picker", { description: "Compare plans and upgrade." })}>
            <Sparkles className="h-3.5 w-3.5" /> Upgrade plan
          </Button>
        }
      />

      {/* TOP ROW — PLAN + PAYMENT */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* CURRENT PLAN */}
        <Card className="lg:col-span-2 relative overflow-hidden">
          <div className="absolute top-0 right-0 h-32 w-32 bg-primary/10 rounded-full blur-3xl -mr-8 -mt-8" aria-hidden />
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="text-[10px] gap-1 border-primary/30 text-primary bg-primary/5">
                    <Crown className="h-2.5 w-2.5" /> Current plan
                  </Badge>
                </div>
                <CardTitle className="text-2xl">Pro</CardTitle>
                <CardDescription className="text-sm mt-1">For growing teams that need power and scale.</CardDescription>
              </div>
              <div className="text-right shrink-0">
                <p className="text-3xl font-semibold tabular-nums">$249<span className="text-base text-muted-foreground">/mo</span></p>
                <p className="text-xs text-muted-foreground mt-0.5">Billed monthly</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border border-border p-3">
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground flex items-center gap-1"><Calendar className="h-2.5 w-2.5" /> Next billing date</p>
                <p className="text-sm font-medium mt-1">Aug 14, 2026</p>
                <p className="text-[11px] text-muted-foreground">in 31 days</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground flex items-center gap-1"><TrendingUp className="h-2.5 w-2.5" /> Lifetime spend</p>
                <p className="text-sm font-medium mt-1 tabular-nums">${totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
                <p className="text-[11px] text-muted-foreground">across {INVOICES.length} invoices</p>
              </div>
            </div>

            {/* Features included */}
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Included in Pro</p>
              <div className="grid sm:grid-cols-2 gap-1.5">
                {[
                  "Up to 20 team members",
                  "250 GB file storage",
                  "1M API calls / month",
                  "500K webhook deliveries",
                  "Audit logs (90 days)",
                  "Advanced role permissions",
                  "SSO & SAML",
                  "Priority support · 4h SLA",
                ].map((f) => (
                  <div key={f} className="flex items-center gap-2 text-xs">
                    <CheckCircle2 className="h-3 w-3 text-[color:var(--success)] shrink-0" />
                    <span className="text-foreground">{f}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <Button variant="outline" size="sm" className="gap-1.5" asChild>
                <a href="/admin/subscription">
                  <ArrowUpRight className="h-3.5 w-3.5" /> Compare plans
                </a>
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.message("Managing subscription")}>
                Manage subscription
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* PAYMENT METHOD */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Payment method</CardTitle>
            <CardDescription>Charged on each renewal date.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-lg border border-border bg-muted/30">
              <div className="grid place-items-center h-10 w-14 rounded-md bg-foreground text-background text-[10px] font-bold tracking-wide">
                VISA
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium font-mono">•••• •••• •••• 4242</p>
                <p className="text-xs text-muted-foreground">Expires 08/27 · Amara Okafor</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Auto-renew</span>
                <StatusBadge tone="success" dot>Enabled</StatusBadge>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Billing email</span>
                <span className="font-mono">billing@nexusgrid.io</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Tax ID</span>
                <span className="font-mono">84-2910037</span>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full text-xs gap-1.5" onClick={() => toast.message("Opening payment editor")}>
              <CreditCard className="h-3.5 w-3.5" /> Update payment method
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* USAGE METERS */}
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" /> Usage this cycle
          </CardTitle>
          <CardDescription>Resets on Aug 14, 2026. Usage overages are billed at the rates in your plan.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {USAGE_BARS.map((u) => {
              const pct = Math.min(100, Math.round((u.current / u.limit) * 100));
              const isWarning = pct >= 80;
              return (
                <div key={u.label} className="rounded-lg border border-border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className={cn("grid place-items-center h-8 w-8 rounded-md", toneTile[u.tone])}>
                      <u.icon className="h-4 w-4" />
                    </div>
                    {isWarning ? (
                      <Badge variant="outline" className="text-[9px] gap-1 border-[color:var(--warning)]/40 text-[color:var(--warning)] bg-[color:var(--warning)]/5">
                        <AlertTriangle className="h-2.5 w-2.5" /> Near limit
                      </Badge>
                    ) : (
                      <span className="text-[10px] text-muted-foreground">{pct}%</span>
                    )}
                  </div>
                  <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{u.label}</p>
                  <p className="text-lg font-semibold tabular-nums mt-0.5">
                    {u.current}{u.unit} <span className="text-xs text-muted-foreground font-normal">/ {u.limit}{u.unit}</span>
                  </p>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden mt-2">
                    <div
                      className={cn("h-full rounded-full transition-all", isWarning ? "bg-[color:var(--warning)]" : toneBar[u.tone])}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        {[
          { icon: CheckCircle2, tone: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Total paid", value: `$${totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, hint: `${INVOICES.filter((i) => i.status === "paid").length} invoices` },
          { icon: Calendar, tone: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]", label: "Pending", value: `$${pending.toFixed(2)}`, hint: `${INVOICES.filter((i) => i.status === "pending").length} invoice${INVOICES.filter((i) => i.status === "pending").length === 1 ? "" : "s"}` },
          { icon: AlertTriangle, tone: "bg-destructive/12 text-destructive", label: "Failed", value: `$${failed.toFixed(2)}`, hint: `${INVOICES.filter((i) => i.status === "failed").length} invoice${INVOICES.filter((i) => i.status === "failed").length === 1 ? "" : "s"}` },
        ].map((s) => (
          <Card key={s.label} className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("grid place-items-center h-7 w-7 rounded-md", s.tone)}><s.icon className="h-3.5 w-3.5" /></div>
              <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</span>
            </div>
            <p className="text-xl font-semibold tabular-nums leading-tight">{s.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.hint}</p>
          </Card>
        ))}
      </div>

      {/* BILLING HISTORY */}
      <Card>
        <CardContent className="p-0">
          <DataTable
            data={INVOICES}
            columns={columns}
            pageSize={8}
            searchable
            searchKeys={["number", "method", "date"]}
            title="Billing history"
            getRowId={(r) => r.id}
            enableExport
            initialSort={{ key: "date", direction: "desc" }}
          />
        </CardContent>
      </Card>
    </>
  );
}
