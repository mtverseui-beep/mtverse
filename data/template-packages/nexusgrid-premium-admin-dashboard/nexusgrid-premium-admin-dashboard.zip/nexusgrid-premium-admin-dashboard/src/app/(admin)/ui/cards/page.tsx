"use client";

import * as React from "react";
import {
  LayoutPanelTop,
  MoreHorizontal,
  TrendingUp,
  TrendingDown,
  Users,
  DollarSign,
  ShoppingCart,
  Activity,
  Star,
  Heart,
  Share2,
  Eye,
  MapPin,
  Clock,
  ArrowRight,
  Sparkles,
  Package,
  CheckCircle2,
  GitCommit,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle, CardAction } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/common/status-badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function CardsPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Cards"
        description="Container primitives — variants for default, outlined, elevated, gradient and interactive use."
        icon={LayoutPanelTop}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/cards" },
          { label: "Cards" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Card presets exported")}>
            <Share2 /> Export presets
          </Button>
        }
      />

      {/* Card variants */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Card variants</CardTitle>
          <CardDescription>
            Five styling variants for different visual weight and emphasis.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {/* Default */}
          <Card className="py-4">
            <CardHeader className="pb-2">
              <CardDescription>Default</CardDescription>
              <CardTitle className="text-base">Standard card</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              The most common container. Uses the card background and a subtle shadow.
            </CardContent>
          </Card>

          {/* Outlined */}
          <Card className="py-4 border-2 shadow-none">
            <CardHeader className="pb-2">
              <CardDescription>Outlined</CardDescription>
              <CardTitle className="text-base">Bordered card</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              A flat card with a stronger border and no shadow. Useful in dense layouts.
            </CardContent>
          </Card>

          {/* Elevated */}
          <Card className="py-4 shadow-lg shadow-foreground/5">
            <CardHeader className="pb-2">
              <CardDescription>Elevated</CardDescription>
              <CardTitle className="text-base">Lifted card</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              Stronger shadow for floating panels, popovers and step content.
            </CardContent>
          </Card>

          {/* Gradient */}
          <Card className="py-4 border-primary/20 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
            <CardHeader className="pb-2">
              <CardDescription>Gradient</CardDescription>
              <CardTitle className="text-base">Featured card</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              Tinted background with a subtle gradient. Draws attention to featured content.
            </CardContent>
          </Card>

          {/* Interactive */}
          <Card
            className="py-4 transition-all hover:shadow-lg hover:-translate-y-0.5 hover:border-primary/40 cursor-pointer group"
            onClick={() => toast.message("Card clicked")}
          >
            <CardHeader className="pb-2">
              <CardDescription>Interactive</CardDescription>
              <CardTitle className="text-base flex items-center justify-between">
                Hover me
                <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              Hover lifts the card and reveals an arrow. Use for clickable list items.
            </CardContent>
          </Card>

          {/* Muted */}
          <Card className="py-4 bg-muted/40 border-muted">
            <CardHeader className="pb-2">
              <CardDescription>Muted</CardDescription>
              <CardTitle className="text-base">Secondary card</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              Lower-contrast surface for footers, summaries or aside content.
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      {/* Card anatomy */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Anatomy</CardTitle>
          <CardDescription>
            Header, content, footer, image, title, description and action slot — all composable.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          {/* With header + footer */}
          <Card className="py-0 overflow-hidden">
            <CardHeader className="border-b">
              <CardTitle className="text-base">Subscription summary</CardTitle>
              <CardDescription>Renewal cycle ending July 31, 2026</CardDescription>
              <CardAction>
                <Button variant="ghost" size="icon" aria-label="More">
                  <MoreHorizontal />
                </Button>
              </CardAction>
            </CardHeader>
            <CardContent className="py-4 text-sm text-muted-foreground">
              You are on the <span className="font-medium text-foreground">Pro</span> plan with 18 of 25 seats used.
              Your next invoice of $648.00 will be charged automatically.
            </CardContent>
            <CardFooter className="border-t justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => toast.message("Invoice preview opened")}>
                View invoice
              </Button>
              <Button size="sm" onClick={() => toast.success("Renewal scheduled")}>
                Renew now
              </Button>
            </CardFooter>
          </Card>

          {/* With image */}
          <Card className="py-0 overflow-hidden">
            <div className="aspect-[16/9] bg-gradient-to-br from-primary/30 via-primary/10 to-violet-500/20 grid place-items-center">
              <Sparkles className="h-10 w-10 text-primary" />
            </div>
            <CardHeader>
              <CardTitle className="text-base">Welcome to NexusGrid</CardTitle>
              <CardDescription>Everything you need to launch your dashboard in minutes.</CardDescription>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              Pre-built layouts, theming tokens and reusable components ship in every starter template.
            </CardContent>
            <CardFooter className="gap-2">
              <Button size="sm" className="w-full" onClick={() => toast.success("Tour started")}>
                Start the tour
              </Button>
            </CardFooter>
          </Card>
        </CardContent>
      </Card>

      {/* Stat cards */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Stat cards</CardTitle>
          <CardDescription>
            Compact metric cards with trend indicators and sparkline-ready footers.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              label: "Total revenue",
              value: "$284,392",
              delta: "+12.4%",
              trend: "up" as const,
              icon: DollarSign,
              tone: "primary",
            },
            {
              label: "Active users",
              value: "84,392",
              delta: "+8.2%",
              trend: "up" as const,
              icon: Users,
              tone: "info",
            },
            {
              label: "Orders placed",
              value: "2,184",
              delta: "-3.1%",
              trend: "down" as const,
              icon: ShoppingCart,
              tone: "warning",
            },
            {
              label: "Conversion rate",
              value: "4.2%",
              delta: "+0.6pp",
              trend: "up" as const,
              icon: Activity,
              tone: "success",
            },
          ].map((s) => (
            <Card key={s.label} className="py-4">
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div
                    className={cn(
                      "grid h-9 w-9 place-items-center rounded-lg",
                      s.tone === "primary" && "bg-primary/15 text-primary",
                      s.tone === "info" && "bg-[color:var(--info)]/15 text-[color:var(--info)]",
                      s.tone === "warning" && "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
                      s.tone === "success" && "bg-[color:var(--success)]/15 text-[color:var(--success)]"
                    )}
                  >
                    <s.icon className="h-4 w-4" />
                  </div>
                  <span
                    className={cn(
                      "inline-flex items-center gap-1 text-xs font-medium",
                      s.trend === "up" ? "text-[color:var(--success)]" : "text-destructive"
                    )}
                  >
                    {s.trend === "up" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {s.delta}
                  </span>
                </div>
                <div>
                  <p className="text-2xl font-semibold tabular-nums">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
                <p className="text-[11px] text-muted-foreground">vs previous 30 days</p>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      {/* Profile + Product cards */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Profile & product cards</CardTitle>
          <CardDescription>
            Composed examples for common dashboard surfaces.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {/* Profile card */}
          <Card className="py-0 overflow-hidden">
            <div className="h-20 bg-gradient-to-r from-primary/30 via-violet-500/20 to-amber-500/20" />
            <CardContent className="-mt-8 pb-4 space-y-3">
              <Avatar className="h-16 w-16 ring-4 ring-card">
                <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&h=128&fit=crop" alt="Amara Reyes" />
                <AvatarFallback>AR</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-semibold">Amara Reyes</p>
                  <StatusBadge tone="success" dot>Online</StatusBadge>
                </div>
                <p className="text-sm text-muted-foreground">Senior Product Designer · Berlin</p>
              </div>
              <div className="flex gap-4 text-xs text-muted-foreground">
                <span><strong className="text-foreground">142</strong> projects</span>
                <span><strong className="text-foreground">2.8k</strong> commits</span>
                <span><strong className="text-foreground">38</strong> reviews</span>
              </div>
              <div className="flex gap-2">
                <Button size="sm" className="flex-1" onClick={() => toast.success("Message sent to Amara")}>
                  Message
                </Button>
                <Button size="sm" variant="outline" onClick={() => toast.message("Following Amara")}>
                  Follow
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Product card */}
          <Card className="py-0 overflow-hidden group transition-all hover:shadow-lg hover:-translate-y-0.5 cursor-pointer">
            <div className="aspect-square bg-gradient-to-br from-amber-500/20 via-rose-500/15 to-violet-500/20 grid place-items-center">
              <Package className="h-12 w-12 text-muted-foreground" />
            </div>
            <CardContent className="py-4 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">Aurora wireless headset</p>
                  <p className="text-xs text-muted-foreground">SKU NEX-AUR-001 · 28 in stock</p>
                </div>
                <Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent">
                  Active
                </Badge>
              </div>
              <div className="flex items-center gap-1 text-amber-500">
                {[0, 1, 2, 3].map((i) => (
                  <Star key={i} className="h-3.5 w-3.5 fill-current" />
                ))}
                <Star className="h-3.5 w-3.5" />
                <span className="ml-1 text-xs text-muted-foreground">4.2 · 218 reviews</span>
              </div>
              <div className="flex items-end justify-between pt-1">
                <div>
                  <p className="text-2xl font-semibold tabular-nums">$284</p>
                  <p className="text-xs text-muted-foreground line-through">$329</p>
                </div>
                <Button size="sm" onClick={() => toast.success("Added to cart")}>
                  Add to cart
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Activity card */}
          <Card className="py-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Recent activity</CardTitle>
              <CardDescription>Latest events in your workspace</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                {
                  icon: GitCommit,
                  actor: "Devon Park",
                  text: "merged PR #1284 into main",
                  time: "12 min ago",
                  tone: "primary",
                },
                {
                  icon: CheckCircle2,
                  actor: "Priya Shah",
                  text: "closed ticket NG-2041 as resolved",
                  time: "1 hr ago",
                  tone: "success",
                },
                {
                  icon: ShoppingCart,
                  actor: "Acme Corp",
                  text: "placed order #51829 for $1,290",
                  time: "2 hr ago",
                  tone: "info",
                },
                {
                  icon: Users,
                  actor: "Marco Bianchi",
                  text: "invited 3 new members to the workspace",
                  time: "4 hr ago",
                  tone: "violet",
                },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div
                    className={cn(
                      "grid h-8 w-8 shrink-0 place-items-center rounded-lg",
                      item.tone === "primary" && "bg-primary/15 text-primary",
                      item.tone === "success" && "bg-[color:var(--success)]/15 text-[color:var(--success)]",
                      item.tone === "info" && "bg-[color:var(--info)]/15 text-[color:var(--info)]",
                      item.tone === "violet" && "bg-violet-500/15 text-violet-500"
                    )}
                  >
                    <item.icon className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm">
                      <span className="font-medium">{item.actor}</span>{" "}
                      <span className="text-muted-foreground">{item.text}</span>
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                      <Clock className="h-3 w-3" /> {item.time}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
            <CardFooter className="border-t justify-end">
              <Button variant="ghost" size="sm" onClick={() => toast.message("Activity log opened")}>
                View all activity <ArrowRight />
              </Button>
            </CardFooter>
          </Card>
        </CardContent>
      </Card>

      {/* Pricing-style cards */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Plan comparison cards</CardTitle>
          <CardDescription>
            Equal-height cards with feature lists, badges and primary action.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-3">
          {[
            {
              name: "Starter",
              price: "$0",
              cadence: "/mo",
              desc: "For solo founders validating an idea.",
              features: ["1 workspace", "3 projects", "Community support", "1 GB storage"],
              cta: "Downgrade",
              featured: false,
            },
            {
              name: "Pro",
              price: "$36",
              cadence: "/mo",
              desc: "For growing teams shipping fast.",
              features: ["Unlimited projects", "Up to 25 members", "Priority email support", "50 GB storage", "Audit logs"],
              cta: "Current plan",
              featured: true,
            },
            {
              name: "Enterprise",
              price: "Custom",
              cadence: "",
              desc: "For organisations with custom needs.",
              features: ["SSO + SAML", "Unlimited members", "Dedicated success manager", "Custom SLAs", "On-prem deployment"],
              cta: "Contact sales",
              featured: false,
            },
          ].map((plan) => (
            <Card
              key={plan.name}
              className={cn(
                "py-4",
                plan.featured && "border-primary/40 ring-2 ring-primary/30 shadow-lg shadow-primary/10"
              )}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{plan.name}</CardTitle>
                  {plan.featured && (
                    <Badge className="bg-primary/15 text-primary ring-1 ring-inset ring-primary/25 border-transparent gap-1">
                      <Sparkles className="h-3 w-3" /> Current
                    </Badge>
                  )}
                </div>
                <CardDescription>{plan.desc}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-semibold tabular-nums">{plan.price}</span>
                  {plan.cadence && <span className="text-sm text-muted-foreground">{plan.cadence}</span>}
                </div>
                <ul className="space-y-1.5 text-sm">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2">
                      <CheckCircle2 className="h-3.5 w-3.5 text-[color:var(--success)]" />
                      <span className="text-muted-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button
                  variant={plan.featured ? "outline" : "default"}
                  className="w-full"
                  onClick={() => toast.message(`${plan.name} plan selected`)}
                >
                  {plan.cta}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Cards page · 6 variants · anatomy · stat cards · profile + product + activity + pricing
      </p>
    </div>
  );
}
