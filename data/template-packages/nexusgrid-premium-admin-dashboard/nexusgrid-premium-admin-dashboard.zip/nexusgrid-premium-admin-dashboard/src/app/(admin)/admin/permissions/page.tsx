"use client";

import * as React from "react";
import {
  ShieldCheck,
  Shield,
  Crown,
  UserCog,
  PenSquare,
  Eye,
  UserX,
  Users,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Filter,
  Search,
  Lock,
  Square,
  CheckSquare,
  X,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const ROLES = [
  { id: "owner", name: "Owner", icon: Crown, tone: "warning" as const, members: 1 },
  { id: "admin", name: "Admin", icon: Shield, tone: "danger" as const, members: 3 },
  { id: "manager", name: "Manager", icon: UserCog, tone: "primary" as const, members: 6 },
  { id: "editor", name: "Editor", icon: PenSquare, tone: "info" as const, members: 14 },
  { id: "viewer", name: "Viewer", icon: Eye, tone: "neutral" as const, members: 9 },
  { id: "guest", name: "Guest", icon: UserX, tone: "violet" as const, members: 4 },
];

const toneIcon: Record<string, string> = {
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  danger: "bg-destructive/15 text-destructive",
  primary: "bg-primary/15 text-primary",
  info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
  neutral: "bg-muted text-muted-foreground",
  violet: "bg-violet-500/15 text-violet-500",
};

const RESOURCES = [
  { name: "Users", icon: Users, desc: "Members, invites, and profile data" },
  { name: "Projects", icon: PenSquare, desc: "Projects, tasks, sprints, and milestones" },
  { name: "Orders", icon: Shield, desc: "Customer orders, refunds, and cancellations" },
  { name: "Reports", icon: Eye, desc: "Analytics, exports, and saved views" },
  { name: "Settings", icon: ShieldCheck, desc: "Workspace configuration and preferences" },
  { name: "Billing", icon: Crown, desc: "Invoices, payment methods, and subscription" },
  { name: "API Keys", icon: Lock, desc: "Programmatic access tokens and scopes" },
  { name: "Webhooks", icon: Shield, desc: "Outbound event delivery endpoints" },
];

const ACTIONS = ["View", "Create", "Edit", "Delete", "Admin"] as const;
type Action = (typeof ACTIONS)[number];

// permission templates per role
const ROLE_TEMPLATES: Record<string, Record<string, Record<Action, boolean>>> = {
  owner: Object.fromEntries(RESOURCES.map((r) => [r.name, Object.fromEntries(ACTIONS.map((a) => [a, true])) as Record<Action, boolean>])) as Record<string, Record<Action, boolean>>,
  admin: {
    Users: { View: true, Create: true, Edit: true, Delete: true, Admin: true },
    Projects: { View: true, Create: true, Edit: true, Delete: true, Admin: true },
    Orders: { View: true, Create: true, Edit: true, Delete: true, Admin: true },
    Reports: { View: true, Create: true, Edit: true, Delete: true, Admin: true },
    Settings: { View: true, Create: true, Edit: true, Delete: false, Admin: true },
    Billing: { View: true, Create: false, Edit: true, Delete: false, Admin: true },
    "API Keys": { View: true, Create: true, Edit: true, Delete: true, Admin: true },
    Webhooks: { View: true, Create: true, Edit: true, Delete: true, Admin: true },
  },
  manager: {
    Users: { View: true, Create: true, Edit: true, Delete: false, Admin: false },
    Projects: { View: true, Create: true, Edit: true, Delete: true, Admin: false },
    Orders: { View: true, Create: true, Edit: true, Delete: false, Admin: false },
    Reports: { View: true, Create: true, Edit: true, Delete: false, Admin: false },
    Settings: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Billing: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    "API Keys": { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Webhooks: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
  },
  editor: {
    Users: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Projects: { View: true, Create: true, Edit: true, Delete: true, Admin: false },
    Orders: { View: true, Create: true, Edit: true, Delete: false, Admin: false },
    Reports: { View: true, Create: true, Edit: false, Delete: false, Admin: false },
    Settings: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Billing: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    "API Keys": { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    Webhooks: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
  },
  viewer: {
    Users: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Projects: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Orders: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Reports: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Settings: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Billing: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    "API Keys": { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    Webhooks: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
  },
  guest: {
    Users: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Projects: { View: true, Create: false, Edit: false, Delete: false, Admin: false },
    Orders: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    Reports: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    Settings: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    Billing: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    "API Keys": { View: false, Create: false, Edit: false, Delete: false, Admin: false },
    Webhooks: { View: false, Create: false, Edit: false, Delete: false, Admin: false },
  },
};

const actionTone: Record<Action, string> = {
  View: "text-[color:var(--info)]",
  Create: "text-[color:var(--success)]",
  Edit: "text-[color:var(--warning)]",
  Delete: "text-destructive",
  Admin: "text-primary",
};

export default function PermissionsPage() {
  const [roleId, setRoleId] = React.useState("manager");
  const [matrix, setMatrix] = React.useState<Record<string, Record<Action, boolean>>>(ROLE_TEMPLATES.manager);
  const [saved, setSaved] = React.useState<Record<string, Record<Action, boolean>>>(ROLE_TEMPLATES.manager);
  const [search, setSearch] = React.useState("");

  const role = ROLES.find((r) => r.id === roleId)!;
  const isDirty = JSON.stringify(matrix) !== JSON.stringify(saved);

  const switchRole = (id: string) => {
    setRoleId(id);
    const tpl = ROLE_TEMPLATES[id];
    setMatrix(tpl);
    setSaved(tpl);
  };

  const toggle = (resource: string, action: Action) =>
    setMatrix((prev) => ({
      ...prev,
      [resource]: { ...prev[resource], [action]: !prev[resource][action] },
    }));

  const setRowAll = (resource: string, value: boolean) =>
    setMatrix((prev) => ({
      ...prev,
      [resource]: Object.fromEntries(ACTIONS.map((a) => [a, value])) as Record<Action, boolean>,
    }));

  const setColAll = (action: Action, value: boolean) =>
    setMatrix((prev) => {
      const next = { ...prev };
      for (const r of Object.keys(next)) next[r] = { ...next[r], [action]: value };
      return next;
    });

  const filteredResources = RESOURCES.filter((r) => !search || r.name.toLowerCase().includes(search.toLowerCase()));

  const totals = {
    enabled: Object.values(matrix).reduce((acc, row) => acc + Object.values(row).filter(Boolean).length, 0),
    total: RESOURCES.length * ACTIONS.length,
  };
  const pct = Math.round((totals.enabled / totals.total) * 100);

  const save = () => {
    setSaved(matrix);
    toast.success(`${role.name} permissions saved`, { description: `${totals.enabled} of ${totals.total} permissions enabled.` });
  };
  const reset = () => { setMatrix(saved); toast.message("Reverted to last saved state"); };

  return (
    <>
      <PageHeader
        title="Permissions"
        description="A grid of resources × actions. Toggle cells to grant or revoke access for the selected role."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Permissions" }]}
        icon={ShieldCheck}
        actions={
          <div className="flex items-center gap-2">
            {isDirty ? (
              <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/40 text-amber-600 bg-amber-500/5">
                <AlertTriangle className="h-3 w-3" /> Unsaved
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[10px] gap-1 border-emerald-500/40 text-emerald-600 bg-emerald-500/5">
                <CheckCircle2 className="h-3 w-3" /> Saved
              </Badge>
            )}
            <Button variant="outline" size="sm" className="gap-1.5" disabled={!isDirty} onClick={reset}>
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </Button>
            <Button size="sm" className="gap-1.5" disabled={!isDirty} onClick={save}>
              <Save className="h-3.5 w-3.5" /> Save changes
            </Button>
          </div>
        }
      />

      {/* ROLE PILLS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-6">
        {ROLES.map((r) => (
          <button
            key={r.id}
            onClick={() => switchRole(r.id)}
            className={cn(
              "flex items-center gap-2.5 p-3 rounded-xl border transition-all text-left",
              roleId === r.id ? "border-primary bg-primary/[0.04] ring-1 ring-primary/30 shadow-premium-xs" : "border-border hover:border-primary/30 bg-card"
            )}
          >
            <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", toneIcon[r.tone])}>
              <r.icon className="h-4 w-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold truncate">{r.name}</p>
              <p className="text-[11px] text-muted-foreground">{r.members} member{r.members > 1 ? "s" : ""}</p>
            </div>
          </button>
        ))}
      </div>

      {/* SUMMARY + MATRIX */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* LEFT SUMMARY */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className={cn("grid place-items-center h-10 w-10 rounded-lg", toneIcon[role.tone])}>
                <role.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-semibold">{role.name}</p>
                <p className="text-xs text-muted-foreground">{role.members} member{role.members > 1 ? "s" : ""} assigned</p>
              </div>
            </div>
            <Separator className="my-3" />
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Permissions enabled</span>
                <span className="font-semibold tabular-nums">{totals.enabled} / {totals.total}</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-primary transition-all" style={{ width: `${pct}%` }} />
              </div>
              <p className="text-[11px] text-muted-foreground mt-1">{pct}% of all resource/action pairs</p>
            </div>
            <Separator className="my-3" />
            <div className="space-y-1.5">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">By action</p>
              {ACTIONS.map((a) => {
                const count = Object.values(matrix).filter((row) => row[a]).length;
                return (
                  <div key={a} className="flex items-center justify-between text-xs">
                    <span className={cn("font-medium", actionTone[a])}>{a}</span>
                    <span className="tabular-nums text-muted-foreground">{count} / {RESOURCES.length}</span>
                  </div>
                );
              })}
            </div>
          </Card>
          <Card className="p-4 bg-primary/[0.03] border-primary/20">
            <p className="text-xs font-medium text-primary mb-1">Permission inheritance</p>
            <p className="text-[11px] text-muted-foreground leading-relaxed">Higher-tier actions imply lower ones. Granting “Admin” on a resource automatically enables View, Create, Edit, and Delete.</p>
          </Card>
        </div>

        {/* MATRIX */}
        <Card className="lg:col-span-3">
          <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3">
            <div>
              <CardTitle className="text-base">Permission matrix — {role.name}</CardTitle>
              <CardDescription>Toggle individual cells or use the column headers to grant a full action across all resources.</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Filter resources…"
                  className="pl-8 h-8 w-[200px] text-xs"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-y border-border bg-muted/40">
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-3 min-w-[260px]">Resource</th>
                    {ACTIONS.map((a) => {
                      const allOn = RESOURCES.every((r) => matrix[r.name][a]);
                      return (
                        <th key={a} className="px-2 py-3 min-w-[88px]">
                          <button
                            type="button"
                            onClick={() => setColAll(a, !allOn)}
                            className="group w-full flex flex-col items-center gap-1"
                          >
                            <span className={cn("text-xs font-semibold uppercase tracking-wide", actionTone[a])}>{a}</span>
                            <span className={cn(
                              "inline-grid place-items-center h-5 w-5 rounded border transition-all",
                              allOn ? "bg-primary border-primary text-primary-foreground" : "border-border text-transparent group-hover:border-primary/40"
                            )}>
                              {allOn ? <CheckSquare className="h-3 w-3" /> : <Square className="h-3 w-3" />}
                            </span>
                          </button>
                        </th>
                      );
                    })}
                    <th className="px-2 py-3 min-w-[88px]">
                      <span className="block text-center text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">All</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredResources.map((res) => {
                    const allOn = ACTIONS.every((a) => matrix[res.name][a]);
                    const noneOn = ACTIONS.every((a) => !matrix[res.name][a]);
                    return (
                      <tr key={res.name} className="hover:bg-muted/20 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2.5">
                            <div className="grid place-items-center h-8 w-8 rounded-lg bg-muted text-muted-foreground shrink-0">
                              <res.icon className="h-4 w-4" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-sm font-medium">{res.name}</p>
                              <p className="text-[11px] text-muted-foreground truncate">{res.desc}</p>
                            </div>
                          </div>
                        </td>
                        {ACTIONS.map((a) => {
                          const checked = matrix[res.name][a];
                          return (
                            <td key={a} className="px-2 py-3 text-center">
                              <button
                                type="button"
                                onClick={() => toggle(res.name, a)}
                                className={cn(
                                  "inline-grid place-items-center h-6 w-6 rounded-md border transition-all",
                                  checked
                                    ? "bg-primary border-primary text-primary-foreground shadow-premium-xs"
                                    : "bg-card border-border text-transparent hover:border-primary/50"
                                )}
                              >
                                {checked && <CheckCircle2 className="h-4 w-4" />}
                              </button>
                            </td>
                          );
                        })}
                        <td className="px-2 py-3 text-center">
                          <button
                            type="button"
                            onClick={() => setRowAll(res.name, !allOn)}
                            className={cn(
                              "text-[10px] font-medium uppercase tracking-wide px-2 py-1 rounded border transition-colors",
                              allOn ? "border-primary/30 bg-primary/10 text-primary" : noneOn ? "border-border text-muted-foreground hover:border-primary/40" : "border-[color:var(--warning)]/30 bg-[color:var(--warning)]/10 text-[color:var(--warning)]"
                            )}
                          >
                            {allOn ? "All" : noneOn ? "None" : "Some"}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredResources.length === 0 && (
                    <tr>
                      <td colSpan={ACTIONS.length + 2} className="text-center text-sm text-muted-foreground py-10">
                        No resources match “{search}”.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Legend */}
            <div className="px-4 py-3 border-t border-border bg-muted/20 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-4 flex-wrap">
                <span className="inline-flex items-center gap-1.5">
                  <span className="inline-grid place-items-center h-4 w-4 rounded bg-primary text-primary-foreground"><CheckCircle2 className="h-2.5 w-2.5" /></span>
                  Granted
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="inline-grid place-items-center h-4 w-4 rounded border border-border" />
                  Denied
                </span>
                <span className="hidden sm:inline">Click any cell or column header to toggle.</span>
              </div>
              <span className="text-[11px]">{isDirty ? "Unsaved changes — save to apply." : "All changes saved."}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
