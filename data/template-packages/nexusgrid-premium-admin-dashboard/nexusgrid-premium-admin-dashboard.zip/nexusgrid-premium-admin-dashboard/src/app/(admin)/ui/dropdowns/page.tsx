"use client";

import * as React from "react";
import {
  ChevronDownSquare,
  User,
  Settings,
  LogOut,
  Mail,
  Moon,
  Sun,
  Monitor,
  Bell,
  CreditCard,
  Trash2,
  Edit3,
  Copy,
  Share2,
  Star,
  Archive,
  Download,
  Tag,
  Move,
  Eye,
  Plus,
  Flag,
  MoreHorizontal,
  ChevronRight,
  Check,
  Keyboard,
  FileText,
  Smile,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuShortcut,
} from "@/components/ui/dropdown-menu";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
  ContextMenuSeparator,
  ContextMenuLabel,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuCheckboxItem,
} from "@/components/ui/context-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function DropdownsPage() {
  const [theme, setTheme] = React.useState("system");
  const [notifications, setNotifications] = React.useState({
    email: true,
    push: false,
    sms: false,
    weekly: true,
  });
  const [visibleColumns, setVisibleColumns] = React.useState({
    name: true,
    email: true,
    role: true,
    status: true,
    lastActive: false,
    spend: true,
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dropdowns"
        description="Disclosed menu surfaces — items, headers, separators, checkboxes, radios, sub-menus and context menus."
        icon={ChevronDownSquare}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/dropdowns" },
          { label: "Dropdowns" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Dropdown tokens copied")}>
            <Copy /> Copy tokens
          </Button>
        }
      />

      {/* Simple + icons */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Simple & with icons</CardTitle>
          <CardDescription>
            Basic dropdowns and the same pattern with leading icons for visual scanning.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">Actions <ChevronRight className="rotate-90" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={() => toast.message("Profile opened")}>Profile</DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.message("Settings opened")}>Settings</DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.message("Billing opened")}>Billing</DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.message("Sign out initiated")}>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">With icons <ChevronRight className="rotate-90" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={() => toast.success("Edit action")}>
                <Edit3 /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Duplicate action")}>
                <Copy /> Duplicate
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Share action")}>
                <Share2 /> Share
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Archive action")}>
                <Archive /> Archive
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Download action")}>
                <Download /> Download
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem variant="destructive" onClick={() => toast.error("Delete action")}>
                <Trash2 /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* With avatar + label */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" alt="Amara" />
                  <AvatarFallback>AR</AvatarFallback>
                </Avatar>
                Amara Reyes <ChevronRight className="rotate-90" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <div className="flex items-center gap-2 px-2 py-1.5">
                <Avatar className="h-9 w-9">
                  <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" alt="Amara" />
                  <AvatarFallback>AR</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">Amara Reyes</p>
                  <p className="text-xs text-muted-foreground truncate">amara@nexusgrid.io</p>
                </div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Account</DropdownMenuLabel>
              <DropdownMenuItem><User /> Profile</DropdownMenuItem>
              <DropdownMenuItem><Settings /> Settings</DropdownMenuItem>
              <DropdownMenuItem><CreditCard /> Billing</DropdownMenuItem>
              <DropdownMenuItem><Bell /> Notifications <DropdownMenuShortcut>⌘N</DropdownMenuShortcut></DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem><Keyboard /> Keyboard shortcuts <DropdownMenuShortcut>⌘K</DropdownMenuShortcut></DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem variant="destructive"><LogOut /> Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Header */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">With label <ChevronRight className="rotate-90" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuLabel>Move to project</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem><Move /> Q3 marketing launch</DropdownMenuItem>
              <DropdownMenuItem><Move /> Billing redesign</DropdownMenuItem>
              <DropdownMenuItem><Move /> Onboarding flow v2</DropdownMenuItem>
              <DropdownMenuItem><Move /> Internal tooling</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem><Plus /> Create new project</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardContent>
      </Card>

      {/* Checkbox + radio */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Checkbox & radio items</CardTitle>
          <CardDescription>
            Multi-select checkboxes and single-select radios for filter and preference menus.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          {/* Checkbox items */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                Columns ({Object.values(visibleColumns).filter(Boolean).length}) <ChevronRight className="rotate-90" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuLabel>Visible columns</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {Object.entries(visibleColumns).map(([key, value]) => (
                <DropdownMenuCheckboxItem
                  key={key}
                  checked={value}
                  onCheckedChange={(c) =>
                    setVisibleColumns((v) => ({ ...v, [key]: !!c }))
                  }
                  onSelect={(e) => e.preventDefault()}
                >
                  {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, " $1")}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Checkbox preferences */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                Notifications <ChevronRight className="rotate-90" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuLabel>Channels</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuCheckboxItem
                checked={notifications.email}
                onCheckedChange={(c) => setNotifications((n) => ({ ...n, email: !!c }))}
                onSelect={(e) => e.preventDefault()}
              >
                <Mail /> Email
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={notifications.push}
                onCheckedChange={(c) => setNotifications((n) => ({ ...n, push: !!c }))}
                onSelect={(e) => e.preventDefault()}
              >
                <Bell /> Push
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={notifications.sms}
                onCheckedChange={(c) => setNotifications((n) => ({ ...n, sms: !!c }))}
                onSelect={(e) => e.preventDefault()}
              >
                <Monitor /> SMS
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={notifications.weekly}
                onCheckedChange={(c) => setNotifications((n) => ({ ...n, weekly: !!c }))}
                onSelect={(e) => e.preventDefault()}
              >
                <FileText /> Weekly digest
              </DropdownMenuCheckboxItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Radio items - theme */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                Theme: {theme} <ChevronRight className="rotate-90" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuLabel>Appearance</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuRadioGroup value={theme} onValueChange={setTheme}>
                <DropdownMenuRadioItem value="light"><Sun /> Light</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="dark"><Moon /> Dark</DropdownMenuRadioItem>
                <DropdownMenuRadioItem value="system"><Monitor /> System</DropdownMenuRadioItem>
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardContent>
      </Card>

      {/* Sub-menus */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Sub-menus</CardTitle>
          <CardDescription>
            Nested menus for organising related actions — useful for tag categories and labels.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Tag /> Tag customer <ChevronRight className="rotate-90" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuLabel>Apply tag</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem><Star /> Favourite</DropdownMenuItem>
              <DropdownMenuItem><Flag /> Flagged</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuSub>
                <DropdownMenuSubTrigger><Tag /> Priority</DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  <DropdownMenuItem><Star className="text-amber-500" /> High</DropdownMenuItem>
                  <DropdownMenuItem><Star /> Medium</DropdownMenuItem>
                  <DropdownMenuItem><Star /> Low</DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger><Smile /> Lifecycle</DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  <DropdownMenuItem>Onboarding</DropdownMenuItem>
                  <DropdownMenuItem>Active</DropdownMenuItem>
                  <DropdownMenuItem>At risk</DropdownMenuItem>
                  <DropdownMenuItem>Churned</DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger><Tag /> Industry</DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  <DropdownMenuItem>SaaS</DropdownMenuItem>
                  <DropdownMenuItem>Finance</DropdownMenuItem>
                  <DropdownMenuItem>Healthcare</DropdownMenuItem>
                  <DropdownMenuItem>Retail</DropdownMenuItem>
                  <DropdownMenuItem>Education</DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSeparator />
              <DropdownMenuItem><Plus /> Create new tag</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download /> Export <ChevronRight className="rotate-90" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuItem onClick={() => toast.success("Exported as CSV")}>
                <FileText /> Comma-separated (CSV)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Exported as JSON")}>
                <FileText /> JSON
              </DropdownMenuItem>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger><FileText /> Spreadsheet</DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  <DropdownMenuItem onClick={() => toast.success("Exported as XLSX")}>Excel (.xlsx)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => toast.success("Exported as ODS")}>OpenDocument (.ods)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => toast.success("Exported as Numbers")}>Apple Numbers</DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSub>
                <DropdownMenuSubTrigger><FileText /> PDF report</DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  <DropdownMenuItem>Summary (1 page)</DropdownMenuItem>
                  <DropdownMenuItem>Detailed (per-row)</DropdownMenuItem>
                  <DropdownMenuItem>With charts</DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => toast.message("Configure export settings")}>
                <Settings /> Export preferences
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardContent>
      </Card>

      {/* Context menu */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Context menu</CardTitle>
          <CardDescription>
            Right-click anywhere inside the box below to reveal a context-sensitive menu.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ContextMenu>
            <ContextMenuTrigger asChild>
              <div className="rounded-lg border-2 border-dashed bg-muted/30 p-8 grid place-items-center min-h-[220px] cursor-context-select">
                <div className="text-center">
                  <MoreHorizontal className="mx-auto h-8 w-8 text-muted-foreground" />
                  <p className="mt-2 text-sm font-medium">Right-click anywhere in this area</p>
                  <p className="text-xs text-muted-foreground">A context menu will appear with row actions</p>
                </div>
              </div>
            </ContextMenuTrigger>
            <ContextMenuContent className="w-56">
              <ContextMenuItem onClick={() => toast.success("Row opened")}>
                <Eye /> Open
              </ContextMenuItem>
              <ContextMenuItem onClick={() => toast.success("Edit action")}>
                <Edit3 /> Edit
              </ContextMenuItem>
              <ContextMenuItem onClick={() => toast.success("Row duplicated")}>
                <Copy /> Duplicate
              </ContextMenuItem>
              <ContextMenuItem onClick={() => toast.success("Share link copied")}>
                <Share2 /> Copy share link
              </ContextMenuItem>
              <ContextMenuSeparator />
              <ContextMenuSub>
                <ContextMenuSubTrigger><Tag /> Assign tag</ContextMenuSubTrigger>
                <ContextMenuSubContent>
                  <ContextMenuItem><Star /> Favourite</ContextMenuItem>
                  <ContextMenuItem><Flag /> Flagged</ContextMenuItem>
                  <ContextMenuItem><Archive /> Archived</ContextMenuItem>
                </ContextMenuSubContent>
              </ContextMenuSub>
              <ContextMenuSub>
                <ContextMenuSubTrigger><Move /> Move to</ContextMenuSubTrigger>
                <ContextMenuSubContent>
                  <ContextMenuItem>Q3 marketing</ContextMenuItem>
                  <ContextMenuItem>Billing redesign</ContextMenuItem>
                  <ContextMenuItem>Onboarding flow v2</ContextMenuItem>
                </ContextMenuSubContent>
              </ContextMenuSub>
              <ContextMenuSeparator />
              <ContextMenuCheckboxItem checked>Show in archive</ContextMenuCheckboxItem>
              <ContextMenuSeparator />
              <ContextMenuItem variant="destructive" onClick={() => toast.error("Row deleted")}>
                <Trash2 /> Delete
              </ContextMenuItem>
            </ContextMenuContent>
          </ContextMenu>
        </CardContent>
      </Card>

      {/* With shortcuts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">With keyboard shortcuts</CardTitle>
          <CardDescription>
            Use <code className="rounded bg-muted px-1 text-xs">DropdownMenuShortcut</code> to display keyboard hints.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">File <ChevronRight className="rotate-90" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuItem><FileText /> New file <DropdownMenuShortcut>⌘N</DropdownMenuShortcut></DropdownMenuItem>
              <DropdownMenuItem><Copy /> Copy <DropdownMenuShortcut>⌘C</DropdownMenuShortcut></DropdownMenuItem>
              <DropdownMenuItem><Download /> Save <DropdownMenuShortcut>⌘S</DropdownMenuShortcut></DropdownMenuItem>
              <DropdownMenuItem><Share2 /> Share <DropdownMenuShortcut>⌘I</DropdownMenuShortcut></DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem variant="destructive"><Trash2 /> Delete <DropdownMenuShortcut>⌫</DropdownMenuShortcut></DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="More actions">
                <MoreHorizontal />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuItem><Eye /> View details</DropdownMenuItem>
              <DropdownMenuItem><Edit3 /> Edit</DropdownMenuItem>
              <DropdownMenuItem><Copy /> Copy ID</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem variant="destructive"><Trash2 /> Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Dropdowns page · icons · labels · checkbox + radio items · sub-menus · context menu · shortcuts
      </p>
    </div>
  );
}
