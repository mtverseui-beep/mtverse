"use client";

import * as React from "react";
import {
  LayoutPanelLeft,
  Save,
  X,
  CheckCircle2,
  User,
  Mail,
  Phone,
  Building2,
  MapPin,
  Tag,
  DollarSign,
  Package,
  Hash,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

function Field({
  label,
  children,
  hint,
  icon: Icon,
  className,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
  icon?: React.ElementType;
  className?: string;
}) {
  return (
    <div className={className}>
      <Label className="text-xs mb-1.5 flex items-center gap-1.5">
        {Icon && <Icon className="h-3.5 w-3.5 text-muted-foreground" />}
        {label}
      </Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground mt-1">{hint}</p>}
    </div>
  );
}

function Actions({ onSave, onCancel, saveLabel = "Save" }: { onSave: () => void; onCancel: () => void; saveLabel?: string }) {
  return (
    <div className="flex items-center justify-end gap-2 pt-4 border-t mt-4">
      <Button type="button" variant="outline" size="sm" onClick={onCancel} className="gap-1.5">
        <X className="h-3.5 w-3.5" /> Cancel
      </Button>
      <Button type="submit" size="sm" onClick={onSave} className="gap-1.5">
        <Save className="h-3.5 w-3.5" /> {saveLabel}
      </Button>
    </div>
  );
}

export default function FormLayoutsPage() {
  return (
    <>
      <PageHeader
        title="Form Layouts"
        description="Four production-ready layouts — single column, two-column, three-column and sectioned forms."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Form Layouts" }]}
        icon={LayoutPanelLeft}
        actions={<Badge variant="secondary" className="text-[10px] uppercase tracking-wide">4 layouts</Badge>}
      />

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* SINGLE COLUMN */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">1</span>
              Single Column
            </CardTitle>
            <CardDescription>Best for narrow panels and mobile-first customer forms.</CardDescription>
          </CardHeader>
          <CardContent>
            <form
              className="grid gap-4"
              onSubmit={(e) => {
                e.preventDefault();
                toast.success("Customer profile created");
                (e.target as HTMLFormElement).reset();
              }}
            >
              <Field label="Full name" icon={User}>
                <Input name="name" placeholder="Sarah Chen" />
              </Field>
              <Field label="Email address" icon={Mail}>
                <Input name="email" type="email" placeholder="sarah@example.com" />
              </Field>
              <Field label="Phone" icon={Phone}>
                <Input name="phone" type="tel" placeholder="+1 (415) 555-0148" />
              </Field>
              <Field label="Company" icon={Building2}>
                <Input name="company" placeholder="Aurora Labs Inc." />
              </Field>
              <Field label="Notes" hint="Optional — visible to your account team only.">
                <Textarea name="notes" rows={3} placeholder="VIP customer, prefers email contact" />
              </Field>
              <Actions onSave={() => toast.success("Customer profile created")} onCancel={() => toast.message("Discarded changes")} saveLabel="Create customer" />
            </form>
          </CardContent>
        </Card>

        {/* TWO COLUMN */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">2</span>
              Two Column Grid
            </CardTitle>
            <CardDescription>Compact layout ideal for product creation forms.</CardDescription>
          </CardHeader>
          <CardContent>
            <form
              className="grid gap-4"
              onSubmit={(e) => {
                e.preventDefault();
                toast.success("Product saved to catalog");
                (e.target as HTMLFormElement).reset();
              }}
            >
              <Field label="Product name" icon={Package} className="col-span-full">
                <Input name="pname" placeholder="Aurora Wireless Headphones" />
              </Field>
              <Field label="SKU" icon={Hash}>
                <Input name="sku" placeholder="AUR-WH-001" className="font-mono text-xs" />
              </Field>
              <Field label="Category" icon={Tag}>
                <Select name="cat" defaultValue="audio">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="audio">Audio</SelectItem>
                    <SelectItem value="wearables">Wearables</SelectItem>
                    <SelectItem value="accessories">Accessories</SelectItem>
                    <SelectItem value="smart-home">Smart Home</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Price" icon={DollarSign}>
                <Input name="price" type="number" step="0.01" min={0} defaultValue="189.00" />
              </Field>
              <Field label="Stock">
                <Input name="stock" type="number" min={0} defaultValue={248} />
              </Field>
              <Field label="Short description" className="col-span-full" hint="Shown on product cards and search results.">
                <Textarea name="desc" rows={3} placeholder="Premium over-ear headphones with active noise cancellation and 40-hour battery life." />
              </Field>
              <Actions onSave={() => toast.success("Product saved to catalog")} onCancel={() => toast.message("Discarded changes")} saveLabel="Save product" />
            </form>
          </CardContent>
        </Card>

        {/* THREE COLUMN */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">3</span>
              Three Column Grid
            </CardTitle>
            <CardDescription>Wide desktop layout — collapses gracefully on smaller screens.</CardDescription>
          </CardHeader>
          <CardContent>
            <form
              className="grid gap-4"
              onSubmit={(e) => {
                e.preventDefault();
                toast.success("Inventory record updated");
                (e.target as HTMLFormElement).reset();
              }}
            >
              <Field label="Warehouse" icon={Building2} className="sm:col-span-3">
                <Select name="wh" defaultValue="sf">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sf">San Francisco — Pier 96</SelectItem>
                    <SelectItem value="ny">New York — Jersey City</SelectItem>
                    <SelectItem value="eu">Rotterdam — EU Hub</SelectItem>
                    <SelectItem value="sg">Singapore — APAC Hub</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Item code" icon={Hash} className="sm:col-span-1">
                <Input name="code" placeholder="AUR-WH-001" className="font-mono text-xs" />
              </Field>
              <Field label="On hand" className="sm:col-span-1">
                <Input name="onhand" type="number" defaultValue={248} />
              </Field>
              <Field label="Reserved" className="sm:col-span-1">
                <Input name="reserved" type="number" defaultValue={32} />
              </Field>
              <Field label="Reorder point" className="sm:col-span-1">
                <Input name="reorder" type="number" defaultValue={80} />
              </Field>
              <Field label="Lead time (days)" className="sm:col-span-1">
                <Input name="lead" type="number" defaultValue={14} />
              </Field>
              <Field label="Bin location" icon={MapPin} className="sm:col-span-1">
                <Input name="bin" placeholder="A-12-04" className="font-mono text-xs" />
              </Field>
              <Actions onSave={() => toast.success("Inventory record updated")} onCancel={() => toast.message("Discarded changes")} />
            </form>
          </CardContent>
        </Card>

        {/* SECTIONED */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-[11px] font-semibold">4</span>
              Sectioned Form with Dividers
            </CardTitle>
            <CardDescription>Group fields with labeled sections for complex records.</CardDescription>
          </CardHeader>
          <CardContent>
            <form
              className="grid gap-4"
              onSubmit={(e) => {
                e.preventDefault();
                toast.success("Supplier onboarded successfully");
                (e.target as HTMLFormElement).reset();
              }}
            >
              <div className="grid gap-1">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5" /> Primary Contact
                </p>
                <Separator />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Contact name" icon={User}>
                  <Input name="cname" placeholder="Marcus Reyes" />
                </Field>
                <Field label="Role">
                  <Input name="role" placeholder="Account Manager" />
                </Field>
                <Field label="Email" icon={Mail}>
                  <Input name="cemail" type="email" placeholder="marcus@supplier.com" />
                </Field>
                <Field label="Phone" icon={Phone}>
                  <Input name="cphone" type="tel" placeholder="+1 (415) 555-0148" />
                </Field>
              </div>

              <div className="grid gap-1 pt-2">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5">
                  <Building2 className="h-3.5 w-3.5" /> Company
                </p>
                <Separator />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Legal name" className="sm:col-span-2">
                  <Input name="legal" placeholder="Quantum Components LLC" />
                </Field>
                <Field label="Tax ID">
                  <Input name="taxid" placeholder="84-2918372" className="font-mono text-xs" />
                </Field>
                <Field label="Payment terms">
                  <Select name="terms" defaultValue="net30">
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="net15">Net 15</SelectItem>
                      <SelectItem value="net30">Net 30</SelectItem>
                      <SelectItem value="net45">Net 45</SelectItem>
                      <SelectItem value="net60">Net 60</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
              </div>

              <div className="grid gap-1 pt-2">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5" /> Shipping Address
                </p>
                <Separator />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Street" className="sm:col-span-2">
                  <Input name="street" placeholder="1140 Mission St, Suite 400" />
                </Field>
                <Field label="City">
                  <Input name="city" placeholder="San Francisco" />
                </Field>
                <Field label="State / Province">
                  <Input name="state" placeholder="CA" />
                </Field>
                <Field label="Postal code">
                  <Input name="zip" placeholder="94103" />
                </Field>
                <Field label="Country">
                  <Select name="country" defaultValue="us">
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="us">United States</SelectItem>
                      <SelectItem value="ca">Canada</SelectItem>
                      <SelectItem value="de">Germany</SelectItem>
                      <SelectItem value="jp">Japan</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
              </div>

              <Actions onSave={() => toast.success("Supplier onboarded successfully")} onCancel={() => toast.message("Discarded changes")} saveLabel="Onboard supplier" />
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Tips footer */}
      <Card className="mt-6 bg-muted/30">
        <CardContent className="pt-0">
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { t: "Mobile first", d: "Always start single-column and stack fields. Use sm:grid-cols-2 to upgrade on wider viewports.", icon: User },
              { t: "Logical grouping", d: "Use section headers with separators to break long forms into scannable chunks.", icon: Building2 },
              { t: "Sticky actions", d: "For very long forms, keep the action bar sticky to the bottom of the viewport.", icon: CheckCircle2 },
            ].map((tip) => (
              <div key={tip.t} className="flex items-start gap-3">
                <div className="grid place-items-center h-8 w-8 rounded-lg bg-primary/10 text-primary shrink-0">
                  <tip.icon className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">{tip.t}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{tip.d}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </>
  );
}
