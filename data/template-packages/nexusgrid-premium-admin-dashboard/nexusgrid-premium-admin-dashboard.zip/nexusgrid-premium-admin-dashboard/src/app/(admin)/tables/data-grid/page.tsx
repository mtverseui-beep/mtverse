"use client";

import * as React from "react";
import {
  Grid3x3,
  TrendingUp,
  TrendingDown,
  Filter,
  Search,
  Download,
  ArrowUpDown,
  Sparkles,
  Sigma,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type ProductRow = {
  sku: string;
  name: string;
  category: "Audio" | "Peripherals" | "Cameras" | "Lighting" | "Furniture" | "Wearables";
  months: number[]; // 12 entries (Jan–Dec 2026)
  color: string;
};

const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const products: ProductRow[] = [
  { sku: "NX-1001", name: "Aurora Mechanical Keyboard", category: "Peripherals", color: "var(--primary)", months: [12400, 13800, 15200, 14600, 16800, 18400, 21200, 22400, 21800, 19600, 23800, 28400] },
  { sku: "NX-1002", name: "Lumen 4K Webcam", category: "Cameras", color: "var(--info)", months: [8200, 7600, 8800, 9400, 10200, 11800, 12600, 13200, 12400, 11600, 14200, 16800] },
  { sku: "NX-1003", name: "Pulse Wireless Mouse", category: "Peripherals", color: "var(--success)", months: [18600, 19400, 21200, 22800, 24600, 26800, 28400, 31200, 29800, 27400, 32600, 36800] },
  { sku: "NX-1004", name: "Cadence Studio Headphones", category: "Audio", color: "violet", months: [6400, 7200, 8800, 9600, 11200, 13800, 16400, 18200, 17600, 15800, 19400, 22800] },
  { sku: "NX-1005", name: "Beacon Smart Lamp", category: "Lighting", color: "var(--warning)", months: [4200, 4600, 5400, 5800, 6400, 7200, 7800, 8400, 8200, 7600, 9200, 10800] },
  { sku: "NX-1006", name: "Halo USB-C Hub", category: "Peripherals", color: "var(--info)", months: [9800, 10200, 11800, 12400, 13200, 14600, 15800, 16400, 15600, 14800, 17200, 19800] },
  { sku: "NX-1007", name: "Echo Standing Desk", category: "Furniture", color: "var(--primary)", months: [3200, 3400, 3800, 4200, 4600, 5200, 5800, 6200, 6000, 5600, 6400, 7400] },
  { sku: "NX-1008", name: "Vega Wireless Earbuds", category: "Audio", color: "violet", months: [14800, 16200, 18400, 19600, 22400, 24800, 27200, 29400, 28200, 26400, 30800, 35400] },
  { sku: "NX-1009", name: "Pulse Fitness Band", category: "Wearables", color: "var(--success)", months: [6800, 7200, 8200, 8800, 9600, 10400, 11200, 11800, 11400, 10800, 12600, 14800] },
  { sku: "NX-1010", name: "Lumen Stream Mic", category: "Audio", color: "var(--warning)", months: [4200, 4400, 5200, 5800, 6400, 7600, 8800, 9600, 9200, 8400, 10200, 12400] },
];

const categoryToneMap: Record<ProductRow["category"], "primary" | "info" | "violet" | "warning" | "success" | "neutral"> = {
  Audio: "violet",
  Peripherals: "primary",
  Cameras: "info",
  Lighting: "warning",
  Furniture: "neutral",
  Wearables: "success",
};

const fmt = (n: number) => n.toLocaleString("en-US", { maximumFractionDigits: 0 });

export default function DataGridPage() {
  const [search, setSearch] = React.useState("");
  const [categoryFilter, setCategoryFilter] = React.useState<string>("");
  const [hoveredCell, setHoveredCell] = React.useState<{ row: number; col: number } | null>(null);
  const [sortDir, setSortDir] = React.useState<"asc" | "desc" | null>("desc");

  const categories = Array.from(new Set(products.map((p) => p.category)));

  const filteredRows = React.useMemo(() => {
    let result = [...products];
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((p) => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q));
    }
    if (categoryFilter) result = result.filter((p) => p.category === categoryFilter);
    if (sortDir) {
      const totals = result.map((p) => ({ p, total: p.months.reduce((a, b) => a + b, 0) }));
      totals.sort((a, b) => (sortDir === "asc" ? a.total - b.total : b.total - a.total));
      result = totals.map((t) => t.p);
    }
    return result;
  }, [search, categoryFilter, sortDir]);

  // Column totals (monthly)
  const monthTotals = React.useMemo(() => {
    const totals = new Array(12).fill(0);
    filteredRows.forEach((p) => p.months.forEach((v, i) => (totals[i] += v)));
    return totals;
  }, [filteredRows]);

  const grandTotal = monthTotals.reduce((a, b) => a + b, 0);
  const rowTotals = filteredRows.map((p) => p.months.reduce((a, b) => a + b, 0));
  const allValues = filteredRows.flatMap((p) => p.months);
  const maxValue = Math.max(...allValues, 1);
  const minValue = Math.min(...allValues, 0);

  // Year-over-year comparison (simulated): each month vs prior year
  const yoyGrowth = monthTotals.map((m, i) => {
    // Simulated prior year: 12% lower baseline with seasonal variation
    const prior = Math.round(m * (0.78 + (i % 3) * 0.04));
    return prior > 0 ? ((m - prior) / prior) * 100 : 0;
  });

  const cycleSort = () => {
    setSortDir((prev) => (prev === "asc" ? "desc" : prev === "desc" ? null : "asc"));
  };

  return (
    <>
      <PageHeader
        title="Data Grid"
        description="Excel-like product × month sales matrix with fixed header row, fixed first column, row striping, intensity-scaled cell heat, and a totals footer — built from scratch (not the DataTable component)."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Data Grid" }]}
        icon={Grid3x3}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Sales matrix exported as XLSX (demo)")}>
            <Download className="h-3.5 w-3.5" /> Export grid
          </Button>
        }
      />

      {/* Top KPI strip — unique visual element: heat-map mini summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">FY 2026 Revenue</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">${(grandTotal / 1000).toFixed(1)}K</p>
                <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1.5">
                  <TrendingUp className="h-3 w-3" /> +18.4% vs FY 2025
                </p>
              </div>
              <span className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                <Sigma className="h-4 w-4" />
              </span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Best Month</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5">Dec</p>
            <p className="text-xs text-muted-foreground mt-1.5">${(monthTotals[11] / 1000).toFixed(1)}K · peak season</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Slowest Month</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5">Jan</p>
            <p className="text-xs text-muted-foreground mt-1.5">${(monthTotals[0] / 1000).toFixed(1)}K · post-holiday dip</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Top Product</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 truncate">Pulse Mouse</p>
            <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1.5">
              <TrendingUp className="h-3 w-3" /> ${Math.max(...rowTotals).toLocaleString()} total
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between text-base">
            <span className="flex items-center gap-2">
              <span className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
                <Grid3x3 className="h-4 w-4" />
              </span>
              Product × Month Revenue Matrix
            </span>
            <Badge variant="outline" className="text-[11px]">{filteredRows.length} products · 12 months</Badge>
          </CardTitle>
          <CardDescription className="text-xs">
            Cell background intensity scales with revenue relative to the grid maximum. Click a column header to sort. Hover any cell to highlight its row + column.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Toolbar: search + category filter + sort */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2 mb-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search SKU or product…"
                className="h-8 pl-8 text-xs"
              />
            </div>
            <div className="flex items-center gap-1.5">
              <Button
                variant={categoryFilter === "" ? "default" : "outline"}
                size="sm"
                className="h-8 text-xs"
                onClick={() => setCategoryFilter("")}
              >
                All
              </Button>
              {categories.map((c) => (
                <Button
                  key={c}
                  variant={categoryFilter === c ? "default" : "outline"}
                  size="sm"
                  className="h-8 text-xs"
                  onClick={() => setCategoryFilter(c)}
                >
                  {c}
                </Button>
              ))}
            </div>
            <div className="flex-1" />
            <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={cycleSort}>
              <ArrowUpDown className="h-3.5 w-3.5" />
              Sort total: {sortDir === "asc" ? "asc" : sortDir === "desc" ? "desc" : "none"}
            </Button>
          </div>

          {/* The Excel-like grid */}
          <div className="rounded-lg border border-border overflow-auto max-h-[640px]">
            <table className="w-full border-collapse text-sm">
              <thead className="sticky top-0 z-20">
                {/* Year-over-year growth row */}
                <tr className="bg-muted/60 border-b border-border">
                  <th className="sticky left-0 z-30 bg-muted/60 border-r border-border px-3 py-1.5 text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    YoY Growth
                  </th>
                  {yoyGrowth.map((g, i) => (
                    <th
                      key={i}
                      className={cn(
                        "border-r border-border px-2 py-1.5 text-[10px] font-medium tabular-nums text-center",
                        g >= 0 ? "text-[color:var(--success)]" : "text-[color:var(--danger)]"
                      )}
                    >
                      {g >= 0 ? "+" : ""}{g.toFixed(1)}%
                    </th>
                  ))}
                  <th className="bg-muted/60 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground text-right">
                    Avg
                  </th>
                </tr>
                {/* Month headers */}
                <tr className="bg-muted/40 border-b border-border">
                  <th className="sticky left-0 z-30 bg-muted/40 border-r border-border px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-foreground">
                    Product
                  </th>
                  {months.map((m, i) => (
                    <th
                      key={m}
                      className={cn(
                        "border-r border-border px-2 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground text-center min-w-[80px]",
                        hoveredCell?.col === i && "bg-primary/10 text-foreground"
                      )}
                    >
                      {m}
                    </th>
                  ))}
                  <th className="bg-muted/40 px-3 py-2 text-right text-xs font-semibold uppercase tracking-wide text-foreground min-w-[90px]">
                    Row Total
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredRows.length === 0 ? (
                  <tr>
                    <td colSpan={14} className="text-center text-sm text-muted-foreground py-12">
                      No products match the current filters.
                    </td>
                  </tr>
                ) : (
                  filteredRows.map((p, ri) => {
                    const total = rowTotals[ri];
                    const avg = Math.round(total / 12);
                    return (
                      <tr key={p.sku} className={cn("border-b border-border last:border-0", ri % 2 === 1 && "bg-muted/20")}>
                        {/* Fixed first column */}
                        <td
                          className={cn(
                            "sticky left-0 z-10 border-r border-border px-3 py-2 bg-card",
                            ri % 2 === 1 && "bg-muted/30",
                            hoveredCell?.row === ri && "bg-primary/5"
                          )}
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className="h-2 w-2 rounded-full shrink-0"
                              style={{ backgroundColor: p.color }}
                            />
                            <div className="min-w-0">
                              <p className="font-medium text-xs truncate max-w-[180px]">{p.name}</p>
                              <p className="text-[10px] text-muted-foreground font-mono">{p.sku}</p>
                            </div>
                          </div>
                        </td>
                        {/* Revenue cells */}
                        {p.months.map((v, ci) => {
                          const intensity = (v - minValue) / (maxValue - minValue || 1);
                          const bg = `color-mix(in srgb, ${p.color} ${10 + intensity * 38}%, transparent)`;
                          return (
                            <td
                              key={ci}
                              className={cn(
                                "border-r border-border px-2 py-1.5 text-center text-xs tabular-nums cursor-default transition-colors",
                                hoveredCell?.row === ri && hoveredCell?.col === ci && "ring-2 ring-inset ring-foreground/40",
                                hoveredCell?.row === ri && "bg-primary/10",
                                hoveredCell?.col === ci && "bg-primary/10"
                              )}
                              style={{ backgroundColor: bg }}
                              onMouseEnter={() => setHoveredCell({ row: ri, col: ci })}
                              onMouseLeave={() => setHoveredCell(null)}
                              title={`${p.name} · ${months[ci]} 2026: $${fmt(v)}`}
                            >
                              <span className={cn(intensity > 0.55 ? "font-semibold text-foreground" : "text-foreground/80")}>
                                {v >= 1000 ? `${(v / 1000).toFixed(1)}K` : v}
                              </span>
                            </td>
                          );
                        })}
                        {/* Row total */}
                        <td className={cn("px-3 py-1.5 text-right text-xs tabular-nums font-semibold bg-muted/30", hoveredCell?.row === ri && "bg-primary/10")}>
                          ${fmt(total)}
                          <div className="text-[10px] font-normal text-muted-foreground">${fmt(avg)}/mo avg</div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
              {/* Totals footer */}
              <tfoot className="sticky bottom-0 z-10">
                <tr className="bg-muted/60 border-t-2 border-border font-semibold">
                  <td className="sticky left-0 z-10 bg-muted/60 border-r border-border px-3 py-2 text-xs uppercase tracking-wide text-foreground">
                    Monthly Total
                  </td>
                  {monthTotals.map((t, i) => (
                    <td
                      key={i}
                      className={cn(
                        "border-r border-border px-2 py-2 text-center text-xs tabular-nums",
                        hoveredCell?.col === i && "bg-primary/15"
                      )}
                    >
                      ${fmt(t)}
                    </td>
                  ))}
                  <td className="bg-primary/10 px-3 py-2 text-right text-sm tabular-nums font-bold text-primary">
                    ${fmt(grandTotal)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Legend strip */}
          <div className="flex flex-wrap items-center gap-3 mt-3">
            <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide">Cell heat:</span>
            <div className="inline-flex items-center gap-1">
              <span className="h-3 w-3 rounded-sm border border-border" style={{ backgroundColor: "color-mix(in srgb, var(--primary) 10%, transparent)" }} />
              <span className="text-[11px] text-muted-foreground">low</span>
            </div>
            <div className="inline-flex items-center gap-1">
              <span className="h-3 w-3 rounded-sm border border-border" style={{ backgroundColor: "color-mix(in srgb, var(--primary) 28%, transparent)" }} />
              <span className="text-[11px] text-muted-foreground">mid</span>
            </div>
            <div className="inline-flex items-center gap-1">
              <span className="h-3 w-3 rounded-sm border border-border" style={{ backgroundColor: "color-mix(in srgb, var(--primary) 48%, transparent)" }} />
              <span className="text-[11px] text-muted-foreground">high</span>
            </div>
            <div className="ml-auto flex items-center gap-2 text-[11px] text-muted-foreground">
              <Filter className="h-3 w-3" />
              <span>Each product uses its category color for the heat scale.</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category breakdown card — unique visual element */}
      <Card className="mt-6">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
              <Sparkles className="h-4 w-4" />
            </span>
            Category Contribution Breakdown
          </CardTitle>
          <CardDescription className="text-xs">
            Stacked bar showing each category's share of FY 2026 revenue — derived live from the grid above.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {(() => {
            const byCat = categories.map((c) => ({
              cat: c,
              total: products.filter((p) => p.category === c).reduce((s, p) => s + p.months.reduce((a, b) => a + b, 0), 0),
              color: products.find((p) => p.category === c)?.color ?? "var(--primary)",
            }));
            const grand = byCat.reduce((s, x) => s + x.total, 0);
            const sorted = [...byCat].sort((a, b) => b.total - a.total);
            return (
              <div className="space-y-3">
                <div className="flex h-3 rounded-full overflow-hidden ring-1 ring-border">
                  {sorted.map((c) => (
                    <div
                      key={c.cat}
                      style={{ width: `${(c.total / grand) * 100}%`, backgroundColor: c.color }}
                      title={`${c.cat}: $${fmt(c.total)} (${((c.total / grand) * 100).toFixed(1)}%)`}
                    />
                  ))}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                  {sorted.map((c) => {
                    const pct = (c.total / grand) * 100;
                    return (
                      <div key={c.cat} className="rounded-lg border border-border p-2.5">
                        <div className="flex items-center gap-1.5">
                          <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: c.color }} />
                          <span className="text-xs font-medium">{c.cat}</span>
                        </div>
                        <p className="text-sm font-semibold tabular-nums mt-1">${(c.total / 1000).toFixed(1)}K</p>
                        <p className="text-[11px] text-muted-foreground tabular-nums">{pct.toFixed(1)}% of total</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </CardContent>
      </Card>
    </>
  );
}
