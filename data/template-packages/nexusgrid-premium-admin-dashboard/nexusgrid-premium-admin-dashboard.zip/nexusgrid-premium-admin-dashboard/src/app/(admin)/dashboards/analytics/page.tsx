"use client";

import * as React from "react";
import {
  BarChart3,
  Users,
  Eye,
  MousePointerClick,
  Activity,
  Globe,
  Download,
  CalendarRange,
  ArrowUpRight,
  TrendingUp,
  TrendingDown,
  Smartphone,
  Monitor,
  Tablet,
  Zap,
  Target,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { KpiCard, Sparkline } from "@/components/common/kpi-card";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  AreaTrendChart,
  DonutChart,
  RadialProgress,
} from "@/components/charts";
import {
  analyticsTraffic,
  analyticsSources,
  analyticsDevices,
  topPages,
} from "@/data/mock-data";

// Inline geo data (top 5 countries). Distinct from mock-data sets used elsewhere.
const geoCountries = [
  { country: "United States", code: "US", visitors: 38420, share: 42.8 },
  { country: "United Kingdom", code: "GB", visitors: 14820, share: 16.5 },
  { country: "Germany", code: "DE", visitors: 9840, share: 11.0 },
  { country: "India", code: "IN", visitors: 8240, share: 9.2 },
  { country: "Brazil", code: "BR", visitors: 6180, share: 6.9 },
];

const liveCountries = [
  { country: "United States", visitors: 1248 },
  { country: "United Kingdom", visitors: 642 },
  { country: "Germany", visitors: 418 },
  { country: "India", visitors: 392 },
  { country: "Canada", visitors: 284 },
];

const geoBarColors = [
  "var(--primary)",
  "oklch(0.70 0.15 75)",
  "var(--info)",
  "oklch(0.62 0.18 25)",
  "oklch(0.58 0.13 250)",
];

const deviceIcons: Record<string, React.ReactNode> = {
  Desktop: <Monitor className="h-3.5 w-3.5" />,
  Mobile: <Smartphone className="h-3.5 w-3.5" />,
  Tablet: <Tablet className="h-3.5 w-3.5" />,
};

export default function AnalyticsDashboardPage() {
  const usersSeries = analyticsTraffic.map((d) => d.users);
  const sessionsSeries = analyticsTraffic.map((d) => d.sessions);
  const pageviewsSeries = analyticsTraffic.map((d) => d.pageviews);
  // Compose a believable bounce-rate series from the page-level bounce values.
  const bounceSeries = topPages.map((p) => p.bounce);
  const maxViews = Math.max(...topPages.map((p) => p.views));
  const totalSources = analyticsSources.reduce((s, x) => s + x.value, 0);
  const liveUsers = liveCountries.reduce((s, x) => s + x.visitors, 0);

  return (
    <>
      <PageHeader
        title="Analytics Dashboard"
        description="Product analytics across acquisition, engagement, and conversion — refreshed every 60 seconds."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Analytics" }]}
        icon={BarChart3}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <CalendarRange className="h-3.5 w-3.5" /> Last 7 days
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5">
              <Zap className="h-3.5 w-3.5" /> Real-time
            </Button>
          </>
        }
      />

      {/* KPI Row — sparkline-driven, distinct from ecommerce's hint-only cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Active Users"
          value="84,392"
          icon={Users}
          accent="primary"
          trend={{ value: 12.4, direction: "up" }}
          hint="vs last 7 days"
          sparkline={<Sparkline data={usersSeries} color="var(--primary)" />}
        />
        <KpiCard
          label="Sessions"
          value="112,840"
          icon={MousePointerClick}
          accent="info"
          trend={{ value: 8.2, direction: "up" }}
          hint="1.34 per user"
          sparkline={<Sparkline data={sessionsSeries} color="var(--info)" />}
        />
        <KpiCard
          label="Page Views"
          value="284,392"
          icon={Eye}
          accent="success"
          trend={{ value: 18.6, direction: "up" }}
          hint="2.52 per session"
          sparkline={<Sparkline data={pageviewsSeries} color="var(--success)" />}
        />
        <KpiCard
          label="Bounce Rate"
          value="38.2%"
          icon={Activity}
          accent="warning"
          // Down is good for bounce rate → positive override
          trend={{ value: 2.1, direction: "down", positive: true }}
          hint="lower is better"
          sparkline={<Sparkline data={bounceSeries} color="var(--warning)" />}
        />
      </div>

      {/* Traffic overview + sources */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Traffic Overview
              </CardTitle>
              <CardDescription>Daily users, sessions, and page views for the selected window.</CardDescription>
            </div>
            <Tabs defaultValue="all" className="w-auto">
              <TabsList className="grid w-full grid-cols-3 h-8">
                <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                <TabsTrigger value="users" className="text-xs">Users</TabsTrigger>
                <TabsTrigger value="views" className="text-xs">Views</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="hidden" />
              <TabsContent value="users" className="hidden" />
              <TabsContent value="views" className="hidden" />
            </Tabs>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={analyticsTraffic}
              xKey="date"
              series={[
                { key: "pageviews", name: "Page Views", color: "var(--info)" },
                { key: "sessions", name: "Sessions", color: "var(--primary)" },
                { key: "users", name: "Users", color: "oklch(0.70 0.15 75)" },
              ]}
              height={300}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Traffic Sources</CardTitle>
            <CardDescription>Where your visitors are coming from.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={analyticsSources}
              centerLabel="Visitors"
              centerValue={totalSources.toLocaleString()}
              height={200}
            />
            <div className="mt-3 space-y-1.5 max-h-44 overflow-y-auto pr-1 custom-scroll">
              {analyticsSources.map((s) => {
                const pct = ((s.value / totalSources) * 100).toFixed(1);
                return (
                  <div key={s.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="h-2 w-2 rounded-full shrink-0" style={{ background: s.color }} />
                      <span className="text-muted-foreground truncate">{s.name}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-medium tabular-nums">{s.value.toLocaleString()}</span>
                      <span className="text-muted-foreground tabular-nums w-10 text-right">{pct}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top pages + right column (live + devices) */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base">Top Pages</CardTitle>
              <CardDescription>Most-viewed routes with engagement quality signals.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View report <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Path</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Views</th>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-40 hidden md:table-cell">Share</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Bounce</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Avg. Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {topPages.map((p) => {
                    const widthPct = (p.views / maxViews) * 100;
                    const bounceTone = p.bounce < 25 ? "success" : p.bounce < 35 ? "warning" : "danger";
                    return (
                      <tr key={p.path} className="hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3">
                          <span className="font-mono text-xs text-foreground">{p.path}</span>
                        </td>
                        <td className="px-4 py-3 text-right tabular-nums font-medium">{p.views.toLocaleString()}</td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-primary/60 to-primary transition-all duration-700 ease-out"
                              style={{ width: `${widthPct}%` }}
                            />
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right hidden sm:table-cell">
                          <StatusBadge tone={bounceTone as any} dot>
                            {p.bounce}%
                          </StatusBadge>
                        </td>
                        <td className="px-4 py-3 text-right tabular-nums text-muted-foreground hidden lg:table-cell">
                          {p.avgTime}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Right column: Live users + Devices */}
        <div className="space-y-4">
          {/* Live users — pulsing dot, premium gradient card */}
          <Card className="relative overflow-hidden bg-gradient-to-br from-primary/[0.06] via-card to-card">
            <CardContent className="pt-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="absolute inline-flex h-full w-full rounded-full bg-[color:var(--success)] opacity-75 animate-ping" />
                    <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[color:var(--success)]" />
                  </span>
                  <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Live now</span>
                </div>
                <StatusBadge tone="success" dot>Active</StatusBadge>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-semibold tabular-nums tracking-tight">{liveUsers.toLocaleString()}</span>
                <span className="text-xs text-muted-foreground">users online</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Updated 12 seconds ago</p>

              <div className="mt-4 pt-4 border-t border-border">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2.5">Top countries</p>
                <ul className="space-y-2">
                  {liveCountries.map((c) => (
                    <li key={c.country} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 min-w-0">
                        <Globe className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <span className="text-foreground truncate">{c.country}</span>
                      </div>
                      <span className="font-medium tabular-nums text-muted-foreground">{c.visitors.toLocaleString()}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Device breakdown */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Devices</CardTitle>
              <CardDescription>Session split by device class.</CardDescription>
            </CardHeader>
            <CardContent>
              <DonutChart
                data={analyticsDevices}
                centerLabel="Desktop"
                centerValue="58%"
                height={180}
                innerRadius={48}
                outerRadius={72}
              />
              <div className="mt-3 grid grid-cols-3 gap-2">
                {analyticsDevices.map((d) => (
                  <div key={d.name} className="rounded-lg border border-border bg-muted/30 px-2.5 py-2 text-center">
                    <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                      {deviceIcons[d.name]}
                      <span className="text-[10px] uppercase tracking-wide">{d.name}</span>
                    </div>
                    <div className="flex items-center justify-center gap-1.5">
                      <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                      <span className="text-sm font-semibold tabular-nums">{d.value}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Geo analytics + Conversion radial */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Globe className="h-4 w-4 text-primary" />
                Geo Analytics
              </CardTitle>
              <CardDescription>Top contributing countries this period.</CardDescription>
            </div>
            <StatusBadge tone="info">5 of 42</StatusBadge>
          </CardHeader>
          <CardContent className="space-y-3.5">
            {geoCountries.map((c, i) => (
              <div key={c.code} className="flex items-center gap-3">
                <div className="grid place-items-center h-7 w-7 rounded-md bg-muted text-xs font-semibold text-muted-foreground tabular-nums shrink-0">
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="font-medium text-foreground truncate">{c.country}</span>
                    <span className="text-xs text-muted-foreground tabular-nums">{c.visitors.toLocaleString()} visits</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 flex-1 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700 ease-out"
                        style={{ width: `${(c.share / 42.8) * 100}%`, background: geoBarColors[i % geoBarColors.length] }}
                      />
                    </div>
                    <span className="text-xs font-medium tabular-nums w-12 text-right text-muted-foreground">{c.share}%</span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="h-4 w-4 text-[color:var(--success)]" />
              Conversion Rate
            </CardTitle>
            <CardDescription>Visitor → signup this period.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <RadialProgress
              value={4.2}
              size={180}
              color="var(--success)"
              label="of visitors"
              sublabel="goal: 5.0%"
            />
            <div className="mt-4 w-full grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-border bg-muted/30 px-3 py-2">
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <TrendingUp className="h-3 w-3 text-[color:var(--success)]" />
                  Signups
                </div>
                <p className="text-sm font-semibold tabular-nums mt-0.5">3,548</p>
              </div>
              <div className="rounded-lg border border-border bg-muted/30 px-3 py-2">
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <TrendingDown className="h-3 w-3 text-[color:var(--warning)]" />
                  Drop-off
                </div>
                <p className="text-sm font-semibold tabular-nums mt-0.5">81,244</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
