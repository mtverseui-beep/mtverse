"use client";

import * as React from "react";
import {
  Bell,
  Mail,
  MessageSquare,
  AtSign,
  GitPullRequest,
  AlertTriangle,
  Calendar,
  Zap,
  Shield,
  Smartphone,
  Clock,
  Moon,
  Volume2,
  CheckCircle2,
  Save,
  RotateCcw,
  Inbox,
  Filter,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Cat = {
  id: string;
  icon: React.ElementType;
  iconTone: string;
  name: string;
  desc: string;
  email: boolean;
  push: boolean;
  sms: boolean;
};

const toneMap: Record<string, string> = {
  primary: "bg-primary/12 text-primary",
  info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
  success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  danger: "bg-destructive/12 text-destructive",
  violet: "bg-violet-500/12 text-violet-500",
};

const INITIAL_CATS: Cat[] = [
  { id: "mentions", icon: AtSign, iconTone: "primary", name: "Mentions", desc: "When someone @mentions you in any context.", email: true, push: true, sms: false },
  { id: "comments", icon: MessageSquare, iconTone: "info", name: "Comments & replies", desc: "Replies to your tasks, PRs and designs.", email: true, push: true, sms: false },
  { id: "pulls", icon: GitPullRequest, iconTone: "success", name: "Pull request reviews", desc: "When a PR needs your review or is approved.", email: true, push: false, sms: false },
  { id: "incidents", icon: AlertTriangle, iconTone: "danger", name: "Incidents", desc: "Sev-1 and Sev-2 incidents on owned services.", email: true, push: true, sms: true },
  { id: "deploys", icon: Zap, iconTone: "warning", name: "Deployments", desc: "When a deploy starts, succeeds or fails.", email: false, push: true, sms: false },
  { id: "calendar", icon: Calendar, iconTone: "violet", name: "Calendar & meetings", desc: "Meeting reminders and schedule changes.", email: true, push: true, sms: false },
  { id: "security", icon: Shield, iconTone: "danger", name: "Security alerts", desc: "New logins, suspicious activity, password changes.", email: true, push: true, sms: true },
];

type RecentNotif = {
  id: string;
  icon: React.ElementType;
  iconTone: "primary" | "info" | "success" | "warning" | "danger" | "violet";
  title: string;
  preview: string;
  time: string;
  unread: boolean;
  channel: "email" | "push" | "sms";
  avatar?: string;
};

const RECENT: RecentNotif[] = [
  { id: "n1", icon: GitPullRequest, iconTone: "success", title: "PR #2841 approved by Daniel Kim", preview: "“Looks good — ship it. Nice work on the sharding logic.”", time: "4 min ago", unread: true, channel: "push", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&q=80&auto=format&fit=crop" },
  { id: "n2", icon: AlertTriangle, iconTone: "danger", title: "Sev-2 incident declared on webhooks-service", preview: "Elevated 5xx error rate detected by Pulse monitor. Page initiated by on-call rotation.", time: "22 min ago", unread: true, channel: "sms" },
  { id: "n3", icon: AtSign, iconTone: "primary", title: "Priya mentioned you in RFC-014", preview: "“@amara — can you weigh in on the conflict-resolution strategy in §3.2?”", time: "1 hour ago", unread: true, channel: "email", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&q=80&auto=format&fit=crop" },
  { id: "n4", icon: MessageSquare, iconTone: "info", title: "New comment on Atlas Ledger spec", preview: "Marcus replied: “The retroactive adjustment window feels too narrow…”", time: "3 hours ago", unread: false, channel: "email", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&q=80&auto=format&fit=crop" },
  { id: "n5", icon: Zap, iconTone: "warning", title: "Deploy succeeded: falcon-runtime@v2.8.0", preview: "Promoted to production in 4m 12s. 14 PoPs updated, 0 errors.", time: "5 hours ago", unread: false, channel: "push" },
  { id: "n6", icon: Calendar, iconTone: "violet", title: "Meeting reminder: Platform sync in 15 minutes", preview: "Engineering all-hands, Conference Room B / Zoom link in invite.", time: "15 min ago", unread: false, channel: "push" },
  { id: "n7", icon: Shield, iconTone: "danger", title: "New sign-in from MacBook Pro · San Francisco", preview: "If this was you, no action is needed. Otherwise, secure your account.", time: "Yesterday", unread: false, channel: "email" },
];

const channelTone: Record<RecentNotif["channel"], "primary" | "info" | "warning"> = {
  email: "info",
  push: "primary",
  sms: "warning",
};

export default function NotificationsPage() {
  const [cats, setCats] = React.useState<Cat[]>(INITIAL_CATS);
  const [savedCats, setSavedCats] = React.useState<Cat[]>(INITIAL_CATS);
  const [digest, setDigest] = React.useState("daily");
  const [savedDigest, setSavedDigest] = React.useState("daily");
  const [quietStart, setQuietStart] = React.useState("22:00");
  const [quietEnd, setQuietEnd] = React.useState("08:00");
  const [quietEnabled, setQuietEnabled] = React.useState(true);
  const [volume, setVolume] = React.useState(70);
  const [saving, setSaving] = React.useState(false);
  const [filter, setFilter] = React.useState("all");

  const toggle = (id: string, channel: "email" | "push" | "sms") =>
    setCats((prev) => prev.map((c) => (c.id === id ? { ...c, [channel]: !c[channel] } : c)));

  const isDirty = JSON.stringify(cats) !== JSON.stringify(savedCats) || digest !== savedDigest;

  const save = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSavedCats(cats);
      setSavedDigest(digest);
      toast.success("Notification preferences saved", {
        description: "Changes apply to all new events going forward.",
      });
    }, 800);
  };

  const reset = () => {
    setCats(savedCats);
    setDigest(savedDigest);
    toast.message("Reverted to last saved preferences");
  };

  const filtered = filter === "all" ? RECENT : filter === "unread" ? RECENT.filter((r) => r.unread) : RECENT.filter((r) => r.channel === filter);

  return (
    <>
      <PageHeader
        title="Notifications"
        description="Fine-tune what reaches your inbox, lock screen, and SMS — and when to be left alone."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Account" }, { label: "Notifications" }]}
        icon={Bell}
        actions={
          <div className="flex items-center gap-2">
            {isDirty ? (
              <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/40 text-amber-600 bg-amber-500/5">
                <AlertTriangle className="h-3 w-3" /> Unsaved changes
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[10px] gap-1 border-emerald-500/40 text-emerald-600 bg-emerald-500/5">
                <CheckCircle2 className="h-3 w-3" /> All saved
              </Badge>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* LEFT — preferences (2 cols) */}
        <div className="xl:col-span-2 space-y-6">
          {/* Per-category preferences */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Inbox className="h-4 w-4 text-primary" /> Notification categories
              </CardTitle>
              <CardDescription>Choose which channels receive each type of event.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {/* Header row */}
              <div className="hidden sm:grid grid-cols-[1fr_64px_64px_64px] gap-2 px-4 pb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                <span>Category</span>
                <span className="text-center flex items-center justify-center gap-1"><Mail className="h-3 w-3" /> Email</span>
                <span className="text-center flex items-center justify-center gap-1"><Bell className="h-3 w-3" /> Push</span>
                <span className="text-center flex items-center justify-center gap-1"><Smartphone className="h-3 w-3" /> SMS</span>
              </div>
              <div className="divide-y divide-border">
                {cats.map((c) => (
                  <div key={c.id} className="grid grid-cols-1 sm:grid-cols-[1fr_64px_64px_64px] gap-2 px-4 py-3 hover:bg-muted/30 transition-colors items-center">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", toneMap[c.iconTone])}>
                        <c.icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{c.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{c.desc}</p>
                      </div>
                    </div>
                    <div className="grid place-items-center"><Switch checked={c.email} onCheckedChange={() => toggle(c.id, "email")} /></div>
                    <div className="grid place-items-center"><Switch checked={c.push} onCheckedChange={() => toggle(c.id, "push")} /></div>
                    <div className="grid place-items-center"><Switch checked={c.sms} onCheckedChange={() => toggle(c.id, "sms")} /></div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Email digest + quiet hours */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Mail className="h-4 w-4 text-primary" /> Email digest
                </CardTitle>
                <CardDescription>Batch non-urgent emails into a single digest.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-1.5">
                  <Label className="text-xs">Frequency</Label>
                  <Select value={digest} onValueChange={setDigest}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="realtime">Realtime — send as they happen</SelectItem>
                      <SelectItem value="hourly">Hourly digest</SelectItem>
                      <SelectItem value="daily">Daily digest · 8:00 AM</SelectItem>
                      <SelectItem value="weekly">Weekly digest · Mondays</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground flex items-start gap-2">
                  <Clock className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <p>Urgent notifications (incidents, security) bypass the digest and arrive immediately.</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Moon className="h-4 w-4 text-primary" /> Quiet hours
                </CardTitle>
                <CardDescription>Mute non-urgent notifications during your focus or sleep windows.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Enable quiet hours</p>
                    <p className="text-xs text-muted-foreground">Mutes push and email digests.</p>
                  </div>
                  <Switch checked={quietEnabled} onCheckedChange={setQuietEnabled} />
                </div>
                <Separator />
                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Starts</Label>
                    <input
                      type="time"
                      value={quietStart}
                      onChange={(e) => setQuietStart(e.target.value)}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm font-mono"
                    />
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Ends</Label>
                    <input
                      type="time"
                      value={quietEnd}
                      onChange={(e) => setQuietEnd(e.target.value)}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm font-mono"
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Active daily from <span className="font-mono text-foreground">{quietStart}</span> to <span className="font-mono text-foreground">{quietEnd}</span>.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Mobile push + volume */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Smartphone className="h-4 w-4 text-primary" /> Mobile push
              </CardTitle>
              <CardDescription>How push notifications behave on your devices.</CardDescription>
            </CardHeader>
            <CardContent className="grid sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium">Lock-screen previews</p>
                    <p className="text-xs text-muted-foreground">Show message content on the lock screen.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <Separator />
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium">Badge count</p>
                    <p className="text-xs text-muted-foreground">Show unread count on the app icon.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <Separator />
                <div className="flex items-center justify-between py-2">
                  <div>
                    <p className="text-sm font-medium">Do not disturb override</p>
                    <p className="text-xs text-muted-foreground">Honor the system DND setting.</p>
                  </div>
                  <Switch />
                </div>
              </div>
              <div className="space-y-3">
                <Label className="text-xs flex items-center gap-1.5">
                  <Volume2 className="h-3.5 w-3.5 text-muted-foreground" /> Notification volume — {volume}%
                </Label>
                <Slider value={[volume]} onValueChange={(v) => setVolume(v[0])} min={0} max={100} step={5} />
                <div className="flex justify-between text-[10px] text-muted-foreground">
                  <span>Mute</span><span>Max</span>
                </div>
                <div className="rounded-lg border border-border p-3 bg-muted/30 text-xs text-muted-foreground">
                  Plays a soft chime at {volume}% volume for push notifications during non-quiet hours.
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sticky save bar */}
          <div className="sticky bottom-4 z-10">
            <Card className={cn(
              "px-4 py-3 flex items-center justify-between gap-3 transition-all",
              isDirty ? "border-primary/40 bg-card/95 backdrop-blur shadow-premium-md" : "opacity-60"
            )}>
              <div className="flex items-center gap-2 min-w-0">
                {isDirty ? (
                  <><AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" /><span className="text-sm text-muted-foreground truncate">You have unsaved changes.</span></>
                ) : (
                  <><CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" /><span className="text-sm text-muted-foreground">All preferences saved.</span></>
                )}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Button variant="outline" size="sm" className="gap-1.5" disabled={!isDirty || saving} onClick={reset}>
                  <RotateCcw className="h-3.5 w-3.5" /> Reset
                </Button>
                <Button size="sm" className="gap-1.5" disabled={!isDirty || saving} onClick={save}>
                  {saving ? <RotateCcw className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                  {saving ? "Saving…" : "Save preferences"}
                </Button>
              </div>
            </Card>
          </div>
        </div>

        {/* RIGHT — recent notifications (1 col) */}
        <div className="xl:col-span-1">
          <Card className="xl:sticky xl:top-4">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Bell className="h-4 w-4 text-primary" /> Recent
                </CardTitle>
                <Badge variant="outline" className="text-[10px]">{RECENT.filter((r) => r.unread).length} new</Badge>
              </div>
              <Tabs value={filter} onValueChange={setFilter}>
                <TabsList className="grid grid-cols-4 h-8 w-full">
                  <TabsTrigger value="all" className="text-[10px]">All</TabsTrigger>
                  <TabsTrigger value="unread" className="text-[10px]">Unread</TabsTrigger>
                  <TabsTrigger value="email" className="text-[10px]">Email</TabsTrigger>
                  <TabsTrigger value="push" className="text-[10px]">Push</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-[640px] overflow-y-auto divide-y divide-border">
                {filtered.length === 0 ? (
                  <div className="p-8 text-center">
                    <Filter className="h-8 w-8 mx-auto text-muted-foreground/50 mb-2" />
                    <p className="text-xs text-muted-foreground">No notifications match this filter.</p>
                  </div>
                ) : (
                  filtered.map((n) => (
                    <div key={n.id} className={cn("p-3 hover:bg-muted/30 transition-colors cursor-pointer", n.unread && "bg-primary/[0.025]")}>
                      <div className="flex gap-2.5">
                        {n.avatar ? (
                          <Avatar className="h-8 w-8 shrink-0">
                            <AvatarImage src={n.avatar} alt="" />
                            <AvatarFallback>U</AvatarFallback>
                          </Avatar>
                        ) : (
                          <div className={cn("grid place-items-center h-8 w-8 rounded-lg shrink-0", toneMap[n.iconTone])}>
                            <n.icon className="h-4 w-4" />
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-xs font-semibold leading-snug truncate">{n.title}</p>
                            {n.unread && <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0 mt-1.5" />}
                          </div>
                          <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{n.preview}</p>
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className="text-[10px] text-muted-foreground">{n.time}</span>
                            <span className="text-[10px] text-muted-foreground">·</span>
                            <StatusBadge tone={channelTone[n.channel]} className="text-[9px] px-1.5 py-0">{n.channel}</StatusBadge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="p-2 border-t border-border">
                <Button variant="ghost" size="sm" className="w-full text-xs">Mark all as read</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <label className={cn("text-xs font-medium text-foreground", className)}>{children}</label>;
}
