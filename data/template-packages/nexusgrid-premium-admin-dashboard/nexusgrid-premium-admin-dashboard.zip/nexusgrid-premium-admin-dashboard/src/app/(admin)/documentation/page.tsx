"use client";

import * as React from "react";
import {
  BookOpen,
  Search,
  ChevronRight,
  ChevronLeft,
  FileText,
  Rocket,
  Download,
  Settings,
  Boxes,
  Code,
  Upload,
  HelpCircle,
  Clock,
  Eye,
  Lightbulb,
  Check,
  Copy,
  Terminal,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type DocItem = { id: string; label: string; };
type DocSection = {
  id: string;
  label: string;
  icon: React.ElementType;
  items: DocItem[];
};

const SECTIONS: DocSection[] = [
  {
    id: "introduction",
    label: "Introduction",
    icon: FileText,
    items: [
      { id: "overview", label: "Overview" },
      { id: "philosophy", label: "Design philosophy" },
      { id: "key-concepts", label: "Key concepts" },
    ],
  },
  {
    id: "getting-started",
    label: "Getting Started",
    icon: Rocket,
    items: [
      { id: "sign-up", label: "Sign up & onboarding" },
      { id: "first-project", label: "Create your first project" },
      { id: "invite-team", label: "Invite your team" },
    ],
  },
  {
    id: "installation",
    label: "Installation",
    icon: Download,
    items: [
      { id: "system-reqs", label: "System requirements" },
      { id: "cli", label: "CLI installation" },
      { id: "self-host", label: "Self-hosting" },
    ],
  },
  {
    id: "configuration",
    label: "Configuration",
    icon: Settings,
    items: [
      { id: "env-vars", label: "Environment variables" },
      { id: "workspaces", label: "Workspace settings" },
      { id: "roles", label: "Roles & permissions" },
    ],
  },
  {
    id: "components",
    label: "Components",
    icon: Boxes,
    items: [
      { id: "projects", label: "Projects" },
      { id: "tasks", label: "Tasks & subtasks" },
      { id: "dashboards", label: "Dashboards" },
      { id: "automations", label: "Automations" },
    ],
  },
  {
    id: "api-reference",
    label: "API Reference",
    icon: Code,
    items: [
      { id: "auth", label: "Authentication" },
      { id: "endpoints", label: "Endpoints" },
      { id: "webhooks", label: "Webhooks" },
      { id: "rate-limits", label: "Rate limits" },
    ],
  },
  {
    id: "deployment",
    label: "Deployment",
    icon: Upload,
    items: [
      { id: "production", label: "Production checklist" },
      { id: "scaling", label: "Scaling strategies" },
      { id: "monitoring", label: "Monitoring & alerts" },
    ],
  },
  {
    id: "faq",
    label: "FAQ",
    icon: HelpCircle,
    items: [
      { id: "common-issues", label: "Common issues" },
      { id: "troubleshooting", label: "Troubleshooting" },
    ],
  },
];

const TOC = [
  { id: "overview", label: "Overview" },
  { id: "philosophy", label: "Design philosophy" },
  { id: "key-concepts", label: "Key concepts" },
  { id: "next-steps", label: "Next steps" },
];

export default function DocumentationPage() {
  const [activeSection, setActiveSection] = React.useState("introduction");
  const [activeDoc, setActiveDoc] = React.useState("overview");
  const [expanded, setExpanded] = React.useState<Set<string>>(new Set(["introduction"]));

  const toggleSection = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <>
      <PageHeader
        title="Documentation"
        description="Everything you need to build, deploy, and master NexusGrid — from quickstarts to deep API reference."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Documentation" }]}
        icon={BookOpen}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Opening GitHub discussions")}>
              <HelpCircle className="h-3.5 w-3.5" /> Get help
            </Button>
            <Button size="sm" className="gap-1.5">
              <Code className="h-3.5 w-3.5" /> API reference
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr_220px] gap-6">
        {/* SIDEBAR NAV */}
        <aside className="lg:sticky lg:top-4 lg:self-start lg:max-h-[calc(100vh-2rem)] lg:overflow-y-auto">
          <div className="relative mb-3 lg:hidden">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search docs..." className="pl-9 h-9" />
          </div>
          <Card className="hidden lg:block">
            <CardContent className="p-3">
              <div className="relative mb-3">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input placeholder="Search docs..." className="pl-8 h-8 text-xs" />
              </div>
              <nav className="space-y-0.5">
                {SECTIONS.map((s) => (
                  <div key={s.id}>
                    <button
                      type="button"
                      onClick={() => toggleSection(s.id)}
                      className={cn(
                        "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm font-medium transition-colors text-left",
                        activeSection === s.id ? "bg-primary/10 text-primary" : "hover:bg-muted/60 text-foreground/80"
                      )}
                    >
                      <s.icon className="h-4 w-4 shrink-0" />
                      <span className="flex-1">{s.label}</span>
                      <ChevronRight className={cn("h-3.5 w-3.5 text-muted-foreground transition-transform", expanded.has(s.id) && "rotate-90")} />
                    </button>
                    {expanded.has(s.id) && (
                      <ul className="ml-6 mt-0.5 space-y-0.5 border-l border-border pl-2">
                        {s.items.map((item) => (
                          <li key={item.id}>
                            <button
                              type="button"
                              onClick={() => { setActiveSection(s.id); setActiveDoc(item.id); }}
                              className={cn(
                                "w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs transition-colors text-left",
                                activeDoc === item.id ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"
                              )}
                            >
                              {activeDoc === item.id && <span className="absolute -ml-[14px] h-3.5 w-0.5 rounded-full bg-primary" />}
                              {item.label}
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </nav>
            </CardContent>
          </Card>
        </aside>

        {/* MAIN CONTENT */}
        <main className="min-w-0">
          {/* Mobile search */}
          <Card className="mb-4 lg:hidden">
            <CardContent className="p-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search documentation..." className="pl-9 h-9" />
              </div>
            </CardContent>
          </Card>

          <article className="prose prose-sm max-w-none">
            {/* Doc header */}
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-3">
              <FileText className="h-3.5 w-3.5" />
              <span>Introduction</span>
              <ChevronRight className="h-3 w-3" />
              <span className="text-foreground font-medium">Overview</span>
            </div>

            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-semibold tracking-tight">Overview</h1>
              <Badge variant="outline" className="text-[10px] gap-1">
                <Clock className="h-2.5 w-2.5" /> 5 min read
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-2">Updated June 28, 2026 · by Marcus Lee</p>

            <Separator className="my-6" />

            <p className="text-[15px] leading-relaxed text-foreground/90 mb-6">
              <strong>NexusGrid</strong> is a unified workspace for project management, CRM, and analytics. It brings together
              tasks, contacts, dashboards, and automations in a single, fast interface — built for teams that want the power of
              a dozen point tools without the integration overhead. This guide walks you through everything from your first
              project to building production-grade automations on our API.
            </p>

            <section id="overview" className="scroll-mt-20 mb-8">
              <h2 className="text-xl font-semibold tracking-tight mb-3 flex items-center gap-2">
                <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-xs font-bold">1</span>
                What is NexusGrid?
              </h2>
              <p className="text-[15px] leading-relaxed text-foreground/90 mb-3">
                At its core, NexusGrid is a relational database with a polished UI on top. Every record can have custom fields,
                relationships to other records, and trigger automations. You can build anything from a simple todo list to a
                multi-team OKR tracker using the same primitives.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
                {[
                  { icon: Boxes, title: "Records", desc: "Structured data with custom fields" },
                  { icon: Settings, title: "Views", desc: "Table, Kanban, calendar, timeline" },
                  { icon: Code, title: "Automations", desc: "Triggers, actions, and conditions" },
                ].map((f) => (
                  <div key={f.title} className="rounded-lg border border-border bg-muted/30 p-3">
                    <f.icon className="h-4 w-4 text-primary mb-2" />
                    <p className="text-sm font-medium">{f.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{f.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            <section id="philosophy" className="scroll-mt-20 mb-8">
              <h2 className="text-xl font-semibold tracking-tight mb-3 flex items-center gap-2">
                <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-xs font-bold">2</span>
                Design philosophy
              </h2>
              <p className="text-[15px] leading-relaxed text-foreground/90 mb-3">
                NexusGrid is built around three principles:
              </p>
              <ul className="space-y-2 my-4">
                {[
                  "Speed first — every interaction should respond in under 100ms.",
                  "Composable — features build on each other, never duplicate.",
                  "Observable — every action is logged, queryable, and reversible.",
                ].map((p) => (
                  <li key={p} className="flex items-start gap-2 text-[15px] text-foreground/90">
                    <Check className="h-4 w-4 text-[color:var(--success)] shrink-0 mt-1" /> {p}
                  </li>
                ))}
              </ul>
            </section>

            <section id="key-concepts" className="scroll-mt-20 mb-8">
              <h2 className="text-xl font-semibold tracking-tight mb-3 flex items-center gap-2">
                <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-xs font-bold">3</span>
                Key concepts
              </h2>
              <p className="text-[15px] leading-relaxed text-foreground/90 mb-4">
                Before you build anything, understand these five building blocks. Every feature in NexusGrid is a combination of them.
              </p>

              <div className="rounded-lg border border-border overflow-hidden my-4">
                <div className="px-4 py-2.5 border-b border-border bg-muted/40 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Core terminology
                </div>
                <table className="w-full text-sm">
                  <tbody className="divide-y divide-border">
                    {[
                      ["Workspace", "Top-level container for your organization. Holds members, billing, and settings."],
                      ["Project", "A collection of records inside a workspace. Where day-to-day work happens."],
                      ["Record", "A single item in a project — a task, contact, deal, or anything you track."],
                      ["Field", "A column on a record. Text, number, date, dropdown, formula, or relation."],
                      ["View", "A lens on a project — table, Kanban, calendar, gallery, or Gantt."],
                    ].map(([term, def]) => (
                      <tr key={term}>
                        <td className="px-4 py-2.5 font-medium align-top whitespace-nowrap">{term}</td>
                        <td className="px-4 py-2.5 text-muted-foreground">{def}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section id="quickstart" className="scroll-mt-20 mb-8">
              <h2 className="text-xl font-semibold tracking-tight mb-3 flex items-center gap-2">
                <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-xs font-bold">4</span>
                Quickstart: create your first project
              </h2>
              <p className="text-[15px] leading-relaxed text-foreground/90 mb-3">
                The fastest way to learn NexusGrid is to use it. Open your terminal and run:
              </p>
              <div className="rounded-lg bg-zinc-950 text-zinc-100 p-4 my-3 relative group">
                <div className="flex items-center gap-1.5 mb-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-green-500/70" />
                  <span className="ml-2 text-[11px] text-zinc-400 flex items-center gap-1"><Terminal className="h-3 w-3" /> bash</span>
                  <button
                    onClick={() => { navigator.clipboard?.writeText("npx nexusgrid create my-project"); toast.success("Copied to clipboard"); }}
                    className="ml-auto text-zinc-400 hover:text-zinc-100 transition-colors"
                    aria-label="Copy"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                </div>
                <pre className="text-[13px] font-mono overflow-x-auto"><code><span className="text-zinc-500">$</span> npx nexusgrid create my-project<span className="text-zinc-500">
{"{"} 
  </span><span className="text-emerald-400">"template"</span><span className="text-zinc-500">:</span> <span className="text-emerald-400">"kanban"</span><span className="text-zinc-500">,
  </span><span className="text-emerald-400">"name"</span><span className="text-zinc-500">:</span> <span className="text-emerald-400">"My First Project"</span>
<span className="text-zinc-500">{"}"}</span></code></pre>
              </div>
              <p className="text-[15px] leading-relaxed text-foreground/90">
                The CLI will scaffold a new project, open it in your browser, and walk you through inviting your first teammates.
                For a no-code approach, use the in-app New Project wizard at <code className="px-1 py-0.5 rounded bg-muted text-foreground text-[13px]">Projects → New</code>.
              </p>
            </section>

            <section id="next-steps" className="scroll-mt-20 mb-8">
              <h2 className="text-xl font-semibold tracking-tight mb-3 flex items-center gap-2">
                <span className="grid place-items-center h-6 w-6 rounded-md bg-primary/10 text-primary text-xs font-bold">5</span>
                Next steps
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4">
                {[
                  { title: "Create your first project", desc: "Hands-on walkthrough of the project builder." },
                  { title: "Invite your team", desc: "Add members, set roles, manage permissions." },
                  { title: "Build a dashboard", desc: "Visualize your data with widgets and filters." },
                  { title: "Automate with workflows", desc: "Trigger actions when records change." },
                ].map((c) => (
                  <a key={c.title} href="#" className="group rounded-lg border border-border p-3 hover:border-primary/40 hover:bg-primary/[0.03] transition-all">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium group-hover:text-primary transition-colors">{c.title}</p>
                      <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all" />
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{c.desc}</p>
                  </a>
                ))}
              </div>
            </section>

            {/* Footer nav */}
            <Separator className="my-6" />
            <div className="flex items-center justify-between gap-3">
              <a href="#" className="group flex items-center gap-3 rounded-lg border border-border p-3 hover:border-primary/40 transition-all flex-1 min-w-0">
                <ChevronLeft className="h-4 w-4 text-muted-foreground group-hover:text-primary shrink-0" />
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">Previous</p>
                  <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">Welcome</p>
                </div>
              </a>
              <a href="#" className="group flex items-center gap-3 rounded-lg border border-border p-3 hover:border-primary/40 transition-all flex-1 min-w-0 text-right justify-end">
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">Next</p>
                  <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">Sign up & onboarding</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary shrink-0" />
              </a>
            </div>

            <div className="mt-6 rounded-lg bg-primary/[0.04] border border-primary/15 p-4 flex items-start gap-3">
              <div className="grid place-items-center h-7 w-7 rounded-md bg-primary/12 text-primary shrink-0">
                <Lightbulb className="h-3.5 w-3.5" />
              </div>
              <div className="text-sm">
                <p className="font-medium mb-0.5">Was this page helpful?</p>
                <div className="flex items-center gap-2 mt-1.5">
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Thanks for the feedback!")}>
                    <Check className="h-3 w-3" /> Yes
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => toast.message("Tell us how to improve")}>No</Button>
                  <span className="text-[11px] text-muted-foreground flex items-center gap-1 ml-1">
                    <Eye className="h-3 w-3" /> 8,420 views this month
                  </span>
                </div>
              </div>
            </div>
          </article>
        </main>

        {/* TOC */}
        <aside className="hidden lg:block lg:sticky lg:top-4 lg:self-start">
          <Card>
            <CardContent className="p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-1.5">On this page</p>
              <nav className="space-y-0.5">
                {TOC.map((t) => (
                  <a
                    key={t.id}
                    href={`#${t.id}`}
                    className="block px-2.5 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
                  >
                    {t.label}
                  </a>
                ))}
              </nav>
              <Separator className="my-3" />
              <div className="px-2.5 py-1.5">
                <p className="text-[11px] text-muted-foreground mb-1.5">Edit this page</p>
                <Button variant="outline" size="sm" className="w-full h-7 text-xs gap-1">
                  <FileText className="h-3 w-3" /> Edit on GitHub
                </Button>
              </div>
            </CardContent>
          </Card>
        </aside>
      </div>
    </>
  );
}
