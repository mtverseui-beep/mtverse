"use client";

import * as React from "react";
import {
  Folder,
  FolderOpen,
  FileText,
  Image as ImageIcon,
  FileSpreadsheet,
  FileWarning,
  FileArchive,
  FileVideo,
  Upload,
  Download,
  MoreHorizontal,
  Eye,
  Pencil,
  Share2,
  Trash2,
  Copy,
  Star,
  Search,
  ChevronRight,
  Home,
  HardDrive,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type FileKind = "folder" | "doc" | "image" | "spreadsheet" | "pdf" | "archive" | "video";

type FileItem = {
  id: string;
  name: string;
  kind: FileKind;
  size: number; // MB (0 for folders)
  sizeLabel: string;
  ownerId: string;
  owner: string;
  ownerAvatar: string;
  modified: string;
  modifiedAgo: string;
  starred: boolean;
  sharedWith: { name: string; avatar: string }[];
  parent: string; // folder path
};

const team = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop" },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop" },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop" },
];

const kindMeta: Record<FileKind, { icon: LucideIcon; color: string; label: string }> = {
  folder: { icon: Folder, color: "var(--primary)", label: "Folder" },
  doc: { icon: FileText, color: "var(--info)", label: "Document" },
  image: { icon: ImageIcon, color: "oklch(0.70 0.15 75)", label: "Image" },
  spreadsheet: { icon: FileSpreadsheet, color: "var(--success)", label: "Spreadsheet" },
  pdf: { icon: FileWarning, color: "var(--destructive)", label: "PDF" },
  archive: { icon: FileArchive, color: "oklch(0.62 0.18 305)", label: "Archive" },
  video: { icon: FileVideo, color: "oklch(0.62 0.18 25)", label: "Video" },
};

const files: FileItem[] = [
  // Folders (current path: Atlas Mobile Redesign)
  { id: "F-001", name: "Design Assets", kind: "folder", size: 0, sizeLabel: "—", ownerId: "u5", owner: team[4].name, ownerAvatar: team[4].avatar, modified: "Jul 05, 2026", modifiedAgo: "1d ago", starred: true, sharedWith: [team[0], team[1]], parent: "Atlas Mobile Redesign" },
  { id: "F-002", name: "Engineering Specs", kind: "folder", size: 0, sizeLabel: "—", ownerId: "u1", owner: team[0].name, ownerAvatar: team[0].avatar, modified: "Jul 04, 2026", modifiedAgo: "2d ago", starred: false, sharedWith: [team[1], team[2]], parent: "Atlas Mobile Redesign" },
  { id: "F-003", name: "Client Approvals", kind: "folder", size: 0, sizeLabel: "—", ownerId: "u1", owner: team[0].name, ownerAvatar: team[0].avatar, modified: "Jun 28, 2026", modifiedAgo: "8d ago", starred: false, sharedWith: [team[2], team[3], team[4]], parent: "Atlas Mobile Redesign" },

  // Files
  { id: "FL-101", name: "Atlas-Redesign-Spec-v3.pdf", kind: "pdf", size: 12.4, sizeLabel: "12.4 MB", ownerId: "u1", owner: team[0].name, ownerAvatar: team[0].avatar, modified: "Jul 06, 2026", modifiedAgo: "today", starred: true, sharedWith: [team[2], team[3]], parent: "Atlas Mobile Redesign" },
  { id: "FL-102", name: "Onboarding-Flow-Mocks.fig", kind: "image", size: 28.7, sizeLabel: "28.7 MB", ownerId: "u5", owner: team[4].name, ownerAvatar: team[4].avatar, modified: "Jul 06, 2026", modifiedAgo: "today", starred: false, sharedWith: [team[0]], parent: "Atlas Mobile Redesign" },
  { id: "FL-103", name: "Sprint-24-Plan.xlsx", kind: "spreadsheet", size: 0.8, sizeLabel: "820 KB", ownerId: "u1", owner: team[0].name, ownerAvatar: team[0].avatar, modified: "Jul 05, 2026", modifiedAgo: "1d ago", starred: true, sharedWith: [team[1], team[2], team[3], team[4]], parent: "Atlas Mobile Redesign" },
  { id: "FL-104", name: "Architecture-Decisions.md", kind: "doc", size: 0.04, sizeLabel: "42 KB", ownerId: "u2", owner: team[1].name, ownerAvatar: team[1].avatar, modified: "Jul 04, 2026", modifiedAgo: "2d ago", starred: false, sharedWith: [team[0], team[2]], parent: "Atlas Mobile Redesign" },
  { id: "FL-105", name: "Biometric-Login-Demo.mp4", kind: "video", size: 184.2, sizeLabel: "184.2 MB", ownerId: "u1", owner: team[0].name, ownerAvatar: team[0].avatar, modified: "Jul 03, 2026", modifiedAgo: "3d ago", starred: false, sharedWith: [team[4]], parent: "Atlas Mobile Redesign" },
  { id: "FL-106", name: "Design-Tokens.zip", kind: "archive", size: 6.8, sizeLabel: "6.8 MB", ownerId: "u5", owner: team[4].name, ownerAvatar: team[4].avatar, modified: "Jul 02, 2026", modifiedAgo: "4d ago", starred: false, sharedWith: [team[0], team[1]], parent: "Atlas Mobile Redesign" },
  { id: "FL-107", name: "Beta-Release-Notes.docx", kind: "doc", size: 0.18, sizeLabel: "180 KB", ownerId: "u1", owner: team[0].name, ownerAvatar: team[0].avatar, modified: "Jul 01, 2026", modifiedAgo: "5d ago", starred: true, sharedWith: [team[2], team[3]], parent: "Atlas Mobile Redesign" },
  { id: "FL-108", name: "QA-Checklist-v2.pdf", kind: "pdf", size: 2.1, sizeLabel: "2.1 MB", ownerId: "u3", owner: team[2].name, ownerAvatar: team[2].avatar, modified: "Jun 30, 2026", modifiedAgo: "6d ago", starred: false, sharedWith: [team[0], team[1], team[4]], parent: "Atlas Mobile Redesign" },
  { id: "FL-109", name: "App-Icon-Assets.png", kind: "image", size: 4.6, sizeLabel: "4.6 MB", ownerId: "u5", owner: team[4].name, ownerAvatar: team[4].avatar, modified: "Jun 28, 2026", modifiedAgo: "8d ago", starred: false, sharedWith: [team[0]], parent: "Atlas Mobile Redesign" },
  { id: "FL-110", name: "Budget-Tracker-Q3.xlsx", kind: "spreadsheet", size: 1.4, sizeLabel: "1.4 MB", ownerId: "u3", owner: team[2].name, ownerAvatar: team[2].avatar, modified: "Jun 26, 2026", modifiedAgo: "10d ago", starred: false, sharedWith: [team[0], team[3]], parent: "Atlas Mobile Redesign" },
];

const storageByType = [
  { type: "Documents", size: 1.8, color: "var(--info)", icon: FileText, pct: 18 },
  { type: "Images", size: 2.6, color: "oklch(0.70 0.15 75)", icon: ImageIcon, pct: 26 },
  { type: "Videos", size: 3.2, color: "oklch(0.62 0.18 25)", icon: FileVideo, pct: 32 },
  { type: "Archives", size: 1.4, color: "oklch(0.62 0.18 305)", icon: FileArchive, pct: 14 },
  { type: "Other", size: 1.0, color: "var(--success)", icon: FileSpreadsheet, pct: 10 },
];

const STORAGE_TOTAL = 100; // GB
const STORAGE_USED = 10.0; // GB (sum of storageByType sizes)

/* ---------- Page ---------- */

export default function FilesPage() {
  const [view, setView] = React.useState<"grid" | "list">("grid");
  const [search, setSearch] = React.useState("");

  const filtered = React.useMemo(() => {
    if (!search.trim()) return files;
    const q = search.toLowerCase();
    return files.filter((f) => f.name.toLowerCase().includes(q) || f.id.toLowerCase().includes(q) || f.owner.toLowerCase().includes(q));
  }, [search]);

  const foldersFirst = React.useMemo(() => {
    return [...filtered].sort((a, b) => {
      if (a.kind === "folder" && b.kind !== "folder") return -1;
      if (a.kind !== "folder" && b.kind === "folder") return 1;
      return a.name.localeCompare(b.name);
    });
  }, [filtered]);

  const columns: Column<FileItem>[] = React.useMemo(() => [
    {
      key: "name",
      header: "Name",
      sortable: true,
      sortAccessor: (r) => r.name,
      cell: (r) => {
        const meta = kindMeta[r.kind];
        const Icon = meta.icon;
        return (
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="grid place-items-center h-8 w-8 rounded-lg shrink-0"
              style={{ background: `color-mix(in srgb, ${meta.color} 12%, transparent)`, color: meta.color }}
            >
              <Icon className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="font-medium text-foreground text-sm truncate">{r.name}</p>
                {r.starred && <Star className="h-3 w-3 text-[color:var(--warning)] fill-[color:var(--warning)] shrink-0" />}
              </div>
              <p className="text-[10px] text-muted-foreground font-mono">{r.id}</p>
            </div>
          </div>
        );
      },
    },
    {
      key: "kind",
      header: "Type",
      sortable: true,
      sortAccessor: (r) => r.kind,
      filterable: true,
      filterAccessor: (r) => r.kind,
      filterOptions: [
        { label: "Folder", value: "folder" },
        { label: "Document", value: "doc" },
        { label: "Image", value: "image" },
        { label: "Spreadsheet", value: "spreadsheet" },
        { label: "PDF", value: "pdf" },
        { label: "Archive", value: "archive" },
        { label: "Video", value: "video" },
      ],
      cell: (r) => {
        const meta = kindMeta[r.kind];
        return (
          <span
            className="inline-flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded-md ring-1 ring-inset"
            style={{
              color: meta.color,
              background: `color-mix(in srgb, ${meta.color} 12%, transparent)`,
              borderColor: `color-mix(in srgb, ${meta.color} 25%, transparent)`,
            }}
          >
            {meta.label}
          </span>
        );
      },
      width: "w-32",
    },
    {
      key: "size",
      header: "Size",
      sortable: true,
      sortAccessor: (r) => r.size,
      align: "right",
      cell: (r) => <span className="font-mono text-xs tabular-nums text-muted-foreground">{r.sizeLabel}</span>,
      width: "w-24",
    },
    {
      key: "owner",
      header: "Owner",
      sortable: true,
      sortAccessor: (r) => r.owner,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-6 w-6">
            <AvatarImage src={r.ownerAvatar} alt={r.owner} />
            <AvatarFallback className="text-[9px]">{r.owner.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
          </Avatar>
          <span className="text-xs text-muted-foreground truncate">{r.owner}</span>
        </div>
      ),
      width: "w-36",
    },
    {
      key: "modified",
      header: "Modified",
      sortable: true,
      sortAccessor: (r) => r.modified,
      cell: (r) => (
        <div className="text-right">
          <p className="font-mono text-xs text-muted-foreground">{r.modified}</p>
          <p className="text-[10px] text-muted-foreground">{r.modifiedAgo}</p>
        </div>
      ),
      width: "w-28",
      align: "right",
    },
    {
      key: "shared",
      header: "Shared With",
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          {r.sharedWith.length > 0 ? (
            <>
              <div className="flex -space-x-1.5">
                {r.sharedWith.slice(0, 3).map((s, i) => (
                  <Avatar key={i} className="h-5 w-5 border-2 border-card">
                    <AvatarImage src={s.avatar} alt={s.name} />
                    <AvatarFallback className="text-[8px]">{s.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                  </Avatar>
                ))}
                {r.sharedWith.length > 3 && (
                  <div className="grid place-items-center h-5 w-5 rounded-full border-2 border-card bg-muted text-[8px] font-semibold">
                    +{r.sharedWith.length - 3}
                  </div>
                )}
              </div>
              <span className="text-[10px] text-muted-foreground">{r.sharedWith.length}</span>
            </>
          ) : (
            <span className="text-[10px] text-muted-foreground/60 italic">Private</span>
          )}
        </div>
      ),
      width: "w-32",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div onClick={(e) => e.stopPropagation()} className="flex items-center justify-end gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success(`Downloading ${r.name}`)}>
            <Download className="h-3.5 w-3.5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="text-xs truncate max-w-[180px]">{r.name}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Previewing ${r.name}`)}>
                <Eye className="h-3.5 w-3.5" /> Preview
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Renaming ${r.name}`)}>
                <Pencil className="h-3.5 w-3.5" /> Rename
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Share link for ${r.name} copied`)}>
                <Share2 className="h-3.5 w-3.5" /> Share link
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Duplicating ${r.name}`)}>
                <Copy className="h-3.5 w-3.5" /> Duplicate
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(r.starred ? "Removed star" : "Starred")}>
                <Star className="h-3.5 w-3.5" /> {r.starred ? "Unstar" : "Star"}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${r.name} moved to trash`)}>
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      width: "w-24",
    },
  ], []);

  const storagePct = Math.round((STORAGE_USED / STORAGE_TOTAL) * 100);

  return (
    <>
      <PageHeader
        title="Project Files"
        description="Manage shared documents, design assets, and deliverables across all engagements."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: "Files" }]}
        icon={Folder}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("All files exported as ZIP")}>
              <Download className="h-3.5 w-3.5" /> Export All
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Upload drawer opened")}>
              <Upload className="h-3.5 w-3.5" /> Upload
            </Button>
          </>
        }
      />

      {/* Storage usage panel + folder breadcrumb row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Storage usage — large card spanning 2 cols */}
        <Card className="lg:col-span-2 overflow-hidden">
          <CardContent className="pt-5">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
                  <HardDrive className="h-3.5 w-3.5" /> Storage Usage
                </p>
                <div className="mt-1.5 flex items-baseline gap-2">
                  <span className="text-2xl font-semibold tabular-nums">{STORAGE_USED.toFixed(1)}</span>
                  <span className="text-sm text-muted-foreground">of {STORAGE_TOTAL} GB</span>
                  <StatusBadge tone={storagePct > 80 ? "danger" : storagePct > 60 ? "warning" : "success"} className="text-[10px]">
                    {storagePct}% used
                  </StatusBadge>
                </div>
              </div>
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast.success("Upgrade plan dialog opened")}>
                <TrendingUp className="h-3.5 w-3.5" /> Upgrade
              </Button>
            </div>

            {/* Stacked storage bar by type */}
            <div className="flex h-3 w-full rounded-full overflow-hidden ring-1 ring-inset ring-border mb-3">
              {storageByType.map((t) => (
                <div
                  key={t.type}
                  className="h-full transition-all hover:brightness-110"
                  style={{ width: `${(t.size / STORAGE_TOTAL) * 100}%`, background: t.color }}
                  title={`${t.type}: ${t.size} GB`}
                />
              ))}
            </div>

            {/* Type breakdown grid */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {storageByType.map((t) => {
                const Icon = t.icon;
                return (
                  <div key={t.type} className="rounded-lg border border-border p-2.5">
                    <div className="flex items-center gap-1.5 mb-1">
                      <div
                        className="grid place-items-center h-5 w-5 rounded shrink-0"
                        style={{ background: `color-mix(in srgb, ${t.color} 14%, transparent)`, color: t.color }}
                      >
                        <Icon className="h-3 w-3" />
                      </div>
                      <span className="text-[10px] font-medium text-muted-foreground truncate">{t.type}</span>
                    </div>
                    <p className="text-sm font-semibold tabular-nums">{t.size} GB</p>
                    <p className="text-[10px] text-muted-foreground tabular-nums">{t.pct}% of total</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Quick actions / recent uploads */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FolderOpen className="h-4 w-4 text-violet-500" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest file changes across the workspace.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[220px] overflow-y-auto pr-1 custom-scroll">
            {files.slice(0, 5).map((f) => {
              const meta = kindMeta[f.kind];
              const Icon = meta.icon;
              return (
                <div key={f.id} className="flex items-center gap-2.5 rounded-md p-2 hover:bg-muted/30 transition-colors cursor-pointer">
                  <div
                    className="grid place-items-center h-7 w-7 rounded shrink-0"
                    style={{ background: `color-mix(in srgb, ${meta.color} 12%, transparent)`, color: meta.color }}
                  >
                    <Icon className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium text-foreground truncate">{f.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{f.owner} · {f.modifiedAgo}</p>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      {/* Folder breadcrumb + view toggle */}
      <div className="mb-4 flex items-center justify-between gap-3 flex-wrap">
        <nav aria-label="Folder path" className="flex items-center gap-1.5 text-sm">
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs gap-1.5 text-muted-foreground" onClick={() => toast.message("Navigating to root")}>
            <Home className="h-3.5 w-3.5" /> Workspace
          </Button>
          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs gap-1.5 text-muted-foreground" onClick={() => toast.message("Navigating to Projects")}>
            <Folder className="h-3.5 w-3.5" /> Projects
          </Button>
          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs gap-1.5 font-semibold text-foreground bg-muted/40">
            <FolderOpen className="h-3.5 w-3.5 text-primary" /> Atlas Mobile Redesign
          </Button>
        </nav>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              placeholder="Search files…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-9 pl-8 w-[200px] text-xs"
            />
          </div>
          <Tabs value={view} onValueChange={(v) => setView(v as typeof view)}>
            <TabsList className="h-9">
              <TabsTrigger value="grid" className="gap-1.5 text-xs">
                <FolderOpen className="h-3.5 w-3.5" /> Grid
              </TabsTrigger>
              <TabsTrigger value="list" className="gap-1.5 text-xs">
                <FileText className="h-3.5 w-3.5" /> List
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* File counts summary strip */}
      <div className="mb-4 flex items-center gap-2 flex-wrap text-xs">
        <StatusBadge tone="primary" dot>
          {files.filter((f) => f.kind === "folder").length} folders
        </StatusBadge>
        <StatusBadge tone="info" dot>
          {files.filter((f) => f.kind !== "folder").length} files
        </StatusBadge>
        <StatusBadge tone="warning" dot>
          {files.filter((f) => f.starred).length} starred
        </StatusBadge>
        <span className="text-muted-foreground ml-auto">
          Total size: <span className="font-mono font-semibold tabular-nums">{(files.reduce((s, f) => s + f.size, 0)).toFixed(1)} MB</span>
        </span>
      </div>

      {/* View body */}
      {view === "grid" ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {/* New folder/upload tile */}
          <button
            onClick={() => toast.success("Upload drawer opened")}
            className="group rounded-xl border-2 border-dashed border-border p-4 flex flex-col items-center justify-center text-center min-h-[140px] hover:border-primary/40 hover:bg-primary/[0.03] transition-all"
          >
            <div className="grid place-items-center h-10 w-10 rounded-lg bg-muted text-muted-foreground group-hover:bg-primary/12 group-hover:text-primary transition-colors mb-2">
              <Upload className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-foreground">Drop files here</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">or click to browse</p>
          </button>

          {foldersFirst.map((f) => {
            const meta = kindMeta[f.kind];
            const Icon = meta.icon;
            return (
              <div
                key={f.id}
                onClick={() => f.kind === "folder" ? toast.message(`Opening folder ${f.name}`) : toast.message(`Previewing ${f.name}`)}
                className="group relative rounded-xl border border-border bg-card p-4 cursor-pointer hover:border-primary/40 hover:shadow-premium-sm transition-all"
              >
                {/* Star + actions */}
                <div className="absolute right-2 top-2 flex items-center gap-0.5">
                  {f.starred && <Star className="h-3 w-3 text-[color:var(--warning)] fill-[color:var(--warning)]" />}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                        <MoreHorizontal className="h-3.5 w-3.5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40" onClick={(e) => e.stopPropagation()}>
                      <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Downloading ${f.name}`)}>
                        <Download className="h-3.5 w-3.5" /> Download
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Share link copied`)}>
                        <Share2 className="h-3.5 w-3.5" /> Share
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Renaming`)}>
                        <Pencil className="h-3.5 w-3.5" /> Rename
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${f.name} moved to trash`)}>
                        <Trash2 className="h-3.5 w-3.5" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Icon */}
                <div
                  className="grid place-items-center h-12 w-12 rounded-lg mb-3"
                  style={{ background: `color-mix(in srgb, ${meta.color} 14%, transparent)`, color: meta.color }}
                >
                  <Icon className="h-6 w-6" />
                </div>

                {/* Name */}
                <p className="text-sm font-medium text-foreground truncate mb-1">{f.name}</p>
                <p className="text-[10px] text-muted-foreground tabular-nums">
                  {f.sizeLabel} · {f.modifiedAgo}
                </p>

                {/* Owner + shared */}
                <div className="mt-2 pt-2 border-t border-border flex items-center justify-between">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={f.ownerAvatar} alt={f.owner} />
                    <AvatarFallback className="text-[8px]">{f.owner.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                  </Avatar>
                  {f.sharedWith.length > 0 && (
                    <div className="flex -space-x-1.5">
                      {f.sharedWith.slice(0, 3).map((s, i) => (
                        <Avatar key={i} className="h-4 w-4 border border-card">
                          <AvatarImage src={s.avatar} alt={s.name} />
                          <AvatarFallback className="text-[7px]">{s.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                        </Avatar>
                      ))}
                      {f.sharedWith.length > 3 && (
                        <div className="grid place-items-center h-4 w-4 rounded-full border border-card bg-muted text-[7px] font-semibold">
                          +{f.sharedWith.length - 3}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <DataTable
          title={`Files — Atlas Mobile Redesign (${filtered.length})`}
          data={foldersFirst}
          columns={columns}
          searchKeys={["name", "id", "owner"]}
          getRowId={(r) => r.id}
          onRowClick={(r) => r.kind === "folder" ? toast.message(`Opening folder ${r.name}`) : toast.message(`Previewing ${r.name}`)}
          enableSelection
          enableExport
          enableDensity
          enableColumnVisibility
          pageSize={12}
          initialSort={{ key: "kind", direction: "asc" }}
          bulkActions={[
            {
              label: "Download",
              icon: Download,
              onClick: (sel) => toast.success(`Downloading ${sel.length} item${sel.length > 1 ? "s" : ""} as ZIP`),
            },
            {
              label: "Share",
              icon: Share2,
              onClick: (sel) => toast.success(`Share link for ${sel.length} item${sel.length > 1 ? "s" : ""} copied`),
            },
            {
              label: "Star",
              icon: Star,
              onClick: (sel) => toast.success(`Starred ${sel.length} item${sel.length > 1 ? "s" : ""}`),
            },
            {
              label: "Delete",
              icon: Trash2,
              onClick: (sel) => toast.error(`Moved ${sel.length} item${sel.length > 1 ? "s" : ""} to trash`),
            },
          ]}
        />
      )}
    </>
  );
}
