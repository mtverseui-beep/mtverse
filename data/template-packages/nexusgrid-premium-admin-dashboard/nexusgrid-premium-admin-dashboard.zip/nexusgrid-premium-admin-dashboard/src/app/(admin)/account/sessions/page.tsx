"use client";

import * as React from "react";
import {
  Monitor,
  Smartphone,
  Tablet,
  Laptop,
  Watch,
  MapPin,
  Clock,
  LogOut,
  Shield,
  CheckCircle2,
  Star,
  Globe,
  Fingerprint,
  Activity,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { DataTable, type Column } from "@/components/tables/data-table";
import { AreaTrendChart } from "@/components/charts";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Session = {
  id: string;
  device: "laptop" | "monitor" | "tablet" | "smartphone" | "watch";
  deviceName: string;
  browser: string;
  os: string;
  location: string;
  ip: string;
  lastActive: string;
  current: boolean;
  trusted: boolean;
};

const deviceIcons = { laptop: Laptop, monitor: Monitor, tablet: Tablet, smartphone: Smartphone, watch: Watch };

const SESSIONS: Session[] = [
  { id: "s1", device: "laptop", deviceName: "MacBook Pro 16\"", browser: "Chrome 126", os: "macOS 14.5 Sonoma", location: "San Francisco, CA, US", ip: "73.158.42.10", lastActive: "Active now", current: true, trusted: true },
  { id: "s2", device: "smartphone", deviceName: "iPhone 15 Pro", browser: "Safari Mobile", os: "iOS 17.5", location: "San Francisco, CA, US", ip: "73.158.42.11", lastActive: "12 min ago", current: false, trusted: true },
  { id: "s3", device: "laptop", deviceName: "ThinkPad X1 Carbon", browser: "Firefox 127", os: "Ubuntu 24.04 LTS", location: "Berlin, DE", ip: "85.214.132.88", lastActive: "3 hours ago", current: false, trusted: true },
  { id: "s4", device: "tablet", deviceName: "iPad Pro 12.9", browser: "Safari", os: "iPadOS 17.5", location: "San Francisco, CA, US", ip: "73.158.42.18", lastActive: "Yesterday, 9:14 PM", current: false, trusted: false },
  { id: "s5", device: "monitor", deviceName: "Office Workstation", browser: "Edge 126", os: "Windows 11 Pro", location: "New York, NY, US", ip: "108.19.44.201", lastActive: "2 days ago", current: false, trusted: false },
  { id: "s6", device: "laptop", deviceName: "MacBook Air", browser: "Safari 17", os: "macOS 14.4", location: "Tokyo, JP", ip: "202.45.171.18", lastActive: "5 days ago", current: false, trusted: false },
  { id: "s7", device: "smartphone", deviceName: "Pixel 8 Pro", browser: "Chrome Mobile", os: "Android 14", location: "San Francisco, CA, US", ip: "73.158.42.22", lastActive: "1 week ago", current: false, trusted: false },
];

const LOGIN_HISTORY = [
  { day: "Mon", logins: 8, failed: 0 },
  { day: "Tue", logins: 12, failed: 1 },
  { day: "Wed", logins: 6, failed: 0 },
  { day: "Thu", logins: 14, failed: 2 },
  { day: "Fri", logins: 9, failed: 0 },
  { day: "Sat", logins: 3, failed: 0 },
  { day: "Sun", logins: 4, failed: 1 },
];

const TRUSTED = [
  { id: "t1", name: "MacBook Pro 16\"", location: "San Francisco, CA", added: "Mar 2022", lastSeen: "Active now", icon: Laptop },
  { id: "t2", name: "iPhone 15 Pro", location: "San Francisco, CA", added: "Sep 2023", lastSeen: "12 min ago", icon: Smartphone },
  { id: "t3", name: "ThinkPad X1 Carbon", location: "Berlin, DE", added: "Jan 2024", lastSeen: "3 hours ago", icon: Laptop },
];

export default function SessionsPage() {
  const otherSessions = SESSIONS.filter((s) => !s.current);

  const columns: Column<Session>[] = [
    {
      key: "device",
      header: "Device",
      sortable: true,
      sortAccessor: (r) => r.deviceName,
      cell: (r) => {
        const Icon = deviceIcons[r.device];
        return (
          <div className="flex items-center gap-3">
            <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", r.current ? "bg-primary/12 text-primary" : "bg-muted text-muted-foreground")}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-medium text-sm truncate">{r.deviceName}</p>
                {r.current && <StatusBadge tone="success" dot>This device</StatusBadge>}
              </div>
              <p className="text-xs text-muted-foreground truncate">{r.browser} · {r.os}</p>
            </div>
          </div>
        );
      },
    },
    {
      key: "location",
      header: "Location",
      sortable: true,
      sortAccessor: (r) => r.location,
      filterable: true,
      filterAccessor: (r) => r.location.split(",")[1].trim(),
      filterOptions: [
        { label: "United States", value: "US" },
        { label: "Germany", value: "DE" },
        { label: "Japan", value: "JP" },
      ],
      cell: (r) => (
        <div className="flex items-center gap-1.5 text-sm">
          <MapPin className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <span>{r.location}</span>
        </div>
      ),
    },
    {
      key: "ip",
      header: "IP address",
      cell: (r) => <span className="font-mono text-xs text-muted-foreground">{r.ip}</span>,
    },
    {
      key: "lastActive",
      header: "Last active",
      sortable: true,
      sortAccessor: (r) => (r.current ? 999 : 0),
      cell: (r) => (
        <span className={cn("text-xs inline-flex items-center gap-1", r.current ? "text-[color:var(--success)] font-medium" : "text-muted-foreground")}>
          <Clock className="h-3 w-3" /> {r.lastActive}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => r.trusted ? <StatusBadge tone="info">Trusted</StatusBadge> : <StatusBadge tone="neutral">Untrusted</StatusBadge>,
    },
    {
      key: "actions",
      header: "",
      align: "right",
      hideable: false,
      cell: (r) =>
        r.current ? (
          <span className="text-xs text-muted-foreground pr-2">Current</span>
        ) : (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="sm" className="text-xs text-destructive hover:text-destructive hover:bg-destructive/10 gap-1">
                <LogOut className="h-3.5 w-3.5" /> Revoke
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Revoke session on {r.deviceName}?</AlertDialogTitle>
                <AlertDialogDescription>
                  The device at {r.location} ({r.ip}) will be signed out immediately. The next sign-in will require full authentication.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => toast.success("Session revoked", { description: `${r.deviceName} signed out.` })}>
                  Revoke
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        ),
    },
  ];

  return (
    <>
      <PageHeader
        title="Sessions"
        description="Every device currently authenticated to your account — and a history of recent sign-ins."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Account" }, { label: "Sessions" }]}
        icon={Monitor}
        actions={
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5" disabled={otherSessions.length === 0}>
                <LogOut className="h-3.5 w-3.5" /> Sign out all others
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Sign out of {otherSessions.length} other session{otherSessions.length > 1 ? "s" : ""}?</AlertDialogTitle>
                <AlertDialogDescription>
                  All other devices will be immediately signed out. Your current session on this MacBook Pro will remain active.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => toast.success(`Signed out of ${otherSessions.length} sessions`)}>
                  Sign out all others
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        }
      />

      {/* SUMMARY STRIP */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { icon: Monitor, tone: "bg-primary/12 text-primary", label: "Active sessions", value: String(SESSIONS.length), hint: `${otherSessions.length} other devices` },
          { icon: Shield, tone: "bg-[color:var(--info)]/12 text-[color:var(--info)]", label: "Trusted devices", value: String(TRUSTED.length), hint: "Skip 2FA on these" },
          { icon: Globe, tone: "bg-violet-500/12 text-violet-500", label: "Countries", value: "3", hint: "US, DE, JP" },
          { icon: Activity, tone: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Sign-ins (7d)", value: "56", hint: "4 failed" },
        ].map((s) => (
          <Card key={s.label} className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("grid place-items-center h-7 w-7 rounded-md", s.tone)}><s.icon className="h-3.5 w-3.5" /></div>
              <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</span>
            </div>
            <p className="text-xl font-semibold tabular-nums leading-tight">{s.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.hint}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* LOGIN HISTORY CHART */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" /> Login activity
                </CardTitle>
                <CardDescription>Successful and failed sign-ins over the last 7 days.</CardDescription>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary" /> Successful</span>
                <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-destructive" /> Failed</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={LOGIN_HISTORY}
              xKey="day"
              series={[
                { key: "logins", name: "Successful", color: "var(--primary)" },
                { key: "failed", name: "Failed", color: "var(--destructive)" },
              ]}
              height={240}
            />
          </CardContent>
        </Card>

        {/* TRUSTED DEVICES */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Fingerprint className="h-4 w-4 text-primary" /> Trusted devices
            </CardTitle>
            <CardDescription>Skip 2FA on devices you mark as trusted.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {TRUSTED.map((t) => (
              <div key={t.id} className="flex items-center gap-3 p-2.5 rounded-lg border border-border hover:bg-muted/30 transition-colors">
                <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)] shrink-0">
                  <t.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <p className="text-sm font-medium truncate">{t.name}</p>
                    <Star className="h-3 w-3 text-[color:var(--warning)] fill-[color:var(--warning)] shrink-0" />
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{t.location} · added {t.added}</p>
                  <p className="text-[11px] text-muted-foreground/80 mt-0.5">Last seen {t.lastSeen}</p>
                </div>
                <Button variant="ghost" size="sm" className="text-xs text-muted-foreground hover:text-destructive shrink-0">Remove</Button>
              </div>
            ))}
            <Separator />
            <div className="flex items-center justify-between pt-1">
              <div className="min-w-0">
                <p className="text-sm font-medium">Trust new devices for 30 days</p>
                <p className="text-xs text-muted-foreground">After successful 2FA, skip on that device.</p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ACTIVE SESSIONS TABLE */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Monitor className="h-4 w-4 text-primary" /> All sessions
          </CardTitle>
          <CardDescription>Manage every authenticated device in real time.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <DataTable
            data={SESSIONS}
            columns={columns}
            pageSize={10}
            searchable
            searchKeys={["deviceName", "browser", "os", "location", "ip"]}
            title="Sessions"
            getRowId={(r) => r.id}
            enableSelection
            bulkActions={[
              { label: "Revoke", icon: LogOut, onClick: (sel) => toast.success(`Revoked ${sel.length} sessions`) },
            ]}
          />
        </CardContent>
      </Card>
    </>
  );
}
