"use client";

import * as React from "react";
import {
  Search as SearchIcon,
  FileText,
  Database,
  Users,
  FileBox,
  ChevronRight,
  ChevronLeft,
  MoreHorizontal,
  Clock,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type ResultType = "page" | "record" | "person" | "file";

type Result = {
  id: string;
  type: ResultType;
  title: string;
  snippet: string;
  url: string;
  breadcrumb: string[];
  meta: string;
  relevance: number;
};

const RESULTS: Result[] = [
  {
    id: "1",
    type: "page",
    title: "Ecommerce Dashboard — Overview",
    snippet: "Real-time sales, orders, inventory, and customer insights across all your storefronts. Track GMV, conversion rate, and average order value in one view, with breakdowns by channel and product category.",
    url: "/dashboards/ecommerce",
    breadcrumb: ["Dashboards", "Ecommerce"],
    meta: "Updated 2 days ago",
    relevance: 98,
  },
  {
    id: "2",
    type: "page",
    title: "Dashboard Customization Guide",
    snippet: "Learn how to add, remove, and rearrange widgets on any dashboard. Drag widgets onto the canvas, connect them to a data source, and share the result with viewers. Includes a list of all 24 available widget types.",
    url: "/documentation#dashboards",
    breadcrumb: ["Documentation", "Components", "Dashboards"],
    meta: "5 min read",
    relevance: 95,
  },
  {
    id: "3",
    type: "record",
    title: "Order #ORD-7821 — Acme Industries",
    snippet: "Order containing 4 line items totaling $1,247.50. Status: shipped, tracking number 1Z999AA10123456784. Placed on Jun 28, 2026 at 2:14 PM EST.",
    url: "/ecommerce/orders/ORD-7821",
    breadcrumb: ["Ecommerce", "Orders", "ORD-7821"],
    meta: "Yesterday at 2:14 PM",
    relevance: 92,
  },
  {
    id: "4",
    type: "person",
    title: "Jordan Avery — Customer Success Manager",
    snippet: "Jordan manages 42 active accounts with a combined ARR of $1.8M. Last contacted 3 days ago. Currently working on renewal for Acme Industries (due Aug 14, 2026).",
    url: "/crm/contacts/jordan-avery",
    breadcrumb: ["CRM", "Contacts", "Jordan Avery"],
    meta: "Active now",
    relevance: 89,
  },
  {
    id: "5",
    type: "page",
    title: "CRM Dashboard — Pipeline & Forecast",
    snippet: "Track deals through every stage of your pipeline with weighted forecasts, win-rate analytics, and rep leaderboards. Filter by owner, segment, or close date.",
    url: "/dashboards/crm",
    breadcrumb: ["Dashboards", "CRM"],
    meta: "Updated 1 hour ago",
    relevance: 86,
  },
  {
    id: "6",
    type: "file",
    title: "Q2-2026-Revenue-Report.pdf",
    snippet: "Q2 financial summary covering all revenue streams, including SaaS subscriptions ($1.24M), professional services ($310K), and partner referrals ($48K). 12 pages, 1.8 MB.",
    url: "/files/q2-2026-revenue-report",
    breadcrumb: ["Files", "Reports", "2026"],
    meta: "Uploaded 4 days ago by Marcus Lee",
    relevance: 84,
  },
  {
    id: "7",
    type: "record",
    title: "Acme Industries — Account Record",
    snippet: "Enterprise customer since March 2024. 142 employees, 8 active projects, ARR $84,000. Renewal date Aug 14, 2026. Health score: 87/100 (Good).",
    url: "/crm/accounts/acme-industries",
    breadcrumb: ["CRM", "Accounts", "Acme Industries"],
    meta: "Updated 3 days ago",
    relevance: 81,
  },
  {
    id: "8",
    type: "page",
    title: "Analytics Dashboard — Traffic & Conversions",
    snippet: "Visitor-to-purchase journey with funnel visualization, traffic source attribution, and real-time user counts. Includes geo analytics and device breakdown.",
    url: "/dashboards/analytics",
    breadcrumb: ["Dashboards", "Analytics"],
    meta: "Updated 12 minutes ago",
    relevance: 78,
  },
  {
    id: "9",
    type: "person",
    title: "Marcus Lee — Engineering Lead",
    snippet: "Marcus owns the dashboard infrastructure team (7 engineers). Currently working on real-time collaboration features. Last commit 2 hours ago on nexusgrid/web#4821.",
    url: "/crm/contacts/marcus-lee",
    breadcrumb: ["CRM", "Contacts", "Marcus Lee"],
    meta: "Active 2 hours ago",
    relevance: 75,
  },
  {
    id: "10",
    type: "file",
    title: "dashboard-widget-sdk-reference.md",
    snippet: "Complete SDK reference for building custom dashboard widgets. Covers the widget lifecycle, data binding API, theming hooks, and event system. Includes 8 code samples in TypeScript.",
    url: "/files/dashboard-widget-sdk-reference",
    breadcrumb: ["Files", "Engineering", "SDK"],
    meta: "Uploaded 2 weeks ago",
    relevance: 71,
  },
];

const TYPE_META: Record<ResultType | "all", { label: string; icon: React.ElementType; tone: string }> = {
  all: { label: "All results", icon: SearchIcon, tone: "primary" },
  page: { label: "Pages", icon: FileText, tone: "primary" },
  record: { label: "Records", icon: Database, tone: "violet" },
  person: { label: "People", icon: Users, tone: "info" },
  file: { label: "Files", icon: FileBox, tone: "warning" },
};

const DATE_FILTERS = [
  { id: "any", label: "Any time" },
  { id: "24h", label: "Past 24 hours" },
  { id: "7d", label: "Past week" },
  { id: "30d", label: "Past month" },
  { id: "year", label: "Past year" },
];

const SOURCE_FILTERS = [
  { id: "nexusgrid", label: "NexusGrid", count: 64 },
  { id: "docs", label: "Documentation", count: 28 },
  { id: "community", label: "Community forum", count: 17 },
  { id: "github", label: "GitHub", count: 9 },
];

export default function SearchResultsPage() {
  const [query, setQuery] = React.useState("dashboard");
  const [type, setType] = React.useState<ResultType | "all">("all");
  const [date, setDate] = React.useState("any");
  const [source, setSource] = React.useState<string[]>(["nexusgrid"]);
  const [page, setPage] = React.useState(1);

  const filtered = React.useMemo(() => {
    return RESULTS.filter((r) => type === "all" || r.type === type);
  }, [type]);

  const typeCounts = React.useMemo(() => {
    const counts: Record<string, number> = { all: RESULTS.length, page: 0, record: 0, person: 0, file: 0 };
    RESULTS.forEach((r) => { counts[r.type] = (counts[r.type] ?? 0) + 1; });
    return counts;
  }, []);

  const toggleSource = (id: string) => {
    setSource((prev) => prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]);
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success(`Searching for "${query}"`, { description: `${filtered.length} results found in 0.18s` });
  };

  return (
    <>
      <PageHeader
        title="Search Results"
        description={`Showing ${filtered.length} results for "${query}" — found in 0.18 seconds.`}
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Search Results" }]}
        icon={SearchIcon}
      />

      {/* SEARCH BAR */}
      <Card className="mb-6">
        <CardContent className="p-3">
          <form onSubmit={onSubmit}>
            <div className="relative">
              <SearchIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-muted-foreground" />
              <Input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search across pages, records, people, and files..."
                className="pl-11 pr-28 h-11"
              />
              <Button type="submit" size="sm" className="absolute right-1.5 top-1/2 -translate-y-1/2 h-8 gap-1.5">
                <SearchIcon className="h-3.5 w-3.5" /> Search
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-6">
        {/* FILTER SIDEBAR */}
        <aside className="lg:sticky lg:top-4 lg:self-start space-y-4">
          <Card>
            <CardContent className="p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-1.5">Type</p>
              <nav className="space-y-0.5">
                {(["all", "page", "record", "person", "file"] as const).map((t) => {
                  const meta = TYPE_META[t];
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => { setType(t); setPage(1); }}
                      className={cn(
                        "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm transition-colors text-left",
                        type === t ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground/80"
                      )}
                    >
                      <meta.icon className="h-4 w-4" />
                      <span className="flex-1">{meta.label}</span>
                      <Badge variant="outline" className="text-[10px] h-4.5">{typeCounts[t]}</Badge>
                    </button>
                  );
                })}
              </nav>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-1.5">Date range</p>
              <div className="space-y-0.5">
                {DATE_FILTERS.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => setDate(d.id)}
                    className={cn(
                      "w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-xs transition-colors text-left",
                      date === d.id ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    <span className={cn(
                      "grid place-items-center h-3.5 w-3.5 rounded-full border",
                      date === d.id ? "border-primary bg-primary text-primary-foreground" : "border-border"
                    )}>
                      {date === d.id && <span className="h-1.5 w-1.5 rounded-full bg-primary-foreground" />}
                    </span>
                    {d.label}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-1.5">Source</p>
              <div className="space-y-0.5">
                {SOURCE_FILTERS.map((s) => (
                  <label
                    key={s.id}
                    className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md hover:bg-muted/60 transition-colors cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={source.includes(s.id)}
                      onChange={() => toggleSource(s.id)}
                      className="h-3.5 w-3.5 rounded border-border accent-primary"
                    />
                    <span className="text-xs flex-1">{s.label}</span>
                    <span className="text-[10px] text-muted-foreground tabular-nums">{s.count}</span>
                  </label>
                ))}
              </div>
            </CardContent>
          </Card>
        </aside>

        {/* RESULTS */}
        <div className="min-w-0">
          {/* Result meta */}
          <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
            <p className="text-sm text-muted-foreground">
              About <span className="font-semibold text-foreground tabular-nums">{filtered.length}</span> results
              <span className="mx-2 text-muted-foreground/50">·</span>
              <span className="inline-flex items-center gap-1 text-xs">
                <Clock className="h-3 w-3" /> 0.18 seconds
              </span>
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="text-xs gap-1.5">
                <TrendingUp className="h-3.5 w-3.5" /> Sort: Relevance
              </Button>
            </div>
          </div>

          {/* Results list */}
          <div className="space-y-3">
            {filtered.map((r) => {
              const meta = TYPE_META[r.type];
              return (
                <Card key={r.id} className="hover:shadow-premium-sm transition-all hover:border-primary/30 group">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={cn(
                        "grid place-items-center h-9 w-9 rounded-lg shrink-0",
                        meta.tone === "primary" ? "bg-primary/12 text-primary" :
                        meta.tone === "violet" ? "bg-violet-500/12 text-violet-500" :
                        meta.tone === "info" ? "bg-[color:var(--info)]/12 text-[color:var(--info)]" :
                        "bg-[color:var(--warning)]/15 text-[color:var(--warning)]"
                      )}>
                        <meta.icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-1 flex-wrap">
                          {r.breadcrumb.map((b, i) => (
                            <React.Fragment key={i}>
                              {i > 0 && <ChevronRight className="h-2.5 w-2.5 opacity-50" />}
                              <span className={cn(i === r.breadcrumb.length - 1 && "text-foreground/80")}>{b}</span>
                            </React.Fragment>
                          ))}
                          <span className="text-muted-foreground/60">·</span>
                          <span>{r.meta}</span>
                        </div>
                        <a href={r.url} className="block">
                          <h3 className="text-base font-semibold text-foreground group-hover:text-primary transition-colors">
                            {r.title}
                          </h3>
                        </a>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2 leading-relaxed">{r.snippet}</p>
                        <div className="flex items-center gap-3 mt-2.5">
                          <a href={r.url} className="text-xs text-primary hover:underline truncate">
                            {r.url}
                          </a>
                          <Badge variant="outline" className="text-[10px] ml-auto shrink-0">
                            {Math.round(r.relevance)}% match
                          </Badge>
                        </div>
                      </div>
                      <button
                        className="text-muted-foreground hover:text-foreground p-1 rounded transition-colors shrink-0"
                        onClick={() => toast.message("Saved to bookmarks")}
                        aria-label="More actions"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* PAGINATION */}
          <Separator className="my-6" />
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <p className="text-xs text-muted-foreground">Page {page} of 8 · 80 total results</p>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1"
                disabled={page === 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                <ChevronLeft className="h-3.5 w-3.5" /> Previous
              </Button>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((p) => (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={cn(
                      "h-8 w-8 rounded-md text-xs font-medium transition-colors",
                      p === page ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                    )}
                  >
                    {p}
                  </button>
                ))}
                <span className="px-1 text-muted-foreground">...</span>
                <button
                  onClick={() => setPage(8)}
                  className={cn(
                    "h-8 w-8 rounded-md text-xs font-medium transition-colors",
                    8 === page ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                  )}
                >
                  8
                </button>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1"
                disabled={page === 8}
                onClick={() => setPage((p) => Math.min(8, p + 1))}
              >
                Next <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
