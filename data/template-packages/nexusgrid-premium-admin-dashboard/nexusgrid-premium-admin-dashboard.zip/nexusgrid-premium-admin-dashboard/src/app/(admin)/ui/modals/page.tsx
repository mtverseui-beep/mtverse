"use client";

import * as React from "react";
import {
  PanelRightOpen,
  AlertTriangle,
  Trash2,
  UserPlus,
  FileText,
  Maximize2,
  Mail,
  Check,
  X,
  Loader2,
  CreditCard,
  Sparkles,
  ShieldAlert,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function ModalsPage() {
  const [fullscreen, setFullscreen] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  const submitInvite = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Invitation sent to amara@nexusgrid.io");
      (document.activeElement as HTMLElement)?.blur();
    }, 1400);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Modals"
        description="Centered overlays for focused tasks — sizes, types, headers, footers and scrollable content."
        icon={PanelRightOpen}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/modals" },
          { label: "Modals" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => setFullscreen(true)}>
            <Maximize2 /> Open fullscreen demo
          </Button>
        }
      />

      {/* Sizes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Modal sizes</CardTitle>
          <CardDescription>
            Five widths from compact small dialogs through full-viewport overlays.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {[
            { label: "Small (sm)", max: "sm:max-w-sm", content: "Compact dialogs for confirmations and quick alerts." },
            { label: "Medium (md)", max: "sm:max-w-md", content: "The default size — balanced for most tasks." },
            { label: "Large (lg)", max: "sm:max-w-lg", content: "Forms with multiple fields and supporting copy." },
            { label: "Extra large (xl)", max: "sm:max-w-2xl", content: "Multi-section content and rich previews." },
          ].map((s) => (
            <Dialog key={s.label}>
              <DialogTrigger asChild>
                <Button variant="outline">{s.label}</Button>
              </DialogTrigger>
              <DialogContent className={s.max}>
                <DialogHeader>
                  <DialogTitle>{s.label} dialog</DialogTitle>
                  <DialogDescription>{s.content}</DialogDescription>
                </DialogHeader>
                <div className="rounded-lg border bg-muted/40 p-4 text-sm text-muted-foreground">
                  The dialog container width is capped at the size label. On mobile, all dialogs collapse to a
                  nearly full-width sheet with horizontal padding.
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button variant="outline">Cancel</Button>
                  </DialogClose>
                  <DialogClose asChild>
                    <Button onClick={() => toast.success("Action confirmed")}>Confirm</Button>
                  </DialogClose>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          ))}

          <Dialog open={fullscreen} onOpenChange={setFullscreen}>
            <DialogContent className="sm:max-w-none w-screen h-screen max-w-full max-h-full rounded-none sm:inset-0 sm:translate-x-0 sm:translate-y-0 top-0 left-0 translate-x-0 translate-y-0 p-0">
              <div className="flex flex-col h-full">
                <DialogHeader className="p-6 border-b">
                  <DialogTitle className="flex items-center gap-2">
                    <Maximize2 className="h-4 w-4" /> Fullscreen workspace
                  </DialogTitle>
                  <DialogDescription>
                    Useful for immersive editors, document previews, and onboarding flows.
                  </DialogDescription>
                </DialogHeader>
                <div className="flex-1 overflow-auto p-6 space-y-4">
                  <div className="grid gap-4 md:grid-cols-3">
                    {["Drafts", "In review", "Published"].map((col, i) => (
                      <div key={col} className="rounded-lg border bg-card p-3">
                        <div className="flex items-center justify-between mb-3">
                          <p className="text-sm font-semibold">{col}</p>
                          <Badge variant="secondary">{[3, 7, 12][i]}</Badge>
                        </div>
                        <div className="space-y-2">
                          {["Quarterly report", "API documentation", "Sales deck", "Onboarding flow"].slice(0, 3).map((t) => (
                            <div key={t} className="rounded-md border bg-background p-2.5 text-xs">
                              <p className="font-medium">{t}</p>
                              <p className="text-muted-foreground mt-0.5">Updated 2 hours ago</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <DialogFooter className="p-6 border-t">
                  <DialogClose asChild>
                    <Button variant="outline">Close</Button>
                  </DialogClose>
                  <Button onClick={() => toast.success("Workspace saved")}>Save workspace</Button>
                </DialogFooter>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Types */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Modal types</CardTitle>
          <CardDescription>
            Default dialog, alert dialog (forceful), confirmation and form modal.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {/* Default */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">Default dialog</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Subscribe to release notes</DialogTitle>
                <DialogDescription>
                  Get an email every time we ship a new version. You can unsubscribe at any time.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2">
                <Label htmlFor="subscribe-email">Email address</Label>
                <Input id="subscribe-email" type="email" defaultValue="amara@nexusgrid.io" />
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <DialogClose asChild>
                  <Button onClick={() => toast.success("Subscribed to release notes")}>
                    <Mail /> Subscribe
                  </Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Alert dialog */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="text-destructive">
                <ShieldAlert /> Alert dialog
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Revoke API key immediately?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently disable the key <code className="rounded bg-muted px-1 py-0.5 text-xs">nx_live_2f9c…b41a</code> and any service using it will lose access within seconds. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-destructive text-white hover:bg-destructive/90"
                  onClick={() => toast.error("API key revoked")}
                >
                  Revoke key
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Confirmation */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Trash2 /> Confirmation
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <div className="flex items-start gap-4">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-destructive/10 text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <DialogHeader className="text-left">
                    <DialogTitle>Delete 12 selected customers?</DialogTitle>
                    <DialogDescription>
                      This will permanently remove the selected customers along with their order history and support tickets.
                    </DialogDescription>
                  </DialogHeader>
                </div>
              </div>
              <div className="rounded-md border bg-muted/40 p-3 text-xs text-muted-foreground space-y-1">
                <p className="font-medium text-foreground">Affected customers:</p>
                <p>Acme Corp, Globex Inc, Initech, Stark Industries and 8 more</p>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <DialogClose asChild>
                  <Button variant="destructive" onClick={() => toast.error("12 customers deleted")}>
                    Delete permanently
                  </Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Form modal */}
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <UserPlus /> Form modal
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Invite team member</DialogTitle>
                <DialogDescription>
                  Send an invitation email. They will be added to your workspace after they accept.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={submitInvite} className="space-y-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="invite-name">Full name</Label>
                  <Input id="invite-name" placeholder="Amara Reyes" required />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="invite-email">Email</Label>
                  <Input id="invite-email" type="email" placeholder="amara@nexusgrid.io" required />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="invite-message">Personal note (optional)</Label>
                  <Textarea id="invite-message" rows={3} placeholder="Looking forward to having you on the team…" />
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button type="button" variant="outline">Cancel</Button>
                  </DialogClose>
                  <Button type="submit" disabled={submitting}>
                    {submitting ? <Loader2 className="animate-spin" /> : <Mail />}
                    {submitting ? "Sending…" : "Send invite"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Anatomy */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Dialog anatomy</CardTitle>
          <CardDescription>
            Header (title + description), body content, and footer (cancel + primary action).
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full md:w-auto">
                <FileText /> Open anatomy dialog
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" /> Edit release notes
                </DialogTitle>
                <DialogDescription>
                  Write the customer-facing summary of changes for version 4.2.0.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="rn-version">Version</Label>
                  <Input id="rn-version" defaultValue="4.2.0" />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="rn-summary">Summary</Label>
                  <Textarea
                    id="rn-summary"
                    rows={5}
                    defaultValue="NexusGrid 4.2 ships a new billing engine with usage-based invoicing, audit log exports to CSV and JSON, and 14 new dashboard templates including CRM and logistics views."
                  />
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Badge variant="secondary" className="gap-1">
                    <Check className="h-3 w-3" /> Draft saved
                  </Badge>
                  <span>Auto-saves every 30 seconds</span>
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <DialogClose asChild>
                  <Button onClick={() => toast.success("Release notes published")}>
                    Publish
                  </Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Scrollable body */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full md:w-auto">
                Scrollable body
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg max-h-[85vh]">
              <DialogHeader>
                <DialogTitle>Changelog 4.2.0</DialogTitle>
                <DialogDescription>Highlights from this release.</DialogDescription>
              </DialogHeader>
              <div className="overflow-y-auto max-h-[55vh] -mx-1 px-1 space-y-3">
                {[
                  { title: "Billing engine v2", body: "Per-seat and metered usage now supported with proration and credit carry-over." },
                  { title: "Audit log exports", body: "Filter the audit log and export results to CSV, JSON or XLSX with signed URLs." },
                  { title: "14 new dashboard templates", body: "CRM, logistics, healthcare, education, real estate and more." },
                  { title: "Reactive command palette", body: "Now indexes recently visited pages, team members and saved filters." },
                  { title: "Webhook retry policy", body: "Exponential backoff with up to 24 hours of retries for failing endpoints." },
                  { title: "Two-factor enforcement", body: "Workspace admins can require 2FA for all members." },
                  { title: "Performance", body: "List views load up to 3.2x faster with the new virtualised table renderer." },
                  { title: "Accessibility", body: "Focus trapping in modals, ARIA live regions for toasts, and 100% keyboard navigation." },
                ].map((item, i) => (
                  <div key={i} className="rounded-md border p-3">
                    <p className="text-sm font-medium">{item.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{item.body}</p>
                  </div>
                ))}
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button>Got it</Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Payment / rich modal */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Rich modal — payment</CardTitle>
          <CardDescription>
            Multi-section modal combining header, form inputs and footer with primary action.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <CreditCard /> Add payment method
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Add payment method</DialogTitle>
                <DialogDescription>
                  Add a card to enable automatic renewals. Your card is tokenised and stored securely.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="pm-cardholder">Cardholder name</Label>
                  <Input id="pm-cardholder" placeholder="Amara Reyes" />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="pm-number">Card number</Label>
                  <Input id="pm-number" placeholder="4242 4242 4242 4242" inputMode="numeric" />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="grid gap-1.5">
                    <Label htmlFor="pm-expiry">Expiry</Label>
                    <Input id="pm-expiry" placeholder="08/28" />
                  </div>
                  <div className="grid gap-1.5">
                    <Label htmlFor="pm-cvc">CVC</Label>
                    <Input id="pm-cvc" placeholder="123" />
                  </div>
                  <div className="grid gap-1.5">
                    <Label htmlFor="pm-zip">ZIP</Label>
                    <Input id="pm-zip" placeholder="10115" />
                  </div>
                </div>
                <div className="rounded-md bg-muted/40 p-3 text-xs text-muted-foreground flex items-start gap-2">
                  <ShieldAlert className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                  <span>Payments are processed by our PCI-DSS Level 1 processor. We never see or store your CVC.</span>
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <DialogClose asChild>
                  <Button onClick={() => toast.success("Payment method added successfully")}>
                    <Check /> Add card
                  </Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Modals page · 5 sizes · 4 types · anatomy · scrollable body · payment form
      </p>
    </div>
  );
}
