"use client";

import * as React from "react";
import {
  KanbanSquare,
  FolderKanban,
  Gauge,
  AlertTriangle,
  Users,
  Filter,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Flag,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AreaTrendChart, DonutChart, RadarComparison } from "@/components/charts";
import { projectHealth, projectWorkload, salesReps } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline projects data (not in shared mock) ---------- */

// Sprint burnup — 10 day sprint, ideal vs actual story points
const sprintBurnup = [
  { day: "D1", ideal: 24, actual: 18 },
  { day: "D2", ideal: 48, actual: 42 },
  { day: "D3", ideal: 72, actual: 68 },
  { day: "D4", ideal: 96, actual: 84 },
  { day: "D5", ideal: 120, actual: 118 },
  { day: "D6", ideal: 144, actual: 138 },
  { day: "D7", ideal: 168, actual: 152 },
  { day: "D8", ideal: 192, actual: 178 },
  { day: "D9", ideal: 216, actual: 208 },
  { day: "D10", ideal: 240, actual: 232 },
];

// Active projects — 6 rows
const activeProjects = [
  { name: "Atlas Mobile Redesign", client: "Globex Corp", owner: salesReps[0], progress: 78, due: "Jul 14, 2026", status: "on-track" as const, tone: "success" as StatusTone },
  { name: "Pulse Analytics Platform", client: "Initech", owner: salesReps[2], progress: 42, due: "Aug 02, 2026", status: "at-risk" as const, tone: "warning" as StatusTone },
  { name: "Vertex Payment Gateway", client: "Hooli", owner: salesReps[1], progress: 28, due: "Sep 10, 2026", status: "delayed" as const, tone: "danger" as StatusTone },
  { name: "Nimbus Cloud Migration", client: "Acme Corp", owner: salesReps[3], progress: 92, due: "Jul 08, 2026", status: "on-track" as const, tone: "success" as StatusTone },
  { name: "Quasar Mobile SDK", client: "Umbrella Inc", owner: salesReps[4], progress: 100, due: "Jun 30, 2026", status: "completed" as const, tone: "primary" as StatusTone },
  { name: "Orbit Data Pipeline", client: "Soylent", owner: salesReps[2], progress: 56, due: "Jul 22, 2026", status: "on-track" as const, tone: "success" as StatusTone },
];

// Upcoming milestones — 5 items
const milestones = [
  { project: "Atlas Mobile Redesign", milestone: "Beta release to TestFlight", date: "Jul 09, 2026", days: "in 3 days", tone: "success" as StatusTone, status: "On Track" },
  { project: "Pulse Analytics Platform", milestone: "API v2 schema freeze", date: "Jul 11, 2026", days: "in 5 days", tone: "warning" as StatusTone, status: "At Risk" },
  { project: "Nimbus Cloud Migration", milestone: "Production cutover", date: "Jul 14, 2026", days: "in 8 days", tone: "success" as StatusTone, status: "On Track" },
  { project: "Orbit Data Pipeline", milestone: "Backfill completion", date: "Jul 18, 2026", days: "in 12 days", tone: "success" as StatusTone, status: "On Track" },
  { project: "Vertex Payment Gateway", milestone: "PCI-DSS audit", date: "Jul 25, 2026", days: "in 19 days", tone: "danger" as StatusTone, status: "Delayed" },
];

/* ---------- Project KPI card — energetic sprints vibe ---------- */
// Distinct from all existing KPI cards: top sprint-day tracker strip
// (10 dots representing sprint days, filled up to current day),
// big value, bottom sprint-completion progress bar with day counter.
// Uses violet/primary accent palette.

function ProjectKpiCard({
  label,
  value,
  unit,
  icon: Icon,
  trend,
  progress,
  progressLabel,
  accent,
  danger = false,
  sprintDay = 7,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  progress: number; // 0-100
  progressLabel: string;
  accent: "primary" | "violet" | "warning" | "danger";
  danger?: boolean;
  sprintDay?: number; // current day of sprint (1-10)
}) {
  const accentBg: Record<string, string> = {
    primary: "bg-primary/12 text-primary",
    violet: "bg-violet-500/12 text-violet-500",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    danger: "bg-destructive/12 text-destructive",
  };
  const accentBar: Record<string, string> = {
    primary: "from-primary/70 to-primary",
    violet: "from-violet-500/70 to-violet-500",
    warning: "from-[color:var(--warning)]/70 to-[color:var(--warning)]",
    danger: "from-destructive/70 to-destructive",
  };
  const accentDot: Record<string, string> = {
    primary: "bg-primary",
    violet: "bg-violet-500",
    warning: "bg-[color:var(--warning)]",
    danger: "bg-destructive",
  };
  const accentText: Record<string, string> = {
    primary: "text-primary",
    violet: "text-violet-500",
    warning: "text-[color:var(--warning)]",
    danger: "text-destructive",
  };

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm",
        danger && "border-destructive/25 bg-destructive/[0.03]"
      )}
    >
      {/* Sprint day tracker strip — 10 dots, energetic sprint motif */}
      <div className="flex items-center gap-1 mb-3">
        <span className="text-[9px] font-semibold uppercase tracking-wider text-muted-foreground mr-1.5 tabular-nums">
          S24
        </span>
        {Array.from({ length: 10 }).map((_, i) => {
          const filled = i < sprintDay;
          return (
            <span
              key={i}
              className={cn(
                "h-1 flex-1 rounded-full transition-colors",
                filled ? accentDot[accent] : "bg-muted"
              )}
            />
          );
        })}
        <span className="text-[9px] font-medium text-muted-foreground ml-1.5 tabular-nums">
          D{sprintDay}/10
        </span>
      </div>

      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
            {label}
          </p>
          <div className="mt-1.5 flex items-baseline gap-1">
            <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
            {unit && (
              <span className={cn("text-sm font-semibold tabular-nums", accentText[accent])}>
                {unit}
              </span>
            )}
          </div>
        </div>
        <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentBg[accent])}>
          <Icon className="h-4.5 w-4.5" />
        </div>
      </div>

      {/* Bottom sprint-completion progress bar */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1.5">
          <span className="truncate">{progressLabel}</span>
          <span className={cn("font-semibold tabular-nums shrink-0", accentText[accent])}>
            {progress}%
          </span>
        </div>
        <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
          <div
            className={cn("h-full rounded-full bg-gradient-to-r transition-all duration-700 ease-out", accentBar[accent])}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Trend pill */}
      <div className="mt-3 flex items-center gap-1.5">
        <span
          className={cn(
            "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
            trend.positive
              ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
              : "bg-destructive/12 text-destructive"
          )}
        >
          {trend.direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {Math.abs(trend.value)}%
        </span>
        <span className="text-xs text-muted-foreground">vs. last sprint</span>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function ProjectsDashboardPage() {
  const totalProjects = projectHealth.reduce((s, x) => s + x.value, 0);
  const onTrackPct = ((projectHealth[0].value / totalProjects) * 100).toFixed(0);

  return (
    <>
      <PageHeader
        title="Projects Dashboard"
        description="Sprint velocity, project health, and team workload across active engagements."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Projects" }]}
        icon={KanbanSquare}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Sprint 24
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="h-3.5 w-3.5" /> New project
            </Button>
          </>
        }
      />

      {/* KPI Row — ProjectKpiCard with sprint-day tracker + sprint progress bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <ProjectKpiCard
          label="Active Projects"
          value="28"
          icon={FolderKanban}
          accent="primary"
          progress={70}
          progressLabel="40 planned · 28 active"
          trend={{ value: 8, direction: "up", positive: true }}
          sprintDay={7}
        />
        <ProjectKpiCard
          label="Sprint Progress"
          value="68"
          unit="%"
          icon={Gauge}
          accent="violet"
          progress={68}
          progressLabel="232 of 340 story points"
          trend={{ value: 4, direction: "up", positive: true }}
          sprintDay={7}
        />
        <ProjectKpiCard
          label="Overdue Tasks"
          value="12"
          icon={AlertTriangle}
          accent="danger"
          danger
          progress={38}
          progressLabel="12 of 32 tasks overdue"
          trend={{ value: 2, direction: "down", positive: true }}
          sprintDay={7}
        />
        <ProjectKpiCard
          label="Team Capacity"
          value="84"
          unit="%"
          icon={Users}
          accent="warning"
          progress={84}
          progressLabel="168 of 200 hrs booked"
          trend={{ value: 6, direction: "up", positive: true }}
          sprintDay={7}
        />
      </div>

      {/* Project health donut + Sprint burnup */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <KanbanSquare className="h-4 w-4 text-violet-500" />
              Project Health
            </CardTitle>
            <CardDescription>Distribution across {totalProjects} portfolio projects.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={projectHealth}
              centerLabel="On Track"
              centerValue={`${onTrackPct}%`}
              height={200}
            />
            <div className="mt-3 grid grid-cols-2 gap-2 pt-3 border-t border-border">
              {projectHealth.map((h) => (
                <div key={h.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="h-2 w-2 rounded-full shrink-0" style={{ background: h.color }} />
                    <span className="text-muted-foreground truncate">{h.name}</span>
                  </div>
                  <span className="font-semibold tabular-nums shrink-0">{h.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Sprint Burnup
              </CardTitle>
              <CardDescription>
                Ideal vs. actual story point completion across Sprint 24 (10 days).
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--info)]" /> Ideal
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" /> Actual
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={sprintBurnup}
              xKey="day"
              series={[
                { key: "ideal", name: "Ideal", color: "var(--info)" },
                { key: "actual", name: "Actual", color: "var(--primary)" },
              ]}
              height={300}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Committed</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">340 pts</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Completed</p>
                <p className="text-sm font-semibold text-primary tabular-nums mt-0.5">232 pts</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Velocity</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">+12%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active projects table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <FolderKanban className="h-4 w-4 text-violet-500" />
              Active Projects
            </CardTitle>
            <CardDescription>Engagement status across all client workstreams.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            View all <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Project</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Owner</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Progress</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Due Date</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {activeProjects.map((p) => (
                  <tr key={p.name} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-medium text-foreground truncate">{p.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{p.client}</p>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-7 w-7">
                          <AvatarImage src={p.owner.avatar} alt={p.owner.name} />
                          <AvatarFallback className="text-[10px]">
                            {p.owner.name.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground truncate">{p.owner.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="h-1.5 w-24 rounded-full bg-muted overflow-hidden shrink-0">
                          <div
                            className={cn(
                              "h-full rounded-full transition-all duration-700 ease-out",
                              p.progress === 100
                                ? "bg-primary"
                                : p.progress >= 75
                                ? "bg-[color:var(--success)]"
                                : p.progress >= 50
                                ? "bg-violet-500"
                                : p.progress >= 30
                                ? "bg-[color:var(--warning)]"
                                : "bg-destructive"
                            )}
                            style={{ width: `${p.progress}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold tabular-nums w-9 shrink-0">{p.progress}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground tabular-nums hidden sm:table-cell">
                      {p.due}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={p.tone} dot className="capitalize">
                        {p.status}
                      </StatusBadge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Team workload radar + Upcoming milestones */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-violet-500" />
              Team Workload
            </CardTitle>
            <CardDescription>Hours by activity type per teammate this sprint.</CardDescription>
          </CardHeader>
          <CardContent>
            <RadarComparison
              data={projectWorkload}
              axisKey="name"
              series={[
                { key: "design", name: "Design", color: "var(--primary)" },
                { key: "dev", name: "Development", color: "oklch(0.62 0.18 305)" },
                { key: "review", name: "Review", color: "var(--info)" },
              ]}
              height={300}
            />
            <div className="mt-2 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Avg Design</p>
                <p className="text-sm font-semibold text-primary tabular-nums mt-0.5">18.8h</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Avg Dev</p>
                <p className="text-sm font-semibold text-violet-500 tabular-nums mt-0.5">28.4h</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Avg Review</p>
                <p className="text-sm font-semibold text-[color:var(--info)] tabular-nums mt-0.5">14.0h</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Flag className="h-4 w-4 text-violet-500" />
                Upcoming Milestones
              </CardTitle>
              <CardDescription>Key deliverables in the next 3 weeks.</CardDescription>
            </div>
            <StatusBadge tone="primary" dot>5 due soon</StatusBadge>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[380px] overflow-y-auto pr-1 custom-scroll">
            {milestones.map((m, i) => (
              <div
                key={i}
                className="group flex items-center gap-3 rounded-lg border border-border bg-muted/20 p-3 hover:bg-muted/40 hover:border-violet-500/30 transition-colors cursor-pointer"
              >
                <div className={cn(
                  "grid place-items-center h-9 w-9 rounded-lg shrink-0",
                  m.tone === "success" && "bg-[color:var(--success)]/12 text-[color:var(--success)]",
                  m.tone === "warning" && "bg-[color:var(--warning)]/12 text-[color:var(--warning)]",
                  m.tone === "danger" && "bg-destructive/12 text-destructive"
                )}>
                  <Flag className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground truncate">{m.milestone}</p>
                  <p className="text-xs text-muted-foreground truncate">{m.project}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-medium text-foreground tabular-nums whitespace-nowrap">{m.date}</p>
                  <p className="text-[10px] text-muted-foreground tabular-nums">{m.days}</p>
                </div>
                <StatusBadge tone={m.tone} className="capitalize shrink-0">{m.status}</StatusBadge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
