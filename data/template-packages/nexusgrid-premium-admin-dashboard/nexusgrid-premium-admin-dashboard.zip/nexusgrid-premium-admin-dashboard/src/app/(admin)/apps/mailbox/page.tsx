"use client";

import * as React from "react";
import {
  Mail,
  Inbox,
  Star,
  Send,
  FileEdit,
  Archive,
  AlertOctagon,
  Trash2,
  Search,
  PenSquare,
  Reply,
  Forward,
  Paperclip,
  Archive as ArchiveIcon,
  MailOpen,
  FolderInput,
  Clock,
  ChevronLeft,
  MoreHorizontal,
  Tag,
  Image as ImageIcon,
  FileText,
  Smile,
  Bold,
  Italic,
  Underline,
  Link as LinkIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type FolderKey = "inbox" | "starred" | "sent" | "drafts" | "archive" | "spam" | "trash" | "label-work" | "label-personal" | "label-invoices";

type Email = {
  id: string;
  from: { name: string; email: string; avatar: string };
  to: string;
  subject: string;
  preview: string;
  body: string;
  date: string;
  read: boolean;
  starred: boolean;
  attachments: { name: string; size: string; type: "pdf" | "image" | "doc" }[];
  folder: FolderKey;
  labels: string[];
};

const folders: { key: FolderKey; label: string; icon: any; count?: number; color?: string }[] = [
  { key: "inbox", label: "Inbox", icon: Inbox, count: 124 },
  { key: "starred", label: "Starred", icon: Star, count: 8 },
  { key: "sent", label: "Sent", icon: Send, count: 432 },
  { key: "drafts", label: "Drafts", icon: FileEdit, count: 3 },
  { key: "archive", label: "Archive", icon: Archive, count: 1284 },
  { key: "spam", label: "Spam", icon: AlertOctagon, count: 12 },
  { key: "trash", label: "Trash", icon: Trash2, count: 47 },
];

const labels = [
  { key: "label-work" as FolderKey, label: "Work", color: "var(--primary)" },
  { key: "label-personal" as FolderKey, label: "Personal", color: "oklch(0.70 0.15 75)" },
  { key: "label-invoices" as FolderKey, label: "Invoices", color: "oklch(0.62 0.18 140)" },
];

const emails: Email[] = [
  {
    id: "e1",
    from: { name: "Sarah Chen", email: "sarah.chen@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Q3 Roadmap — Final review before board",
    preview: "Hi team, I've attached the finalized Q3 roadmap deck. Please review the platform and infrastructure sections before our 2pm sync...",
    body: "<p>Hi team,</p><p>I've attached the finalized Q3 roadmap deck. Please review the <strong>platform</strong> and <strong>infrastructure</strong> sections before our 2pm sync — particularly the migration timeline (slides 14–18).</p><p>A few things to flag:</p><ul><li>Customer interview findings are summarized on slide 9</li><li>Updated ARR projection model is in the appendix</li><li>Engineering capacity assumptions need sign-off from Aiko</li></ul><p>I'll send a calendar hold for the board pre-read at 4pm.</p><p>Thanks,<br/>Sarah</p>",
    date: "12:42 PM",
    read: false,
    starred: true,
    attachments: [
      { name: "Q3-roadmap-v8.pdf", size: "4.2 MB", type: "pdf" },
      { name: "arr-projection.xlsx", size: "1.1 MB", type: "doc" },
    ],
    folder: "inbox",
    labels: ["Work"],
  },
  {
    id: "e2",
    from: { name: "Stripe", email: "billing@stripe.com", avatar: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Invoice #INV-20841 — payment received",
    preview: "We've received your payment of $4,820.00 for invoice INV-20841. Your receipt is attached...",
    body: "<p>Hi Marcus,</p><p>We've received your payment of <strong>$4,820.00</strong> for invoice <span style='font-family:monospace'>INV-20841</span>.</p><p><strong>Payment method:</strong> Visa ending in 4242<br/><strong>Date:</strong> July 12, 2026<br/><strong>Reference:</strong> ch_3PqWb2F8uQ</p><p>Your receipt is attached to this email. You can also download it any time from the Stripe dashboard.</p><p>Thanks for your business!</p><p>— Stripe Billing</p>",
    date: "11:18 AM",
    read: false,
    starred: false,
    attachments: [{ name: "receipt-INV-20841.pdf", size: "82 KB", type: "pdf" }],
    folder: "inbox",
    labels: ["Invoices"],
  },
  {
    id: "e3",
    from: { name: "Marcus Reyes", email: "marcus.reyes@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Re: Customer escalation — Cloudflare",
    preview: "Thanks for jumping on this quickly. I've looped in Elena; we should aim for a written response by EOD...",
    body: "<p>Thanks for jumping on this quickly.</p><p>I've looped in Elena; we should aim for a written response by EOD. Key points to address:</p><ol><li>The latency spike on July 8 — root cause + remediation</li><li>Credit proposal (suggest 1 month of service)</li><li>Updated SLA going forward</li></ol><p>Let's sync at 3.</p><p>Marcus</p>",
    date: "10:04 AM",
    read: true,
    starred: true,
    attachments: [],
    folder: "inbox",
    labels: ["Work"],
  },
  {
    id: "e4",
    from: { name: "Elena Petrov", email: "elena.petrov@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Board pre-read — H1 results & Q3 plan",
    preview: "Attaching the board pre-read for next Tuesday's meeting. Please review the financial summary and the strategic priorities section...",
    body: "<p>Team,</p><p>Attaching the board pre-read for next Tuesday's meeting. Please review the <strong>financial summary</strong> and the <strong>strategic priorities</strong> section.</p><p>Key takeaways:</p><ul><li>H1 revenue came in 8% above plan</li><li>Gross margin expanded 320 bps YoY</li><li>Q3 guidance raised to $14.2M ARR</li></ul><p>Let me know if you have any concerns before Monday EOD.</p><p>Elena</p>",
    date: "Yesterday",
    read: true,
    starred: true,
    attachments: [{ name: "board-preread-H1.pdf", size: "6.8 MB", type: "pdf" }],
    folder: "inbox",
    labels: ["Work"],
  },
  {
    id: "e5",
    from: { name: "Priya Sharma", email: "priya.s@gmail.com", avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Brunch this Saturday?",
    preview: "Hey! Olive & Oak finally reopened after the remodel. Want to check it out Saturday around 11?...",
    body: "<p>Hey!</p><p>Olive &amp; Oak finally reopened after the remodel. Want to check it out Saturday around 11?</p><p>They have that lavender honey French toast you loved last time :)</p><p>Let me know!</p><p>Priya</p>",
    date: "Yesterday",
    read: false,
    starred: false,
    attachments: [],
    folder: "inbox",
    labels: ["Personal"],
  },
  {
    id: "e6",
    from: { name: "GitHub", email: "noreply@github.com", avatar: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "[nexusgrid/platform] PR #2841 approved and ready to merge",
    preview: "Aiko Tanaka approved your pull request. All CI checks passed. You can now merge into main...",
    body: "<p><strong>Aiko Tanaka</strong> approved your pull request <a href='#'>#2841: Refactor payment retry logic</a>.</p><p>All CI checks passed.</p><p>You can now merge into <code>main</code>.</p><p style='color:#6b7280;font-size:12px'>— GitHub Notifications</p>",
    date: "Yesterday",
    read: true,
    starred: false,
    attachments: [],
    folder: "inbox",
    labels: ["Work"],
  },
  {
    id: "e7",
    from: { name: "Notion Team", email: "team@notion.so", avatar: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Your workspace usage report is ready",
    preview: "Your team created 248 new pages this month. Here's a summary of the most active spaces and members...",
    body: "<p>Hi Marcus,</p><p>Your team created <strong>248 new pages</strong> this month. Here's a summary:</p><ul><li>Most active space: Engineering (89 pages)</li><li>Top contributor: Aiko Tanaka</li><li>Average page rating: 4.6 / 5</li></ul><p>View the full report in your Notion workspace.</p>",
    date: "Mon",
    read: true,
    starred: false,
    attachments: [],
    folder: "inbox",
    labels: [],
  },
  {
    id: "e8",
    from: { name: "Aiko Tanaka", email: "aiko.tanaka@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Postmortem — July 8 incident",
    preview: "I've finished the postmortem for the July 8 latency incident. Root cause was a misconfigured connection pool...",
    body: "<p>Marcus,</p><p>I've finished the postmortem for the July 8 latency incident.</p><p><strong>Root cause:</strong> misconfigured connection pool on the read replica (max-pool-size was set to 8 instead of 80 during the rolling deploy).</p><p><strong>Impact:</strong> ~12% of read requests timed out over a 47-minute window.</p><p><strong>Mitigation:</strong> fixed config + added pre-deploy validation. Full write-up attached.</p><p>Aiko</p>",
    date: "Mon",
    read: true,
    starred: false,
    attachments: [{ name: "postmortem-2026-07-08.pdf", size: "320 KB", type: "pdf" }],
    folder: "inbox",
    labels: ["Work"],
  },
  {
    id: "e9",
    from: { name: "James Okoro", email: "james.okoro@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Stripe vendor intro — confirmed for Friday",
    preview: "Stripe's platform team confirmed Friday 2pm PT for the integration deep-dive. I'll send the agenda...",
    body: "<p>Stripe's platform team confirmed Friday 2pm PT for the integration deep-dive. I'll send the agenda.</p><p>Suggested prep:</p><ul><li>Review their Connect docs</li><li>Bring our current txn volume + edge cases</li></ul><p>James</p>",
    date: "Sun",
    read: true,
    starred: false,
    attachments: [],
    folder: "inbox",
    labels: ["Work"],
  },
  {
    id: "e10",
    from: { name: "Vercel", email: "noreply@vercel.com", avatar: "https://images.unsplash.com/photo-1620288627229-c5b1d2f80c8f?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Deployment successful — nexusgrid-web (production)",
    preview: "Your deployment to production completed in 47 seconds. View build logs and analytics in your dashboard...",
    body: "<p>Deployment to <strong>production</strong> completed successfully.</p><p><strong>Project:</strong> nexusgrid-web<br/><strong>Branch:</strong> main<br/><strong>Commit:</strong> 8f2a91c<br/><strong>Duration:</strong> 47s</p><p>View build logs and analytics in your dashboard.</p>",
    date: "Sun",
    read: true,
    starred: false,
    attachments: [],
    folder: "inbox",
    labels: [],
  },
  {
    id: "e11",
    from: { name: "Linear", email: "notifications@linear.app", avatar: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Weekly digest — 14 issues closed, 22 opened",
    preview: "Your team made great progress this week. Here's a snapshot of the activity across all projects...",
    body: "<p>Hi team,</p><p>Here's a snapshot of the activity this week:</p><ul><li>14 issues closed</li><li>22 issues opened</li><li>3 cycles completed</li></ul><p>Top contributor: Aiko Tanaka (8 issues).</p>",
    date: "Sat",
    read: true,
    starred: false,
    attachments: [],
    folder: "inbox",
    labels: ["Work"],
  },
  {
    id: "e12",
    from: { name: "AWS Billing", email: "billing@aws.amazon.com", avatar: "https://images.unsplash.com/photo-1605379399642-870262d3d051?w=80&h=80&fit=crop" },
    to: "me@nexusgrid.io",
    subject: "Your AWS invoice for June 2026 is ready",
    preview: "Your invoice for June 2026 totals $18,420.00. Payment will be charged on July 18...",
    body: "<p>Your AWS invoice for June 2026 is ready.</p><p><strong>Total:</strong> $18,420.00<br/><strong>Payment method:</strong> Visa ending in 4242<br/><strong>Charge date:</strong> July 18, 2026</p><p>Download the full PDF for line-item details.</p>",
    date: "Jul 4",
    read: true,
    starred: false,
    attachments: [{ name: "aws-invoice-june-2026.pdf", size: "1.4 MB", type: "pdf" }],
    folder: "inbox",
    labels: ["Invoices"],
  },
];

const STORAGE_USED = "8.4 GB";
const STORAGE_TOTAL = "15 GB";

export default function MailboxPage() {
  const [activeFolder, setActiveFolder] = React.useState<FolderKey>("inbox");
  const [activeEmailId, setActiveEmailId] = React.useState<string>("e1");
  const [search, setSearch] = React.useState("");
  const [composeOpen, setComposeOpen] = React.useState(false);
  const [emailsState, setEmailsState] = React.useState(emails);

  const activeEmail = emailsState.find((e) => e.id === activeEmailId);

  const folderEmails = emailsState.filter((e) => {
    if (activeFolder === "starred") return e.starred;
    if (activeFolder === "label-work") return e.labels.includes("Work");
    if (activeFolder === "label-personal") return e.labels.includes("Personal");
    if (activeFolder === "label-invoices") return e.labels.includes("Invoices");
    return e.folder === activeFolder;
  }).filter((e) => !search || e.subject.toLowerCase().includes(search.toLowerCase()) || e.from.name.toLowerCase().includes(search.toLowerCase()));

  const unreadInInbox = emailsState.filter((e) => !e.read && e.folder === "inbox").length;

  function markAsRead(id: string) {
    setEmailsState((prev) => prev.map((e) => (e.id === id ? { ...e, read: true } : e)));
  }

  function toggleStar(id: string) {
    setEmailsState((prev) => prev.map((e) => (e.id === id ? { ...e, starred: !e.starred } : e)));
  }

  function handleSelect(id: string) {
    setActiveEmailId(id);
    markAsRead(id);
  }

  function emailAction(action: string, id: string) {
    const e = emailsState.find((x) => x.id === id);
    toast.success(action, { description: e ? `"${e.subject.slice(0, 40)}${e.subject.length > 40 ? "…" : ""}"` : undefined });
    if (action === "Archive") setEmailsState((p) => p.map((x) => (x.id === id ? { ...x, folder: "archive" } : x)));
    if (action === "Delete") setEmailsState((p) => p.map((x) => (x.id === id ? { ...x, folder: "trash" } : x)));
    if (action === "Marked unread") setEmailsState((p) => p.map((x) => (x.id === id ? { ...x, read: false } : x)));
  }

  return (
    <>
      <PageHeader
        title="Mailbox"
        description="Unified inbox with smart labels, snooze, and one-click actions."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "Mailbox" }]}
        icon={Mail}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setComposeOpen(true)}>
            <PenSquare className="h-3.5 w-3.5" /> Compose
          </Button>
        }
      />

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr_460px] h-[calc(100vh-220px)] min-h-[560px]">
            {/* FOLDER LIST */}
            <div className="border-r flex flex-col">
              <div className="p-3 border-b">
                <Button size="sm" className="w-full gap-1.5" onClick={() => setComposeOpen(true)}>
                  <PenSquare className="h-3.5 w-3.5" /> Compose
                </Button>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-2">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5">Folders</p>
                  {folders.map((f) => {
                    const Icon = f.icon;
                    const active = activeFolder === f.key;
                    return (
                      <button
                        key={f.key}
                        onClick={() => setActiveFolder(f.key)}
                        className={cn(
                          "w-full flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm transition-colors",
                          active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground"
                        )}
                      >
                        <span className="flex items-center gap-2">
                          <Icon className="h-3.5 w-3.5" />
                          {f.label}
                        </span>
                        {f.count !== undefined && (
                          <span className={cn(
                            "text-[10px] tabular-nums px-1.5 py-0.5 rounded-full",
                            f.key === "inbox" && unreadInInbox > 0 ? "bg-primary text-primary-foreground font-semibold" : "bg-muted text-muted-foreground"
                          )}>
                            {f.key === "inbox" ? unreadInInbox : f.count}
                          </span>
                        )}
                      </button>
                    );
                  })}
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5 mt-3">Labels</p>
                  {labels.map((l) => {
                    const active = activeFolder === l.key;
                    return (
                      <button
                        key={l.key}
                        onClick={() => setActiveFolder(l.key)}
                        className={cn(
                          "w-full flex items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors",
                          active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground"
                        )}
                      >
                        <span className="h-2 w-2 rounded-full" style={{ background: l.color }} />
                        {l.label}
                      </button>
                    );
                  })}

                  <div className="mt-4 px-2">
                    <div className="rounded-md bg-muted/40 p-3">
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1.5">Storage</p>
                      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                        <div className="h-full rounded-full bg-primary" style={{ width: "56%" }} />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1.5">{STORAGE_USED} of {STORAGE_TOTAL} used</p>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </div>

            {/* EMAIL LIST */}
            <div className="border-r flex flex-col min-w-0">
              <div className="p-3 border-b">
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                    <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search mail..." className="h-9 pl-8 text-sm" />
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="icon" className="h-9 w-9"><MoreHorizontal className="h-4 w-4" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => toast.success("Marked all as read")}>Mark all as read</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toast.success("Refreshing...")}>Refresh</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toast.success("Sorting by date")}>Sort by date</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <p className="text-xs text-muted-foreground mt-2 px-1">{folderEmails.length} messages in {folders.find((f) => f.key === activeFolder)?.label ?? labels.find((l) => l.key === activeFolder)?.label}</p>
              </div>
              <ScrollArea className="flex-1">
                <div className="divide-y">
                  {folderEmails.length === 0 && (
                    <div className="py-16 text-center text-sm text-muted-foreground">No messages here.</div>
                  )}
                  {folderEmails.map((e) => {
                    const isActive = e.id === activeEmailId;
                    return (
                      <button
                        key={e.id}
                        onClick={() => handleSelect(e.id)}
                        className={cn(
                          "w-full flex gap-3 px-3 py-3 text-left transition-colors relative",
                          isActive ? "bg-primary/[0.06]" : "hover:bg-muted/30",
                          !e.read && "bg-primary/[0.03]"
                        )}
                      >
                        {isActive && <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary" />}
                        <Avatar className="h-9 w-9 shrink-0">
                          <AvatarImage src={e.from.avatar} alt={e.from.name} />
                          <AvatarFallback className="text-[10px]">{e.from.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className={cn("text-sm truncate", !e.read ? "font-semibold text-foreground" : "font-medium text-foreground/80")}>{e.from.name}</span>
                            <span className="text-[10px] text-muted-foreground shrink-0 tabular-nums">{e.date}</span>
                          </div>
                          <p className={cn("text-xs truncate mt-0.5", !e.read ? "font-medium text-foreground" : "text-muted-foreground")}>{e.subject}</p>
                          <p className="text-[11px] text-muted-foreground truncate mt-0.5">{e.preview}</p>
                          <div className="flex items-center gap-1.5 mt-1.5">
                            {e.starred && <Star className="h-3 w-3 text-[color:var(--warning)] fill-current" />}
                            {e.attachments.length > 0 && <Paperclip className="h-3 w-3 text-muted-foreground" />}
                            {e.labels.map((l) => {
                              const lab = labels.find((x) => x.label === l);
                              return lab ? (
                                <span key={l} className="inline-flex items-center gap-1 text-[9px] font-medium px-1.5 py-0.5 rounded" style={{ background: `color-mix(in srgb, ${lab.color} 12%, transparent)`, color: lab.color }}>
                                  <Tag className="h-2 w-2" />{l}
                                </span>
                              ) : null;
                            })}
                            {!e.read && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-primary" />}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>

            {/* EMAIL PREVIEW */}
            <div className="flex flex-col min-w-0">
              {activeEmail ? (
                <>
                  {/* Toolbar */}
                  <div className="flex items-center gap-1 px-3 py-2 border-b">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => emailAction("Archive", activeEmail.id)} title="Archive"><ArchiveIcon className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => emailAction("Delete", activeEmail.id)} title="Delete"><Trash2 className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => emailAction("Marked unread", activeEmail.id)} title="Mark unread"><MailOpen className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => emailAction("Moved to folder", activeEmail.id)} title="Move"><FolderInput className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toast.success("Snoozed until tomorrow")} title="Snooze"><Clock className="h-4 w-4" /></Button>
                    <Separator orientation="vertical" className="h-5 mx-1" />
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStar(activeEmail.id)} title="Star">
                      <Star className={cn("h-4 w-4", activeEmail.starred && "text-[color:var(--warning)] fill-current")} />
                    </Button>
                    <div className="flex-1" />
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toast.success("More options")}><MoreHorizontal className="h-4 w-4" /></Button>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-4">
                      <h2 className="text-lg font-semibold text-foreground mb-3">{activeEmail.subject}</h2>
                      <div className="flex items-center justify-between gap-3 pb-3 border-b">
                        <div className="flex items-center gap-3 min-w-0">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={activeEmail.from.avatar} alt={activeEmail.from.name} />
                            <AvatarFallback>{activeEmail.from.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="text-sm font-medium">{activeEmail.from.name} <span className="text-muted-foreground font-normal">&lt;{activeEmail.from.email}&gt;</span></p>
                            <p className="text-xs text-muted-foreground">to {activeEmail.to}</p>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-xs text-muted-foreground">{activeEmail.date}</p>
                          {activeEmail.labels.map((l) => (
                            <Badge key={l} variant="outline" className="text-[9px] mt-1">{l}</Badge>
                          ))}
                        </div>
                      </div>
                      <div
                        className="prose prose-sm max-w-none mt-4 text-sm leading-relaxed text-foreground/90 [&_strong]:font-semibold [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_a]:text-primary [&_a]:underline [&_code]:font-mono [&_code]:text-xs [&_code]:bg-muted [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded"
                        dangerouslySetInnerHTML={{ __html: activeEmail.body }}
                      />
                      {activeEmail.attachments.length > 0 && (
                        <div className="mt-5">
                          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">Attachments ({activeEmail.attachments.length})</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {activeEmail.attachments.map((a, i) => (
                              <button
                                key={i}
                                onClick={() => toast.success(`Downloading ${a.name}`)}
                                className="flex items-center gap-3 rounded-lg border border-border p-2.5 hover:border-primary/40 hover:bg-muted/30 transition-colors text-left"
                              >
                                <div className={cn(
                                  "grid place-items-center h-9 w-9 rounded-md shrink-0",
                                  a.type === "pdf" ? "bg-destructive/10 text-destructive" : a.type === "image" ? "bg-[color:var(--info)]/12 text-[color:var(--info)]" : "bg-primary/10 text-primary"
                                )}>
                                  {a.type === "image" ? <ImageIcon className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                                </div>
                                <div className="min-w-0">
                                  <p className="text-xs font-medium truncate">{a.name}</p>
                                  <p className="text-[10px] text-muted-foreground">{a.size}</p>
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                  {/* Reply bar */}
                  <div className="border-t p-3 flex items-center gap-2">
                    <Button size="sm" variant="outline" className="gap-1.5" onClick={() => toast.success("Reply draft opened")}><Reply className="h-3.5 w-3.5" /> Reply</Button>
                    <Button size="sm" variant="outline" className="gap-1.5" onClick={() => toast.success("Reply all draft opened")}><Reply className="h-3.5 w-3.5" /> Reply All</Button>
                    <Button size="sm" variant="outline" className="gap-1.5" onClick={() => toast.success("Forward draft opened")}><Forward className="h-3.5 w-3.5" /> Forward</Button>
                  </div>
                </>
              ) : (
                <div className="flex-1 grid place-items-center text-sm text-muted-foreground">Select an email to read.</div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Compose dialog */}
      <Dialog open={composeOpen} onOpenChange={setComposeOpen}>
        <DialogContent className="sm:max-w-[640px]">
          <DialogHeader>
            <DialogTitle>New Message</DialogTitle>
            <DialogDescription>Compose a new email.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-[60px_1fr] items-center gap-2">
              <Label className="text-xs text-right">To</Label>
              <Input placeholder="recipient@example.com" className="h-8 text-sm" />
            </div>
            <div className="grid grid-cols-[60px_1fr] items-center gap-2">
              <Label className="text-xs text-right">CC</Label>
              <Input placeholder="cc@example.com (optional)" className="h-8 text-sm" />
            </div>
            <div className="grid grid-cols-[60px_1fr] items-center gap-2">
              <Label className="text-xs text-right">Subject</Label>
              <Input placeholder="Subject line" className="h-8 text-sm" />
            </div>
            <div>
              <div className="flex items-center gap-0.5 border-b pb-1.5 mb-1.5">
                <Button variant="ghost" size="icon" className="h-7 w-7"><Bold className="h-3.5 w-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7"><Italic className="h-3.5 w-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7"><Underline className="h-3.5 w-3.5" /></Button>
                <Separator orientation="vertical" className="h-4 mx-1" />
                <Button variant="ghost" size="icon" className="h-7 w-7"><LinkIcon className="h-3.5 w-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7"><Smile className="h-3.5 w-3.5" /></Button>
              </div>
              <Textarea placeholder="Write your message..." rows={8} className="text-sm" />
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Paperclip className="h-3.5 w-3.5" /> No attachments
              <Button variant="ghost" size="sm" className="h-6 text-xs ml-1" onClick={() => toast.success("File picker opened")}>Attach</Button>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" size="sm" onClick={() => { toast.success("Saved to drafts"); setComposeOpen(false); }}>Save Draft</Button>
            <div className="flex-1" />
            <Button variant="outline" size="sm" onClick={() => toast.success("Scheduled for tomorrow 9 AM")}>Schedule</Button>
            <Button size="sm" className="gap-1.5" onClick={() => { toast.success("Message sent"); setComposeOpen(false); }}>
              <Send className="h-3.5 w-3.5" /> Send
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
