"use client";

import * as React from "react";
import Link from "next/link";
import {
  DollarSign,
  ShoppingCart,
  Users,
  Package,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Eye,
  RotateCcw,
  MoreHorizontal,
  Download,
  Filter,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { KpiCard, Sparkline } from "@/components/common/kpi-card";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  AreaTrendChart,
  BarTrendChart,
  DonutChart,
} from "@/components/charts";
import {
  ecommerceRevenueData,
  ecommerceFunnel,
  topProducts,
  recentOrders,
  customerSegments,
} from "@/data/mock-data";
import { cn } from "@/lib/utils";

export default function EcommerceDashboardPage() {
  return (
    <>
      <PageHeader
        title="Ecommerce Dashboard"
        description="Real-time sales, orders, inventory, and customer insights across all your storefronts."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Ecommerce" }]}
        icon={ShoppingCart}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Last 30 days
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" asChild>
              <Link href="/ecommerce/orders?action=new">
                <ShoppingCart className="h-3.5 w-3.5" /> New Order
              </Link>
            </Button>
          </>
        }
      />

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Total Revenue"
          value="$284,392"
          icon={DollarSign}
          accent="primary"
          trend={{ value: 12.4, direction: "up" }}
          hint="vs last month"
          sparkline={<Sparkline data={ecommerceRevenueData.map((d) => d.revenue)} color="var(--primary)" />}
        />
        <KpiCard
          label="Orders"
          value="3,284"
          icon={ShoppingCart}
          accent="info"
          trend={{ value: 8.2, direction: "up" }}
          hint="vs last month"
          sparkline={<Sparkline data={ecommerceRevenueData.map((d) => d.orders)} color="var(--info)" />}
        />
        <KpiCard
          label="Active Customers"
          value="28,420"
          icon={Users}
          accent="success"
          trend={{ value: 4.6, direction: "up" }}
          hint="1,240 new this month"
        />
        <KpiCard
          label="Avg. Order Value"
          value="$86.60"
          icon={TrendingUp}
          accent="warning"
          trend={{ value: 2.1, direction: "down" }}
          hint="vs last month"
        />
      </div>

      {/* Revenue Chart + Funnel */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base">Revenue Performance</CardTitle>
              <CardDescription>Gross merchandise value and order volume over the last 12 months.</CardDescription>
            </div>
            <Tabs defaultValue="revenue" className="w-auto">
              <TabsList className="grid w-full grid-cols-2 h-8">
                <TabsTrigger value="revenue" className="text-xs">Revenue</TabsTrigger>
                <TabsTrigger value="orders" className="text-xs">Orders</TabsTrigger>
              </TabsList>
              <TabsContent value="revenue" className="hidden" />
              <TabsContent value="orders" className="hidden" />
            </Tabs>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={ecommerceRevenueData}
              xKey="month"
              series={[
                { key: "revenue", name: "Revenue ($)", color: "var(--primary)" },
                { key: "refunds", name: "Refunds ($)", color: "var(--destructive)" },
              ]}
              height={300}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Conversion Funnel</CardTitle>
            <CardDescription>Visitor-to-purchase journey.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {ecommerceFunnel.map((stage, i) => {
              const max = ecommerceFunnel[0].value;
              const pct = (stage.value / max) * 100;
              const conv = i === 0 ? 100 : (stage.value / ecommerceFunnel[i - 1].value) * 100;
              return (
                <div key={stage.stage}>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium text-foreground">{stage.stage}</span>
                    <span className="text-muted-foreground tabular-nums">
                      {stage.value.toLocaleString()}{" "}
                      <span className="text-[10px] opacity-70">
                        ({conv.toFixed(1)}%)
                      </span>
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700 ease-out"
                      style={{ width: `${pct}%`, background: stage.color }}
                    />
                  </div>
                </div>
              );
            })}
            <div className="pt-3 mt-3 border-t border-border">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Overall conversion</span>
                <span className="font-semibold text-[color:var(--success)]">7.35%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Products + Customer Segments */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base">Top Performing Products</CardTitle>
              <CardDescription>Best sellers by revenue this period.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild className="text-xs">
              <Link href="/ecommerce/products">View all <ArrowUpRight className="h-3.5 w-3.5 ml-0.5" /></Link>
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Product</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Sold</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Revenue</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Stock</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Trend</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {topProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.image}
                            alt={p.name}
                            className="h-10 w-10 rounded-lg object-cover bg-muted shrink-0"
                          />
                          <div className="min-w-0">
                            <p className="font-medium text-foreground truncate">{p.name}</p>
                            <p className="text-xs text-muted-foreground">{p.sku}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums">{p.sold.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right tabular-nums font-medium hidden sm:table-cell">${p.revenue.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right hidden md:table-cell">
                        <span className={cn(
                          "inline-block px-1.5 py-0.5 rounded text-xs font-medium tabular-nums",
                          p.stock < 20 ? "bg-destructive/12 text-destructive" : p.stock < 50 ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" : "bg-muted text-muted-foreground"
                        )}>
                          {p.stock}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className={cn(
                          "inline-flex items-center gap-0.5 text-xs font-medium tabular-nums",
                          p.trend >= 0 ? "text-[color:var(--success)]" : "text-destructive"
                        )}>
                          {p.trend >= 0 ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                          {Math.abs(p.trend)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Customer Segments</CardTitle>
            <CardDescription>Distribution by lifecycle stage.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={customerSegments}
              centerLabel="Customers"
              centerValue="27,990"
              height={220}
            />
            <div className="mt-3 space-y-1.5">
              {customerSegments.map((s) => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                    <span className="text-muted-foreground">{s.name}</span>
                  </div>
                  <span className="font-medium tabular-nums">{s.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders + Quick Actions */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base">Recent Orders</CardTitle>
              <CardDescription>Latest transactions across all channels.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild className="text-xs">
              <Link href="/ecommerce/orders">View all <ArrowUpRight className="h-3.5 w-3.5 ml-0.5" /></Link>
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Order</th>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Customer</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Total</th>
                    <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {recentOrders.slice(0, 6).map((o) => (
                    <tr key={o.id} className="hover:bg-muted/30 transition-colors cursor-pointer">
                      <td className="px-4 py-3 font-mono text-xs">{o.id}</td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-medium text-foreground">{o.customer}</p>
                          <p className="text-xs text-muted-foreground">{o.email}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums font-medium hidden sm:table-cell">${o.total.toFixed(2)}</td>
                      <td className="px-4 py-3 text-center">
                        <StatusBadge tone={orderStatusTone(o.status)} dot>{o.status}</StatusBadge>
                      </td>
                      <td className="px-4 py-3 text-right text-xs text-muted-foreground hidden md:table-cell">{o.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {/* Inventory alerts */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Package className="h-4 w-4 text-[color:var(--warning)]" />
                Inventory Alerts
              </CardTitle>
              <CardDescription>Items needing restock soon.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {topProducts.filter((p) => p.stock < 50).map((p) => (
                <div key={p.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img src={p.image} alt={p.name} className="h-8 w-8 rounded-md object-cover" />
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.sku}</p>
                    </div>
                  </div>
                  <span className={cn(
                    "text-xs font-semibold px-1.5 py-0.5 rounded tabular-nums",
                    p.stock < 20 ? "bg-destructive/12 text-destructive" : "bg-[color:var(--warning)]/15 text-[color:var(--warning)]"
                  )}>
                    {p.stock} left
                  </span>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full text-xs mt-2" asChild>
                <Link href="/ecommerce/inventory">
                  Manage inventory <ArrowUpRight className="h-3 w-3 ml-0.5" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          {/* Refunds quick stat */}
          <Card className="bg-gradient-to-br from-destructive/[0.04] to-transparent">
            <CardContent className="pt-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 text-[color:var(--destructive)] mb-1.5">
                    <RotateCcw className="h-4 w-4" />
                    <span className="text-xs font-semibold uppercase tracking-wide">Refunds</span>
                  </div>
                  <p className="text-2xl font-semibold tabular-nums">$8,420</p>
                  <p className="text-xs text-muted-foreground mt-1">128 refunds · 0.42% rate</p>
                </div>
                <StatusBadge tone="danger" dot>-0.8%</StatusBadge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

function orderStatusTone(status: string): any {
  switch (status) {
    case "completed": return "success";
    case "processing": return "info";
    case "shipped": return "primary";
    case "pending": return "warning";
    case "cancelled": return "danger";
    default: return "neutral";
  }
}
