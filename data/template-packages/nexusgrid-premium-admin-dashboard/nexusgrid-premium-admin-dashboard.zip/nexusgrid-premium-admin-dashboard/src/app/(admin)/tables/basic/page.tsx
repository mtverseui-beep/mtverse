"use client";

import * as React from "react";
import {
  Table,
  TableIcon,
  Rows3,
  Grid2x2,
  Minimize2,
  Hash,
  Users,
  Package,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Table as UiTable,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type UserRow = { id: number; name: string; role: string; team: string; joined: string };
const usersData: UserRow[] = [
  { id: 1, name: "Sarah Chen", role: "Senior Engineer", team: "Platform", joined: "2023-04-12" },
  { id: 2, name: "Marcus Reyes", role: "Product Designer", team: "Design", joined: "2022-08-03" },
  { id: 3, name: "Elena Petrov", role: "Engineering Manager", team: "Platform", joined: "2021-01-22" },
  { id: 4, name: "James Okoro", role: "Data Scientist", team: "Analytics", joined: "2023-11-15" },
  { id: 5, name: "Aiko Tanaka", role: "Frontend Engineer", team: "Web", joined: "2024-02-09" },
];

type ProductRow = { sku: string; name: string; category: string; price: number; stock: number };
const productsData: ProductRow[] = [
  { sku: "NX-1001", name: "Aurora Mechanical Keyboard", category: "Peripherals", price: 189.0, stock: 142 },
  { sku: "NX-1002", name: "Lumen 4K Webcam", category: "Cameras", price: 129.5, stock: 88 },
  { sku: "NX-1003", name: "Pulse Wireless Mouse", category: "Peripherals", price: 64.99, stock: 312 },
  { sku: "NX-1004", name: "Cadence Studio Headphones", category: "Audio", price: 249.0, stock: 56 },
  { sku: "NX-1005", name: "Beacon Smart Lamp", category: "Lighting", price: 89.0, stock: 207 },
  { sku: "NX-1006", name: "Halo USB-C Hub", category: "Accessories", price: 79.99, stock: 174 },
  { sku: "NX-1007", name: "Echo Standing Desk", category: "Furniture", price: 549.0, stock: 24 },
];

type SalesRow = { region: string; q1: number; q2: number; q3: number; q4: number; total: number };
const salesData: SalesRow[] = [
  { region: "North America", q1: 248000, q2: 286000, q3: 312000, q4: 358000, total: 1204000 },
  { region: "Europe", q1: 184000, q2: 212000, q3: 196000, q4: 238000, total: 830000 },
  { region: "Asia Pacific", q1: 162000, q2: 198000, q3: 224000, q4: 268000, total: 852000 },
  { region: "Latin America", q1: 78000, q2: 92000, q3: 86000, q4: 108000, total: 364000 },
  { region: "Middle East & Africa", q1: 54000, q2: 64000, q3: 72000, q4: 86000, total: 276000 },
];

type ActivityRow = { ts: string; user: string; action: string; target: string };
const activityData: ActivityRow[] = [
  { ts: "10:42:18", user: "sarah.c", action: "merged PR #4821", target: "platform/web" },
  { ts: "10:38:04", user: "marcus.r", action: "commented on", target: "Design ticket #1124" },
  { ts: "10:31:55", user: "elena.p", action: "approved deploy", target: "production-cluster-1" },
  { ts: "10:24:30", user: "james.o", action: "ran query", target: "warehouse.orders_daily" },
  { ts: "10:18:12", user: "aiko.t", action: "opened PR #4823", target: "web/checkout-flow" },
  { ts: "10:11:46", user: "david.k", action: "closed incident", target: "INC-2026-0982" },
  { ts: "10:04:22", user: "lena.h", action: "uploaded file", target: "design/v3-spec.pdf" },
  { ts: "09:58:09", user: "raj.p", action: "scheduled job", target: "nightly-etl-pipeline" },
];

const fmt = (n: number) => n.toLocaleString("en-US", { maximumFractionDigits: 0 });

export default function BasicTablesPage() {
  return (
    <>
      <PageHeader
        title="Basic Tables"
        description="Five foundational table styles — bordered, striped, hover, cell-bordered, and compact — built on the shared shadcn/ui Table primitives."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Basic Tables" }]}
        icon={Table}
      />

      <div className="grid grid-cols-1 gap-6">
        {/* a) Simple bordered table */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <span className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
                <TableIcon className="h-4 w-4" />
              </span>
              Simple Bordered Table
            </CardTitle>
            <CardDescription className="text-xs">
              Outer border wrapping the entire table — useful for compact dashboard panels.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <UiTable>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="w-12 text-xs font-semibold">#</TableHead>
                    <TableHead className="text-xs font-semibold">Name</TableHead>
                    <TableHead className="text-xs font-semibold">Role</TableHead>
                    <TableHead className="text-xs font-semibold">Team</TableHead>
                    <TableHead className="text-xs font-semibold">Joined</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {usersData.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-mono text-xs text-muted-foreground">{u.id}</TableCell>
                      <TableCell className="font-medium text-sm">{u.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{u.role}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-[11px] font-normal">{u.team}</Badge>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{u.joined}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </UiTable>
            </div>
          </CardContent>
        </Card>

        {/* b) Striped table */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
                <Rows3 className="h-4 w-4" />
              </span>
              Striped Table
            </CardTitle>
            <CardDescription className="text-xs">
              Alternating zebra striping with <code className="text-[11px] bg-muted px-1 py-0.5 rounded">odd:</code> row modifier for scan-ability across long product lists.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <UiTable>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="text-xs font-semibold">SKU</TableHead>
                    <TableHead className="text-xs font-semibold">Product</TableHead>
                    <TableHead className="text-xs font-semibold">Category</TableHead>
                    <TableHead className="text-xs font-semibold text-right">Price</TableHead>
                    <TableHead className="text-xs font-semibold text-right">Stock</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productsData.map((p, i) => (
                    <TableRow key={p.sku} className={cn(i % 2 === 1 && "bg-muted/30")}>
                      <TableCell className="font-mono text-xs text-primary">{p.sku}</TableCell>
                      <TableCell className="font-medium text-sm">{p.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{p.category}</TableCell>
                      <TableCell className="text-right tabular-nums text-sm font-medium">${p.price.toFixed(2)}</TableCell>
                      <TableCell className="text-right tabular-nums text-sm">
                        <span className={cn(p.stock < 50 && "text-[color:var(--warning)] font-medium")}>
                          {p.stock}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </UiTable>
            </div>
          </CardContent>
        </Card>

        {/* c) Hover-effect table */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--success)]/12 text-[color:var(--success)]">
                <TrendingUp className="h-4 w-4" />
              </span>
              Hover-Effect Table
            </CardTitle>
            <CardDescription className="text-xs">
              Each row lifts to a soft tinted background on hover — standard interactive treatment for clickable rows.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <UiTable>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="text-xs font-semibold">Region</TableHead>
                    <TableHead className="text-xs font-semibold text-right">Q1</TableHead>
                    <TableHead className="text-xs font-semibold text-right">Q2</TableHead>
                    <TableHead className="text-xs font-semibold text-right">Q3</TableHead>
                    <TableHead className="text-xs font-semibold text-right">Q4</TableHead>
                    <TableHead className="text-xs font-semibold text-right">FY Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {salesData.map((r) => (
                    <TableRow key={r.region} className="cursor-pointer">
                      <TableCell className="font-medium text-sm">{r.region}</TableCell>
                      <TableCell className="text-right tabular-nums text-sm text-muted-foreground">${fmt(r.q1)}</TableCell>
                      <TableCell className="text-right tabular-nums text-sm text-muted-foreground">${fmt(r.q2)}</TableCell>
                      <TableCell className="text-right tabular-nums text-sm text-muted-foreground">${fmt(r.q3)}</TableCell>
                      <TableCell className="text-right tabular-nums text-sm text-muted-foreground">${fmt(r.q4)}</TableCell>
                      <TableCell className="text-right tabular-nums text-sm font-semibold">${fmt(r.total)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </UiTable>
            </div>
          </CardContent>
        </Card>

        {/* d) Bordered cells table */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <span className="grid place-items-center h-7 w-7 rounded-lg bg-violet-500/12 text-violet-500">
                <Grid2x2 className="h-4 w-4" />
              </span>
              Bordered Cells Table
            </CardTitle>
            <CardDescription className="text-xs">
              Every cell carries its own border, producing a structured grid look — great for dense activity logs.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <UiTable className="[&_td]:border-r [&_td]:border-border [&_td:last-child]:border-r-0 [&_th]:border-r [&_th]:border-border [&_th:last-child]:border-r-0">
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40 border-b border-border">
                    <TableHead className="text-xs font-semibold w-28">Timestamp</TableHead>
                    <TableHead className="text-xs font-semibold w-28">User</TableHead>
                    <TableHead className="text-xs font-semibold w-44">Action</TableHead>
                    <TableHead className="text-xs font-semibold">Target</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activityData.map((a, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-mono text-xs text-muted-foreground">{a.ts}</TableCell>
                      <TableCell className="font-mono text-xs text-primary">{a.user}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{a.action}</TableCell>
                      <TableCell className="font-mono text-xs">{a.target}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </UiTable>
            </div>
          </CardContent>
        </Card>

        {/* e) Compact table */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--warning)]/15 text-[color:var(--warning)]">
                <Minimize2 className="h-4 w-4" />
              </span>
              Compact Table
            </CardTitle>
            <CardDescription className="text-xs">
              Tightened padding (<code className="text-[11px] bg-muted px-1 py-0.5 rounded">py-1.5</code>) and reduced font sizes — packs ~40% more rows into the same vertical space.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <UiTable className="[&_td]:py-1.5 [&_td]:px-2 [&_th]:py-1.5 [&_th]:px-2">
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="text-[11px] font-semibold uppercase tracking-wide">SKU</TableHead>
                    <TableHead className="text-[11px] font-semibold uppercase tracking-wide">Product</TableHead>
                    <TableHead className="text-[11px] font-semibold uppercase tracking-wide">Category</TableHead>
                    <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-right">Price</TableHead>
                    <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-right">Stock</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productsData.map((p) => (
                    <TableRow key={p.sku}>
                      <TableCell className="font-mono text-[11px] text-primary">{p.sku}</TableCell>
                      <TableCell className="text-xs font-medium">{p.name}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{p.category}</TableCell>
                      <TableCell className="text-right tabular-nums text-xs font-medium">${p.price.toFixed(2)}</TableCell>
                      <TableCell className="text-right tabular-nums text-xs">
                        <span className={cn(p.stock < 50 && "text-[color:var(--warning)] font-medium")}>
                          {p.stock}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </UiTable>
            </div>
          </CardContent>
        </Card>

        {/* Style legend strip */}
        <Card>
          <CardContent className="pt-5">
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Quick reference:</span>
              {[
                { icon: Hash, label: "Bordered", color: "bg-primary/10 text-primary" },
                { icon: Rows3, label: "Striped", color: "bg-[color:var(--info)]/12 text-[color:var(--info)]" },
                { icon: Users, label: "Hover", color: "bg-[color:var(--success)]/12 text-[color:var(--success)]" },
                { icon: Grid2x2, label: "Cell-bordered", color: "bg-violet-500/12 text-violet-500" },
                { icon: Minimize2, label: "Compact", color: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" },
              ].map((s) => (
                <div key={s.label} className="inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1 text-xs">
                  <span className={cn("grid place-items-center h-5 w-5 rounded", s.color)}>
                    <s.icon className="h-3 w-3" />
                  </span>
                  <span className="text-foreground">{s.label}</span>
                </div>
              ))}
              <div className="ml-auto flex items-center gap-2 text-xs text-muted-foreground">
                <Package className="h-3.5 w-3.5" />
                <span>5 styles · 27 rows total · all built on <code className="text-[11px] bg-muted px-1 py-0.5 rounded">@/components/ui/table</code></span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
