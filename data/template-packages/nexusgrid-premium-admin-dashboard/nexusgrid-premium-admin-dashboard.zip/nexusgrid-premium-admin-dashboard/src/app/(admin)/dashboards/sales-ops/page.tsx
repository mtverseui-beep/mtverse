"use client";

import * as React from "react";
import {
  TrendingUp,
  Target,
  Gauge,
  Scale,
  Filter,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  Trophy,
  Crown,
  ChevronRight,
  MapPin,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LineTrendChart, BarTrendChart } from "@/components/charts";
import { salesReps, months } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline sales-ops data (not shared with CRM) ---------- */

// Weighted forecast vs. actual across 12 months (in $K)
const forecastVsActual = months.map((m, i) => {
  const base = 320 + i * 14;
  const noise = Math.round(Math.sin(i * 0.9) * 28);
  const forecast = base + 18;
  const actual = i <= 6 ? base + noise - 4 : base + noise + 22; // actual under-performed early, beat forecast late
  return { month: m, forecast, actual };
});

// Stage funnel — distinct from CRM (Lead→Qualified→Proposal→Negotiation→Won)
const stageFunnel = [
  { stage: "Lead", count: 524, value: 5240000, color: "var(--info)" },
  { stage: "Qualified", count: 318, value: 3860000, color: "oklch(0.58 0.13 250)" },
  { stage: "Proposal", count: 184, value: 2640000, color: "var(--primary)" },
  { stage: "Negotiation", count: 96, value: 1820000, color: "oklch(0.70 0.15 75)" },
  { stage: "Won", count: 62, value: 1240000, color: "var(--success)" },
];

// Avg days in each stage — for aging bar chart
const stageAging = [
  { stage: "Lead", days: 6 },
  { stage: "Qualified", days: 14 },
  { stage: "Proposal", days: 22 },
  { stage: "Negotiation", days: 31 },
  { stage: "Closed-Won", days: 9 },
];

// Territory performance
const territories = [
  { name: "North America", rep: "Sarah Chen", revenue: 1284000, deals: 86, attainment: 112, tone: "success" as StatusTone },
  { name: "EMEA", rep: "Elena Petrov", revenue: 968000, deals: 64, attainment: 104, tone: "success" as StatusTone },
  { name: "APAC", rep: "Aiko Tanaka", revenue: 742000, deals: 52, attainment: 96, tone: "warning" as StatusTone },
  { name: "LATAM", rep: "Marcus Reyes", revenue: 418000, deals: 38, attainment: 82, tone: "warning" as StatusTone },
  { name: "ANZ", rep: "James Okoro", revenue: 286000, deals: 24, attainment: 74, tone: "danger" as StatusTone },
];

/* ---------- Sales Ops KPI card — competitive leaderboard vibe ---------- */
// Distinct from KpiCard (sparkline) and CrmKpiCard (accent edge + secondary):
// this card uses a bottom progress bar showing % attainment vs. quota.

function SalesKpiCard({
  label,
  value,
  icon: Icon,
  trend,
  quota,
  attainment,
  accent,
  trendSuffix = "%",
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  quota: string;
  attainment: number; // 0-150 normalized to bar width
  accent: "primary" | "info" | "warning" | "success";
  trendSuffix?: string;
}) {
  const accentBg: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
  };
  const accentBar: Record<string, string> = {
    primary: "from-primary/80 to-primary",
    info: "from-[color:var(--info)]/80 to-[color:var(--info)]",
    warning: "from-[color:var(--warning)]/80 to-[color:var(--warning)]",
    success: "from-[color:var(--success)]/80 to-[color:var(--success)]",
  };
  // Attainment bar capped at 100% width
  const barWidth = Math.min(100, attainment);
  const overQuota = attainment >= 100;

  return (
    <div className="group relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm hover:border-primary/30">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">{label}</p>
          <p className="mt-1.5 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
        </div>
        <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentBg[accent])}>
          <Icon className="h-4.5 w-4.5" />
        </div>
      </div>

      {/* Quota attainment bar — leaderboard vibe */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1.5">
          <span>vs. quota {quota}</span>
          <span className={cn("font-semibold tabular-nums", overQuota ? "text-[color:var(--success)]" : "text-foreground")}>
            {attainment}%
          </span>
        </div>
        <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
          <div
            className={cn("h-full rounded-full bg-gradient-to-r transition-all duration-700 ease-out", accentBar[accent])}
            style={{ width: `${barWidth}%` }}
          />
        </div>
      </div>

      {/* Trend pill */}
      <div className="mt-3 flex items-center gap-1.5">
        <span
          className={cn(
            "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium",
            trend.positive
              ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
              : "bg-destructive/12 text-destructive"
          )}
        >
          {trend.direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {Math.abs(trend.value)}{trendSuffix}
        </span>
        <span className="text-xs text-muted-foreground">vs. last quarter</span>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function SalesOpsDashboardPage() {
  // Sort reps by attainment descending for leaderboard
  const leaderboard = [...salesReps]
    .map((r) => ({ ...r, attainmentPct: Math.round((r.attainment / r.quota) * 100) }))
    .sort((a, b) => b.attainmentPct - a.attainmentPct);
  const topPerformer = leaderboard[0];

  // Funnel conversions
  const maxFunnelCount = stageFunnel[0].count;
  const totalFunnelValue = stageFunnel.reduce((s, x) => s + x.value, 0);

  return (
    <>
      <PageHeader
        title="Sales Ops Dashboard"
        description="Forecast accuracy, rep attainment, and pipeline velocity across the sales org."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Sales Ops" }]}
        icon={TrendingUp}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Q2 2026
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5">
              <Target className="h-3.5 w-3.5" /> Set quota
            </Button>
          </>
        }
      />

      {/* KPI Row — SalesKpiCard with quota attainment bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <SalesKpiCard
          label="Pipeline Value"
          value="$4.2M"
          icon={TrendingUp}
          accent="primary"
          quota="$3.8M"
          attainment={111}
          trend={{ value: 12, direction: "up", positive: true }}
        />
        <SalesKpiCard
          label="Quota Attainment"
          value="94%"
          icon={Target}
          accent="success"
          quota="$2.4M"
          attainment={94}
          trend={{ value: 6, direction: "up", positive: true }}
        />
        <SalesKpiCard
          label="Forecast Accuracy"
          value="91%"
          icon={Gauge}
          accent="info"
          quota="100%"
          attainment={91}
          trend={{ value: 3, direction: "up", positive: true }}
        />
        <SalesKpiCard
          label="Win/Loss Ratio"
          value="1.8"
          icon={Scale}
          accent="warning"
          quota="2.0"
          attainment={90}
          trend={{ value: 0.2, direction: "up", positive: true }}
          trendSuffix=""
        />
      </div>

      {/* Forecast chart + Leaderboard */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Weighted Forecast vs. Actual
              </CardTitle>
              <CardDescription>Monthly forecast accuracy across the trailing 12 months.</CardDescription>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--info)]" /> Forecast
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" /> Actual
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <LineTrendChart
              data={forecastVsActual}
              xKey="month"
              series={[
                { key: "forecast", name: "Forecast ($K)", color: "var(--info)", dashed: true },
                { key: "actual", name: "Actual ($K)", color: "var(--primary)" },
              ]}
              height={300}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Avg Forecast</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">
                  ${(forecastVsActual.reduce((s, x) => s + x.forecast, 0) / 12).toFixed(0)}K
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Avg Actual</p>
                <p className="text-sm font-semibold text-primary tabular-nums mt-0.5">
                  ${(forecastVsActual.reduce((s, x) => s + x.actual, 0) / 12).toFixed(0)}K
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Variance</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">+4.2%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sales rep leaderboard */}
        <Card className="relative overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Trophy className="h-4 w-4 text-[color:var(--warning)]" />
              Rep Leaderboard
            </CardTitle>
            <CardDescription>By quota attainment this quarter.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[380px] overflow-y-auto pr-1 custom-scroll">
            {leaderboard.map((rep, i) => {
              const isTop = i === 0;
              return (
                <div
                  key={rep.name}
                  className={cn(
                    "relative flex items-center gap-3 rounded-lg border p-3 transition-colors",
                    isTop
                      ? "border-[color:var(--warning)]/30 bg-[color:var(--warning)]/[0.06]"
                      : "border-border bg-muted/20 hover:bg-muted/40"
                  )}
                >
                  {/* Rank badge */}
                  <div
                    className={cn(
                      "grid place-items-center h-7 w-7 rounded-md shrink-0 text-xs font-bold tabular-nums",
                      isTop
                        ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]"
                        : i === 1
                        ? "bg-muted text-muted-foreground"
                        : i === 2
                        ? "bg-[color:var(--info)]/15 text-[color:var(--info)]"
                        : "bg-muted text-muted-foreground"
                    )}
                  >
                    {isTop ? <Crown className="h-3.5 w-3.5" /> : i + 1}
                  </div>

                  <Avatar className="h-9 w-9 shrink-0 ring-2 ring-card">
                    <AvatarImage src={rep.avatar} alt={rep.name} />
                    <AvatarFallback className="text-[10px]">
                      {rep.name.split(" ").map((n) => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium text-foreground truncate">{rep.name}</p>
                      <span
                        className={cn(
                          "text-sm font-semibold tabular-nums shrink-0",
                          rep.attainmentPct >= 100 ? "text-[color:var(--success)]" : "text-foreground"
                        )}
                      >
                        {rep.attainmentPct}%
                      </span>
                    </div>
                    <div className="mt-1 flex items-center gap-2">
                      <div className="h-1.5 flex-1 rounded-full bg-muted overflow-hidden">
                        <div
                          className={cn(
                            "h-full rounded-full transition-all duration-700 ease-out",
                            isTop
                              ? "bg-gradient-to-r from-[color:var(--warning)]/70 to-[color:var(--warning)]"
                              : rep.attainmentPct >= 100
                              ? "bg-[color:var(--success)]"
                              : "bg-primary"
                          )}
                          style={{ width: `${Math.min(100, rep.attainmentPct)}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-muted-foreground tabular-nums w-12 text-right">
                        ${(rep.attainment / 1000).toFixed(0)}K
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
            {/* Top performer callout */}
            <div className="mt-3 rounded-lg border border-[color:var(--warning)]/30 bg-[color:var(--warning)]/[0.06] p-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wide mb-1">
                <Crown className="h-3.5 w-3.5 text-[color:var(--warning)]" />
                Top Performer
              </div>
              <p className="text-sm font-medium text-foreground">
                {topPerformer.name} hit {topPerformer.attainmentPct}% of quota
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {topPerformer.deals} deals closed · {topPerformer.winRate}% win rate
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Stage conversion funnel — full width, horizontal stacked bars + arrows */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-start justify-between gap-2 pb-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="h-4 w-4 text-primary" />
              Stage Conversion Funnel
            </CardTitle>
            <CardDescription>
              Lead → Won progression with stage-to-stage conversion rates.{" "}
              <span className="text-foreground font-medium tabular-nums">${(totalFunnelValue / 1000000).toFixed(2)}M</span>{" "}
              total pipeline value.
            </CardDescription>
          </div>
          <StatusBadge tone="primary" dot>{stageFunnel[0].count} leads</StatusBadge>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {stageFunnel.map((stage, i) => {
              const widthPct = (stage.count / maxFunnelCount) * 100;
              const prevCount = i === 0 ? stage.count : stageFunnel[i - 1].count;
              const conversion = i === 0 ? 100 : (stage.count / prevCount) * 100;
              const isLast = i === stageFunnel.length - 1;
              return (
                <React.Fragment key={stage.stage}>
                  <div className="grid grid-cols-1 sm:grid-cols-[140px_1fr_120px] items-center gap-3 py-2">
                    {/* Stage label */}
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="h-2.5 w-2.5 rounded-sm shrink-0" style={{ background: stage.color }} />
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{stage.stage}</p>
                        <p className="text-[10px] text-muted-foreground tabular-nums">
                          ${(stage.value / 1000000).toFixed(2)}M
                        </p>
                      </div>
                    </div>

                    {/* Horizontal bar — width proportional to count */}
                    <div className="relative h-9 rounded-lg bg-muted/40 overflow-hidden">
                      <div
                        className="absolute inset-y-0 left-0 rounded-lg transition-all duration-700 ease-out flex items-center justify-end pr-2"
                        style={{ width: `${Math.max(widthPct, 8)}%`, background: stage.color, opacity: 0.9 }}
                      >
                        <span className="text-[11px] font-semibold text-white tabular-nums drop-shadow-sm">
                          {stage.count}
                        </span>
                      </div>
                    </div>

                    {/* Conversion % */}
                    <div className="flex items-center justify-end gap-1.5 text-xs">
                      {i > 0 && (
                        <>
                          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
                          <span
                            className={cn(
                              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 font-medium tabular-nums",
                              conversion >= 50
                                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                                : conversion >= 30
                                ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]"
                                : "bg-destructive/12 text-destructive"
                            )}
                          >
                            <ArrowDownRight className="h-3 w-3" />
                            {conversion.toFixed(1)}%
                          </span>
                        </>
                      )}
                      {i === 0 && (
                        <span className="text-xs text-muted-foreground tabular-nums">entry</span>
                      )}
                    </div>
                  </div>
                  {!isLast && <div className="h-px bg-border/60" />}
                </React.Fragment>
              );
            })}
          </div>
          <div className="mt-4 pt-3 border-t border-border grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Overall Conversion</p>
              <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                {((stageFunnel[4].count / stageFunnel[0].count) * 100).toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Avg Stage Drop</p>
              <p className="text-sm font-semibold tabular-nums mt-0.5">42.6%</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Bottleneck Stage</p>
              <p className="text-sm font-semibold text-[color:var(--warning)] mt-0.5">Negotiation</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Deals Won</p>
              <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">62</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Deal aging + Territory performance */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Gauge className="h-4 w-4 text-[color:var(--warning)]" />
              Deal Aging Analysis
            </CardTitle>
            <CardDescription>Avg days deals spend in each pipeline stage.</CardDescription>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={stageAging}
              xKey="stage"
              series={[
                { key: "days", name: "Avg Days", color: "var(--warning)" },
              ]}
              height={260}
            />
            <div className="mt-3 pt-3 border-t border-border flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Slowest stage</span>
              <span className="font-medium text-[color:var(--warning)]">Negotiation · 31 days</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                Territory Performance
              </CardTitle>
              <CardDescription>Revenue and attainment by region this quarter.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Territory</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Revenue</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Deals</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Attainment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {territories.map((t) => (
                    <tr key={t.name} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2 min-w-0">
                          <MapPin className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                          <div className="min-w-0">
                            <p className="font-medium text-foreground truncate">{t.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{t.rep}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums font-medium">
                        ${(t.revenue / 1000).toFixed(0)}K
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums hidden sm:table-cell">{t.deals}</td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="hidden sm:block h-1.5 w-14 rounded-full bg-muted overflow-hidden">
                            <div
                              className={cn(
                                "h-full rounded-full transition-all duration-700 ease-out",
                                t.attainment >= 100 ? "bg-[color:var(--success)]" : t.attainment >= 90 ? "bg-[color:var(--warning)]" : "bg-destructive"
                              )}
                              style={{ width: `${Math.min(100, t.attainment)}%` }}
                            />
                          </div>
                          <StatusBadge tone={t.tone} className="tabular-nums">{t.attainment}%</StatusBadge>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
