"use client";

import * as React from "react";
import {
  CreditCard,
  Lock,
  Wallet,
  Building2,
  Bitcoin,
  CheckCircle2,
  Loader2,
  ShieldCheck,
  Receipt,
  ArrowLeft,
  Download,
  Printer,
  Mail,
  User,
  MapPin,
  Globe,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type CardType = "visa" | "mastercard" | "amex" | "discover" | "unknown";

function detectCard(num: string): CardType {
  const n = num.replace(/\s/g, "");
  if (/^4/.test(n)) return "visa";
  if (/^5[1-5]/.test(n) || /^2[2-7]/.test(n)) return "mastercard";
  if (/^3[47]/.test(n)) return "amex";
  if (/^6(?:011|5)/.test(n)) return "discover";
  return "unknown";
}

function formatCardNumber(value: string): string {
  const digits = value.replace(/\D/g, "").slice(0, 16);
  return digits.replace(/(.{4})/g, "$1 ").trim();
}

function formatExpiry(value: string): string {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)}/${digits.slice(2)}`;
}

const CARD_BRAND: Record<CardType, { label: string; gradient: string }> = {
  visa: { label: "VISA", gradient: "from-indigo-600 to-blue-700" },
  mastercard: { label: "MASTERCARD", gradient: "from-orange-500 to-red-600" },
  amex: { label: "AMEX", gradient: "from-teal-600 to-emerald-700" },
  discover: { label: "DISCOVER", gradient: "from-amber-500 to-orange-700" },
  unknown: { label: "AURORA", gradient: "from-zinc-700 to-zinc-900" },
};

const METHODS = [
  { v: "card", label: "Card", icon: CreditCard },
  { v: "paypal", label: "PayPal", icon: Wallet },
  { v: "bank", label: "Bank", icon: Building2 },
  { v: "crypto", label: "Crypto", icon: Bitcoin },
];

export default function PaymentFormPage() {
  const [method, setMethod] = React.useState("card");
  const [number, setNumber] = React.useState("");
  const [name, setName] = React.useState("");
  const [expiry, setExpiry] = React.useState("");
  const [cvv, setCvv] = React.useState("");
  const [cvvFocused, setCvvFocused] = React.useState(false);
  const [currency, setCurrency] = React.useState("USD");
  const [amount, setAmount] = React.useState("248.00");
  const [saveCard, setSaveCard] = React.useState(true);
  const [processing, setProcessing] = React.useState(false);
  const [receipt, setReceipt] = React.useState<null | {
    id: string;
    method: string;
    amount: string;
    currency: string;
    date: Date;
    last4: string;
  }>(null);

  const brand = detectCard(number);
  const brandInfo = CARD_BRAND[brand];

  const canPay =
    method === "card"
      ? number.replace(/\s/g, "").length >= 15 && name.length > 1 && expiry.length === 5 && cvv.length >= 3
      : true;

  const pay = () => {
    if (!canPay) {
      toast.error("Please complete all card fields");
      return;
    }
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      const id = `PAY-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
      setReceipt({
        id,
        method: METHODS.find((m) => m.v === method)?.label ?? "Card",
        amount,
        currency,
        date: new Date(),
        last4: method === "card" ? number.replace(/\s/g, "").slice(-4) : "—",
      });
      toast.success("Payment successful", {
        description: `${currency} ${amount} · ${id}`,
      });
    }, 1800);
  };

  if (receipt) {
    return (
      <>
        <PageHeader
          title="Payment Form"
          description="Premium checkout with card preview, multiple payment methods and live receipt."
          breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Payment Form" }]}
          icon={CreditCard}
        />
        <Card className="max-w-lg mx-auto">
          <CardHeader className="text-center items-center">
            <div className="grid place-items-center h-14 w-14 rounded-full bg-emerald-500/10 text-emerald-500 mb-1">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <CardTitle>Payment received</CardTitle>
            <CardDescription>Your transaction has been processed successfully.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="rounded-lg border bg-muted/30 p-4 grid gap-2.5 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Receipt ID</span>
                <span className="font-mono font-medium">{receipt.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-semibold tabular-nums">{receipt.currency} {receipt.amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Method</span>
                <span className="font-medium">{receipt.method}{receipt.last4 !== "—" && ` ···· ${receipt.last4}`}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Date</span>
                <span className="font-medium">{receipt.date.toLocaleString()}</span>
              </div>
              <Separator />
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">Paid</Badge>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Receipt downloaded")}>
                <Download className="h-3.5 w-3.5" /> Download
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Receipt sent to email")}>
                <Mail className="h-3.5 w-3.5" /> Email
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Print dialog opened")}>
                <Printer className="h-3.5 w-3.5" /> Print
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="gap-1.5"
              onClick={() => {
                setReceipt(null);
                setNumber(""); setName(""); setExpiry(""); setCvv("");
              }}
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Make another payment
            </Button>
          </CardContent>
        </Card>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Payment Form"
        description="Premium checkout with card preview, multiple payment methods and live receipt."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Payment Form" }]}
        icon={CreditCard}
        actions={
          <Badge variant="outline" className="text-[10px] gap-1">
            <Lock className="h-3 w-3" /> 256-bit TLS secured
          </Badge>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* PAYMENT DETAILS */}
        <div className="lg:col-span-3 grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Payment method</CardTitle>
              <CardDescription>Choose how you'd like to pay. All methods are encrypted end-to-end.</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={method} onValueChange={setMethod}>
                <TabsList className="grid grid-cols-4 w-full h-auto">
                  {METHODS.map((m) => (
                    <TabsTrigger key={m.v} value={m.v} className="flex-col py-2 gap-1 text-[11px]">
                      <m.icon className="h-4 w-4" />
                      {m.label}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {/* CARD */}
                <TabsContent value="card" className="mt-4 grid gap-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="grid gap-1.5 sm:col-span-2">
                      <Label className="text-xs flex items-center gap-1.5">
                        <CreditCard className="h-3.5 w-3.5 text-muted-foreground" /> Card number
                      </Label>
                      <div className="relative">
                        <Input
                          value={number}
                          onChange={(e) => setNumber(formatCardNumber(e.target.value))}
                          placeholder="4242 4242 4242 4242"
                          inputMode="numeric"
                          className="font-mono pr-16"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold tracking-wider text-muted-foreground">
                          {brand !== "unknown" && CARD_BRAND[brand].label}
                        </span>
                      </div>
                    </div>
                    <div className="grid gap-1.5 sm:col-span-2">
                      <Label className="text-xs flex items-center gap-1.5">
                        <User className="h-3.5 w-3.5 text-muted-foreground" /> Name on card
                      </Label>
                      <Input
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Sarah Chen"
                      />
                    </div>
                    <div className="grid gap-1.5">
                      <Label className="text-xs">Expiry (MM/YY)</Label>
                      <Input
                        value={expiry}
                        onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                        placeholder="08/27"
                        inputMode="numeric"
                        className="font-mono"
                      />
                    </div>
                    <div className="grid gap-1.5">
                      <Label className="text-xs flex items-center gap-1.5">
                        <Lock className="h-3.5 w-3.5 text-muted-foreground" /> CVV
                      </Label>
                      <Input
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
                        onFocus={() => setCvvFocused(true)}
                        onBlur={() => setCvvFocused(false)}
                        placeholder="123"
                        inputMode="numeric"
                        className="font-mono"
                        type="password"
                      />
                    </div>
                  </div>
                  <Label className="flex items-start gap-2.5 text-xs font-normal cursor-pointer rounded-md border p-3">
                    <Checkbox checked={saveCard} onCheckedChange={(v) => setSaveCard(!!v)} className="mt-0.5" />
                    <span>
                      <span className="font-medium">Save this card for faster checkout</span>
                      <br />
                      <span className="text-muted-foreground">Your card is encrypted with AES-256 and tokenised.</span>
                    </span>
                  </Label>
                </TabsContent>

                {/* PAYPAL */}
                <TabsContent value="paypal" className="mt-4">
                  <div className="grid place-items-center text-center gap-3 py-6 rounded-lg border bg-muted/30">
                    <div className="grid place-items-center h-12 w-12 rounded-full bg-[#003087] text-white">
                      <Wallet className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Continue with PayPal</p>
                      <p className="text-xs text-muted-foreground mt-1 max-w-xs">You'll be redirected to PayPal to securely complete your purchase.</p>
                    </div>
                    <Button className="gap-1.5 bg-[#0070ba] hover:bg-[#0070ba]/90">
                      <Wallet className="h-4 w-4" /> Pay with PayPal
                    </Button>
                  </div>
                </TabsContent>

                {/* BANK */}
                <TabsContent value="bank" className="mt-4 grid gap-4">
                  <div className="rounded-lg border bg-muted/30 p-3 flex items-start gap-2.5 text-xs">
                    <Building2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <p className="text-muted-foreground">
                      Bank transfers take <span className="font-medium text-foreground">1-3 business days</span> to settle. Your order ships once payment is confirmed.
                    </p>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="grid gap-1.5">
                      <Label className="text-xs">Account holder</Label>
                      <Input placeholder="Aurora Labs Inc." defaultValue="Aurora Labs Inc." />
                    </div>
                    <div className="grid gap-1.5">
                      <Label className="text-xs">Bank name</Label>
                      <Input placeholder="First Republic Bank" defaultValue="First Republic Bank" />
                    </div>
                    <div className="grid gap-1.5">
                      <Label className="text-xs">Routing number</Label>
                      <Input placeholder="321081669" className="font-mono" defaultValue="321081669" />
                    </div>
                    <div className="grid gap-1.5">
                      <Label className="text-xs">Account number</Label>
                      <Input placeholder="8001234567" className="font-mono" defaultValue="8001234567" />
                    </div>
                  </div>
                </TabsContent>

                {/* CRYPTO */}
                <TabsContent value="crypto" className="mt-4 grid gap-4">
                  <div className="grid sm:grid-cols-3 gap-2">
                    {[
                      { sym: "BTC", name: "Bitcoin", addr: "bc1qxy...aurora" },
                      { sym: "ETH", name: "Ethereum", addr: "0x7Ab3...aurora" },
                      { sym: "USDC", name: "USD Coin", addr: "0x7Ab3...aurora" },
                    ].map((c, i) => (
                      <button
                        key={c.sym}
                        type="button"
                        onClick={() => setMethod("crypto")}
                        className={cn(
                          "rounded-lg border p-3 text-left transition-colors",
                          i === 0 ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "hover:bg-accent/40"
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold">{c.sym}</span>
                          {i === 0 && <CheckCircle2 className="h-3.5 w-3.5 text-primary" />}
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-0.5">{c.name}</p>
                        <p className="text-[10px] font-mono text-muted-foreground mt-1 truncate">{c.addr}</p>
                      </button>
                    ))}
                  </div>
                  <div className="rounded-lg border bg-muted/30 p-3 text-xs">
                    <p className="text-muted-foreground">
                      Send the exact amount of <span className="font-medium text-foreground">{currency} {amount}</span> worth of{" "}
                      <span className="font-medium text-foreground">BTC</span> to the address above. The exchange rate is locked for 30 minutes.
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* BILLING ADDRESS */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" /> Billing address
              </CardTitle>
              <CardDescription>The address associated with your payment method.</CardDescription>
            </CardHeader>
            <CardContent className="grid sm:grid-cols-2 gap-4">
              <div className="grid gap-1.5 sm:col-span-2">
                <Label className="text-xs">Street address</Label>
                <Input placeholder="1140 Mission St, Suite 400" defaultValue="1140 Mission St, Suite 400" />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">City</Label>
                <Input placeholder="San Francisco" defaultValue="San Francisco" />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">State / Province</Label>
                <Input placeholder="CA" defaultValue="CA" />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Postal code</Label>
                <Input placeholder="94103" defaultValue="94103" className="font-mono" />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs flex items-center gap-1.5">
                  <Globe className="h-3.5 w-3.5 text-muted-foreground" /> Country
                </Label>
                <Select defaultValue="us">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">United States</SelectItem>
                    <SelectItem value="ca">Canada</SelectItem>
                    <SelectItem value="uk">United Kingdom</SelectItem>
                    <SelectItem value="de">Germany</SelectItem>
                    <SelectItem value="fr">France</SelectItem>
                    <SelectItem value="jp">Japan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* ORDER SUMMARY + CARD PREVIEW */}
        <div className="lg:col-span-2 grid gap-6">
          {/* CARD PREVIEW */}
          <div className="lg:sticky lg:top-4 grid gap-4">
            <div
              className="relative h-52 w-full rounded-2xl shadow-xl [perspective:1000px]"
              aria-label="Credit card preview"
            >
              <div
                className={cn(
                  "absolute inset-0 [transform-style:preserve-3d] transition-transform duration-700",
                  cvvFocused && "[transform:rotateY(180deg)]"
                )}
              >
                {/* FRONT */}
                <div className={cn("absolute inset-0 [backface-visibility:hidden] rounded-2xl bg-gradient-to-br p-5 flex flex-col justify-between text-white", brandInfo.gradient)}>
                  <div className="flex items-start justify-between">
                    <div className="grid place-items-center h-9 w-12 rounded-md bg-yellow-300/90">
                      <span className="h-6 w-8 rounded-sm border-2 border-yellow-300/0 [background:linear-gradient(135deg,#fcd34d_50%,transparent_50)]" />
                    </div>
                    <div className="grid place-items-center h-9 w-9 rounded-full bg-white/20 backdrop-blur">
                      <CreditCard className="h-4 w-4" />
                    </div>
                  </div>
                  <div className="font-mono text-lg tracking-widest tabular-nums drop-shadow">
                    {number || "•••• •••• •••• ••••"}
                  </div>
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-[9px] uppercase tracking-wider opacity-70">Card holder</p>
                      <p className="text-xs font-medium uppercase tracking-wide">{name || "YOUR NAME"}</p>
                    </div>
                    <div>
                      <p className="text-[9px] uppercase tracking-wider opacity-70">Expires</p>
                      <p className="text-xs font-mono">{expiry || "MM/YY"}</p>
                    </div>
                    <span className="text-sm font-bold tracking-wider">{brandInfo.label}</span>
                  </div>
                </div>
                {/* BACK */}
                <div className={cn("absolute inset-0 [backface-visibility:hidden] [transform:rotateY(180deg)] rounded-2xl bg-gradient-to-br p-5 flex flex-col text-white", brandInfo.gradient)}>
                  <div className="h-9 -mx-5 mt-2 bg-black/80" />
                  <div className="mt-4">
                    <p className="text-[9px] uppercase tracking-wider opacity-70 mb-1">CVV</p>
                    <div className="h-7 rounded bg-white/90 text-black flex items-center justify-end px-3 font-mono text-sm">
                      {cvv || "•••"}
                    </div>
                  </div>
                  <div className="mt-auto">
                    <p className="text-[10px] opacity-70">This card is property of Aurora Bank. If found, please return to the address on the back.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* ORDER SUMMARY */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Receipt className="h-4 w-4 text-primary" /> Order summary
                </CardTitle>
              </CardHeader>
              <CardContent className="grid gap-3">
                <div className="grid gap-2 text-xs">
                  {[
                    { l: "Aurora Wireless Headphones", v: "189.00" },
                    { l: "Premium case", v: "29.00" },
                    { l: "Extended warranty (2yr)", v: "24.00" },
                  ].map((row) => (
                    <div key={row.l} className="flex justify-between">
                      <span className="text-muted-foreground">{row.l}</span>
                      <span className="tabular-nums">{row.v}</span>
                    </div>
                  ))}
                </div>
                <Separator />
                <div className="grid gap-2 text-xs">
                  <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span className="tabular-nums">242.00</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span className="tabular-nums">6.00</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Tax (8.5%)</span><span className="tabular-nums">20.57</span></div>
                </div>
                <Separator />
                {/* AMOUNT + CURRENCY */}
                <div className="grid grid-cols-[1fr_auto] gap-2 items-end">
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Amount</Label>
                    <div className="relative">
                      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">{currency === "USD" ? "$" : currency === "EUR" ? "€" : currency === "GBP" ? "£" : "$"}</span>
                      <Input
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="pl-7 font-mono tabular-nums"
                      />
                    </div>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Currency</Label>
                    <Select value={currency} onValueChange={setCurrency}>
                      <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="GBP">GBP</SelectItem>
                        <SelectItem value="JPY">JPY</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-2 border-t">
                  <span className="text-sm font-medium">Total</span>
                  <span className="text-lg font-semibold tabular-nums">{currency} {amount}</span>
                </div>

                <Button
                  size="lg"
                  className="w-full gap-2 mt-1"
                  disabled={processing || !canPay}
                  onClick={pay}
                >
                  {processing ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Processing…
                    </>
                  ) : (
                    <>
                      <Lock className="h-4 w-4" /> Pay {currency} {amount}
                    </>
                  )}
                </Button>
                <div className="flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground">
                  <ShieldCheck className="h-3 w-3" />
                  Secured by 256-bit TLS · PCI DSS compliant
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
