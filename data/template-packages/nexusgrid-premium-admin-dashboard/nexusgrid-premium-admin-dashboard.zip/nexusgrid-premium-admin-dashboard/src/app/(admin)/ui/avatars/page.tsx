"use client";

import * as React from "react";
import {
  CircleUser,
  Users,
  Plus,
  Settings,
  MoreHorizontal,
  Shield,
  Crown,
  Briefcase,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const team = [
  {
    name: "Amara Reyes",
    role: "Product Designer",
    src: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&h=128&fit=crop",
    initials: "AR",
    status: "success" as const,
    statusLabel: "Online",
  },
  {
    name: "Devon Park",
    role: "Engineering Lead",
    src: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop",
    initials: "DP",
    status: "warning" as const,
    statusLabel: "Away",
  },
  {
    name: "Priya Shah",
    role: "Customer Success",
    src: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=128&h=128&fit=crop",
    initials: "PS",
    status: "neutral" as const,
    statusLabel: "Offline",
  },
  {
    name: "Marco Bianchi",
    role: "Backend Engineer",
    src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=128&h=128&fit=crop",
    initials: "MB",
    status: "success" as const,
    statusLabel: "Online",
  },
  {
    name: "Yuki Tanaka",
    role: "UX Researcher",
    src: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=128&h=128&fit=crop",
    initials: "YT",
    status: "info" as const,
    statusLabel: "In meeting",
  },
];

const sizes = [
  { label: "Extra small", className: "h-6 w-6", textClass: "text-[10px]" },
  { label: "Small", className: "h-8 w-8", textClass: "text-xs" },
  { label: "Medium", className: "h-10 w-10", textClass: "text-sm" },
  { label: "Large", className: "h-14 w-14", textClass: "text-base" },
  { label: "Extra large", className: "h-20 w-20", textClass: "text-xl" },
];

function StatusDot({ tone, ring = "ring-background" }: { tone: string; ring?: string }) {
  return (
    <span
      className={cn(
        "absolute bottom-0 right-0 block h-3 w-3 rounded-full ring-2",
        tone,
        ring
      )}
    />
  );
}

export default function AvatarsPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Avatars"
        description="User representations — sizes, fallbacks, status dots, rings, shapes and stacked groups."
        icon={CircleUser}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/avatars" },
          { label: "Avatars" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Avatar component API copied")}>
            <Settings /> Component API
          </Button>
        }
      />

      {/* Sizes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Sizes</CardTitle>
          <CardDescription>
            Five sizes from extra-small (24px) to extra-large (80px), with image and fallback.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-end gap-6">
          {sizes.map((s) => (
            <div key={s.label} className="flex flex-col items-center gap-2">
              <Avatar className={s.className}>
                <AvatarImage src={team[0].src} alt={team[0].name} />
                <AvatarFallback className={s.textClass}>{team[0].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">{s.label}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Fallback initials */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Fallback initials</CardTitle>
          <CardDescription>
            When the image fails to load or is omitted, initials render on a muted background.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-4">
          {team.map((m) => (
            <Avatar key={m.name} className="h-12 w-12">
              <AvatarFallback>{m.initials}</AvatarFallback>
            </Avatar>
          ))}
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-primary/15 text-primary">NG</AvatarFallback>
          </Avatar>
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-[color:var(--success)]/15 text-[color:var(--success)]">
              AC
            </AvatarFallback>
          </Avatar>
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-violet-500/15 text-violet-500">VL</AvatarFallback>
          </Avatar>
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-amber-500/15 text-amber-600 dark:text-amber-400">
              AM
            </AvatarFallback>
          </Avatar>
        </CardContent>
      </Card>

      {/* Status dots */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Status indicators</CardTitle>
          <CardDescription>
            A status dot at the bottom-right of the avatar reflects presence.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-6">
          <div className="relative">
            <Avatar className="h-12 w-12">
              <AvatarImage src={team[0].src} alt={team[0].name} />
              <AvatarFallback>{team[0].initials}</AvatarFallback>
            </Avatar>
            <StatusDot tone="bg-[color:var(--success)]" />
          </div>
          <div className="relative">
            <Avatar className="h-12 w-12">
              <AvatarImage src={team[1].src} alt={team[1].name} />
              <AvatarFallback>{team[1].initials}</AvatarFallback>
            </Avatar>
            <StatusDot tone="bg-[color:var(--warning)]" />
          </div>
          <div className="relative">
            <Avatar className="h-12 w-12">
              <AvatarImage src={team[2].src} alt={team[2].name} />
              <AvatarFallback>{team[2].initials}</AvatarFallback>
            </Avatar>
            <StatusDot tone="bg-muted-foreground" />
          </div>
          <div className="relative">
            <Avatar className="h-12 w-12">
              <AvatarImage src={team[3].src} alt={team[3].name} />
              <AvatarFallback>{team[3].initials}</AvatarFallback>
            </Avatar>
            <StatusDot tone="bg-[color:var(--info)]" />
          </div>
          <div className="relative">
            <Avatar className="h-12 w-12">
              <AvatarImage src={team[4].src} alt={team[4].name} />
              <AvatarFallback>{team[4].initials}</AvatarFallback>
            </Avatar>
            <StatusDot tone="bg-destructive" />
          </div>
          <div className="h-px w-12 bg-border" />
          <div className="flex flex-col gap-1">
            {team.map((m) => (
              <div key={m.name} className="flex items-center gap-2.5">
                <Avatar className="h-7 w-7">
                  <AvatarImage src={m.src} alt={m.name} />
                  <AvatarFallback>{m.initials}</AvatarFallback>
                </Avatar>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{m.name}</span>
                  <StatusBadge tone={m.status} dot>
                    {m.statusLabel}
                  </StatusBadge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Rings + Shapes */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Avatar rings</CardTitle>
            <CardDescription>
              Use ring utilities to highlight selected, featured or verified users.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap items-center gap-6">
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 ring-2 ring-primary ring-offset-2 ring-offset-background">
                <AvatarImage src={team[0].src} alt={team[0].name} />
                <AvatarFallback>{team[0].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Primary</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 ring-2 ring-[color:var(--success)] ring-offset-2 ring-offset-background">
                <AvatarImage src={team[3].src} alt={team[3].name} />
                <AvatarFallback>{team[3].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Success</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 ring-2 ring-violet-500 ring-offset-2 ring-offset-background">
                <AvatarImage src={team[4].src} alt={team[4].name} />
                <AvatarFallback>{team[4].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Violet</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 ring-2 ring-amber-500 ring-offset-2 ring-offset-background">
                <AvatarImage src={team[2].src} alt={team[2].name} />
                <AvatarFallback>{team[2].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Amber</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 ring-2 ring-destructive ring-offset-2 ring-offset-background">
                <AvatarImage src={team[1].src} alt={team[1].name} />
                <AvatarFallback>{team[1].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Destructive</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Shapes</CardTitle>
            <CardDescription>
              Circle, rounded and square variants — match shape to your product language.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap items-center gap-6">
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14">
                <AvatarImage src={team[0].src} alt={team[0].name} />
                <AvatarFallback>{team[0].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Circle</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 rounded-lg">
                <AvatarImage src={team[1].src} alt={team[1].name} />
                <AvatarFallback>{team[1].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Rounded</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 rounded-md">
                <AvatarImage src={team[2].src} alt={team[2].name} />
                <AvatarFallback>{team[2].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Medium</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 rounded-none">
                <AvatarImage src={team[3].src} alt={team[3].name} />
                <AvatarFallback>{team[3].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Square</span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-14 w-14 rounded-xl">
                <AvatarImage src={team[4].src} alt={team[4].name} />
                <AvatarFallback>{team[4].initials}</AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground">Large radius</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Avatar groups */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Avatar groups</CardTitle>
          <CardDescription>
            Stacked overlapping avatars with a count indicator for large teams.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-10">
          <div className="flex flex-col items-center gap-3">
            <div className="flex -space-x-2">
              {team.slice(0, 3).map((m) => (
                <Avatar key={m.name} className="h-10 w-10 ring-2 ring-background">
                  <AvatarImage src={m.src} alt={m.name} />
                  <AvatarFallback>{m.initials}</AvatarFallback>
                </Avatar>
              ))}
            </div>
            <span className="text-xs text-muted-foreground">3 members</span>
          </div>

          <div className="flex flex-col items-center gap-3">
            <div className="flex -space-x-2">
              {team.map((m) => (
                <Avatar key={m.name} className="h-10 w-10 ring-2 ring-background">
                  <AvatarImage src={m.src} alt={m.name} />
                  <AvatarFallback>{m.initials}</AvatarFallback>
                </Avatar>
              ))}
              <div className="grid h-10 w-10 place-items-center rounded-full bg-muted text-xs font-medium ring-2 ring-background">
                +8
              </div>
            </div>
            <span className="text-xs text-muted-foreground">5 + 8 more</span>
          </div>

          <div className="flex flex-col items-center gap-3">
            <div className="flex -space-x-3">
              {team.slice(0, 4).map((m, i) => (
                <Avatar
                  key={m.name}
                  className="h-8 w-8 ring-2 ring-background"
                  style={{ zIndex: team.length - i }}
                >
                  <AvatarImage src={m.src} alt={m.name} />
                  <AvatarFallback>{m.initials}</AvatarFallback>
                </Avatar>
              ))}
            </div>
            <span className="text-xs text-muted-foreground">Compact small</span>
          </div>

          <div className="flex flex-col items-center gap-3">
            <div className="flex -space-x-4">
              {team.slice(0, 5).map((m, i) => (
                <Avatar
                  key={m.name}
                  className="h-14 w-14 ring-4 ring-background"
                  style={{ zIndex: team.length - i }}
                >
                  <AvatarImage src={m.src} alt={m.name} />
                  <AvatarFallback>{m.initials}</AvatarFallback>
                </Avatar>
              ))}
            </div>
            <span className="text-xs text-muted-foreground">Large with thick ring</span>
          </div>
        </CardContent>
      </Card>

      {/* In-context */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">In context</CardTitle>
          <CardDescription>
            How avatars appear inside profile cards, comment threads and team lists.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2">
          {/* Profile card */}
          <div className="rounded-lg border p-4 flex items-start gap-4">
            <div className="relative">
              <Avatar className="h-16 w-16 ring-2 ring-primary ring-offset-2 ring-offset-background">
                <AvatarImage src={team[0].src} alt={team[0].name} />
                <AvatarFallback>{team[0].initials}</AvatarFallback>
              </Avatar>
              <StatusDot tone="bg-[color:var(--success)]" ring="ring-card" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <p className="font-semibold truncate">{team[0].name}</p>
                <Badge className="bg-primary/15 text-primary ring-1 ring-inset ring-primary/25 border-transparent gap-1">
                  <Crown className="h-3 w-3" /> Owner
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{team[0].role}</p>
              <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Briefcase className="h-3 w-3" /> 3 active projects
                </span>
                <span className="inline-flex items-center gap-1">
                  <Shield className="h-3 w-3" /> Admin
                </span>
              </div>
            </div>
            <Button variant="ghost" size="icon" aria-label="More actions">
              <MoreHorizontal />
            </Button>
          </div>

          {/* Comment thread */}
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-start gap-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={team[1].src} alt={team[1].name} />
                <AvatarFallback>{team[1].initials}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1 rounded-lg bg-muted p-2.5">
                <p className="text-xs font-semibold">{team[1].name}</p>
                <p className="text-sm text-muted-foreground">
                  Pushed a fix for the webhook retry bug. Could someone review PR #1284?
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 pl-6">
              <Avatar className="h-8 w-8">
                <AvatarImage src={team[3].src} alt={team[3].name} />
                <AvatarFallback>{team[3].initials}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1 rounded-lg bg-muted p-2.5">
                <p className="text-xs font-semibold">{team[3].name}</p>
                <p className="text-sm text-muted-foreground">
                  Looking now. Will leave comments inline. Should land before the deploy window.
                </p>
              </div>
            </div>
          </div>

          {/* Team list */}
          <div className="rounded-lg border p-4 md:col-span-2">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <p className="text-sm font-semibold">Workspace members · 13</p>
              </div>
              <Button size="sm" variant="outline" onClick={() => toast.message("Invite dialog opened")}>
                <Plus /> Invite member
              </Button>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              {team.map((m) => (
                <div key={m.name} className="flex items-center gap-3 rounded-md border p-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={m.src} alt={m.name} />
                    <AvatarFallback>{m.initials}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{m.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{m.role}</p>
                  </div>
                  <StatusBadge tone={m.status} dot>
                    {m.statusLabel}
                  </StatusBadge>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Avatars page · 5 sizes · fallbacks · status dots · rings · 3 shapes · stacked groups · in-context examples
      </p>
    </div>
  );
}
