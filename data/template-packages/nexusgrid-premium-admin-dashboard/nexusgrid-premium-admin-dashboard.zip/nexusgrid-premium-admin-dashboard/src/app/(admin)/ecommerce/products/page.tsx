"use client";

import * as React from "react";
import {
  Package,
  Plus,
  Upload,
  Search,
  LayoutGrid,
  Table as TableIcon,
  Star,
  MoreHorizontal,
  Pencil,
  Trash2,
  Eye,
  Copy,
  PackageCheck,
  PackageX,
  AlertTriangle,
  Boxes,
  Tag,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Product = {
  id: string;
  name: string;
  sku: string;
  category: string;
  price: number;
  compareAt?: number;
  stock: number;
  rating: number;
  reviews: number;
  status: "active" | "low-stock" | "out-of-stock" | "draft";
  image: string;
};

const products: Product[] = [
  { id: "NX-1001", name: "Aether Wireless Headphones", sku: "AET-WH-BLK", category: "Electronics", price: 129.00, compareAt: 159.00, stock: 124, rating: 4.8, reviews: 1284, status: "active", image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop" },
  { id: "NX-1002", name: "Lumen Smart Desk Lamp", sku: "LUM-SDL-WHT", category: "Home & Living", price: 79.00, stock: 86, rating: 4.6, reviews: 642, status: "active", image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&h=400&fit=crop" },
  { id: "NX-1003", name: "Vertex Mechanical Keyboard", sku: "VRT-MK-87", category: "Electronics", price: 149.00, compareAt: 179.00, stock: 42, rating: 4.7, reviews: 928, status: "low-stock", image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400&h=400&fit=crop" },
  { id: "NX-1004", name: "Pulse Fitness Tracker", sku: "PLS-FT-GRN", category: "Sports", price: 89.00, stock: 218, rating: 4.5, reviews: 428, status: "active", image: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=400&h=400&fit=crop" },
  { id: "NX-1005", name: "Nova Travel Backpack 40L", sku: "NOV-TB-40L", category: "Fashion", price: 119.00, compareAt: 139.00, stock: 9, rating: 4.9, reviews: 1842, status: "low-stock", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop" },
  { id: "NX-1006", name: "Atlas Running Shoes", sku: "ATL-RS-BLU", category: "Sports", price: 144.00, stock: 0, rating: 4.4, reviews: 312, status: "out-of-stock", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop" },
  { id: "NX-1007", name: "Halo Tabletop Speaker", sku: "HAL-TS-OAK", category: "Electronics", price: 199.00, stock: 67, rating: 4.7, reviews: 218, status: "active", image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?w=400&h=400&fit=crop" },
  { id: "NX-1008", name: "Verde Ceramic Planter", sku: "VRD-CP-12", category: "Home & Living", price: 42.00, stock: 184, rating: 4.3, reviews: 142, status: "active", image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=400&fit=crop" },
  { id: "NX-1009", name: "Strata Minimalist Watch", sku: "STR-MW-SLV", category: "Fashion", price: 219.00, compareAt: 259.00, stock: 38, rating: 4.8, reviews: 728, status: "active", image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=400&h=400&fit=crop" },
  { id: "NX-1010", name: "Cobalt Espresso Maker", sku: "CBT-EM-PRO", category: "Home & Living", price: 349.00, stock: 24, rating: 4.9, reviews: 184, status: "active", image: "https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=400&h=400&fit=crop" },
  { id: "NX-1011", name: "Drift Yoga Mat Pro", sku: "DRF-YM-TEAL", category: "Sports", price: 58.00, stock: 96, rating: 4.6, reviews: 264, status: "active", image: "https://images.unsplash.com/photo-1592432678016-e910b452f9a2?w=400&h=400&fit=crop" },
  { id: "NX-1012", name: "Forge Leather Wallet", sku: "FRG-LW-TAN", category: "Fashion", price: 68.00, stock: 0, rating: 4.5, reviews: 92, status: "out-of-stock", image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=400&h=400&fit=crop" },
];

const categories = ["All", "Electronics", "Fashion", "Home & Living", "Sports", "Books"];

const statusToneMap: Record<Product["status"], "success" | "warning" | "danger" | "neutral"> = {
  active: "success",
  "low-stock": "warning",
  "out-of-stock": "danger",
  draft: "neutral",
};

function StarRating({ rating, className }: { rating: number; className?: string }) {
  return (
    <div className={cn("inline-flex items-center gap-0.5", className)}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={cn(
            "h-3 w-3",
            i < Math.floor(rating)
              ? "fill-amber-400 text-amber-400"
              : i < rating
              ? "fill-amber-400/50 text-amber-400"
              : "fill-muted text-muted-foreground/40"
          )}
        />
      ))}
      <span className="text-xs text-muted-foreground ml-1 tabular-nums">{rating.toFixed(1)}</span>
    </div>
  );
}

// Compact stat card style — different from KpiCard
function StatTile({
  label,
  value,
  icon: Icon,
  accent,
  hint,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "warning" | "danger";
  hint?: string;
}) {
  const accentMap = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    danger: "bg-destructive/15 text-destructive",
  };
  return (
    <Card className="overflow-hidden">
      <CardContent className="pt-5 pb-4">
        <div className="flex items-center gap-3">
          <div className={cn("grid place-items-center h-11 w-11 rounded-xl shrink-0", accentMap[accent])}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">{label}</p>
            <p className="text-xl font-semibold tabular-nums mt-0.5">{value}</p>
            {hint && <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{hint}</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ProductsPage() {
  const [view, setView] = React.useState<"grid" | "table">("grid");
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("All");

  const filtered = React.useMemo(() => {
    return products.filter((p) => {
      const matchesSearch =
        !search ||
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.sku.toLowerCase().includes(search.toLowerCase());
      const matchesCat = category === "All" || p.category === category;
      return matchesSearch && matchesCat;
    });
  }, [search, category]);

  const columns: Column<Product>[] = React.useMemo(() => [
    {
      key: "image",
      header: "Product",
      sortable: true,
      sortAccessor: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-3">
          <img src={r.image} alt={r.name} className="h-10 w-10 rounded-lg object-cover bg-muted shrink-0" />
          <div className="min-w-0">
            <p className="font-medium text-foreground text-sm truncate">{r.name}</p>
            <p className="text-xs text-muted-foreground font-mono">{r.sku}</p>
          </div>
        </div>
      ),
    },
    {
      key: "category",
      header: "Category",
      sortable: true,
      sortAccessor: (r) => r.category,
      filterable: true,
      filterAccessor: (r) => r.category,
      filterOptions: categories.filter((c) => c !== "All").map((c) => ({ label: c, value: c })),
      cell: (r) => <span className="text-xs text-muted-foreground">{r.category}</span>,
      width: "w-36",
    },
    {
      key: "price",
      header: "Price",
      sortable: true,
      sortAccessor: (r) => r.price,
      align: "right",
      cell: (r) => (
        <div className="flex flex-col items-end">
          <span className="font-medium tabular-nums">${r.price.toFixed(2)}</span>
          {r.compareAt && (
            <span className="text-xs text-muted-foreground line-through tabular-nums">${r.compareAt.toFixed(2)}</span>
          )}
        </div>
      ),
      width: "w-28",
    },
    {
      key: "rating",
      header: "Rating",
      sortable: true,
      sortAccessor: (r) => r.rating,
      cell: (r) => <StarRating rating={r.rating} />,
      width: "w-32",
    },
    {
      key: "stock",
      header: "Stock",
      sortable: true,
      sortAccessor: (r) => r.stock,
      align: "right",
      cell: (r) => (
        <span className={cn(
          "inline-block px-2 py-0.5 rounded text-xs font-medium tabular-nums",
          r.stock === 0 ? "bg-destructive/12 text-destructive" : r.stock < 20 ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" : "bg-muted text-muted-foreground"
        )}>
          {r.stock}
        </span>
      ),
      width: "w-24",
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Active", value: "active" },
        { label: "Low Stock", value: "low-stock" },
        { label: "Out of Stock", value: "out-of-stock" },
        { label: "Draft", value: "draft" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={statusToneMap[r.status]} dot className="capitalize">
          {r.status.replace("-", " ")}
        </StatusBadge>
      ),
      width: "w-32",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-7 w-7">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuLabel className="text-xs">{r.name}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening ${r.name} preview`)}>
              <Eye className="h-3.5 w-3.5" /> View product
            </DropdownMenuItem>
            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Editing ${r.name}`)}>
              <Pencil className="h-3.5 w-3.5" /> Edit
            </DropdownMenuItem>
            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Duplicated ${r.sku}`)}>
              <Copy className="h-3.5 w-3.5" /> Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`Deleted ${r.name}`)}>
              <Trash2 className="h-3.5 w-3.5" /> Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
      width: "w-16",
    },
  ], []);

  return (
    <>
      <PageHeader
        title="Products"
        description="Manage your catalog, pricing, inventory, and product listings."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Products" }]}
        icon={Package}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Import dialog opened")}>
              <Upload className="h-3.5 w-3.5" /> Import
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add product form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Product
            </Button>
          </>
        }
      />

      {/* Stat tiles — compact icon+value style, distinct from KpiCard */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatTile label="Total Products" value="1,284" icon={Boxes} accent="primary" hint="across 6 categories" />
        <StatTile label="Active" value="1,142" icon={PackageCheck} accent="success" hint="89% of catalog" />
        <StatTile label="Low Stock" value="86" icon={AlertTriangle} accent="warning" hint="need restock soon" />
        <StatTile label="Out of Stock" value="42" icon={PackageX} accent="danger" hint="3.3% of catalog" />
      </div>

      {/* Search + category filter bar */}
      <Card className="mb-4">
        <CardContent className="pt-4 pb-4">
          <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name or SKU..."
                className="h-9 pl-8 text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Tag className="h-3.5 w-3.5 text-muted-foreground hidden sm:block" />
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="h-9 w-[180px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1" />
            <Tabs value={view} onValueChange={(v) => setView(v as "grid" | "table")}>
              <TabsList className="grid grid-cols-2 h-9 w-[160px]">
                <TabsTrigger value="grid" className="text-xs gap-1.5">
                  <LayoutGrid className="h-3.5 w-3.5" /> Grid
                </TabsTrigger>
                <TabsTrigger value="table" className="text-xs gap-1.5">
                  <TableIcon className="h-3.5 w-3.5" /> Table
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      <Tabs value={view} className="w-full">
        {/* Grid view */}
        <TabsContent value="grid" className="mt-0">
          {filtered.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-sm text-muted-foreground">
                No products match your filters.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filtered.map((p) => (
                <Card
                  key={p.id}
                  className="overflow-hidden group hover:shadow-premium-md transition-all cursor-pointer"
                  onClick={() => toast.message(`Opening product ${p.sku} detail`)}
                >
                  <div className="relative aspect-square bg-muted overflow-hidden">
                    <img
                      src={p.image}
                      alt={p.name}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {p.compareAt && (
                      <span className="absolute top-2 left-2 bg-destructive text-destructive-foreground text-[10px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded">
                        Sale
                      </span>
                    )}
                    <div className="absolute top-2 right-2">
                      <StatusBadge tone={statusToneMap[p.status]} dot className="capitalize bg-card/90 backdrop-blur">
                        {p.status.replace("-", " ")}
                      </StatusBadge>
                    </div>
                    <div
                      className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="icon" variant="secondary" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-40">
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Previewing ${p.name}`)}>
                            <Eye className="h-3.5 w-3.5" /> Preview
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Editing ${p.name}`)}>
                            <Pencil className="h-3.5 w-3.5" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`Deleted ${p.name}`)}>
                            <Trash2 className="h-3.5 w-3.5" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                  <CardContent className="pt-3 pb-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">{p.category}</span>
                      <span className="font-mono text-[10px] text-muted-foreground">{p.sku}</span>
                    </div>
                    <h3 className="text-sm font-semibold text-foreground line-clamp-1">{p.name}</h3>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-base font-semibold tabular-nums">${p.price.toFixed(2)}</span>
                        {p.compareAt && (
                          <span className="text-xs text-muted-foreground line-through tabular-nums">${p.compareAt.toFixed(2)}</span>
                        )}
                      </div>
                      <StarRating rating={p.rating} />
                    </div>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                      <span className="text-xs text-muted-foreground">{p.reviews.toLocaleString()} reviews</span>
                      <span className={cn(
                        "text-xs font-medium px-1.5 py-0.5 rounded tabular-nums",
                        p.stock === 0 ? "bg-destructive/12 text-destructive" : p.stock < 20 ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" : "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                      )}>
                        {p.stock === 0 ? "Out of stock" : `${p.stock} in stock`}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Table view */}
        <TabsContent value="table" className="mt-0">
          <DataTable
            title="Product Catalog"
            data={filtered}
            columns={columns}
            searchKeys={["name", "sku"]}
            getRowId={(r) => r.id}
            onRowClick={(r) => toast.message(`Opening product ${r.sku} detail`)}
            pageSize={10}
            enableExport
            enableDensity
            enableColumnVisibility
          />
        </TabsContent>
      </Tabs>
    </>
  );
}
