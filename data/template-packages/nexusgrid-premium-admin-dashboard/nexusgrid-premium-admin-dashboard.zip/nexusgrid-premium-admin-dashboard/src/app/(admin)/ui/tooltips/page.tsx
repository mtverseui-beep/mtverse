"use client";

import * as React from "react";
import {
  Lightbulb,
  Info,
  HelpCircle,
  Settings,
  Bell,
  Download,
  Edit3,
  Trash2,
  Star,
  Heart,
  Bookmark,
  Share2,
  Plus,
  Search,
  Filter,
  Eye,
  Copy,
  Save,
  Upload,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function Tip({
  side,
  children,
  trigger,
}: {
  side: "top" | "right" | "bottom" | "left";
  children: React.ReactNode;
  trigger: React.ReactNode;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{trigger}</TooltipTrigger>
      <TooltipContent side={side}>{children}</TooltipContent>
    </Tooltip>
  );
}

export default function TooltipsPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Tooltips"
        description="Hover, focus and click-triggered contextual hints — all four sides, with arrows and rich content."
        icon={Lightbulb}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/tooltips" },
          { label: "Tooltips" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Tooltip spec copied")}>
            <Copy /> Spec sheet
          </Button>
        }
      />

      <TooltipProvider delayDuration={200}>
        {/* All sides */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">All four sides</CardTitle>
            <CardDescription>
              Tooltips can be anchored to the top, right, bottom or left of the trigger.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-8">
              <div className="flex flex-col items-center gap-3">
                <Tip side="top" trigger={<Button variant="outline" size="sm">Top</Button>}>
                  Appears above the trigger
                </Tip>
                <span className="text-xs text-muted-foreground">side="top"</span>
              </div>
              <div className="flex flex-col items-center gap-3">
                <Tip side="right" trigger={<Button variant="outline" size="sm">Right</Button>}>
                  Appears to the right
                </Tip>
                <span className="text-xs text-muted-foreground">side="right"</span>
              </div>
              <div className="flex flex-col items-center gap-3">
                <Tip side="bottom" trigger={<Button variant="outline" size="sm">Bottom</Button>}>
                  Appears below the trigger
                </Tip>
                <span className="text-xs text-muted-foreground">side="bottom"</span>
              </div>
              <div className="flex flex-col items-center gap-3">
                <Tip side="left" trigger={<Button variant="outline" size="sm">Left</Button>}>
                  Appears to the left
                </Tip>
                <span className="text-xs text-muted-foreground">side="left"</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Icon button tooltips */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Icon button tooltips</CardTitle>
            <CardDescription>
              Icon-only buttons rely on tooltips for accessibility — always provide a label.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            {[
              { icon: Search, label: "Search workspace", side: "top" as const },
              { icon: Filter, label: "Filter results", side: "top" as const },
              { icon: Edit3, label: "Edit selected row", side: "top" as const },
              { icon: Copy, label: "Copy to clipboard", side: "top" as const },
              { icon: Save, label: "Save changes", side: "top" as const },
              { icon: Download, label: "Download as CSV", side: "bottom" as const },
              { icon: Upload, label: "Upload file", side: "bottom" as const },
              { icon: Eye, label: "Preview", side: "bottom" as const },
              { icon: Share2, label: "Share with team", side: "bottom" as const },
              { icon: Plus, label: "Add new item", side: "bottom" as const },
              { icon: Star, label: "Add to favourites", side: "right" as const },
              { icon: Heart, label: "Like", side: "right" as const },
              { icon: Bookmark, label: "Bookmark", side: "left" as const },
              { icon: Trash2, label: "Delete permanently", side: "left" as const },
            ].map(({ icon: Icon, label, side }) => (
              <Tooltip key={label}>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" aria-label={label} onClick={() => toast.message(label)}>
                    <Icon />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side={side}>{label}</TooltipContent>
              </Tooltip>
            ))}
          </CardContent>
        </Card>

        {/* Arrow + content lengths */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Arrows & content lengths</CardTitle>
            <CardDescription>
              The default tooltip includes an arrow. Content can be short or paragraph length.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-3">
              <Tip side="top" trigger={<Button variant="outline" size="sm">Short</Button>}>
                Quick tip
              </Tip>
              <Tip side="top" trigger={<Button variant="outline" size="sm">Medium</Button>}>
                A slightly longer sentence to demonstrate wrapping behaviour.
              </Tip>
              <Tip side="top" trigger={<Button variant="outline" size="sm">Long</Button>}>
                This tooltip contains a paragraph of supporting copy. Tooltips are best kept short, but
                when needed they will wrap to multiple lines and respect the max-width of the content area.
              </Tip>
              <Tip side="top" trigger={<Button variant="outline" size="sm">With shortcut</Button>}>
                <span className="flex items-center gap-1.5">Press <kbd className="rounded bg-primary-foreground/15 px-1.5 py-0.5 text-[10px] font-mono">⌘K</kbd> to open the command palette</span>
              </Tip>
              <Tip side="top" trigger={<Button variant="outline" size="sm">Rich content</Button>}>
                <span className="flex flex-col gap-1">
                  <span className="font-medium">Release v4.2.0</span>
                  <span className="text-[10px] opacity-80">Ships in 2 days · 18 PRs merged</span>
                </span>
              </Tip>
            </div>
          </CardContent>
        </Card>

        {/* Triggers */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Trigger types</CardTitle>
            <CardDescription>
              Tooltips open on hover, on keyboard focus, and on touch — all out of the box.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-3">
            <div className="flex flex-col items-center gap-2 rounded-lg border p-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" className="w-full">Hover me</Button>
                </TooltipTrigger>
                <TooltipContent>Triggered on hover after the delay</TooltipContent>
              </Tooltip>
              <p className="text-xs text-muted-foreground text-center">Hover trigger</p>
            </div>
            <div className="flex flex-col items-center gap-2 rounded-lg border p-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" className="w-full">Tab to me</Button>
                </TooltipTrigger>
                <TooltipContent>Triggered on focus</TooltipContent>
              </Tooltip>
              <p className="text-xs text-muted-foreground text-center">Focus trigger (try Tab key)</p>
            </div>
            <div className="flex flex-col items-center gap-2 rounded-lg border p-4">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" className="w-full">Touch me</Button>
                </TooltipTrigger>
                <TooltipContent>Triggered on tap</TooltipContent>
              </Tooltip>
              <p className="text-xs text-muted-foreground text-center">Touch trigger (mobile)</p>
            </div>
          </CardContent>
        </Card>

        {/* In-context */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">In context</CardTitle>
            <CardDescription>
              Tooltips in real UI surfaces — toolbar, status indicators, truncated text and form hints.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 lg:grid-cols-2">
            {/* Toolbar */}
            <div className="rounded-lg border p-4">
              <p className="text-xs text-muted-foreground mb-3">Document toolbar</p>
              <div className="flex items-center gap-1 rounded-md border bg-muted/30 p-1">
                {[
                  { icon: Search, label: "Find" },
                  { icon: Edit3, label: "Edit" },
                  { icon: Copy, label: "Copy" },
                  { icon: Save, label: "Save" },
                  { icon: Download, label: "Export" },
                  { icon: Share2, label: "Share" },
                  { icon: Trash2, label: "Delete" },
                ].map(({ icon: Icon, label }) => (
                  <Tooltip key={label}>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7" aria-label={label} onClick={() => toast.message(label)}>
                        <Icon className="h-3.5 w-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">{label}</TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>

            {/* Status pills */}
            <div className="rounded-lg border p-4">
              <p className="text-xs text-muted-foreground mb-3">Status indicators with tooltips</p>
              <div className="flex flex-wrap items-center gap-4">
                {[
                  { tone: "bg-[color:var(--success)]", label: "All systems operational" },
                  { tone: "bg-[color:var(--warning)]", label: "Degraded performance in EU" },
                  { tone: "bg-[color:var(--info)]", label: "Maintenance scheduled" },
                  { tone: "bg-destructive", label: "Outage in API gateway" },
                ].map((s) => (
                  <Tooltip key={s.label}>
                    <TooltipTrigger asChild>
                      <button type="button" aria-label={s.label} className="grid place-items-center h-6 w-6">
                        <span className={cn("h-2.5 w-2.5 rounded-full", s.tone)} />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">{s.label}</TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>

            {/* Truncated text */}
            <div className="rounded-lg border p-4">
              <p className="text-xs text-muted-foreground mb-3">Truncated text</p>
              <Tooltip>
                <TooltipTrigger asChild>
                  <p className="text-sm font-medium truncate max-w-xs cursor-help">
                    A very long pull request title that demonstrates tooltip on truncation — Refactor billing engine v2 to support metered usage with proration
                  </p>
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-xs">
                  A very long pull request title that demonstrates tooltip on truncation — Refactor billing engine v2 to support metered usage with proration
                </TooltipContent>
              </Tooltip>
            </div>

            {/* Form hint */}
            <div className="rounded-lg border p-4">
              <p className="text-xs text-muted-foreground mb-3">Form hint</p>
              <div className="flex items-center gap-2">
                <span className="text-sm">API rate limit</span>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button type="button" aria-label="What is the API rate limit?" className="grid place-items-center h-4 w-4 rounded-full bg-muted text-muted-foreground hover:bg-foreground/10">
                      <HelpCircle className="h-3 w-3" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="max-w-xs">
                    Maximum number of API requests per minute. Default is 1,000 — Enterprise plans can raise this to 10,000.
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Directional arrow grid */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Directional arrows</CardTitle>
            <CardDescription>
              Each directional tooltip's arrow points back to its trigger.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-6 py-12 place-items-center">
              <div />
              <Tip side="top" trigger={<Button variant="outline" size="icon" aria-label="Up"><ArrowUp /></Button>}>
                <ChevronUp className="inline h-3 w-3 mr-1" /> Top arrow points down
              </Tip>
              <div />

              <Tip side="left" trigger={<Button variant="outline" size="icon" aria-label="Left"><ArrowLeft /></Button>}>
                <ChevronLeft className="inline h-3 w-3 mr-1" /> Left arrow points right
              </Tip>
              <div className="grid place-items-center h-9 w-9 rounded-md border-2 border-dashed text-muted-foreground text-xs">
                origin
              </div>
              <Tip side="right" trigger={<Button variant="outline" size="icon" aria-label="Right"><ArrowRight /></Button>}>
                Right arrow points left <ChevronRight className="inline h-3 w-3 ml-1" />
              </Tip>

              <div />
              <Tip side="bottom" trigger={<Button variant="outline" size="icon" aria-label="Down"><ArrowDown /></Button>}>
                <ChevronDown className="inline h-3 w-3 mr-1" /> Bottom arrow points up
              </Tip>
              <div />
            </div>
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground text-center pb-6">
          Tooltips page · 4 sides · icon buttons · arrows · hover / focus / touch · in-context examples
        </p>
      </TooltipProvider>
    </div>
  );
}
