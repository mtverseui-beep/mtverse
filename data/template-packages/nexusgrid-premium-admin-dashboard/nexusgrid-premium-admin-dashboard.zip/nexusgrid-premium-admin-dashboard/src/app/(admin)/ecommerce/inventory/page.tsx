"use client";

import * as React from "react";
import {
  Box,
  Warehouse,
  AlertTriangle,
  PackageX,
  DollarSign,
  Boxes,
  Plus,
  Download,
  ArrowUpRight,
  TrendingUp,
  Bell,
  RefreshCw,
  Building2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarTrendChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type InvStatus = "in-stock" | "low" | "out" | "overstock";

type InventoryItem = {
  sku: string;
  product: string;
  warehouse: "A" | "B" | "C";
  onHand: number;
  reserved: number;
  reorderPoint: number;
  restockDate: string;
  unitCost: number;
};

const inventory: InventoryItem[] = [
  { sku: "AET-WH-BLK", product: "Aether Wireless Headphones", warehouse: "A", onHand: 124, reserved: 18, reorderPoint: 40, restockDate: "2026-06-28", unitCost: 78 },
  { sku: "LUM-SDL-WHT", product: "Lumen Smart Desk Lamp", warehouse: "A", onHand: 86, reserved: 12, reorderPoint: 30, restockDate: "2026-06-30", unitCost: 42 },
  { sku: "VRT-MK-87", product: "Vertex Mechanical Keyboard", warehouse: "B", onHand: 14, reserved: 4, reorderPoint: 30, restockDate: "2026-06-22", unitCost: 92 },
  { sku: "PLS-FT-GRN", product: "Pulse Fitness Tracker", warehouse: "B", onHand: 218, reserved: 32, reorderPoint: 60, restockDate: "2026-07-04", unitCost: 54 },
  { sku: "NOV-TB-40L", product: "Nova Travel Backpack", warehouse: "A", onHand: 9, reserved: 6, reorderPoint: 25, restockDate: "2026-06-20", unitCost: 68 },
  { sku: "ATL-RS-BLU", product: "Atlas Running Shoes", warehouse: "C", onHand: 0, reserved: 0, reorderPoint: 40, restockDate: "2026-07-08", unitCost: 84 },
  { sku: "HAL-TS-OAK", product: "Halo Tabletop Speaker", warehouse: "B", onHand: 67, reserved: 8, reorderPoint: 20, restockDate: "2026-07-02", unitCost: 124 },
  { sku: "VRD-CP-12", product: "Verde Ceramic Planter", warehouse: "C", onHand: 184, reserved: 22, reorderPoint: 50, restockDate: "2026-07-10", unitCost: 18 },
  { sku: "STR-MW-SLV", product: "Strata Minimalist Watch", warehouse: "A", onHand: 38, reserved: 6, reorderPoint: 15, restockDate: "2026-06-26", unitCost: 142 },
  { sku: "CBT-EM-PRO", product: "Cobalt Espresso Maker", warehouse: "B", onHand: 24, reserved: 4, reorderPoint: 12, restockDate: "2026-06-29", unitCost: 218 },
  { sku: "DRF-YM-TEAL", product: "Drift Yoga Mat Pro", warehouse: "C", onHand: 96, reserved: 14, reorderPoint: 30, restockDate: "2026-07-06", unitCost: 28 },
  { sku: "FRG-LW-TAN", product: "Forge Leather Wallet", warehouse: "A", onHand: 0, reserved: 0, reorderPoint: 20, restockDate: "2026-07-12", unitCost: 32 },
];

function getInvStatus(item: InventoryItem): InvStatus {
  if (item.onHand === 0) return "out";
  if (item.onHand <= item.reorderPoint) return "low";
  if (item.onHand > item.reorderPoint * 4) return "overstock";
  return "in-stock";
}

const statusToneMap: Record<InvStatus, "success" | "warning" | "danger" | "info"> = {
  "in-stock": "success",
  low: "warning",
  out: "danger",
  overstock: "info",
};

const statusLabel: Record<InvStatus, string> = {
  "in-stock": "In Stock",
  low: "Low Stock",
  out: "Out of Stock",
  overstock: "Overstock",
};

// Inventory-flavored KPI card — warehouse shelf motif with capacity bar
function InvKpi({
  label,
  value,
  icon: Icon,
  accent,
  capacity,
  capacityLabel,
  hint,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "warning" | "danger";
  capacity: number;
  capacityLabel: string;
  hint?: string;
}) {
  const accentBar = {
    primary: "var(--primary)",
    success: "var(--success)",
    warning: "var(--warning)",
    danger: "var(--destructive)",
  };
  const accentIcon = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    danger: "bg-destructive/15 text-destructive",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentIcon[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* capacity bar */}
        <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1.5">
          <span>{capacityLabel}</span>
          <span className="font-medium tabular-nums">{capacity}%</span>
        </div>
        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{ width: `${capacity}%`, background: accentBar[accent] }}
          />
        </div>
        {hint && <p className="text-[11px] text-muted-foreground mt-2">{hint}</p>}
      </CardContent>
    </Card>
  );
}

export default function InventoryPage() {
  const [warehouse, setWarehouse] = React.useState<"all" | "A" | "B" | "C">("all");

  const filtered = React.useMemo(() => {
    if (warehouse === "all") return inventory;
    return inventory.filter((i) => i.warehouse === warehouse);
  }, [warehouse]);

  const stockValue = filtered.reduce((sum, i) => sum + i.onHand * i.unitCost, 0);
  const lowStock = filtered.filter((i) => getInvStatus(i) === "low").length;
  const outStock = filtered.filter((i) => getInvStatus(i) === "out").length;

  // Top 8 products by stock for bar chart
  const chartData = React.useMemo(() => {
    return [...inventory]
      .sort((a, b) => b.onHand - a.onHand)
      .slice(0, 8)
      .map((i) => ({
        sku: i.sku.split("-")[0],
        onHand: i.onHand,
        reorder: i.reorderPoint,
      }));
  }, []);

  const warehouseStats = [
    { key: "A", name: "Warehouse A", location: "Reno, NV", capacity: 78, items: inventory.filter((i) => i.warehouse === "A").length },
    { key: "B", name: "Warehouse B", location: "Memphis, TN", capacity: 64, items: inventory.filter((i) => i.warehouse === "B").length },
    { key: "C", name: "Warehouse C", location: "Allentown, PA", capacity: 92, items: inventory.filter((i) => i.warehouse === "C").length },
  ] as const;

  return (
    <>
      <PageHeader
        title="Inventory"
        description="Track stock levels across warehouses, set reorder points, and prevent stockouts."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Inventory" }]}
        icon={Box}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Inventory exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Restock order initiated")}>
              <RefreshCw className="h-3.5 w-3.5" /> Restock
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add SKU form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add SKU
            </Button>
          </>
        }
      />

      {/* Inventory KPI cards — warehouse capacity motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <InvKpi label="Total SKUs" value="1,284" icon={Boxes} accent="primary" capacity={72} capacityLabel="Catalog Fill" hint="Across 3 warehouses" />
        <InvKpi label="Stock Value" value={`$${(stockValue / 1000).toFixed(1)}K`} icon={DollarSign} accent="success" capacity={84} capacityLabel="Budget Used" hint="Q3 inventory budget" />
        <InvKpi label="Low Stock Items" value={String(lowStock)} icon={AlertTriangle} accent="warning" capacity={Math.round((lowStock / filtered.length) * 100)} capacityLabel="Of Catalog" hint="Below reorder point" />
        <InvKpi label="Out of Stock" value={String(outStock)} icon={PackageX} accent="danger" capacity={Math.round((outStock / filtered.length) * 100)} capacityLabel="Of Catalog" hint="Immediate restock needed" />
      </div>

      {/* Warehouse summary tiles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {warehouseStats.map((w) => (
          <Card key={w.key} className={cn(warehouse === w.key && "ring-1 ring-primary/40")}>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                    <Building2 className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{w.name}</p>
                    <p className="text-xs text-muted-foreground">{w.location}</p>
                  </div>
                </div>
                <StatusBadge tone={w.capacity > 85 ? "danger" : w.capacity > 70 ? "warning" : "success"} dot>
                  {w.capacity}% full
                </StatusBadge>
              </div>
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
                <span>Capacity utilization</span>
                <span className="font-medium text-foreground tabular-nums">{w.items} SKUs</span>
              </div>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full transition-all duration-700",
                    w.capacity > 85 ? "bg-destructive" : w.capacity > 70 ? "bg-[color:var(--warning)]" : "bg-[color:var(--success)]"
                  )}
                  style={{ width: `${w.capacity}%` }}
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Stock levels chart + low stock alerts */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Stock Levels vs. Reorder Points
            </CardTitle>
            <CardDescription>Top 8 SKUs by on-hand quantity across all warehouses.</CardDescription>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={chartData}
              xKey="sku"
              series={[
                { key: "onHand", name: "On Hand", color: "var(--primary)" },
                { key: "reorder", name: "Reorder Point", color: "var(--warning)" },
              ]}
              height={300}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Bell className="h-4 w-4 text-[color:var(--warning)]" />
                Low Stock Alerts
              </CardTitle>
              <CardDescription>{lowStock + outStock} items need attention.</CardDescription>
            </div>
            <StatusBadge tone="warning" dot>{lowStock + outStock}</StatusBadge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[300px] overflow-y-auto divide-y divide-border">
              {inventory
                .filter((i) => ["low", "out"].includes(getInvStatus(i)))
                .sort((a, b) => a.onHand - b.onHand)
                .map((i) => {
                  const status = getInvStatus(i);
                  return (
                    <div
                      key={i.sku}
                      className="flex items-center justify-between p-3 hover:bg-muted/40 transition-colors cursor-pointer"
                      onClick={() => toast.message(`Opening ${i.sku} restock dialog`)}
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{i.product}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-[10px] text-muted-foreground">{i.sku}</span>
                          <span className="text-[10px] text-muted-foreground">·</span>
                          <span className="text-[10px] text-muted-foreground">Warehouse {i.warehouse}</span>
                        </div>
                      </div>
                      <div className="text-right ml-2 shrink-0">
                        <p className={cn(
                          "text-sm font-semibold tabular-nums",
                          status === "out" ? "text-destructive" : "text-[color:var(--warning)]"
                        )}>
                          {i.onHand}
                        </p>
                        <p className="text-[10px] text-muted-foreground">/ {i.reorderPoint} reorder</p>
                      </div>
                    </div>
                  );
                })}
            </div>
            <div className="p-3 border-t border-border">
              <Button variant="outline" size="sm" className="w-full text-xs gap-1.5" onClick={() => toast.success("Bulk restock order created")}>
                <RefreshCw className="h-3.5 w-3.5" /> Create restock order
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Inventory table with warehouse tabs */}
      <Tabs value={warehouse} onValueChange={(v) => setWarehouse(v as "all" | "A" | "B" | "C")}>
        <TabsList className="grid grid-cols-4 h-9 w-full sm:w-auto mb-4">
          <TabsTrigger value="all" className="text-xs gap-1.5">
            <Warehouse className="h-3.5 w-3.5" /> All
          </TabsTrigger>
          <TabsTrigger value="A" className="text-xs">Warehouse A</TabsTrigger>
          <TabsTrigger value="B" className="text-xs">Warehouse B</TabsTrigger>
          <TabsTrigger value="C" className="text-xs">Warehouse C</TabsTrigger>
        </TabsList>
        <TabsContent value={warehouse} className="mt-0">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b border-border bg-muted/40">
                    <tr>
                      <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">SKU</th>
                      <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Product</th>
                      <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Warehouse</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">On Hand</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Reserved</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Available</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Reorder Pt</th>
                      <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden xl:table-cell">Last Restock</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filtered.map((i) => {
                      const status = getInvStatus(i);
                      const available = i.onHand - i.reserved;
                      return (
                        <tr
                          key={i.sku}
                          className="hover:bg-muted/30 transition-colors cursor-pointer"
                          onClick={() => toast.message(`Opening ${i.sku} detail`)}
                        >
                          <td className="px-4 py-3 font-mono text-xs">{i.sku}</td>
                          <td className="px-4 py-3 font-medium text-foreground">{i.product}</td>
                          <td className="px-4 py-3 text-center hidden sm:table-cell">
                            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                              <Building2 className="h-3 w-3" /> {i.warehouse}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right tabular-nums font-medium">{i.onHand}</td>
                          <td className="px-4 py-3 text-right tabular-nums text-muted-foreground hidden md:table-cell">{i.reserved}</td>
                          <td className="px-4 py-3 text-right tabular-nums">
                            <span className={cn(available === 0 && "text-muted-foreground")}>{available}</span>
                          </td>
                          <td className="px-4 py-3 text-right tabular-nums text-muted-foreground hidden lg:table-cell">{i.reorderPoint}</td>
                          <td className="px-4 py-3 text-center">
                            <StatusBadge tone={statusToneMap[status]} dot>{statusLabel[status]}</StatusBadge>
                          </td>
                          <td className="px-4 py-3 text-right text-xs text-muted-foreground font-mono hidden xl:table-cell">{i.restockDate}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="flex items-center justify-between p-3 border-t border-border bg-muted/30">
                <span className="text-xs text-muted-foreground">
                  Showing <span className="font-medium text-foreground">{filtered.length}</span> SKUs
                </span>
                <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.message("Opening full inventory ledger")}>
                  View ledger <ArrowUpRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
