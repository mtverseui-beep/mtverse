"use client";

import * as React from "react";
import {
  Tag,
  Plus,
  Search,
  MoreHorizontal,
  Pencil,
  Trash2,
  FolderTree,
  Package,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Cpu,
  Shirt,
  Home,
  Dumbbell,
  BookOpen,
  Car,
  Palette,
  Smartphone,
  Gamepad2,
  Camera,
  Music,
  Leaf,
  Baby,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DonutChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Category = {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  products: number;
  subCategories: number;
  revenue: number;
  growth: number;
  status: "active" | "draft" | "archived";
  color: string;
};

const categories: Category[] = [
  { id: "CAT-01", name: "Electronics", icon: Cpu, products: 284, subCategories: 12, revenue: 184200, growth: 12.4, status: "active", color: "var(--primary)" },
  { id: "CAT-02", name: "Fashion", icon: Shirt, products: 412, subCategories: 18, revenue: 142800, growth: 8.2, status: "active", color: "oklch(0.70 0.15 75)" },
  { id: "CAT-03", name: "Home & Living", icon: Home, products: 218, subCategories: 9, revenue: 98400, growth: 6.4, status: "active", color: "oklch(0.62 0.18 25)" },
  { id: "CAT-04", name: "Sports", icon: Dumbbell, products: 168, subCategories: 7, revenue: 84600, growth: -2.1, status: "active", color: "oklch(0.58 0.13 250)" },
  { id: "CAT-05", name: "Books", icon: BookOpen, products: 524, subCategories: 22, revenue: 62800, growth: 4.8, status: "active", color: "oklch(0.62 0.18 305)" },
  { id: "CAT-06", name: "Automotive", icon: Car, products: 96, subCategories: 6, revenue: 124800, growth: 18.6, status: "active", color: "var(--info)" },
  { id: "CAT-07", name: "Beauty", icon: Palette, products: 184, subCategories: 8, revenue: 72400, growth: 14.2, status: "active", color: "var(--success)" },
  { id: "CAT-08", name: "Mobile Accessories", icon: Smartphone, products: 142, subCategories: 5, revenue: 48200, growth: -4.6, status: "draft", color: "var(--warning)" },
  { id: "CAT-09", name: "Gaming", icon: Gamepad2, products: 88, subCategories: 4, revenue: 96400, growth: 22.8, status: "active", color: "var(--destructive)" },
  { id: "CAT-10", name: "Photography", icon: Camera, products: 64, subCategories: 3, revenue: 142000, growth: 9.4, status: "active", color: "oklch(0.70 0.15 75)" },
  { id: "CAT-11", name: "Music & Audio", icon: Music, products: 112, subCategories: 5, revenue: 88600, growth: 3.2, status: "active", color: "oklch(0.58 0.13 250)" },
  { id: "CAT-12", name: "Garden", icon: Leaf, products: 78, subCategories: 4, revenue: 32400, growth: 7.8, status: "archived", color: "var(--success)" },
];

const statusToneMap: Record<Category["status"], "success" | "neutral" | "warning"> = {
  active: "success",
  draft: "warning",
  archived: "neutral",
};

const topCategoriesForDonut = categories
  .filter((c) => c.status === "active")
  .sort((a, b) => b.revenue - a.revenue)
  .slice(0, 6)
  .map((c) => ({ name: c.name, value: c.revenue, color: c.color }));

export default function CategoriesPage() {
  const [search, setSearch] = React.useState("");

  const filtered = React.useMemo(() => {
    if (!search) return categories;
    return categories.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()));
  }, [search]);

  const totalProducts = categories.reduce((s, c) => s + c.products, 0);
  const totalRevenue = categories.reduce((s, c) => s + c.revenue, 0);
  const activeCount = categories.filter((c) => c.status === "active").length;

  return (
    <>
      <PageHeader
        title="Categories"
        description="Organize your catalog into categories and sub-categories for easier discovery."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Categories" }]}
        icon={Tag}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Categories tree exported")}>
              <FolderTree className="h-3.5 w-3.5" /> Tree View
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add category form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Category
            </Button>
          </>
        }
      />

      {/* Summary stat band — wide horizontal cards, distinct from other pages */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="bg-gradient-to-br from-primary/5 to-transparent">
          <CardContent className="pt-5 pb-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Total Categories</p>
                <p className="text-3xl font-semibold tabular-nums mt-1">{categories.length}</p>
                <p className="text-xs text-muted-foreground mt-1">{activeCount} active · {categories.length - activeCount} inactive</p>
              </div>
              <div className="grid place-items-center h-14 w-14 rounded-2xl bg-primary/10 text-primary">
                <Tag className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Total Products</p>
                <p className="text-3xl font-semibold tabular-nums mt-1">{totalProducts.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground mt-1">across {categories.reduce((s, c) => s + c.subCategories, 0)} sub-categories</p>
              </div>
              <div className="grid place-items-center h-14 w-14 rounded-2xl bg-[color:var(--info)]/12 text-[color:var(--info)]">
                <Package className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Category Revenue</p>
                <p className="text-3xl font-semibold tabular-nums mt-1">${(totalRevenue / 1000).toFixed(1)}K</p>
                <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1">
                  <ArrowUpRight className="h-3 w-3" /> +8.4% vs last quarter
                </p>
              </div>
              <div className="grid place-items-center h-14 w-14 rounded-2xl bg-[color:var(--success)]/15 text-[color:var(--success)]">
                <TrendingUp className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Donut + search bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Revenue by Category</CardTitle>
            <CardDescription>Top 6 categories by revenue.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={topCategoriesForDonut}
              centerLabel="Total"
              centerValue={`$${(topCategoriesForDonut.reduce((s, c) => s + c.value, 0) / 1000).toFixed(0)}K`}
              height={240}
            />
            <div className="mt-3 space-y-1.5">
              {topCategoriesForDonut.map((s) => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                    <span className="text-muted-foreground">{s.name}</span>
                  </div>
                  <span className="font-medium tabular-nums">${(s.value / 1000).toFixed(0)}K</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Category cards grid */}
        <div className="lg:col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search categories..."
                className="h-9 pl-8 text-sm"
              />
            </div>
            <span className="text-xs text-muted-foreground shrink-0">{filtered.length} of {categories.length}</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filtered.map((c) => {
              const Icon = c.icon;
              return (
                <Card
                  key={c.id}
                  className="group hover:shadow-premium-sm transition-all cursor-pointer"
                  onClick={() => toast.message(`Opening category ${c.name} detail`)}
                >
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start gap-3">
                      <div
                        className="grid place-items-center h-11 w-11 rounded-xl shrink-0"
                        style={{ background: `color-mix(in srgb, ${c.color} 14%, transparent)`, color: c.color }}
                      >
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <h3 className="text-sm font-semibold truncate">{c.name}</h3>
                          <div onClick={(e) => e.stopPropagation()}>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-6 w-6 -mr-1 opacity-60 group-hover:opacity-100">
                                  <MoreHorizontal className="h-3.5 w-3.5" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-40">
                                <DropdownMenuLabel className="text-xs">{c.name}</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Editing ${c.name}`)}>
                                  <Pencil className="h-3.5 w-3.5" /> Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Viewing ${c.products} products in ${c.name}`)}>
                                  <Package className="h-3.5 w-3.5" /> View products
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`Deleted category ${c.name}`)}>
                                  <Trash2 className="h-3.5 w-3.5" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="font-mono text-[10px] text-muted-foreground">{c.id}</span>
                          <StatusBadge tone={statusToneMap[c.status]} dot className="capitalize">{c.status}</StatusBadge>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-border">
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Products</p>
                        <p className="text-sm font-semibold tabular-nums mt-0.5">{c.products}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Sub-cats</p>
                        <p className="text-sm font-semibold tabular-nums mt-0.5">{c.subCategories}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Growth</p>
                        <p className={cn(
                          "text-sm font-semibold tabular-nums mt-0.5 inline-flex items-center gap-0.5",
                          c.growth >= 0 ? "text-[color:var(--success)]" : "text-destructive"
                        )}>
                          {c.growth >= 0 ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                          {Math.abs(c.growth)}%
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
