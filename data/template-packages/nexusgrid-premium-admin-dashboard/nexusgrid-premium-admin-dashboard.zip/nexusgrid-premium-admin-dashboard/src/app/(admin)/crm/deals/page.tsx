"use client";

import * as React from "react";
import {
  Briefcase,
  DollarSign,
  Trophy,
  XCircle,
  Plus,
  MoreHorizontal,
  Eye,
  Mail,
  Calendar,
  Trash2,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Flame,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type DealStage = "lead" | "qualified" | "proposal" | "negotiation" | "won" | "lost";
type Priority = "low" | "medium" | "high" | "critical";

type Deal = {
  id: string;
  name: string;
  company: string;
  logo: string;
  value: number;
  stage: DealStage;
  probability: number;
  owner: string;
  ownerAvatar: string;
  expectedClose: string;
  priority: Priority;
};

const deals: Deal[] = [
  { id: "DL-5012", name: "Annual Platform License", company: "Globex Corp", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=64&h=64&fit=crop", value: 84000, stage: "negotiation", probability: 75, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Jul 14, 2026", priority: "high" },
  { id: "DL-5011", name: "Enterprise Analytics Suite", company: "Initech", logo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=64&h=64&fit=crop", value: 62500, stage: "proposal", probability: 60, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", expectedClose: "Jul 18, 2026", priority: "medium" },
  { id: "DL-5010", name: "Cloud Migration Package", company: "Hooli", logo: "https://images.unsplash.com/photo-1620288627229-c5b1d2f80c8f?w=64&h=64&fit=crop", value: 124000, stage: "negotiation", probability: 80, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Jul 22, 2026", priority: "critical" },
  { id: "DL-5009", name: "Healthcare Compliance Add-on", company: "Umbrella Inc", logo: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=64&h=64&fit=crop", value: 48200, stage: "qualified", probability: 35, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", expectedClose: "Aug 02, 2026", priority: "low" },
  { id: "DL-5008", name: "Manufacturing ERP Integration", company: "Acme Corp", logo: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=64&h=64&fit=crop", value: 96800, stage: "proposal", probability: 55, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", expectedClose: "Jul 28, 2026", priority: "high" },
  { id: "DL-5007", name: "Multi-Year Support Contract", company: "Soylent", logo: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop", value: 152000, stage: "won", probability: 100, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Jul 01, 2026", priority: "high" },
  { id: "DL-5006", name: "API Tier Upgrade", company: "Stripe", logo: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=64&h=64&fit=crop", value: 38400, stage: "qualified", probability: 40, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Aug 10, 2026", priority: "medium" },
  { id: "DL-5005", name: "Fintech Compliance Bundle", company: "Plaid", logo: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop", value: 72400, stage: "lead", probability: 20, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", expectedClose: "Aug 22, 2026", priority: "medium" },
  { id: "DL-5004", name: "Ecommerce Analytics Rollout", company: "Rakuten", logo: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=64&h=64&fit=crop", value: 58300, stage: "proposal", probability: 50, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", expectedClose: "Jul 31, 2026", priority: "low" },
  { id: "DL-5003", name: "Telehealth Module", company: "Ro Health", logo: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=64&h=64&fit=crop", value: 91500, stage: "qualified", probability: 45, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Aug 05, 2026", priority: "high" },
  { id: "DL-5002", name: "CDN Enterprise Plan", company: "Cloudflare", logo: "https://images.unsplash.com/photo-1551803091-e20673f15770?w=64&h=64&fit=crop", value: 184000, stage: "negotiation", probability: 85, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Jul 12, 2026", priority: "critical" },
  { id: "DL-5001", name: "SaaS Subscription Premium", company: "Freshworks", logo: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=64&h=64&fit=crop", value: 67800, stage: "lead", probability: 15, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", expectedClose: "Sep 01, 2026", priority: "low" },
  { id: "DL-5000", name: "Banking SDK License", company: "N26 Bank", logo: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=64&h=64&fit=crop", value: 42000, stage: "lost", probability: 0, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", expectedClose: "Jun 28, 2026", priority: "low" },
  { id: "DL-4999", name: "Patient Scheduling Platform", company: "Doctolib", logo: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=64&h=64&fit=crop", value: 102500, stage: "proposal", probability: 65, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", expectedClose: "Jul 25, 2026", priority: "high" },
  { id: "DL-4998", name: "Ride-Logistics Integration", company: "Careem", logo: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=64&h=64&fit=crop", value: 88600, stage: "qualified", probability: 50, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", expectedClose: "Aug 14, 2026", priority: "medium" },
  { id: "DL-4997", name: "Buy-Now-Pay-Later Module", company: "Klarna", logo: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=64&h=64&fit=crop", value: 142000, stage: "won", probability: 100, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", expectedClose: "Jul 03, 2026", priority: "high" },
];

const stageToneMap: Record<DealStage, StatusTone> = {
  lead: "info",
  qualified: "primary",
  proposal: "violet",
  negotiation: "warning",
  won: "success",
  lost: "danger",
};

const stageLabelMap: Record<DealStage, string> = {
  lead: "Lead",
  qualified: "Qualified",
  proposal: "Proposal",
  negotiation: "Negotiation",
  won: "Won",
  lost: "Lost",
};

const priorityToneMap: Record<Priority, StatusTone> = {
  low: "neutral",
  medium: "info",
  high: "warning",
  critical: "danger",
};

/* Pipeline stages summary data (excluding lost) */
const pipelineStages = [
  { stage: "Lead", count: 38, value: 412000, color: "var(--info)" },
  { stage: "Qualified", count: 26, value: 528000, color: "var(--primary)" },
  { stage: "Proposal", count: 18, value: 642000, color: "oklch(0.62 0.18 305)" },
  { stage: "Negotiation", count: 11, value: 486000, color: "oklch(0.70 0.15 75)" },
  { stage: "Won", count: 8, value: 294000, color: "var(--success)" },
];

/* DealKpi — pipeline-mini-icons motif: small horizontal stage dots representing deal distribution */
function DealKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive,
  stageBars,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "warning" | "info";
  trend: string;
  trendPositive: boolean;
  stageBars: { count: number; color: string }[];
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
  };
  const total = stageBars.reduce((s, b) => s + b.count, 0) || 1;
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
            <p className="text-xs text-muted-foreground mt-1">{hint}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* Stage distribution mini bars — distinct motif */}
        <div className="flex items-end gap-1 h-6">
          {stageBars.map((b, i) => (
            <div
              key={i}
              className="flex-1 rounded-sm transition-all duration-500"
              style={{ height: `${(b.count / total) * 100}%`, background: b.color, minHeight: 4 }}
              title={`${b.count} deals`}
            />
          ))}
        </div>
        <div className="flex items-center gap-1 mt-2 text-xs">
          {trendPositive ? (
            <ArrowUpRight className="h-3 w-3 text-[color:var(--success)]" />
          ) : (
            <ArrowDownRight className="h-3 w-3 text-[color:var(--success)]" />
          )}
          <span className="text-[color:var(--success)] font-medium">{trend}</span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DealsPage() {
  const totalPipelineValue = pipelineStages.reduce((s, x) => s + x.value, 0);
  const maxStageValue = Math.max(...pipelineStages.map((s) => s.value));

  const columns: Column<Deal>[] = React.useMemo(
    () => [
      {
        key: "deal",
        header: "Deal Name",
        sortable: true,
        sortAccessor: (r) => r.name,
        cell: (r) => (
          <div className="flex items-center gap-2.5 min-w-0">
            <img src={r.logo} alt={`${r.company} logo`} className="h-9 w-9 rounded-lg object-cover bg-muted shrink-0" />
            <div className="min-w-0">
              <p className="font-medium text-sm text-foreground truncate">{r.name}</p>
              <p className="text-xs text-muted-foreground truncate">
                <span className="font-mono">{r.id}</span> · {r.company}
              </p>
            </div>
          </div>
        ),
      },
      {
        key: "company",
        header: "Company",
        sortable: true,
        sortAccessor: (r) => r.company,
        cell: (r) => <span className="text-sm text-foreground">{r.company}</span>,
        width: "w-40",
        defaultHidden: true,
      },
      {
        key: "value",
        header: "Value",
        sortable: true,
        sortAccessor: (r) => r.value,
        align: "right",
        cell: (r) => (
          <span className="font-semibold tabular-nums">${r.value.toLocaleString()}</span>
        ),
        width: "w-28",
      },
      {
        key: "stage",
        header: "Stage",
        sortable: true,
        sortAccessor: (r) => r.stage,
        filterable: true,
        filterAccessor: (r) => r.stage,
        filterOptions: [
          { label: "Lead", value: "lead" },
          { label: "Qualified", value: "qualified" },
          { label: "Proposal", value: "proposal" },
          { label: "Negotiation", value: "negotiation" },
          { label: "Won", value: "won" },
          { label: "Lost", value: "lost" },
        ],
        align: "center",
        cell: (r) => (
          <StatusBadge tone={stageToneMap[r.stage]} dot>
            {stageLabelMap[r.stage]}
          </StatusBadge>
        ),
        width: "w-32",
      },
      {
        key: "probability",
        header: "Probability",
        sortable: true,
        sortAccessor: (r) => r.probability,
        cell: (r) => (
          <div className="flex items-center gap-2 w-32">
            <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full transition-all duration-500",
                  r.probability >= 75
                    ? "bg-[color:var(--success)]"
                    : r.probability >= 50
                    ? "bg-primary"
                    : r.probability >= 25
                    ? "bg-[color:var(--warning)]"
                    : "bg-destructive"
                )}
                style={{ width: `${r.probability}%` }}
              />
            </div>
            <span
              className={cn(
                "text-xs font-semibold tabular-nums",
                r.probability >= 75
                  ? "text-[color:var(--success)]"
                  : r.probability >= 50
                  ? "text-primary"
                  : r.probability >= 25
                  ? "text-[color:var(--warning)]"
                  : "text-destructive"
              )}
            >
              {r.probability}%
            </span>
          </div>
        ),
        width: "w-32",
      },
      {
        key: "owner",
        header: "Owner",
        sortable: true,
        sortAccessor: (r) => r.owner,
        cell: (r) => (
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={r.ownerAvatar} alt={r.owner} />
              <AvatarFallback className="text-[9px]">
                {r.owner.split(" ").map((p) => p[0]).join("")}
              </AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground truncate">{r.owner}</span>
          </div>
        ),
        width: "w-36",
      },
      {
        key: "expectedClose",
        header: "Expected Close",
        sortable: true,
        sortAccessor: (r) => r.expectedClose,
        cell: (r) => (
          <span className="text-xs text-muted-foreground font-mono whitespace-nowrap">{r.expectedClose}</span>
        ),
        width: "w-32",
      },
      {
        key: "priority",
        header: "Priority",
        sortable: true,
        sortAccessor: (r) => r.priority,
        filterable: true,
        filterAccessor: (r) => r.priority,
        filterOptions: [
          { label: "Critical", value: "critical" },
          { label: "High", value: "high" },
          { label: "Medium", value: "medium" },
          { label: "Low", value: "low" },
        ],
        align: "center",
        cell: (r) => (
          <StatusBadge tone={priorityToneMap[r.priority]} className="capitalize">
            {r.priority}
          </StatusBadge>
        ),
        width: "w-24",
      },
      {
        key: "actions",
        header: "Actions",
        align: "right",
        hideable: false,
        cell: (r) => (
          <div onClick={(e) => e.stopPropagation()}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-44">
                <DropdownMenuLabel className="text-xs font-mono">{r.id}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening deal ${r.id}`)}>
                  <Eye className="h-3.5 w-3.5" /> View deal
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Proposal emailed to ${r.company}`)}>
                  <Mail className="h-3.5 w-3.5" /> Send proposal
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Meeting scheduled for ${r.name}`)}>
                  <Calendar className="h-3.5 w-3.5" /> Schedule meeting
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${r.name} marked as lost`)}>
                  <Trash2 className="h-3.5 w-3.5" /> Mark as lost
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        ),
        width: "w-16",
      },
    ],
    []
  );

  return (
    <>
      <PageHeader
        title="Deals"
        description="Track every opportunity through your pipeline — from first pitch to closed-won."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Deals" }]}
        icon={Briefcase}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Deals exported as CSV")}>
              <Briefcase className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Create deal form opened")}>
              <Plus className="h-3.5 w-3.5" /> Create Deal
            </Button>
          </>
        }
      />

      {/* KPI Row — stage-mini-bars motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <DealKpi label="Open Deals" value="93" hint="across 4 active stages" icon={Briefcase} accent="primary" trend="+6.8% this month" trendPositive={true} stageBars={[{ count: 38, color: "var(--info)" }, { count: 26, color: "var(--primary)" }, { count: 18, color: "oklch(0.62 0.18 305)" }, { count: 11, color: "oklch(0.70 0.15 75)" }]} />
        <DealKpi label="Total Value" value="$2.36M" hint="weighted $1.42M" icon={DollarSign} accent="info" trend="+12.4% vs last month" trendPositive={true} stageBars={[{ count: 30, color: "var(--info)" }, { count: 25, color: "var(--primary)" }, { count: 30, color: "oklch(0.62 0.18 305)" }, { count: 20, color: "oklch(0.70 0.15 75)" }]} />
        <DealKpi label="Won (this month)" value="8" hint="$294K closed revenue" icon={Trophy} accent="success" trend="+3 wins vs June" trendPositive={true} stageBars={[{ count: 2, color: "var(--success)" }, { count: 3, color: "var(--success)" }, { count: 2, color: "var(--success)" }, { count: 1, color: "var(--success)" }]} />
        <DealKpi label="Lost (this month)" value="4" hint="$48K lost value" icon={XCircle} accent="warning" trend="−2 losses vs June" trendPositive={true} stageBars={[{ count: 1, color: "var(--destructive)" }, { count: 2, color: "var(--destructive)" }, { count: 1, color: "var(--destructive)" }, { count: 0, color: "var(--destructive)" }]} />
      </div>

      {/* Pipeline visualization — horizontal stages with counts and $ values */}
      <Card className="mb-6">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Flame className="h-4 w-4 text-[color:var(--warning)]" />
              Deal Stage Pipeline
            </CardTitle>
            <CardDescription>
              {pipelineStages.reduce((s, x) => s + x.count, 0)} open deals ·{" "}
              <span className="font-medium text-foreground tabular-nums">${(totalPipelineValue / 1000).toFixed(0)}K total value</span>
            </CardDescription>
          </div>
          <StatusBadge tone="primary" dot>Live</StatusBadge>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
            {pipelineStages.map((s, i) => {
              const isLast = i === pipelineStages.length - 1;
              const barWidth = (s.value / maxStageValue) * 100;
              return (
                <div key={s.stage} className="relative">
                  {!isLast && (
                    <div className="hidden sm:flex absolute top-7 -right-2.5 z-10 h-5 w-5 items-center justify-center text-muted-foreground/50">
                      <ChevronRight className="h-4 w-4" />
                    </div>
                  )}
                  <div className="rounded-lg border border-border bg-muted/30 p-3 h-full flex flex-col">
                    <div className="flex items-center gap-1.5 mb-2">
                      <span className="h-2 w-2 rounded-full shrink-0" style={{ background: s.color }} />
                      <span className="text-xs font-medium text-foreground truncate">{s.stage}</span>
                    </div>
                    <p className="text-2xl font-semibold tabular-nums tracking-tight">{s.count}</p>
                    <p className="text-xs text-muted-foreground tabular-nums mt-0.5">
                      ${(s.value / 1000).toFixed(0)}K
                    </p>
                    {/* Horizontal value bar */}
                    <div className="mt-3 h-1.5 w-full rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-700 ease-out" style={{ width: `${barWidth}%`, background: s.color, opacity: 0.85 }} />
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-1.5 tabular-nums">
                      {((s.count / pipelineStages.reduce((s, x) => s + x.count, 0)) * 100).toFixed(0)}% of pipeline
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Deals DataTable */}
      <DataTable
        title="All Deals"
        data={deals}
        columns={columns}
        searchKeys={["name", "company", "id"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening deal ${r.id}`)}
        enableSelection
        enableExport
        enableDensity
        enableColumnVisibility
        pageSize={10}
        initialSort={{ key: "value", direction: "desc" }}
        bulkActions={[
          {
            label: "Mark as won",
            icon: Trophy,
            onClick: (sel) => toast.success(`Marked ${sel.length} deal${sel.length > 1 ? "s" : ""} as won`),
          },
          {
            label: "Assign owner",
            icon: Briefcase,
            onClick: (sel) => toast.message(`Assigning ${sel.length} deal${sel.length > 1 ? "s" : ""}…`),
          },
          {
            label: "Export selected",
            icon: DollarSign,
            onClick: (sel) => toast.success(`Exported ${sel.length} deal${sel.length > 1 ? "s" : ""}`),
          },
          {
            label: "Delete",
            icon: Trash2,
            onClick: (sel) => toast.error(`Deleted ${sel.length} deal${sel.length > 1 ? "s" : ""}`),
          },
        ]}
      />
    </>
  );
}
