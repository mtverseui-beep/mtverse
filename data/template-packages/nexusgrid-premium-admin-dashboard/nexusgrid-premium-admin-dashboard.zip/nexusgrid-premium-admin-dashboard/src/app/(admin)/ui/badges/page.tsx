"use client";

import * as React from "react";
import {
  Tag as TagIcon,
  CheckCircle2,
  AlertTriangle,
  Info,
  XCircle,
  Clock,
  X,
  Bell,
  Mail,
  MessageSquare,
  ShoppingCart,
  Star,
  GitPullRequest,
  GitBranch,
  Lock,
  Sparkles,
  Flame,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function Section({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent className="flex flex-wrap items-center gap-3">
        {children}
      </CardContent>
    </Card>
  );
}

export default function BadgesPage() {
  const [removable, setRemovable] = React.useState(["TypeScript", "React 19", "Tailwind v4", "Prisma"]);
  const [notifications, setNotifications] = React.useState(8);

  const removeTag = (tag: string) => {
    setRemovable((prev) => prev.filter((t) => t !== tag));
    toast.message(`Removed "${tag}"`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Badges"
        description="Compact status labels — variants, dots, icons, removable tags and count badges."
        icon={TagIcon}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/badges" },
          { label: "Badges" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Badge tokens copied to clipboard")}>
            <Sparkles /> Copy tokens
          </Button>
        }
      />

      {/* Variants */}
      <Section
        title="Variants"
        description="The four built-in shadcn variants, extended with success, warning and info tones."
      >
        <Badge>Default</Badge>
        <Badge variant="secondary">Secondary</Badge>
        <Badge variant="destructive">Destructive</Badge>
        <Badge variant="outline">Outline</Badge>
        <Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent">
          Success
        </Badge>
        <Badge className="bg-[color:var(--warning)]/15 text-[color:var(--warning)] ring-1 ring-inset ring-[color:var(--warning)]/25 border-transparent">
          Warning
        </Badge>
        <Badge className="bg-[color:var(--info)]/15 text-[color:var(--info)] ring-1 ring-inset ring-[color:var(--info)]/25 border-transparent">
          Info
        </Badge>
        <Badge className="bg-violet-500/15 text-violet-500 ring-1 ring-inset ring-violet-500/25 border-transparent">
          Violet
        </Badge>
      </Section>

      {/* With dots */}
      <Section
        title="With status dots"
        description="Pulse-friendly status pills indicating live or operational state."
      >
        <Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--success)] animate-pulse" />
          Online
        </Badge>
        <Badge className="bg-[color:var(--warning)]/15 text-[color:var(--warning)] ring-1 ring-inset ring-[color:var(--warning)]/25 border-transparent gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--warning)]" />
          Away
        </Badge>
        <Badge className="bg-muted text-muted-foreground ring-1 ring-inset ring-border gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground" />
          Offline
        </Badge>
        <Badge className="bg-destructive/15 text-destructive ring-1 ring-inset ring-destructive/25 border-transparent gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-destructive" />
          Error
        </Badge>
        <Badge className="bg-[color:var(--info)]/15 text-[color:var(--info)] ring-1 ring-inset ring-[color:var(--info)]/25 border-transparent gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--info)]" />
          Syncing
        </Badge>
      </Section>

      {/* With icons */}
      <Section
        title="With icons"
        description="Badges with a leading icon for additional context."
      >
        <Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent gap-1">
          <CheckCircle2 /> Verified
        </Badge>
        <Badge className="bg-[color:var(--warning)]/15 text-[color:var(--warning)] ring-1 ring-inset ring-[color:var(--warning)]/25 border-transparent gap-1">
          <AlertTriangle /> Pending review
        </Badge>
        <Badge className="bg-destructive/15 text-destructive ring-1 ring-inset ring-destructive/25 border-transparent gap-1">
          <XCircle /> Failed
        </Badge>
        <Badge className="bg-[color:var(--info)]/15 text-[color:var(--info)] ring-1 ring-inset ring-[color:var(--info)]/25 border-transparent gap-1">
          <Info /> New
        </Badge>
        <Badge className="bg-muted text-muted-foreground ring-1 ring-inset ring-border gap-1">
          <Clock /> Awaiting
        </Badge>
        <Badge className="bg-violet-500/15 text-violet-500 ring-1 ring-inset ring-violet-500/25 border-transparent gap-1">
          <Flame /> Hot
        </Badge>
        <Badge className="bg-primary/15 text-primary ring-1 ring-inset ring-primary/25 border-transparent gap-1">
          <TrendingUp /> Trending
        </Badge>
      </Section>

      {/* Removable tags */}
      <Section
        title="Removable tags"
        description="Tag chips with a dismiss control — commonly used for filters and multi-select fields."
      >
        {removable.length === 0 ? (
          <span className="text-sm text-muted-foreground">All tags cleared.</span>
        ) : (
          removable.map((tag) => (
            <Badge
              key={tag}
              variant="secondary"
              className="rounded-full pl-3 pr-1 py-1 gap-1.5 text-sm"
            >
              {tag}
              <button
                type="button"
                aria-label={`Remove ${tag}`}
                onClick={() => removeTag(tag)}
                className="grid place-items-center h-4 w-4 rounded-full hover:bg-foreground/10 transition-colors"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))
        )}
        <Button
          variant="outline"
          size="sm"
          onClick={() => setRemovable(["TypeScript", "React 19", "Tailwind v4", "Prisma"])}
        >
          Reset tags
        </Button>
      </Section>

      {/* Status badges */}
      <Section
        title="Status badges (shared component)"
        description="The shared StatusBadge component is used across all tables and dashboards."
      >
        <StatusBadge tone="success" dot>
          Active
        </StatusBadge>
        <StatusBadge tone="warning" dot>
          Trial
        </StatusBadge>
        <StatusBadge tone="danger" dot>
          Suspended
        </StatusBadge>
        <StatusBadge tone="info" dot>
          Invited
        </StatusBadge>
        <StatusBadge tone="neutral" dot>
          Archived
        </StatusBadge>
        <StatusBadge tone="primary" dot>
          Premium
        </StatusBadge>
        <StatusBadge tone="violet" dot>
          Enterprise
        </StatusBadge>
      </Section>

      {/* Count + notification badges */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Count & notification badges</CardTitle>
            <CardDescription>
              Anchored counts for unread messages, cart items, or notifications.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap items-center gap-8">
            <div className="relative">
              <Button variant="outline" size="icon" aria-label="Notifications">
                <Bell />
              </Button>
              <span className="absolute -top-1.5 -right-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-destructive px-1 text-[10px] font-semibold text-white ring-2 ring-background">
                {notifications}
              </span>
            </div>
            <div className="relative">
              <Button variant="outline" size="icon" aria-label="Inbox">
                <Mail />
              </Button>
              <span className="absolute -top-1.5 -right-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-foreground ring-2 ring-background">
                24
              </span>
            </div>
            <div className="relative">
              <Button variant="outline" size="icon" aria-label="Comments">
                <MessageSquare />
              </Button>
              <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-[color:var(--success)] ring-2 ring-background" />
            </div>
            <div className="relative">
              <Button variant="outline" size="icon" aria-label="Cart">
                <ShoppingCart />
              </Button>
              <span className="absolute -top-1.5 -right-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-[color:var(--warning)] px-1 text-[10px] font-semibold text-white ring-2 ring-background">
                3
              </span>
            </div>
            <div className="flex flex-col gap-2">
              <Button size="sm" variant="ghost" onClick={() => setNotifications((n) => Math.max(0, n - 1))}>
                Mark one read
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setNotifications(8)}>
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">In-context badges</CardTitle>
            <CardDescription>
              How badges look alongside avatars, list items and PR metadata.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border p-2.5">
              <div className="flex items-center gap-2.5 min-w-0">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop" />
                  <AvatarFallback>AR</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">Amara Reyes</p>
                  <p className="text-xs text-muted-foreground truncate">amara@nexusgrid.io</p>
                </div>
              </div>
              <StatusBadge tone="success" dot>
                Online
              </StatusBadge>
            </div>

            <div className="flex items-center justify-between rounded-lg border p-2.5">
              <div className="flex items-center gap-2.5">
                <GitPullRequest className="h-4 w-4 text-[color:var(--success)]" />
                <div>
                  <p className="text-sm font-medium">PR #1284 — Add dark mode tokens</p>
                  <p className="text-xs text-muted-foreground">opened 2 hours ago by you</p>
                </div>
              </div>
              <Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent">
                Merged
              </Badge>
            </div>

            <div className="flex items-center justify-between rounded-lg border p-2.5">
              <div className="flex items-center gap-2.5">
                <GitBranch className="h-4 w-4 text-violet-500" />
                <div>
                  <p className="text-sm font-medium">feat/billing-engine</p>
                  <p className="text-xs text-muted-foreground">3 commits ahead of main</p>
                </div>
              </div>
              <Badge variant="outline" className="gap-1">
                <Lock className="h-3 w-3" /> Protected
              </Badge>
            </div>

            <div className="flex items-center justify-between rounded-lg border p-2.5">
              <div className="flex items-center gap-2.5">
                <Star className="h-4 w-4 text-amber-500" />
                <div>
                  <p className="text-sm font-medium">Pro plan subscription</p>
                  <p className="text-xs text-muted-foreground">renews on Jul 28, 2026</p>
                </div>
              </div>
              <Badge className="bg-amber-500/15 text-amber-600 ring-1 ring-inset ring-amber-500/25 border-transparent dark:text-amber-400">
                Pro
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sizing */}
      <Section
        title="Sizing"
        description="Badges scale by adjusting padding and font size — keep proportions tight."
      >
        <Badge className="text-[10px] px-1.5 py-0">XS badge</Badge>
        <Badge className="text-xs px-2 py-0.5">Small badge</Badge>
        <Badge>Default badge</Badge>
        <Badge className="text-sm px-3 py-1">Large badge</Badge>
        <Badge className="text-base px-4 py-1.5 rounded-full">Pill badge</Badge>
      </Section>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Badges page · 8 color tones · dots · icons · removable tags · notification counts · shared StatusBadge
      </p>
    </div>
  );
}
