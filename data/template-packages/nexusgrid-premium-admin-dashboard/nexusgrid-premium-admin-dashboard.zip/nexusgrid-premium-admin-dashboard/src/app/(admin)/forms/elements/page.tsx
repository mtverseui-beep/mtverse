"use client";

import * as React from "react";
import {
  FormInput,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Link2,
  Phone,
  Hash,
  DollarSign,
  Calendar as CalendarIcon,
  Upload,
  FileImage,
  X,
  Search,
  User,
  CreditCard,
  Palette,
  CheckCircle2,
  Minus,
  Loader2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { format } from "date-fns";

function Field({
  label,
  hint,
  children,
  htmlFor,
  className,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
  htmlFor?: string;
  className?: string;
}) {
  return (
    <div className={cn("grid gap-1.5", className)}>
      <Label htmlFor={htmlFor} className="text-xs">
        {label}
      </Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}

function SectionCard({
  title,
  description,
  badge,
  children,
}: {
  title: string;
  description: string;
  badge?: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">{title}</CardTitle>
            <CardDescription className="mt-1">{description}</CardDescription>
          </div>
          {badge && <Badge variant="secondary" className="text-[10px] uppercase tracking-wide">{badge}</Badge>}
        </div>
      </CardHeader>
      <CardContent className="grid gap-4">{children}</CardContent>
    </Card>
  );
}

export default function FormElementsPage() {
  const [showPassword, setShowPassword] = React.useState(false);
  const [bio, setBio] = React.useState("");
  const [singleSlider, setSingleSlider] = React.useState([42]);
  const [rangeSlider, setRangeSlider] = React.useState([20, 75]);
  const [date, setDate] = React.useState<Date | undefined>(undefined);
  const [toggleA, setToggleA] = React.useState(true);
  const [toggleB, setToggleB] = React.useState(false);
  const [toggleC, setToggleC] = React.useState(true);
  const [radio, setRadio] = React.useState("express");
  const [color, setColor] = React.useState("#6366f1");
  const [filePreview, setFilePreview] = React.useState<string | null>(null);
  const [fileName, setFileName] = React.useState<string>("");
  const fileRef = React.useRef<HTMLInputElement>(null);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFileName(f.name);
    if (f.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = () => setFilePreview(reader.result as string);
      reader.readAsDataURL(f);
    } else {
      setFilePreview(null);
    }
    toast.success(`Attached ${f.name}`);
  };

  return (
    <>
      <PageHeader
        title="Form Elements"
        description="A comprehensive catalog of every input control available in the NexusGrid design system."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Form Elements" }]}
        icon={FormInput}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => toast.message("Copied form schema to clipboard")}>
              Copy Schema
            </Button>
            <Button size="sm" onClick={() => toast.success("Form draft saved")}>
              Save Draft
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* TEXT INPUTS */}
        <SectionCard title="Text Inputs" description="Default, placeholder, disabled, readonly, with icon and prefix/suffix variants." badge="12 variants">
          <Field label="Default" htmlFor="txt-default">
            <Input id="txt-default" defaultValue="AuroraWorkspace" />
          </Field>
          <Field label="With placeholder" htmlFor="txt-placeholder" hint="Helper text appears muted below the field.">
            <Input id="txt-placeholder" placeholder="Enter workspace name" />
          </Field>
          <Field label="Disabled" htmlFor="txt-disabled">
            <Input id="txt-disabled" defaultValue="Read-only tenant" disabled />
          </Field>
          <Field label="Readonly" htmlFor="txt-readonly">
            <Input id="txt-readonly" defaultValue="NX-2026-07-0142" readOnly className="bg-muted/40 font-mono text-xs" />
          </Field>
          <Field label="With leading icon" htmlFor="txt-icon">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input id="txt-icon" placeholder="Search products, orders, customers" className="pl-8" />
            </div>
          </Field>
          <Field label="With prefix and suffix" htmlFor="txt-prefix" hint="Great for currency, percentage or unit fields.">
            <div className="flex items-stretch">
              <span className="inline-flex items-center rounded-l-md border border-r-0 border-input bg-muted px-3 text-xs text-muted-foreground">
                <DollarSign className="h-3.5 w-3.5" />
              </span>
              <Input id="txt-prefix" defaultValue="1,248.50" className="rounded-l-none font-mono" />
              <span className="inline-flex items-center rounded-r-md border border-l-0 border-input bg-muted px-3 text-xs text-muted-foreground">
                USD
              </span>
            </div>
          </Field>
        </SectionCard>

        {/* NUMBER, EMAIL, PASSWORD, URL */}
        <SectionCard title="Specialized Inputs" description="Number, email, password, URL and telephone inputs with proper keyboard hints." badge="5 types">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Number — default" htmlFor="num-default">
              <Input id="num-default" type="number" defaultValue={8} />
            </Field>
            <Field label="Number — with steps" htmlFor="num-steps" hint="step=0.25, min=0, max=10">
              <Input id="num-steps" type="number" step={0.25} min={0} max={10} defaultValue={2.5} />
            </Field>
            <Field label="Email" htmlFor="in-email">
              <div className="relative">
                <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="in-email" type="email" defaultValue="founder@aurora.io" className="pl-8" />
              </div>
            </Field>
            <Field label="Telephone" htmlFor="in-tel">
              <div className="relative">
                <Phone className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="in-tel" type="tel" defaultValue="+1 (415) 555-0148" className="pl-8" />
              </div>
            </Field>
            <Field label="URL" htmlFor="in-url" className="col-span-2">
              <div className="relative">
                <Link2 className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="in-url" type="url" defaultValue="https://aurora.io/docs/api" className="pl-8" />
              </div>
            </Field>
            <Field label="Password" htmlFor="in-pwd" className="col-span-2" hint="Toggle visibility with the eye icon.">
              <div className="relative">
                <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="in-pwd"
                  type={showPassword ? "text" : "password"}
                  defaultValue="aurora-secret-2026"
                  className="pl-8 pr-9"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </Field>
          </div>
        </SectionCard>

        {/* TEXTAREA */}
        <SectionCard title="Textarea" description="Multiline input with character count and auto-resize hints." badge="3 variants">
          <Field label="Default" htmlFor="ta-default">
            <Textarea id="ta-default" placeholder="Tell us about your project" rows={4} />
          </Field>
          <Field label="With character count" htmlFor="ta-count" hint={`${bio.length} / 280 characters`}>
            <Textarea
              id="ta-count"
              rows={4}
              maxLength={280}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Write a short bio"
            />
          </Field>
          <Field label="Auto-resize" htmlFor="ta-auto" hint="field-sizing:content lets the box grow with input.">
            <Textarea id="ta-auto" placeholder="Start typing — the box grows naturally" className="min-h-[60px] max-h-64" />
          </Field>
        </SectionCard>

        {/* SELECTS */}
        <SectionCard title="Selects" description="Default, grouped and large option sets." badge="3 variants">
          <Field label="Default select" htmlFor="sel-default">
            <Select defaultValue="standard">
              <SelectTrigger id="sel-default" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="standard">Standard shipping (3-5 days)</SelectItem>
                <SelectItem value="express">Express shipping (1-2 days)</SelectItem>
                <SelectItem value="overnight">Overnight (next day)</SelectItem>
                <SelectItem value="pickup">Local pickup</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Grouped select" htmlFor="sel-grouped">
            <Select defaultValue="us">
              <SelectTrigger id="sel-grouped" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Americas</SelectLabel>
                  <SelectItem value="us">United States</SelectItem>
                  <SelectItem value="ca">Canada</SelectItem>
                  <SelectItem value="br">Brazil</SelectItem>
                </SelectGroup>
                <SelectSeparator />
                <SelectGroup>
                  <SelectLabel>Europe</SelectLabel>
                  <SelectItem value="de">Germany</SelectItem>
                  <SelectItem value="fr">France</SelectItem>
                  <SelectItem value="nl">Netherlands</SelectItem>
                </SelectGroup>
                <SelectSeparator />
                <SelectGroup>
                  <SelectLabel>Asia Pacific</SelectLabel>
                  <SelectItem value="jp">Japan</SelectItem>
                  <SelectItem value="sg">Singapore</SelectItem>
                  <SelectItem value="au">Australia</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Searchable hint" htmlFor="sel-search" hint="For large option sets use the Combobox pattern on the Select & Combobox page.">
            <Select>
              <SelectTrigger id="sel-search" className="w-full">
                <span className="text-muted-foreground">Select a currency</span>
              </SelectTrigger>
              <SelectContent>
                {["USD — US Dollar", "EUR — Euro", "GBP — British Pound", "JPY — Japanese Yen", "CNY — Chinese Yuan", "AUD — Australian Dollar", "CAD — Canadian Dollar", "CHF — Swiss Franc", "INR — Indian Rupee", "BRL — Brazilian Real"].map((c) => (
                  <SelectItem key={c} value={c.split(" — ")[0]}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </SectionCard>

        {/* CHECKBOXES */}
        <SectionCard title="Checkboxes" description="Default, indeterminate and disabled states." badge="3 states">
          <div className="grid gap-3">
            <Label className="flex items-center gap-2.5 text-sm font-normal">
              <Checkbox defaultChecked />
              Send me product updates and announcements
            </Label>
            <Label className="flex items-center gap-2.5 text-sm font-normal">
              <Checkbox checked="indeterminate" />
              Indeterminate — some sub-items selected
            </Label>
            <Label className="flex items-center gap-2.5 text-sm font-normal text-muted-foreground">
              <Checkbox disabled />
              Disabled option (legacy plan only)
            </Label>
            <Label className="flex items-center gap-2.5 text-sm font-normal">
              <Checkbox defaultChecked disabled />
              Disabled but checked
            </Label>
            <Separator className="my-1" />
            <div className="grid gap-2.5">
              <p className="text-xs font-medium">Channel preferences</p>
              {["Email newsletter", "In-app notifications", "SMS alerts", "Slack integration"].map((c, i) => (
                <Label key={c} className="flex items-center gap-2.5 text-sm font-normal">
                  <Checkbox defaultChecked={i < 2} />
                  {c}
                </Label>
              ))}
            </div>
          </div>
        </SectionCard>

        {/* RADIO + SWITCH */}
        <SectionCard title="Radio Groups & Switches" description="Single-choice radio cards and binary toggles." badge="Choice controls">
          <Field label="Shipping method">
            <RadioGroup value={radio} onValueChange={setRadio} className="gap-2.5">
              {[
                { v: "standard", t: "Standard", d: "3-5 business days · Free" },
                { v: "express", t: "Express", d: "1-2 business days · $12.00" },
                { v: "overnight", t: "Overnight", d: "Next business day · $28.00" },
              ].map((o) => (
                <Label
                  key={o.v}
                  className={cn(
                    "flex items-start gap-3 rounded-lg border p-3 cursor-pointer transition-colors",
                    radio === o.v ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "hover:bg-accent/50"
                  )}
                >
                  <RadioGroupItem value={o.v} className="mt-0.5" />
                  <div className="grid gap-0.5">
                    <span className="text-sm font-medium leading-none">{o.t}</span>
                    <span className="text-xs text-muted-foreground">{o.d}</span>
                  </div>
                </Label>
              ))}
            </RadioGroup>
          </Field>
          <Separator />
          <div className="grid gap-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Two-factor authentication</p>
                <p className="text-xs text-muted-foreground">Require a code at every sign in.</p>
              </div>
              <Switch checked={toggleA} onCheckedChange={setToggleA} />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Beta feature access</p>
                <p className="text-xs text-muted-foreground">Opt into early access releases.</p>
              </div>
              <Switch checked={toggleB} onCheckedChange={setToggleB} />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Auto-save drafts</p>
                <p className="text-xs text-muted-foreground">Save form state every 30 seconds.</p>
              </div>
              <Switch checked={toggleC} onCheckedChange={setToggleC} />
            </div>
          </div>
        </SectionCard>

        {/* SLIDERS */}
        <SectionCard title="Sliders" description="Single thumb and dual-thumb range sliders." badge="2 variants">
          <Field label={`Single value — ${singleSlider[0]}%`} hint="Drag to set commission rate.">
            <Slider value={singleSlider} onValueChange={setSingleSlider} max={100} step={1} />
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>0%</span><span>25%</span><span>50%</span><span>75%</span><span>100%</span>
            </div>
          </Field>
          <Separator />
          <Field label={`Price range — $${rangeSlider[0]} to $${rangeSlider[1]}`} hint="Two-thumb range slider for filtering.">
            <Slider value={rangeSlider} onValueChange={setRangeSlider} min={0} max={100} step={5} />
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>$0</span><span>$50</span><span>$100</span>
            </div>
          </Field>
        </SectionCard>

        {/* DATE PICKER */}
        <SectionCard title="Date Picker" description="Calendar popover built on react-day-picker." badge="Popover">
          <Field label="Delivery date" hint={date ? format(date, "PPP") : "Pick a date"}>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  {date ? format(date, "PPP") : <span className="text-muted-foreground">Choose a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
              </PopoverContent>
            </Popover>
          </Field>
        </SectionCard>

        {/* FILE + COLOR */}
        <SectionCard title="File & Color" description="File input with preview and native color picker styled." badge="Pickers">
          <Field label="File upload with preview" hint="Click to browse an image file.">
            <div className="flex items-center gap-3">
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                onChange={onFile}
                className="hidden"
                id="file-input"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileRef.current?.click()}
                className="gap-1.5"
              >
                <Upload className="h-3.5 w-3.5" /> Browse
              </Button>
              {fileName ? (
                <div className="flex items-center gap-2 min-w-0 flex-1 rounded-md border p-1.5 pr-2">
                  {filePreview ? (
                    <img src={filePreview} alt="" className="h-8 w-8 rounded object-cover" />
                  ) : (
                    <div className="grid place-items-center h-8 w-8 rounded bg-muted">
                      <FileImage className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                  <span className="text-xs truncate flex-1">{fileName}</span>
                  <button
                    type="button"
                    onClick={() => { setFileName(""); setFilePreview(null); if (fileRef.current) fileRef.current.value = ""; }}
                    className="grid place-items-center h-6 w-6 rounded hover:bg-accent text-muted-foreground"
                    aria-label="Remove file"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ) : (
                <span className="text-xs text-muted-foreground">No file selected</span>
              )}
            </div>
          </Field>
          <Separator />
          <Field label="Accent color" hint={`Selected hex: ${color.toUpperCase()}`}>
            <div className="flex items-center gap-3">
              <div className="relative h-9 w-14 rounded-md border overflow-hidden">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                />
                <div className="absolute inset-0" style={{ backgroundColor: color }} />
              </div>
              <Input value={color} onChange={(e) => setColor(e.target.value)} className="font-mono text-xs w-28" />
              <div className="flex gap-1.5">
                {["#6366f1", "#10b981", "#f59e0b", "#ef4444", "#0ea5e9"].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className="h-6 w-6 rounded-full border-2 border-background ring-1 ring-border"
                    style={{ backgroundColor: c }}
                    aria-label={`Pick ${c}`}
                  />
                ))}
              </div>
            </div>
          </Field>
        </SectionCard>
      </div>

      {/* STATES ROW */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-base">Input States</CardTitle>
          <CardDescription>Default, focus, error, success and loading states side by side.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Field label="Default">
              <Input placeholder="Default" />
            </Field>
            <Field label="Error" hint="Invalid email format">
              <Input defaultValue="not-an-email" aria-invalid className="border-destructive focus-visible:ring-destructive/30" />
            </Field>
            <Field label="Success" hint="Username is available">
              <div className="relative">
                <Input defaultValue="aurora-founder" className="pr-8 border-emerald-500 focus-visible:ring-emerald-500/30" />
                <CheckCircle2 className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-emerald-500" />
              </div>
            </Field>
            <Field label="Loading">
              <div className="relative">
                <Input defaultValue="validating" disabled className="pr-8" />
                <Loader2 className="absolute right-2.5 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
              </div>
            </Field>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
