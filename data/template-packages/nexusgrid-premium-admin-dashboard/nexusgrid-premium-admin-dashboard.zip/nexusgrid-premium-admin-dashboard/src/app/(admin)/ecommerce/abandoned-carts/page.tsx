"use client";

import * as React from "react";
import {
  ShoppingCart,
  Mail,
  Target,
  DollarSign,
  ShoppingBag,
  Download,
  Send,
  Eye,
  MoreHorizontal,
  TrendingUp,
  ArrowRight,
  CheckCircle2,
  Clock,
  XCircle,
  RotateCcw,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type CartStage = "viewed" | "email-sent" | "recovered" | "lost";

type AbandonedCart = {
  id: string;
  customer: string;
  email: string;
  avatar: string;
  items: number;
  value: number;
  stage: CartStage;
  abandonedAt: string;
  emailSent: boolean;
  lastNotified?: string;
};

const carts: AbandonedCart[] = [
  { id: "CART-9482", customer: "Sarah Chen", email: "sarah.chen@example.com", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", items: 3, value: 428.50, stage: "email-sent", abandonedAt: "2026-07-01 10:42", emailSent: true, lastNotified: "2026-07-01 14:30" },
  { id: "CART-9481", customer: "Marcus Reyes", email: "marcus.r@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", items: 1, value: 186.00, stage: "viewed", abandonedAt: "2026-07-01 09:18", emailSent: false },
  { id: "CART-9480", customer: "Elena Petrov", email: "elena.petrov@example.com", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", items: 5, value: 742.25, stage: "recovered", abandonedAt: "2026-06-30 16:24", emailSent: true, lastNotified: "2026-06-30 19:00" },
  { id: "CART-9479", customer: "James Okoro", email: "j.okoro@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", items: 2, value: 96.99, stage: "lost", abandonedAt: "2026-06-29 11:08", emailSent: true, lastNotified: "2026-06-29 15:30" },
  { id: "CART-9478", customer: "Aiko Tanaka", email: "aiko.t@example.com", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", items: 2, value: 312.00, stage: "email-sent", abandonedAt: "2026-06-30 22:14", emailSent: true, lastNotified: "2026-07-01 06:00" },
  { id: "CART-9477", customer: "David Kim", email: "d.kim@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", items: 4, value: 528.75, stage: "recovered", abandonedAt: "2026-06-29 13:42", emailSent: true, lastNotified: "2026-06-29 18:00" },
  { id: "CART-9476", customer: "Lena Hoffmann", email: "lena.h@example.com", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", items: 1, value: 144.50, stage: "viewed", abandonedAt: "2026-07-01 08:02", emailSent: false },
  { id: "CART-9475", customer: "Raj Patel", email: "raj.patel@example.com", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", items: 6, value: 1248.00, stage: "email-sent", abandonedAt: "2026-06-30 19:48", emailSent: true, lastNotified: "2026-06-30 22:30" },
  { id: "CART-9474", customer: "Mei Lin", email: "mei.lin@example.com", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", items: 3, value: 287.40, stage: "lost", abandonedAt: "2026-06-28 14:18", emailSent: true, lastNotified: "2026-06-28 18:00" },
  { id: "CART-9473", customer: "Carlos Mendez", email: "c.mendez@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", items: 2, value: 178.20, stage: "recovered", abandonedAt: "2026-06-28 09:24", emailSent: true, lastNotified: "2026-06-28 14:00" },
  { id: "CART-9472", customer: "Priya Sharma", email: "priya.s@example.com", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", items: 8, value: 1840.00, stage: "email-sent", abandonedAt: "2026-06-30 11:36", emailSent: true, lastNotified: "2026-06-30 16:00" },
  { id: "CART-9471", customer: "Sofia Rossi", email: "sofia.rossi@example.com", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", items: 4, value: 612.30, stage: "viewed", abandonedAt: "2026-07-01 07:14", emailSent: false },
];

const stageToneMap: Record<CartStage, "info" | "primary" | "success" | "danger"> = {
  viewed: "info",
  "email-sent": "primary",
  recovered: "success",
  lost: "danger",
};

const stageLabelMap: Record<CartStage, string> = {
  viewed: "Cart Viewed",
  "email-sent": "Email Sent",
  recovered: "Recovered",
  lost: "Lost",
};

// Funnel: Cart Created → Cart Viewed → Email Sent → Recovered
const funnelStages = [
  { key: "created", label: "Carts Created", value: 8420, icon: ShoppingCart, color: "var(--info)" },
  { key: "viewed", label: "Cart Viewed", value: 5240, icon: Eye, color: "oklch(0.58 0.13 250)" },
  { key: "sent", label: "Recovery Email Sent", value: 3180, icon: Mail, color: "var(--primary)" },
  { key: "recovered", label: "Recovered", value: 1084, icon: CheckCircle2, color: "var(--success)" },
];

// Recovery-style KPI card — funnel-step colored top strip
function CartKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive = true,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "info" | "success" | "warning";
  trend: string;
  trendPositive?: boolean;
}) {
  const accentStrip = {
    primary: "bg-primary",
    info: "bg-[color:var(--info)]",
    success: "bg-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]",
  };
  const accentIcon = {
    primary: "bg-primary/10 text-primary",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  return (
    <Card className="relative overflow-hidden">
      <div className={cn("h-1 w-full", accentStrip[accent])} />
      <CardContent className="pt-4 pb-4">
        <div className="flex items-start justify-between mb-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
          <div className={cn("grid place-items-center h-8 w-8 rounded-lg shrink-0", accentIcon[accent])}>
            <Icon className="h-4 w-4" />
          </div>
        </div>
        <p className="text-2xl font-semibold tabular-nums">{value}</p>
        <p className="text-xs text-muted-foreground mt-1">{hint}</p>
        <p className={cn(
          "text-xs font-medium mt-2 inline-flex items-center gap-0.5",
          trendPositive ? "text-[color:var(--success)]" : "text-destructive"
        )}>
          <TrendingUp className="h-3 w-3" /> {trend}
        </p>
      </CardContent>
    </Card>
  );
}

export default function AbandonedCartsPage() {
  return (
    <>
      <PageHeader
        title="Abandoned Carts"
        description="Recover lost revenue from carts left before checkout with timely recovery emails."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Abandoned Carts" }]}
        icon={ShoppingCart}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Carts report exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Recovery campaign launched to 12 recipients")}>
              <Send className="h-3.5 w-3.5" /> Send Recovery Campaign
            </Button>
          </>
        }
      />

      {/* KPI cards — funnel-step colored top strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <CartKpi label="Abandoned Carts" value="1,284" hint="last 30 days" icon={ShoppingCart} accent="warning" trend="6.4% of all carts" trendPositive={false} />
        <CartKpi label="Recovery Rate" value="34.1%" hint="industry avg: 28%" icon={Target} accent="primary" trend="+2.8% vs last month" />
        <CartKpi label="Recovered Revenue" value="$284,820" hint="from 1,084 carts" icon={DollarSign} accent="success" trend="+18.2% vs last month" />
        <CartKpi label="Avg Cart Value" value="$221.80" hint="abandoned carts" icon={ShoppingBag} accent="info" trend="+4.6% vs last month" />
      </div>

      {/* Recovery funnel — custom horizontal step funnel */}
      <Card className="mb-6">
        <CardHeader className="pb-2 flex flex-row items-start justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              Recovery Funnel
            </CardTitle>
            <CardDescription>Cart abandonment journey from creation to recovery.</CardDescription>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <div className="text-right">
              <p className="text-muted-foreground">Overall Recovery</p>
              <p className="font-semibold text-[color:var(--success)] text-base tabular-nums">12.87%</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {funnelStages.map((stage, i) => {
              const Icon = stage.icon;
              const max = funnelStages[0].value;
              const pct = (stage.value / max) * 100;
              const conv = i === 0 ? 100 : (stage.value / funnelStages[i - 1].value) * 100;
              return (
                <div key={stage.key} className="relative">
                  {i < funnelStages.length - 1 && (
                    <div className="hidden md:flex absolute top-1/2 -right-2 -translate-y-1/2 z-10 items-center justify-center h-6 w-6 rounded-full bg-card border border-border">
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                    </div>
                  )}
                  <div
                    className="rounded-xl border border-border p-4 h-full transition-all hover:shadow-premium-sm"
                    style={{ background: `linear-gradient(180deg, color-mix(in srgb, ${stage.color} 6%, transparent), transparent)` }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div
                        className="grid place-items-center h-9 w-9 rounded-lg"
                        style={{ background: `color-mix(in srgb, ${stage.color} 14%, transparent)`, color: stage.color }}
                      >
                        <Icon className="h-4.5 w-4.5" />
                      </div>
                      {i > 0 && (
                        <StatusBadge tone={conv >= 60 ? "success" : conv >= 40 ? "warning" : "danger"} dot>
                          {conv.toFixed(1)}%
                        </StatusBadge>
                      )}
                    </div>
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{stage.label}</p>
                    <p className="text-2xl font-semibold tabular-nums mt-0.5">{stage.value.toLocaleString()}</p>
                    <div className="mt-3 h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct}%`, background: stage.color }}
                      />
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-1.5">
                      {pct.toFixed(1)}% of created carts
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 pt-4 border-t border-border">
            <div>
              <p className="text-xs text-muted-foreground">Stage Drop-off Avg</p>
              <p className="text-sm font-semibold tabular-nums mt-0.5">−29.4%</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Email Open Rate</p>
              <p className="text-sm font-semibold tabular-nums mt-0.5">42.8%</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Email Click Rate</p>
              <p className="text-sm font-semibold tabular-nums mt-0.5">18.4%</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Revenue per Email</p>
              <p className="text-sm font-semibold tabular-nums mt-0.5">$89.50</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Abandoned carts table — custom */}
      <Card>
        <CardContent className="p-0">
          <div className="flex items-center justify-between p-3 sm:p-4 border-b border-border bg-muted/30">
            <div>
              <h3 className="text-sm font-semibold">Active Abandoned Carts</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Carts awaiting recovery action</p>
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge tone="info" dot>{carts.filter((c) => c.stage === "viewed").length} awaiting email</StatusBadge>
              <StatusBadge tone="primary" dot>{carts.filter((c) => c.stage === "email-sent").length} in progress</StatusBadge>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Cart ID</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Customer</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Items</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Value</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Stage</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Abandoned</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Email Sent</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-32">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {carts.map((c) => (
                  <tr
                    key={c.id}
                    className="hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => toast.message(`Opening cart ${c.id} detail`)}
                  >
                    <td className="px-4 py-3 font-mono text-xs font-semibold">{c.id}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <Avatar className="h-7 w-7 shrink-0">
                          <AvatarImage src={c.avatar} alt={c.customer} />
                          <AvatarFallback className="text-[10px]">{c.customer.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{c.customer}</p>
                          <p className="text-xs text-muted-foreground truncate">{c.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">
                      <span className="inline-flex items-center gap-1 text-xs">
                        <ShoppingBag className="h-3 w-3 text-muted-foreground" /> {c.items}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold">${c.value.toFixed(2)}</td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={stageToneMap[c.stage]} dot>{stageLabelMap[c.stage]}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground font-mono hidden md:table-cell">{c.abandonedAt}</td>
                    <td className="px-4 py-3 text-center hidden sm:table-cell">
                      {c.emailSent ? (
                        <span className="inline-flex items-center gap-1 text-xs text-[color:var(--success)]">
                          <CheckCircle2 className="h-3.5 w-3.5" /> Yes
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                          <XCircle className="h-3.5 w-3.5" /> No
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="inline-flex items-center gap-1">
                        {!c.emailSent && c.stage !== "recovered" && c.stage !== "lost" && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 text-xs gap-1"
                            onClick={() => toast.success(`Recovery email sent to ${c.email}`)}
                          >
                            <Mail className="h-3 w-3" /> Send
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0"
                          onClick={() => toast.message(`Opening cart ${c.id} detail`)}
                        >
                          <Eye className="h-3.5 w-3.5" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuLabel className="text-xs font-mono">{c.id}</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening cart ${c.id} detail`)}>
                              <Eye className="h-3.5 w-3.5" /> View cart
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Recovery email sent to ${c.email}`)}>
                              <Send className="h-3.5 w-3.5" /> Send recovery email
                            </DropdownMenuItem>
                            {c.stage === "recovered" && (
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Order created from ${c.id}`)}>
                                <ShoppingCart className="h-3.5 w-3.5" /> View order
                              </DropdownMenuItem>
                            )}
                            {c.stage !== "lost" && c.stage !== "recovered" && (
                              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.error(`Marked ${c.id} as lost`)}>
                                <RotateCcw className="h-3.5 w-3.5" /> Mark as lost
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between p-3 border-t border-border bg-muted/30">
            <span className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">{carts.length}</span> carts ·{" "}
              <span className="font-medium text-[color:var(--success)]">${carts.reduce((s, c) => s + c.value, 0).toFixed(2)}</span> at-risk revenue
            </span>
            <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.message("Opening full abandoned-carts ledger")}>
              View all <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Bottom insight tiles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <Card className="bg-gradient-to-br from-primary/5 to-transparent">
          <CardContent className="pt-5">
            <div className="flex items-start gap-3">
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary shrink-0">
                <Clock className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Best Recovery Window</p>
                <p className="text-lg font-semibold mt-1">1–3 hours after</p>
                <p className="text-xs text-muted-foreground mt-0.5">42% of recoveries happen here</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start gap-3">
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--success)]/15 text-[color:var(--success)] shrink-0">
                <Target className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Most Effective Subject</p>
                <p className="text-lg font-semibold mt-1">"Forgot something?"</p>
                <p className="text-xs text-muted-foreground mt-0.5">48% open rate · 22% CTR</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start gap-3">
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--warning)]/15 text-[color:var(--warning)] shrink-0">
                <Mail className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Recovery Email Queue</p>
                <p className="text-lg font-semibold mt-1">8 scheduled</p>
                <p className="text-xs text-muted-foreground mt-0.5">Next send in 24 min</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
