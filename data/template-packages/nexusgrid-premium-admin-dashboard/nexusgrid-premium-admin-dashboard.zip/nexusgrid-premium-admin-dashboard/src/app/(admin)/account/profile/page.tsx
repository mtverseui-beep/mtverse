"use client";

import * as React from "react";
import {
  User,
  MapPin,
  Calendar,
  Briefcase,
  Mail,
  Phone,
  Globe,
  Github,
  Twitter,
  Linkedin,
  Dribbble,
  Pencil,
  Award,
  FolderGit2,
  Activity,
  TrendingUp,
  CheckCircle2,
  Star,
  Zap,
  Target,
  GitPullRequest,
  FileText,
  MessageSquare,
  Plus,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const PROFILE = {
  name: "Amara Okafor",
  firstName: "Amara",
  lastName: "Okafor",
  role: "Principal Product Engineer",
  team: "Platform Infrastructure",
  username: "amara.o",
  email: "amara.okafor@nexusgrid.io",
  phone: "+1 (415) 555-0182",
  location: "San Francisco, CA",
  timezone: "UTC-08:00 Pacific",
  joined: "March 2022",
  cover: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=1600&q=80&auto=format&fit=crop",
  avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=400&q=80&auto=format&fit=crop",
  bio: "Building the compute fabric that powers NexusGrid. Distributed systems, developer tooling, and the occasional 3am incident review. Previously at Fly.io and Stripe.",
  website: "amara.dev",
  social: { github: "amara-o", twitter: "amara_codes", linkedin: "amaraokafor", dribbble: "" },
  stats: { commits: 1842, prs: 318, reviews: 624, deployments: 142 },
  skills: ["TypeScript", "Rust", "Kubernetes", "Distributed Systems", "PostgreSQL", "gRPC", "Terraform", "Observability", "System Design", "Go"],
};

type ActivityItem = {
  id: string;
  icon: React.ElementType;
  iconTone: "success" | "info" | "primary" | "warning" | "violet";
  title: string;
  detail: string;
  time: string;
};

const ACTIVITY: ActivityItem[] = [
  { id: "a1", icon: GitPullRequest, iconTone: "success", title: "Merged pull request #2841", detail: "feat: shard the events queue across regions", time: "12 minutes ago" },
  { id: "a2", icon: FileText, iconTone: "info", title: "Published RFC-014", detail: "Multi-region write conflict resolution", time: "2 hours ago" },
  { id: "a3", icon: MessageSquare, iconTone: "primary", title: "Commented on #2812", detail: "Suggested backpressure over circuit breaker", time: "5 hours ago" },
  { id: "a4", icon: Zap, iconTone: "warning", title: "Resolved incident INC-2204", detail: "Elevated 5xx on /v1/webhooks — caching layer miss", time: "Yesterday" },
  { id: "a5", icon: Award, iconTone: "violet", title: "Earned the Reliability Champion badge", detail: "30 days of zero Sev-1 incidents", time: "2 days ago" },
  { id: "a6", icon: GitPullRequest, iconTone: "success", title: "Opened pull request #2828", detail: "Migrate billing ledger to double-entry model", time: "3 days ago" },
];

type Project = {
  id: string;
  name: string;
  description: string;
  progress: number;
  status: "on-track" | "at-risk" | "shipped" | "in-review";
  stars: number;
};

const PROJECTS: Project[] = [
  { id: "p1", name: "Falcon Edge Runtime", description: "Sub-50ms cold-start serverless functions on 14 PoPs.", progress: 82, status: "on-track", stars: 142 },
  { id: "p2", name: "Atlas Ledger", description: "Double-entry billing engine with retroactive adjustments.", progress: 64, status: "in-review", stars: 88 },
  { id: "p3", name: "Meridian Webhooks", description: "At-least-once delivery with replay and dead-letter queues.", progress: 100, status: "shipped", stars: 211 },
  { id: "p4", name: "Pulse Telemetry", description: "OpenTelemetry-native trace pipeline for tier-1 services.", progress: 38, status: "at-risk", stars: 47 },
];

const ACHIEVEMENTS = [
  { id: "ach1", icon: Star, tone: "warning" as const, title: "Top 1% Reviewer", desc: "Q2 2026 · 624 reviews" },
  { id: "ach2", icon: Target, tone: "success" as const, title: "Reliability Champion", desc: "30 days Sev-1 free" },
  { id: "ach3", icon: TrendingUp, tone: "primary" as const, title: "On-Call MVP", desc: "12 incidents resolved <15m" },
  { id: "ach4", icon: Zap, tone: "info" as const, title: "Ship Sprint Winner", desc: "Spring 2026 hackathon" },
  { id: "ach5", icon: Award, tone: "violet" as const, title: "Mentor of the Quarter", desc: "Onboarded 6 engineers" },
];

const toneIcon: Record<string, string> = {
  success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
  info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
  primary: "bg-primary/15 text-primary",
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  violet: "bg-violet-500/15 text-violet-500",
};

const statusTone = (s: Project["status"]) =>
  s === "shipped" ? "success" : s === "on-track" ? "primary" : s === "in-review" ? "info" : "warning";

export default function ProfilePage() {
  const [editOpen, setEditOpen] = React.useState(false);
  const [draft, setDraft] = React.useState({
    firstName: PROFILE.firstName,
    lastName: PROFILE.lastName,
    role: PROFILE.role,
    team: PROFILE.team,
    bio: PROFILE.bio,
    location: PROFILE.location,
    phone: PROFILE.phone,
    website: PROFILE.website,
    username: PROFILE.username,
  });

  const save = () => {
    setEditOpen(false);
    toast.success("Profile updated", {
      description: "Your changes are now visible across the workspace.",
    });
  };

  return (
    <>
      <PageHeader
        title="Profile"
        description="Your public identity, expertise, and recent activity on NexusGrid."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Account" }, { label: "Profile" }]}
        icon={User}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setEditOpen(true)}>
            <Pencil className="h-3.5 w-3.5" /> Edit profile
          </Button>
        }
      />

      {/* COVER + HEADER CARD */}
      <Card className="overflow-hidden mb-6">
        <div className="relative h-44 sm:h-52">
          <img src={PROFILE.cover} alt="Cover" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
        </div>
        <CardContent className="-mt-16 sm:-mt-20 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            <Avatar className="h-28 w-28 rounded-2xl ring-4 ring-card shadow-premium-md shrink-0">
              <AvatarImage src={PROFILE.avatar} alt={PROFILE.name} />
              <AvatarFallback>AO</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0 sm:pb-2">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-2xl font-semibold tracking-tight">{PROFILE.name}</h2>
                <StatusBadge tone="success" dot>Active</StatusBadge>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {PROFILE.role} · <span className="text-foreground/80">{PROFILE.team}</span>
              </p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2 flex-wrap">
                <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {PROFILE.location}</span>
                <span className="inline-flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Joined {PROFILE.joined}</span>
                <span className="inline-flex items-center gap-1"><Briefcase className="h-3.5 w-3.5" /> @{PROFILE.username}</span>
              </div>
            </div>
            <div className="flex items-center gap-2 sm:pb-2">
              <Button variant="outline" size="sm" className="gap-1.5"><Mail className="h-3.5 w-3.5" /> Message</Button>
              <Button size="sm" className="gap-1.5" onClick={() => setEditOpen(true)}><Pencil className="h-3.5 w-3.5" /> Edit</Button>
            </div>
          </div>

          {/* Stats strip */}
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 divide-x divide-y sm:divide-y-0 divide-border rounded-xl border border-border overflow-hidden">
            {[
              { label: "Commits", value: PROFILE.stats.commits.toLocaleString(), icon: GitPullRequest },
              { label: "Pull Requests", value: PROFILE.stats.prs.toLocaleString(), icon: GitPullRequest },
              { label: "Reviews", value: PROFILE.stats.reviews.toLocaleString(), icon: CheckCircle2 },
              { label: "Deployments", value: PROFILE.stats.deployments.toLocaleString(), icon: Zap },
            ].map((s) => (
              <div key={s.label} className="p-4 flex items-center gap-3 bg-card">
                <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary shrink-0">
                  <s.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-lg font-semibold tabular-nums leading-tight">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* MAIN GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT COLUMN */}
        <div className="lg:col-span-1 space-y-6">
          {/* About */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">About</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm leading-relaxed text-muted-foreground">{PROFILE.bio}</p>
              <div className="space-y-2.5 pt-1">
                <div className="flex items-center gap-2.5 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground shrink-0" />
                  <a href={`mailto:${PROFILE.email}`} className="text-foreground hover:text-primary truncate">{PROFILE.email}</a>
                </div>
                <div className="flex items-center gap-2.5 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground shrink-0" />
                  <span className="text-foreground font-mono text-xs">{PROFILE.phone}</span>
                </div>
                <div className="flex items-center gap-2.5 text-sm">
                  <Globe className="h-4 w-4 text-muted-foreground shrink-0" />
                  <a href={`https://${PROFILE.website}`} className="text-foreground hover:text-primary">{PROFILE.website}</a>
                </div>
                <div className="flex items-center gap-2.5 text-sm">
                  <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                  <span className="text-foreground">{PROFILE.location} · {PROFILE.timezone}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Skills & Expertise</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-1.5">
                {PROFILE.skills.map((skill, i) => (
                  <Badge
                    key={skill}
                    variant="outline"
                    className={cn(
                      "text-xs font-medium rounded-md",
                      i === 0 ? "border-primary/30 bg-primary/8 text-primary" : "bg-muted/50"
                    )}
                  >
                    {skill}
                  </Badge>
                ))}
                <Badge variant="outline" className="text-xs rounded-md border-dashed cursor-pointer hover:bg-accent gap-1">
                  <Plus className="h-3 w-3" /> Add
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Social */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Connected Accounts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                { icon: Github, label: "GitHub", handle: PROFILE.social.github, color: "text-foreground" },
                { icon: Twitter, label: "Twitter", handle: PROFILE.social.twitter ? `@${PROFILE.social.twitter}` : "Not connected", color: "text-sky-500" },
                { icon: Linkedin, label: "LinkedIn", handle: PROFILE.social.linkedin ? "/in/" + PROFILE.social.linkedin : "Not connected", color: "text-blue-600" },
                { icon: Dribbble, label: "Dribbble", handle: "Not connected", color: "text-pink-500" },
              ].map((s) => (
                <div key={s.label} className="flex items-center justify-between p-2.5 rounded-lg hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <s.icon className={cn("h-4 w-4", s.color)} />
                    <div>
                      <p className="text-sm font-medium leading-tight">{s.label}</p>
                      <p className="text-xs text-muted-foreground">{s.handle}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="text-xs h-7">Manage</Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* RIGHT COLUMN */}
        <div className="lg:col-span-2 space-y-6">
          {/* Activity feed */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" /> Recent Activity
                </CardTitle>
                <CardDescription>The last 7 days across repositories and incidents.</CardDescription>
              </div>
              <Button variant="ghost" size="sm" className="text-xs">View all</Button>
            </CardHeader>
            <CardContent>
              <ol className="relative space-y-1 max-h-[420px] overflow-y-auto pr-2 -mr-2">
                {ACTIVITY.map((a, i) => (
                  <li key={a.id} className="relative pl-10 pb-4 last:pb-0">
                    {i !== ACTIVITY.length - 1 && (
                      <span className="absolute left-[18px] top-9 bottom-0 w-px bg-border" aria-hidden />
                    )}
                    <span className={cn("absolute left-0 top-0 grid place-items-center h-9 w-9 rounded-full ring-4 ring-card", toneIcon[a.iconTone])}>
                      <a.icon className="h-4 w-4" />
                    </span>
                    <div className="pt-1">
                      <p className="text-sm font-medium leading-tight">{a.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{a.detail}</p>
                      <p className="text-[11px] text-muted-foreground/80 mt-1">{a.time}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>

          {/* Recent projects */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <FolderGit2 className="h-4 w-4 text-primary" /> Recent Projects
                </CardTitle>
                <CardDescription>Active work in the Platform Infrastructure org.</CardDescription>
              </div>
              <Button variant="ghost" size="sm" className="text-xs gap-1">All projects <TrendingUp className="h-3 w-3" /></Button>
            </CardHeader>
            <CardContent className="grid sm:grid-cols-2 gap-3">
              {PROJECTS.map((p) => (
                <div key={p.id} className="rounded-xl border border-border p-4 hover:border-primary/30 hover:shadow-premium-xs transition-all">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold truncate">{p.name}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{p.description}</p>
                    </div>
                    <StatusBadge tone={statusTone(p.status)} dot>{p.status.replace("-", " ")}</StatusBadge>
                  </div>
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-medium tabular-nums">{p.progress}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all",
                          p.progress === 100 ? "bg-[color:var(--success)]" : p.progress >= 60 ? "bg-primary" : "bg-[color:var(--warning)]"
                        )}
                        style={{ width: `${p.progress}%` }}
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-3">
                    <Star className="h-3 w-3 text-[color:var(--warning)]" />
                    <span className="tabular-nums">{p.stars}</span>
                    <span className="mx-1">·</span>
                    <span className="font-mono">{p.id.toUpperCase()}</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Award className="h-4 w-4 text-primary" /> Achievements
              </CardTitle>
              <CardDescription>Milestones earned through code, mentorship, and on-call heroics.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {ACHIEVEMENTS.map((ach) => (
                <div key={ach.id} className="rounded-xl border border-border p-3 text-center hover:bg-muted/30 transition-colors">
                  <div className={cn("mx-auto grid place-items-center h-10 w-10 rounded-full mb-2", toneIcon[ach.tone])}>
                    <ach.icon className="h-5 w-5" />
                  </div>
                  <p className="text-xs font-semibold leading-tight">{ach.title}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{ach.desc}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* EDIT DIALOG */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit profile</DialogTitle>
            <DialogDescription>Update your personal details. Changes are visible workspace-wide.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-xs">First name</Label>
                <Input value={draft.firstName} onChange={(e) => setDraft({ ...draft, firstName: e.target.value })} />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Last name</Label>
                <Input value={draft.lastName} onChange={(e) => setDraft({ ...draft, lastName: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-xs">Role</Label>
                <Input value={draft.role} onChange={(e) => setDraft({ ...draft, role: e.target.value })} />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Team</Label>
                <Select value={draft.team} onValueChange={(v) => setDraft({ ...draft, team: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Platform Infrastructure", "Developer Experience", "Security", "Data Platform", "Growth"].map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">Bio</Label>
              <Textarea rows={3} value={draft.bio} onChange={(e) => setDraft({ ...draft, bio: e.target.value })} />
              <p className="text-[11px] text-muted-foreground">{draft.bio.length} / 280 characters</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label className="text-xs">Location</Label>
                <Input value={draft.location} onChange={(e) => setDraft({ ...draft, location: e.target.value })} />
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Username</Label>
                <Input value={draft.username} onChange={(e) => setDraft({ ...draft, username: e.target.value })} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button onClick={save}>Save changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
