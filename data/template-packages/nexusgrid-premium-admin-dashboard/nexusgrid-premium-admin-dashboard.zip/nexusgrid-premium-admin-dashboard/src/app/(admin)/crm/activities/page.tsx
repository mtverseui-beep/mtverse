"use client";

import * as React from "react";
import {
  Activity,
  Phone,
  Mail,
  CalendarClock,
  StickyNote,
  Trophy,
  PhoneCall,
  Send,
  CheckSquare,
  Users,
  MoreHorizontal,
  ArrowUpRight,
  TrendingUp,
  Filter,
  Download,
  Plus,
  Clock,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarTrendChart } from "@/components/charts";
import { crmActivities } from "@/data/mock-data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type ActivityType = "call" | "email" | "meeting" | "note" | "won" | "task";

type ActivityItem = {
  type: ActivityType;
  title: string;
  owner: string;
  ownerAvatar: string;
  time: string;
  detail?: string;
  customer?: string;
};

const extraActivities: ActivityItem[] = [
  { type: "task", title: "Updated proposal for Cloudflare CDN deal", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", time: "5 min ago", detail: "Sent revised pricing tiers to procurement", customer: "Cloudflare" },
  { type: "call", title: "Discovery call with Plaid's Head of Integrations", owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", time: "25 min ago", detail: "Identified 3 integration use cases", customer: "Plaid" },
  { type: "email", title: "Followed up with Doctolib on contract terms", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", time: "1 hr ago", detail: "Awaiting legal review of MSA", customer: "Doctolib" },
  { type: "meeting", title: "Quarterly business review with Klarna", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", time: "2 hr ago", detail: "Expansion to APAC region approved", customer: "Klarna" },
  { type: "note", title: "Logged competitor intel on Mercari", owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", time: "4 hr ago", detail: "Evaluating alternative platform", customer: "Mercari" },
];

// Merge shared crmActivities with avatar info + extras
const sharedWithAvatars: ActivityItem[] = crmActivities.map((a) => {
  const ownerAvatarMap: Record<string, string> = {
    "Sarah Chen": "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop",
    "Marcus Reyes": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop",
    "Elena Petrov": "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop",
    "James Okoro": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop",
    "Aiko Tanaka": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop",
  };
  const customerMap: Record<string, string> = {
    "Discovery call with Globex Corp": "Globex Corp",
    "Sent proposal to Initech": "Initech",
    "Demo scheduled with Hooli": "Hooli",
    "Added follow-up reminder for Acme": "Acme Corp",
    "Closed deal with Umbrella Inc": "Umbrella Inc",
  };
  return {
    type: a.type as ActivityType,
    title: a.title,
    owner: a.owner,
    ownerAvatar: ownerAvatarMap[a.owner] ?? "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop",
    time: a.time,
    customer: customerMap[a.title],
  };
});

const allActivities: ActivityItem[] = [...extraActivities, ...sharedWithAvatars];

const activityConfig: Record<ActivityType, { icon: typeof Phone; tone: StatusTone; ring: string; label: string }> = {
  call: { icon: Phone, tone: "primary", ring: "bg-primary/12 text-primary", label: "Call" },
  email: { icon: Mail, tone: "info", ring: "bg-[color:var(--info)]/12 text-[color:var(--info)]", label: "Email" },
  meeting: { icon: CalendarClock, tone: "violet", ring: "bg-violet-500/12 text-violet-500", label: "Meeting" },
  note: { icon: StickyNote, tone: "neutral", ring: "bg-muted text-muted-foreground", label: "Note" },
  won: { icon: Trophy, tone: "success", ring: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Won" },
  task: { icon: CheckSquare, tone: "warning", ring: "bg-[color:var(--warning)]/12 text-[color:var(--warning)]", label: "Task" },
};

const weeklyActivityData = [
  { day: "Mon", calls: 28, emails: 64, meetings: 8, tasks: 22 },
  { day: "Tue", calls: 34, emails: 72, meetings: 12, tasks: 18 },
  { day: "Wed", calls: 22, emails: 58, meetings: 14, tasks: 26 },
  { day: "Thu", calls: 38, emails: 84, meetings: 10, tasks: 20 },
  { day: "Fri", calls: 42, emails: 96, meetings: 16, tasks: 24 },
  { day: "Sat", calls: 8, emails: 18, meetings: 2, tasks: 6 },
  { day: "Sun", calls: 4, emails: 12, meetings: 0, tasks: 4 },
];

/* ActivityKpi — multi-color-strip motif: a horizontal stacked bar showing the activity mix */
function ActivityKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive,
  mix,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  trend: string;
  trendPositive: boolean;
  mix: { count: number; color: string }[];
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  const total = mix.reduce((s, m) => s + m.count, 0) || 1;
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* Stacked color strip motif — distinct */}
        <div className="flex h-2 w-full rounded-full overflow-hidden bg-muted mb-3">
          {mix.map((m, i) => (
            <div
              key={i}
              className="h-full transition-all duration-500"
              style={{ width: `${(m.count / total) * 100}%`, background: m.color }}
              title={`${m.count}`}
            />
          ))}
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground truncate">{hint}</span>
          <span className={cn("inline-flex items-center gap-0.5 font-medium shrink-0", trendPositive ? "text-[color:var(--success)]" : "text-destructive")}>
            <ArrowUpRight className="h-3 w-3" />
            {trend}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ActivitiesPage() {
  const [filter, setFilter] = React.useState<string>("all");

  const filtered = React.useMemo(() => {
    if (filter === "all") return allActivities;
    return allActivities.filter((a) => a.type === filter);
  }, [filter]);

  return (
    <>
      <PageHeader
        title="Sales Activities"
        description="Track every call, email, meeting, and note logged across the sales org."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Sales Activities" }]}
        icon={Activity}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Activities exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Log activity form opened")}>
              <Plus className="h-3.5 w-3.5" /> Log Activity
            </Button>
          </>
        }
      />

      {/* KPI Row — stacked color-strip motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <ActivityKpi label="Calls Today" value="38" hint="across 6 reps" icon={PhoneCall} accent="primary" trend="+12 vs yesterday" trendPositive={true} mix={[{ count: 14, color: "var(--primary)" }, { count: 12, color: "oklch(0.70 0.15 75)" }, { count: 8, color: "var(--info)" }, { count: 4, color: "var(--success)" }]} />
        <ActivityKpi label="Emails Sent" value="184" hint="42% open rate" icon={Send} accent="info" trend="+24% vs last week" trendPositive={true} mix={[{ count: 64, color: "var(--info)" }, { count: 48, color: "var(--primary)" }, { count: 42, color: "oklch(0.70 0.15 75)" }, { count: 30, color: "var(--success)" }]} />
        <ActivityKpi label="Meetings Scheduled" value="14" hint="8 demos · 6 QBRs" icon={CalendarClock} accent="success" trend="+4 this week" trendPositive={true} mix={[{ count: 8, color: "var(--success)" }, { count: 4, color: "oklch(0.62 0.18 305)" }, { count: 2, color: "var(--primary)" }]} />
        <ActivityKpi label="Tasks Completed" value="62" hint="of 78 assigned" icon={CheckSquare} accent="warning" trend="79% completion rate" trendPositive={true} mix={[{ count: 28, color: "var(--warning)" }, { count: 18, color: "oklch(0.62 0.18 25)" }, { count: 12, color: "var(--info)" }, { count: 4, color: "var(--success)" }]} />
      </div>

      {/* Activity by type bar chart + Activity timeline */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Activity by Type
            </CardTitle>
            <CardDescription>This week's volume across channels.</CardDescription>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={weeklyActivityData}
              xKey="day"
              series={[
                { key: "calls", name: "Calls", color: "var(--primary)" },
                { key: "emails", name: "Emails", color: "var(--info)" },
                { key: "meetings", name: "Meetings", color: "oklch(0.62 0.18 305)" },
                { key: "tasks", name: "Tasks", color: "var(--warning)" },
              ]}
              stacked
              height={240}
            />
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                  <span className="h-2 w-2 rounded-full bg-primary" /> Total Calls
                </span>
                <span className="font-semibold tabular-nums">176</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                  <span className="h-2 w-2 rounded-full bg-[color:var(--info)]" /> Total Emails
                </span>
                <span className="font-semibold tabular-nums">404</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                  <span className="h-2 w-2 rounded-full" style={{ background: "oklch(0.62 0.18 305)" }} /> Total Meetings
                </span>
                <span className="font-semibold tabular-nums">62</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                  <span className="h-2 w-2 rounded-full bg-[color:var(--warning)]" /> Total Tasks
                </span>
                <span className="font-semibold tabular-nums">120</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Activity timeline with filter tabs */}
        <Card className="xl:col-span-2">
          <CardHeader className="pb-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="h-4 w-4 text-[color:var(--warning)]" />
                Activity Timeline
              </CardTitle>
              <CardDescription>{filtered.length} of {allActivities.length} activities shown</CardDescription>
            </div>
            <Tabs value={filter} onValueChange={setFilter}>
              <TabsList className="h-9">
                <TabsTrigger value="all" className="text-xs gap-1">
                  <Filter className="h-3 w-3" /> All
                </TabsTrigger>
                <TabsTrigger value="call" className="text-xs gap-1">
                  <Phone className="h-3 w-3" /> Calls
                </TabsTrigger>
                <TabsTrigger value="email" className="text-xs gap-1">
                  <Mail className="h-3 w-3" /> Emails
                </TabsTrigger>
                <TabsTrigger value="meeting" className="text-xs gap-1">
                  <CalendarClock className="h-3 w-3" /> Meetings
                </TabsTrigger>
                <TabsTrigger value="note" className="text-xs gap-1">
                  <StickyNote className="h-3 w-3" /> Notes
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>
          <CardContent>
            <Tabs value={filter}>
              <TabsContent value={filter} className="mt-0">
                <ol className="relative">
                  {/* Timeline vertical line */}
                  <span className="absolute left-[19px] top-2 bottom-2 w-px bg-border" aria-hidden />
                  <div className="space-y-1 max-h-[460px] overflow-y-auto pr-1">
                    {filtered.map((a, i) => {
                      const cfg = activityConfig[a.type];
                      const Icon = cfg.icon;
                      const isLast = i === filtered.length - 1;
                      return (
                        <li
                          key={i}
                          className={cn(
                            "relative flex gap-3 pl-0 pr-1 py-2.5",
                            !isLast && "border-b border-border/60"
                          )}
                        >
                          <div
                            className={cn(
                              "relative z-10 grid place-items-center h-10 w-10 rounded-full ring-4 ring-card shrink-0",
                              cfg.ring
                            )}
                          >
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1 pt-0.5">
                            <div className="flex items-start justify-between gap-2">
                              <p className="text-sm font-medium text-foreground leading-snug">{a.title}</p>
                              <StatusBadge tone={cfg.tone} className="capitalize shrink-0">
                                {cfg.label}
                              </StatusBadge>
                            </div>
                            {a.detail && (
                              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{a.detail}</p>
                            )}
                            <div className="mt-1.5 flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                              <span className="inline-flex items-center gap-1">
                                <Avatar className="h-4 w-4">
                                  <AvatarImage src={a.ownerAvatar} alt={a.owner} />
                                  <AvatarFallback className="text-[8px]">
                                    {a.owner.split(" ").map((p) => p[0]).join("")}
                                  </AvatarFallback>
                                </Avatar>
                                {a.owner}
                              </span>
                              {a.customer && (
                                <>
                                  <span className="opacity-40">·</span>
                                  <span className="inline-flex items-center gap-1 text-primary">
                                    <Users className="h-3 w-3" /> {a.customer}
                                  </span>
                                </>
                              )}
                              <span className="opacity-40">·</span>
                              <span className="inline-flex items-center gap-1 tabular-nums">
                                <Clock className="h-3 w-3" /> {a.time}
                              </span>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                    {filtered.length === 0 && (
                      <div className="py-12 text-center">
                        <Activity className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">No activities of this type yet.</p>
                      </div>
                    )}
                  </div>
                </ol>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
