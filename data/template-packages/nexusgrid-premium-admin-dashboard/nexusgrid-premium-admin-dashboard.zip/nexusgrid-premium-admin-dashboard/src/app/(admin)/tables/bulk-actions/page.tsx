"use client";

import * as React from "react";
import {
  ListChecks,
  Check,
  CheckCheck,
  X,
  Power,
  PowerOff,
  Trash2,
  Download,
  Tag,
  FolderInput,
  ChevronDown,
  Users,
  Shield,
  AlertTriangle,
  Mail,
  MoreHorizontal,
  Search,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type UserStatus = "active" | "inactive" | "suspended";
type UserRole = "admin" | "editor" | "viewer" | "billing";

type User = {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: UserRole;
  department: string;
  lastActive: string;
  status: UserStatus;
  mfaEnabled: boolean;
};

const users: User[] = [
  { id: "U-1001", name: "Sarah Chen", email: "sarah.chen@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", role: "admin", department: "Engineering", lastActive: "2026-07-14 10:42", status: "active", mfaEnabled: true },
  { id: "U-1002", name: "Marcus Reyes", email: "marcus.reyes@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "editor", department: "Design", lastActive: "2026-07-14 09:18", status: "active", mfaEnabled: true },
  { id: "U-1003", name: "Elena Petrov", email: "elena.petrov@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", role: "admin", department: "Engineering", lastActive: "2026-07-14 10:55", status: "active", mfaEnabled: true },
  { id: "U-1004", name: "James Okoro", email: "james.okoro@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "viewer", department: "Analytics", lastActive: "2026-07-12 14:22", status: "inactive", mfaEnabled: false },
  { id: "U-1005", name: "Aiko Tanaka", email: "aiko.tanaka@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", role: "editor", department: "Engineering", lastActive: "2026-07-14 08:04", status: "active", mfaEnabled: true },
  { id: "U-1006", name: "David Kim", email: "david.kim@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "editor", department: "Engineering", lastActive: "2026-07-13 19:48", status: "active", mfaEnabled: false },
  { id: "U-1007", name: "Lena Hoffmann", email: "lena.hoffmann@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", role: "viewer", department: "Design", lastActive: "2026-07-14 11:02", status: "active", mfaEnabled: true },
  { id: "U-1008", name: "Raj Patel", email: "raj.patel@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", role: "billing", department: "Product", lastActive: "2026-07-11 16:30", status: "suspended", mfaEnabled: false },
  { id: "U-1009", name: "Mei Lin", email: "mei.lin@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", role: "editor", department: "Marketing", lastActive: "2026-07-14 10:11", status: "active", mfaEnabled: true },
  { id: "U-1010", name: "Carlos Mendez", email: "carlos.mendez@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "viewer", department: "Sales", lastActive: "2026-07-14 07:48", status: "active", mfaEnabled: false },
  { id: "U-1011", name: "Priya Sharma", email: "priya.sharma@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", role: "admin", department: "Sales", lastActive: "2026-07-14 10:38", status: "active", mfaEnabled: true },
  { id: "U-1012", name: "Noah Williams", email: "noah.williams@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "editor", department: "Engineering", lastActive: "2026-07-09 12:14", status: "suspended", mfaEnabled: false },
  { id: "U-1013", name: "Sofia Rossi", email: "sofia.rossi@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", role: "editor", department: "Design", lastActive: "2026-07-13 22:01", status: "active", mfaEnabled: true },
  { id: "U-1014", name: "Ahmed Hassan", email: "ahmed.hassan@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", role: "admin", department: "Engineering", lastActive: "2026-07-14 11:18", status: "active", mfaEnabled: true },
  { id: "U-1015", name: "Yuki Sato", email: "yuki.sato@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", role: "viewer", department: "Engineering", lastActive: "2026-07-10 18:42", status: "inactive", mfaEnabled: false },
  { id: "U-1016", name: "Olivia Bennett", email: "olivia.bennett@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", role: "billing", department: "Product", lastActive: "2026-07-14 09:55", status: "active", mfaEnabled: true },
  { id: "U-1017", name: "Lucas Moreau", email: "lucas.moreau@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "editor", department: "Engineering", lastActive: "2026-07-12 11:08", status: "active", mfaEnabled: false },
];

const statusToneMap: Record<UserStatus, "success" | "neutral" | "danger"> = {
  active: "success",
  inactive: "neutral",
  suspended: "danger",
};
const roleToneMap: Record<UserRole, "primary" | "info" | "warning" | "neutral"> = {
  admin: "primary",
  editor: "info",
  viewer: "warning",
  billing: "neutral",
};

const FOLDERS = ["Engineering Team", "Sales & Marketing", "Design Studio", "Operations", "External Vendors"];

type BulkAction = "activate" | "deactivate" | "delete" | "export" | "tag" | "move";

function initials(name: string) {
  return name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}

export default function BulkActionsTablePage() {
  const [data, setData] = React.useState<User[]>(users);
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [search, setSearch] = React.useState("");
  const [roleFilter, setRoleFilter] = React.useState<UserRole | "">("");
  const [statusFilter, setStatusFilter] = React.useState<UserStatus | "">("");
  const [confirmAction, setConfirmAction] = React.useState<{ type: BulkAction; count: number } | null>(null);
  const [tagDialogOpen, setTagDialogOpen] = React.useState(false);
  const [moveDialogOpen, setMoveDialogOpen] = React.useState(false);
  const [pendingTag, setPendingTag] = React.useState("");
  const [pendingFolder, setPendingFolder] = React.useState("");
  const [appliedTags, setAppliedTags] = React.useState<Record<string, string[]>>({});

  const filtered = React.useMemo(() => {
    let result = [...data];
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((u) => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.id.toLowerCase().includes(q));
    }
    if (roleFilter) result = result.filter((u) => u.role === roleFilter);
    if (statusFilter) result = result.filter((u) => u.status === statusFilter);
    return result;
  }, [data, search, roleFilter, statusFilter]);

  const visibleIds = filtered.map((u) => u.id);
  const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selected.has(id));
  const someVisibleSelected = visibleIds.some((id) => selected.has(id));

  const toggleOne = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAllVisible = () => {
    setSelected((prev) => {
      if (allVisibleSelected) {
        const next = new Set(prev);
        visibleIds.forEach((id) => next.delete(id));
        return next;
      }
      const next = new Set(prev);
      visibleIds.forEach((id) => next.add(id));
      return next;
    });
  };

  const clearSelection = () => setSelected(new Set());

  const selectedUsers = data.filter((u) => selected.has(u.id));

  const runAction = (type: BulkAction) => {
    const count = selected.size;
    const names = selectedUsers.map((u) => u.name).slice(0, 3).join(", ");
    const moreText = count > 3 ? ` and ${count - 3} more` : "";

    switch (type) {
      case "activate":
        setData((prev) => prev.map((u) => (selected.has(u.id) ? { ...u, status: "active" } : u)));
        toast.success(`Activated ${count} user${count > 1 ? "s" : ""}`, { description: `${names}${moreText}` });
        clearSelection();
        break;
      case "deactivate":
        setData((prev) => prev.map((u) => (selected.has(u.id) ? { ...u, status: "inactive" } : u)));
        toast.success(`Deactivated ${count} user${count > 1 ? "s" : ""}`, { description: `${names}${moreText}` });
        clearSelection();
        break;
      case "delete":
        setData((prev) => prev.filter((u) => !selected.has(u.id)));
        toast.error(`Deleted ${count} user${count > 1 ? "s" : ""}`, { description: `${names}${moreText} — irreversible.` });
        clearSelection();
        break;
      case "export":
        toast.success(`Exported ${count} user${count > 1 ? "s" : ""} as CSV`, { description: `File: users-export-${Date.now()}.csv` });
        clearSelection();
        break;
      case "tag":
        if (!pendingTag.trim()) {
          toast.error("Enter a tag value first");
          return;
        }
        setAppliedTags((prev) => {
          const next = { ...prev };
          selectedUsers.forEach((u) => {
            next[u.id] = Array.from(new Set([...(next[u.id] ?? []), pendingTag.trim()]));
          });
          return next;
        });
        toast.success(`Tagged ${count} user${count > 1 ? "s" : ""} with "${pendingTag.trim()}"`, { description: `${names}${moreText}` });
        setPendingTag("");
        setTagDialogOpen(false);
        clearSelection();
        break;
      case "move":
        if (!pendingFolder) {
          toast.error("Choose a destination folder");
          return;
        }
        toast.success(`Moved ${count} user${count > 1 ? "s" : ""} to "${pendingFolder}"`, { description: `${names}${moreText}` });
        setPendingFolder("");
        setMoveDialogOpen(false);
        clearSelection();
        break;
    }
    setConfirmAction(null);
  };

  const handleActionClick = (type: BulkAction) => {
    // Delete and deactivate get a confirmation dialog; others run directly or open their own dialog
    if (type === "delete" || type === "deactivate") {
      setConfirmAction({ type, count: selected.size });
    } else if (type === "tag") {
      setTagDialogOpen(true);
    } else if (type === "move") {
      setMoveDialogOpen(true);
    } else {
      runAction(type);
    }
  };

  const activeCount = data.filter((u) => u.status === "active").length;
  const suspendedCount = data.filter((u) => u.status === "suspended").length;
  const mfaCount = data.filter((u) => u.mfaEnabled).length;

  return (
    <>
      <PageHeader
        title="Bulk Actions Table"
        description="Full bulk-action workflow — single, multi, and select-all checkboxes; a contextual action bar that appears on selection; and confirmations for destructive operations. 17 users with role, status, MFA, and tags."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Bulk Actions" }]}
        icon={ListChecks}
      />

      {/* Stat strip — unique visual element */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Total Users</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">{data.length}</p>
              </div>
              <span className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                <Users className="h-4 w-4" />
              </span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Active</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 text-[color:var(--success)]">{activeCount}</p>
            <p className="text-xs text-muted-foreground mt-1">{data.length > 0 ? ((activeCount / data.length) * 100).toFixed(0) : 0}% of total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Suspended</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 text-[color:var(--danger)]">{suspendedCount}</p>
            <p className="text-xs text-muted-foreground mt-1">requires admin review</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">MFA Enabled</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5">{mfaCount}</p>
            <p className="text-xs text-muted-foreground mt-1">{data.length > 0 ? ((mfaCount / data.length) * 100).toFixed(0) : 0}% adoption rate</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <span className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
              <ListChecks className="h-4 w-4" />
            </span>
            User Management
          </CardTitle>
          <CardDescription className="text-xs">
            Use the checkboxes to select one, many, or all matching users. A bulk action bar will slide in with destructive operations gated behind a confirmation dialog.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filter toolbar */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2 mb-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, email, or user ID…"
                className="h-8 pl-8 text-xs"
              />
            </div>
            <div className="flex items-center gap-1.5">
              <Button
                variant={roleFilter === "" ? "default" : "outline"}
                size="sm"
                className="h-8 text-xs"
                onClick={() => setRoleFilter("")}
              >
                All roles
              </Button>
              {(["admin", "editor", "viewer", "billing"] as UserRole[]).map((r) => (
                <Button
                  key={r}
                  variant={roleFilter === r ? "default" : "outline"}
                  size="sm"
                  className="h-8 text-xs capitalize"
                  onClick={() => setRoleFilter(r)}
                >
                  {r}
                </Button>
              ))}
            </div>
            <div className="flex-1" />
            <Button
              variant={statusFilter === "" ? "default" : "outline"}
              size="sm"
              className="h-8 text-xs capitalize"
              onClick={() => setStatusFilter(statusFilter === "" ? "suspended" : "")}
            >
              {statusFilter === "" ? "All status" : `Only ${statusFilter}`}
            </Button>
          </div>

          {/* Bulk action bar */}
          {selected.size > 0 && (
            <div className="flex flex-wrap items-center gap-2 px-3 py-2 mb-2 rounded-lg bg-primary/5 border border-primary/20">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                <CheckCheck className="h-3.5 w-3.5" />
                {selected.size} selected
              </span>
              <div className="h-4 w-px bg-border mx-1" />
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => handleActionClick("activate")}>
                <Power className="h-3 w-3 text-[color:var(--success)]" /> Activate
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => handleActionClick("deactivate")}>
                <PowerOff className="h-3 w-3 text-muted-foreground" /> Deactivate
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => handleActionClick("tag")}>
                <Tag className="h-3 w-3 text-[color:var(--info)]" /> Tag
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => handleActionClick("move")}>
                <FolderInput className="h-3 w-3 text-violet-500" /> Move to folder
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => handleActionClick("export")}>
                <Download className="h-3 w-3" /> Export
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5 text-destructive hover:text-destructive" onClick={() => handleActionClick("delete")}>
                <Trash2 className="h-3 w-3" /> Delete
              </Button>
              <div className="flex-1" />
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={clearSelection}>
                <X className="h-3 w-3 mr-1" /> Clear
              </Button>
            </div>
          )}

          {/* The table */}
          <div className="rounded-lg border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/40 border-b border-border">
                    <th className="text-left px-3 py-2 w-10">
                      <input
                        type="checkbox"
                        checked={allVisibleSelected}
                        ref={(el) => {
                          if (el) el.indeterminate = !allVisibleSelected && someVisibleSelected;
                        }}
                        onChange={toggleAllVisible}
                        className="h-3.5 w-3.5 rounded border-border accent-primary cursor-pointer"
                        aria-label="Select all visible rows"
                      />
                    </th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2">User</th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Role</th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-32">Department</th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-32">Last Active</th>
                    <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Status</th>
                    <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-20">MFA</th>
                    <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-32">Tags</th>
                    <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-12"></th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="text-center text-sm text-muted-foreground py-12">
                        No users match the current filters.
                      </td>
                    </tr>
                  ) : (
                    filtered.map((u) => {
                      const isSelected = selected.has(u.id);
                      return (
                        <tr
                          key={u.id}
                          className={cn(
                            "border-b border-border last:border-0 hover:bg-muted/30 transition-colors",
                            isSelected && "bg-primary/[0.04]"
                          )}
                        >
                          <td className="px-3 py-2" onClick={(e) => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleOne(u.id)}
                              className="h-3.5 w-3.5 rounded border-border accent-primary cursor-pointer"
                              aria-label={`Select ${u.name}`}
                            />
                          </td>
                          <td className="px-3 py-2">
                            <div className="flex items-center gap-2.5">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={u.avatar} alt={u.name} />
                                <AvatarFallback className="text-[11px] font-medium">{initials(u.name)}</AvatarFallback>
                              </Avatar>
                              <div className="min-w-0">
                                <p className="font-medium text-sm truncate">{u.name}</p>
                                <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-3 py-2">
                            <StatusBadge tone={roleToneMap[u.role]} className="capitalize">{u.role}</StatusBadge>
                          </td>
                          <td className="px-3 py-2 text-sm text-muted-foreground">{u.department}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-muted-foreground">{u.lastActive}</td>
                          <td className="px-3 py-2 text-center">
                            <StatusBadge tone={statusToneMap[u.status]} dot className="capitalize">{u.status}</StatusBadge>
                          </td>
                          <td className="px-3 py-2 text-center">
                            {u.mfaEnabled ? (
                              <Shield className="h-4 w-4 text-[color:var(--success)] inline-block" />
                            ) : (
                              <span className="text-[11px] text-muted-foreground italic">off</span>
                            )}
                          </td>
                          <td className="px-3 py-2">
                            <div className="flex flex-wrap gap-1">
                              {(appliedTags[u.id] ?? []).length === 0 ? (
                                <span className="text-[11px] text-muted-foreground/60 italic">—</span>
                              ) : (
                                (appliedTags[u.id] ?? []).map((t) => (
                                  <span key={t} className="inline-flex items-center rounded bg-[color:var(--info)]/12 text-[color:var(--info)] px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset ring-[color:var(--info)]/20">
                                    {t}
                                  </span>
                                ))
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-2 text-center" onClick={(e) => e.stopPropagation()}>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-7 w-7">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-44">
                                <DropdownMenuLabel className="text-xs font-mono">{u.id}</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening profile for ${u.name}`)}>
                                  <Users className="h-3.5 w-3.5" /> View profile
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Email composed to ${u.email}`)}>
                                  <Mail className="h-3.5 w-3.5" /> Send email
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="text-xs gap-2"
                                  onClick={() => {
                                    setSelected(new Set([u.id]));
                                    handleActionClick("activate");
                                  }}
                                >
                                  <Power className="h-3.5 w-3.5" /> Activate
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="text-xs gap-2 text-destructive focus:text-destructive"
                                  onClick={() => {
                                    setSelected(new Set([u.id]));
                                    handleActionClick("delete");
                                  }}
                                >
                                  <Trash2 className="h-3.5 w-3.5" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
          <div className="flex items-center justify-between mt-3">
            <p className="text-xs text-muted-foreground">
              {filtered.length} of {data.length} users shown
              {selected.size > 0 && <> · <span className="text-primary font-medium">{selected.size} selected</span></>}
            </p>
            <p className="text-xs text-muted-foreground">Tip: click the header checkbox to select all matching rows at once.</p>
          </div>
        </CardContent>
      </Card>

      {/* Workflow legend — unique visual element */}
      <Card className="mt-6">
        <CardContent className="pt-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-start gap-3">
              <span className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary shrink-0 text-xs font-bold">1</span>
              <div>
                <p className="text-sm font-medium">Select rows</p>
                <p className="text-xs text-muted-foreground mt-0.5">Single click a checkbox, or use the header checkbox to select all matching rows. Indeterminate state shows partial selection.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)] shrink-0 text-xs font-bold">2</span>
              <div>
                <p className="text-sm font-medium">Pick an action</p>
                <p className="text-xs text-muted-foreground mt-0.5">The bulk action bar slides in with 6 operations. Tag and Move open dialogs; Activate / Export run immediately; Delete and Deactivate ask for confirmation.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--success)]/12 text-[color:var(--success)] shrink-0 text-xs font-bold">3</span>
              <div>
                <p className="text-sm font-medium">Confirm + toast</p>
                <p className="text-xs text-muted-foreground mt-0.5">Destructive actions show a confirmation dialog with the exact count. Every action fires a toast with the affected user names.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confirmation dialog for delete / deactivate */}
      <Dialog open={confirmAction !== null} onOpenChange={(o) => !o && setConfirmAction(null)}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <span className="grid place-items-center h-8 w-8 rounded-lg bg-destructive/12 text-destructive">
                <AlertTriangle className="h-4 w-4" />
              </span>
              Confirm {confirmAction?.type === "delete" ? "deletion" : "deactivation"}
            </DialogTitle>
            <DialogDescription>
              You are about to {confirmAction?.type === "delete" ? "permanently delete" : "deactivate"}{" "}
              <span className="font-semibold text-foreground">{confirmAction?.count}</span> user{confirmAction && confirmAction.count > 1 ? "s" : ""}.
              {confirmAction?.type === "delete"
                ? " This action cannot be undone."
                : " Users will lose access immediately but remain in the directory."}
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-md bg-muted/50 p-3 text-xs">
            <p className="font-medium mb-1">Affected users:</p>
            <p className="text-muted-foreground line-clamp-2">
              {selectedUsers.map((u) => u.name).join(", ")}
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setConfirmAction(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              className="gap-1.5"
              onClick={() => confirmAction && runAction(confirmAction.type)}
            >
              {confirmAction?.type === "delete" ? <Trash2 className="h-3.5 w-3.5" /> : <PowerOff className="h-3.5 w-3.5" />}
              {confirmAction?.type === "delete" ? "Delete" : "Deactivate"} {confirmAction?.count}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tag dialog */}
      <Dialog open={tagDialogOpen} onOpenChange={setTagDialogOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Tag className="h-4 w-4 text-[color:var(--info)]" />
              Tag {selected.size} user{selected.size > 1 ? "s" : ""}
            </DialogTitle>
            <DialogDescription>
              Add a tag to all selected users. Tags are visible in the table and can be filtered on later.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-2 py-2">
            <Input
              value={pendingTag}
              onChange={(e) => setPendingTag(e.target.value)}
              placeholder="e.g. q4-review, vip, contractor"
              className="h-9"
              autoFocus
            />
            <div className="flex flex-wrap gap-1.5 mt-1">
              {["vip", "contractor", "q4-review", "high-priority", "external"].map((t) => (
                <button
                  key={t}
                  onClick={() => setPendingTag(t)}
                  className="inline-flex items-center rounded-full border border-border px-2 py-0.5 text-[11px] hover:bg-muted"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setTagDialogOpen(false)}>Cancel</Button>
            <Button size="sm" className="gap-1.5" onClick={() => runAction("tag")}>
              <Check className="h-3.5 w-3.5" /> Apply tag
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Move dialog */}
      <Dialog open={moveDialogOpen} onOpenChange={setMoveDialogOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderInput className="h-4 w-4 text-violet-500" />
              Move {selected.size} user{selected.size > 1 ? "s" : ""}
            </DialogTitle>
            <DialogDescription>
              Choose a destination folder. Users retain their roles and permissions.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-1.5 py-2">
            {FOLDERS.map((f) => (
              <button
                key={f}
                onClick={() => setPendingFolder(f)}
                className={cn(
                  "flex items-center gap-2 rounded-md border px-3 py-2 text-left text-sm transition-colors",
                  pendingFolder === f ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"
                )}
              >
                <FolderInput className="h-4 w-4 text-muted-foreground" />
                {f}
                {pendingFolder === f && <Check className="h-3.5 w-3.5 text-primary ml-auto" />}
              </button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setMoveDialogOpen(false)}>Cancel</Button>
            <Button size="sm" className="gap-1.5" onClick={() => runAction("move")}>
              <FolderInput className="h-3.5 w-3.5" /> Move users
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
