"use client";

import * as React from "react";
import {
  Plug,
  Search,
  CheckCircle2,
  Cloud,
  Key,
  CreditCard,
  Mail,
  MessageSquare,
  Github,
  Figma,
  Slack,
  Trello,
  Calendar,
  FileText,
  Code2,
  BarChart3,
  Database,
  Zap,
  Settings2,
  ExternalLink,
  Star,
  Filter,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Integration = {
  id: string;
  name: string;
  icon: React.ElementType;
  color: string;
  category: "Communication" | "Developer" | "Productivity" | "Analytics" | "Payments" | "CRM" | "Storage";
  description: string;
  connected: boolean;
  popular?: boolean;
  account?: string;
  events?: number;
};

const INTEGRATIONS: Integration[] = [
  { id: "slack", name: "Slack", icon: Slack, color: "bg-violet-500/12 text-violet-500", category: "Communication", description: "Send notifications, run slash commands, and turn messages into tasks.", connected: true, popular: true, account: "nexusgrid.slack.com", events: 18420 },
  { id: "github", name: "GitHub", icon: Github, color: "bg-foreground/8 text-foreground", category: "Developer", description: "Sync pull requests, issues, commits, and deployments to your projects.", connected: true, popular: true, account: "nexusgrid-org", events: 92840 },
  { id: "stripe", name: "Stripe", icon: CreditCard, color: "bg-indigo-500/12 text-indigo-500", category: "Payments", description: "Self-serve billing, subscription management, and automated invoicing.", connected: true, account: "acct_1Nx9gr...", events: 4280 },
  { id: "figma", name: "Figma", icon: Figma, color: "bg-orange-500/12 text-orange-500", category: "Productivity", description: "Embed design files, sync component libraries, and track design changes.", connected: true, account: "NexusGrid team", events: 2840 },
  { id: "hubspot", name: "HubSpot", icon: BarChart3, color: "bg-orange-600/12 text-orange-600", category: "CRM", description: "Sync contacts, deals, and lifecycle stages for marketing and sales.", connected: false },
  { id: "salesforce", name: "Salesforce", icon: Cloud, color: "bg-sky-500/12 text-sky-500", category: "CRM", description: "Enterprise CRM sync with custom field mapping and bi-directional flow.", connected: false, popular: true },
  { id: "zapier", name: "Zapier", icon: Zap, color: "bg-orange-500/12 text-orange-500", category: "Productivity", description: "Connect NexusGrid to 5,000+ apps without writing a line of code.", connected: true, popular: true, account: "amara@nexusgrid.io", events: 14200 },
  { id: "notion", name: "Notion", icon: FileText, color: "bg-foreground/8 text-foreground", category: "Productivity", description: "Embed docs, sync databases, and surface wiki pages in your workspace.", connected: false },
  { id: "linear", name: "Linear", icon: Code2, color: "bg-indigo-500/12 text-indigo-500", category: "Developer", description: "Bi-directional issue sync with sprints, labels, and status workflows.", connected: false, popular: true },
  { id: "datadog", name: "Datadog", icon: BarChart3, color: "bg-violet-500/12 text-violet-500", category: "Analytics", description: "Push metrics, traces, and logs to Datadog for unified observability.", connected: false },
  { id: "amplitude", name: "Amplitude", icon: BarChart3, color: "bg-blue-500/12 text-blue-500", category: "Analytics", description: "Stream product events for cohort analysis and retention tracking.", connected: false },
  { id: "s3", name: "Amazon S3", icon: Database, color: "bg-amber-500/12 text-amber-500", category: "Storage", description: "Archive exports, backups, and large file attachments to your S3 bucket.", connected: true, account: "nexusgrid-backups", events: 940 },
  { id: "twilio", name: "Twilio", icon: MessageSquare, color: "bg-red-500/12 text-red-500", category: "Communication", description: "Send SMS notifications, OTPs, and incident pages via Twilio.", connected: false },
  { id: "google_calendar", name: "Google Calendar", icon: Calendar, color: "bg-blue-500/12 text-blue-500", category: "Productivity", description: "Sync meetings, deadlines, and PTO to your team's shared calendar.", connected: false },
  { id: "trello", name: "Trello", icon: Trello, color: "bg-blue-600/12 text-blue-600", category: "Productivity", description: "Mirror Trello boards as NexusGrid projects with card status sync.", connected: false },
];

const CATEGORIES = ["All", "Communication", "Developer", "Productivity", "Analytics", "Payments", "CRM", "Storage"] as const;

export default function IntegrationsPage() {
  const [integrations, setIntegrations] = React.useState<Integration[]>(INTEGRATIONS);
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState<string>("All");
  const [showConnectedOnly, setShowConnectedOnly] = React.useState(false);

  const filtered = integrations.filter((i) => {
    const s = search.toLowerCase();
    const matchSearch = !s || i.name.toLowerCase().includes(s) || i.description.toLowerCase().includes(s);
    const matchCat = category === "All" || i.category === category;
    const matchConnected = !showConnectedOnly || i.connected;
    return matchSearch && matchCat && matchConnected;
  });

  const connected = integrations.filter((i) => i.connected);
  const available = integrations.filter((i) => !i.connected);

  const toggle = (id: string) =>
    setIntegrations((prev) => prev.map((i) => (i.id === id ? { ...i, connected: !i.connected } : i)));

  return (
    <>
      <PageHeader
        title="Integrations"
        description="Connect NexusGrid to the tools your team already lives in. 15+ services supported."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Integrations" }]}
        icon={Plug}
        actions={
          <Badge variant="outline" className="text-[10px] gap-1 border-emerald-500/40 text-emerald-600 bg-emerald-500/5">
            <CheckCircle2 className="h-3 w-3" /> {connected.length} connected
          </Badge>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* CATALOG (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          {/* FILTER BAR */}
          <Card className="p-3">
            <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search integrations…" className="pl-8 h-9 text-sm" />
              </div>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="h-9 w-[160px] text-xs gap-1.5"><Filter className="h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button
                variant={showConnectedOnly ? "default" : "outline"}
                size="sm"
                className="text-xs gap-1.5 h-9"
                onClick={() => setShowConnectedOnly(!showConnectedOnly)}
              >
                <CheckCircle2 className="h-3.5 w-3.5" /> Connected only
              </Button>
            </div>
          </Card>

          {/* GRID */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filtered.map((i) => (
              <Card
                key={i.id}
                className={cn(
                  "p-4 transition-all hover:shadow-premium-sm flex flex-col",
                  i.connected && "ring-1 ring-[color:var(--success)]/20"
                )}
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className={cn("grid place-items-center h-11 w-11 rounded-xl shrink-0", i.color)}>
                    <i.icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-semibold truncate">{i.name}</p>
                      {i.popular && (
                        <Badge variant="outline" className="text-[9px] gap-0.5 border-[color:var(--warning)]/40 text-[color:var(--warning)] bg-[color:var(--warning)]/5 shrink-0">
                          <Star className="h-2.5 w-2.5 fill-[color:var(--warning)]" /> Popular
                        </Badge>
                      )}
                    </div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wide mt-0.5">{i.category}</p>
                  </div>
                  {i.connected && <StatusBadge tone="success" dot>Connected</StatusBadge>}
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 flex-1">{i.description}</p>
                <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
                  {i.connected ? (
                    <>
                      <span className="text-[11px] text-muted-foreground font-mono truncate">{i.account}</span>
                      <Button variant="outline" size="sm" className="text-xs gap-1 h-7 shrink-0" onClick={() => toast.message(`Opening ${i.name} settings`)}>
                        <Settings2 className="h-3 w-3" /> Configure
                      </Button>
                    </>
                  ) : (
                    <>
                      <span className="text-[11px] text-muted-foreground">Not connected</span>
                      <Button size="sm" className="text-xs gap-1 h-7 shrink-0" onClick={() => { toggle(i.id); toast.success(`${i.name} connected`, { description: "Auth flow complete." }); }}>
                        <Plug className="h-3 w-3" /> Connect
                      </Button>
                    </>
                  )}
                </div>
              </Card>
            ))}
            {filtered.length === 0 && (
              <Card className="p-8 text-center col-span-full border-dashed">
                <p className="text-sm text-muted-foreground">No integrations match your filters.</p>
              </Card>
            )}
          </div>
        </div>

        {/* CONNECTED PANEL (1 col) */}
        <div className="lg:col-span-1">
          <Card className="lg:sticky lg:top-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-[color:var(--success)]" /> Connected ({connected.length})
              </CardTitle>
              <CardDescription>Manage your active integrations.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-[640px] overflow-y-auto divide-y divide-border">
                {connected.map((i) => (
                  <div key={i.id} className="p-3 hover:bg-muted/30 transition-colors">
                    <div className="flex items-start gap-2.5">
                      <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", i.color)}>
                        <i.icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-sm font-medium truncate">{i.name}</p>
                          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => toast.message(`Opening ${i.name}`)}>
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        </div>
                        <p className="text-[11px] text-muted-foreground truncate font-mono">{i.account}</p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <Badge variant="outline" className="text-[9px] gap-1">
                            <Zap className="h-2.5 w-2.5" /> {(i.events ?? 0).toLocaleString()} events
                          </Badge>
                          <StatusBadge tone="success" dot>Healthy</StatusBadge>
                        </div>
                      </div>
                    </div>
                    <Separator className="my-2.5" />
                    <div className="flex items-center gap-1.5">
                      <Button variant="outline" size="sm" className="text-xs h-7 flex-1 gap-1" onClick={() => toast.message(`${i.name} settings`)}>
                        <Settings2 className="h-3 w-3" /> Settings
                      </Button>
                      <Button variant="ghost" size="sm" className="text-xs h-7 text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => { toggle(i.id); toast.success(`${i.name} disconnected`); }}>
                        Disconnect
                      </Button>
                    </div>
                  </div>
                ))}
                {connected.length === 0 && (
                  <div className="p-8 text-center">
                    <Plug className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
                    <p className="text-xs text-muted-foreground">No integrations connected yet.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
