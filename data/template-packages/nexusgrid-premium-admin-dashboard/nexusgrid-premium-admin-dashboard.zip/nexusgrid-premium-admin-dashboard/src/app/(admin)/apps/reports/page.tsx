"use client";

import * as React from "react";
import {
  FileText,
  Plus,
  Play,
  Download,
  Clock,
  Calendar,
  Users,
  TrendingUp,
  DollarSign,
  Package,
  BarChart3,
  PieChart,
  Activity,
  Filter,
  MoreHorizontal,
  CheckCircle2,
  XCircle,
  Loader2,
  Star,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { KpiCard, Sparkline } from "@/components/common/kpi-card";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type ReportCategory = "Sales" | "Finance" | "Operations" | "Custom";

type Report = {
  id: string;
  name: string;
  description: string;
  category: ReportCategory;
  icon: any;
  iconColor: string;
  lastRun: string;
  schedule: string;
  owner: string;
  ownerAvatar: string;
  starred?: boolean;
};

const reports: Report[] = [
  { id: "r1", name: "Monthly Revenue Performance", description: "Revenue, refunds, and net GMV by channel and region.", category: "Sales", icon: DollarSign, iconColor: "var(--success)", lastRun: "2 hours ago", schedule: "Daily · 6:00 AM", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", starred: true },
  { id: "r2", name: "Customer Cohort Retention", description: "12-month rolling retention by acquisition cohort and segment.", category: "Sales", icon: Users, iconColor: "var(--primary)", lastRun: "Yesterday", schedule: "Weekly · Mondays", owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop" },
  { id: "r3", name: "P&L Statement (Monthly)", description: "Income statement with budget vs. actual variances.", category: "Finance", icon: BarChart3, iconColor: "oklch(0.62 0.18 140)", lastRun: "3 days ago", schedule: "Monthly · 2nd business day", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", starred: true },
  { id: "r4", name: "Cash Flow Forecast", description: "13-week rolling cash forecast with scenario modeling.", category: "Finance", icon: TrendingUp, iconColor: "oklch(0.70 0.15 75)", lastRun: "5 days ago", schedule: "Weekly · Fridays", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop" },
  { id: "r5", name: "Inventory Turnover", description: "SKU-level turnover, days-of-supply, and slow-mover analysis.", category: "Operations", icon: Package, iconColor: "oklch(0.62 0.18 305)", lastRun: "Today", schedule: "Daily · 8:00 AM", owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop" },
  { id: "r6", name: "Fulfillment SLA Report", description: "Order-to-delivery cycle time, by carrier and region.", category: "Operations", icon: Activity, iconColor: "var(--info)", lastRun: "Yesterday", schedule: "Weekly · Wednesdays", owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop" },
  { id: "r7", name: "Marketing Channel Mix", description: "Spend, CAC, and LTV by channel with attribution window.", category: "Custom", icon: PieChart, iconColor: "oklch(0.62 0.18 25)", lastRun: "1 week ago", schedule: "Monthly · 1st", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop" },
  { id: "r8", name: "Executive KPI Scorecard", description: "Top 12 KPIs rolled up for the leadership weekly review.", category: "Custom", icon: FileText, iconColor: "var(--primary)", lastRun: "Today", schedule: "Weekly · Mondays 7:00 AM", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", starred: true },
];

type Activity = {
  id: string;
  name: string;
  runBy: string;
  runByAvatar: string;
  status: "success" | "failed" | "running";
  duration: string;
  downloaded: boolean;
  finishedAt: string;
};

const activities: Activity[] = [
  { id: "a1", name: "Monthly Revenue Performance", runBy: "Scheduled", runByAvatar: "", status: "success", duration: "4.2s", downloaded: true, finishedAt: "2h ago" },
  { id: "a2", name: "Executive KPI Scorecard", runBy: "Elena Petrov", runByAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", status: "success", duration: "8.1s", downloaded: true, finishedAt: "4h ago" },
  { id: "a3", name: "Inventory Turnover", runBy: "Scheduled", runByAvatar: "", status: "success", duration: "12.4s", downloaded: false, finishedAt: "Today 8:00 AM" },
  { id: "a4", name: "P&L Statement (Monthly)", runBy: "Elena Petrov", runByAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", status: "success", duration: "18.7s", downloaded: true, finishedAt: "3d ago" },
  { id: "a5", name: "Customer Cohort Retention", runBy: "Marcus Reyes", runByAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", status: "success", duration: "6.8s", downloaded: false, finishedAt: "Yesterday" },
  { id: "a6", name: "Cash Flow Forecast", runBy: "Scheduled", runByAvatar: "", status: "failed", duration: "2.1s", downloaded: false, finishedAt: "5d ago" },
  { id: "a7", name: "Marketing Channel Mix", runBy: "Sarah Chen", runByAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", status: "success", duration: "9.4s", downloaded: true, finishedAt: "1w ago" },
  { id: "a8", name: "Fulfillment SLA Report", runBy: "Scheduled", runByAvatar: "", status: "success", duration: "5.6s", downloaded: false, finishedAt: "2d ago" },
];

const activityStatusConfig: Record<Activity["status"], { tone: StatusTone; icon: any; label: string }> = {
  success: { tone: "success", icon: CheckCircle2, label: "Success" },
  failed: { tone: "danger", icon: XCircle, label: "Failed" },
  running: { tone: "info", icon: Loader2, label: "Running" },
};

const categoryTabs = ["Sales", "Finance", "Operations", "Custom"] as ReportCategory[];

export default function ReportsPage() {
  const [activeCategory, setActiveCategory] = React.useState<ReportCategory | "All">("All");
  const [newOpen, setNewOpen] = React.useState(false);

  const filteredReports = reports.filter((r) => activeCategory === "All" || r.category === activeCategory);

  const columns: Column<Activity>[] = [
    {
      key: "name",
      header: "Report",
      sortable: true,
      sortAccessor: (r) => r.name,
      cell: (r) => <span className="text-sm font-medium">{r.name}</span>,
    },
    {
      key: "runBy",
      header: "Run By",
      cell: (r) => (
        <div className="flex items-center gap-2">
          {r.runByAvatar ? (
            <Avatar className="h-6 w-6">
              <AvatarImage src={r.runByAvatar} alt={r.runBy} />
              <AvatarFallback className="text-[10px]">{r.runBy.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
            </Avatar>
          ) : (
            <div className="grid place-items-center h-6 w-6 rounded-full bg-muted text-muted-foreground">
              <Calendar className="h-3 w-3" />
            </div>
          )}
          <span className="text-xs">{r.runBy}</span>
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Success", value: "success" },
        { label: "Failed", value: "failed" },
        { label: "Running", value: "running" },
      ],
      align: "center",
      cell: (r) => {
        const cfg = activityStatusConfig[r.status];
        const Icon = cfg.icon;
        return (
          <StatusBadge tone={cfg.tone} dot>
            <Icon className={cn("h-2.5 w-2.5", r.status === "running" && "animate-spin")} />
            {cfg.label}
          </StatusBadge>
        );
      },
    },
    {
      key: "duration",
      header: "Duration",
      sortable: true,
      sortAccessor: (r) => r.duration,
      align: "right",
      cell: (r) => <span className="text-xs tabular-nums font-mono">{r.duration}</span>,
    },
    {
      key: "finishedAt",
      header: "Finished",
      sortable: true,
      sortAccessor: (r) => r.finishedAt,
      cell: (r) => <span className="text-xs text-muted-foreground">{r.finishedAt}</span>,
    },
    {
      key: "downloaded",
      header: "Downloaded",
      align: "center",
      cell: (r) => r.downloaded ? <CheckCircle2 className="h-3.5 w-3.5 text-[color:var(--success)] mx-auto" /> : <span className="text-xs text-muted-foreground/50">—</span>,
      hideable: true,
    },
    {
      key: "actions",
      header: "",
      align: "right",
      hideable: false,
      cell: (r) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-7 w-7"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => toast.success("Download started")}><Download className="h-3.5 w-3.5 mr-2" />Download</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast.success("Re-running report")}><Play className="h-3.5 w-3.5 mr-2" />Re-run</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast.success("Shared")}><Users className="h-3.5 w-3.5 mr-2" />Share</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  return (
    <>
      <PageHeader
        title="Reports"
        description="Build, schedule, and share data-driven reports across the organization."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "Reports" }]}
        icon={FileText}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setNewOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> New Report
          </Button>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Saved Reports"
          value={reports.length.toString()}
          icon={FileText}
          accent="primary"
          trend={{ value: 12.4, direction: "up" }}
          hint="3 added this month"
          sparkline={<Sparkline data={[2, 4, 5, 6, 7, 8, 8]} color="var(--primary)" />}
        />
        <KpiCard
          label="Scheduled"
          value="6"
          icon={Calendar}
          accent="info"
          trend={{ value: 8.2, direction: "up" }}
          hint="running on schedule"
        />
        <KpiCard
          label="Generated Today"
          value="24"
          icon={Activity}
          accent="success"
          trend={{ value: 4.6, direction: "up" }}
          hint="across all reports"
        />
        <KpiCard
          label="Total Exports"
          value="1,842"
          icon={Download}
          accent="warning"
          trend={{ value: 18.6, direction: "up" }}
          hint="last 30 days"
          sparkline={<Sparkline data={[1240, 1380, 1490, 1580, 1670, 1760, 1842]} color="var(--warning)" />}
        />
      </div>

      {/* Category tabs */}
      <Tabs value={activeCategory} onValueChange={(v) => setActiveCategory(v as any)} className="mb-4">
        <TabsList>
          <TabsTrigger value="All" className="text-xs">All Reports</TabsTrigger>
          {categoryTabs.map((c) => (
            <TabsTrigger key={c} value={c} className="text-xs">{c}</TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* Reports grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
        {filteredReports.map((r) => {
          const Icon = r.icon;
          return (
            <Card key={r.id} className="group hover:border-primary/30 hover:shadow-premium-sm transition-all">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="grid place-items-center h-11 w-11 rounded-lg shrink-0" style={{ background: `color-mix(in srgb, ${r.iconColor} 12%, transparent)`, color: r.iconColor }}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex items-center gap-1">
                    {r.starred && <Star className="h-3.5 w-3.5 text-[color:var(--warning)] fill-current" />}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => toast.success("Duplicated")}>Duplicate</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast.success("Schedule opened")}>Edit schedule</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast.success("Shared with team")}>Share</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => toast.success("Report deleted")}>Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-sm font-semibold leading-snug">{r.name}</p>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 min-h-[32px]">{r.description}</p>

                <div className="flex items-center gap-3 mt-3 text-[10px] text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{r.lastRun}</span>
                  <span className="inline-flex items-center gap-1"><Calendar className="h-2.5 w-2.5" />{r.schedule}</span>
                </div>

                <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={r.ownerAvatar} alt={r.owner} />
                      <AvatarFallback className="text-[8px]">{r.owner.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                    </Avatar>
                    <span className="text-[10px] text-muted-foreground">{r.owner}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Opening report")}>
                      View <ChevronRight className="h-3 w-3" />
                    </Button>
                    <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Generating report...")}>
                      <Play className="h-3 w-3" /> Run
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Recent activity table */}
      <DataTable
        title="Recent Report Runs"
        data={activities}
        columns={columns}
        pageSize={8}
        getRowId={(r) => r.id}
        initialSort={{ key: "finishedAt", direction: "desc" }}
        onRowClick={(r) => toast.message(`Viewing ${r.name}`)}
      />

      {/* New report dialog */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>New Report Builder</DialogTitle>
            <DialogDescription>Configure a data source, fields, filters, and delivery schedule.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Step 1: Source */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="grid place-items-center h-5 w-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">1</div>
                <Label className="text-xs font-semibold uppercase tracking-wide">Data Source</Label>
              </div>
              <Select defaultValue="postgres-main">
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="postgres-main" className="text-sm">PostgreSQL · main (read replica)</SelectItem>
                  <SelectItem value="warehouse" className="text-sm">Snowflake · analytics warehouse</SelectItem>
                  <SelectItem value="stripe" className="text-sm">Stripe · billing events</SelectItem>
                  <SelectItem value="segment" className="text-sm">Segment · product events</SelectItem>
                  <SelectItem value="zendesk" className="text-sm">Zendesk · support tickets</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Step 2: Fields */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="grid place-items-center h-5 w-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">2</div>
                <Label className="text-xs font-semibold uppercase tracking-wide">Fields</Label>
              </div>
              <div className="rounded-lg border border-border p-3 grid grid-cols-2 gap-2">
                {[
                  { label: "Customer name", checked: true },
                  { label: "Email", checked: true },
                  { label: "Plan tier", checked: true },
                  { label: "MRR", checked: true },
                  { label: "Signup date", checked: false },
                  { label: "Last activity", checked: true },
                  { label: "Lifetime revenue", checked: true },
                  { label: "Churn risk score", checked: false },
                ].map((f) => (
                  <label key={f.label} className="flex items-center gap-2 cursor-pointer">
                    <Checkbox defaultChecked={f.checked} />
                    <span className="text-xs">{f.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Step 3: Filters */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="grid place-items-center h-5 w-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">3</div>
                <Label className="text-xs font-semibold uppercase tracking-wide">Filters</Label>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Select defaultValue="active">
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" className="text-xs">All customers</SelectItem>
                    <SelectItem value="active" className="text-xs">Active only</SelectItem>
                    <SelectItem value="churned" className="text-xs">Churned only</SelectItem>
                    <SelectItem value="trial" className="text-xs">Trialing only</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="90d">
                  <SelectTrigger className="h-8 text-xs"><Filter className="h-3 w-3" /><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7d" className="text-xs">Last 7 days</SelectItem>
                    <SelectItem value="30d" className="text-xs">Last 30 days</SelectItem>
                    <SelectItem value="90d" className="text-xs">Last 90 days</SelectItem>
                    <SelectItem value="ytd" className="text-xs">Year to date</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Step 4: Schedule */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="grid place-items-center h-5 w-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">4</div>
                <Label className="text-xs font-semibold uppercase tracking-wide">Schedule & Delivery</Label>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Select defaultValue="weekly">
                  <SelectTrigger className="h-8 text-xs"><Calendar className="h-3 w-3" /><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily" className="text-xs">Daily</SelectItem>
                    <SelectItem value="weekly" className="text-xs">Weekly</SelectItem>
                    <SelectItem value="monthly" className="text-xs">Monthly</SelectItem>
                    <SelectItem value="manual" className="text-xs">Manual only</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="pdf">
                  <SelectTrigger className="h-8 text-xs"><Download className="h-3 w-3" /><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pdf" className="text-xs">PDF</SelectItem>
                    <SelectItem value="xlsx" className="text-xs">Excel (XLSX)</SelectItem>
                    <SelectItem value="csv" className="text-xs">CSV</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Input placeholder="Recipients (comma-separated emails)" className="h-8 text-xs" defaultValue="elena.petrov@nexusgrid.io, marcus.reyes@nexusgrid.io" />
            </div>

            {/* Name + description */}
            <div className="space-y-2 pt-2 border-t">
              <div className="space-y-1.5">
                <Label className="text-xs">Report name</Label>
                <Input placeholder="Untitled report" className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Description (optional)</Label>
                <Textarea placeholder="What does this report show?" rows={2} className="text-sm" />
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setNewOpen(false)}>Cancel</Button>
            <Button variant="outline" size="sm" onClick={() => toast.success("Preview generated")}><Play className="h-3.5 w-3.5" /> Preview</Button>
            <Button size="sm" className="gap-1.5" onClick={() => { toast.success("Report saved and scheduled"); setNewOpen(false); }}>
              <CheckCircle2 className="h-3.5 w-3.5" /> Save Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
