"use client";

import * as React from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  CheckCheck,
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Phone,
  CalendarDays,
  ShieldCheck,
  CheckCircle2,
  X,
  Zap,
  Coffee,
  Loader2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { format, differenceInYears } from "date-fns";

const schema = z
  .object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    email: z.string().min(1, "Email is required").email("Enter a valid email address"),
    password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Add at least one uppercase letter")
      .regex(/[0-9]/, "Add at least one number"),
    confirmPassword: z.string().min(1, "Please confirm your password"),
    phone: z
      .string()
      .min(1, "Phone is required")
      .regex(/^\+?[\d\s()-]{10,}$/, "Enter a valid phone number"),
    dob: z
      .date({ required_error: "Date of birth is required" })
      .refine((d) => differenceInYears(new Date(), d) >= 18, "You must be 18 or older"),
    terms: z.boolean().refine((v) => v === true, "You must accept the terms"),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type FormValues = z.infer<typeof schema>;

function strengthOf(pwd: string): { score: number; label: string; tone: string } {
  let score = 0;
  if (pwd.length >= 8) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^a-zA-Z0-9]/.test(pwd)) score++;
  if (pwd.length >= 12) score++;
  const map = [
    { label: "Too short", tone: "bg-muted" },
    { label: "Weak", tone: "bg-destructive" },
    { label: "Fair", tone: "bg-amber-500" },
    { label: "Good", tone: "bg-sky-500" },
    { label: "Strong", tone: "bg-emerald-500" },
    { label: "Excellent", tone: "bg-emerald-600" },
  ];
  return { score, ...map[score] };
}

function RegistrationForm({
  mode,
  onSubmitted,
  onStateChange,
}: {
  mode: "onBlur" | "onChange";
  onSubmitted: (v: FormValues) => void;
  onStateChange: (s: { isDirty: boolean; isValid: boolean; submitCount: number; errors: Record<string, unknown>; touched: Record<string, boolean> }) => void;
}) {
  const [showPwd, setShowPwd] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    mode,
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      phone: "",
      terms: false,
    },
  });

  const password = form.watch("password");
  const strength = strengthOf(password);

  React.useEffect(() => {
    const sub = form.subscribe((state) => {
      onStateChange({
        isDirty: state.isDirty,
        isValid: state.isValid,
        submitCount: state.submitCount,
        errors: state.errors as Record<string, unknown>,
        touched: state.touchedFields as Record<string, boolean>,
      });
    });
    return () => sub();
  }, [form, onStateChange]);

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmitted)}
        className="grid gap-5"
      >
        <div className="grid sm:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5 text-muted-foreground" /> Full name
                </FormLabel>
                <FormControl>
                  <Input placeholder="Sarah Chen" {...field} />
                </FormControl>
                <FormDescription className="text-[11px]">Minimum 2 characters.</FormDescription>
                <FormMessage className="text-[11px]" />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-muted-foreground" /> Email address
                </FormLabel>
                <FormControl>
                  <Input type="email" placeholder="sarah@example.com" {...field} />
                </FormControl>
                <FormDescription className="text-[11px]">We'll send a verification link here.</FormDescription>
                <FormMessage className="text-[11px]" />
              </FormItem>
            )}
          />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs flex items-center gap-1.5">
                  <Lock className="h-3.5 w-3.5 text-muted-foreground" /> Password
                </FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input
                      type={showPwd ? "text" : "password"}
                      placeholder="At least 8 characters"
                      {...field}
                      className="pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPwd((s) => !s)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                      aria-label={showPwd ? "Hide password" : "Show password"}
                    >
                      {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </FormControl>
                {password.length > 0 && (
                  <div className="flex items-center gap-2 mt-1.5">
                    <div className="flex-1 grid grid-cols-5 gap-1">
                      {[0, 1, 2, 3, 4].map((i) => (
                        <div
                          key={i}
                          className={cn(
                            "h-1 rounded-full transition-colors",
                            i < strength.score ? strength.tone : "bg-muted"
                          )}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-medium text-muted-foreground w-16 text-right">
                      {strength.label}
                    </span>
                  </div>
                )}
                <FormMessage className="text-[11px]" />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="confirmPassword"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs flex items-center gap-1.5">
                  <ShieldCheck className="h-3.5 w-3.5 text-muted-foreground" /> Confirm password
                </FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input
                      type={showConfirm ? "text" : "password"}
                      placeholder="Re-enter your password"
                      {...field}
                      className="pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirm((s) => !s)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                      aria-label={showConfirm ? "Hide password" : "Show password"}
                    >
                      {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </FormControl>
                <FormDescription className="text-[11px]">Must match the password above.</FormDescription>
                <FormMessage className="text-[11px]" />
              </FormItem>
            )}
          />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs flex items-center gap-1.5">
                  <Phone className="h-3.5 w-3.5 text-muted-foreground" /> Phone number
                </FormLabel>
                <FormControl>
                  <Input type="tel" placeholder="+1 (415) 555-0148" {...field} />
                </FormControl>
                <FormDescription className="text-[11px]">Include country code and area code.</FormDescription>
                <FormMessage className="text-[11px]" />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="dob"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" /> Date of birth
                </FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        type="button"
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                        {field.value ? format(field.value, "PPP") : "Pick your birth date"}
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      disabled={(d) => d > new Date() || d < new Date("1900-01-01")}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormDescription className="text-[11px]">You must be 18 or older.</FormDescription>
                <FormMessage className="text-[11px]" />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="terms"
          render={({ field }) => (
            <FormItem>
              <div className="flex items-start gap-2.5 rounded-md border p-3">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    className="mt-0.5"
                  />
                </FormControl>
                <div className="grid gap-0.5">
                  <Label className="text-xs font-medium cursor-pointer">
                    I agree to the Terms of Service and Privacy Policy
                  </Label>
                  <p className="text-[11px] text-muted-foreground">
                    By creating an account you consent to receive transactional emails. You can unsubscribe anytime.
                  </p>
                </div>
              </div>
              <FormMessage className="text-[11px]" />
            </FormItem>
          )}
        />

        <div className="flex items-center justify-between gap-2 pt-2 border-t">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              form.reset();
              toast.message("Form reset");
            }}
            className="gap-1.5"
          >
            <X className="h-3.5 w-3.5" /> Reset
          </Button>
          <Button type="submit" size="sm" disabled={form.formState.isSubmitting} className="gap-1.5">
            {form.formState.isSubmitting ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <CheckCircle2 className="h-3.5 w-3.5" />
            )}
            Create account
          </Button>
        </div>
      </form>
    </Form>
  );
}

type LiveState = {
  isDirty: boolean;
  isValid: boolean;
  submitCount: number;
  errors: Record<string, unknown>;
  touched: Record<string, boolean>;
};

export default function FormValidationPage() {
  const [validateOnBlur, setValidateOnBlur] = React.useState(true);
  const [submitted, setSubmitted] = React.useState<FormValues | null>(null);
  const [live, setLive] = React.useState<LiveState>({
    isDirty: false,
    isValid: false,
    submitCount: 0,
    errors: {},
    touched: {},
  });

  const onStateChange = React.useCallback((s: LiveState) => setLive(s), []);

  return (
    <>
      <PageHeader
        title="Form Validation"
        description="Real-time, schema-driven validation powered by react-hook-form and zod."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Form Validation" }]}
        icon={CheckCheck}
        actions={
          <div className="flex items-center gap-2 rounded-lg border bg-card px-3 py-1.5">
            <Zap className={cn("h-3.5 w-3.5", validateOnBlur ? "text-muted-foreground" : "text-primary")} />
            <Coffee className={cn("h-3.5 w-3.5", validateOnBlur ? "text-primary" : "text-muted-foreground")} />
            <Separator orientation="vertical" className="h-4" />
            <span className="text-xs text-muted-foreground">{validateOnBlur ? "On blur" : "On change"}</span>
            <Switch checked={validateOnBlur} onCheckedChange={setValidateOnBlur} />
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Create your account</CardTitle>
            <CardDescription>Fields validate {validateOnBlur ? "when you leave them" : "as you type"}. Try invalid values to see error states.</CardDescription>
          </CardHeader>
          <CardContent>
            <RegistrationForm
              key={validateOnBlur ? "blur" : "change"}
              mode={validateOnBlur ? "onBlur" : "onChange"}
              onSubmitted={(v) => {
                setSubmitted(v);
                toast.success("Account created", { description: `Welcome aboard, ${v.name}!` });
              }}
              onStateChange={onStateChange}
            />
          </CardContent>
        </Card>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Live form state</CardTitle>
              <CardDescription>Inspect what react-hook-form tracks internally.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Validation mode</span>
                <Badge variant="secondary">{validateOnBlur ? "onBlur" : "onChange"}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Dirty</span>
                <Badge variant={live.isDirty ? "default" : "outline"}>{live.isDirty ? "Yes" : "No"}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Valid</span>
                <Badge variant={live.isValid ? "default" : "outline"}>{live.isValid ? "Yes" : "No"}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Submit count</span>
                <span className="tabular-nums">{live.submitCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Errors</span>
                <span className="tabular-nums">{Object.keys(live.errors).length}</span>
              </div>
              <Separator />
              <div>
                <p className="text-muted-foreground mb-1.5">Touched fields</p>
                <div className="flex flex-wrap gap-1 min-h-[20px]">
                  {Object.keys(live.touched).length === 0 ? (
                    <span className="text-muted-foreground italic">None yet</span>
                  ) : (
                    Object.keys(live.touched).map((k) => (
                      <Badge key={k} variant="outline" className="text-[10px]">{k}</Badge>
                    ))
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {submitted ? (
            <Card className="border-emerald-500/40 bg-emerald-500/5">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" /> Submission received
                </CardTitle>
                <CardDescription>Here's the validated payload that would be sent to the API.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-3 text-xs">
                <Row label="Name" value={submitted.name} />
                <Row label="Email" value={submitted.email} />
                <Row label="Phone" value={submitted.phone} />
                <Row label="Date of birth" value={format(submitted.dob, "PPP")} />
                <Row label="Password" value={"•".repeat(submitted.password.length)} />
                <Row label="Terms accepted" value={submitted.terms ? "Yes" : "No"} />
              </CardContent>
            </Card>
          ) : (
            <Card className="border-dashed">
              <CardContent className="py-10 grid place-items-center text-center gap-2">
                <div className="grid place-items-center h-10 w-10 rounded-full bg-muted">
                  <CheckCheck className="h-5 w-5 text-muted-foreground" />
                </div>
                <p className="text-sm font-medium">No submission yet</p>
                <p className="text-xs text-muted-foreground max-w-[220px]">Fill out the form and submit to see the validated payload here.</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium truncate max-w-[60%] text-right">{value}</span>
    </div>
  );
}
