"use client";

import * as React from "react";
import {
  RotateCcw,
  DollarSign,
  Clock,
  Timer,
  Download,
  RefreshCw,
  MoreHorizontal,
  Eye,
  Check,
  X,
  AlertCircle,
  TrendingDown,
  Inbox,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { AreaTrendChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type RefundStatus = "pending" | "approved" | "processing" | "completed" | "rejected";

type Refund = {
  id: string;
  orderId: string;
  customer: string;
  avatar: string;
  amount: number;
  reason: string;
  status: RefundStatus;
  requested: string;
  processedBy: string;
  processedAt?: string;
};

const refunds: Refund[] = [
  { id: "RF-4821", orderId: "NX-3945", customer: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", amount: 96.99, reason: "Item arrived damaged", status: "pending", requested: "2026-07-01 09:24", processedBy: "—" },
  { id: "RF-4820", orderId: "NX-3942", customer: "Lena Hoffmann", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", amount: 144.50, reason: "Wrong item shipped", status: "approved", requested: "2026-06-30 14:12", processedBy: "Sarah Chen", processedAt: "2026-06-30 16:40" },
  { id: "RF-4819", orderId: "NX-3930", customer: "Ethan Wright", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", amount: 168.45, reason: "Customer changed mind", status: "completed", requested: "2026-06-29 11:08", processedBy: "Marcus Reyes", processedAt: "2026-06-29 15:22" },
  { id: "RF-4818", orderId: "NX-3917", customer: "Isabella Costa", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", amount: 428.00, reason: "Product defective", status: "processing", requested: "2026-06-29 08:42", processedBy: "Elena Petrov", processedAt: "2026-06-29 14:00" },
  { id: "RF-4817", orderId: "NX-3905", customer: "Raj Patel", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", amount: 84.00, reason: "Late delivery", status: "completed", requested: "2026-06-28 19:15", processedBy: "Sarah Chen", processedAt: "2026-06-28 21:30" },
  { id: "RF-4816", orderId: "NX-3898", customer: "Mei Lin", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", amount: 287.40, reason: "Item not as described", status: "pending", requested: "2026-06-28 10:50", processedBy: "—" },
  { id: "RF-4815", orderId: "NX-3892", customer: "Sofia Rossi", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", amount: 612.30, reason: "Duplicate charge", status: "rejected", requested: "2026-06-27 13:24", processedBy: "James Okoro", processedAt: "2026-06-27 17:48" },
  { id: "RF-4814", orderId: "NX-3885", customer: "Carlos Mendez", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", amount: 178.20, reason: "Customer changed mind", status: "completed", requested: "2026-06-26 09:30", processedBy: "Aiko Tanaka", processedAt: "2026-06-26 12:10" },
  { id: "RF-4813", orderId: "NX-3879", customer: "Yuki Sato", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", amount: 398.75, reason: "Item arrived damaged", status: "approved", requested: "2026-06-25 15:18", processedBy: "Marcus Reyes", processedAt: "2026-06-25 18:22" },
  { id: "RF-4812", orderId: "NX-3870", customer: "Charlotte Klein", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", amount: 245.00, reason: "Wrong size", status: "processing", requested: "2026-06-24 11:42", processedBy: "Elena Petrov", processedAt: "2026-06-24 16:00" },
  { id: "RF-4811", orderId: "NX-3862", customer: "David Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", amount: 528.75, reason: "Product defective", status: "completed", requested: "2026-06-23 08:15", processedBy: "Sarah Chen", processedAt: "2026-06-23 11:30" },
  { id: "RF-4810", orderId: "NX-3855", customer: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", amount: 312.00, reason: "Late delivery", status: "completed", requested: "2026-06-22 14:24", processedBy: "James Okoro", processedAt: "2026-06-22 17:00" },
];

const statusToneMap: Record<RefundStatus, "warning" | "info" | "primary" | "success" | "danger"> = {
  pending: "warning",
  approved: "info",
  processing: "primary",
  completed: "success",
  rejected: "danger",
};

const refundTrend = [
  { day: "Jun 25", amount: 840, count: 4 },
  { day: "Jun 26", amount: 1240, count: 6 },
  { day: "Jun 27", amount: 920, count: 5 },
  { day: "Jun 28", amount: 1640, count: 7 },
  { day: "Jun 29", amount: 1380, count: 6 },
  { day: "Jun 30", amount: 2120, count: 9 },
  { day: "Jul 01", amount: 1820, count: 8 },
];

// Refund-style KPI card — left accent bar + ledger feel
function RefundKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "danger" | "warning" | "info";
  trend: string;
  trendPositive?: boolean;
}) {
  const accentBar = {
    primary: "bg-primary",
    danger: "bg-destructive",
    warning: "bg-[color:var(--warning)]",
    info: "bg-[color:var(--info)]",
  };
  const accentIcon = {
    primary: "bg-primary/10 text-primary",
    danger: "bg-destructive/12 text-destructive",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
  };
  return (
    <Card className="relative overflow-hidden">
      <div className={cn("absolute left-0 top-0 bottom-0 w-1", accentBar[accent])} />
      <CardContent className="pt-5 pb-4 pl-6">
        <div className="flex items-start justify-between mb-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
          <div className={cn("grid place-items-center h-8 w-8 rounded-lg shrink-0", accentIcon[accent])}>
            <Icon className="h-4 w-4" />
          </div>
        </div>
        <p className="text-2xl font-semibold tabular-nums">{value}</p>
        <p className="text-xs text-muted-foreground mt-1">{hint}</p>
        <p className={cn(
          "text-xs font-medium mt-2 inline-flex items-center gap-0.5",
          trendPositive ? "text-[color:var(--success)]" : "text-destructive"
        )}>
          <TrendingDown className="h-3 w-3" /> {trend}
        </p>
      </CardContent>
    </Card>
  );
}

export default function RefundsPage() {
  const [statusFilter, setStatusFilter] = React.useState<"all" | RefundStatus>("all");

  const filtered = React.useMemo(() => {
    if (statusFilter === "all") return refunds;
    return refunds.filter((r) => r.status === statusFilter);
  }, [statusFilter]);

  const reasonCounts = React.useMemo(() => {
    const map = new Map<string, number>();
    refunds.forEach((r) => map.set(r.reason, (map.get(r.reason) ?? 0) + 1));
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, []);

  return (
    <>
      <PageHeader
        title="Refunds"
        description="Process customer refund requests, track resolution times, and analyze refund drivers."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Refunds" }]}
        icon={RotateCcw}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Refund report exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Bulk refund processor opened")}>
              <RefreshCw className="h-3.5 w-3.5" /> Process Pending
            </Button>
          </>
        }
      />

      {/* Refund KPI cards — left accent bar + ledger feel */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <RefundKpi label="Total Refunds" value="128" hint="last 30 days" icon={Inbox} accent="primary" trend="8 vs prev. period" trendPositive />
        <RefundKpi label="Refund Amount" value="$8,420" hint="2.96% of revenue" icon={DollarSign} accent="danger" trend="$640 vs prev. period" trendPositive />
        <RefundKpi label="Pending" value="6" hint="awaiting review" icon={Clock} accent="warning" trend="2 added today" />
        <RefundKpi label="Avg Processing Time" value="4.2 hrs" hint="target: < 6 hrs" icon={Timer} accent="info" trend="0.8 hrs faster" trendPositive />
      </div>

      {/* Refund trend chart + reason breakdown */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="pb-2 flex flex-row items-start justify-between">
            <div>
              <CardTitle className="text-base">Refund Trend</CardTitle>
              <CardDescription>Daily refund amount over the last 7 days.</CardDescription>
            </div>
            <StatusBadge tone="danger" dot>−$8,420 total</StatusBadge>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={refundTrend}
              xKey="day"
              series={[
                { key: "amount", name: "Refund Amount ($)", color: "var(--destructive)" },
              ]}
              height={260}
            />
            <div className="grid grid-cols-3 gap-3 mt-3 pt-3 border-t border-border">
              <div>
                <p className="text-xs text-muted-foreground">Peak Day</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">Jun 30 · $2,120</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Daily Average</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">$1,280</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Avg Refund Size</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">$65.78</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-[color:var(--warning)]" />
              Refund Reasons
            </CardTitle>
            <CardDescription>Why customers request refunds.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {reasonCounts.map(([reason, count]) => {
              const pct = Math.round((count / refunds.length) * 100);
              return (
                <div key={reason}>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium text-foreground">{reason}</span>
                    <span className="text-muted-foreground tabular-nums">{count} · {pct}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-700",
                        reason.includes("damage") || reason.includes("defective")
                          ? "bg-destructive"
                          : reason.includes("Wrong") || reason.includes("Late")
                          ? "bg-[color:var(--warning)]"
                          : "bg-[color:var(--info)]"
                      )}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
            <div className="pt-3 mt-3 border-t border-border">
              <p className="text-xs text-muted-foreground">
                <span className="font-medium text-foreground">Quality issues</span> (damage + defective) account for{" "}
                <span className="font-semibold text-destructive">
                  {Math.round(
                    ((reasonCounts.find(([r]) => r.includes("damage"))?.[1] ?? 0) +
                      (reasonCounts.find(([r]) => r.includes("defective"))?.[1] ?? 0)) /
                      refunds.length *
                      100
                  )}%
                </span>{" "}
                of all refunds.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Refunds table — custom */}
      <Card>
        <CardContent className="p-0">
          {/* Status filter tabs */}
          <div className="flex items-center justify-between gap-2 p-3 sm:p-4 border-b border-border bg-muted/30">
            <Tabs value={statusFilter} onValueChange={(v) => setStatusFilter(v as "all" | RefundStatus)}>
              <TabsList className="h-9 flex-wrap">
                <TabsTrigger value="all" className="text-xs">All ({refunds.length})</TabsTrigger>
                <TabsTrigger value="pending" className="text-xs">Pending ({refunds.filter((r) => r.status === "pending").length})</TabsTrigger>
                <TabsTrigger value="approved" className="text-xs">Approved</TabsTrigger>
                <TabsTrigger value="processing" className="text-xs">Processing</TabsTrigger>
                <TabsTrigger value="completed" className="text-xs">Completed</TabsTrigger>
                <TabsTrigger value="rejected" className="text-xs">Rejected</TabsTrigger>
              </TabsList>
            </Tabs>
            <span className="text-xs text-muted-foreground hidden sm:block">{filtered.length} refunds</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Refund ID</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Order</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Customer</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Amount</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Reason</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Requested</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden xl:table-cell">Processed By</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-12">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((r) => (
                  <tr
                    key={r.id}
                    className="hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => toast.message(`Opening refund ${r.id} detail`)}
                  >
                    <td className="px-4 py-3 font-mono text-xs font-semibold">{r.id}</td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className="font-mono text-xs text-primary">{r.orderId}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <Avatar className="h-7 w-7 shrink-0">
                          <AvatarImage src={r.avatar} alt={r.customer} />
                          <AvatarFallback className="text-[10px]">{r.customer.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium truncate">{r.customer}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="tabular-nums font-semibold text-destructive">−${r.amount.toFixed(2)}</span>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            onClick={(e) => e.stopPropagation()}
                            className="text-xs text-muted-foreground hover:text-foreground hover:underline"
                          >
                            {r.reason}
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-56">
                          <DropdownMenuLabel className="text-xs">Refund reason</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-xs">{r.reason}</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-xs" onClick={() => toast.message(`Editing reason for ${r.id}`)}>Edit reason</DropdownMenuItem>
                          <DropdownMenuItem className="text-xs" onClick={() => toast.success(`Reason tagged as 'quality' for ${r.id}`)}>Tag as quality issue</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={statusToneMap[r.status]} dot className="capitalize">{r.status}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground font-mono hidden lg:table-cell">{r.requested}</td>
                    <td className="px-4 py-3 hidden xl:table-cell">
                      <span className={cn("text-xs", r.processedBy === "—" ? "text-muted-foreground italic" : "text-foreground")}>
                        {r.processedBy}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-44">
                          <DropdownMenuLabel className="text-xs font-mono">{r.id}</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening refund ${r.id} detail`)}>
                            <Eye className="h-3.5 w-3.5" /> View details
                          </DropdownMenuItem>
                          {r.status === "pending" && (
                            <>
                              <DropdownMenuItem className="text-xs gap-2 text-[color:var(--success)] focus:text-[color:var(--success)]" onClick={() => toast.success(`Approved ${r.id}`)}>
                                <Check className="h-3.5 w-3.5" /> Approve
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`Rejected ${r.id}`)}>
                                <X className="h-3.5 w-3.5" /> Reject
                              </DropdownMenuItem>
                            </>
                          )}
                          {(r.status === "approved" || r.status === "processing") && (
                            <DropdownMenuItem className="text-xs gap-2 text-[color:var(--success)] focus:text-[color:var(--success)]" onClick={() => toast.success(`Marked ${r.id} as completed`)}>
                              <Check className="h-3.5 w-3.5" /> Mark completed
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={9} className="text-center text-sm text-muted-foreground py-12">
                      No refunds match this filter.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
