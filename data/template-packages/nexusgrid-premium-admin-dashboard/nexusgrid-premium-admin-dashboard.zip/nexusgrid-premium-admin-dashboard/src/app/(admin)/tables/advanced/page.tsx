"use client";

import * as React from "react";
import {
  Table2,
  MoreHorizontal,
  Mail,
  Eye,
  Phone,
  Building2,
  Briefcase,
  CalendarDays,
  DollarSign,
  UserPlus,
  CheckCircle2,
  Trash2,
  Download,
  Tag,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";

type EmployeeStatus = "active" | "on_leave" | "remote" | "inactive";
type EmployeeType = "full_time" | "contractor" | "intern" | "part_time";

type Employee = {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: string;
  department: "Engineering" | "Design" | "Product" | "Sales" | "Marketing" | "Operations" | "Finance" | "People";
  type: EmployeeType;
  salary: number;
  joinDate: string;
  status: EmployeeStatus;
  phone: string;
};

const employees: Employee[] = [
  { id: "EMP-2401", name: "Sarah Chen", email: "sarah.chen@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", role: "Staff Engineer", department: "Engineering", type: "full_time", salary: 198000, joinDate: "2021-03-15", status: "active", phone: "+1 415-555-0184" },
  { id: "EMP-2402", name: "Marcus Reyes", email: "marcus.reyes@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "Senior Product Designer", department: "Design", type: "full_time", salary: 164000, joinDate: "2020-07-22", status: "remote", phone: "+1 415-555-0112" },
  { id: "EMP-2403", name: "Elena Petrov", email: "elena.petrov@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", role: "Engineering Manager", department: "Engineering", type: "full_time", salary: 215000, joinDate: "2019-01-08", status: "active", phone: "+1 415-555-0145" },
  { id: "EMP-2404", name: "James Okoro", email: "james.okoro@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "Data Scientist", department: "Operations", type: "full_time", salary: 152000, joinDate: "2022-09-12", status: "on_leave", phone: "+1 415-555-0177" },
  { id: "EMP-2405", name: "Aiko Tanaka", email: "aiko.tanaka@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", role: "Frontend Engineer", department: "Engineering", type: "full_time", salary: 138000, joinDate: "2023-02-20", status: "remote", phone: "+1 415-555-0192" },
  { id: "EMP-2406", name: "David Kim", email: "david.kim@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "Backend Engineer", department: "Engineering", type: "contractor", salary: 142000, joinDate: "2022-11-04", status: "active", phone: "+1 415-555-0133" },
  { id: "EMP-2407", name: "Lena Hoffmann", email: "lena.hoffmann@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", role: "UX Researcher", department: "Design", type: "full_time", salary: 128000, joinDate: "2023-06-19", status: "active", phone: "+1 415-555-0156" },
  { id: "EMP-2408", name: "Raj Patel", email: "raj.patel@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", role: "Product Manager", department: "Product", type: "full_time", salary: 174000, joinDate: "2020-04-30", status: "active", phone: "+1 415-555-0188" },
  { id: "EMP-2409", name: "Mei Lin", email: "mei.lin@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", role: "Growth Marketer", department: "Marketing", type: "full_time", salary: 118000, joinDate: "2023-08-11", status: "remote", phone: "+1 415-555-0167" },
  { id: "EMP-2410", name: "Carlos Mendez", email: "carlos.mendez@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "Account Executive", department: "Sales", type: "full_time", salary: 124000, joinDate: "2021-10-17", status: "active", phone: "+1 415-555-0123" },
  { id: "EMP-2411", name: "Priya Sharma", email: "priya.sharma@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", role: "Sales Director", department: "Sales", type: "full_time", salary: 208000, joinDate: "2018-05-14", status: "active", phone: "+1 415-555-0144" },
  { id: "EMP-2412", name: "Noah Williams", email: "noah.williams@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "DevOps Engineer", department: "Engineering", type: "full_time", salary: 156000, joinDate: "2022-03-08", status: "on_leave", phone: "+1 415-555-0199" },
  { id: "EMP-2413", name: "Sofia Rossi", email: "sofia.rossi@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", role: "Brand Designer", department: "Design", type: "full_time", salary: 122000, joinDate: "2023-04-25", status: "remote", phone: "+1 415-555-0166" },
  { id: "EMP-2414", name: "Ahmed Hassan", email: "ahmed.hassan@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", role: "Security Engineer", department: "Engineering", type: "full_time", salary: 168000, joinDate: "2021-12-02", status: "active", phone: "+1 415-555-0177" },
  { id: "EMP-2415", name: "Yuki Sato", email: "yuki.sato@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", role: "iOS Engineer", department: "Engineering", type: "full_time", salary: 144000, joinDate: "2022-08-29", status: "active", phone: "+1 415-555-0185" },
  { id: "EMP-2416", name: "Olivia Bennett", email: "olivia.bennett@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", role: "Senior PM", department: "Product", type: "full_time", salary: 186000, joinDate: "2020-02-18", status: "active", phone: "+1 415-555-0122" },
  { id: "EMP-2417", name: "Lucas Moreau", email: "lucas.moreau@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "Solutions Architect", department: "Engineering", type: "contractor", salary: 178000, joinDate: "2021-07-13", status: "remote", phone: "+1 415-555-0149" },
  { id: "EMP-2418", name: "Isabella Costa", email: "isabella.costa@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", role: "Content Strategist", department: "Marketing", type: "full_time", salary: 108000, joinDate: "2023-09-05", status: "active", phone: "+1 415-555-0163" },
  { id: "EMP-2419", name: "Ethan Wright", email: "ethan.wright@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "QA Engineer", department: "Engineering", type: "full_time", salary: 112000, joinDate: "2022-05-23", status: "inactive", phone: "+1 415-555-0118" },
  { id: "EMP-2420", name: "Charlotte Klein", email: "charlotte.klein@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", role: "Senior Accountant", department: "Finance", type: "full_time", salary: 134000, joinDate: "2019-11-19", status: "active", phone: "+1 415-555-0157" },
  { id: "EMP-2421", name: "Daniel Foster", email: "daniel.foster@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", role: "Customer Success Mgr", department: "Operations", type: "full_time", salary: 116000, joinDate: "2022-01-31", status: "active", phone: "+1 415-555-0141" },
  { id: "EMP-2422", name: "Amara Okafor", email: "amara.okafor@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", role: "People Ops Lead", department: "People", type: "full_time", salary: 142000, joinDate: "2021-04-26", status: "active", phone: "+1 415-555-0188" },
  { id: "EMP-2423", name: "Hiroshi Yamada", email: "hiroshi.yamada@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "Android Engineer", department: "Engineering", type: "full_time", salary: 146000, joinDate: "2022-10-14", status: "remote", phone: "+1 415-555-0172" },
  { id: "EMP-2424", name: "Grace Liu", email: "grace.liu@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", role: "Product Marketing Mgr", department: "Marketing", type: "full_time", salary: 138000, joinDate: "2021-08-09", status: "active", phone: "+1 415-555-0153" },
  { id: "EMP-2425", name: "Theo Bergmann", email: "theo.bergmann@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "ML Engineer Intern", department: "Engineering", type: "intern", salary: 68000, joinDate: "2024-06-03", status: "active", phone: "+1 415-555-0196" },
  { id: "EMP-2426", name: "Zara Ahmed", email: "zara.ahmed@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", role: "Junior Designer", department: "Design", type: "part_time", salary: 74000, joinDate: "2024-01-15", status: "remote", phone: "+1 415-555-0119" },
  { id: "EMP-2427", name: "Diego Santos", email: "diego.santos@nexusgrid.io", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "Field Sales Rep", department: "Sales", type: "full_time", salary: 96000, joinDate: "2022-07-21", status: "inactive", phone: "+1 415-555-0137" },
];

const statusToneMap: Record<EmployeeStatus, "success" | "info" | "primary" | "warning" | "neutral"> = {
  active: "success",
  remote: "primary",
  on_leave: "warning",
  inactive: "neutral",
};
const statusLabelMap: Record<EmployeeStatus, string> = {
  active: "Active",
  remote: "Remote",
  on_leave: "On Leave",
  inactive: "Inactive",
};
const typeToneMap: Record<EmployeeType, "primary" | "info" | "warning" | "neutral"> = {
  full_time: "primary",
  contractor: "info",
  intern: "warning",
  part_time: "neutral",
};
const typeLabelMap: Record<EmployeeType, string> = {
  full_time: "Full-time",
  contractor: "Contractor",
  intern: "Intern",
  part_time: "Part-time",
};

const MAX_SALARY = 220000;

const deptColors: Record<Employee["department"], string> = {
  Engineering: "var(--primary)",
  Design: "violet",
  Product: "var(--info)",
  Sales: "var(--success)",
  Marketing: "var(--warning)",
  Operations: "var(--info)",
  Finance: "var(--success)",
  People: "var(--primary)",
};

function initials(name: string) {
  return name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}

export default function AdvancedTablesPage() {
  const columns: Column<Employee>[] = React.useMemo(() => [
    {
      key: "employee",
      header: "Employee",
      sortable: true,
      sortAccessor: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <Avatar className="h-8 w-8">
            <AvatarImage src={r.avatar} alt={r.name} />
            <AvatarFallback className="text-[11px] font-medium">{initials(r.name)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="font-medium text-foreground text-sm truncate">{r.name}</p>
            <p className="text-xs text-muted-foreground truncate">{r.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: "role",
      header: "Role",
      sortable: true,
      sortAccessor: (r) => r.role,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <Briefcase className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-sm text-foreground">{r.role}</span>
        </div>
      ),
      width: "w-44",
    },
    {
      key: "department",
      header: "Department",
      sortable: true,
      sortAccessor: (r) => r.department,
      filterable: true,
      filterAccessor: (r) => r.department,
      filterOptions: [
        { label: "Engineering", value: "Engineering" },
        { label: "Design", value: "Design" },
        { label: "Product", value: "Product" },
        { label: "Sales", value: "Sales" },
        { label: "Marketing", value: "Marketing" },
        { label: "Operations", value: "Operations" },
        { label: "Finance", value: "Finance" },
        { label: "People", value: "People" },
      ],
      cell: (r) => (
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset"
          style={{
            backgroundColor: `color-mix(in srgb, ${deptColors[r.department]} 10%, transparent)`,
            color: deptColors[r.department],
            borderColor: `color-mix(in srgb, ${deptColors[r.department]} 25%, transparent)`,
          }}
        >
          <Building2 className="h-3 w-3" />
          {r.department}
        </span>
      ),
      width: "w-40",
    },
    {
      key: "type",
      header: "Type",
      sortable: true,
      sortAccessor: (r) => r.type,
      filterable: true,
      filterAccessor: (r) => r.type,
      filterOptions: [
        { label: "Full-time", value: "full_time" },
        { label: "Contractor", value: "contractor" },
        { label: "Intern", value: "intern" },
        { label: "Part-time", value: "part_time" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={typeToneMap[r.type]}>{typeLabelMap[r.type]}</StatusBadge>
      ),
      width: "w-32",
    },
    {
      key: "salary",
      header: "Salary",
      sortable: true,
      sortAccessor: (r) => r.salary,
      align: "right",
      cell: (r) => {
        const pct = Math.min(100, (r.salary / MAX_SALARY) * 100);
        return (
          <div className="flex flex-col items-end gap-1">
            <span className="tabular-nums font-medium text-sm">${r.salary.toLocaleString()}</span>
            <div className="h-1 w-20 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        );
      },
      width: "w-32",
    },
    {
      key: "joinDate",
      header: "Joined",
      sortable: true,
      sortAccessor: (r) => r.joinDate,
      cell: (r) => (
        <span className="font-mono text-xs text-muted-foreground">{r.joinDate}</span>
      ),
      width: "w-28",
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Active", value: "active" },
        { label: "Remote", value: "remote" },
        { label: "On Leave", value: "on_leave" },
        { label: "Inactive", value: "inactive" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={statusToneMap[r.status]} dot>{statusLabelMap[r.status]}</StatusBadge>
      ),
      width: "w-32",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div onClick={(e) => e.stopPropagation()}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="text-xs font-mono">{r.id}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening profile for ${r.name}`)}>
                <Eye className="h-3.5 w-3.5" /> View profile
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Email composed to ${r.email}`)}>
                <Mail className="h-3.5 w-3.5" /> Send email
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Call initiated to ${r.phone}`)}>
                <Phone className="h-3.5 w-3.5" /> Call {r.phone}
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Calendar opened for ${r.name}`)}>
                <CalendarDays className="h-3.5 w-3.5" /> Schedule 1:1
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`Deactivated ${r.name}`)}>
                <Trash2 className="h-3.5 w-3.5" /> Deactivate
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      width: "w-16",
    },
  ], []);

  return (
    <>
      <PageHeader
        title="Advanced Tables"
        description="The full DataTable component with sorting, filtering, pagination, selection, bulk actions, column visibility, density toggle, and CSV/JSON export — all enabled at once."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Advanced Tables" }]}
        icon={Table2}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("New employee onboarding flow opened")}>
            <UserPlus className="h-3.5 w-3.5" /> Add Employee
          </Button>
        }
      />

      {/* Feature chip strip — unique visual element */}
      <Card className="mb-6">
        <CardContent className="pt-5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide mr-1">Enabled features:</span>
            {[
              { label: "Search", icon: Eye },
              { label: "Multi-sort", icon: Briefcase },
              { label: "Status filter", icon: CheckCircle2 },
              { label: "Type filter", icon: Tag },
              { label: "Pagination 10/25/50", icon: CalendarDays },
              { label: "Row selection", icon: CheckCircle2 },
              { label: "Bulk actions", icon: Trash2 },
              { label: "Column visibility", icon: Building2 },
              { label: "Density toggle", icon: Briefcase },
              { label: "CSV / JSON export", icon: Download },
            ].map((f) => (
              <span key={f.label} className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary ring-1 ring-primary/15">
                <f.icon className="h-3 w-3" />
                {f.label}
              </span>
            ))}
            <span className="ml-auto text-xs text-muted-foreground inline-flex items-center gap-1.5">
              <DollarSign className="h-3.5 w-3.5" />
              Total payroll: <span className="font-semibold text-foreground tabular-nums">${(employees.reduce((s, e) => s + e.salary, 0) / 1_000_000).toFixed(2)}M</span>
              <span className="text-muted-foreground/60">·</span>
              {employees.length} employees
            </span>
          </div>
        </CardContent>
      </Card>

      <DataTable
        title="Employee Directory"
        data={employees}
        columns={columns}
        searchKeys={["id", "name", "email", "role"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening profile for ${r.name}`)}
        enableSelection
        enableExport
        enableDensity
        enableColumnVisibility
        pageSize={10}
        initialSort={{ key: "joinDate", direction: "asc" }}
        bulkActions={[
          {
            label: "Activate",
            icon: CheckCircle2,
            onClick: (sel) => toast.success(`Activated ${sel.length} employee${sel.length > 1 ? "s" : ""}`),
          },
          {
            label: "Tag",
            icon: Tag,
            onClick: (sel) => toast.message(`Tagging ${sel.length} employees…`),
          },
          {
            label: "Export",
            icon: Download,
            onClick: (sel) => toast.success(`Exported ${sel.length} employee${sel.length > 1 ? "s" : ""} as CSV`),
          },
          {
            label: "Deactivate",
            icon: Trash2,
            onClick: (sel) => toast.error(`Deactivated ${sel.length} employee${sel.length > 1 ? "s" : ""}`),
          },
        ]}
        toolbarActions={
          <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={() => toast.success("Export started — 27 records")}>
            <Download className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Export All</span>
          </Button>
        }
      />

      {/* Renderer showcase panel — unique visual element */}
      <Card className="mt-6">
        <CardContent className="pt-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-lg border border-border p-3 bg-muted/20">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Avatar + Name cell</p>
              <div className="flex items-center gap-2.5">
                <Avatar className="h-9 w-9">
                  <AvatarImage src={employees[0].avatar} alt={employees[0].name} />
                  <AvatarFallback className="text-xs">{initials(employees[0].name)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-sm">{employees[0].name}</p>
                  <p className="text-xs text-muted-foreground">{employees[0].email}</p>
                </div>
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/20">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Salary bar cell</p>
              <div className="flex flex-col items-end gap-1.5">
                <span className="tabular-nums font-medium text-sm">${employees[2].salary.toLocaleString()}</span>
                <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full bg-primary" style={{ width: `${(employees[2].salary / MAX_SALARY) * 100}%` }} />
                </div>
                <span className="text-[10px] text-muted-foreground">98% of band max</span>
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/20">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Status badge cell</p>
              <div className="flex flex-wrap gap-1.5">
                {(["active", "remote", "on_leave", "inactive"] as EmployeeStatus[]).map((s) => (
                  <StatusBadge key={s} tone={statusToneMap[s]} dot>{statusLabelMap[s]}</StatusBadge>
                ))}
              </div>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            The grid above shows three of the custom cell renderers used in this DataTable. Each cell type is fully sortable, filterable, and survives CSV/JSON export.
          </p>
        </CardContent>
      </Card>
    </>
  );
}
