"use client";

import * as React from "react";
import {
  Settings2,
  Shield,
  Bell,
  CreditCard,
  Plug,
  CheckCircle2,
  AlertTriangle,
  Save,
  RotateCcw,
  User,
  Globe,
  Clock,
  Type,
  Lock,
  Smartphone,
  Key,
  Mail,
  MessageSquare,
  Zap,
  Calendar,
  Crown,
  Receipt,
  Eye,
  EyeOff,
  Cloud,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Settings = {
  fullName: string;
  email: string;
  username: string;
  bio: string;
  timezone: string;
  language: string;
  dateFormat: string;
  currentPassword: string;
  newPassword: string;
  twoFactor: boolean;
  loginAlerts: boolean;
  sessionTimeout: string;
  emailMentions: boolean;
  emailComments: boolean;
  emailTasks: boolean;
  emailWeekly: boolean;
  pushMentions: boolean;
  pushDeadlines: boolean;
  pushDeploys: boolean;
  digestFreq: string;
  cardBrand: string;
  cardLast4: string;
  cardExpiry: string;
  billingEmail: string;
  autoRenew: boolean;
  taxId: string;
  slackConnected: boolean;
  githubConnected: boolean;
  stripeConnected: boolean;
  hubspotConnected: boolean;
};

const DEFAULTS: Settings = {
  fullName: "Amara Okafor",
  email: "amara.okafor@nexusgrid.io",
  username: "amara.o",
  bio: "Principal Product Engineer on the Platform Infrastructure team. Building the compute fabric that powers NexusGrid.",
  timezone: "UTC-08:00 Pacific",
  language: "English (US)",
  dateFormat: "MMM d, yyyy",
  currentPassword: "",
  newPassword: "",
  twoFactor: true,
  loginAlerts: true,
  sessionTimeout: "30 days",
  emailMentions: true,
  emailComments: true,
  emailTasks: false,
  emailWeekly: true,
  pushMentions: true,
  pushDeadlines: true,
  pushDeploys: false,
  digestFreq: "daily",
  cardBrand: "Visa",
  cardLast4: "4242",
  cardExpiry: "08/27",
  billingEmail: "billing@nexusgrid.io",
  autoRenew: true,
  taxId: "84-2910037",
  slackConnected: true,
  githubConnected: true,
  stripeConnected: true,
  hubspotConnected: false,
};

const TABS = [
  { v: "general", label: "General", icon: Settings2 },
  { v: "security", label: "Security", icon: Shield },
  { v: "notifications", label: "Notifications", icon: Bell },
  { v: "billing", label: "Billing", icon: CreditCard },
  { v: "integrations", label: "Integrations", icon: Plug },
];

function Row({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium">{title}</p>
        {desc && <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

export default function AccountSettingsPage() {
  const [tab, setTab] = React.useState("general");
  const [settings, setSettings] = React.useState<Settings>(DEFAULTS);
  const [saved, setSaved] = React.useState<Settings>(DEFAULTS);
  const [saving, setSaving] = React.useState(false);
  const [showNew, setShowNew] = React.useState(false);

  const set = <K extends keyof Settings>(k: K, v: Settings[K]) =>
    setSettings((s) => ({ ...s, [k]: v }));

  const isDirty = JSON.stringify(settings) !== JSON.stringify(saved);
  const dirtyKeys = Object.keys(settings).filter(
    (k) => (settings as Record<string, unknown>)[k] !== (saved as Record<string, unknown>)[k]
  );

  const save = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSaved(settings);
      toast.success("Settings saved", { description: "Your account preferences have been updated." });
    }, 850);
  };

  const reset = () => {
    setSettings(saved);
    toast.message("Reverted to last saved state");
  };

  return (
    <>
      <PageHeader
        title="Account Settings"
        description="Manage your profile, security, notifications, billing, and integrations."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Account" }, { label: "Settings" }]}
        icon={Settings2}
        actions={
          <div className="flex items-center gap-2">
            {isDirty ? (
              <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/40 text-amber-600 bg-amber-500/5">
                <AlertTriangle className="h-3 w-3" /> {dirtyKeys.length} unsaved change{dirtyKeys.length > 1 ? "s" : ""}
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[10px] gap-1 border-emerald-500/40 text-emerald-600 bg-emerald-500/5">
                <CheckCircle2 className="h-3 w-3" /> All changes saved
              </Badge>
            )}
          </div>
        }
      />

      <Tabs value={tab} onValueChange={setTab} className="grid lg:grid-cols-[220px_1fr] gap-6">
        {/* SIDEBAR TABS */}
        <div className="lg:sticky lg:top-4 lg:self-start space-y-3">
          <Card className="p-2">
            <TabsList className="grid grid-cols-5 lg:grid-cols-1 gap-1 h-auto bg-transparent p-0">
              {TABS.map((t) => (
                <TabsTrigger
                  key={t.v}
                  value={t.v}
                  className="justify-start gap-2 px-3 py-2 text-xs data-[state=active]:bg-accent data-[state=active]:shadow-none rounded-md"
                >
                  <t.icon className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline lg:inline">{t.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </Card>
          <Card className="p-4 bg-primary/[0.03] border-primary/20">
            <div className="flex items-center gap-2 text-primary mb-1.5">
              <Crown className="h-4 w-4" />
              <p className="text-xs font-semibold uppercase tracking-wide">Pro plan</p>
            </div>
            <p className="text-xs text-muted-foreground">Renews Aug 14, 2026. Manage your subscription in the Billing tab.</p>
          </Card>
        </div>

        {/* CONTENT + STICKY ACTIONS */}
        <div className="grid gap-6">
          {/* GENERAL */}
          <TabsContent value="general" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <User className="h-4 w-4 text-primary" /> General
                </CardTitle>
                <CardDescription>Your personal information and localisation preferences.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <div className="flex items-center gap-4 pb-2">
                  <Avatar className="h-16 w-16 rounded-xl">
                    <AvatarImage src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=200&q=80&auto=format&fit=crop" alt="Avatar" />
                    <AvatarFallback>AO</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col gap-1.5">
                    <Button variant="outline" size="sm" className="w-fit text-xs">Upload new photo</Button>
                    <p className="text-[11px] text-muted-foreground">JPG or PNG, max 2MB. 256×256 recommended.</p>
                  </div>
                </div>
                <Separator />
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Full name</Label>
                    <Input value={settings.fullName} onChange={(e) => set("fullName", e.target.value)} />
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Username</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground text-sm">@</span>
                      <Input value={settings.username} onChange={(e) => set("username", e.target.value)} />
                    </div>
                  </div>
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-xs flex items-center gap-1.5">
                    <Mail className="h-3.5 w-3.5 text-muted-foreground" /> Email address
                  </Label>
                  <Input type="email" value={settings.email} onChange={(e) => set("email", e.target.value)} />
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-xs">Bio</Label>
                  <Textarea rows={3} value={settings.bio} onChange={(e) => set("bio", e.target.value)} />
                  <p className="text-[11px] text-muted-foreground">{settings.bio.length} / 240 characters</p>
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="grid gap-1.5">
                    <Label className="text-xs flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5 text-muted-foreground" /> Timezone
                    </Label>
                    <Select value={settings.timezone} onValueChange={(v) => set("timezone", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {["UTC", "UTC-08:00 Pacific", "UTC-05:00 Eastern", "UTC+00:00 London", "UTC+01:00 Berlin", "UTC+09:00 Tokyo"].map((t) => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs flex items-center gap-1.5">
                      <Globe className="h-3.5 w-3.5 text-muted-foreground" /> Language
                    </Label>
                    <Select value={settings.language} onValueChange={(v) => set("language", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {["English (US)", "English (UK)", "Deutsch", "Français", "日本語", "中文"].map((t) => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs flex items-center gap-1.5">
                      <Type className="h-3.5 w-3.5 text-muted-foreground" /> Date format
                    </Label>
                    <Select value={settings.dateFormat} onValueChange={(v) => set("dateFormat", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MMM d, yyyy">Jul 1, 2026</SelectItem>
                        <SelectItem value="d MMM yyyy">1 Jul 2026</SelectItem>
                        <SelectItem value="yyyy-MM-dd">2026-07-01</SelectItem>
                        <SelectItem value="MM/dd/yyyy">07/01/2026</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SECURITY */}
          <TabsContent value="security" className="mt-0 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Lock className="h-4 w-4 text-primary" /> Password
                </CardTitle>
                <CardDescription>Use at least 12 characters with a mix of letters, numbers, and symbols.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Current password</Label>
                    <Input type="password" placeholder="••••••••••" />
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">New password</Label>
                    <div className="relative">
                      <Input
                        type={showNew ? "text" : "password"}
                        value={settings.newPassword}
                        onChange={(e) => set("newPassword", e.target.value)}
                        placeholder="Enter new password"
                        className="pr-9"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNew(!showNew)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showNew ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="h-4 w-4 text-primary" /> Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="divide-y divide-border">
                <Row title="Two-factor authentication" desc="Require a 6-digit code from your authenticator app at sign-in.">
                  <Switch checked={settings.twoFactor} onCheckedChange={(v) => set("twoFactor", v)} />
                </Row>
                <Row title="New login alerts" desc="Email me when a new device signs into my account.">
                  <Switch checked={settings.loginAlerts} onCheckedChange={(v) => set("loginAlerts", v)} />
                </Row>
                <Row title="Session timeout" desc="Automatically sign out after a period of inactivity.">
                  <Select value={settings.sessionTimeout} onValueChange={(v) => set("sessionTimeout", v)}>
                    <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["1 hour", "8 hours", "1 day", "7 days", "30 days"].map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Row>
              </CardContent>
            </Card>
          </TabsContent>

          {/* NOTIFICATIONS */}
          <TabsContent value="notifications" className="mt-0 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Mail className="h-4 w-4 text-primary" /> Email notifications
                </CardTitle>
                <CardDescription>Choose what triggers an email to your inbox.</CardDescription>
              </CardHeader>
              <CardContent className="divide-y divide-border">
                <Row title="Mentions" desc="When someone @mentions you in a comment or thread.">
                  <Switch checked={settings.emailMentions} onCheckedChange={(v) => set("emailMentions", v)} />
                </Row>
                <Row title="Comments on my work" desc="Replies to your tasks, PRs, and design files.">
                  <Switch checked={settings.emailComments} onCheckedChange={(v) => set("emailComments", v)} />
                </Row>
                <Row title="Task assignments" desc="Includes reassignments and delegation.">
                  <Switch checked={settings.emailTasks} onCheckedChange={(v) => set("emailTasks", v)} />
                </Row>
                <Row title="Weekly summary" desc="A Monday-morning recap of last week's activity.">
                  <Switch checked={settings.emailWeekly} onCheckedChange={(v) => set("emailWeekly", v)} />
                </Row>
                <div className="pt-3">
                  <Label className="text-xs mb-1.5 block">Email digest frequency</Label>
                  <Select value={settings.digestFreq} onValueChange={(v) => set("digestFreq", v)}>
                    <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["realtime", "hourly", "daily", "weekly"].map((t) => (
                        <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-primary" /> Mobile push
                </CardTitle>
                <CardDescription>Notifications delivered to the NexusGrid mobile app.</CardDescription>
              </CardHeader>
              <CardContent className="divide-y divide-border">
                <Row title="Mentions" desc="@mentions across tasks and threads.">
                  <Switch checked={settings.pushMentions} onCheckedChange={(v) => set("pushMentions", v)} />
                </Row>
                <Row title="Deadline reminders" desc="24 hours before a task is due.">
                  <Switch checked={settings.pushDeadlines} onCheckedChange={(v) => set("pushDeadlines", v)} />
                </Row>
                <Row title="Deployment events" desc="When a deploy starts, succeeds, or fails.">
                  <Switch checked={settings.pushDeploys} onCheckedChange={(v) => set("pushDeploys", v)} />
                </Row>
              </CardContent>
            </Card>
          </TabsContent>

          {/* BILLING */}
          <TabsContent value="billing" className="mt-0 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-primary" /> Payment method
                </CardTitle>
                <CardDescription>The card used for monthly subscription billing.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <div className="flex items-center gap-3 p-3 rounded-lg border border-border bg-muted/30">
                  <div className="grid place-items-center h-10 w-14 rounded-md bg-foreground text-background text-xs font-bold tracking-wide">
                    {settings.cardBrand.toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium font-mono">•••• •••• •••• {settings.cardLast4}</p>
                    <p className="text-xs text-muted-foreground">Expires {settings.cardExpiry}</p>
                  </div>
                  <Button variant="outline" size="sm" className="text-xs">Update</Button>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Billing email</Label>
                    <Input type="email" value={settings.billingEmail} onChange={(e) => set("billingEmail", e.target.value)} />
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Tax ID / VAT</Label>
                    <Input value={settings.taxId} onChange={(e) => set("taxId", e.target.value)} className="font-mono" />
                  </div>
                </div>
                <Row title="Auto-renew subscription" desc="Charge this card automatically on each renewal date.">
                  <Switch checked={settings.autoRenew} onCheckedChange={(v) => set("autoRenew", v)} />
                </Row>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Receipt className="h-4 w-4 text-primary" /> Recent invoices
                  </CardTitle>
                  <CardDescription>The last 3 billing statements.</CardDescription>
                </div>
                <Button variant="ghost" size="sm" className="text-xs">View all</Button>
              </CardHeader>
              <CardContent className="space-y-2">
                {[
                  { num: "INV-2026-0714", date: "Jul 14, 2026", amount: "$249.00", status: "paid" as const },
                  { num: "INV-2026-0614", date: "Jun 14, 2026", amount: "$249.00", status: "paid" as const },
                  { num: "INV-2026-0514", date: "May 14, 2026", amount: "$249.00", status: "paid" as const },
                ].map((inv) => (
                  <div key={inv.num} className="flex items-center justify-between p-2.5 rounded-lg hover:bg-muted/40 transition-colors">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="grid place-items-center h-8 w-8 rounded-md bg-[color:var(--success)]/12 text-[color:var(--success)]">
                        <Calendar className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium font-mono">{inv.num}</p>
                        <p className="text-xs text-muted-foreground">{inv.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <StatusBadge tone="success" dot>{inv.status}</StatusBadge>
                      <span className="text-sm font-medium tabular-nums">{inv.amount}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* INTEGRATIONS */}
          <TabsContent value="integrations" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Plug className="h-4 w-4 text-primary" /> Connected integrations
                </CardTitle>
                <CardDescription>Third-party services linked to your account.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { icon: MessageSquare, name: "Slack", desc: "Channel notifications and slash commands", connected: settings.slackConnected, key: "slackConnected" as const, color: "text-violet-500" },
                  { icon: Key, name: "GitHub", desc: "Sync pull requests, issues, and commits", connected: settings.githubConnected, key: "githubConnected" as const, color: "text-foreground" },
                  { icon: CreditCard, name: "Stripe", desc: "Billing connector for self-serve invoicing", connected: settings.stripeConnected, key: "stripeConnected" as const, color: "text-indigo-500" },
                  { icon: Cloud, name: "HubSpot", desc: "CRM sync and lead enrichment", connected: settings.hubspotConnected, key: "hubspotConnected" as const, color: "text-orange-500" },
                ].map((int) => (
                  <div key={int.name} className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="grid place-items-center h-10 w-10 rounded-lg bg-muted">
                        <int.icon className={cn("h-5 w-5", int.color)} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium">{int.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{int.desc}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {int.connected ? (
                        <>
                          <StatusBadge tone="success" dot>Connected</StatusBadge>
                          <Button variant="outline" size="sm" className="text-xs" onClick={() => set(int.key, false)}>Disconnect</Button>
                        </>
                      ) : (
                        <Button size="sm" className="text-xs gap-1" onClick={() => set(int.key, true)}>
                          <Zap className="h-3 w-3" /> Connect
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* STICKY SAVE BAR */}
          <div className="sticky bottom-4 z-10">
            <Card className={cn(
              "px-4 py-3 flex items-center justify-between gap-3 transition-all",
              isDirty ? "border-primary/40 bg-card/95 backdrop-blur shadow-premium-md" : "opacity-60"
            )}>
              <div className="flex items-center gap-2 min-w-0">
                {isDirty ? (
                  <>
                    <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" />
                    <span className="text-sm text-muted-foreground truncate">
                      You have <span className="text-foreground font-medium">{dirtyKeys.length}</span> unsaved change{dirtyKeys.length > 1 ? "s" : ""}.
                    </span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                    <span className="text-sm text-muted-foreground">All changes saved.</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Button variant="outline" size="sm" className="gap-1.5" disabled={!isDirty || saving} onClick={reset}>
                  <RotateCcw className="h-3.5 w-3.5" /> Reset
                </Button>
                <Button size="sm" className="gap-1.5" disabled={!isDirty || saving} onClick={save}>
                  {saving ? <RotateCcw className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                  {saving ? "Saving…" : "Save changes"}
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </Tabs>
    </>
  );
}
