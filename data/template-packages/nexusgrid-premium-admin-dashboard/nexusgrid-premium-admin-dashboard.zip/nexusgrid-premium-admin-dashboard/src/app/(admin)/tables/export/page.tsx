"use client";

import * as React from "react";
import {
  Download,
  FileText,
  FileSpreadsheet,
  FileJson,
  FileCode2,
  FileDown,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  History,
  X,
  Check,
  ChevronDown,
  Package,
  AlertCircle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type StockStatus = "in_stock" | "low_stock" | "out_of_stock" | "discontinued";
type Warehouse = "Oakland" | "Newark" | "Dallas" | "Atlanta" | "Portland";

type InventoryItem = {
  id: string;
  sku: string;
  name: string;
  category: "Audio" | "Peripherals" | "Cameras" | "Lighting" | "Furniture" | "Wearables";
  quantity: number;
  reorderPoint: number;
  unitCost: number;
  unitPrice: number;
  warehouse: Warehouse;
  status: StockStatus;
  lastRestock: string;
};

const inventory: InventoryItem[] = [
  { id: "INV-2001", sku: "NX-1001", name: "Aurora Mechanical Keyboard", category: "Peripherals", quantity: 142, reorderPoint: 50, unitCost: 84.0, unitPrice: 189.0, warehouse: "Oakland", status: "in_stock", lastRestock: "2026-07-08" },
  { id: "INV-2002", sku: "NX-1002", name: "Lumen 4K Webcam", category: "Cameras", quantity: 88, reorderPoint: 40, unitCost: 58.0, unitPrice: 129.5, warehouse: "Newark", status: "in_stock", lastRestock: "2026-07-06" },
  { id: "INV-2003", sku: "NX-1003", name: "Pulse Wireless Mouse", category: "Peripherals", quantity: 312, reorderPoint: 100, unitCost: 22.0, unitPrice: 64.99, warehouse: "Dallas", status: "in_stock", lastRestock: "2026-07-12" },
  { id: "INV-2004", sku: "NX-1004", name: "Cadence Studio Headphones", category: "Audio", quantity: 38, reorderPoint: 50, unitCost: 112.0, unitPrice: 249.0, warehouse: "Oakland", status: "low_stock", lastRestock: "2026-07-02" },
  { id: "INV-2005", sku: "NX-1005", name: "Beacon Smart Lamp", category: "Lighting", quantity: 207, reorderPoint: 60, unitCost: 38.0, unitPrice: 89.0, warehouse: "Atlanta", status: "in_stock", lastRestock: "2026-07-10" },
  { id: "INV-2006", sku: "NX-1006", name: "Halo USB-C Hub", category: "Peripherals", quantity: 174, reorderPoint: 80, unitCost: 28.0, unitPrice: 79.99, warehouse: "Portland", status: "in_stock", lastRestock: "2026-07-11" },
  { id: "INV-2007", sku: "NX-1007", name: "Echo Standing Desk", category: "Furniture", quantity: 0, reorderPoint: 15, unitCost: 312.0, unitPrice: 549.0, warehouse: "Dallas", status: "out_of_stock", lastRestock: "2026-06-22" },
  { id: "INV-2008", sku: "NX-1008", name: "Vega Wireless Earbuds", category: "Audio", quantity: 0, reorderPoint: 0, unitCost: 76.0, unitPrice: 179.0, warehouse: "Oakland", status: "discontinued", lastRestock: "2026-05-15" },
  { id: "INV-2009", sku: "NX-1009", name: "Lumen Stream Mic", category: "Audio", quantity: 98, reorderPoint: 40, unitCost: 64.0, unitPrice: 149.0, warehouse: "Newark", status: "in_stock", lastRestock: "2026-07-09" },
  { id: "INV-2010", sku: "NX-1010", name: "Pulse Fitness Band", category: "Wearables", quantity: 28, reorderPoint: 50, unitCost: 42.0, unitPrice: 99.0, warehouse: "Atlanta", status: "low_stock", lastRestock: "2026-07-01" },
  { id: "INV-2011", sku: "NX-1011", name: "Beacon Floor Lamp", category: "Lighting", quantity: 64, reorderPoint: 30, unitCost: 88.0, unitPrice: 219.0, warehouse: "Portland", status: "in_stock", lastRestock: "2026-07-05" },
  { id: "INV-2012", sku: "NX-1012", name: "Aurora Lite Keyboard", category: "Peripherals", quantity: 12, reorderPoint: 40, unitCost: 64.0, unitPrice: 139.0, warehouse: "Dallas", status: "low_stock", lastRestock: "2026-06-28" },
  { id: "INV-2013", sku: "NX-1013", name: "Pulse Pro Mouse", category: "Peripherals", quantity: 224, reorderPoint: 80, unitCost: 38.0, unitPrice: 109.0, warehouse: "Oakland", status: "in_stock", lastRestock: "2026-07-12" },
  { id: "INV-2014", sku: "NX-1014", name: "Cadence Earbuds Pro", category: "Audio", quantity: 156, reorderPoint: 60, unitCost: 92.0, unitPrice: 219.0, warehouse: "Newark", status: "in_stock", lastRestock: "2026-07-07" },
  { id: "INV-2015", sku: "NX-1015", name: "Vega Smartwatch", category: "Wearables", quantity: 0, reorderPoint: 25, unitCost: 184.0, unitPrice: 399.0, warehouse: "Atlanta", status: "out_of_stock", lastRestock: "2026-06-18" },
];

const statusToneMap: Record<StockStatus, "success" | "warning" | "danger" | "neutral"> = {
  in_stock: "success",
  low_stock: "warning",
  out_of_stock: "danger",
  discontinued: "neutral",
};
const statusLabelMap: Record<StockStatus, string> = {
  in_stock: "In Stock",
  low_stock: "Low Stock",
  out_of_stock: "Out of Stock",
  discontinued: "Discontinued",
};

type ExportFormat = "csv" | "json" | "xlsx" | "pdf";

type ExportHistoryEntry = {
  id: string;
  filename: string;
  format: ExportFormat;
  rows: number;
  columns: number;
  timestamp: string;
  user: string;
  size: string;
  scope: "all" | "filtered" | "selected";
};

const initialHistory: ExportHistoryEntry[] = [
  { id: "EXP-9842", filename: "inventory-full-2026-07-14.csv", format: "csv", rows: 15, columns: 10, timestamp: "2026-07-14 10:42:18", user: "sarah.c", size: "4.2 KB", scope: "all" },
  { id: "EXP-9841", filename: "low-stock-alert-2026-07-14.xlsx", format: "xlsx", rows: 4, columns: 7, timestamp: "2026-07-14 09:18:04", user: "marcus.r", size: "18.4 KB", scope: "filtered" },
  { id: "EXP-9840", filename: "audit-trail-q2.json", format: "json", rows: 12, columns: 10, timestamp: "2026-07-13 16:31:55", user: "elena.p", size: "9.8 KB", scope: "all" },
  { id: "EXP-9839", filename: "warehouse-oakland-2026-07-13.pdf", format: "pdf", rows: 6, columns: 6, timestamp: "2026-07-13 11:24:30", user: "james.o", size: "42.1 KB", scope: "filtered" },
  { id: "EXP-9838", filename: "selected-reorder-2026-07-12.csv", format: "csv", rows: 3, columns: 10, timestamp: "2026-07-12 14:11:46", user: "aiko.t", size: "1.1 KB", scope: "selected" },
];

const allColumns = [
  { key: "id", label: "Inventory ID" },
  { key: "sku", label: "SKU" },
  { key: "name", label: "Product Name" },
  { key: "category", label: "Category" },
  { key: "quantity", label: "Quantity" },
  { key: "reorderPoint", label: "Reorder Point" },
  { key: "unitCost", label: "Unit Cost" },
  { key: "unitPrice", label: "Unit Price" },
  { key: "warehouse", label: "Warehouse" },
  { key: "status", label: "Status" },
  { key: "lastRestock", label: "Last Restock" },
] as const;

const formatMeta: Record<ExportFormat, { label: string; icon: typeof FileText; tone: "primary" | "info" | "success" | "violet"; size?: string }> = {
  csv: { label: "CSV", icon: FileCode2, tone: "primary" },
  json: { label: "JSON", icon: FileJson, tone: "info" },
  xlsx: { label: "Excel (XLSX)", icon: FileSpreadsheet, tone: "success" },
  pdf: { label: "PDF", icon: FileText, tone: "violet" },
};

export default function ExportTablePage() {
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState<StockStatus | "">("");
  const [warehouseFilter, setWarehouseFilter] = React.useState<Warehouse | "">("");
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [history, setHistory] = React.useState<ExportHistoryEntry[]>(initialHistory);
  const [exportDialogOpen, setExportDialogOpen] = React.useState(false);
  const [pendingFormat, setPendingFormat] = React.useState<ExportFormat>("csv");
  const [pendingScope, setPendingScope] = React.useState<"all" | "filtered" | "selected">("all");
  const [selectedColumns, setSelectedColumns] = React.useState<Set<string>>(new Set(allColumns.map((c) => c.key)));
  const [exporting, setExporting] = React.useState(false);

  const filtered = React.useMemo(() => {
    let result = [...inventory];
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((i) => i.name.toLowerCase().includes(q) || i.sku.toLowerCase().includes(q) || i.id.toLowerCase().includes(q));
    }
    if (statusFilter) result = result.filter((i) => i.status === statusFilter);
    if (warehouseFilter) result = result.filter((i) => i.warehouse === warehouseFilter);
    return result;
  }, [search, statusFilter, warehouseFilter]);

  const visibleIds = filtered.map((i) => i.id);
  const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selected.has(id));
  const someVisibleSelected = visibleIds.some((id) => selected.has(id));

  const toggleOne = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const toggleAllVisible = () => {
    setSelected((prev) => {
      if (allVisibleSelected) {
        const next = new Set(prev);
        visibleIds.forEach((id) => next.delete(id));
        return next;
      }
      const next = new Set(prev);
      visibleIds.forEach((id) => next.add(id));
      return next;
    });
  };
  const toggleColumn = (key: string) => {
    setSelectedColumns((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const openExportDialog = (format: ExportFormat) => {
    setPendingFormat(format);
    setPendingScope(selected.size > 0 ? "selected" : "filtered");
    setExportDialogOpen(true);
  };

  const runExport = () => {
    if (selectedColumns.size === 0) {
      toast.error("Select at least one column to export");
      return;
    }
    let rows: InventoryItem[] = [];
    if (pendingScope === "all") rows = inventory;
    else if (pendingScope === "filtered") rows = filtered;
    else rows = inventory.filter((i) => selected.has(i.id));

    if (rows.length === 0) {
      toast.error("No rows match the current export scope");
      return;
    }

    setExporting(true);
    setTimeout(() => {
      // Actually trigger a CSV/JSON download
      if (pendingFormat === "csv" || pendingFormat === "xlsx") {
        const cols = allColumns.filter((c) => selectedColumns.has(c.key));
        const header = cols.map((c) => c.label).join(",");
        const dataRows = rows.map((r) =>
          cols.map((c) => {
            const v = r[c.key as keyof InventoryItem];
            return `"${String(v).replace(/"/g, '""')}"`;
          }).join(",")
        );
        const blob = new Blob([[header, ...dataRows].join("\n")], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `inventory-${pendingScope}-${Date.now()}.csv`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (pendingFormat === "json") {
        const cols = allColumns.filter((c) => selectedColumns.has(c.key));
        const slim = rows.map((r) => {
          const o: Record<string, unknown> = {};
          cols.forEach((c) => (o[c.key] = r[c.key as keyof InventoryItem]));
          return o;
        });
        const blob = new Blob([JSON.stringify(slim, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `inventory-${pendingScope}-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
      }

      const newEntry: ExportHistoryEntry = {
        id: `EXP-${Math.floor(9843 + Math.random() * 100)}`,
        filename: `inventory-${pendingScope}-${new Date().toISOString().slice(0, 10)}.${pendingFormat === "xlsx" ? "xlsx" : pendingFormat}`,
        format: pendingFormat,
        rows: rows.length,
        columns: selectedColumns.size,
        timestamp: new Date().toLocaleString("en-US", { hour12: false }).replace(",", ""),
        user: "you",
        size: pendingFormat === "pdf" ? "—" : `${(rows.length * 0.4 + 0.8).toFixed(1)} KB`,
        scope: pendingScope,
      };
      setHistory((prev) => [newEntry, ...prev].slice(0, 5));
      setExporting(false);
      setExportDialogOpen(false);
      toast.success(`Exported ${rows.length} rows as ${formatMeta[pendingFormat].label}`, {
        description: `${newEntry.filename} · ${selectedColumns.size} columns`,
      });
      if (pendingScope === "selected") setSelected(new Set());
    }, 750);
  };

  const stats = {
    total: inventory.length,
    inStock: inventory.filter((i) => i.status === "in_stock").length,
    low: inventory.filter((i) => i.status === "low_stock").length,
    outOrDisco: inventory.filter((i) => i.status === "out_of_stock" || i.status === "discontinued").length,
    value: inventory.reduce((s, i) => s + i.unitPrice * i.quantity, 0),
  };

  return (
    <>
      <PageHeader
        title="Export Table"
        description="Export to CSV / JSON / Excel / PDF with row-scope selection (all / filtered / selected), column selection, and an export history panel showing the last 5 downloads."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Export" }]}
        icon={Download}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => openExportDialog("csv")}>
              <FileCode2 className="h-3.5 w-3.5" /> CSV
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => openExportDialog("json")}>
              <FileJson className="h-3.5 w-3.5" /> JSON
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => openExportDialog("xlsx")}>
              <FileSpreadsheet className="h-3.5 w-3.5" /> Excel
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => openExportDialog("pdf")}>
              <FileText className="h-3.5 w-3.5" /> PDF
            </Button>
          </>
        }
      />

      {/* Quick export tiles — unique visual element */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {(["csv", "json", "xlsx", "pdf"] as ExportFormat[]).map((fmt) => {
          const meta = formatMeta[fmt];
          const toneClass: Record<string, string> = {
            primary: "bg-primary/10 text-primary ring-primary/20",
            info: "bg-[color:var(--info)]/12 text-[color:var(--info)] ring-[color:var(--info)]/20",
            success: "bg-[color:var(--success)]/12 text-[color:var(--success)] ring-[color:var(--success)]/20",
            violet: "bg-violet-500/12 text-violet-500 ring-violet-500/20",
          };
          const Icon = meta.icon;
          return (
            <button
              key={fmt}
              onClick={() => openExportDialog(fmt)}
              className="group rounded-xl border border-border bg-card p-4 text-left hover:border-primary/30 hover:shadow-premium-xs transition-all"
            >
              <div className="flex items-start justify-between mb-2">
                <span className={cn("grid place-items-center h-10 w-10 rounded-lg ring-1 ring-inset", toneClass[meta.tone])}>
                  <Icon className="h-5 w-5" />
                </span>
                <FileDown className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <p className="text-sm font-semibold">{meta.label}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                {fmt === "csv" && "Comma-separated, UTF-8"}
                {fmt === "json" && "Structured, pretty-printed"}
                {fmt === "xlsx" && "Multi-sheet workbook"}
                {fmt === "pdf" && "Printable layout (UI)"}
              </p>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Inventory table — 2/3 */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <span className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
                  <Package className="h-4 w-4" />
                </span>
                Inventory
              </CardTitle>
              <CardDescription className="text-xs">
                Select rows with checkboxes to export just the selection, or use filters to export only matching rows. The Export dialog remembers your last scope.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Filter toolbar */}
              <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2 mb-3">
                <div className="relative flex-1 max-w-xs">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search SKU, name, or ID…"
                    className="h-8 pl-8 text-xs"
                  />
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                      <Filter className="h-3.5 w-3.5" />
                      Status
                      {statusFilter && <span className="bg-primary text-primary-foreground rounded-full text-[10px] px-1.5 py-0.5">1</span>}
                      <ChevronDown className="h-3 w-3 opacity-60" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-44">
                    <DropdownMenuItem className="text-xs" onClick={() => setStatusFilter("")}>All</DropdownMenuItem>
                    {(["in_stock", "low_stock", "out_of_stock", "discontinued"] as StockStatus[]).map((s) => (
                      <DropdownMenuItem key={s} className="text-xs" onClick={() => setStatusFilter(s)}>
                        {statusFilter === s && <Check className="h-3 w-3 mr-1.5" />}
                        {statusLabelMap[s]}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                      <Package className="h-3.5 w-3.5" />
                      Warehouse
                      {warehouseFilter && <span className="bg-primary text-primary-foreground rounded-full text-[10px] px-1.5 py-0.5">1</span>}
                      <ChevronDown className="h-3 w-3 opacity-60" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-44">
                    <DropdownMenuItem className="text-xs" onClick={() => setWarehouseFilter("")}>All</DropdownMenuItem>
                    {(["Oakland", "Newark", "Dallas", "Atlanta", "Portland"] as Warehouse[]).map((w) => (
                      <DropdownMenuItem key={w} className="text-xs" onClick={() => setWarehouseFilter(w)}>
                        {warehouseFilter === w && <Check className="h-3 w-3 mr-1.5" />}
                        {w}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                <div className="flex-1" />
                {selected.size > 0 && (
                  <Badge variant="outline" className="text-[11px] gap-1 h-8 px-2">
                    <Check className="h-3 w-3 text-primary" />
                    {selected.size} selected
                  </Badge>
                )}
              </div>

              {/* Bulk action bar */}
              {selected.size > 0 && (
                <div className="flex flex-wrap items-center gap-2 px-3 py-2 mb-2 rounded-lg bg-primary/5 border border-primary/20">
                  <span className="text-xs font-semibold text-primary">{selected.size} rows selected</span>
                  <div className="flex-1" />
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => openExportDialog("csv")}>
                    <FileCode2 className="h-3 w-3" /> Export selected as CSV
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => openExportDialog("xlsx")}>
                    <FileSpreadsheet className="h-3 w-3" /> as Excel
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setSelected(new Set())}>
                    <X className="h-3 w-3 mr-1" /> Clear
                  </Button>
                </div>
              )}

              <div className="rounded-lg border border-border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/40 border-b border-border">
                        <th className="text-left px-3 py-2 w-10">
                          <input
                            type="checkbox"
                            checked={allVisibleSelected}
                            ref={(el) => {
                              if (el) el.indeterminate = !allVisibleSelected && someVisibleSelected;
                            }}
                            onChange={toggleAllVisible}
                            className="h-3.5 w-3.5 rounded border-border accent-primary cursor-pointer"
                            aria-label="Select all visible rows"
                          />
                        </th>
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">ID</th>
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2">Product</th>
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Category</th>
                        <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-20">Qty</th>
                        <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Unit Cost</th>
                        <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Unit Price</th>
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Warehouse</th>
                        <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-28">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="text-center text-sm text-muted-foreground py-12">
                            No inventory items match the current filters.
                          </td>
                        </tr>
                      ) : (
                        filtered.map((item) => {
                          const isSelected = selected.has(item.id);
                          return (
                            <tr
                              key={item.id}
                              className={cn(
                                "border-b border-border last:border-0 hover:bg-muted/30 transition-colors",
                                isSelected && "bg-primary/[0.04]"
                              )}
                            >
                              <td className="px-3 py-2" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={() => toggleOne(item.id)}
                                  className="h-3.5 w-3.5 rounded border-border accent-primary cursor-pointer"
                                  aria-label={`Select ${item.name}`}
                                />
                              </td>
                              <td className="px-3 py-2 font-mono text-[11px] text-muted-foreground">{item.id}</td>
                              <td className="px-3 py-2">
                                <p className="font-medium text-sm">{item.name}</p>
                                <p className="text-[11px] text-muted-foreground font-mono">{item.sku}</p>
                              </td>
                              <td className="px-3 py-2 text-sm text-muted-foreground">{item.category}</td>
                              <td className="px-3 py-2 text-right tabular-nums">
                                <span className={cn(item.quantity === 0 ? "text-[color:var(--danger)] font-medium" : item.quantity < item.reorderPoint ? "text-[color:var(--warning)] font-medium" : "")}>
                                  {item.quantity}
                                </span>
                              </td>
                              <td className="px-3 py-2 text-right tabular-nums text-sm text-muted-foreground">${item.unitCost.toFixed(2)}</td>
                              <td className="px-3 py-2 text-right tabular-nums text-sm font-medium">${item.unitPrice.toFixed(2)}</td>
                              <td className="px-3 py-2 text-sm text-muted-foreground">{item.warehouse}</td>
                              <td className="px-3 py-2 text-center">
                                <StatusBadge tone={statusToneMap[item.status]} dot>{statusLabelMap[item.status]}</StatusBadge>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="flex items-center justify-between mt-3">
                <p className="text-xs text-muted-foreground">
                  {filtered.length} of {inventory.length} items shown
                  {selected.size > 0 && <> · <span className="text-primary font-medium">{selected.size} selected</span></>}
                </p>
                <p className="text-xs text-muted-foreground">
                  Total inventory value: <span className="font-semibold text-foreground tabular-nums">${stats.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Export history panel — 1/3 */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-base">
                <span className="flex items-center gap-2">
                  <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
                    <History className="h-4 w-4" />
                  </span>
                  Export History
                </span>
                <Badge variant="outline" className="text-[11px]">last 5</Badge>
              </CardTitle>
              <CardDescription className="text-xs">
                Past exports with format, row count, scope, and download timestamp.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
                {history.length === 0 ? (
                  <div className="text-center py-12">
                    <History className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground">No exports yet.</p>
                  </div>
                ) : (
                  history.map((h) => {
                    const meta = formatMeta[h.format];
                    const Icon = meta.icon;
                    const toneClass: Record<string, string> = {
                      primary: "bg-primary/10 text-primary",
                      info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
                      success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
                      violet: "bg-violet-500/12 text-violet-500",
                    };
                    return (
                      <div key={h.id} className="rounded-lg border border-border p-3 hover:bg-muted/30 transition-colors">
                        <div className="flex items-start gap-2.5">
                          <span className={cn("grid place-items-center h-8 w-8 rounded-lg shrink-0", toneClass[meta.tone])}>
                            <Icon className="h-4 w-4" />
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-medium truncate">{h.filename}</p>
                            <p className="text-[11px] text-muted-foreground font-mono mt-0.5">{h.timestamp}</p>
                            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                              <Badge variant="outline" className="text-[10px] h-4 px-1.5 uppercase">{h.format}</Badge>
                              <span className="text-[10px] text-muted-foreground">{h.rows} rows · {h.columns} cols · {h.size}</span>
                              <Badge
                                variant="outline"
                                className={cn(
                                  "text-[10px] h-4 px-1.5 capitalize",
                                  h.scope === "all" && "border-border text-muted-foreground",
                                  h.scope === "filtered" && "border-primary/30 text-primary",
                                  h.scope === "selected" && "border-[color:var(--info)]/30 text-[color:var(--info)]"
                                )}
                              >
                                {h.scope}
                              </Badge>
                            </div>
                          </div>
                          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => toast.success(`Re-downloading ${h.filename}`)}>
                            <Download className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
              <div className="mt-3 pt-3 border-t border-border">
                <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                  <span className="inline-flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-[color:var(--success)]" />
                    Auto-archived to <span className="font-medium text-foreground">/exports</span>
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    Retained 30 days
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Export configuration dialog */}
      <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {(() => {
                const Icon = formatMeta[pendingFormat].icon;
                return <Icon className="h-4 w-4 text-primary" />;
              })()}
              Export as {formatMeta[pendingFormat].label}
            </DialogTitle>
            <DialogDescription>
              Choose what to export and which columns to include. Click Export to download the file.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            {/* Scope selection */}
            <div>
              <p className="text-xs font-medium mb-1.5">What to export</p>
              <div className="grid grid-cols-3 gap-2">
                {([
                  { v: "all", label: "All rows", count: inventory.length, hint: "entire dataset" },
                  { v: "filtered", label: "Filtered", count: filtered.length, hint: "current view" },
                  { v: "selected", label: "Selected", count: selected.size, hint: "checked rows" },
                ] as const).map((opt) => (
                  <button
                    key={opt.v}
                    onClick={() => setPendingScope(opt.v)}
                    disabled={opt.v === "selected" && selected.size === 0}
                    className={cn(
                      "rounded-md border p-2 text-left transition-colors disabled:opacity-40 disabled:cursor-not-allowed",
                      pendingScope === opt.v ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"
                    )}
                  >
                    <p className="text-xs font-medium">{opt.label}</p>
                    <p className="text-base font-semibold tabular-nums mt-0.5">{opt.count}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{opt.hint}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Column selection */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <p className="text-xs font-medium">Columns to include</p>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" className="h-6 text-[11px]" onClick={() => setSelectedColumns(new Set(allColumns.map((c) => c.key)))}>
                    All
                  </Button>
                  <Button variant="ghost" size="sm" className="h-6 text-[11px]" onClick={() => setSelectedColumns(new Set())}>
                    None
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-1 max-h-44 overflow-y-auto rounded-md border border-border p-2">
                {allColumns.map((c) => (
                  <label
                    key={c.key}
                    className="flex items-center gap-2 rounded px-1.5 py-1 hover:bg-muted/40 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={selectedColumns.has(c.key)}
                      onChange={() => toggleColumn(c.key)}
                      className="h-3.5 w-3.5 rounded border-border accent-primary"
                    />
                    <span className="text-xs">{c.label}</span>
                  </label>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground mt-1 inline-flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                {selectedColumns.size} of {allColumns.length} columns selected
              </p>
            </div>

            {/* Summary preview */}
            <div className="rounded-md bg-muted/50 p-3 text-xs">
              <div className="flex items-center justify-between mb-1">
                <span className="text-muted-foreground">Filename preview:</span>
                <span className="font-mono text-[11px] text-foreground">inventory-{pendingScope}-{new Date().toISOString().slice(0, 10)}.{pendingFormat === "xlsx" ? "xlsx" : pendingFormat}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Estimated size:</span>
                <span className="font-mono text-[11px] text-foreground">
                  {pendingScope === "all" ? inventory.length : pendingScope === "filtered" ? filtered.length : selected.size} rows × {selectedColumns.size} cols
                  {" ≈ "}
                  {pendingFormat === "pdf" ? "—" : `${(((pendingScope === "all" ? inventory.length : pendingScope === "filtered" ? filtered.length : selected.size) * selectedColumns.size * 0.04) + 0.8).toFixed(1)} KB`}
                </span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setExportDialogOpen(false)}>Cancel</Button>
            <Button size="sm" className="gap-1.5" onClick={runExport} disabled={exporting || selectedColumns.size === 0}>
              {exporting ? (
                <>
                  <Clock className="h-3.5 w-3.5 animate-spin" /> Exporting…
                </>
              ) : (
                <>
                  <Download className="h-3.5 w-3.5" /> Export {pendingScope === "all" ? inventory.length : pendingScope === "filtered" ? filtered.length : selected.size} rows
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
