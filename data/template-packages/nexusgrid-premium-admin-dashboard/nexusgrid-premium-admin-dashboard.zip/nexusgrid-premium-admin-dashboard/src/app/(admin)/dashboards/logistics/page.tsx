"use client";

import * as React from "react";
import {
  Truck,
  Package,
  Clock,
  TrendingUp,
  Gauge,
  Filter,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  MapPin,
  Route,
  CheckCircle2,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BarTrendChart, DonutChart } from "@/components/charts";
import { shipments, weekdays } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline logistics data ---------- */

// Shipment status breakdown — counts add up to Active Shipments KPI (1,284)
const shipmentStatus = [
  { name: "In Transit", value: 642, color: "var(--info)" },
  { name: "Delivered", value: 482, color: "var(--success)" },
  { name: "Delayed", value: 124, color: "var(--warning)" },
  { name: "Customs", value: 36, color: "oklch(0.62 0.18 305)" },
];

// Weekly delivery trend — 7 days, delivered vs delayed
const weeklyDelivery = weekdays.map((d, i) => ({
  day: d,
  delivered: 60 + Math.round(Math.sin(i * 0.8) * 14 + i * 4),
  delayed: 4 + Math.round(Math.cos(i * 0.6) * 3 + (i % 3 === 0 ? 2 : 0)),
}));

// Fleet status — 4 vehicles
const fleet = [
  { id: "TRK-418", driver: "Carlos Mendez", status: "in-transit", tone: "info" as StatusTone, location: "I-5 N, Oregon", progress: 64 },
  { id: "TRK-417", driver: "Priya Sharma", status: "loading", tone: "warning" as StatusTone, location: "Depot — Oakland, CA", progress: 12 },
  { id: "TRK-416", driver: "Tom Bradley", status: "delivered", tone: "success" as StatusTone, location: "Warehouse — Phoenix, AZ", progress: 100 },
  { id: "TRK-415", driver: "Lina Park", status: "maintenance", tone: "neutral" as StatusTone, location: "Service yard — Reno, NV", progress: 0 },
];

// Top routes — 5 entries
const topRoutes = [
  { origin: "Shanghai", destination: "Los Angeles", shipments: 184, avgTime: "14.2 days", onTime: 96, tone: "success" as StatusTone },
  { origin: "Hamburg", destination: "New York", shipments: 142, avgTime: "11.8 days", onTime: 92, tone: "success" as StatusTone },
  { origin: "Singapore", destination: "Rotterdam", shipments: 128, avgTime: "18.4 days", onTime: 88, tone: "warning" as StatusTone },
  { origin: "Tokyo", destination: "Sydney", shipments: 96, avgTime: "9.6 days", onTime: 94, tone: "success" as StatusTone },
  { origin: "Mumbai", destination: "Dubai", shipments: 84, avgTime: "6.2 days", onTime: 78, tone: "danger" as StatusTone },
];

// Carrier color map for badges
const carrierColors: Record<string, string> = {
  DHL: "bg-[color:var(--warning)]/12 text-[color:var(--warning)] ring-[color:var(--warning)]/20",
  FedEx: "bg-violet-500/12 text-violet-500 ring-violet-500/20",
  Maersk: "bg-[color:var(--info)]/12 text-[color:var(--info)] ring-[color:var(--info)]/20",
  UPS: "bg-primary/12 text-primary ring-primary/20",
};

const shipmentStatusTone: Record<string, StatusTone> = {
  "in-transit": "info",
  delivered: "success",
  delayed: "warning",
  customs: "violet",
};

/* ---------- Logistics KPI card — route/map feel, monospace numerals ---------- */
// Distinct from all existing KPI cards:
// - Top "route" decoration (origin dot ━━ dashed line ━━ truck icon ━━ dashed line ━━ destination dot)
// - Big value in monospace tabular-nums (logistics ID aesthetic)
// - Compact layout, info-color accent throughout
// - Bottom mini progress bar + ETA caption instead of trend chart

function LogisticsKpiCard({
  label,
  value,
  unit,
  icon: Icon,
  trend,
  trendLabel,
  progress,
  progressLabel,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  trendLabel: string;
  progress: number; // 0-100
  progressLabel: string;
}) {
  const isUp = trend.direction === "up";

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      {/* Top route decoration — origin / dashed line / truck / dashed line / destination */}
      <div className="flex items-center gap-1.5 mb-3" aria-hidden>
        <span className="h-2 w-2 rounded-full bg-[color:var(--info)] ring-2 ring-[color:var(--info)]/20 shrink-0" />
        <span className="flex-1 h-px border-t border-dashed border-muted-foreground/40" />
        <Icon className="h-3.5 w-3.5 text-[color:var(--info)] shrink-0" />
        <span className="flex-1 h-px border-t border-dashed border-muted-foreground/40" />
        <span className="h-2 w-2 rounded-full bg-primary ring-2 ring-primary/20 shrink-0" />
      </div>

      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
            {label}
          </p>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-2xl font-semibold tracking-tight tabular-nums font-mono">{value}</span>
            {unit && <span className="text-sm font-semibold text-muted-foreground tabular-nums">{unit}</span>}
          </div>
        </div>
        <div className="grid place-items-center h-9 w-9 rounded-lg shrink-0 bg-[color:var(--info)]/12 text-[color:var(--info)]">
          <Icon className="h-4.5 w-4.5" />
        </div>
      </div>

      {/* Mini progress bar */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1.5">
          <span className="truncate font-mono">{progressLabel}</span>
          <span className="font-semibold tabular-nums text-[color:var(--info)] shrink-0 font-mono">
            {progress}%
          </span>
        </div>
        <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[color:var(--info)]/70 to-[color:var(--info)] transition-all duration-700 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Trend pill + caption */}
      <div className="mt-3 flex items-center gap-1.5">
        <span
          className={cn(
            "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
            trend.positive
              ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
              : "bg-destructive/12 text-destructive"
          )}
        >
          {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {Math.abs(trend.value)}%
        </span>
        <span className="text-xs text-muted-foreground truncate">{trendLabel}</span>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function LogisticsDashboardPage() {
  const totalShipments = shipmentStatus.reduce((s, x) => s + x.value, 0);

  return (
    <>
      <PageHeader
        title="Logistics Dashboard"
        description="Active shipments, fleet status, and delivery performance across global routes."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Logistics" }]}
        icon={Truck}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> All carriers
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5 bg-[color:var(--info)] text-[color:var(--info-foreground)] hover:bg-[color:var(--info)]/90">
              <Plus className="h-3.5 w-3.5" /> New shipment
            </Button>
          </>
        }
      />

      {/* KPI Row — LogisticsKpiCard with route decoration + monospace numerals */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <LogisticsKpiCard
          label="Active Shipments"
          value="1,284"
          icon={Package}
          trend={{ value: 8, direction: "up", positive: true }}
          trendLabel="vs. last week"
          progress={82}
          progressLabel="1,054 tracked · 230 untracked"
        />
        <LogisticsKpiCard
          label="On-Time Delivery"
          value="94.2"
          unit="%"
          icon={CheckCircle2}
          trend={{ value: 1.4, direction: "up", positive: true }}
          trendLabel="vs. last week"
          progress={94}
          progressLabel="1,210 of 1,284 on time"
        />
        <LogisticsKpiCard
          label="Fleet Utilization"
          value="78"
          unit="%"
          icon={Gauge}
          trend={{ value: 3, direction: "up", positive: true }}
          trendLabel="vs. last week"
          progress={78}
          progressLabel="62 of 80 vehicles in service"
        />
        <LogisticsKpiCard
          label="Avg Transit Time"
          value="3.2"
          unit="days"
          icon={Clock}
          trend={{ value: 0.4, direction: "down", positive: true }}
          trendLabel="faster vs. last week"
          progress={68}
          progressLabel="target: 4.7 days"
        />
      </div>

      {/* Shipment status donut + Weekly delivery trend */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Package className="h-4 w-4 text-[color:var(--info)]" />
              Shipment Status
            </CardTitle>
            <CardDescription>Current breakdown across {totalShipments.toLocaleString()} active shipments.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={shipmentStatus}
              centerLabel="Active"
              centerValue={totalShipments.toLocaleString()}
              height={200}
            />
            <div className="mt-3 space-y-1.5 pt-3 border-t border-border">
              {shipmentStatus.map((s) => {
                const pct = ((s.value / totalShipments) * 100).toFixed(1);
                return (
                  <div key={s.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="h-2 w-2 rounded-full shrink-0" style={{ background: s.color }} />
                      <span className="text-muted-foreground truncate">{s.name}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-medium tabular-nums font-mono">{s.value.toLocaleString()}</span>
                      <span className="text-muted-foreground tabular-nums w-10 text-right">{pct}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-[color:var(--info)]" />
                Weekly Delivery Trend
              </CardTitle>
              <CardDescription>Delivered vs. delayed shipments over the last 7 days.</CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)]" /> Delivered
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--warning)]" /> Delayed
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={weeklyDelivery}
              xKey="day"
              series={[
                { key: "delivered", name: "Delivered", color: "var(--success)" },
                { key: "delayed", name: "Delayed", color: "var(--warning)" },
              ]}
              stacked
              height={300}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total Delivered</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums font-mono mt-0.5">
                  {weeklyDelivery.reduce((s, x) => s + x.delivered, 0)}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total Delayed</p>
                <p className="text-sm font-semibold text-[color:var(--warning)] tabular-nums font-mono mt-0.5">
                  {weeklyDelivery.reduce((s, x) => s + x.delayed, 0)}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">On-Time Rate</p>
                <p className="text-sm font-semibold text-[color:var(--info)] tabular-nums font-mono mt-0.5">
                  {(
                    (weeklyDelivery.reduce((s, x) => s + x.delivered, 0) /
                      (weeklyDelivery.reduce((s, x) => s + x.delivered + x.delayed, 0))) *
                    100
                  ).toFixed(1)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active shipments table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Package className="h-4 w-4 text-[color:var(--info)]" />
              Active Shipments
            </CardTitle>
            <CardDescription>Live tracking of shipments across all carriers.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            View all <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Shipment ID</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Carrier</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Route</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">ETA</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Weight</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {shipments.map((s) => (
                  <tr key={s.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs font-medium text-foreground">{s.id}</span>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span
                        className={cn(
                          "inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold ring-1 ring-inset",
                          carrierColors[s.carrier] ?? "bg-muted text-muted-foreground ring-border"
                        )}
                      >
                        {s.carrier}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2 min-w-0">
                        <MapPin className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                        <span className="text-xs text-foreground truncate">{s.origin}</span>
                        <span className="text-muted-foreground/60 shrink-0" aria-hidden>→</span>
                        <span className="text-xs text-foreground truncate">{s.destination}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={shipmentStatusTone[s.status]} dot className="capitalize">
                        {s.status}
                      </StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground tabular-nums font-mono hidden md:table-cell">
                      {s.eta}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="text-xs font-medium tabular-nums font-mono">{s.weight}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Fleet status + Route performance */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Fleet status — 4 vehicle cards */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Truck className="h-4 w-4 text-[color:var(--info)]" />
                Fleet Status
              </CardTitle>
              <CardDescription>Live status of vehicles in the active fleet.</CardDescription>
            </div>
            <StatusBadge tone="info" dot>{fleet.length} vehicles</StatusBadge>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {fleet.map((v) => (
                <div
                  key={v.id}
                  className="relative overflow-hidden rounded-lg border border-border bg-muted/20 p-4 hover:bg-muted/40 hover:border-[color:var(--info)]/30 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)] shrink-0">
                        <Truck className="h-4.5 w-4.5" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-mono text-xs font-semibold text-foreground">{v.id}</p>
                        <p className="text-[11px] text-muted-foreground truncate">{v.driver}</p>
                      </div>
                    </div>
                    <StatusBadge tone={v.tone} dot className="capitalize shrink-0">{v.status}</StatusBadge>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2.5">
                    <MapPin className="h-3 w-3 shrink-0" />
                    <span className="truncate">{v.location}</span>
                  </div>
                  {/* Trip progress bar */}
                  <div className="h-1 w-full rounded-full bg-muted overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-700 ease-out",
                        v.status === "delivered" && "bg-[color:var(--success)]",
                        v.status === "in-transit" && "bg-[color:var(--info)]",
                        v.status === "loading" && "bg-[color:var(--warning)]",
                        v.status === "maintenance" && "bg-muted-foreground/40"
                      )}
                      style={{ width: `${v.progress}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Route performance — top 5 routes */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Route className="h-4 w-4 text-[color:var(--info)]" />
                Route Performance
              </CardTitle>
              <CardDescription>Top 5 routes by shipment volume this month.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Route</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Shipments</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Avg Time</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">On-Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {topRoutes.map((r) => (
                    <tr key={`${r.origin}-${r.destination}`} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <MapPin className="h-3 w-3 text-muted-foreground shrink-0" />
                          <span className="text-xs text-foreground truncate">{r.origin}</span>
                          <span className="text-muted-foreground/60 shrink-0" aria-hidden>→</span>
                          <span className="text-xs text-foreground truncate">{r.destination}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums font-mono font-medium">{r.shipments}</td>
                      <td className="px-4 py-3 text-right tabular-nums font-mono text-muted-foreground hidden sm:table-cell">
                        {r.avgTime}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="hidden sm:block h-1.5 w-14 rounded-full bg-muted overflow-hidden">
                            <div
                              className={cn(
                                "h-full rounded-full transition-all duration-700 ease-out",
                                r.onTime >= 90 ? "bg-[color:var(--success)]" : r.onTime >= 80 ? "bg-[color:var(--warning)]" : "bg-destructive"
                              )}
                              style={{ width: `${r.onTime}%` }}
                            />
                          </div>
                          <StatusBadge tone={r.tone} className="tabular-nums">{r.onTime}%</StatusBadge>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
