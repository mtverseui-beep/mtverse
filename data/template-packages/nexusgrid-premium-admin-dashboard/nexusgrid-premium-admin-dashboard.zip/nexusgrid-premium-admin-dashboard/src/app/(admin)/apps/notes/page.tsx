"use client";

import * as React from "react";
import {
  StickyNote,
  Search,
  Plus,
  Pin,
  PinOff,
  Trash2,
  Tag,
  Clock,
  Notebook,
  Lightbulb,
  Briefcase,
  Home,
  Star,
  MoreHorizontal,
  Bold,
  Italic,
  List as ListIcon,
  Code,
  Quote,
  Heading,
  Check,
  Share2,
  Download,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type Note = {
  id: string;
  title: string;
  body: string;
  tags: string[];
  notebook: "personal" | "work" | "ideas";
  pinned: boolean;
  starred: boolean;
  updated: string;
  wordCount: number;
};

const initialNotes: Note[] = [
  {
    id: "n1",
    title: "Q3 Strategy — Talking Points",
    body: "## Pre-read summary\n\n- H1 closed 8% above plan, gross margin +320bps YoY\n- Q3 guidance raised to $14.2M ARR\n- Three strategic priorities: **platform resilience**, **enterprise expansion**, **payment partnerships**\n\n## Asks for the board\n1. Approve the $2.4M platform investment\n2. Sign off on the Stripe partnership MOU\n3. Endorse the new IC compensation framework\n\n## Risks to flag\n- Customer concentration: top 10 = 38% of ARR\n- Engineering capacity for the migration timeline",
    tags: ["strategy", "board", "q3"],
    notebook: "work",
    pinned: true,
    starred: true,
    updated: "2 min ago",
    wordCount: 142,
  },
  {
    id: "n2",
    title: "1:1 with Aiko — Weekly Sync",
    body: "## Topics\n\n- Payment retry refactor — PR #2841 ready for review\n- Migration cutover plan: confirm Friday 2am PT window\n- Hiring: 2 backend roles opened, pipeline of 14 candidates\n\n## Action items\n- [ ] Aiko: send postmortem template for July 8 incident\n- [ ] Me: review capacity model before Friday\n\n## Notes\nAiko raised concerns about the connection pool config drift — we should add pre-deploy validation. Suggested adding a CLI check that diffs against the production config.",
    tags: ["1on1", "engineering", "people"],
    notebook: "work",
    pinned: true,
    starred: false,
    updated: "1 hour ago",
    wordCount: 98,
  },
  {
    id: "n3",
    title: "Book Recommendations 2026",
    body: "## Currently reading\n- **The Creative Act** — Rick Rubin (p. 142 / 416)\n- **Slow Productivity** — Cal Newport (just started)\n\n## Queue\n1. The Idealist — Benjamin Wallace-Wells\n2. Same as Ever — Morgan Housel\n3. The Anxious Generation — Jonathan Haidt\n4. Co-Intelligence — Ethan Mollick\n\n## Finished\n- The Algebra of Wealth (4/5)\n- Build the Life You Want (3/5)",
    tags: ["reading", "personal"],
    notebook: "personal",
    pinned: false,
    starred: true,
    updated: "Yesterday",
    wordCount: 76,
  },
  {
    id: "n4",
    title: "Product Idea: Usage-Based Pricing Tier",
    body: "## Problem\nMid-market customers churn because they hit the seat cap before value realization.\n\n## Hypothesis\nA usage-based tier (priced per API call + base platform fee) would unlock 40+ accounts currently stuck in procurement.\n\n## Validation plan\n- Pull the last 12 months of expansion/contraction data\n- Interview 8 customers who churned citing price\n- Model 3 pricing scenarios: $0.01, $0.015, $0.02 per call\n\n## Open questions\n- Do we keep the seat component or go pure usage?\n- How do we handle enterprise minimums?",
    tags: ["product", "pricing", "idea"],
    notebook: "ideas",
    pinned: false,
    starred: false,
    updated: "Yesterday",
    wordCount: 124,
  },
  {
    id: "n5",
    title: "Sprint 24 Retro Notes",
    body: "## What went well\n- Shipped the new onboarding flow (3 days early)\n- Zero P1 incidents\n- Design+eng pairing on the dashboard paid off\n\n## What didn't\n- Standups ran long (avg 22min, target 15min)\n- Story pointing was inconsistent across teams\n\n## Action items\n- [ ] Trial 15-min hard-stop timer for standups\n- [ ] Refresh pointing guide with examples\n- [ ] Schedule design+eng pairing 2x/week\n\nConfidence vote: 4.2 / 5",
    tags: ["retro", "sprint-24", "process"],
    notebook: "work",
    pinned: false,
    starred: false,
    updated: "2 days ago",
    wordCount: 86,
  },
  {
    id: "n6",
    title: "Weekend Trip — Big Sur",
    body: "## Itinerary\n**Day 1** — Drive down 101, stop at Pigeon Point Lighthouse. Lunch at Duarte's. Camp at Plaskett Creek.\n\n**Day 2** — Morning hike: McWay Falls → Partington Cove. Afternoon at Carmel Valley Ranch.\n\n## Packing list\n- [ ] Headlamps + extra batteries\n- [ ] Camp stove + fuel\n- [ ] Coffee pour-over kit\n- [ ] Layers (it drops to 50F at night)\n\n## Reservations\n- Plaskett Creek: confirmed, site #14\n- Duarte's: 1:30pm Saturday",
    tags: ["travel", "personal"],
    notebook: "personal",
    pinned: false,
    starred: false,
    updated: "3 days ago",
    wordCount: 95,
  },
  {
    id: "n7",
    title: "Customer Interview Themes — July",
    body: "## Interviewed\n- 4 enterprise (1000+ seats)\n- 3 mid-market (100-1000)\n- 3 SMB (<100)\n\n## Top 5 themes\n1. **Onboarding friction** at week 2 (8/10 mentioned)\n2. **Reporting gaps** — custom dashboards are the #1 ask\n3. **Mobile parity** — the iOS app is 'barely usable'\n4. **SSO** — must-have for enterprise\n5. **Pricing transparency** — usage tier confusion\n\n## Quotes worth keeping\n- \"The product is great once you're in, but getting the team set up takes a full sprint.\"\n- \"I'd pay double for a real mobile experience.\"",
    tags: ["research", "customer", "q3"],
    notebook: "work",
    pinned: false,
    starred: true,
    updated: "4 days ago",
    wordCount: 112,
  },
  {
    id: "n8",
    title: "Side Project: Garden Planner",
    body: "## Goal\nBuild a small garden planning tool that suggests companion plants based on sun exposure and zone.\n\n## Stack ideas\n- Next.js + Prisma (already familiar)\n- Pull USDA zone data from the open API\n- GPT for the recommendation layer\n\n## MVP scope\n- [ ] Add plants to a virtual plot\n- [ ] Sun exposure per plant\n- [ ] Companion suggestions\n- [ ] Seasonal planting calendar\n\nStretch: harvest reminders, photo journal.",
    tags: ["side-project", "code", "idea"],
    notebook: "ideas",
    pinned: false,
    starred: false,
    updated: "5 days ago",
    wordCount: 88,
  },
  {
    id: "n9",
    title: "Home Maintenance Log",
    body: "## 2026 timeline\n- **Jan** — Furnace service (HVAC Co., $180)\n- **Mar** — Roof inspection (clean, next due 2028)\n- **May** — Replaced water heater (12yr warranty)\n- **Jul** — Tree trimming (back oak + maple)\n\n## Upcoming\n- [ ] Gutter cleaning — Aug\n- [ ] Chimney sweep — Oct\n- [ ] Sprinkler winterization — Nov\n\n## Vendors\n- HVAC: Peninsula Mechanical\n- Roof: Bay Area Roofing Co.\n- Tree: Acme Arborists",
    tags: ["home", "maintenance"],
    notebook: "personal",
    pinned: false,
    starred: false,
    updated: "1 week ago",
    wordCount: 78,
  },
  {
    id: "n10",
    title: "Hiring Rubric — Senior PM",
    body: "## Competencies (1-5 scale)\n1. **Strategic framing** — Can they turn ambiguous problems into testable bets?\n2. **Customer empathy** — Depth of direct customer interaction evidence\n3. **Technical fluency** — Can they engage eng on architecture trade-offs?\n4. **Communication** — Clarity in writing + verbal synthesis\n5. **Ownership** — Track record of multi-quarter delivery\n\n## Bar\n- 4 of 5 competencies at 4+\n- No 2s\n- Reference checks must include a peer + a report\n\n## Calibration\nWe've been too lenient on technical fluency — raise the bar in round 2.",
    tags: ["hiring", "pm", "people"],
    notebook: "work",
    pinned: false,
    starred: false,
    updated: "1 week ago",
    wordCount: 96,
  },
];

const notebooks = [
  { key: "all", label: "All Notes", icon: StickyNote, count: initialNotes.length },
  { key: "personal", label: "Personal", icon: Home, count: initialNotes.filter((n) => n.notebook === "personal").length },
  { key: "work", label: "Work", icon: Briefcase, count: initialNotes.filter((n) => n.notebook === "work").length },
  { key: "ideas", label: "Ideas", icon: Lightbulb, count: initialNotes.filter((n) => n.notebook === "ideas").length },
];

const allTags = Array.from(new Set(initialNotes.flatMap((n) => n.tags))).sort();

export default function NotesPage() {
  const [activeNotebook, setActiveNotebook] = React.useState<string>("all");
  const [activeTag, setActiveTag] = React.useState<string | null>(null);
  const [activeId, setActiveId] = React.useState<string>("n1");
  const [search, setSearch] = React.useState("");
  const [notes, setNotes] = React.useState(initialNotes);
  const [title, setTitle] = React.useState(initialNotes[0].title);
  const [body, setBody] = React.useState(initialNotes[0].body);
  const [tags, setTags] = React.useState(initialNotes[0].tags.join(", "));

  const filteredNotes = notes
    .filter((n) => activeNotebook === "all" || n.notebook === activeNotebook)
    .filter((n) => !activeTag || n.tags.includes(activeTag))
    .filter((n) => !search || n.title.toLowerCase().includes(search.toLowerCase()) || n.body.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => Number(b.pinned) - Number(a.pinned));

  const pinnedNotes = filteredNotes.filter((n) => n.pinned);
  const otherNotes = filteredNotes.filter((n) => !n.pinned);

  const active = notes.find((n) => n.id === activeId);

  React.useEffect(() => {
    if (active) {
      setTitle(active.title);
      setBody(active.body);
      setTags(active.tags.join(", "));
    }
  }, [activeId]);

  function selectNote(id: string) {
    setActiveId(id);
  }

  function togglePin(id: string) {
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)));
    toast.success(active && !active.pinned ? "Note pinned" : "Note unpinned");
  }

  function toggleStar(id: string) {
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, starred: !n.starred } : n)));
  }

  function deleteNote(id: string) {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    toast.success("Note moved to trash");
    if (id === activeId) {
      const next = notes.find((n) => n.id !== id);
      if (next) setActiveId(next.id);
    }
  }

  function saveNote() {
    setNotes((prev) => prev.map((n) => (n.id === activeId ? {
      ...n,
      title: title || "Untitled",
      body,
      tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
      updated: "just now",
      wordCount: body.trim().split(/\s+/).length,
    } : n)));
    toast.success("Note saved");
  }

  function createNote() {
    const id = `n${Date.now()}`;
    const newNote: Note = {
      id,
      title: "Untitled note",
      body: "",
      tags: [],
      notebook: activeNotebook === "all" ? "work" : (activeNotebook as any),
      pinned: false,
      starred: false,
      updated: "just now",
      wordCount: 0,
    };
    setNotes((prev) => [newNote, ...prev]);
    setActiveId(id);
    setTitle("Untitled note");
    setBody("");
    setTags("");
    toast.success("Note created");
  }

  const notebookColor: Record<string, string> = {
    personal: "oklch(0.62 0.18 140)",
    work: "var(--primary)",
    ideas: "oklch(0.62 0.18 305)",
  };

  return (
    <>
      <PageHeader
        title="Notes"
        description="Capture ideas, meeting notes, and research in rich-text notebooks."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "Notes" }]}
        icon={StickyNote}
        actions={
          <Button size="sm" className="gap-1.5" onClick={createNote}>
            <Plus className="h-3.5 w-3.5" /> New Note
          </Button>
        }
      />

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div className="grid grid-cols-1 lg:grid-cols-[260px_360px_1fr] h-[calc(100vh-220px)] min-h-[560px]">
            {/* NOTEBOOK SIDEBAR */}
            <div className="border-r flex flex-col">
              <div className="p-3 border-b">
                <Button size="sm" className="w-full gap-1.5" onClick={createNote}>
                  <Plus className="h-3.5 w-3.5" /> New Note
                </Button>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-2">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5">Notebooks</p>
                  {notebooks.map((nb) => {
                    const Icon = nb.icon;
                    const active = activeNotebook === nb.key;
                    return (
                      <button
                        key={nb.key}
                        onClick={() => { setActiveNotebook(nb.key); setActiveTag(null); }}
                        className={cn(
                          "w-full flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm transition-colors",
                          active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground"
                        )}
                      >
                        <span className="flex items-center gap-2">
                          <Icon className="h-3.5 w-3.5" />
                          {nb.label}
                        </span>
                        <span className="text-[10px] tabular-nums text-muted-foreground">{nb.count}</span>
                      </button>
                    );
                  })}

                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5 mt-3">Tags</p>
                  <div className="flex flex-wrap gap-1 px-1">
                    {allTags.map((t) => (
                      <button
                        key={t}
                        onClick={() => setActiveTag(activeTag === t ? null : t)}
                        className={cn(
                          "inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded ring-1 ring-inset transition-colors",
                          activeTag === t
                            ? "bg-primary/15 text-primary ring-primary/30"
                            : "bg-muted text-muted-foreground ring-border hover:bg-muted/70"
                        )}
                      >
                        <Tag className="h-2 w-2" />{t}
                      </button>
                    ))}
                  </div>

                  <div className="mt-4 px-2">
                    <div className="rounded-md bg-muted/40 p-3">
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground mb-2">Markdown tips</p>
                      <ul className="text-[10px] text-muted-foreground space-y-1 font-mono">
                        <li># Heading</li>
                        <li>**bold** / *italic*</li>
                        <li>- bullet item</li>
                        <li>- [ ] checklist</li>
                        <li>`code`</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </div>

            {/* NOTES LIST */}
            <div className="border-r flex flex-col min-w-0">
              <div className="p-3 border-b">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search notes..." className="h-9 pl-8 text-sm" />
                </div>
                <p className="text-xs text-muted-foreground mt-2 px-1">{filteredNotes.length} notes {activeTag && <span className="text-primary">· tagged #{activeTag}</span>}</p>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-2 space-y-1">
                  {pinnedNotes.length > 0 && (
                    <>
                      <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5 flex items-center gap-1"><Pin className="h-2.5 w-2.5" /> Pinned</p>
                      {pinnedNotes.map((n) => (
                        <NoteListItem key={n.id} note={n} active={n.id === activeId} onClick={() => selectNote(n.id)} onPin={() => togglePin(n.id)} notebookColor={notebookColor} />
                      ))}
                      <Separator className="my-2" />
                    </>
                  )}
                  {otherNotes.map((n) => (
                    <NoteListItem key={n.id} note={n} active={n.id === activeId} onClick={() => selectNote(n.id)} onPin={() => togglePin(n.id)} notebookColor={notebookColor} />
                  ))}
                  {filteredNotes.length === 0 && (
                    <div className="py-12 text-center text-sm text-muted-foreground">No notes found.</div>
                  )}
                </div>
              </ScrollArea>
            </div>

            {/* EDITOR */}
            <div className="flex flex-col min-w-0">
              {active ? (
                <>
                  {/* Toolbar */}
                  <div className="flex items-center gap-1 px-4 py-2 border-b">
                    <Button variant="ghost" size="sm" className="gap-1.5 text-xs" onClick={() => togglePin(active.id)}>
                      {active.pinned ? <><PinOff className="h-3.5 w-3.5" /> Unpin</> : <><Pin className="h-3.5 w-3.5" /> Pin</>}
                    </Button>
                    <Button variant="ghost" size="sm" className="gap-1.5 text-xs" onClick={() => toggleStar(active.id)}>
                      <Star className={cn("h-3.5 w-3.5", active.starred && "text-[color:var(--warning)] fill-current")} />
                      {active.starred ? "Starred" : "Star"}
                    </Button>
                    <Separator orientation="vertical" className="h-5 mx-1" />
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("Heading applied")}><Heading className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("Bold applied")}><Bold className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("Italic applied")}><Italic className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("List applied")}><ListIcon className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("Code block applied")}><Code className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("Quote applied")}><Quote className="h-3.5 w-3.5" /></Button>
                    <div className="flex-1" />
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("Note shared")}><Share2 className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.success("Exported as Markdown")}><Download className="h-3.5 w-3.5" /></Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => togglePin(active.id)}>{active.pinned ? "Unpin note" : "Pin note"}</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast.success("Duplicated")}>Duplicate</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => toast.success("Moved to trash")}><Trash2 className="h-3.5 w-3.5 mr-1.5" />Move to trash</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => deleteNote(active.id)}>Delete permanently</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <ScrollArea className="flex-1">
                    <div className="p-5 max-w-3xl mx-auto">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="h-2 w-2 rounded-full" style={{ background: notebookColor[active.notebook] }} />
                        <span className="text-[10px] uppercase tracking-wide text-muted-foreground capitalize">{active.notebook}</span>
                        <span className="text-[10px] text-muted-foreground">·</span>
                        <span className="text-[10px] text-muted-foreground flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{active.updated}</span>
                        <span className="text-[10px] text-muted-foreground">·</span>
                        <span className="text-[10px] text-muted-foreground tabular-nums">{active.wordCount} words</span>
                        {active.starred && <Star className="h-3 w-3 text-[color:var(--warning)] fill-current ml-auto" />}
                      </div>
                      <Input
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="Untitled note"
                        className="border-0 px-0 text-2xl font-semibold tracking-tight focus-visible:ring-0 h-auto bg-transparent"
                      />
                      <Textarea
                        value={body}
                        onChange={(e) => setBody(e.target.value)}
                        placeholder="Start writing... Markdown supported."
                        className="mt-3 border-0 px-0 text-sm font-mono leading-relaxed focus-visible:ring-0 min-h-[400px] resize-none bg-transparent"
                      />
                      <div className="mt-4 pt-4 border-t">
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-1.5">Tags</p>
                        <Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="comma, separated, tags" className="h-8 text-xs" />
                      </div>
                    </div>
                  </ScrollArea>

                  <div className="border-t p-3 flex items-center justify-between">
                    <p className="text-[10px] text-muted-foreground">Auto-saves every 5 seconds · Last saved {active.updated}</p>
                    <Button size="sm" className="gap-1.5" onClick={saveNote}><Check className="h-3.5 w-3.5" /> Save</Button>
                  </div>
                </>
              ) : (
                <div className="flex-1 grid place-items-center text-sm text-muted-foreground">Select or create a note to start writing.</div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}

function NoteListItem({ note, active, onClick, onPin, notebookColor }: {
  note: Note;
  active: boolean;
  onClick: () => void;
  onPin: () => void;
  notebookColor: Record<string, string>;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-left rounded-lg p-3 transition-all border",
        active ? "border-primary/40 bg-primary/[0.04] shadow-premium-xs" : "border-transparent hover:bg-muted/40 hover:border-border"
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-medium text-foreground truncate flex-1">{note.title || "Untitled"}</p>
        <span className="flex items-center gap-1 shrink-0">
          {note.starred && <Star className="h-3 w-3 text-[color:var(--warning)] fill-current" />}
          {note.pinned && <Pin className="h-3 w-3 text-primary" />}
        </span>
      </div>
      <p className="text-xs text-muted-foreground line-clamp-2 mt-1 leading-relaxed">{note.body.replace(/[#*\[\]]/g, "").trim() || "Empty note"}</p>
      <div className="flex items-center justify-between gap-2 mt-2">
        <div className="flex items-center gap-1 flex-wrap min-w-0">
          <span className="h-1.5 w-1.5 rounded-full shrink-0" style={{ background: notebookColor[note.notebook] }} />
          {note.tags.slice(0, 2).map((t) => (
            <span key={t} className="text-[9px] text-muted-foreground">#{t}</span>
          ))}
          {note.tags.length > 2 && <span className="text-[9px] text-muted-foreground">+{note.tags.length - 2}</span>}
        </div>
        <span className="text-[9px] text-muted-foreground shrink-0">{note.updated}</span>
      </div>
    </button>
  );
}
