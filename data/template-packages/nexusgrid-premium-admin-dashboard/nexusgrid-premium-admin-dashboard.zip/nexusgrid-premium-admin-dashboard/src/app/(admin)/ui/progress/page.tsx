"use client";

import * as React from "react";
import {
  Loader2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Info,
  Upload,
  Download,
  Cpu,
  HardDrive,
  Cloud,
  Database,
  Zap,
  Sparkles,
  ShoppingCart,
  RefreshCw,
  TrendingUp,
  Activity,
  Server,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RadialProgress } from "@/components/charts";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function ColorProgress({
  value,
  color = "primary",
  label,
}: {
  value: number;
  color?: "primary" | "success" | "warning" | "destructive" | "info" | "violet";
  label?: string;
}) {
  const toneClass = {
    primary: "[&>div]:bg-primary",
    success: "[&>div]:bg-[color:var(--success)]",
    warning: "[&>div]:bg-[color:var(--warning)]",
    destructive: "[&>div]:bg-destructive",
    info: "[&>div]:bg-[color:var(--info)]",
    violet: "[&>div]:bg-violet-500",
  };
  return (
    <div className="space-y-1.5">
      {label && (
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">{label}</span>
          <span className="font-medium tabular-nums">{value}%</span>
        </div>
      )}
      <Progress value={value} className={cn(toneClass[color])} />
    </div>
  );
}

export default function ProgressPage() {
  const [indeterminate, setIndeterminate] = React.useState(true);
  const [animatedValue, setAnimatedValue] = React.useState(0);

  React.useEffect(() => {
    const i = setInterval(() => setAnimatedValue((v) => (v >= 100 ? 0 : v + 1)), 60);
    return () => clearInterval(i);
  }, []);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Progress"
        description="Linear and circular indicators — values, indeterminate state, colors, steps and segments."
        icon={Loader2}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/progress" },
          { label: "Progress" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => { setIndeterminate(true); toast.success("Progress demo reset"); }}>
            <RefreshCw /> Reset demo
          </Button>
        }
      />

      {/* Linear progress */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Linear progress</CardTitle>
          <CardDescription>
            Default, with value label, and indeterminate state for unknown durations.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Default (no label)</span>
              <span className="text-muted-foreground">—</span>
            </div>
            <Progress value={62} />
          </div>

          <ColorProgress value={42} label="Uploading release-notes.pdf" color="primary" />
          <ColorProgress value={78} label="Compiling TypeScript" color="info" />
          <ColorProgress value={95} label="Almost done" color="warning" />

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Indeterminate</span>
              <Button variant="ghost" size="sm" className="h-5 text-[10px]" onClick={() => setIndeterminate((v) => !v)}>
                {indeterminate ? "Stop" : "Start"}
              </Button>
            </div>
            {indeterminate ? (
              <div className="relative h-2 w-full overflow-hidden rounded-full bg-primary/20">
                <div className="absolute h-full w-1/3 rounded-full bg-primary animate-[indeterminate_1.4s_ease-in-out_infinite]" style={{ animationName: "indeterminateBar" }} />
                <style>{`@keyframes indeterminateBar { 0% { left: -33%; } 100% { left: 100%; } }`}</style>
              </div>
            ) : (
              <Progress value={50} />
            )}
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Animated (auto-cycling)</span>
              <span className="font-medium tabular-nums">{animatedValue}%</span>
            </div>
            <Progress value={animatedValue} />
          </div>
        </CardContent>
      </Card>

      {/* Colors */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Progress colors</CardTitle>
          <CardDescription>
            Five semantic tones map to your theme tokens — primary, success, warning, info, destructive.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-5 md:grid-cols-2">
          <ColorProgress value={86} label="Primary — onboarding complete" color="primary" />
          <ColorProgress value={94} label="Success — tests passing" color="success" />
          <ColorProgress value={72} label="Warning — disk usage" color="warning" />
          <ColorProgress value={38} label="Info — cache warm-up" color="info" />
          <ColorProgress value={28} label="Destructive — error budget" color="destructive" />
          <ColorProgress value={64} label="Violet — feature flag rollout" color="violet" />
        </CardContent>
      </Card>

      {/* Circular / Radial */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Circular progress (RadialProgress)</CardTitle>
          <CardDescription>
            Shared chart component for circular meters — single value, color and label.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={84} color="var(--primary)" label="onboarding" sublabel="step 4 / 5" />
            <p className="text-xs text-muted-foreground">Onboarding progress</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={62} color="var(--success)" label="this month" sublabel="+8% vs last" />
            <p className="text-xs text-muted-foreground">Quota attainment</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={28} color="var(--warning)" label="remaining" sublabel="of 50 GB" />
            <p className="text-xs text-muted-foreground">Storage used</p>
          </div>
          <div className="flex flex-col items-center gap-2">
            <RadialProgress value={99} color="var(--info)" label="uptime" sublabel="30-day avg" />
            <p className="text-xs text-muted-foreground">Service uptime</p>
          </div>
        </CardContent>
      </Card>

      {/* Stepped */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Stepped progress</CardTitle>
          <CardDescription>
            Multi-step indicator with completed, active and upcoming states — used in wizards and checkouts.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {[
            { steps: ["Account", "Profile", "Address", "Payment", "Review"], active: 2 },
            { steps: ["Cart", "Shipping", "Payment", "Confirmation"], active: 4 },
            { steps: ["Connect repo", "Configure build", "Deploy", "Verify"], active: 1 },
          ].map((flow, fi) => (
            <div key={fi} className="space-y-2">
              <p className="text-xs text-muted-foreground">Flow {fi + 1}</p>
              <div className="flex items-center">
                {flow.steps.map((step, i) => {
                  const isLast = i === flow.steps.length - 1;
                  const isComplete = i < flow.active - 1;
                  const isActive = i === flow.active - 1;
                  return (
                    <React.Fragment key={step}>
                      <div className="flex flex-col items-center gap-1.5">
                        <div
                          className={cn(
                            "grid h-8 w-8 place-items-center rounded-full text-xs font-medium border-2 transition-colors",
                            isComplete && "bg-primary border-primary text-primary-foreground",
                            isActive && "border-primary text-primary bg-primary/10",
                            !isComplete && !isActive && "border-border text-muted-foreground"
                          )}
                        >
                          {isComplete ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
                        </div>
                        <span
                          className={cn(
                            "text-[10px] text-center w-16 truncate",
                            (isComplete || isActive) ? "text-foreground font-medium" : "text-muted-foreground"
                          )}
                        >
                          {step}
                        </span>
                      </div>
                      {!isLast && (
                        <div className="flex-1 h-0.5 mx-1 mb-5 -mt-7 bg-border relative overflow-hidden">
                          <div
                            className={cn(
                              "h-full transition-all",
                              isComplete ? "bg-primary w-full" : "bg-primary w-0"
                            )}
                          />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Multi-segment */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Multi-segment progress</CardTitle>
          <CardDescription>
            A single bar split into colored segments — great for budget, allocation and status breakdowns.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {[
            {
              label: "Marketing budget",
              total: "$48,000 / $50,000",
              segments: [
                { label: "Paid ads", value: 38, color: "bg-primary" },
                { label: "Content", value: 24, color: "bg-[color:var(--info)]" },
                { label: "Events", value: 18, color: "bg-violet-500" },
                { label: "Tools", value: 16, color: "bg-amber-500" },
                { label: "Remaining", value: 4, color: "bg-muted" },
              ],
            },
            {
              label: "Server allocation",
              total: "62 / 80 instances",
              segments: [
                { label: "Web", value: 28, color: "bg-primary" },
                { label: "API", value: 22, color: "bg-[color:var(--success)]" },
                { label: "Workers", value: 18, color: "bg-[color:var(--warning)]" },
                { label: "Free", value: 12, color: "bg-muted" },
              ],
            },
            {
              label: "Sprint effort",
              total: "186 / 240 story points",
              segments: [
                { label: "Done", value: 50, color: "bg-[color:var(--success)]" },
                { label: "In progress", value: 22, color: "bg-primary" },
                { label: "In review", value: 12, color: "bg-[color:var(--info)]" },
                { label: "To do", value: 16, color: "bg-muted" },
              ],
            },
          ].map((bar, i) => (
            <div key={i} className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">{bar.label}</span>
                <span className="text-muted-foreground tabular-nums">{bar.total}</span>
              </div>
              <div className="flex h-3 w-full overflow-hidden rounded-full bg-muted">
                {bar.segments.map((s, si) => (
                  <div
                    key={si}
                    className={cn("h-full transition-all", s.color)}
                    style={{ width: `${s.value}%` }}
                    title={`${s.label}: ${s.value}%`}
                  />
                ))}
              </div>
              <div className="flex flex-wrap gap-3 text-[11px]">
                {bar.segments.map((s, si) => (
                  <span key={si} className="inline-flex items-center gap-1.5 text-muted-foreground">
                    <span className={cn("h-2 w-2 rounded-sm", s.color)} />
                    {s.label} <span className="font-medium text-foreground">{s.value}%</span>
                  </span>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Live system stats */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Live system progress</CardTitle>
          <CardDescription>
            Real-world dashboard use case — CPU, memory, disk, network and quota meters.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[
            { icon: Cpu, label: "CPU usage", value: 42, tone: "primary", sub: "8 cores · 2.8 GHz avg" },
            { icon: HardDrive, label: "Memory", value: 78, tone: "warning", sub: "25.4 / 32 GB" },
            { icon: Database, label: "Disk", value: 64, tone: "info", sub: "1.9 / 3.0 TB" },
            { icon: Cloud, label: "Bandwidth", value: 28, tone: "success", sub: "412 Mbps of 1.5 Gbps" },
            { icon: Server, label: "API load", value: 56, tone: "primary", sub: "560 / 1000 req/min" },
            { icon: Zap, label: "Error budget", value: 18, tone: "destructive", sub: "burning fast" },
          ].map((s) => (
            <div key={s.label} className="rounded-lg border p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={cn(
                      "grid h-7 w-7 place-items-center rounded-md",
                      s.tone === "primary" && "bg-primary/15 text-primary",
                      s.tone === "warning" && "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
                      s.tone === "info" && "bg-[color:var(--info)]/15 text-[color:var(--info)]",
                      s.tone === "success" && "bg-[color:var(--success)]/15 text-[color:var(--success)]",
                      s.tone === "destructive" && "bg-destructive/15 text-destructive"
                    )}
                  >
                    <s.icon className="h-3.5 w-3.5" />
                  </div>
                  <span className="text-sm font-medium">{s.label}</span>
                </div>
                <span className="text-sm font-semibold tabular-nums">{s.value}%</span>
              </div>
              <ColorProgress value={s.value} color={s.tone as any} />
              <p className="text-[11px] text-muted-foreground">{s.sub}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Progress page · linear · colors · radial · stepped · multi-segment · live system meters
      </p>
    </div>
  );
}
