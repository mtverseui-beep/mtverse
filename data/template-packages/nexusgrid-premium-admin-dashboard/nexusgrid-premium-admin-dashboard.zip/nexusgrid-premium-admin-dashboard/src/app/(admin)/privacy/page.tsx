"use client";

import * as React from "react";
import {
  Shield,
  Printer,
  Download,
  ChevronRight,
  FileText,
  Lock,
  Cookie,
  Eye,
  UserCheck,
  AlertTriangle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

const SECTIONS = [
  { id: "introduction", title: "1. Introduction & Scope", icon: FileText },
  { id: "collection", title: "2. Information We Collect", icon: Eye },
  { id: "use", title: "3. How We Use Your Information", icon: UserCheck },
  { id: "sharing", title: "4. How We Share Information", icon: ChevronRight },
  { id: "cookies", title: "5. Cookies & Tracking Technologies", icon: Cookie },
  { id: "retention", title: "6. Data Retention", icon: Lock },
  { id: "security", title: "7. Security Measures", icon: Shield },
  { id: "rights", title: "8. Your Privacy Rights", icon: UserCheck },
  { id: "international", title: "9. International Data Transfers", icon: ChevronRight },
  { id: "children", title: "10. Children's Privacy", icon: Eye },
  { id: "changes", title: "11. Changes to This Policy", icon: FileText },
  { id: "contact", title: "12. Contact Information", icon: ChevronRight },
];

export default function PrivacyPage() {
  const handlePrint = () => {
    if (typeof window !== "undefined") window.print();
    toast.success("Opening print dialog");
  };

  return (
    <>
      <PageHeader
        title="Privacy Policy"
        description="How NexusGrid collects, uses, and protects your personal information. Your privacy is fundamental to how we build our product."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Privacy Policy" }]}
        icon={Shield}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handlePrint}>
              <Printer className="h-3.5 w-3.5" /> Print
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Downloading privacy.pdf")}>
              <Download className="h-3.5 w-3.5" /> Download PDF
            </Button>
          </>
        }
      />

      {/* META CARD */}
      <Card className="mb-6 border-primary/20">
        <CardContent className="p-5 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/10 text-primary shrink-0">
            <Shield className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <h2 className="text-base font-semibold">NexusGrid Privacy Policy</h2>
              <Badge variant="outline" className="text-[10px] gap-1 border-[color:var(--success)]/40 text-[color:var(--success)] bg-[color:var(--success)]/5">
                <Lock className="h-2.5 w-2.5" /> GDPR & CCPA Compliant
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">
              Last updated: <span className="font-medium text-foreground">June 28, 2026</span> · Effective from: <span className="font-medium text-foreground">July 1, 2026</span>
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0 text-xs text-muted-foreground">
            <Lock className="h-3.5 w-3.5" />
            <span>End-to-end encrypted</span>
          </div>
        </CardContent>
      </Card>

      {/* COMPLIANCE BADGES */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {[
          { label: "GDPR", desc: "EU compliant", tone: "primary" as const },
          { label: "CCPA", desc: "California compliant", tone: "violet" as const },
          { label: "SOC 2", desc: "Type II certified", tone: "success" as const },
          { label: "ISO 27001", desc: "Information security", tone: "warning" as const },
        ].map((b) => (
          <Card key={b.label} className="p-0">
            <CardContent className="p-3 flex items-center gap-2.5">
              <div className={
                "grid place-items-center h-9 w-9 rounded-lg shrink-0 " +
                (b.tone === "primary" ? "bg-primary/12 text-primary" :
                 b.tone === "violet" ? "bg-violet-500/12 text-violet-500" :
                 b.tone === "success" ? "bg-[color:var(--success)]/12 text-[color:var(--success)]" :
                 "bg-[color:var(--warning)]/15 text-[color:var(--warning)]")
              }>
                <Shield className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold leading-tight">{b.label}</p>
                <p className="text-[10px] text-muted-foreground leading-tight mt-0.5">{b.desc}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_240px] gap-6">
        {/* CONTENT */}
        <article className="min-w-0 space-y-6">
          <Card>
            <CardContent className="p-6 sm:p-8">
              <p className="text-sm text-muted-foreground italic leading-relaxed">
                NexusGrid, Inc. ("NexusGrid", "we", "us", or "our") is committed to protecting and respecting your privacy.
                This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you access
                our website, web application, mobile apps, and APIs (collectively, the "Service"). We act as the data
                controller for personal information we collect, and your use of the Service is also governed by our Terms
                of Service. Please read this Privacy Policy in conjunction with our Terms.
              </p>
            </CardContent>
          </Card>

          {SECTIONS.map((s) => (
            <Card key={s.id} id={s.id} className="scroll-mt-4">
              <CardContent className="p-6 sm:p-8">
                <div className="flex items-center gap-2.5 mb-4">
                  <div className="grid place-items-center h-8 w-8 rounded-lg bg-primary/10 text-primary shrink-0">
                    <s.icon className="h-4 w-4" />
                  </div>
                  <h2 className="text-lg font-semibold tracking-tight">{s.title}</h2>
                </div>
                <div className="space-y-3 text-sm leading-relaxed text-foreground/85">
                  {SECTIONS_CONTENT[s.id]}
                </div>
              </CardContent>
            </Card>
          ))}

          <Card className="border-[color:var(--warning)]/30 bg-[color:var(--warning)]/[0.03]">
            <CardContent className="p-6 flex items-start gap-3">
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--warning)]/15 text-[color:var(--warning)] shrink-0">
                <AlertTriangle className="h-4 w-4" />
              </div>
              <div className="text-sm">
                <p className="font-semibold mb-1">Exercise your privacy rights</p>
                <p className="text-muted-foreground">
                  To access, correct, delete, or export your personal information, email our Data Protection Officer at{" "}
                  <a href="mailto:privacy@nexusgrid.io" className="text-primary font-medium hover:underline">privacy@nexusgrid.io</a>{" "}
                  or use the privacy controls in your account settings.
                </p>
              </div>
            </CardContent>
          </Card>
        </article>

        {/* TABLE OF CONTENTS */}
        <aside className="hidden lg:block lg:sticky lg:top-4 lg:self-start lg:max-h-[calc(100vh-2rem)] lg:overflow-y-auto">
          <Card>
            <CardContent className="p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-1.5">Table of contents</p>
              <nav className="space-y-0.5">
                {SECTIONS.map((s, i) => (
                  <a
                    key={s.id}
                    href={`#${s.id}`}
                    className="flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors group"
                  >
                    <span className="text-[10px] tabular-nums text-muted-foreground/60 w-4">{i + 1}</span>
                    <span className="flex-1 line-clamp-1">{s.title.replace(/^\d+\.\s/, "")}</span>
                    <ChevronRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                ))}
              </nav>
              <Separator className="my-3" />
              <div className="px-2.5 py-1.5 space-y-2">
                <p className="text-[11px] text-muted-foreground">Related documents</p>
                <a href="/terms" className="block text-xs text-primary hover:underline">Terms of Service</a>
                <a href="/documentation" className="block text-xs text-primary hover:underline">Documentation</a>
                <a href="/contact-support" className="block text-xs text-primary hover:underline">Contact Support</a>
              </div>
            </CardContent>
          </Card>
        </aside>
      </div>
    </>
  );
}

const SECTIONS_CONTENT: Record<string, React.ReactNode[]> = {
  introduction: [
    <p key="p1">This Privacy Policy describes the types of information we collect when you use NexusGrid, how we use that information, with whom we share it, and the choices and controls you have over your data. We have designed our privacy practices to comply with the European Union's General Data Protection Regulation (GDPR), the California Consumer Privacy Act (CCPA), and other applicable data protection laws.</p>,
    <p key="p2">By accessing or using the Service, you consent to the collection, use, and disclosure of your information as described in this Privacy Policy. If you do not agree with our practices, please do not use the Service. If you are a NexusGrid workspace administrator, you may have additional obligations under your agreement with us and applicable law.</p>,
  ],
  collection: [
    <p key="p1">We collect several categories of information to provide and improve the Service:</p>,
    <p key="p2" className="font-medium text-foreground">Information you provide directly:</p>,
    <ul key="ul1" className="list-disc pl-5 space-y-1.5">
      <li><strong>Account information:</strong> Name, email address, password (hashed), and role when you create an account.</li>
      <li><strong>Profile information:</strong> Job title, department, profile photo, phone number, and timezone.</li>
      <li><strong>Workspace details:</strong> Organization name, billing address, and tax identification numbers.</li>
      <li><strong>Customer Content:</strong> Any data, files, messages, or other content you upload, create, or store in the Service.</li>
      <li><strong>Communications:</strong> Records of your support requests, feedback, and other correspondence with us.</li>
    </ul>,
    <p key="p3" className="font-medium text-foreground">Information collected automatically:</p>,
    <ul key="ul2" className="list-disc pl-5 space-y-1.5">
      <li><strong>Usage data:</strong> Pages visited, features used, time spent, click patterns, and search queries.</li>
      <li><strong>Device information:</strong> IP address, browser type and version, operating system, screen resolution, and device identifiers.</li>
      <li><strong>Log data:</strong> Server logs containing timestamps, request URLs, and HTTP status codes for security and debugging purposes.</li>
      <li><strong>Location data:</strong> Approximate location derived from your IP address, never precise GPS coordinates.</li>
    </ul>,
  ],
  use: [
    <p key="p1">We use the information we collect for the following legitimate business purposes:</p>,
    <ul key="ul" className="list-disc pl-5 space-y-1.5">
      <li>To provide, operate, maintain, and improve the Service and its features;</li>
      <li>To create and manage your account, authenticate your identity, and enforce security controls;</li>
      <li>To process payments, issue invoices, and prevent fraudulent transactions;</li>
      <li>To communicate with you about product updates, security alerts, and policy changes;</li>
      <li>To monitor and analyze usage trends, performance metrics, and feature adoption;</li>
      <li>To detect, investigate, and prevent fraud, abuse, security incidents, and violations of our Terms;</li>
      <li>To comply with legal obligations, respond to lawful requests, and protect our rights and property;</li>
      <li>To provide customer support and respond to your inquiries and requests.</li>
    </ul>,
    <p key="p2">We process your information on the legal bases of contract performance, legitimate interests, legal compliance, and your consent where required. You may withdraw consent for optional processing at any time from your account settings.</p>,
  ],
  sharing: [
    <p key="p1">We do not sell your personal information. We share information only in the following limited circumstances:</p>,
    <ul key="ul" className="list-disc pl-5 space-y-1.5">
      <li><strong>Service providers:</strong> Third parties that process data on our behalf, including cloud infrastructure (Amazon Web Services), payment processing (Stripe), email delivery (Postmark), error monitoring (Sentry), and analytics (PostHog). All providers are bound by data processing agreements.</li>
      <li><strong>Within your workspace:</strong> Other members of your workspace may see information you share within the Service, including Customer Content and activity.</li>
      <li><strong>Legal compliance:</strong> When required by law, court order, or government regulation, or to protect the rights, property, or safety of NexusGrid, our users, or others.</li>
      <li><strong>Business transfers:</strong> In connection with a merger, acquisition, asset sale, or similar transaction, we may transfer information to the successor entity, subject to confidentiality obligations.</li>
      <li><strong>Aggregated data:</strong> We may share anonymized, aggregated statistics that cannot identify individual users.</li>
    </ul>,
  ],
  cookies: [
    <p key="p1">We use cookies and similar tracking technologies (collectively, "cookies") to operate and improve the Service. Cookies are small text files stored on your device. We use the following categories:</p>,
    <ul key="ul" className="list-disc pl-5 space-y-1.5">
      <li><strong>Strictly necessary:</strong> Required for the Service to function (e.g., session authentication, load balancing). Cannot be disabled.</li>
      <li><strong>Functional:</strong> Remember your preferences, such as theme, language, and last-viewed project.</li>
      <li><strong>Analytics:</strong> Help us understand how the Service is used so we can improve performance and design.</li>
      <li><strong>Marketing:</strong> Used to measure the effectiveness of campaigns and show relevant content. Opt-in only.</li>
    </ul>,
    <p key="p2">You can control cookies through your browser settings and our cookie preference center. Disabling strictly necessary cookies will prevent you from logging in or using the Service.</p>,
  ],
  retention: [
    <p key="p1">We retain your personal information for as long as your account is active or as needed to provide the Service. After account termination, we delete Customer Content within thirty (30) days, except for:</p>,
    <ul key="ul" className="list-disc pl-5 space-y-1.5">
      <li>Records needed to resolve disputes, enforce agreements, and comply with legal obligations (retained for up to seven (7) years);</li>
      <li>Backups that may contain residual copies of your data, which are deleted within ninety (90) days following termination;</li>
      <li>Aggregated and anonymized data that cannot be linked back to you.</li>
    </ul>,
    <p key="p2">When personal information is no longer needed for the purposes described in this policy, we delete it or render it anonymous.</p>,
  ],
  security: [
    <p key="p1">We implement industry-standard technical and organizational measures to protect your information against unauthorized access, alteration, disclosure, or destruction:</p>,
    <ul key="ul" className="list-disc pl-5 space-y-1.5">
      <li><strong>Encryption:</strong> All data is encrypted in transit using TLS 1.3 and at rest using AES-256.</li>
      <li><strong>Access controls:</strong> Role-based access with least-privilege defaults; all internal access is logged and reviewed monthly.</li>
      <li><strong>Authentication:</strong> Multi-factor authentication is enforced for all internal systems and offered to all customers.</li>
      <li><strong>Monitoring:</strong> 24/7 intrusion detection, anomaly detection, and automated alerting on suspicious activity.</li>
      <li><strong>Audits:</strong> Annual SOC 2 Type II audits and penetration tests by independent third parties.</li>
      <li><strong>Incident response:</strong> A documented incident response plan with notification to affected users within 72 hours of a confirmed breach.</li>
    </ul>,
    <p key="p2">No method of transmission over the internet is 100% secure. While we strive to protect your information, we cannot guarantee absolute security.</p>,
  ],
  rights: [
    <p key="p1">Depending on your location, you may have the following rights regarding your personal information:</p>,
    <ul key="ul" className="list-disc pl-5 space-y-1.5">
      <li><strong>Access:</strong> Request a copy of the personal information we hold about you.</li>
      <li><strong>Rectification:</strong> Request correction of inaccurate or incomplete information.</li>
      <li><strong>Erasure:</strong> Request deletion of your personal information, subject to legal retention requirements.</li>
      <li><strong>Restriction:</strong> Request that we limit processing of your information in certain circumstances.</li>
      <li><strong>Portability:</strong> Receive your information in a structured, machine-readable format.</li>
      <li><strong>Objection:</strong> Object to processing based on legitimate interests or for direct marketing.</li>
      <li><strong>Withdrawal of consent:</strong> Withdraw consent at any time without affecting the lawfulness of processing prior to withdrawal.</li>
    </ul>,
    <p key="p2">To exercise any of these rights, contact us at <a href="mailto:privacy@nexusgrid.io" className="text-primary hover:underline">privacy@nexusgrid.io</a>. We respond to verifiable requests within thirty (30) days. If you are not satisfied with our response, you have the right to lodge a complaint with your local data protection authority.</p>,
  ],
  international: [
    <p key="p1">NexusGrid is based in the United States and processes data globally. If you access the Service from outside the United States, your information may be transferred to and processed in the United States or other countries where we or our service providers operate.</p>,
    <p key="p2">For transfers from the European Economic Area, the United Kingdom, and Switzerland, we rely on Standard Contractual Clauses approved by the European Commission, the UK Information Commissioner, and the Swiss Federal Data Protection and Information Commissioner. We have also implemented supplementary measures, including encryption and access controls, to ensure an adequate level of protection.</p>,
  ],
  children: [
    <p key="p1">The Service is not directed to, and is not intended for use by, anyone under the age of sixteen (16). We do not knowingly collect personal information from children. If you believe we have collected information from a child, please contact us at <a href="mailto:privacy@nexusgrid.io" className="text-primary hover:underline">privacy@nexusgrid.io</a>, and we will promptly delete such information.</p>,
  ],
  changes: [
    <p key="p1">We may update this Privacy Policy from time to time to reflect changes in our practices, technology, legal requirements, or other factors. We will notify you of material changes by email and by prominent notice within the Service at least thirty (30) days before the changes take effect.</p>,
    <p key="p2">We encourage you to review this policy periodically. The "Last updated" date at the top of this page indicates when the policy was last revised. Your continued use of the Service after changes take effect constitutes acceptance of the updated policy.</p>,
  ],
  contact: [
    <p key="p1">If you have any questions, requests, or concerns about this Privacy Policy or our data practices, our Data Protection Officer is available at:</p>,
    <p key="p2" className="rounded-lg border border-border bg-muted/30 p-3 font-medium">
      NexusGrid, Inc.<br />
      Attn: Data Protection Officer<br />
      548 Market Street, #62114<br />
      San Francisco, CA 94104<br />
      Email: <a href="mailto:privacy@nexusgrid.io" className="text-primary hover:underline">privacy@nexusgrid.io</a><br />
      Phone: +1 (415) 555-0143
    </p>,
    <p key="p3">For EU residents, our representative under Article 27 of the GDPR can be reached at the same address. We aim to respond to all inquiries within thirty (30) days.</p>,
  ],
};
