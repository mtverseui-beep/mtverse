"use client";

import * as React from "react";
import {
  Sparkles,
  Search,
  Copy,
  Check,
  X,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CornerUpRight,
  MoveRight,
  Plus,
  Minus,
  Edit3,
  Trash2,
  Save,
  Copy as CopyIcon,
  Clipboard,
  Scissors,
  Download,
  Upload,
  RefreshCw,
  RotateCcw,
  Search as SearchIcon,
  Filter,
  Settings,
  SlidersHorizontal,
  Mail,
  MessageSquare,
  Bell,
  Phone,
  Video,
  Send,
  AtSign,
  Share2,
  FileText,
  Folder,
  FolderOpen,
  FilePlus,
  FileEdit,
  User,
  Users,
  UserPlus,
  UserMinus,
  UserCheck,
  Contact,
  BadgeCheck,
  DollarSign,
  CreditCard,
  TrendingUp,
  TrendingDown,
  Wallet,
  Receipt,
  PiggyBank,
  Coins,
  AlertTriangle,
  Info,
  AlertCircle,
  CircleCheck,
  CircleX,
  OctagonAlert,
  Lightbulb,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  KeyRound,
  Shield,
  ShieldCheck,
  Globe,
  MapPin,
  Compass,
  Navigation,
  Calendar,
  Clock,
  Timer,
  Watch,
  Sun,
  Moon,
  Star,
  Cloud,
  CloudRain,
  Wind,
  Thermometer,
  Droplet,
  Zap,
  Battery,
  Camera,
  Image as ImageIcon,
  Film,
  Music,
  Mic,
  Volume2,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Headphones,
  Code,
  Github,
  GitBranch,
  GitCommit,
  GitPullRequest,
  Terminal,
  Bug,
  Cpu,
  Server,
  Database,
  HardDrive,
  Wifi,
  Bluetooth,
  Activity,
  BarChart3,
  PieChart,
  LineChart,
  Radar,
  ShoppingCart,
  Package,
  Tag,
  ShoppingBag,
  Store,
  Gift,
  BookOpen,
  GraduationCap,
  Library,
  PenTool,
  Pencil,
  Highlighter,
  Palette,
  Brush,
  Layers,
  Grid,
  Layout,
  LayoutPanelTop,
  Square,
  Circle,
  Triangle,
  Heart,
  ThumbsUp,
  Smile,
  Frown,
  Award,
  Trophy,
  Medal,
  Flag,
  Bookmark,
  Target,
  Crosshair,
  Anchor,
  Rocket,
  Plane,
  Truck,
  Bike,
  Car,
  Train,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type IconEntry = { name: string; Icon: LucideIcon };

const categories: { title: string; description: string; icons: IconEntry[] }[] = [
  {
    title: "Navigation",
    description: "Arrows, chevrons and directional movement",
    icons: [
      { name: "ArrowRight", Icon: ArrowRight },
      { name: "ArrowLeft", Icon: ArrowLeft },
      { name: "ArrowUp", Icon: ArrowUp },
      { name: "ArrowDown", Icon: ArrowDown },
      { name: "ChevronUp", Icon: ChevronUp },
      { name: "ChevronDown", Icon: ChevronDown },
      { name: "ChevronLeft", Icon: ChevronLeft },
      { name: "ChevronRight", Icon: ChevronRight },
      { name: "CornerUpRight", Icon: CornerUpRight },
      { name: "MoveRight", Icon: MoveRight },
      { name: "Compass", Icon: Compass },
      { name: "Navigation", Icon: Navigation },
    ],
  },
  {
    title: "Actions",
    description: "Common verbs — create, edit, delete, save, share",
    icons: [
      { name: "Plus", Icon: Plus },
      { name: "Minus", Icon: Minus },
      { name: "Edit3", Icon: Edit3 },
      { name: "Trash2", Icon: Trash2 },
      { name: "Save", Icon: Save },
      { name: "Copy", Icon: CopyIcon },
      { name: "Clipboard", Icon: Clipboard },
      { name: "Scissors", Icon: Scissors },
      { name: "Download", Icon: Download },
      { name: "Upload", Icon: Upload },
      { name: "RefreshCw", Icon: RefreshCw },
      { name: "RotateCcw", Icon: RotateCcw },
      { name: "Search", Icon: SearchIcon },
      { name: "Filter", Icon: Filter },
      { name: "Settings", Icon: Settings },
      { name: "SlidersHorizontal", Icon: SlidersHorizontal },
    ],
  },
  {
    title: "Communication",
    description: "Email, chat, notifications and social",
    icons: [
      { name: "Mail", Icon: Mail },
      { name: "MessageSquare", Icon: MessageSquare },
      { name: "Bell", Icon: Bell },
      { name: "Phone", Icon: Phone },
      { name: "Video", Icon: Video },
      { name: "Send", Icon: Send },
      { name: "AtSign", Icon: AtSign },
      { name: "Share2", Icon: Share2 },
      { name: "Headphones", Icon: Headphones },
      { name: "Mic", Icon: Mic },
      { name: "Volume2", Icon: Volume2 },
    ],
  },
  {
    title: "Files & documents",
    description: "Files, folders and document operations",
    icons: [
      { name: "FileText", Icon: FileText },
      { name: "Folder", Icon: Folder },
      { name: "FolderOpen", Icon: FolderOpen },
      { name: "FilePlus", Icon: FilePlus },
      { name: "FileEdit", Icon: FileEdit },
      { name: "Upload", Icon: Upload },
      { name: "Download", Icon: Download },
      { name: "BookOpen", Icon: BookOpen },
      { name: "Library", Icon: Library },
      { name: "PenTool", Icon: PenTool },
      { name: "Pencil", Icon: Pencil },
      { name: "Highlighter", Icon: Highlighter },
    ],
  },
  {
    title: "Users & people",
    description: "Single users, groups and member management",
    icons: [
      { name: "User", Icon: User },
      { name: "Users", Icon: Users },
      { name: "UserPlus", Icon: UserPlus },
      { name: "UserMinus", Icon: UserMinus },
      { name: "UserCheck", Icon: UserCheck },
      { name: "Contact", Icon: Contact },
      { name: "BadgeCheck", Icon: BadgeCheck },
    ],
  },
  {
    title: "Finance & commerce",
    description: "Money, payments, products and sales",
    icons: [
      { name: "DollarSign", Icon: DollarSign },
      { name: "CreditCard", Icon: CreditCard },
      { name: "TrendingUp", Icon: TrendingUp },
      { name: "TrendingDown", Icon: TrendingDown },
      { name: "Wallet", Icon: Wallet },
      { name: "Receipt", Icon: Receipt },
      { name: "PiggyBank", Icon: PiggyBank },
      { name: "Coins", Icon: Coins },
      { name: "ShoppingCart", Icon: ShoppingCart },
      { name: "ShoppingBag", Icon: ShoppingBag },
      { name: "Store", Icon: Store },
      { name: "Package", Icon: Package },
      { name: "Tag", Icon: Tag },
      { name: "Gift", Icon: Gift },
    ],
  },
  {
    title: "Status & feedback",
    description: "Success, warning, error and informational indicators",
    icons: [
      { name: "Check", Icon: Check },
      { name: "X", Icon: X },
      { name: "AlertTriangle", Icon: AlertTriangle },
      { name: "Info", Icon: Info },
      { name: "AlertCircle", Icon: AlertCircle },
      { name: "CircleCheck", Icon: CircleCheck },
      { name: "CircleX", Icon: CircleX },
      { name: "OctagonAlert", Icon: OctagonAlert },
      { name: "Lightbulb", Icon: Lightbulb },
      { name: "Award", Icon: Award },
      { name: "Trophy", Icon: Trophy },
      { name: "Medal", Icon: Medal },
    ],
  },
  {
    title: "Security",
    description: "Locks, keys, shields and access control",
    icons: [
      { name: "Lock", Icon: Lock },
      { name: "Unlock", Icon: Unlock },
      { name: "KeyRound", Icon: KeyRound },
      { name: "Shield", Icon: Shield },
      { name: "ShieldCheck", Icon: ShieldCheck },
      { name: "Eye", Icon: Eye },
      { name: "EyeOff", Icon: EyeOff },
    ],
  },
  {
    title: "Time & date",
    description: "Calendars, clocks, timers and natural cycles",
    icons: [
      { name: "Calendar", Icon: Calendar },
      { name: "Clock", Icon: Clock },
      { name: "Timer", Icon: Timer },
      { name: "Watch", Icon: Watch },
      { name: "Sun", Icon: Sun },
      { name: "Moon", Icon: Moon },
      { name: "Star", Icon: Star },
    ],
  },
  {
    title: "Weather & nature",
    description: "Atmospheric and environmental glyphs",
    icons: [
      { name: "Cloud", Icon: Cloud },
      { name: "CloudRain", Icon: CloudRain },
      { name: "Wind", Icon: Wind },
      { name: "Thermometer", Icon: Thermometer },
      { name: "Droplet", Icon: Droplet },
      { name: "Zap", Icon: Zap },
      { name: "Battery", Icon: Battery },
    ],
  },
  {
    title: "Media",
    description: "Cameras, images, audio and playback controls",
    icons: [
      { name: "Camera", Icon: Camera },
      { name: "Image", Icon: ImageIcon },
      { name: "Film", Icon: Film },
      { name: "Music", Icon: Music },
      { name: "Mic", Icon: Mic },
      { name: "Play", Icon: Play },
      { name: "Pause", Icon: Pause },
      { name: "SkipForward", Icon: SkipForward },
      { name: "SkipBack", Icon: SkipBack },
    ],
  },
  {
    title: "Developer",
    description: "Source control, build and runtime primitives",
    icons: [
      { name: "Code", Icon: Code },
      { name: "Github", Icon: Github },
      { name: "GitBranch", Icon: GitBranch },
      { name: "GitCommit", Icon: GitCommit },
      { name: "GitPullRequest", Icon: GitPullRequest },
      { name: "Terminal", Icon: Terminal },
      { name: "Bug", Icon: Bug },
      { name: "Cpu", Icon: Cpu },
      { name: "Server", Icon: Server },
      { name: "Database", Icon: Database },
      { name: "HardDrive", Icon: HardDrive },
      { name: "Wifi", Icon: Wifi },
      { name: "Bluetooth", Icon: Bluetooth },
    ],
  },
  {
    title: "Charts & analytics",
    description: "Visualization types and metric glyphs",
    icons: [
      { name: "Activity", Icon: Activity },
      { name: "BarChart3", Icon: BarChart3 },
      { name: "PieChart", Icon: PieChart },
      { name: "LineChart", Icon: LineChart },
      { name: "Radar", Icon: Radar },
      { name: "Target", Icon: Target },
      { name: "Crosshair", Icon: Crosshair },
    ],
  },
  {
    title: "Layout & shapes",
    description: "Containers, primitives and design elements",
    icons: [
      { name: "Layers", Icon: Layers },
      { name: "Grid", Icon: Grid },
      { name: "Layout", Icon: Layout },
      { name: "LayoutPanelTop", Icon: LayoutPanelTop },
      { name: "Square", Icon: Square },
      { name: "Circle", Icon: Circle },
      { name: "Triangle", Icon: Triangle },
      { name: "Palette", Icon: Palette },
      { name: "Brush", Icon: Brush },
      { name: "Flag", Icon: Flag },
      { name: "Bookmark", Icon: Bookmark },
      { name: "Anchor", Icon: Anchor },
    ],
  },
  {
    title: "Emotions & social",
    description: "Reactions, sentiment and affinity",
    icons: [
      { name: "Heart", Icon: Heart },
      { name: "ThumbsUp", Icon: ThumbsUp },
      { name: "Smile", Icon: Smile },
      { name: "Frown", Icon: Frown },
      { name: "Star", Icon: Star },
      { name: "GraduationCap", Icon: GraduationCap },
    ],
  },
  {
    title: "Transportation",
    description: "Vehicles and movement metaphors",
    icons: [
      { name: "Rocket", Icon: Rocket },
      { name: "Plane", Icon: Plane },
      { name: "Truck", Icon: Truck },
      { name: "Bike", Icon: Bike },
      { name: "Car", Icon: Car },
      { name: "Train", Icon: Train },
      { name: "Globe", Icon: Globe },
      { name: "MapPin", Icon: MapPin },
    ],
  },
];

const ALL_ICONS = categories.flatMap((c) => c.icons);
const TOTAL_ICONS = ALL_ICONS.length;

export default function IconsPage() {
  const [query, setQuery] = React.useState("");
  const [activeCategory, setActiveCategory] = React.useState<string>("All");
  const [copied, setCopied] = React.useState<string | null>(null);

  const filteredCategories = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return categories
      .filter((c) => activeCategory === "All" || c.title === activeCategory)
      .map((c) => ({
        ...c,
        icons: c.icons.filter((i) => !q || i.name.toLowerCase().includes(q) || c.title.toLowerCase().includes(q)),
      }))
      .filter((c) => c.icons.length > 0);
  }, [query, activeCategory]);

  const visibleCount = filteredCategories.reduce((sum, c) => sum + c.icons.length, 0);

  const copy = async (name: string) => {
    try {
      await navigator.clipboard.writeText(name);
      setCopied(name);
      toast.success(`Copied "${name}"`, { description: "Paste it into your import statement." });
      setTimeout(() => setCopied((c) => (c === name ? null : c)), 1500);
    } catch {
      toast.error("Clipboard not available — copy manually.");
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Icons Showcase"
        description={`${TOTAL_ICONS} lucide-react icons across ${categories.length} categories — click any icon to copy its name.`}
        icon={Sparkles}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/icons" },
          { label: "Icons" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Full icon list exported to clipboard")}>
            <Copy /> Copy all
          </Button>
        }
      />

      {/* Search + filters */}
      <Card>
        <CardContent className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between py-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search icons by name…"
              className="pl-9"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 grid h-6 w-6 place-items-center rounded-md text-muted-foreground hover:bg-foreground/5"
                aria-label="Clear search"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant={activeCategory === "All" ? "default" : "outline"} className="cursor-pointer" onClick={() => setActiveCategory("All")}>
              All ({TOTAL_ICONS})
            </Badge>
            {categories.map((c) => (
              <Badge
                key={c.title}
                variant={activeCategory === c.title ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setActiveCategory(c.title)}
              >
                {c.title}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Results counter */}
      <div className="flex items-center justify-between text-xs text-muted-foreground px-1">
        <span>
          Showing <strong className="text-foreground tabular-nums">{visibleCount}</strong> of {TOTAL_ICONS} icons
        </span>
        {query && (
          <button className="hover:text-foreground" onClick={() => setQuery("")}>
            Clear search
          </button>
        )}
      </div>

      {/* Icon grid */}
      {filteredCategories.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <Search className="mx-auto h-8 w-8 text-muted-foreground mb-3" />
            <p className="text-sm font-medium">No icons found</p>
            <p className="text-xs text-muted-foreground mt-1">
              Try a different search term — e.g. "arrow", "user", or "chart".
            </p>
          </CardContent>
        </Card>
      ) : (
        filteredCategories.map((cat) => (
          <Card key={cat.title}>
            <CardHeader>
              <div className="flex items-baseline justify-between">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    {cat.title}
                    <Badge variant="secondary" className="text-[10px]">{cat.icons.length}</Badge>
                  </CardTitle>
                  <CardDescription>{cat.description}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10 gap-2">
                {cat.icons.map(({ name, Icon }) => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => copy(name)}
                    className="group relative flex flex-col items-center gap-2 rounded-lg border bg-card p-3 transition-all hover:border-primary/40 hover:bg-accent hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    title={`Click to copy: ${name}`}
                  >
                    <Icon className="h-5 w-5 text-foreground transition-colors group-hover:text-primary" />
                    <span className="text-[10px] text-muted-foreground text-center truncate w-full font-mono">
                      {name}
                    </span>
                    {copied === name ? (
                      <span className="absolute top-1 right-1 grid h-4 w-4 place-items-center rounded-full bg-[color:var(--success)] text-white">
                        <Check className="h-2.5 w-2.5" />
                      </span>
                    ) : (
                      <span className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Copy className="h-3 w-3 text-muted-foreground" />
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        ))
      )}

      {/* Usage card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Usage</CardTitle>
          <CardDescription>
            Import any icon directly from <code className="rounded bg-muted px-1 text-xs">lucide-react</code>.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border bg-muted/40 p-4 font-mono text-xs leading-relaxed overflow-x-auto">
            <p><span className="text-muted-foreground">{"// Single import"}</span></p>
            <p><span className="text-rose-500">import</span> <span className="text-foreground">{"{ Sparkles }"}</span> <span className="text-rose-500">from</span> <span className="text-emerald-600">"lucide-react"</span>;</p>
            <br />
            <p><span className="text-muted-foreground">{"// Usage in JSX"}</span></p>
            <p><span className="text-violet-500">&lt;Sparkles</span> <span className="text-amber-600">className</span>=<span className="text-emerald-600">"h-4 w-4 text-primary"</span> <span className="text-violet-500">/&gt;</span></p>
            <br />
            <p><span className="text-muted-foreground">{"// Type-safe icon prop"}</span></p>
            <p><span className="text-rose-500">import</span> <span className="text-foreground">{"{ type LucideIcon }"}</span> <span className="text-rose-500">from</span> <span className="text-emerald-600">"lucide-react"</span>;</p>
            <p><span className="text-rose-500">function</span> <span className="text-amber-600">MyButton</span>(<span className="text-foreground">{"{ icon: Icon }: { icon: LucideIcon }"}</span>) <span className="text-foreground">{"{"}</span></p>
            <p className="pl-4"><span className="text-rose-500">return</span> <span className="text-violet-500">&lt;Icon /&gt;</span>;</p>
            <p><span className="text-foreground">{"}"}</span></p>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Icons page · {TOTAL_ICONS} icons · {categories.length} categories · click-to-copy · live search filter
      </p>
    </div>
  );
}
