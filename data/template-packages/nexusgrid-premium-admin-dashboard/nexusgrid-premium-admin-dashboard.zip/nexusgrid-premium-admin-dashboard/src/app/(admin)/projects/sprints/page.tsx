"use client";

import * as React from "react";
import {
  LayoutGrid,
  Plus,
  Calendar,
  Zap,
  TrendingDown,
  Flag,
  Users,
  Clock,
  Gauge,
  Play,
  Pause,
  CheckCircle2,
  Loader2,
  AlertTriangle,
  ChevronRight,
  MoreHorizontal,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LineTrendChart } from "@/components/charts";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Sprint data ---------- */

const sprint = {
  name: "Sprint 24 — Velocity Push",
  goal: "Ship Atlas mobile redesign beta + close 80% of Vertex payment criticals",
  startDate: "Jun 24, 2026",
  endDate: "Jul 08, 2026",
  daysTotal: 10,
  daysElapsed: 7,
  daysRemaining: 3,
  pointsCommitted: 240,
  pointsCompleted: 178,
};

// Burndown — 10 working days, ideal linear from 240 → 0, actual remaining
const burndown = [
  { day: "D1", ideal: 216, actual: 224 },
  { day: "D2", ideal: 192, actual: 208 },
  { day: "D3", ideal: 168, actual: 192 },
  { day: "D4", ideal: 144, actual: 176 },
  { day: "D5", ideal: 120, actual: 142 },
  { day: "D6", ideal: 96, actual: 118 },
  { day: "D7", ideal: 72, actual: 62 },
  { day: "D8", ideal: 48, actual: null },
  { day: "D9", ideal: 24, actual: null },
  { day: "D10", ideal: 0, actual: null },
];

type SprintColumnKey = "todo" | "in-progress" | "done";

type SprintTask = {
  id: string;
  title: string;
  points: number;
  assignee: string;
  assigneeAvatar: string;
  column: SprintColumnKey;
  blocked?: boolean;
};

const teamMembers = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", capacity: 32, allocated: 28, points: 42, role: "Frontend Lead" },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", capacity: 32, allocated: 30, points: 38, role: "iOS Engineer" },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", capacity: 32, allocated: 34, points: 44, role: "Backend Lead" },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", capacity: 32, allocated: 24, points: 28, role: "DevOps" },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", capacity: 32, allocated: 32, points: 36, role: "Designer" },
  { name: "David Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", capacity: 24, allocated: 22, points: 30, role: "Data Engineer" },
];

const sprintTasks: SprintTask[] = [
  // To Do
  { id: "ST-301", title: "Onboarding tour redesign", points: 8, assignee: teamMembers[4].name, assigneeAvatar: teamMembers[4].avatar, column: "todo" },
  { id: "ST-302", title: "Push notification A/B framework", points: 13, assignee: teamMembers[0].name, assigneeAvatar: teamMembers[0].avatar, column: "todo" },
  { id: "ST-303", title: "DNS failover runbook drill", points: 5, assignee: teamMembers[3].name, assigneeAvatar: teamMembers[3].avatar, column: "todo" },
  { id: "ST-304", title: "Lead dedup rules engine", points: 8, assignee: teamMembers[5].name, assigneeAvatar: teamMembers[5].avatar, column: "todo" },

  // In Progress
  { id: "ST-311", title: "Biometric login flow", points: 8, assignee: teamMembers[0].name, assigneeAvatar: teamMembers[0].avatar, column: "in-progress" },
  { id: "ST-312", title: "Migrate analytics to v2 schema", points: 13, assignee: teamMembers[2].name, assigneeAvatar: teamMembers[2].avatar, column: "in-progress" },
  { id: "ST-313", title: "PCI-DSS audit prep", points: 13, assignee: teamMembers[3].name, assigneeAvatar: teamMembers[3].avatar, column: "in-progress", blocked: true },
  { id: "ST-314", title: "Kafka topic backfill job", points: 5, assignee: teamMembers[5].name, assigneeAvatar: teamMembers[5].avatar, column: "in-progress" },
  { id: "ST-315", title: "Salesforce OAuth2 connector", points: 8, assignee: teamMembers[0].name, assigneeAvatar: teamMembers[0].avatar, column: "in-progress" },
  { id: "ST-316", title: "Wire fraud detection alerts", points: 13, assignee: teamMembers[2].name, assigneeAvatar: teamMembers[2].avatar, column: "in-progress", blocked: true },

  // Done
  { id: "ST-321", title: "Refactor checkout reducer", points: 5, assignee: teamMembers[0].name, assigneeAvatar: teamMembers[0].avatar, column: "done" },
  { id: "ST-322", title: "DNS failover docs", points: 3, assignee: teamMembers[3].name, assigneeAvatar: teamMembers[3].avatar, column: "done" },
  { id: "ST-323", title: "Refund webhook idempotency", points: 13, assignee: teamMembers[2].name, assigneeAvatar: teamMembers[2].avatar, column: "done" },
  { id: "ST-324", title: "Schema validation upgrade", points: 5, assignee: teamMembers[5].name, assigneeAvatar: teamMembers[5].avatar, column: "done" },
  { id: "ST-325", title: "Design token refresh rate limit", points: 8, assignee: teamMembers[1].name, assigneeAvatar: teamMembers[1].avatar, column: "done" },
  { id: "ST-326", title: "Cutover runbook finalization", points: 8, assignee: teamMembers[3].name, assigneeAvatar: teamMembers[3].avatar, column: "done" },
];

const sprintColumns: Record<SprintColumnKey, { label: string; color: string; tone: StatusTone; icon: typeof Clock }> = {
  todo: { label: "To Do", color: "var(--info)", tone: "info", icon: Clock },
  "in-progress": { label: "In Progress", color: "var(--primary)", tone: "primary", icon: Loader2 },
  done: { label: "Done", color: "var(--success)", tone: "success", icon: CheckCircle2 },
};
const sprintColOrder: SprintColumnKey[] = ["todo", "in-progress", "done"];

/* ---------- Page ---------- */

export default function SprintBoardPage() {
  const totalPoints = sprintTasks.reduce((s, t) => s + t.points, 0);
  const donePoints = sprintTasks.filter((t) => t.column === "done").reduce((s, t) => s + t.points, 0);
  const inProgressPoints = sprintTasks.filter((t) => t.column === "in-progress").reduce((s, t) => s + t.points, 0);
  const todoPoints = sprintTasks.filter((t) => t.column === "todo").reduce((s, t) => s + t.points, 0);
  const completionPct = Math.round((donePoints / sprint.pointsCommitted) * 100);

  return (
    <>
      <PageHeader
        title="Sprint Board"
        description="Live sprint progress, burndown tracking, and team capacity at a glance."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: "Sprint Board" }]}
        icon={LayoutGrid}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.message("Sprint settings opened")}>
              <Pause className="h-3.5 w-3.5" /> Pause Sprint
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New sprint planning opened")}>
              <Plus className="h-3.5 w-3.5" /> New Sprint
            </Button>
          </>
        }
      />

      {/* Active sprint summary — full-width hero card with 4-segment progress */}
      <Card className="mb-6 overflow-hidden border-violet-500/20">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-500/[0.04] via-transparent to-primary/[0.04] pointer-events-none" />
        <CardContent className="relative p-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="grid place-items-center h-7 w-7 rounded-md bg-violet-500/15 text-violet-500">
                  <Zap className="h-4 w-4" />
                </div>
                <StatusBadge tone="violet" dot>Active</StatusBadge>
                <span className="text-[10px] text-muted-foreground font-mono">SPRINT-24</span>
              </div>
              <h2 className="text-xl font-semibold tracking-tight">{sprint.name}</h2>
              <p className="text-xs text-muted-foreground mt-1 max-w-xl line-clamp-2">
                <Flag className="h-3 w-3 inline -mt-0.5 mr-1" />
                {sprint.goal}
              </p>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <div className="text-right">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Days Remaining</p>
                <p className="text-2xl font-semibold tabular-nums text-violet-500">{sprint.daysRemaining}</p>
              </div>
              <div className="h-10 w-px bg-border" />
              <div className="text-right">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Date Range</p>
                <p className="text-xs font-medium font-mono">{sprint.startDate}</p>
                <p className="text-[10px] text-muted-foreground font-mono">→ {sprint.endDate}</p>
              </div>
            </div>
          </div>

          {/* Sprint timeline progress bar — 10 day segments */}
          <div className="mb-3">
            <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1.5">
              <span className="uppercase tracking-wide font-medium">Sprint Day {sprint.daysElapsed} of {sprint.daysTotal}</span>
              <span className="font-mono tabular-nums">{Math.round((sprint.daysElapsed / sprint.daysTotal) * 100)}% time elapsed</span>
            </div>
            <div className="flex items-center gap-1">
              {Array.from({ length: sprint.daysTotal }).map((_, i) => {
                const done = i < sprint.daysElapsed;
                const isToday = i === sprint.daysElapsed - 1;
                return (
                  <div
                    key={i}
                    className={cn(
                      "h-2 flex-1 rounded-sm transition-all relative",
                      done ? "bg-violet-500" : "bg-muted",
                      isToday && "ring-2 ring-violet-500/30 ring-offset-1 ring-offset-card"
                    )}
                    title={`Day ${i + 1}${done ? " (elapsed)" : ""}`}
                  />
                );
              })}
            </div>
          </div>

          {/* 4-stat row: committed / completed / in progress / remaining */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-border">
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                <Gauge className="h-3 w-3" /> Committed
              </p>
              <p className="text-lg font-semibold tabular-nums mt-0.5">{sprint.pointsCommitted} pts</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" /> Completed
              </p>
              <p className="text-lg font-semibold tabular-nums mt-0.5 text-[color:var(--success)]">{donePoints} pts</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                <Loader2 className="h-3 w-3" /> In Progress
              </p>
              <p className="text-lg font-semibold tabular-nums mt-0.5 text-primary">{inProgressPoints} pts</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                <TrendingDown className="h-3 w-3" /> Remaining
              </p>
              <p className="text-lg font-semibold tabular-nums mt-0.5 text-[color:var(--warning)]">{sprint.pointsCommitted - donePoints} pts</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Burndown chart + team capacity panel */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        {/* Burndown */}
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingDown className="h-4 w-4 text-violet-500" />
                Sprint Burndown
              </CardTitle>
              <CardDescription>Ideal (linear) vs. actual story points remaining across {sprint.daysTotal} days.</CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-4 rounded-sm border border-dashed border-[color:var(--info)]" /> Ideal
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-4 rounded-sm bg-primary" /> Actual
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <LineTrendChart
              data={burndown}
              xKey="day"
              series={[
                { key: "ideal", name: "Ideal", color: "var(--info)", dashed: true },
                { key: "actual", name: "Actual", color: "var(--primary)" },
              ]}
              height={300}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">On Track?</p>
                <p className="text-sm font-semibold text-[color:var(--success)] mt-0.5">
                  {donePoints >= (sprint.pointsCommitted / sprint.daysTotal) * sprint.daysElapsed ? "Ahead" : "Behind"} by {Math.abs(donePoints - Math.round((sprint.pointsCommitted / sprint.daysTotal) * sprint.daysElapsed))} pts
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Projected Completion</p>
                <p className="text-sm font-semibold mt-0.5 font-mono">Jul 08, 2026</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Velocity (last 3 sprints)</p>
                <p className="text-sm font-semibold text-primary mt-0.5 tabular-nums">226 pts avg</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Team capacity panel */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-violet-500" />
              Team Capacity
            </CardTitle>
            <CardDescription>Hours allocated vs. capacity for sprint {sprint.daysElapsed}/{sprint.daysTotal}.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1 custom-scroll">
            {teamMembers.map((m) => {
              const pct = Math.round((m.allocated / m.capacity) * 100);
              const overloaded = m.allocated > m.capacity;
              const remaining = m.capacity - m.allocated;
              return (
                <div key={m.name} className="rounded-lg border border-border p-2.5 hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-2 mb-2">
                    <Avatar className="h-7 w-7">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback className="text-[10px]">{m.name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium truncate">{m.name}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{m.role}</p>
                    </div>
                    <StatusBadge tone={overloaded ? "danger" : pct >= 95 ? "warning" : "success"} className="text-[9px]">
                      {overloaded ? "Over" : `${pct}%`}
                    </StatusBadge>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all duration-500",
                          overloaded ? "bg-destructive" : pct >= 95 ? "bg-[color:var(--warning)]" : "bg-primary"
                        )}
                        style={{ width: `${Math.min(pct, 100)}%` }}
                      />
                    </div>
                    <span className="text-[10px] font-semibold tabular-nums w-20 text-right shrink-0">
                      {m.allocated}h / {m.capacity}h
                    </span>
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>{m.points} pts assigned</span>
                    <span className={remaining < 0 ? "text-destructive" : ""}>
                      {remaining >= 0 ? `${remaining}h free` : `${Math.abs(remaining)}h over`}
                    </span>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      {/* Sprint board — 3 columns */}
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <LayoutGrid className="h-4 w-4 text-violet-500" /> Sprint Board — {sprintTasks.length} Stories
        </h3>
        <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.message("Board settings opened")}>
          Configure <ChevronRight className="h-3.5 w-3.5" />
        </Button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        {sprintColOrder.map((col) => {
          const cfg = sprintColumns[col];
          const ColIcon = cfg.icon;
          const colTasks = sprintTasks.filter((t) => t.column === col);
          const colPoints = colTasks.reduce((s, t) => s + t.points, 0);
          return (
            <div key={col} className="flex flex-col min-w-0">
              <div className="rounded-t-lg border border-border border-b-0 bg-muted/40 p-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <ColIcon className="h-3.5 w-3.5 shrink-0" style={{ color: cfg.color }} />
                    <span className="text-sm font-medium text-foreground truncate">{cfg.label}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <StatusBadge tone={cfg.tone} className="text-[10px]">{colPoints} pts</StatusBadge>
                    <span className="text-[10px] text-muted-foreground tabular-nums">{colTasks.length}</span>
                  </div>
                </div>
                <div className="h-1 w-full rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full" style={{ background: cfg.color, width: `${(colPoints / totalPoints) * 100}%` }} />
                </div>
              </div>
              <div
                className="flex-1 rounded-b-lg border border-border border-t-0 bg-muted/20 p-2 min-h-[300px] space-y-2"
                style={{ borderTopColor: cfg.color, borderTopWidth: 2 }}
              >
                {colTasks.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => toast.message(`Opening ${t.id}`, { description: t.title })}
                    className={cn(
                      "group relative rounded-lg border bg-card p-3 cursor-pointer hover:border-primary/40 hover:shadow-premium-sm transition-all",
                      t.blocked ? "border-destructive/30 bg-destructive/[0.03]" : "border-border"
                    )}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <span className="font-mono text-[10px] text-muted-foreground">{t.id}</span>
                      {t.blocked && (
                        <StatusBadge tone="danger" className="text-[9px] px-1.5 py-0">
                          <AlertTriangle className="h-2.5 w-2.5" /> Blocked
                        </StatusBadge>
                      )}
                    </div>
                    <p className="text-sm font-medium text-foreground leading-snug mb-2.5 line-clamp-2">{t.title}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Avatar className="h-5 w-5">
                          <AvatarImage src={t.assigneeAvatar} alt={t.assignee} />
                          <AvatarFallback className="text-[8px]">{t.assignee.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                        </Avatar>
                        <span className="text-[10px] text-muted-foreground truncate max-w-[80px]">{t.assignee}</span>
                      </div>
                      <span
                        className="inline-flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded tabular-nums"
                        style={{
                          background: `color-mix(in srgb, ${cfg.color} 14%, transparent)`,
                          color: cfg.color,
                        }}
                      >
                        <Zap className="h-2.5 w-2.5" />
                        {t.points} pts
                      </span>
                    </div>
                  </div>
                ))}
                <button
                  onClick={() => toast.success(`Add story to ${cfg.label}`)}
                  className="w-full rounded-lg border border-dashed border-border p-2 text-xs text-muted-foreground hover:border-primary/40 hover:text-primary hover:bg-primary/5 transition-colors flex items-center justify-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Add story
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
