"use client";

import * as React from "react";
import {
  ScrollText,
  Download,
  Filter,
  User,
  Shield,
  Settings2,
  Trash2,
  Plus,
  Edit3,
  LogIn,
  LogOut,
  Key,
  Upload,
  Eye,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ChevronDown,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DataTable, type Column } from "@/components/tables/data-table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type AuditLog = {
  id: string;
  timestamp: string;
  fullDate: string;
  user: string;
  avatar: string;
  action: "create" | "update" | "delete" | "login" | "logout" | "settings" | "export" | "permission";
  resource: string;
  resourceId: string;
  ip: string;
  status: "success" | "failure" | "warning";
  detail: string;
};

const USERS = [
  { name: "Amara Okafor", avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=80&q=80&auto=format&fit=crop" },
  { name: "Daniel Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&q=80&auto=format&fit=crop" },
  { name: "Priya Sharma", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&q=80&auto=format&fit=crop" },
  { name: "Marcus Johnson", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&q=80&auto=format&fit=crop" },
  { name: "Sofia Reyes", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&q=80&auto=format&fit=crop" },
  { name: "Lukas Bergmann", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=80&q=80&auto=format&fit=crop" },
  { name: "Yuki Tanaka", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&q=80&auto=format&fit=crop" },
  { name: "System", avatar: "" },
];

const LOGS: AuditLog[] = [
  { id: "log-2941", timestamp: "10:42:18 AM", fullDate: "Jul 14, 2026", user: "Amara Okafor", avatar: USERS[0].avatar, action: "create", resource: "API Key", resourceId: "key_prod_8f2a", ip: "73.158.42.10", status: "success", detail: "Created API key “production-read-only” with read scope" },
  { id: "log-2940", timestamp: "10:38:04 AM", fullDate: "Jul 14, 2026", user: "Daniel Kim", avatar: USERS[1].avatar, action: "settings", resource: "Workspace", resourceId: "ws_nexusgrid", ip: "73.158.42.10", status: "success", detail: "Updated workspace default timezone to UTC-08:00 Pacific" },
  { id: "log-2939", timestamp: "10:24:51 AM", fullDate: "Jul 14, 2026", user: "Priya Sharma", avatar: USERS[2].avatar, action: "update", resource: "Project", resourceId: "prj_falcon", ip: "73.158.42.10", status: "success", detail: "Changed Falcon Edge Runtime status from “at-risk” to “on-track”" },
  { id: "log-2938", timestamp: "10:18:33 AM", fullDate: "Jul 14, 2026", user: "Marcus Johnson", avatar: USERS[3].avatar, action: "login", resource: "Session", resourceId: "ses_a1b2", ip: "108.19.44.201", status: "warning", detail: "Sign-in from new device · New York, NY" },
  { id: "log-2937", timestamp: "09:54:12 AM", fullDate: "Jul 14, 2026", user: "Amara Okafor", avatar: USERS[0].avatar, action: "permission", resource: "Role", resourceId: "role_manager", ip: "73.158.42.10", status: "success", detail: "Granted “Manager” role to Sofia Reyes" },
  { id: "log-2936", timestamp: "09:42:08 AM", fullDate: "Jul 14, 2026", user: "Sofia Reyes", avatar: USERS[4].avatar, action: "export", resource: "Report", resourceId: "rep_q2_rev", ip: "73.158.42.10", status: "success", detail: "Exported Q2 Revenue report as CSV (4,820 rows)" },
  { id: "log-2935", timestamp: "09:21:45 AM", fullDate: "Jul 14, 2026", user: "System", avatar: "", action: "settings", resource: "Webhook", resourceId: "whk_slack", ip: "73.158.42.10", status: "warning", detail: "Webhook delivery to Slack failed (HTTP 503) — 3 retries exhausted" },
  { id: "log-2934", timestamp: "08:58:22 AM", fullDate: "Jul 14, 2026", user: "Lukas Bergmann", avatar: USERS[5].avatar, action: "delete", resource: "Customer", resourceId: "cus_8821", ip: "85.214.132.88", status: "success", detail: "Permanently deleted customer account cus_8821 (GDPR request)" },
  { id: "log-2933", timestamp: "08:42:11 AM", fullDate: "Jul 14, 2026", user: "Yuki Tanaka", avatar: USERS[6].avatar, action: "create", resource: "Project", resourceId: "prj_meridian", ip: "202.45.171.18", status: "success", detail: "Created project “Meridian Webhooks v2”" },
  { id: "log-2932", timestamp: "08:30:09 AM", fullDate: "Jul 14, 2026", user: "Amara Okafor", avatar: USERS[0].avatar, action: "login", resource: "Session", resourceId: "ses_c3d4", ip: "73.158.42.10", status: "success", detail: "Two-factor verified via authenticator app" },
  { id: "log-2931", timestamp: "08:12:54 AM", fullDate: "Jul 14, 2026", user: "Daniel Kim", avatar: USERS[1].avatar, action: "update", resource: "Integration", resourceId: "int_stripe", ip: "73.158.42.10", status: "success", detail: "Updated Stripe sync frequency from hourly to realtime" },
  { id: "log-2930", timestamp: "Yesterday, 11:48 PM", fullDate: "Jul 13, 2026", user: "Unknown", avatar: "", action: "login", resource: "Session", resourceId: "ses_x7y8", ip: "193.32.162.44", status: "failure", detail: "Failed sign-in · incorrect password (1 attempt)" },
  { id: "log-2929", timestamp: "Yesterday, 10:14 PM", fullDate: "Jul 13, 2026", user: "Priya Sharma", avatar: USERS[2].avatar, action: "create", resource: "Invoice", resourceId: "INV-2026-0713", ip: "73.158.42.10", status: "success", detail: "Generated invoice INV-2026-0713 for $249.00" },
  { id: "log-2928", timestamp: "Yesterday, 09:02:31 PM", fullDate: "Jul 13, 2026", user: "Marcus Johnson", avatar: USERS[3].avatar, action: "export", resource: "Customer", resourceId: "cus_all", ip: "108.19.44.201", status: "warning", detail: "Bulk export of 4,820 customer records — manager approval required" },
  { id: "log-2927", timestamp: "Yesterday, 06:48:12 PM", fullDate: "Jul 13, 2026", user: "Amara Okafor", avatar: USERS[0].avatar, action: "delete", resource: "API Key", resourceId: "key_legacy_cron", ip: "73.158.42.10", status: "success", detail: "Revoked API key “legacy-cron” — last used 47 days ago" },
  { id: "log-2926", timestamp: "Yesterday, 04:22:08 PM", fullDate: "Jul 13, 2026", user: "Sofia Reyes", avatar: USERS[4].avatar, action: "update", resource: "Order", resourceId: "ord_5021", ip: "73.158.42.10", status: "success", detail: "Refunded order ord_5021 — $84.00 returned to customer" },
  { id: "log-2925", timestamp: "Yesterday, 02:14:55 PM", fullDate: "Jul 13, 2026", user: "Lukas Bergmann", avatar: USERS[5].avatar, action: "permission", resource: "Role", resourceId: "role_editor", ip: "85.214.132.88", status: "failure", detail: "Permission denied — attempted to grant Admin role without Owner privileges" },
  { id: "log-2924", timestamp: "Yesterday, 11:08 AM", fullDate: "Jul 13, 2026", user: "Yuki Tanaka", avatar: USERS[6].avatar, action: "settings", resource: "Webhook", resourceId: "whk_github", ip: "202.45.171.18", status: "success", detail: "Added webhook endpoint https://hooks.nexusgrid.io/github" },
  { id: "log-2923", timestamp: "Yesterday, 09:30:21 AM", fullDate: "Jul 13, 2026", user: "Amara Okafor", avatar: USERS[0].avatar, action: "logout", resource: "Session", resourceId: "ses_e5f6", ip: "73.158.42.10", status: "success", detail: "Signed out of session ses_e5f6 — user-initiated" },
  { id: "log-2922", timestamp: "2 days ago, 05:48 PM", fullDate: "Jul 12, 2026", user: "Daniel Kim", avatar: USERS[1].avatar, action: "create", resource: "Webhook", resourceId: "whk_zapier", ip: "73.158.42.10", status: "success", detail: "Created webhook for Zapier with events: order.created, customer.updated" },
  { id: "log-2921", timestamp: "2 days ago, 03:12 PM", fullDate: "Jul 12, 2026", user: "Priya Sharma", avatar: USERS[2].avatar, action: "update", resource: "Billing", resourceId: "sub_nexusgrid", ip: "73.158.42.10", status: "success", detail: "Upgraded subscription from Starter to Pro — $249/mo" },
  { id: "log-2920", timestamp: "2 days ago, 01:08 AM", fullDate: "Jul 12, 2026", user: "System", avatar: "", action: "settings", resource: "Backup", resourceId: "bak_daily", ip: "73.158.42.10", status: "success", detail: "Daily workspace backup completed (2.4 GB)" },
];

const actionMeta: Record<AuditLog["action"], { icon: React.ElementType; tone: "success" | "info" | "primary" | "warning" | "danger" | "violet"; label: string }> = {
  create: { icon: Plus, tone: "success", label: "Create" },
  update: { icon: Edit3, tone: "info", label: "Update" },
  delete: { icon: Trash2, tone: "danger", label: "Delete" },
  login: { icon: LogIn, tone: "primary", label: "Sign in" },
  logout: { icon: LogOut, tone: "neutral" as any, label: "Sign out" },
  settings: { icon: Settings2, tone: "violet", label: "Settings" },
  export: { icon: Upload, tone: "warning", label: "Export" },
  permission: { icon: Key, tone: "danger", label: "Permission" },
};

const statusMeta: Record<AuditLog["status"], { tone: "success" | "warning" | "danger"; icon: React.ElementType }> = {
  success: { tone: "success", icon: CheckCircle2 },
  warning: { tone: "warning", icon: AlertTriangle },
  failure: { tone: "danger", icon: XCircle },
};

export default function AuditLogsPage() {
  const [userFilter, setUserFilter] = React.useState("all");
  const [actionFilter, setActionFilter] = React.useState("all");
  const [statusFilter, setStatusFilter] = React.useState("all");
  const [dateFilter, setDateFilter] = React.useState("all");

  const filtered = LOGS.filter((l) => {
    if (userFilter !== "all" && l.user !== userFilter) return false;
    if (actionFilter !== "all" && l.action !== actionFilter) return false;
    if (statusFilter !== "all" && l.status !== statusFilter) return false;
    if (dateFilter === "today" && l.fullDate !== "Jul 14, 2026") return false;
    if (dateFilter === "yesterday" && l.fullDate !== "Jul 13, 2026") return false;
    return true;
  });

  const successCount = filtered.filter((l) => l.status === "success").length;
  const warnCount = filtered.filter((l) => l.status === "warning").length;
  const failCount = filtered.filter((l) => l.status === "failure").length;

  const columns: Column<AuditLog>[] = [
    {
      key: "timestamp",
      header: "Timestamp",
      sortable: true,
      sortAccessor: (r) => r.id,
      width: "min-w-[180px]",
      cell: (r) => (
        <div>
          <p className="text-sm font-medium">{r.fullDate}</p>
          <p className="text-xs text-muted-foreground font-mono">{r.timestamp}</p>
        </div>
      ),
    },
    {
      key: "user",
      header: "User",
      sortable: true,
      sortAccessor: (r) => r.user,
      cell: (r) => (
        <div className="flex items-center gap-2">
          {r.avatar ? (
            <Avatar className="h-7 w-7 shrink-0">
              <AvatarImage src={r.avatar} alt={r.user} />
              <AvatarFallback>{r.user[0]}</AvatarFallback>
            </Avatar>
          ) : (
            <div className="grid place-items-center h-7 w-7 rounded-full bg-muted text-muted-foreground shrink-0">
              <Shield className="h-3.5 w-3.5" />
            </div>
          )}
          <div className="min-w-0">
            <p className="text-sm font-medium truncate">{r.user}</p>
            <p className="text-[11px] text-muted-foreground font-mono">{r.ip}</p>
          </div>
        </div>
      ),
    },
    {
      key: "action",
      header: "Action",
      sortable: true,
      sortAccessor: (r) => r.action,
      cell: (r) => {
        const meta = actionMeta[r.action];
        return (
          <div className="flex items-center gap-1.5">
            <div className={cn("grid place-items-center h-6 w-6 rounded-md shrink-0",
              meta.tone === "success" ? "bg-[color:var(--success)]/12 text-[color:var(--success)]" :
              meta.tone === "info" ? "bg-[color:var(--info)]/12 text-[color:var(--info)]" :
              meta.tone === "primary" ? "bg-primary/12 text-primary" :
              meta.tone === "warning" ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" :
              meta.tone === "danger" ? "bg-destructive/12 text-destructive" :
              "bg-violet-500/12 text-violet-500"
            )}>
              <meta.icon className="h-3 w-3" />
            </div>
            <span className="text-sm">{meta.label}</span>
          </div>
        );
      },
    },
    {
      key: "resource",
      header: "Resource",
      sortable: true,
      sortAccessor: (r) => r.resource,
      cell: (r) => (
        <div>
          <p className="text-sm font-medium">{r.resource}</p>
          <p className="text-[11px] text-muted-foreground font-mono">{r.resourceId}</p>
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      cell: (r) => {
        const meta = statusMeta[r.status];
        return <StatusBadge tone={meta.tone} dot>{r.status}</StatusBadge>;
      },
    },
    {
      key: "detail",
      header: "Details",
      cell: (r) => <p className="text-xs text-muted-foreground line-clamp-2 max-w-md">{r.detail}</p>,
    },
  ];

  return (
    <>
      <PageHeader
        title="Audit Logs"
        description="A tamper-evident trail of every meaningful action across the workspace."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Audit Logs" }]}
        icon={ScrollText}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Audit log exported", { description: `${filtered.length} entries downloaded as CSV.` })}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
          </div>
        }
      />

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { icon: ScrollText, tone: "bg-primary/12 text-primary", label: "Total events", value: String(filtered.length), hint: "Matching filters" },
          { icon: CheckCircle2, tone: "bg-[color:var(--success)]/12 text-[color:var(--success)]", label: "Successful", value: String(successCount), hint: `${Math.round((successCount / Math.max(filtered.length, 1)) * 100)}% of total` },
          { icon: AlertTriangle, tone: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]", label: "Warnings", value: String(warnCount), hint: "Review recommended" },
          { icon: XCircle, tone: "bg-destructive/12 text-destructive", label: "Failures", value: String(failCount), hint: "Action required" },
        ].map((s) => (
          <Card key={s.label} className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("grid place-items-center h-7 w-7 rounded-md", s.tone)}><s.icon className="h-3.5 w-3.5" /></div>
              <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</span>
            </div>
            <p className="text-xl font-semibold tabular-nums leading-tight">{s.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">{s.hint}</p>
          </Card>
        ))}
      </div>

      {/* FILTERS */}
      <Card className="mb-4">
        <CardContent className="p-3">
          <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
            <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground shrink-0">
              <Filter className="h-3.5 w-3.5" /> Filters:
            </div>
            <div className="flex items-center gap-2 flex-wrap flex-1">
              <Select value={userFilter} onValueChange={setUserFilter}>
                <SelectTrigger className="h-8 w-[160px] text-xs"><User className="h-3 w-3 mr-1" /><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All users</SelectItem>
                  {Array.from(new Set(LOGS.map((l) => l.user))).map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={actionFilter} onValueChange={setActionFilter}>
                <SelectTrigger className="h-8 w-[140px] text-xs"><SelectValue placeholder="Action" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All actions</SelectItem>
                  {Object.entries(actionMeta).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="h-8 w-[120px] text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All status</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="failure">Failure</SelectItem>
                </SelectContent>
              </Select>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="h-8 w-[140px] text-xs"><SelectValue placeholder="Date range" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                </SelectContent>
              </Select>
              {(userFilter !== "all" || actionFilter !== "all" || statusFilter !== "all" || dateFilter !== "all") && (
                <Button variant="ghost" size="sm" className="text-xs h-8" onClick={() => { setUserFilter("all"); setActionFilter("all"); setStatusFilter("all"); setDateFilter("all"); }}>
                  Clear all
                </Button>
              )}
            </div>
            <span className="text-xs text-muted-foreground shrink-0">{filtered.length} of {LOGS.length} entries</span>
          </div>
        </CardContent>
      </Card>

      {/* LOGS TABLE */}
      <Card>
        <CardContent className="p-0">
          <DataTable
            data={filtered}
            columns={columns}
            pageSize={10}
            searchable
            searchKeys={["user", "resource", "resourceId", "detail", "ip"]}
            title="Audit trail"
            getRowId={(r) => r.id}
            enableExport
            initialSort={{ key: "timestamp", direction: "desc" }}
          />
        </CardContent>
      </Card>
    </>
  );
}
