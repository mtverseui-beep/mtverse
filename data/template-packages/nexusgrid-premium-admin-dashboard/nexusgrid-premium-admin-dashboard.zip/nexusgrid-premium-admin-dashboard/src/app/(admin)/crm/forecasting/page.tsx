"use client";

import * as React from "react";
import {
  TrendingUp,
  DollarSign,
  Target,
  GitBranch,
  Plus,
  Eye,
  Download,
  Gauge,
  ArrowUpRight,
  ArrowDownRight,
  CircleDot,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LineTrendChart } from "@/components/charts";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const forecastVsActual = [
  { month: "Jan", forecast: 320, actual: 298 },
  { month: "Feb", forecast: 340, actual: 352 },
  { month: "Mar", forecast: 380, actual: 364 },
  { month: "Apr", forecast: 410, actual: 428 },
  { month: "May", forecast: 430, actual: 412 },
  { month: "Jun", forecast: 460, actual: 478 },
  { month: "Jul", forecast: 490, actual: 502 },
  { month: "Aug", forecast: 510, actual: null },
  { month: "Sep", forecast: 540, actual: null },
  { month: "Oct", forecast: 560, actual: null },
  { month: "Nov", forecast: 580, actual: null },
  { month: "Dec", forecast: 620, actual: null },
];

const quarters = [
  { q: "Q1 2026", committed: 1040, bestCase: 1280, closed: 1014, attainment: 98, status: "warning" as StatusTone },
  { q: "Q2 2026", committed: 1300, bestCase: 1620, closed: 1318, attainment: 101, status: "success" as StatusTone },
  { q: "Q3 2026", committed: 1540, bestCase: 1920, closed: 502, attainment: 33, status: "warning" as StatusTone },
  { q: "Q4 2026", committed: 1760, bestCase: 2200, closed: 0, attainment: 0, status: "neutral" as StatusTone },
];

const reps = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", committed: 320, bestCase: 410, closed: 358, attainment: 112, confidence: 86 },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", committed: 360, bestCase: 460, closed: 412, attainment: 114, confidence: 91 },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", committed: 300, bestCase: 380, closed: 268, attainment: 89, confidence: 78 },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", committed: 280, bestCase: 360, closed: 218, attainment: 78, confidence: 68 },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", committed: 260, bestCase: 340, closed: 194, attainment: 75, confidence: 64 },
  { name: "Olivia Hartwell", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=40&h=40&fit=crop", committed: 240, bestCase: 310, closed: 252, attainment: 105, confidence: 82 },
];

/* ForecastKpi — delta-from-quota motif: shows a delta chip and quota baseline below */
function ForecastKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  delta,
  deltaPositive,
  quota,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  delta: string;
  deltaPositive: boolean;
  quota: string;
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* Delta vs quota motif — distinct: shows quota baseline with a delta chip */}
        <div className="flex items-center justify-between gap-2 p-2 rounded-md bg-muted/40">
          <div className="min-w-0">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">vs. Quota</p>
            <p className="text-xs font-medium tabular-nums truncate">{quota}</p>
          </div>
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium shrink-0",
              deltaPositive
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {deltaPositive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {delta}
          </span>
        </div>
        <p className="text-xs text-muted-foreground mt-2">{hint}</p>
      </CardContent>
    </Card>
  );
}

export default function ForecastingPage() {
  return (
    <>
      <PageHeader
        title="Forecasting"
        description="Project revenue outcomes with committed, best-case, and pipeline-based forecasts."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Forecasting" }]}
        icon={TrendingUp}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Forecast exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Forecast submitted for review")}>
              <Plus className="h-3.5 w-3.5" /> Submit Forecast
            </Button>
          </>
        }
      />

      {/* KPI Row — delta-from-quota motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <ForecastKpi label="Committed Forecast" value="$1.54M" hint="Q3 2026 committed" icon={Target} accent="primary" delta="+12.4%" deltaPositive={true} quota="$1.40M" />
        <ForecastKpi label="Best Case" value="$1.92M" hint="upside if all closes" icon={TrendingUp} accent="info" delta="+38.6%" deltaPositive={true} quota="$1.40M" />
        <ForecastKpi label="Pipeline" value="$2.36M" hint="total open deal value" icon={GitBranch} accent="warning" delta="+18.2%" deltaPositive={true} quota="$1.40M" />
        <ForecastKpi label="Quota" value="$1.40M" hint="Q3 2026 target" icon={DollarSign} accent="success" delta="100%" deltaPositive={true} quota="baseline" />
      </div>

      {/* Forecast vs Actual chart + Quarter table */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <GitBranch className="h-4 w-4 text-primary" />
                Forecast vs. Actual
              </CardTitle>
              <CardDescription>Monthly forecast (dashed) vs. closed revenue (solid) — in $K.</CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-3 rounded-full bg-muted-foreground/60" style={{ backgroundImage: "repeating-linear-gradient(90deg, currentColor 0 4px, transparent 4px 7px)" }} />
                Forecast
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="h-0.5 w-3 bg-primary rounded-full" />
                Actual
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <LineTrendChart
              data={forecastVsActual}
              xKey="month"
              series={[
                { key: "forecast", name: "Forecast", color: "var(--muted-foreground)", dashed: true },
                { key: "actual", name: "Actual", color: "var(--primary)" },
              ]}
              height={300}
            />
            <div className="mt-4 pt-4 border-t border-border grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">YTD Forecast</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5">$5.94M</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">YTD Actual</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5 text-primary">$5.83M</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Forecast Accuracy</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5 text-[color:var(--success)]">98.2%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Gauge className="h-4 w-4 text-[color:var(--info)]" />
              Forecast by Quarter
            </CardTitle>
            <CardDescription>Committed, best case, and closed per quarter — in $K.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40 hover:bg-muted/40">
                  <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Quarter</TableHead>
                  <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Comm.</TableHead>
                  <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Best</TableHead>
                  <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Closed</TableHead>
                  <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Attain.</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quarters.map((q) => (
                  <TableRow key={q.q} className="hover:bg-muted/30 cursor-pointer" onClick={() => toast.message(`Opening ${q.q} forecast`)}>
                    <TableCell className="text-xs font-medium font-mono">{q.q}</TableCell>
                    <TableCell className="text-xs text-right tabular-nums">${q.committed}K</TableCell>
                    <TableCell className="text-xs text-right tabular-nums text-muted-foreground">${q.bestCase}K</TableCell>
                    <TableCell className="text-xs text-right tabular-nums font-medium">${q.closed}K</TableCell>
                    <TableCell className="text-right">
                      <StatusBadge tone={q.status} className="tabular-nums">
                        {q.attainment}%
                      </StatusBadge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Rep forecast breakdown table */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <CircleDot className="h-4 w-4 text-primary" />
              Rep Forecast Breakdown
            </CardTitle>
            <CardDescription>Per-rep committed, best case, and attainment — in $K.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.success("Rep forecast exported")}>
            Export <Download className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Sales Rep</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Committed</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Best Case</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Closed</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Attainment</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground hidden md:table-cell">Confidence</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reps.map((r) => {
                const attainmentTone: StatusTone =
                  r.attainment >= 100 ? "success" : r.attainment >= 80 ? "warning" : "danger";
                return (
                  <TableRow key={r.name} className="hover:bg-muted/30">
                    <TableCell>
                      <div className="flex items-center gap-2.5">
                        <Avatar className="h-8 w-8 shrink-0">
                          <AvatarImage src={r.avatar} alt={r.name} />
                          <AvatarFallback className="text-[10px]">
                            {r.name.split(" ").map((p) => p[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{r.name}</p>
                          <p className="text-xs text-muted-foreground">Account Executive</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums font-medium">${r.committed}K</TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">${r.bestCase}K</TableCell>
                    <TableCell className="text-right tabular-nums font-semibold">${r.closed}K</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 w-32">
                        <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
                          <div
                            className={cn(
                              "h-full rounded-full transition-all duration-500",
                              r.attainment >= 100
                                ? "bg-[color:var(--success)]"
                                : r.attainment >= 80
                                ? "bg-[color:var(--warning)]"
                                : "bg-destructive"
                            )}
                            style={{ width: `${Math.min(100, r.attainment)}%` }}
                          />
                        </div>
                        <StatusBadge tone={attainmentTone} className="tabular-nums">
                          {r.attainment}%
                        </StatusBadge>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-20 rounded-full bg-muted overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500 bg-primary"
                            style={{ width: `${r.confidence}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium tabular-nums">{r.confidence}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.message(`Opening ${r.name} forecast`)}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
