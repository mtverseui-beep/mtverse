"use client";

import * as React from "react";
import {
  LoaderCircle,
  Eye,
  EyeOff,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Users,
  DollarSign,
  ShoppingCart,
  Activity,
  Star,
  Mail,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function SkeletonsPage() {
  const [showReal, setShowReal] = React.useState(false);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Skeletons"
        description="Loading placeholders that mirror real content — text, avatars, cards, tables, charts and full pages."
        icon={LoaderCircle}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/skeletons" },
          { label: "Skeletons" },
        ]}
        actions={
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setShowReal((v) => !v);
              toast.message(showReal ? "Showing skeletons" : "Showing real content");
            }}
          >
            {showReal ? <EyeOff /> : <Eye />}
            {showReal ? "Show skeletons" : "Show real content"}
          </Button>
        }
      />

      {/* Text skeletons */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Text skeletons</CardTitle>
          <CardDescription>
            Common paragraph and headline shapes — useful while content fetches.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6 md:grid-cols-2">
          <div className="space-y-3">
            {showReal ? (
              <>
                <h3 className="text-lg font-semibold">Quarterly business review</h3>
                <p className="text-sm text-muted-foreground">
                  Revenue grew 12.4% quarter-over-quarter, driven by a 38% increase in Enterprise
                  contract value and a steady stream of self-serve Pro upgrades from the marketing site.
                </p>
                <p className="text-sm text-muted-foreground">
                  Customer acquisition cost decreased 8% thanks to improved attribution tracking and a
                  shift toward organic content distribution. Net revenue retention sits at 118%.
                </p>
              </>
            ) : (
              <>
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </>
            )}
          </div>

          <div className="space-y-3">
            {showReal ? (
              <>
                <h3 className="text-base font-semibold">Release notes 4.2.0</h3>
                <ul className="text-sm text-muted-foreground space-y-1.5 list-disc pl-4">
                  <li>Billing engine v2 with metered usage and proration</li>
                  <li>Audit log exports to CSV, JSON and XLSX</li>
                  <li>14 new dashboard templates</li>
                  <li>Reactive command palette with fuzzy search</li>
                </ul>
              </>
            ) : (
              <>
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-11/12" />
                <Skeleton className="h-3 w-4/5" />
                <Skeleton className="h-3 w-3/4" />
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Avatar + card skeletons */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Avatar & card skeletons</CardTitle>
          <CardDescription>
            Profile card skeleton that mirrors the eventual layout exactly.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <Card key={i} className="py-4">
              <CardContent className="space-y-3">
                {showReal ? (
                  <>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={`https://images.unsplash.com/photo-1500${68 + i}687${i + 4}620?w=64&h=64&fit=crop`} alt={`User ${i + 1}`} />
                        <AvatarFallback>U{i + 1}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{["Amara Reyes", "Devon Park", "Priya Shah"][i]}</p>
                        <p className="text-xs text-muted-foreground">{["Designer", "Engineer", "CS Lead"][i]}</p>
                      </div>
                    </div>
                    <div className="flex gap-4 text-xs text-muted-foreground">
                      <span><strong className="text-foreground">142</strong> projects</span>
                      <span><strong className="text-foreground">2.8k</strong> commits</span>
                    </div>
                    <Button size="sm" className="w-full" onClick={() => toast.success("Message sent")}>Message</Button>
                  </>
                ) : (
                  <>
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div className="space-y-2 flex-1">
                        <Skeleton className="h-3 w-24" />
                        <Skeleton className="h-2.5 w-16" />
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <Skeleton className="h-3 w-16" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                    <Skeleton className="h-8 w-full" />
                  </>
                )}
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      {/* Stat cards skeleton */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Stat card skeletons</CardTitle>
          <CardDescription>
            KPI tiles loading — they should not jump in height when data arrives.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: DollarSign, label: "Total revenue", value: "$284,392", delta: "+12.4%", trend: "up" },
            { icon: Users, label: "Active users", value: "84,392", delta: "+8.2%", trend: "up" },
            { icon: ShoppingCart, label: "Orders", value: "2,184", delta: "-3.1%", trend: "down" },
            { icon: Activity, label: "Conversion", value: "4.2%", delta: "+0.6pp", trend: "up" },
          ].map((s, i) => (
            <Card key={i} className="py-4">
              <CardContent className="space-y-3">
                {showReal ? (
                  <>
                    <div className="flex items-center justify-between">
                      <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary/15 text-primary">
                        <s.icon className="h-4 w-4" />
                      </div>
                      <span className={cn("inline-flex items-center gap-1 text-xs font-medium", s.trend === "up" ? "text-[color:var(--success)]" : "text-destructive")}>
                        {s.trend === "up" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                        {s.delta}
                      </span>
                    </div>
                    <div>
                      <p className="text-2xl font-semibold tabular-nums">{s.value}</p>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-9 w-9 rounded-lg" />
                      <Skeleton className="h-3 w-10" />
                    </div>
                    <div className="space-y-2">
                      <Skeleton className="h-6 w-20" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      {/* Table skeleton */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Table skeleton</CardTitle>
          <CardDescription>
            Skeleton rows that match the eventual table column widths.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="grid grid-cols-12 gap-3 pb-2 border-b text-[10px] font-medium text-muted-foreground uppercase tracking-wider">
            <div className="col-span-4">Customer</div>
            <div className="col-span-3">Email</div>
            <div className="col-span-2">Plan</div>
            <div className="col-span-2">Spend</div>
            <div className="col-span-1">Status</div>
          </div>
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="grid grid-cols-12 gap-3 items-center py-2 border-b last:border-b-0">
              {showReal ? (
                <>
                  <div className="col-span-4 flex items-center gap-2">
                    <Avatar className="h-7 w-7">
                      <AvatarImage src={`https://images.unsplash.com/photo-1500${68 + i}6876${i + 2}0?w=64&h=64&fit=crop`} alt="" />
                      <AvatarFallback>U{i + 1}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">{["Acme Corp", "Globex Inc", "Initech", "Stark Industries", "Wayne Enterprises", "Cyberdyne"][i]}</span>
                  </div>
                  <div className="col-span-3 text-sm text-muted-foreground truncate">billing@acme.io</div>
                  <div className="col-span-2"><Badge variant="secondary">{["Pro", "Enterprise", "Starter", "Pro", "Enterprise", "Pro"][i]}</Badge></div>
                  <div className="col-span-2 text-sm tabular-nums">${[1240, 8420, 36, 2180, 5400, 920][i]}</div>
                  <div className="col-span-1"><Badge className="bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent">Active</Badge></div>
                </>
              ) : (
                <>
                  <div className="col-span-4 flex items-center gap-2">
                    <Skeleton className="h-7 w-7 rounded-full" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="col-span-3 h-3" />
                  <Skeleton className="col-span-2 h-5 w-12 rounded-full" />
                  <Skeleton className="col-span-2 h-3 w-12" />
                  <Skeleton className="col-span-1 h-5 w-14 rounded-full" />
                </>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Chart skeleton */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Chart skeleton</CardTitle>
          <CardDescription>
            Area / line chart skeleton — bars + axes that mirror the eventual rendered chart.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6 lg:grid-cols-2">
          {showReal ? (
            <>
              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <p className="text-sm font-medium">Traffic overview</p>
                  <p className="text-2xl font-semibold tabular-nums">284,392</p>
                </div>
                <div className="relative h-40">
                  <svg viewBox="0 0 300 120" preserveAspectRatio="none" className="w-full h-full">
                    <defs>
                      <linearGradient id="realgrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <path d="M 0 80 Q 30 60 60 70 T 120 40 T 180 50 T 240 25 T 300 35 L 300 120 L 0 120 Z" fill="url(#realgrad)" />
                    <path d="M 0 80 Q 30 60 60 70 T 120 40 T 180 50 T 240 25 T 300 35" fill="none" stroke="var(--primary)" strokeWidth={2} />
                  </svg>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <p className="text-sm font-medium">Revenue by month</p>
                  <p className="text-2xl font-semibold tabular-nums">$284k</p>
                </div>
                <div className="flex items-end gap-2 h-40">
                  {[60, 80, 45, 95, 70, 88, 100, 78, 92, 65, 85, 95].map((h, i) => (
                    <div key={i} className="flex-1 rounded-t-sm bg-primary/80" style={{ height: `${h}%` }} />
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <Skeleton className="h-3 w-24" />
                  <Skeleton className="h-6 w-20" />
                </div>
                <Skeleton className="h-40 w-full" />
              </div>
              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <Skeleton className="h-3 w-28" />
                  <Skeleton className="h-6 w-16" />
                </div>
                <div className="flex items-end gap-2 h-40">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <Skeleton key={i} className="flex-1" style={{ height: `${[60, 80, 45, 95, 70, 88, 100, 78, 92, 65, 85, 95][i]}%` }} />
                  ))}
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Full-page skeleton */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Full-page skeleton</CardTitle>
          <CardDescription>
            Composite skeleton for an entire page — header, KPIs, chart and table together.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {showReal ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">Sales overview</h3>
                  <p className="text-sm text-muted-foreground">Last 30 days · all regions</p>
                </div>
                <Button variant="outline" size="sm"><RefreshCw /> Refresh</Button>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: "Revenue", value: "$284k", icon: DollarSign },
                  { label: "Orders", value: "2,184", icon: ShoppingCart },
                  { label: "Customers", value: "1,492", icon: Users },
                  { label: "Conversion", value: "4.2%", icon: Activity },
                ].map((s, i) => (
                  <div key={i} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between mb-2">
                      <s.icon className="h-4 w-4 text-muted-foreground" />
                      <Badge variant="secondary" className="text-[10px]">+8%</Badge>
                    </div>
                    <p className="text-xl font-semibold">{s.value}</p>
                    <p className="text-xs text-muted-foreground">{s.label}</p>
                  </div>
                ))}
              </div>
              <div className="rounded-lg border p-4">
                <p className="text-sm font-medium mb-2">Weekly trend</p>
                <Progress value={68} />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-5 w-40" />
                  <Skeleton className="h-3 w-32" />
                </div>
                <Skeleton className="h-8 w-24" />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="rounded-lg border p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-4 w-4 rounded" />
                      <Skeleton className="h-4 w-8 rounded-full" />
                    </div>
                    <Skeleton className="h-5 w-16" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                ))}
              </div>
              <div className="rounded-lg border p-4 space-y-2">
                <Skeleton className="h-3 w-28" />
                <Skeleton className="h-2 w-full rounded-full" />
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="border-t justify-between text-xs text-muted-foreground">
          <span>{showReal ? "Real content rendered" : "Skeleton placeholder"}</span>
          <span>Toggle from header to switch view</span>
        </CardFooter>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Skeletons page · text · avatar + card · stat · table · chart · full-page · toggle to compare
      </p>
    </div>
  );
}
