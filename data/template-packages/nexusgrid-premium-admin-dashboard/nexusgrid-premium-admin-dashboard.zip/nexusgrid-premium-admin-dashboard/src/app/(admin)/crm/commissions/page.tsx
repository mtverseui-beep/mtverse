"use client";

import * as React from "react";
import {
  Percent,
  DollarSign,
  TrendingUp,
  Crown,
  Clock,
  Plus,
  MoreHorizontal,
  Eye,
  CheckCircle2,
  Download,
  ArrowUpRight,
  Layers,
  Award,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AreaTrendChart } from "@/components/charts";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type CommissionTier = "starter" | "standard" | "accelerator" | "presidents-club";
type CommissionStatus = "approved" | "pending" | "paid" | "disputed";

type Rep = {
  id: string;
  name: string;
  avatar: string;
  dealsClosed: number;
  revenue: number;
  tier: CommissionTier;
  baseCommission: number;
  bonus: number;
  status: CommissionStatus;
};

const reps: Rep[] = [
  { id: "CM-101", name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", dealsClosed: 28, revenue: 412000, tier: "presidents-club", baseCommission: 32960, bonus: 8400, status: "approved" },
  { id: "CM-102", name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", dealsClosed: 24, revenue: 358000, tier: "accelerator", baseCommission: 28640, bonus: 4200, status: "approved" },
  { id: "CM-103", name: "Olivia Hartwell", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=40&h=40&fit=crop", dealsClosed: 18, revenue: 252000, tier: "accelerator", baseCommission: 20160, bonus: 1800, status: "pending" },
  { id: "CM-104", name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", dealsClosed: 22, revenue: 268000, tier: "standard", baseCommission: 16080, bonus: 1200, status: "approved" },
  { id: "CM-105", name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", dealsClosed: 19, revenue: 218000, tier: "standard", baseCommission: 13080, bonus: 600, status: "pending" },
  { id: "CM-106", name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", dealsClosed: 16, revenue: 194000, tier: "starter", baseCommission: 9700, bonus: 0, status: "disputed" },
  { id: "CM-107", name: "Carlos Mendez", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=40&h=40&fit=crop", dealsClosed: 14, revenue: 168000, tier: "starter", baseCommission: 8400, bonus: 0, status: "paid" },
  { id: "CM-108", name: "Priya Sharma", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=40&h=40&fit=crop", dealsClosed: 21, revenue: 248000, tier: "standard", baseCommission: 14880, bonus: 1000, status: "paid" },
];

const tierConfig: Record<CommissionTier, { label: string; rate: number; min: string; color: string; tone: StatusTone }> = {
  starter: { label: "Starter", rate: 5, min: "$0 – $200K", color: "var(--info)", tone: "info" },
  standard: { label: "Standard", rate: 8, min: "$200K – $300K", color: "var(--primary)", tone: "primary" },
  accelerator: { label: "Accelerator", rate: 12, min: "$300K – $400K", color: "oklch(0.70 0.15 75)", tone: "warning" },
  "presidents-club": { label: "President's Club", rate: 15, min: "$400K+", color: "var(--success)", tone: "success" },
};

const statusToneMap: Record<CommissionStatus, StatusTone> = {
  approved: "success",
  pending: "warning",
  paid: "primary",
  disputed: "danger",
};

const commissionTrend = [
  { month: "Jan", total: 38400, paid: 36800 },
  { month: "Feb", total: 42800, paid: 41200 },
  { month: "Mar", total: 48200, paid: 46400 },
  { month: "Apr", total: 44800, paid: 42800 },
  { month: "May", total: 52400, paid: 50800 },
  { month: "Jun", total: 58600, paid: 56200 },
  { month: "Jul", total: 64200, paid: 0 },
];

/* CommissionKpi — payout-tiers motif: stacked tier bars showing contribution per tier */
function CommissionKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive,
  tiers,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  trend: string;
  trendPositive: boolean;
  tiers: { count: number; color: string }[];
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  const total = tiers.reduce((s, t) => s + t.count, 0) || 1;
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* Tier contribution motif — stacked vertical bars showing per-tier counts */}
        <div className="flex items-end gap-1.5 h-10 mb-2">
          {tiers.map((t, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="flex-1 w-full flex items-end">
                <div
                  className="w-full rounded-sm transition-all duration-500"
                  style={{ height: `${(t.count / total) * 100}%`, background: t.color, minHeight: 4 }}
                  title={`${t.count} reps`}
                />
              </div>
              <span className="text-[9px] text-muted-foreground tabular-nums">{t.count}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground truncate">{hint}</span>
          <span className={cn("inline-flex items-center gap-0.5 font-medium shrink-0", trendPositive ? "text-[color:var(--success)]" : "text-destructive")}>
            <ArrowUpRight className="h-3 w-3" />
            {trend}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function CommissionsPage() {
  const totalPayout = reps.reduce((s, r) => s + r.baseCommission + r.bonus, 0);
  const avgCommission = Math.round(totalPayout / reps.length);
  const topEarner = reps.reduce((max, r) => (r.baseCommission + r.bonus > max.baseCommission + max.bonus ? r : max), reps[0]);
  const pendingCount = reps.filter((r) => r.status === "pending").length;
  const pendingTotal = reps.filter((r) => r.status === "pending").reduce((s, r) => s + r.baseCommission + r.bonus, 0);

  return (
    <>
      <PageHeader
        title="Commissions"
        description="Calculate, approve, and track commission payouts across all sales reps."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Commissions" }]}
        icon={Percent}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Commission report exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Run commission calculation")}>
              <Plus className="h-3.5 w-3.5" /> Run Calculation
            </Button>
          </>
        }
      />

      {/* KPI Row — tier-bar motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <CommissionKpi label="Total Payout" value={`$${(totalPayout / 1000).toFixed(1)}K`} hint="this period" icon={DollarSign} accent="primary" trend="+12.4% vs last period" trendPositive={true} tiers={[{ count: 2, color: "var(--info)" }, { count: 3, color: "var(--primary)" }, { count: 2, color: "oklch(0.70 0.15 75)" }, { count: 1, color: "var(--success)" }]} />
        <CommissionKpi label="Avg. Commission" value={`$${(avgCommission / 1000).toFixed(1)}K`} hint="per rep" icon={TrendingUp} accent="info" trend="+8.2% vs last period" trendPositive={true} tiers={[{ count: 3, color: "var(--info)" }, { count: 4, color: "var(--primary)" }, { count: 1, color: "oklch(0.70 0.15 75)" }]} />
        <CommissionKpi label="Top Earner" value={topEarner.name} hint={`$${((topEarner.baseCommission + topEarner.bonus) / 1000).toFixed(1)}K total`} icon={Crown} accent="warning" trend="President's Club" trendPositive={true} tiers={[{ count: 1, color: "var(--success)" }, { count: 2, color: "oklch(0.70 0.15 75)" }, { count: 5, color: "var(--muted-foreground)" }]} />
        <CommissionKpi label="Pending Approval" value={`${pendingCount} reps`} hint={`$${(pendingTotal / 1000).toFixed(1)}K awaiting`} icon={Clock} accent="success" trend="needs review" trendPositive={true} tiers={[{ count: 2, color: "var(--warning)" }, { count: 4, color: "var(--success)" }, { count: 2, color: "var(--primary)" }]} />
      </div>

      {/* Commission structure + trend chart */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        {/* Tier structure explainer */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Layers className="h-4 w-4 text-primary" />
              Commission Structure
            </CardTitle>
            <CardDescription>Tiered rates by revenue attainment.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2.5">
            {Object.entries(tierConfig).map(([key, t]) => {
              const repCount = reps.filter((r) => r.tier === key).length;
              return (
                <div
                  key={key}
                  className="rounded-lg border border-border p-3"
                  style={{ borderColor: `color-mix(in srgb, ${t.color} 30%, var(--border))` }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: t.color }} />
                      <span className="text-sm font-medium text-foreground truncate">{t.label}</span>
                    </div>
                    <StatusBadge tone={t.tone} className="tabular-nums">
                      {t.rate}%
                    </StatusBadge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="font-mono">{t.min}</span>
                    <span className="inline-flex items-center gap-1">
                      <Award className="h-3 w-3" />
                      {repCount} rep{repCount !== 1 ? "s" : ""}
                    </span>
                  </div>
                  {/* Rate bar */}
                  <div className="mt-2 h-1 w-full rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${(t.rate / 15) * 100}%`, background: t.color }} />
                  </div>
                </div>
              );
            })}
            <div className="pt-2 mt-2 border-t border-border text-xs text-muted-foreground">
              Rates apply to closed-won revenue. Bonuses awarded for quarterly quota overage (≥110%).
            </div>
          </CardContent>
        </Card>

        {/* Commission trend */}
        <Card className="xl:col-span-2">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-[color:var(--success)]" />
                Commission Trend
              </CardTitle>
              <CardDescription>Total earned vs. paid out — in $.</CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-3 rounded-full bg-primary" /> Total Earned
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-3 rounded-full bg-[color:var(--success)]" /> Paid Out
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={commissionTrend}
              xKey="month"
              series={[
                { key: "total", name: "Total Earned", color: "var(--primary)" },
                { key: "paid", name: "Paid Out", color: "var(--success)" },
              ]}
              height={260}
            />
            <div className="mt-4 pt-4 border-t border-border grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">YTD Total Earned</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5">${(commissionTrend.reduce((s, m) => s + m.total, 0) / 1000).toFixed(0)}K</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">YTD Paid Out</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5 text-[color:var(--success)]">${(commissionTrend.reduce((s, m) => s + m.paid, 0) / 1000).toFixed(0)}K</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Outstanding</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5 text-[color:var(--warning)]">${(commissionTrend[commissionTrend.length - 1].total / 1000).toFixed(0)}K</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rep commissions table */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Percent className="h-4 w-4 text-primary" />
              Rep Commissions
            </CardTitle>
            <CardDescription>Per-rep commission calculations for the current period.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.success("Approving all pending commissions")}>
            Approve All <CheckCircle2 className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Sales Rep</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right hidden sm:table-cell">Deals Closed</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Revenue</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Tier</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right hidden md:table-cell">Base</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right hidden lg:table-cell">Bonus</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Total</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-center">Status</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reps.map((r) => {
                const total = r.baseCommission + r.bonus;
                const tier = tierConfig[r.tier];
                return (
                  <TableRow key={r.id} className="hover:bg-muted/30">
                    <TableCell>
                      <div className="flex items-center gap-2.5">
                        <Avatar className="h-8 w-8 shrink-0">
                          <AvatarImage src={r.avatar} alt={r.name} />
                          <AvatarFallback className="text-[10px]">
                            {r.name.split(" ").map((p) => p[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{r.name}</p>
                          <p className="text-xs text-muted-foreground font-mono">{r.id}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums hidden sm:table-cell">{r.dealsClosed}</TableCell>
                    <TableCell className="text-right tabular-nums font-medium">${(r.revenue / 1000).toFixed(0)}K</TableCell>
                    <TableCell>
                      <StatusBadge tone={tier.tone} className="whitespace-nowrap">
                        {tier.label}
                      </StatusBadge>
                    </TableCell>
                    <TableCell className="text-right tabular-nums hidden md:table-cell text-muted-foreground">
                      ${r.baseCommission.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right tabular-nums hidden lg:table-cell">
                      {r.bonus > 0 ? (
                        <span className="text-[color:var(--success)] font-medium">+${r.bonus.toLocaleString()}</span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right tabular-nums font-semibold">${total.toLocaleString()}</TableCell>
                    <TableCell className="text-center">
                      <StatusBadge tone={statusToneMap[r.status]} dot className="capitalize">
                        {r.status}
                      </StatusBadge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-44">
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening ${r.name} commission detail`)}>
                            <Eye className="h-3.5 w-3.5" /> View detail
                          </DropdownMenuItem>
                          {r.status === "pending" && (
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`${r.name} commission approved`)}>
                              <CheckCircle2 className="h-3.5 w-3.5" /> Approve
                            </DropdownMenuItem>
                          )}
                          {r.status === "approved" && (
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Payment queued for ${r.name}`)}>
                              <DollarSign className="h-3.5 w-3.5" /> Mark as paid
                            </DropdownMenuItem>
                          )}
                          {r.status === "disputed" && (
                            <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening dispute for ${r.name}`)}>
                              <Clock className="h-3.5 w-3.5" /> Resolve dispute
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Statement sent to ${r.name}`)}>
                            <Download className="h-3.5 w-3.5" /> Download statement
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
