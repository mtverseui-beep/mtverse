"use client";

import * as React from "react";
import {
  MessageSquare,
  Search,
  Send,
  Paperclip,
  Smile,
  Phone,
  Video,
  MoreVertical,
  ArrowLeft,
  Info,
  Mic,
  CheckCheck,
  Pin,
  BellOff,
  Ban,
  Trash2,
  Star,
  FileText,
  Image as ImageIcon,
  Plus,
  Users,
  Circle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type Conversation = {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  lastTime: string;
  unread: number;
  online: boolean;
  status: "active" | "away" | "offline";
  role: string;
  email: string;
  phone: string;
  pinned?: boolean;
  isGroup?: boolean;
  members?: number;
};

type Message = {
  id: string;
  conversationId: string;
  senderId: string; // "me" or contact id
  senderName: string;
  senderAvatar?: string;
  text: string;
  time: string;
  status: "sent" | "delivered" | "read";
  reactions?: { emoji: string; count: number }[];
  attachment?: { type: "image" | "file"; name: string; size?: string };
  reply?: { name: string; text: string };
};

type SharedFile = { name: string; size: string; type: "doc" | "image" | "pdf"; date: string };

const conversations: Conversation[] = [
  { id: "c1", name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop", lastMessage: "Perfect — I'll send the updated deck by EOD.", lastTime: "12:42 PM", unread: 2, online: true, status: "active", role: "Senior Product Manager", email: "sarah.chen@nexusgrid.io", phone: "+1 (415) 555-2841", pinned: true },
  { id: "c2", name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop", lastMessage: "Can we move the strategy sync to Thursday?", lastTime: "11:58 AM", unread: 0, online: true, status: "active", role: "VP of Sales", email: "marcus.reyes@nexusgrid.io", phone: "+1 (415) 555-9082" },
  { id: "c3", name: "Engineering Channel", avatar: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=80&h=80&fit=crop", lastMessage: "Aiko: deployment looks clean, pushing to prod", lastTime: "11:30 AM", unread: 5, online: true, status: "active", role: "Group · 12 members", email: "", phone: "", isGroup: true, members: 12 },
  { id: "c4", name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop", lastMessage: "Board deck is locked. Sent for final review.", lastTime: "10:14 AM", unread: 0, online: false, status: "away", role: "Chief Revenue Officer", email: "elena.petrov@nexusgrid.io", phone: "+1 (415) 555-7711" },
  { id: "c5", name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop", lastMessage: "Thanks for the intro — call scheduled for Friday.", lastTime: "Yesterday", unread: 0, online: true, status: "active", role: "Account Executive", email: "james.okoro@nexusgrid.io", phone: "+1 (415) 555-3325" },
  { id: "c6", name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=80&h=80&fit=crop", lastMessage: "I pushed the fix — branch feature/payment-flow", lastTime: "Yesterday", unread: 0, online: false, status: "offline", role: "Staff Engineer", email: "aiko.tanaka@nexusgrid.io", phone: "+1 (415) 555-6047" },
  { id: "c7", name: "Priya Sharma", avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=80&h=80&fit=crop", lastMessage: "Brunch this Saturday? Olive & Oak at 11?", lastTime: "Tue", unread: 1, online: false, status: "offline", role: "Friend", email: "priya.s@gmail.com", phone: "+1 (512) 555-0098" },
  { id: "c8", name: "Design Critique", avatar: "https://images.unsplash.com/photo-1502691876148-a84978e59af8?w=80&h=80&fit=crop", lastMessage: "Daniel: new mockups are in Figma, please leave comments", lastTime: "Mon", unread: 0, online: true, status: "active", role: "Group · 7 members", email: "", phone: "", isGroup: true, members: 7 },
  { id: "c9", name: "Notion Team", avatar: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=80&h=80&fit=crop", lastMessage: "Your subscription renews on Aug 14.", lastTime: "Sun", unread: 0, online: false, status: "offline", role: "Notifications", email: "billing@notion.so", phone: "" },
  { id: "c10", name: "Daniel Foster", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop", lastMessage: "Loved the new onboarding flow — really clean.", lastTime: "Sun", unread: 0, online: false, status: "offline", role: "Lead Designer", email: "daniel.foster@nexusgrid.io", phone: "+1 (415) 555-2204" },
];

const messages: Message[] = [
  { id: "m1", conversationId: "c1", senderId: "c1", senderName: "Sarah Chen", senderAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", text: "Hey — quick one on the Q3 roadmap deck. Are you still good to walk through the platform section together?", time: "12:18 PM", status: "read" },
  { id: "m2", conversationId: "c1", senderId: "me", senderName: "You", text: "Yes! I just finished the first pass on the architecture diagram. Want me to drop it in the doc before we hop on a call?", time: "12:21 PM", status: "read" },
  { id: "m3", conversationId: "c1", senderId: "c1", senderName: "Sarah Chen", senderAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", text: "Please. I'll add comments and we can sync at 2.", time: "12:22 PM", status: "read", reactions: [{ emoji: "+1", count: 1 }] },
  { id: "m4", conversationId: "c1", senderId: "me", senderName: "You", text: "Sounds good. Sharing the diagram and the dependency map. Two files coming through.", time: "12:24 PM", status: "delivered" },
  { id: "m5", conversationId: "c1", senderId: "me", senderName: "You", text: "", time: "12:24 PM", status: "delivered", attachment: { type: "file", name: "Q3-platform-architecture.pdf", size: "2.4 MB" } },
  { id: "m6", conversationId: "c1", senderId: "c1", senderName: "Sarah Chen", senderAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", text: "Got it. Skimming now — initial reaction: love the layered service breakdown. Let's chat about the data layer concern I flagged in the comments.", time: "12:38 PM", status: "read", reply: { name: "You", text: "Sounds good. Sharing the diagram..." } },
  { id: "m7", conversationId: "c1", senderId: "c1", senderName: "Sarah Chen", senderAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", text: "Perfect — I'll send the updated deck by EOD.", time: "12:42 PM", status: "read", reactions: [{ emoji: "heart", count: 1 }] },
];

const sharedFiles: SharedFile[] = [
  { name: "Q3-platform-architecture.pdf", size: "2.4 MB", type: "pdf", date: "Today" },
  { name: "Roadmap-overview.png", size: "820 KB", type: "image", date: "Yesterday" },
  { name: "Customer-interview-notes.docx", size: "1.1 MB", type: "doc", date: "Jul 4" },
  { name: "Stakeholder-feedback.pdf", size: "640 KB", type: "pdf", date: "Jul 2" },
];

export default function ChatPage() {
  const [activeId, setActiveId] = React.useState("c1");
  const [search, setSearch] = React.useState("");
  const [tab, setTab] = React.useState("all");
  const [draft, setDraft] = React.useState("");
  const [mobilePane, setMobilePane] = React.useState<"list" | "thread" | "info">("list");
  const [showInfo, setShowInfo] = React.useState(true);
  const [isTyping, setIsTyping] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  const active = conversations.find((c) => c.id === activeId)!;
  const thread = messages.filter((m) => m.conversationId === activeId);

  const filteredConversations = conversations.filter((c) => {
    if (search && !c.name.toLowerCase().includes(search.toLowerCase()) && !c.lastMessage.toLowerCase().includes(search.toLowerCase())) return false;
    if (tab === "unread" && c.unread === 0) return false;
    if (tab === "groups" && !c.isGroup) return false;
    if (tab === "direct" && c.isGroup) return false;
    return true;
  });

  React.useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [activeId, thread.length]);

  React.useEffect(() => {
    if (activeId !== "c1") return;
    const t = setTimeout(() => setIsTyping(true), 800);
    const t2 = setTimeout(() => setIsTyping(false), 3500);
    return () => { clearTimeout(t); clearTimeout(t2); };
  }, [activeId]);

  function handleSend() {
    if (!draft.trim()) return;
    toast.success("Message sent");
    setDraft("");
  }

  const statusTone: Record<Conversation["status"], StatusTone> = { active: "success", away: "warning", offline: "neutral" };
  const statusLabel: Record<Conversation["status"], string> = { active: "Online", away: "Away", offline: "Offline" };

  return (
    <>
      <PageHeader
        title="Messages"
        description="Real-time team chat with file sharing, reactions, and presence."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "Chat" }]}
        icon={MessageSquare}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("New chat started")}>
            <Plus className="h-3.5 w-3.5" /> New Chat
          </Button>
        }
      />

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr_300px] h-[calc(100vh-220px)] min-h-[560px]">
            {/* CONVERSATION LIST */}
            <div className={cn("border-r flex flex-col", mobilePane === "thread" && "hidden lg:flex")}>
              <div className="p-3 border-b">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search conversations..." className="h-9 pl-8 text-sm" />
                </div>
                <Tabs value={tab} onValueChange={setTab} className="mt-3">
                  <TabsList className="grid w-full grid-cols-4 h-8">
                    <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                    <TabsTrigger value="unread" className="text-xs">Unread</TabsTrigger>
                    <TabsTrigger value="direct" className="text-xs">Direct</TabsTrigger>
                    <TabsTrigger value="groups" className="text-xs">Groups</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
              <ScrollArea className="flex-1">
                <div className="divide-y">
                  {filteredConversations.map((c) => {
                    const isActive = c.id === activeId;
                    return (
                      <button
                        key={c.id}
                        onClick={() => { setActiveId(c.id); setMobilePane("thread"); }}
                        className={cn(
                          "w-full flex items-start gap-3 px-3 py-3 text-left transition-colors relative",
                          isActive ? "bg-primary/[0.06]" : "hover:bg-muted/40"
                        )}
                      >
                        {isActive && <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary" />}
                        <div className="relative shrink-0">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={c.avatar} alt={c.name} />
                            <AvatarFallback>{c.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          {c.online && <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-[color:var(--success)] ring-2 ring-card" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-medium text-foreground truncate flex items-center gap-1">
                              {c.isGroup && <Users className="h-3 w-3 text-muted-foreground" />}
                              {c.name}
                              {c.pinned && <Pin className="h-3 w-3 text-muted-foreground fill-current" />}
                            </span>
                            <span className="text-[10px] text-muted-foreground shrink-0 tabular-nums">{c.lastTime}</span>
                          </div>
                          <div className="flex items-center justify-between gap-2 mt-0.5">
                            <p className="text-xs text-muted-foreground truncate">{c.lastMessage}</p>
                            {c.unread > 0 && (
                              <span className="shrink-0 grid place-items-center h-4.5 min-w-[18px] px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold tabular-nums">
                                {c.unread}
                              </span>
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                  {filteredConversations.length === 0 && (
                    <div className="py-12 text-center text-sm text-muted-foreground">No conversations match.</div>
                  )}
                </div>
              </ScrollArea>
            </div>

            {/* MESSAGE THREAD */}
            <div className={cn("flex flex-col min-w-0", (mobilePane === "list" || (mobilePane === "info")) && "hidden lg:flex")}>
              {/* Thread header */}
              <div className="flex items-center justify-between gap-2 px-4 py-3 border-b">
                <div className="flex items-center gap-3 min-w-0">
                  <Button variant="ghost" size="icon" className="lg:hidden h-8 w-8" onClick={() => setMobilePane("list")}>
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={active.avatar} alt={active.name} />
                    <AvatarFallback>{active.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate flex items-center gap-1">
                      {active.isGroup && <Users className="h-3 w-3 text-muted-foreground" />}
                      {active.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                      {active.online ? (
                        <><span className="h-1.5 w-1.5 rounded-full bg-[color:var(--success)]" /> Active now</>
                      ) : (
                        <>{statusLabel[active.status]} · last seen 2h ago</>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-0.5">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toast.message("Call started")}><Phone className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toast.message("Video call started")}><Video className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" className={cn("h-8 w-8", showInfo && "text-primary")} onClick={() => { setShowInfo((s) => !s); setMobilePane(showInfo ? "thread" : "info"); }}><Info className="h-4 w-4" /></Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8"><MoreVertical className="h-4 w-4" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => toast.success("Pinned")}>Pin conversation</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toast.success("Muted")}>Mute notifications</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toast.success("Marked as read")}>Mark as read</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => toast.success("Conversation archived")}>Archive</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1">
                <div ref={scrollRef} className="p-4 space-y-4">
                  <div className="flex items-center gap-3">
                    <Separator className="flex-1" />
                    <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Today</span>
                    <Separator className="flex-1" />
                  </div>
                  {thread.map((m) => {
                    const me = m.senderId === "me";
                    return (
                      <div key={m.id} className={cn("flex gap-2.5", me && "flex-row-reverse")}>
                        {!me && (
                          <Avatar className="h-7 w-7 shrink-0">
                            <AvatarImage src={m.senderAvatar} alt={m.senderName} />
                            <AvatarFallback className="text-[10px]">{m.senderName.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                          </Avatar>
                        )}
                        <div className={cn("max-w-[75%] min-w-0", me && "items-end flex flex-col")}>
                          {!me && <p className="text-[11px] font-medium text-foreground mb-1">{m.senderName}</p>}
                          {m.reply && (
                            <div className={cn("mb-1 rounded-md border-l-2 border-primary/40 bg-muted/40 px-2 py-1 text-[11px] text-muted-foreground", me && "self-end")}>
                              <p className="font-medium text-foreground">{m.reply.name}</p>
                              <p className="truncate">{m.reply.text}</p>
                            </div>
                          )}
                          <div className={cn(
                            "rounded-2xl px-3 py-2 text-sm relative group",
                            me ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm"
                          )}>
                            {m.attachment ? (
                              <div className="flex items-center gap-3 min-w-[220px]">
                                <div className={cn("grid place-items-center h-10 w-10 rounded-lg shrink-0", me ? "bg-primary-foreground/15" : "bg-background")}>
                                  {m.attachment.type === "image" ? <ImageIcon className="h-5 w-5" /> : <FileText className="h-5 w-5" />}
                                </div>
                                <div className="min-w-0">
                                  <p className="text-sm font-medium truncate">{m.attachment.name}</p>
                                  <p className={cn("text-[10px] tabular-nums", me ? "text-primary-foreground/70" : "text-muted-foreground")}>{m.attachment.size}</p>
                                </div>
                              </div>
                            ) : (
                              <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
                            )}
                            <div className={cn("flex items-center justify-end gap-1 mt-1 text-[10px]", me ? "text-primary-foreground/70" : "text-muted-foreground")}>
                              <span className="tabular-nums">{m.time}</span>
                              {me && <CheckCheck className={cn("h-3 w-3", m.status === "read" && "text-primary-foreground")} />}
                            </div>
                          </div>
                          {m.reactions && m.reactions.length > 0 && (
                            <div className={cn("flex gap-1 mt-1", me && "justify-end")}>
                              {m.reactions.map((r, i) => (
                                <span key={i} className="inline-flex items-center gap-1 rounded-full bg-muted border border-border px-1.5 py-0.5 text-[10px] font-medium">
                                  <ReactionEmoji type={r.emoji} /> {r.count}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  {isTyping && (
                    <div className="flex gap-2.5">
                      <Avatar className="h-7 w-7 shrink-0">
                        <AvatarImage src={active.avatar} alt={active.name} />
                        <AvatarFallback className="text-[10px]">{active.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                      </Avatar>
                      <div className="rounded-2xl rounded-bl-sm bg-muted px-4 py-2.5 flex items-center gap-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0ms" }} />
                        <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "150ms" }} />
                        <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "300ms" }} />
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* Input */}
              <div className="border-t p-3">
                <div className="flex items-end gap-2">
                  <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => toast.message("Attach file")}><Paperclip className="h-4 w-4" /></Button>
                  <div className="flex-1 relative">
                    <Input
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                      placeholder="Type a message..."
                      className="h-10 pr-10 text-sm"
                    />
                    <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8" onClick={() => toast.message("Emoji picker")}><Smile className="h-4 w-4" /></Button>
                  </div>
                  <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => toast.message("Voice message")}><Mic className="h-4 w-4" /></Button>
                  <Button size="icon" className="h-9 w-9 shrink-0 gap-0" onClick={handleSend} disabled={!draft.trim()}><Send className="h-4 w-4" /></Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1.5 px-1">Press Enter to send · Shift+Enter for new line</p>
              </div>
            </div>

            {/* CONTACT INFO */}
            <div className={cn("border-l flex flex-col", mobilePane !== "info" && "hidden lg:flex")}>
              <div className="flex items-center justify-between px-4 py-3 border-b">
                <p className="text-sm font-medium">Contact Info</p>
                <Button variant="ghost" size="icon" className="h-7 w-7 lg:hidden" onClick={() => setMobilePane("thread")}><ArrowLeft className="h-4 w-4" /></Button>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-4">
                  <div className="flex flex-col items-center text-center">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={active.avatar} alt={active.name} />
                      <AvatarFallback>{active.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <p className="text-base font-semibold mt-3 flex items-center gap-1.5">
                      {active.name}
                      {active.isGroup && <Users className="h-3.5 w-3.5 text-muted-foreground" />}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">{active.role}</p>
                    <StatusBadge tone={statusTone[active.status]} dot className="mt-2">{statusLabel[active.status]}</StatusBadge>
                  </div>

                  <Separator className="my-4" />

                  <div className="space-y-3 text-sm">
                    {active.email && (
                      <div>
                        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Email</p>
                        <p className="text-foreground truncate">{active.email}</p>
                      </div>
                    )}
                    {active.phone && (
                      <div>
                        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Phone</p>
                        <p className="text-foreground tabular-nums">{active.phone}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Timezone</p>
                      <p className="text-foreground">PST · UTC−8</p>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Shared Files ({sharedFiles.length})</p>
                    <Button variant="ghost" size="sm" className="h-6 text-[10px] px-2">View all</Button>
                  </div>
                  <div className="space-y-1.5">
                    {sharedFiles.map((f, i) => (
                      <button key={i} onClick={() => toast.success(`Downloading ${f.name}`)} className="w-full flex items-center gap-2.5 rounded-md p-2 hover:bg-muted/50 transition-colors text-left">
                        <div className={cn(
                          "grid place-items-center h-8 w-8 rounded-md shrink-0",
                          f.type === "pdf" ? "bg-destructive/10 text-destructive" : f.type === "image" ? "bg-[color:var(--info)]/12 text-[color:var(--info)]" : "bg-primary/10 text-primary"
                        )}>
                          {f.type === "image" ? <ImageIcon className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium truncate">{f.name}</p>
                          <p className="text-[10px] text-muted-foreground">{f.size} · {f.date}</p>
                        </div>
                      </button>
                    ))}
                  </div>

                  <Separator className="my-4" />

                  <div className="space-y-1.5">
                    <Button variant="outline" size="sm" className="w-full justify-start gap-2" onClick={() => toast.success("Notifications muted")}><BellOff className="h-3.5 w-3.5" /> Mute notifications</Button>
                    <Button variant="outline" size="sm" className="w-full justify-start gap-2" onClick={() => toast.success("Pinned to top")}><Pin className="h-3.5 w-3.5" /> Pin to top</Button>
                    <Button variant="outline" size="sm" className="w-full justify-start gap-2" onClick={() => toast.success("Starred")}><Star className="h-3.5 w-3.5" /> Star conversation</Button>
                    <Button variant="outline" size="sm" className="w-full justify-start gap-2 text-destructive hover:text-destructive" onClick={() => toast.success("User blocked")}><Ban className="h-3.5 w-3.5" /> Block user</Button>
                    <Button variant="outline" size="sm" className="w-full justify-start gap-2 text-destructive hover:text-destructive" onClick={() => toast.success("Conversation cleared")}><Trash2 className="h-3.5 w-3.5" /> Clear chat</Button>
                  </div>
                </div>
              </ScrollArea>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}

function ReactionEmoji({ type }: { type: string }) {
  // Use simple ASCII/text representations for reactions
  const map: Record<string, string> = {
    "+1": "+1",
    heart: "♥",
    laugh: "ha",
    wow: "wow",
    sad: ":(",
  };
  return <span className="text-[11px]">{map[type] ?? type}</span>;
}
