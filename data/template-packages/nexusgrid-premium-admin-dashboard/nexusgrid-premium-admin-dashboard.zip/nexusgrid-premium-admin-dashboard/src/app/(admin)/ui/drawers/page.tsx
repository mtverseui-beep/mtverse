"use client";

import * as React from "react";
import {
  PanelRightOpen,
  Filter,
  Bell,
  User,
  Settings,
  Search,
  ChevronRight,
  Mail,
  Clock,
  Shield,
  ArrowDown,
  ArrowUp,
  ArrowLeft,
  ArrowRight,
  Star,
  Inbox,
  Save,
  X,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function NotificationRow({
  icon: Icon,
  title,
  body,
  time,
  unread,
  tone = "primary",
}: {
  icon: typeof Bell;
  title: string;
  body: string;
  time: string;
  unread?: boolean;
  tone?: "primary" | "info" | "success" | "warning" | "violet";
}) {
  return (
    <div className={cn("flex items-start gap-3 rounded-md p-2.5 hover:bg-accent transition-colors", unread && "bg-primary/5")}>
      <div
        className={cn(
          "grid h-8 w-8 shrink-0 place-items-center rounded-lg",
          tone === "primary" && "bg-primary/15 text-primary",
          tone === "info" && "bg-[color:var(--info)]/15 text-[color:var(--info)]",
          tone === "success" && "bg-[color:var(--success)]/15 text-[color:var(--success)]",
          tone === "warning" && "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
          tone === "violet" && "bg-violet-500/15 text-violet-500"
        )}
      >
        <Icon className="h-3.5 w-3.5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium">{title}</p>
        <p className="text-xs text-muted-foreground line-clamp-2">{body}</p>
        <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
          <Clock className="h-2.5 w-2.5" /> {time}
        </p>
      </div>
      {unread && <span className="mt-1 h-2 w-2 rounded-full bg-primary shrink-0" />}
    </div>
  );
}

export default function DrawersPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Drawers"
        description="Side panels that slide in from the four edges — ideal for filters, notifications and forms."
        icon={PanelRightOpen}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/drawers" },
          { label: "Drawers" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Drawer spec sheet copied")}>
            <Settings /> Spec sheet
          </Button>
        }
      />

      {/* Drawer positions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Drawer positions</CardTitle>
          <CardDescription>
            Four directions: left, right, top and bottom. Each opens a panel anchored to that edge.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {/* Right */}
          <Drawer direction="right">
            <DrawerTrigger asChild>
              <Button variant="outline" className="w-full justify-between">
                Right drawer <ArrowRight />
              </Button>
            </DrawerTrigger>
            <DrawerContent>
              <DrawerHeader className="text-left">
                <DrawerTitle>Notifications</DrawerTitle>
                <DrawerDescription>You have 4 unread notifications.</DrawerDescription>
              </DrawerHeader>
              <div className="flex-1 overflow-y-auto px-4 pb-2 space-y-1 max-h-[60vh]">
                <NotificationRow icon={Inbox} title="New comment on PR #1284" body="Devon Park: 'Could we extract this into a hook?'" time="2m ago" unread tone="primary" />
                <NotificationRow icon={Shield} title="2FA enabled" body="Your account security was upgraded by an admin." time="1h ago" unread tone="success" />
                <NotificationRow icon={Mail} title="Invoice INV-2041 paid" body="$1,290.00 received from Globex Industries." time="3h ago" unread tone="info" />
                <NotificationRow icon={Star} title="Workspace upgraded to Pro" body="You now have access to audit logs and 50 GB storage." time="5h ago" unread tone="violet" />
                <NotificationRow icon={Bell} title="Weekly digest ready" body="Your team shipped 18 PRs and closed 24 tickets this week." time="Yesterday" tone="primary" />
              </div>
              <DrawerFooter>
                <Button onClick={() => toast.success("All marked as read")}>Mark all as read</Button>
                <DrawerClose asChild>
                  <Button variant="outline">Close</Button>
                </DrawerClose>
              </DrawerFooter>
            </DrawerContent>
          </Drawer>

          {/* Left */}
          <Drawer direction="left">
            <DrawerTrigger asChild>
              <Button variant="outline" className="w-full justify-between">
                <ArrowLeft /> Left drawer
              </Button>
            </DrawerTrigger>
            <DrawerContent>
              <DrawerHeader className="text-left">
                <DrawerTitle>Filters</DrawerTitle>
                <DrawerDescription>Refine the customer list.</DrawerDescription>
              </DrawerHeader>
              <div className="flex-1 overflow-y-auto px-4 pb-2 space-y-4 max-h-[60vh]">
                <div className="space-y-2">
                  <Label className="text-xs">Status</Label>
                  <div className="flex flex-wrap gap-1.5">
                    {["Active", "Trial", "Past due", "Churned"].map((s, i) => (
                      <Badge key={s} variant={i === 0 ? "default" : "outline"} className="cursor-pointer">
                        {s}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Plan</Label>
                  <div className="flex flex-wrap gap-1.5">
                    {["Starter", "Pro", "Enterprise"].map((s, i) => (
                      <Badge key={s} variant={i === 1 ? "default" : "outline"} className="cursor-pointer">
                        {s}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Country</Label>
                  <Input placeholder="Search country…" />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Monthly spend range</Label>
                  <div className="flex gap-2">
                    <Input type="number" placeholder="Min" defaultValue={0} />
                    <Input type="number" placeholder="Max" defaultValue={5000} />
                  </div>
                </div>
              </div>
              <DrawerFooter>
                <Button onClick={() => toast.success("Filters applied")}>
                  Apply filters
                </Button>
                <Button variant="ghost" onClick={() => toast.message("Filters cleared")}>
                  Clear all
                </Button>
              </DrawerFooter>
            </DrawerContent>
          </Drawer>

          {/* Top */}
          <Drawer direction="top">
            <DrawerTrigger asChild>
              <Button variant="outline" className="w-full justify-between">
                Top drawer <ArrowUp />
              </Button>
            </DrawerTrigger>
            <DrawerContent>
              <DrawerHeader className="text-center">
                <DrawerTitle>Quick search</DrawerTitle>
                <DrawerDescription>Find anything in your workspace.</DrawerDescription>
              </DrawerHeader>
              <div className="px-4 pb-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input autoFocus placeholder="Search projects, tasks, customers…" className="pl-9 h-11" />
                </div>
                <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2">
                  {["Projects", "Tasks", "Customers", "Invoices"].map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => toast.message(`Searching in ${q}`)}
                      className="rounded-md border bg-card p-2 text-xs text-left hover:bg-accent transition-colors"
                    >
                      <p className="font-medium">{q}</p>
                      <p className="text-muted-foreground">Quick filter</p>
                    </button>
                  ))}
                </div>
              </div>
              <DrawerFooter className="flex-row justify-end">
                <DrawerClose asChild>
                  <Button variant="outline">Close</Button>
                </DrawerClose>
                <Button onClick={() => toast.success("Search submitted")}>
                  Search
                </Button>
              </DrawerFooter>
            </DrawerContent>
          </Drawer>

          {/* Bottom */}
          <Drawer direction="bottom">
            <DrawerTrigger asChild>
              <Button variant="outline" className="w-full justify-between">
                Bottom drawer <ArrowDown />
              </Button>
            </DrawerTrigger>
            <DrawerContent>
              <DrawerHeader className="text-center">
                <DrawerTitle>Sort customers by</DrawerTitle>
                <DrawerDescription>Choose a sort field and direction.</DrawerDescription>
              </DrawerHeader>
              <div className="px-4 pb-2 grid gap-2 sm:grid-cols-2">
                {[
                  { label: "Name (A → Z)", icon: ArrowDown },
                  { label: "Name (Z → A)", icon: ArrowUp },
                  { label: "Recent activity", icon: Clock },
                  { label: "Monthly spend (high → low)", icon: ArrowDown },
                ].map((opt, i) => (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => toast.success(`Sorted by ${opt.label}`)}
                    className={cn(
                      "flex items-center gap-3 rounded-md border p-3 text-left hover:bg-accent transition-colors",
                      i === 0 && "border-primary ring-1 ring-primary/30 bg-primary/5"
                    )}
                  >
                    <div className="grid h-8 w-8 place-items-center rounded-md bg-muted">
                      <opt.icon className="h-3.5 w-3.5" />
                    </div>
                    <span className="text-sm font-medium flex-1">{opt.label}</span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </button>
                ))}
              </div>
              <DrawerFooter>
                <DrawerClose asChild>
                  <Button>Apply sort</Button>
                </DrawerClose>
              </DrawerFooter>
            </DrawerContent>
          </Drawer>
        </CardContent>
      </Card>

      {/* Sizes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Drawer sizes</CardTitle>
          <CardDescription>
            Three widths via Tailwind overrides — small (320px), medium (480px), large (640px).
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {[
            { label: "Small", width: "sm:max-w-sm" },
            { label: "Medium", width: "sm:max-w-md" },
            { label: "Large", width: "sm:max-w-xl" },
          ].map((s) => (
            <Drawer key={s.label} direction="right">
              <DrawerTrigger asChild>
                <Button variant="outline">{s.label} drawer</Button>
              </DrawerTrigger>
              <DrawerContent className={s.width}>
                <DrawerHeader className="text-left">
                  <DrawerTitle>{s.label} drawer</DrawerTitle>
                  <DrawerDescription>
                    Width capped at {s.label.toLowerCase()} — useful for varying content density.
                  </DrawerDescription>
                </DrawerHeader>
                <div className="flex-1 overflow-y-auto px-4 pb-2 space-y-2 max-h-[55vh]">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="rounded-md border bg-card p-3 text-sm">
                      <p className="font-medium">Section {i + 1}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Sample content block to demonstrate scroll behavior at this width.
                      </p>
                    </div>
                  ))}
                </div>
                <DrawerFooter>
                  <DrawerClose asChild>
                    <Button>Close</Button>
                  </DrawerClose>
                </DrawerFooter>
              </DrawerContent>
            </Drawer>
          ))}
        </CardContent>
      </Card>

      {/* Use cases */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Profile drawer</CardTitle>
            <CardDescription>
              Slide-in detail view for a team member — header, stats, settings and footer actions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Drawer direction="right">
              <DrawerTrigger asChild>
                <Button className="w-full" variant="outline">
                  <User /> Open profile drawer
                </Button>
              </DrawerTrigger>
              <DrawerContent className="sm:max-w-md">
                <DrawerHeader className="text-left">
                  <DrawerTitle>Member profile</DrawerTitle>
                  <DrawerDescription>View and edit team member details.</DrawerDescription>
                </DrawerHeader>
                <div className="flex-1 overflow-y-auto px-4 pb-2 space-y-4 max-h-[60vh]">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-14 w-14 ring-2 ring-primary ring-offset-2 ring-offset-background">
                      <AvatarImage src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop" alt="Devon Park" />
                      <AvatarFallback>DP</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold">Devon Park</p>
                      <p className="text-sm text-muted-foreground">Engineering Lead · London</p>
                      <Badge className="mt-1 bg-[color:var(--success)]/15 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/25 border-transparent gap-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--success)]" /> Online
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center">
                    {[
                      { label: "Commits", value: "2,841" },
                      { label: "PRs", value: "184" },
                      { label: "Reviews", value: "392" },
                    ].map((s) => (
                      <div key={s.label} className="rounded-md border bg-card p-2.5">
                        <p className="text-lg font-semibold tabular-nums">{s.value}</p>
                        <p className="text-[10px] text-muted-foreground">{s.label}</p>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <Label className="text-xs">Permissions</Label>
                    {[
                      { label: "Can manage members", on: false },
                      { label: "Can manage billing", on: true },
                      { label: "Can export data", on: true },
                      { label: "Can delete workspace", on: false },
                    ].map((p) => (
                      <div key={p.label} className="flex items-center justify-between">
                        <span className="text-sm">{p.label}</span>
                        <Switch defaultChecked={p.on} />
                      </div>
                    ))}
                  </div>
                </div>
                <DrawerFooter>
                  <Button onClick={() => toast.success("Permissions saved")}>
                    <Save /> Save permissions
                  </Button>
                  <DrawerClose asChild>
                    <Button variant="outline">Close</Button>
                  </DrawerClose>
                </DrawerFooter>
              </DrawerContent>
            </Drawer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Mobile-style bottom sheet</CardTitle>
            <CardDescription>
              Bottom drawers feel native on mobile. The drag handle appears automatically.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Drawer direction="bottom">
              <DrawerTrigger asChild>
                <Button className="w-full" variant="outline">
                  <Filter /> Open bottom sheet
                </Button>
              </DrawerTrigger>
              <DrawerContent className="sm:max-w-md sm:mx-auto">
                <DrawerHeader className="text-center">
                  <DrawerTitle>Apply quick filters</DrawerTitle>
                  <DrawerDescription>Tap to toggle a filter on or off.</DrawerDescription>
                </DrawerHeader>
                <div className="px-4 pb-2 space-y-2 max-h-[55vh] overflow-y-auto">
                  {[
                    "Open issues only",
                    "Assigned to me",
                    "High priority",
                    "Created in last 7 days",
                    "Blocked",
                    "Awaiting review",
                  ].map((f, i) => (
                    <label
                      key={f}
                      className="flex items-center justify-between rounded-md border bg-card p-3 cursor-pointer hover:bg-accent"
                    >
                      <span className="text-sm font-medium">{f}</span>
                      <Switch defaultChecked={i < 2} />
                    </label>
                  ))}
                </div>
                <DrawerFooter>
                  <Button onClick={() => toast.success("Filters applied")}>
                    Apply 2 filters
                  </Button>
                  <DrawerClose asChild>
                    <Button variant="ghost">
                      <X /> Cancel
                    </Button>
                  </DrawerClose>
                </DrawerFooter>
              </DrawerContent>
            </Drawer>
          </CardContent>
        </Card>
      </div>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Drawers page · 4 positions · 3 sizes · profile + filter + notification use cases
      </p>
    </div>
  );
}
