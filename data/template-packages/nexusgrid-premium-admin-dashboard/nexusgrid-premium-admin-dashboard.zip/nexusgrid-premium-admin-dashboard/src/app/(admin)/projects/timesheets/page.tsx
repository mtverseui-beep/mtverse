"use client";

import * as React from "react";
import {
  Clock,
  Plus,
  Download,
  CheckCircle2,
  XCircle,
  Timer,
  DollarSign,
  Calendar,
  Filter,
  MoreHorizontal,
  Eye,
  Pencil,
  Trash2,
  CheckCheck,
  RotateCcw,
  ArrowUpRight,
  ArrowDownRight,
  ChevronLeft,
  ChevronRight,
  StickyNote,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type EntryStatus = "approved" | "pending" | "rejected";
type Weekday = "Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat" | "Sun";

type TimeEntry = {
  id: string;
  date: string;
  project: string;
  projectColor: string;
  task: string;
  member: string;
  memberAvatar: string;
  hours: number;
  billable: boolean;
  rate: number;
  status: EntryStatus;
  notes: string;
};

const projList = [
  { id: "PRJ-014", name: "Atlas Mobile Redesign", color: "var(--primary)" },
  { id: "PRJ-013", name: "Pulse Analytics Platform", color: "var(--info)" },
  { id: "PRJ-012", name: "Vertex Payment Gateway", color: "var(--destructive)" },
  { id: "PRJ-011", name: "Nimbus Cloud Migration", color: "var(--success)" },
  { id: "PRJ-009", name: "Orbit Data Pipeline", color: "oklch(0.62 0.18 305)" },
  { id: "PRJ-008", name: "Helix CRM Integration", color: "oklch(0.70 0.15 75)" },
];

const team = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", rate: 145 },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", rate: 135 },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", rate: 155 },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", rate: 125 },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", rate: 140 },
];

const statusTone: Record<EntryStatus, StatusTone> = {
  approved: "success",
  pending: "warning",
  rejected: "danger",
};

const days: { key: Weekday; date: string }[] = [
  { key: "Mon", date: "Jun 30" },
  { key: "Tue", date: "Jul 01" },
  { key: "Wed", date: "Jul 02" },
  { key: "Thu", date: "Jul 03" },
  { key: "Fri", date: "Jul 04" },
  { key: "Sat", date: "Jul 05" },
  { key: "Sun", date: "Jul 06" },
];

// Week grid — rows are tasks, columns are days with hours logged
const weekRows: { task: string; project: string; projectColor: string; member: string; hours: Record<Weekday, number> }[] = [
  { task: "Biometric login flow", project: "Atlas Mobile", projectColor: "var(--primary)", member: "Sarah Chen", hours: { Mon: 4, Tue: 5, Wed: 3, Thu: 4, Fri: 2, Sat: 0, Sun: 0 } },
  { task: "Design token refresh", project: "Atlas Mobile", projectColor: "var(--primary)", member: "Marcus Reyes", hours: { Mon: 3, Tue: 2, Wed: 4, Thu: 0, Fri: 0, Sat: 0, Sun: 0 } },
  { task: "Migrate analytics v2", project: "Pulse Analytics", projectColor: "var(--info)", member: "Elena Petrov", hours: { Mon: 6, Tue: 5, Wed: 4, Thu: 6, Fri: 4, Sat: 0, Sun: 0 } },
  { task: "PCI-DSS audit prep", project: "Vertex Payment", projectColor: "var(--destructive)", member: "James Okoro", hours: { Mon: 2, Tue: 3, Wed: 4, Thu: 2, Fri: 3, Sat: 4, Sun: 0 } },
  { task: "Onboarding tour redesign", project: "Atlas Mobile", projectColor: "var(--primary)", member: "Aiko Tanaka", hours: { Mon: 4, Tue: 4, Wed: 3, Thu: 4, Fri: 0, Sat: 0, Sun: 0 } },
  { task: "Kafka topic backfill", project: "Orbit Pipeline", projectColor: "oklch(0.62 0.18 305)", member: "Sarah Chen", hours: { Mon: 0, Tue: 0, Wed: 2, Thu: 3, Fri: 5, Sat: 0, Sun: 0 } },
  { task: "Salesforce OAuth2", project: "Helix CRM", projectColor: "oklch(0.70 0.15 75)", member: "Marcus Reyes", hours: { Mon: 2, Tue: 3, Wed: 2, Thu: 0, Fri: 0, Sat: 0, Sun: 0 } },
  { task: "Cutover runbook", project: "Nimbus Cloud", projectColor: "var(--success)", member: "James Okoro", hours: { Mon: 1, Tue: 2, Wed: 0, Thu: 3, Fri: 4, Sat: 0, Sun: 0 } },
];

const timeEntries: TimeEntry[] = [
  { id: "TE-9001", date: "Jul 06, 2026", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", task: "Biometric login flow", member: "Sarah Chen", memberAvatar: team[0].avatar, hours: 4, billable: true, rate: 145, status: "pending", notes: "Finalizing Face ID integration, awaiting design sign-off" },
  { id: "TE-9002", date: "Jul 06, 2026", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", task: "Kafka topic backfill", member: "Sarah Chen", memberAvatar: team[0].avatar, hours: 5, billable: true, rate: 145, status: "approved", notes: "Backfill job tuned and replayed 2.4M events" },
  { id: "TE-9003", date: "Jul 05, 2026", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", task: "PCI-DSS audit prep", member: "James Okoro", memberAvatar: team[3].avatar, hours: 4, billable: true, rate: 125, status: "pending", notes: "Weekend audit prep, gathering evidence for QSA" },
  { id: "TE-9004", date: "Jul 04, 2026", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", task: "Onboarding tour redesign", member: "Aiko Tanaka", memberAvatar: team[4].avatar, hours: 0, billable: false, rate: 0, status: "rejected", notes: "Holiday — not billable, please reclassify" },
  { id: "TE-9005", date: "Jul 04, 2026", project: "Nimbus Cloud Migration", projectColor: "var(--success)", task: "Cutover runbook", member: "James Okoro", memberAvatar: team[3].avatar, hours: 4, billable: true, rate: 125, status: "approved", notes: "Updated rollback procedure and tested in staging" },
  { id: "TE-9006", date: "Jul 03, 2026", project: "Pulse Analytics Platform", projectColor: "var(--info)", task: "Migrate analytics v2", member: "Elena Petrov", memberAvatar: team[2].avatar, hours: 6, billable: true, rate: 155, status: "approved", notes: "Migrated 18 dashboards, fixed 4 schema mismatches" },
  { id: "TE-9007", date: "Jul 03, 2026", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", task: "Kafka topic backfill", member: "Sarah Chen", memberAvatar: team[0].avatar, hours: 3, billable: true, rate: 145, status: "pending", notes: "Tuning consumer lag, will resume Monday" },
  { id: "TE-9008", date: "Jul 03, 2026", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", task: "Salesforce OAuth2", member: "Marcus Reyes", memberAvatar: team[1].avatar, hours: 0, billable: false, rate: 0, status: "rejected", notes: "Duplicate entry, merged with TE-9010" },
  { id: "TE-9009", date: "Jul 02, 2026", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", task: "Design token refresh", member: "Marcus Reyes", memberAvatar: team[1].avatar, hours: 4, billable: true, rate: 135, status: "approved", notes: "Implemented rate limiter with sliding window" },
  { id: "TE-9010", date: "Jul 02, 2026", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", task: "Salesforce OAuth2", member: "Marcus Reyes", memberAvatar: team[1].avatar, hours: 3, billable: true, rate: 135, status: "pending", notes: "OAuth flow working in sandbox, need prod credentials" },
  { id: "TE-9011", date: "Jul 02, 2026", project: "Pulse Analytics Platform", projectColor: "var(--info)", task: "Migrate analytics v2", member: "Elena Petrov", memberAvatar: team[2].avatar, hours: 4, billable: true, rate: 155, status: "approved", notes: "Schema migration script completed" },
  { id: "TE-9012", date: "Jul 01, 2026", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", task: "PCI-DSS audit prep", member: "James Okoro", memberAvatar: team[3].avatar, hours: 3, billable: true, rate: 125, status: "approved", notes: "Compiled evidence pack for requirement 3" },
  { id: "TE-9013", date: "Jul 01, 2026", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", task: "Biometric login flow", member: "Sarah Chen", memberAvatar: team[0].avatar, hours: 5, billable: true, rate: 145, status: "approved", notes: "Implemented Face ID with fallback to passcode" },
  { id: "TE-9014", date: "Jul 01, 2026", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", task: "Onboarding tour redesign", member: "Aiko Tanaka", memberAvatar: team[4].avatar, hours: 4, billable: true, rate: 140, status: "pending", notes: "New tour flow prototyped in Figma" },
  { id: "TE-9015", date: "Jun 30, 2026", project: "Pulse Analytics Platform", projectColor: "var(--info)", task: "Migrate analytics v2", member: "Elena Petrov", memberAvatar: team[2].avatar, hours: 6, billable: true, rate: 155, status: "approved", notes: "Initial schema audit + dependency graph" },
];

/* ---------- TimeKpi — clock dial motif ---------- */

function TimeKpi({
  label,
  value,
  unit,
  icon: Icon,
  accent,
  dialValue,
  dialMax,
  trend,
  caption,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  accent: "primary" | "success" | "warning" | "danger" | "info";
  dialValue: number;
  dialMax: number;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  caption: string;
}) {
  const colorMap: Record<string, string> = {
    primary: "var(--primary)",
    success: "var(--success)",
    warning: "var(--warning)",
    danger: "var(--destructive)",
    info: "var(--info)",
  };
  const color = colorMap[accent];
  const bgMap: Record<string, string> = {
    primary: "bg-primary/12 text-primary",
    success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/12 text-[color:var(--warning)]",
    danger: "bg-destructive/12 text-destructive",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
  };
  const pct = Math.min(dialValue / dialMax, 1);
  const R = 26;
  const C = 2 * Math.PI * R;

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      <div className="flex items-start gap-4">
        {/* Clock dial */}
        <div className="relative shrink-0">
          <svg width={64} height={64} viewBox="0 0 64 64" className="-rotate-90">
            <circle cx={32} cy={32} r={R} fill="none" stroke="var(--muted)" strokeWidth={5} />
            <circle
              cx={32}
              cy={32}
              r={R}
              fill="none"
              stroke={color}
              strokeWidth={5}
              strokeLinecap="round"
              strokeDasharray={`${C * pct} ${C}`}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center rotate-0">
            <span className="text-xs font-semibold tabular-nums" style={{ color }}>{Math.round(pct * 100)}%</span>
          </div>
        </div>
        {/* Content */}
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">{label}</p>
            <div className={cn("grid place-items-center h-7 w-7 rounded-lg shrink-0", bgMap[accent])}>
              <Icon className="h-3.5 w-3.5" />
            </div>
          </div>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
            {unit && <span className="text-sm font-medium text-muted-foreground">{unit}</span>}
          </div>
          <div className="mt-1 flex items-center gap-1.5">
            <span className={cn("inline-flex items-center gap-0.5 text-[11px] font-medium tabular-nums", trend.positive ? "text-[color:var(--success)]" : "text-destructive")}>
              {trend.direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {Math.abs(trend.value)}%
            </span>
            <span className="text-[11px] text-muted-foreground truncate">{caption}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function TimesheetsPage() {
  const totalHours = timeEntries.reduce((s, e) => s + e.hours, 0);
  const billableHours = timeEntries.filter((e) => e.billable).reduce((s, e) => s + e.hours, 0);
  const weekHours = weekRows.reduce((s, r) => s + Object.values(r.hours).reduce((a, b) => a + b, 0), 0);
  const pendingCount = timeEntries.filter((e) => e.status === "pending").length;

  const columns: Column<TimeEntry>[] = React.useMemo(() => [
    {
      key: "date",
      header: "Date",
      sortable: true,
      sortAccessor: (r) => r.date,
      cell: (r) => <span className="font-mono text-xs text-muted-foreground">{r.date}</span>,
      width: "w-32",
    },
    {
      key: "project",
      header: "Project",
      sortable: true,
      sortAccessor: (r) => r.project,
      filterable: true,
      filterAccessor: (r) => r.project,
      filterOptions: projList.map((p) => ({ label: p.name, value: p.name })),
      cell: (r) => (
        <span
          className="inline-flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded-md ring-1 ring-inset"
          style={{
            color: r.projectColor,
            background: `color-mix(in srgb, ${r.projectColor} 12%, transparent)`,
            borderColor: `color-mix(in srgb, ${r.projectColor} 25%, transparent)`,
          }}
        >
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: r.projectColor }} />
          {r.project}
        </span>
      ),
      width: "w-48",
    },
    {
      key: "task",
      header: "Task",
      sortable: true,
      sortAccessor: (r) => r.task,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <StickyNote className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          <div className="min-w-0">
            <p className="text-sm font-medium truncate">{r.task}</p>
            <p className="text-[10px] text-muted-foreground line-clamp-1 truncate max-w-[200px]">{r.notes}</p>
          </div>
        </div>
      ),
    },
    {
      key: "member",
      header: "Team Member",
      sortable: true,
      sortAccessor: (r) => r.member,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7">
            <AvatarImage src={r.memberAvatar} alt={r.member} />
            <AvatarFallback className="text-[10px]">{r.member.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
          </Avatar>
          <span className="text-xs text-muted-foreground truncate">{r.member}</span>
        </div>
      ),
      width: "w-36",
    },
    {
      key: "hours",
      header: "Hours",
      sortable: true,
      sortAccessor: (r) => r.hours,
      align: "right",
      cell: (r) => (
        <span className="inline-flex items-center gap-1 text-sm font-semibold tabular-nums">
          <Timer className="h-3 w-3 text-muted-foreground" />
          {r.hours}h
        </span>
      ),
      width: "w-24",
    },
    {
      key: "billable",
      header: "Billable",
      sortable: true,
      sortAccessor: (r) => (r.billable ? 1 : 0),
      align: "center",
      cell: (r) => (
        r.billable ? (
          <div className="text-center">
            <StatusBadge tone="success" className="text-[10px]">Billable</StatusBadge>
            <p className="text-[10px] text-muted-foreground tabular-nums mt-0.5">${r.rate}/hr</p>
          </div>
        ) : (
          <StatusBadge tone="neutral" className="text-[10px]">Internal</StatusBadge>
        )
      ),
      width: "w-28",
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Approved", value: "approved" },
        { label: "Pending", value: "pending" },
        { label: "Rejected", value: "rejected" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={statusTone[r.status]} dot className="capitalize">{r.status}</StatusBadge>
      ),
      width: "w-28",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div onClick={(e) => e.stopPropagation()} className="flex items-center justify-end gap-1">
          {r.status === "pending" && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-[color:var(--success)] hover:text-[color:var(--success)] hover:bg-[color:var(--success)]/10"
                onClick={() => toast.success(`${r.id} approved`)}
                title="Approve"
              >
                <CheckCircle2 className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10"
                onClick={() => toast.error(`${r.id} rejected`)}
                title="Reject"
              >
                <XCircle className="h-4 w-4" />
              </Button>
            </>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel className="text-xs">{r.id}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening ${r.id}`)}>
                <Eye className="h-3.5 w-3.5" /> View
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Editing ${r.id}`)}>
                <Pencil className="h-3.5 w-3.5" /> Edit
              </DropdownMenuItem>
              {r.status === "approved" && (
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`${r.id} reopened`)}>
                  <RotateCcw className="h-3.5 w-3.5" /> Reopen
                </DropdownMenuItem>
              )}
              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${r.id} deleted`)}>
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      width: "w-24",
    },
  ], []);

  return (
    <>
      <PageHeader
        title="Timesheets"
        description="Track time across projects, manage approvals, and audit billable utilization."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: "Timesheets" }]}
        icon={Clock}
        actions={
          <>
            <Select defaultValue="week">
              <SelectTrigger className="h-9 w-[140px] text-xs gap-1.5">
                <Calendar className="h-3.5 w-3.5" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Timesheet exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Time entry drawer opened")}>
              <Plus className="h-3.5 w-3.5" /> Log Time
            </Button>
          </>
        }
      />

      {/* KPI row — TimeKpi with clock dial motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <TimeKpi
          label="Total Hours (mo)"
          value="1,284"
          unit="h"
          icon={Clock}
          accent="primary"
          dialValue={1284}
          dialMax={1600}
          trend={{ value: 8, direction: "up", positive: true }}
          caption="80% of capacity"
        />
        <TimeKpi
          label="Billable Hours"
          value="1,062"
          unit="h"
          icon={DollarSign}
          accent="success"
          dialValue={1062}
          dialMax={1284}
          trend={{ value: 4, direction: "up", positive: true }}
          caption="$154K billable revenue"
        />
        <TimeKpi
          label="This Week"
          value={String(weekHours)}
          unit="h"
          icon={Calendar}
          accent="info"
          dialValue={weekHours}
          dialMax={280}
          trend={{ value: 12, direction: "up", positive: true }}
          caption={`${team.length} team members logging`}
        />
        <TimeKpi
          label="Pending Approval"
          value={String(pendingCount)}
          icon={Filter}
          accent="warning"
          dialValue={pendingCount}
          dialMax={timeEntries.length}
          trend={{ value: 2, direction: "down", positive: true }}
          caption="awaiting manager review"
        />
      </div>

      {/* Week view grid — days as columns, tasks as rows */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="h-4 w-4 text-violet-500" />
              Week View — Jun 30 to Jul 06, 2026
            </CardTitle>
            <CardDescription>Hours logged per task per day. Click a cell to add or edit time.</CardDescription>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => toast.message("Previous week")}>
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <Button variant="outline" size="sm" className="h-8 text-xs">Today</Button>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => toast.message("Next week")}>
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-y border-border bg-muted/40">
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 min-w-[240px]">Task · Member</th>
                  {days.map((d) => (
                    <th key={d.key} className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-2 py-2.5 min-w-[60px]">
                      <div>{d.key}</div>
                      <div className="text-[10px] normal-case text-muted-foreground/70 font-mono">{d.date}</div>
                    </th>
                  ))}
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 min-w-[60px]">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {weekRows.map((row, idx) => {
                  const rowTotal = Object.values(row.hours).reduce((a, b) => a + b, 0);
                  return (
                    <tr key={idx} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full shrink-0" style={{ background: row.projectColor }} />
                          <div className="min-w-0">
                            <p className="text-xs font-medium text-foreground truncate">{row.task}</p>
                            <p className="text-[10px] text-muted-foreground truncate">{row.member} · {row.project}</p>
                          </div>
                        </div>
                      </td>
                      {days.map((d) => {
                        const h = row.hours[d.key];
                        const isWeekend = d.key === "Sat" || d.key === "Sun";
                        const intensity = Math.min(h / 6, 1);
                        return (
                          <td key={d.key} className="px-1 py-1.5 text-center">
                            <button
                              onClick={() => h > 0 ? toast.message(`Editing ${row.task} · ${d.key} (${h}h)`) : toast.message(`Add time for ${row.task} · ${d.key}`)}
                              className={cn(
                                "w-12 h-9 rounded-md text-xs font-semibold tabular-nums transition-all hover:ring-1 hover:ring-primary/30",
                                h === 0 && "text-muted-foreground/40 hover:bg-muted/60",
                                h > 0 && "text-foreground hover:shadow-premium-xs"
                              )}
                              style={h > 0 ? {
                                background: `color-mix(in srgb, ${row.projectColor} ${10 + intensity * 25}%, transparent)`,
                              } : undefined}
                            >
                              {h > 0 ? `${h}h` : isWeekend ? "·" : "+"}
                            </button>
                          </td>
                        );
                      })}
                      <td className="px-4 py-2.5 text-right">
                        <span className="inline-flex items-center gap-1 text-xs font-bold tabular-nums">
                          <Timer className="h-3 w-3 text-muted-foreground" />
                          {rowTotal}h
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-border bg-muted/40">
                  <td className="px-4 py-2.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Daily Total</td>
                  {days.map((d) => {
                    const dayTotal = weekRows.reduce((s, r) => s + r.hours[d.key], 0);
                    return (
                      <td key={d.key} className="px-2 py-2.5 text-center">
                        <span className={cn(
                          "inline-block text-xs font-bold tabular-nums px-1.5 py-0.5 rounded",
                          dayTotal > 30 ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]" : "bg-primary/10 text-primary"
                        )}>
                          {dayTotal}h
                        </span>
                      </td>
                    );
                  })}
                  <td className="px-4 py-2.5 text-right">
                    <span className="inline-block text-sm font-bold tabular-nums text-primary">
                      {weekHours}h
                    </span>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Time entries DataTable with approval workflow */}
      <DataTable
        title="Time Entries — All Projects"
        data={timeEntries}
        columns={columns}
        searchKeys={["task", "id", "member", "project", "notes"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening ${r.id}`)}
        enableSelection
        enableExport
        enableDensity
        enableColumnVisibility
        pageSize={10}
        initialSort={{ key: "date", direction: "desc" }}
        bulkActions={[
          {
            label: "Approve selected",
            icon: CheckCheck,
            onClick: (sel) => toast.success(`Approved ${sel.length} entr${sel.length > 1 ? "ies" : "y"}`),
          },
          {
            label: "Reject selected",
            icon: XCircle,
            onClick: (sel) => toast.error(`Rejected ${sel.length} entr${sel.length > 1 ? "ies" : "y"}`),
          },
          {
            label: "Export selected",
            icon: Download,
            onClick: (sel) => toast.success(`Exported ${sel.length} entr${sel.length > 1 ? "ies" : "y"} as CSV`),
          },
          {
            label: "Delete",
            icon: Trash2,
            onClick: (sel) => toast.error(`Deleted ${sel.length} entr${sel.length > 1 ? "ies" : "y"}`),
          },
        ]}
        toolbarActions={
          <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={() => toast.success(`Bulk-approving ${pendingCount} pending entries`)}>
            <CheckCheck className="h-3.5 w-3.5" /> Approve All Pending
          </Button>
        }
      />

      {/* Bottom insight row */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Billable Utilization</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">82.7%</p>
                <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1.5">
                  <ArrowUpRight className="h-3 w-3" /> +3.1% vs last month
                </p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--success)]/12 text-[color:var(--success)]">
                <DollarSign className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Avg. Daily Hours</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">7.4h</p>
                <p className="text-xs text-muted-foreground mt-1.5">across 5 working days</p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/12 text-primary">
                <Clock className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Top Biller (mo)</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">$24.8K</p>
                <p className="text-xs text-muted-foreground mt-1.5">Elena Petrov · 168h billable</p>
              </div>
              <Avatar className="h-9 w-9">
                <AvatarImage src={team[2].avatar} alt={team[2].name} />
                <AvatarFallback className="text-[10px]">{team[2].name.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
              </Avatar>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
