"use client";

import * as React from "react";
import {
  Loader,
  Play,
  Pause,
  RefreshCw,
  Circle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

export default function LoadingStatesPage() {
  const [running, setRunning] = React.useState<Record<string, boolean>>({
    card: true,
    table: true,
    chart: true,
    spinner: true,
    progress: true,
    pulse: true,
    shimmer: true,
    dots: true,
  });

  const [progress, setProgress] = React.useState(67);

  React.useEffect(() => {
    if (!running.progress) return;
    const t = setInterval(() => {
      setProgress((p) => (p >= 100 ? 12 : p + 1));
    }, 80);
    return () => clearInterval(t);
  }, [running.progress]);

  const toggle = (id: string) => setRunning((r) => ({ ...r, [id]: !r[id] }));

  return (
    <>
      <PageHeader
        title="Loading States"
        description="A library of loading patterns to indicate background work. Each one is configurable and accessible."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Loading States" }]}
        icon={Loader}
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={() => setRunning(Object.fromEntries(Object.keys(running).map((k) => [k, true])))}
            >
              <Play className="h-3.5 w-3.5" /> Play all
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={() => setRunning(Object.fromEntries(Object.keys(running).map((k) => [k, false])))}
            >
              <Pause className="h-3.5 w-3.5" /> Pause all
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {/* SKELETON CARD */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">1</span>
                Skeleton card
              </CardTitle>
              <CardDescription className="text-xs">KPI card placeholder.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("card")}>
              {running.card ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border p-4">
              {running.card ? (
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1.5">
                      <div className="h-3 w-24 rounded bg-muted animate-pulse" />
                      <div className="h-7 w-20 rounded bg-muted animate-pulse" />
                    </div>
                    <div className="h-9 w-9 rounded-lg bg-muted animate-pulse" />
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-5 w-14 rounded bg-muted animate-pulse" />
                    <div className="h-3 w-16 rounded bg-muted animate-pulse" />
                  </div>
                  <div className="h-10 w-full rounded bg-muted/60 animate-pulse" />
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Total Revenue</p>
                      <p className="text-2xl font-semibold tabular-nums mt-1.5">$284,392</p>
                    </div>
                    <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                      <RefreshCw className="h-4 w-4" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-[color:var(--success)]/12 text-[color:var(--success)] ring-1 ring-inset ring-[color:var(--success)]/20">+12.4%</Badge>
                    <span className="text-xs text-muted-foreground">vs last month</span>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* SKELETON TABLE */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">2</span>
                Skeleton table
              </CardTitle>
              <CardDescription className="text-xs">List loading state.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("table")}>
              {running.table ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border overflow-hidden">
              <div className="px-3 py-2 border-b border-border bg-muted/40 flex items-center gap-3">
                {["Name", "Status", "Date"].map((h, i) => (
                  <div key={h} className={cn("h-2.5 rounded bg-muted animate-pulse", i === 0 ? "flex-1" : "w-16")} style={{ animationDelay: `${i * 80}ms` }} />
                ))}
              </div>
              <div className="divide-y divide-border">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="px-3 py-2.5 flex items-center gap-3">
                    <div className="h-6 w-6 rounded-full bg-muted animate-pulse shrink-0" />
                    <div className="flex-1 space-y-1.5">
                      <div className="h-2.5 w-3/4 rounded bg-muted animate-pulse" style={{ animationDelay: `${i * 100}ms` }} />
                      <div className="h-2 w-1/2 rounded bg-muted/70 animate-pulse" style={{ animationDelay: `${i * 100 + 50}ms` }} />
                    </div>
                    <div className="h-4 w-12 rounded bg-muted animate-pulse" style={{ animationDelay: `${i * 100 + 100}ms` }} />
                    <div className="h-2.5 w-14 rounded bg-muted/70 animate-pulse" style={{ animationDelay: `${i * 100 + 150}ms` }} />
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SKELETON CHART */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">3</span>
                Skeleton chart
              </CardTitle>
              <CardDescription className="text-xs">Visualization loading.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("chart")}>
              {running.chart ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border p-4">
              <div className="flex items-end justify-between gap-1.5 h-32">
                {[40, 65, 50, 80, 60, 95, 70, 85, 55, 75, 90, 45].map((h, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div
                      className="w-full rounded-t bg-muted animate-pulse"
                      style={{ height: `${h}%`, animationDelay: `${i * 60}ms` }}
                    />
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                <div className="h-2.5 w-20 rounded bg-muted animate-pulse" />
                <div className="h-2.5 w-12 rounded bg-muted/70 animate-pulse" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SPINNER VARIATIONS */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">4</span>
                Spinner variations
              </CardTitle>
              <CardDescription className="text-xs">Different sizes and colors.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("spinner")}>
              {running.spinner ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border p-6 flex items-center justify-around">
              {[
                { size: "h-4 w-4", color: "border-primary" },
                { size: "h-6 w-6", color: "border-violet-500" },
                { size: "h-8 w-8", color: "border-[color:var(--info)]" },
                { size: "h-10 w-10", color: "border-[color:var(--success)]" },
              ].map((s, i) => (
                <div key={i} className="flex flex-col items-center gap-2">
                  <div
                    className={cn(
                      "rounded-full border-2 border-muted",
                      s.color,
                      running.spinner && "animate-spin",
                      s.size
                    )}
                    style={{ borderTopColor: "transparent" }}
                  />
                  <span className="text-[10px] text-muted-foreground tabular-nums">{i + 1}x</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* PROGRESS BAR */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">5</span>
                Progress bar
              </CardTitle>
              <CardDescription className="text-xs">Determinate loading.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("progress")}>
              {running.progress ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border p-4 space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5 text-xs">
                  <span className="text-muted-foreground">Uploading report.pdf</span>
                  <span className="font-medium tabular-nums">{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5 text-xs">
                  <span className="text-muted-foreground">Processing 1,284 records</span>
                  <span className="font-medium tabular-nums">{Math.min(100, progress + 12)}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-violet-500/15 overflow-hidden">
                  <div className="h-full rounded-full bg-violet-500 transition-all" style={{ width: `${Math.min(100, progress + 12)}%` }} />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1.5 text-xs">
                  <span className="text-muted-foreground">Building dashboard</span>
                  <span className="font-medium tabular-nums">{Math.min(100, Math.max(0, progress - 20))}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-[color:var(--success)]/15 overflow-hidden">
                  <div className="h-full rounded-full bg-[color:var(--success)] transition-all" style={{ width: `${Math.min(100, Math.max(0, progress - 20))}%` }} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PULSE LOADING */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">6</span>
                Pulse loading
              </CardTitle>
              <CardDescription className="text-xs">Soft pulsing indicator.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("pulse")}>
              {running.pulse ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border p-6 flex flex-col items-center justify-center gap-4">
              <div className="relative">
                {running.pulse && (
                  <>
                    <span className="absolute inset-0 rounded-full bg-primary/40 animate-ping" style={{ animationDuration: "1.5s" }} />
                    <span className="absolute inset-0 rounded-full bg-primary/30 animate-ping" style={{ animationDuration: "1.5s", animationDelay: "0.5s" }} />
                  </>
                )}
                <div className="relative grid place-items-center h-12 w-12 rounded-full bg-primary/12 text-primary">
                  <Circle className="h-5 w-5 fill-current" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">Connecting to live feed...</p>
            </div>
          </CardContent>
        </Card>

        {/* SHIMMER EFFECT */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">7</span>
                Shimmer effect
              </CardTitle>
              <CardDescription className="text-xs">Gradient sweep placeholder.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("shimmer")}>
              {running.shimmer ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border p-4 space-y-3">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="relative h-9 rounded-md bg-muted/60 overflow-hidden">
                  {running.shimmer && (
                    <div
                      className="absolute inset-0"
                      style={{
                        background: "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.4) 50%, transparent 100%)",
                        backgroundSize: "200% 100%",
                        animation: `shimmer 1.6s ${i * 0.2}s infinite linear`,
                      }}
                    />
                  )}
                </div>
              ))}
              <style>{`@keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }`}</style>
            </div>
          </CardContent>
        </Card>

        {/* DOTS LOADING */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-sm flex items-center gap-2">
                <span className="grid place-items-center h-5 w-5 rounded bg-primary/10 text-primary text-[10px] font-bold">8</span>
                Dots loading
              </CardTitle>
              <CardDescription className="text-xs">Bouncing dots indicator.</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => toggle("dots")}>
              {running.dots ? <><Pause className="h-3 w-3" /> Pause</> : <><Play className="h-3 w-3" /> Play</>}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="rounded-xl border border-border p-8 flex flex-col items-center justify-center gap-6">
              <div className="flex items-center gap-1.5">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className={cn("h-2.5 w-2.5 rounded-full bg-primary", running.dots && "animate-bounce")}
                    style={{ animationDelay: `${i * 150}ms`, animationDuration: "0.9s" }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-2">
                {[0, 1, 2, 3, 4].map((i) => (
                  <span
                    key={i}
                    className={cn("h-1.5 w-1.5 rounded-full bg-violet-500", running.dots && "animate-bounce")}
                    style={{ animationDelay: `${i * 100}ms`, animationDuration: "1.1s" }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-1">
                {[0, 1, 2, 3, 4, 5, 6].map((i) => (
                  <span
                    key={i}
                    className={cn("h-3 w-1 rounded-full bg-[color:var(--info)]", running.dots && "animate-bounce")}
                    style={{ animationDelay: `${i * 80}ms`, animationDuration: "1s" }}
                  />
                ))}
              </div>
              <p className="text-xs text-muted-foreground">Loading conversation...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
