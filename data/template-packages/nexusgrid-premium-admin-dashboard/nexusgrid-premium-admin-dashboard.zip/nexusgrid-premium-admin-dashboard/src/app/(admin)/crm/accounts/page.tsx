"use client";

import * as React from "react";
import {
  Building2,
  Building,
  Heart,
  CreditCard,
  Truck,
  Cpu,
  GraduationCap,
  ShoppingCart,
  Factory,
  Stethoscope,
  TrendingUp,
  TrendingDown,
  MoreHorizontal,
  Eye,
  Mail,
  Globe,
  Trash2,
  Plus,
  Users,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DonutChart } from "@/components/charts";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type AccountStatus = "active" | "churned" | "at-risk" | "expanding";
type Industry =
  | "SaaS"
  | "Fintech"
  | "Healthcare"
  | "Ecommerce"
  | "Manufacturing"
  | "Infrastructure"
  | "Education"
  | "Logistics";

type Account = {
  id: string;
  company: string;
  logo: string;
  industry: Industry;
  website: string;
  employees: number;
  arr: number;
  healthScore: number;
  owner: string;
  ownerAvatar: string;
  status: AccountStatus;
};

const accounts: Account[] = [
  { id: "ACC-9012", company: "Globex Corp", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=64&h=64&fit=crop", industry: "SaaS", website: "globex.com", employees: 1840, arr: 840000, healthScore: 92, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", status: "expanding" },
  { id: "ACC-9011", company: "Initech", logo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=64&h=64&fit=crop", industry: "SaaS", website: "initech.io", employees: 620, arr: 312000, healthScore: 74, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-9010", company: "Hooli", logo: "https://images.unsplash.com/photo-1620288627229-c5b1d2f80c8f?w=64&h=64&fit=crop", industry: "SaaS", website: "hooli.com", employees: 4280, arr: 1240000, healthScore: 88, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", status: "expanding" },
  { id: "ACC-9009", company: "Umbrella Inc", logo: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=64&h=64&fit=crop", industry: "Healthcare", website: "umbrellahealth.com", employees: 1240, arr: 486000, healthScore: 56, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", status: "at-risk" },
  { id: "ACC-9008", company: "Acme Corp", logo: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=64&h=64&fit=crop", industry: "Manufacturing", website: "acme.com", employees: 8200, arr: 968000, healthScore: 81, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-9007", company: "Soylent", logo: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop", industry: "Ecommerce", website: "soylent.com", employees: 480, arr: 1520000, healthScore: 95, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", status: "expanding" },
  { id: "ACC-9006", company: "Stripe", logo: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=64&h=64&fit=crop", industry: "Fintech", website: "stripe.com", employees: 7200, arr: 2180000, healthScore: 90, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-9005", company: "Plaid", logo: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop", industry: "Fintech", website: "plaid.com", employees: 1840, arr: 612000, healthScore: 78, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-9004", company: "Rakuten", logo: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=64&h=64&fit=crop", industry: "Ecommerce", website: "rakuten.com", employees: 14800, arr: 1840000, healthScore: 67, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", status: "at-risk" },
  { id: "ACC-9003", company: "Ro Health", logo: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=64&h=64&fit=crop", industry: "Healthcare", website: "ro.co", employees: 920, arr: 524000, healthScore: 84, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-9002", company: "Cloudflare", logo: "https://images.unsplash.com/photo-1551803091-e20673f15770?w=64&h=64&fit=crop", industry: "Infrastructure", website: "cloudflare.com", employees: 3200, arr: 1680000, healthScore: 93, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", status: "expanding" },
  { id: "ACC-9001", company: "Freshworks", logo: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=64&h=64&fit=crop", industry: "SaaS", website: "freshworks.com", employees: 5200, arr: 842000, healthScore: 76, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-9000", company: "N26 Bank", logo: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=64&h=64&fit=crop", industry: "Fintech", website: "n26.com", employees: 1500, arr: 0, healthScore: 28, owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", status: "churned" },
  { id: "ACC-8999", company: "Doctolib", logo: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=64&h=64&fit=crop", industry: "Healthcare", website: "doctolib.fr", employees: 2200, arr: 742000, healthScore: 86, owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-8998", company: "Careem", logo: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=64&h=64&fit=crop", industry: "Logistics", website: "careem.com", employees: 6800, arr: 624000, healthScore: 72, owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", status: "active" },
  { id: "ACC-8997", company: "Klarna", logo: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=64&h=64&fit=crop", industry: "Fintech", website: "klarna.com", employees: 5200, arr: 1240000, healthScore: 89, owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", status: "expanding" },
  { id: "ACC-8996", company: "Mercari", logo: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=64&h=64&fit=crop", industry: "Ecommerce", website: "mercari.com", employees: 1800, arr: 384000, healthScore: 64, owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", status: "at-risk" },
];

const statusToneMap: Record<AccountStatus, StatusTone> = {
  active: "success",
  churned: "danger",
  "at-risk": "warning",
  expanding: "primary",
};

const industryData: { name: Industry; value: number; color: string }[] = [
  { name: "SaaS", value: 4, color: "var(--primary)" },
  { name: "Fintech", value: 4, color: "oklch(0.70 0.15 75)" },
  { name: "Healthcare", value: 3, color: "var(--success)" },
  { name: "Ecommerce", value: 3, color: "var(--info)" },
  { name: "Manufacturing", value: 1, color: "oklch(0.62 0.18 25)" },
  { name: "Infrastructure", value: 1, color: "oklch(0.58 0.13 250)" },
  { name: "Logistics", value: 1, color: "oklch(0.62 0.18 305)" },
];

const industryIcons: Record<Industry, React.ComponentType<{ className?: string }>> = {
  SaaS: Building,
  Fintech: CreditCard,
  Healthcare: Stethoscope,
  Ecommerce: ShoppingCart,
  Manufacturing: Factory,
  Infrastructure: Cpu,
  Education: GraduationCap,
  Logistics: Truck,
};

/* AccountKpi — split-view motif: left side value, right side industry mini-tiles */
function AccountKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
  trendPositive,
  trendLabel,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  trend: string;
  trendPositive: boolean;
  trendLabel: string;
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
        {/* Industry mini-tiles strip — distinct motif */}
        <div className="grid grid-cols-7 gap-1 mb-3">
          {industryData.map((d) => {
            const IndIcon = industryIcons[d.name];
            return (
              <div
                key={d.name}
                className="grid place-items-center h-6 rounded transition-all"
                style={{ background: `color-mix(in srgb, ${d.color} 14%, transparent)`, color: d.color }}
                title={`${d.name}: ${d.value}`}
              >
                <IndIcon className="h-3 w-3" />
              </div>
            );
          })}
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground truncate">{hint}</span>
          <span className={cn("inline-flex items-center gap-0.5 font-medium shrink-0", trendPositive ? "text-[color:var(--success)]" : "text-destructive")}>
            {trendPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {trend}
            <span className="text-muted-foreground font-normal ml-1 hidden sm:inline">{trendLabel}</span>
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AccountsPage() {
  const columns: Column<Account>[] = React.useMemo(
    () => [
      {
        key: "company",
        header: "Company",
        sortable: true,
        sortAccessor: (r) => r.company,
        cell: (r) => (
          <div className="flex items-center gap-2.5 min-w-0">
            <img src={r.logo} alt={`${r.company} logo`} className="h-9 w-9 rounded-lg object-cover bg-muted shrink-0" />
            <div className="min-w-0">
              <p className="font-medium text-sm text-foreground truncate">{r.company}</p>
              <p className="text-xs text-muted-foreground font-mono truncate">{r.id}</p>
            </div>
          </div>
        ),
      },
      {
        key: "industry",
        header: "Industry",
        sortable: true,
        sortAccessor: (r) => r.industry,
        filterable: true,
        filterAccessor: (r) => r.industry,
        filterOptions: [
          { label: "SaaS", value: "SaaS" },
          { label: "Fintech", value: "Fintech" },
          { label: "Healthcare", value: "Healthcare" },
          { label: "Ecommerce", value: "Ecommerce" },
          { label: "Manufacturing", value: "Manufacturing" },
          { label: "Infrastructure", value: "Infrastructure" },
          { label: "Logistics", value: "Logistics" },
        ],
        cell: (r) => {
          const Icon = industryIcons[r.industry];
          return (
            <span className="inline-flex items-center gap-1.5 text-xs">
              <Icon className="h-3.5 w-3.5 text-muted-foreground" />
              {r.industry}
            </span>
          );
        },
        width: "w-36",
      },
      {
        key: "website",
        header: "Website",
        sortable: true,
        sortAccessor: (r) => r.website,
        cell: (r) => (
          <span className="inline-flex items-center gap-1.5 text-xs text-primary font-mono">
            <Globe className="h-3 w-3" />
            {r.website}
          </span>
        ),
        width: "w-40",
      },
      {
        key: "employees",
        header: "Employees",
        sortable: true,
        sortAccessor: (r) => r.employees,
        align: "right",
        cell: (r) => <span className="tabular-nums text-sm">{r.employees.toLocaleString()}</span>,
        width: "w-28",
      },
      {
        key: "arr",
        header: "ARR",
        sortable: true,
        sortAccessor: (r) => r.arr,
        align: "right",
        cell: (r) => (
          <span className={cn("font-semibold tabular-nums", r.arr === 0 ? "text-muted-foreground" : "text-foreground")}>
            {r.arr === 0 ? "—" : `$${(r.arr / 1000).toFixed(0)}K`}
          </span>
        ),
        width: "w-28",
      },
      {
        key: "healthScore",
        header: "Health Score",
        sortable: true,
        sortAccessor: (r) => r.healthScore,
        cell: (r) => (
          <div className="flex items-center gap-2 w-32">
            <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full transition-all duration-500",
                  r.healthScore >= 80
                    ? "bg-[color:var(--success)]"
                    : r.healthScore >= 60
                    ? "bg-[color:var(--warning)]"
                    : "bg-destructive"
                )}
                style={{ width: `${r.healthScore}%` }}
              />
            </div>
            <span
              className={cn(
                "text-xs font-semibold tabular-nums",
                r.healthScore >= 80
                  ? "text-[color:var(--success)]"
                  : r.healthScore >= 60
                  ? "text-[color:var(--warning)]"
                  : "text-destructive"
              )}
            >
              {r.healthScore}
            </span>
          </div>
        ),
        width: "w-32",
      },
      {
        key: "owner",
        header: "Owner",
        sortable: true,
        sortAccessor: (r) => r.owner,
        cell: (r) => (
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={r.ownerAvatar} alt={r.owner} />
              <AvatarFallback className="text-[9px]">
                {r.owner.split(" ").map((p) => p[0]).join("")}
              </AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground truncate">{r.owner}</span>
          </div>
        ),
        width: "w-36",
      },
      {
        key: "status",
        header: "Status",
        sortable: true,
        sortAccessor: (r) => r.status,
        filterable: true,
        filterAccessor: (r) => r.status,
        filterOptions: [
          { label: "Active", value: "active" },
          { label: "Expanding", value: "expanding" },
          { label: "At-risk", value: "at-risk" },
          { label: "Churned", value: "churned" },
        ],
        align: "center",
        cell: (r) => (
          <StatusBadge tone={statusToneMap[r.status]} dot className="capitalize">
            {r.status === "at-risk" ? "At-risk" : r.status}
          </StatusBadge>
        ),
        width: "w-28",
      },
      {
        key: "actions",
        header: "Actions",
        align: "right",
        hideable: false,
        cell: (r) => (
          <div onClick={(e) => e.stopPropagation()}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-44">
                <DropdownMenuLabel className="text-xs">{r.company}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening account ${r.id}`)}>
                  <Eye className="h-3.5 w-3.5" /> View account
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Email sent to ${r.company}`)}>
                  <Mail className="h-3.5 w-3.5" /> Email team
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Opening ${r.website}`)}>
                  <Globe className="h-3.5 w-3.5" /> Visit website
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening contacts at ${r.company}`)}>
                  <Users className="h-3.5 w-3.5" /> View contacts
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${r.company} removed`)}>
                  <Trash2 className="h-3.5 w-3.5" /> Remove
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        ),
        width: "w-16",
      },
    ],
    []
  );

  const totalARR = accounts.reduce((s, a) => s + a.arr, 0);

  return (
    <>
      <PageHeader
        title="Accounts"
        description="Manage customer organizations, track account health, and surface expansion risks."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Accounts" }]}
        icon={Building2}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Accounts exported")}>
              <Building2 className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add account form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Account
            </Button>
          </>
        }
      />

      {/* KPI Row — industry mini-tiles motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <AccountKpi label="Total Accounts" value="412" hint="across 8 industries" icon={Building2} accent="primary" trend="+8.4%" trendPositive={true} trendLabel="this Q" />
        <AccountKpi label="Active" value="324" hint="78% of portfolio" icon={Heart} accent="success" trend="+12" trendPositive={true} trendLabel="net new" />
        <AccountKpi label="Churned" value="18" hint="4.4% churn rate" icon={TrendingDown} accent="warning" trend="−2" trendPositive={true} trendLabel="vs last Q" />
        <AccountKpi label="Total ARR" value={`$${(totalARR / 1000000).toFixed(1)}M`} hint="across all accounts" icon={CreditCard} accent="info" trend="+18.2%" trendPositive={true} trendLabel="YoY" />
      </div>

      {/* Industry breakdown + Health distribution */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Industry Breakdown</CardTitle>
            <CardDescription>Account distribution by industry.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart data={industryData} centerLabel="Accounts" centerValue={accounts.length.toString()} height={220} />
          </CardContent>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Heart className="h-4 w-4 text-[color:var(--success)]" />
                Account Health Distribution
              </CardTitle>
              <CardDescription>Health scores bucketed across all active accounts.</CardDescription>
            </div>
            <StatusBadge tone="success" dot>Healthy</StatusBadge>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              {[
                { label: "Excellent (90+)", count: 124, pct: 38, color: "var(--success)", tone: "success" as const },
                { label: "Good (70-89)", count: 168, pct: 52, color: "var(--primary)", tone: "primary" as const },
                { label: "At-risk (40-69)", count: 28, pct: 9, color: "var(--warning)", tone: "warning" as const },
                { label: "Critical (<40)", count: 6, pct: 1, color: "var(--destructive)", tone: "danger" as const },
              ].map((b) => (
                <div key={b.label} className="rounded-lg border border-border bg-muted/30 p-3">
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="h-2 w-2 rounded-full shrink-0" style={{ background: b.color }} />
                    <span className="text-xs text-muted-foreground truncate">{b.label}</span>
                  </div>
                  <p className="text-2xl font-semibold tabular-nums">{b.count}</p>
                  <div className="mt-2 h-1.5 w-full rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${b.pct}%`, background: b.color }} />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1.5 tabular-nums">{b.pct}% of portfolio</p>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-border grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">Avg. Health Score</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5">78 / 100</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">At-Risk ARR Exposure</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5 text-[color:var(--warning)]">$1.24M</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Expansion Candidates</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5 text-primary">42 accounts</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Accounts DataTable */}
      <DataTable
        title="All Accounts"
        data={accounts}
        columns={columns}
        searchKeys={["company", "industry", "id", "website"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening account ${r.id}`)}
        enableSelection
        enableExport
        enableDensity
        enableColumnVisibility
        pageSize={10}
        initialSort={{ key: "arr", direction: "desc" }}
        bulkActions={[
          {
            label: "Assign owner",
            icon: Users,
            onClick: (sel) => toast.message(`Assigning ${sel.length} account${sel.length > 1 ? "s" : ""}…`),
          },
          {
            label: "Export selected",
            icon: Building2,
            onClick: (sel) => toast.success(`Exported ${sel.length} account${sel.length > 1 ? "s" : ""}`),
          },
          {
            label: "Mark at-risk",
            icon: Heart,
            onClick: (sel) => toast.success(`Marked ${sel.length} account${sel.length > 1 ? "s" : ""} at-risk`),
          },
          {
            label: "Delete",
            icon: Trash2,
            onClick: (sel) => toast.error(`Deleted ${sel.length} account${sel.length > 1 ? "s" : ""}`),
          },
        ]}
      />
    </>
  );
}
