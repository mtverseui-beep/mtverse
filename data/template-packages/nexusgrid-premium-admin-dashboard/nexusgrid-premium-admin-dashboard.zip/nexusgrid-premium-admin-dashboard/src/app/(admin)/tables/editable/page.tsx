"use client";

import * as React from "react";
import {
  PencilLine,
  Check,
  X,
  Plus,
  Trash2,
  Undo2,
  Save,
  RotateCcw,
  DollarSign,
  Package,
  AlertCircle,
  History,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type ProductStatus = "active" | "draft" | "discontinued";

type Product = {
  id: string;
  name: string;
  sku: string;
  category: "Audio" | "Peripherals" | "Cameras" | "Lighting" | "Furniture";
  price: number;
  cost: number;
  stock: number;
  status: ProductStatus;
};

const initialProducts: Product[] = [
  { id: "PRD-001", name: "Aurora Mechanical Keyboard", sku: "NX-1001", category: "Peripherals", price: 189.0, cost: 84.0, stock: 142, status: "active" },
  { id: "PRD-002", name: "Lumen 4K Webcam", sku: "NX-1002", category: "Cameras", price: 129.5, cost: 58.0, stock: 88, status: "active" },
  { id: "PRD-003", name: "Pulse Wireless Mouse", sku: "NX-1003", category: "Peripherals", price: 64.99, cost: 22.0, stock: 312, status: "active" },
  { id: "PRD-004", name: "Cadence Studio Headphones", sku: "NX-1004", category: "Audio", price: 249.0, cost: 112.0, stock: 56, status: "active" },
  { id: "PRD-005", name: "Beacon Smart Lamp", sku: "NX-1005", category: "Lighting", price: 89.0, cost: 38.0, stock: 207, status: "active" },
  { id: "PRD-006", name: "Halo USB-C Hub", sku: "NX-1006", category: "Peripherals", price: 79.99, cost: 28.0, stock: 174, status: "active" },
  { id: "PRD-007", name: "Echo Standing Desk", sku: "NX-1007", category: "Furniture", price: 549.0, cost: 312.0, stock: 24, status: "draft" },
  { id: "PRD-008", name: "Vega Wireless Earbuds", sku: "NX-1008", category: "Audio", price: 179.0, cost: 76.0, stock: 0, status: "discontinued" },
  { id: "PRD-009", name: "Lumen Stream Mic", sku: "NX-1009", category: "Audio", price: 149.0, cost: 64.0, stock: 98, status: "active" },
  { id: "PRD-010", name: "Pulse Fitness Band", sku: "NX-1010", category: "Peripherals", price: 99.0, cost: 42.0, stock: 0, status: "draft" },
];

type EditableField = "name" | "sku" | "category" | "price" | "cost" | "stock" | "status";

type HistoryEntry = {
  ts: string;
  action: string;
  detail: string;
  snapshot: Product[];
};

export default function EditableTablePage() {
  const [products, setProducts] = React.useState<Product[]>(initialProducts);
  const [editing, setEditing] = React.useState<{ id: string; field: EditableField } | null>(null);
  const [draft, setDraft] = React.useState<string>("");
  const [history, setHistory] = React.useState<HistoryEntry[]>([]);
  const [nextId, setNextId] = React.useState(11);

  const snapshot = (action: string, detail: string) => {
    setHistory((prev) => [
      {
        ts: new Date().toLocaleTimeString("en-US", { hour12: false }),
        action,
        detail,
        snapshot: products.map((p) => ({ ...p })),
      },
      ...prev,
    ].slice(0, 8));
  };

  const startEdit = (id: string, field: EditableField, currentValue: string | number) => {
    setEditing({ id, field });
    setDraft(String(currentValue));
  };

  const cancelEdit = () => {
    setEditing(null);
    setDraft("");
  };

  const commitEdit = () => {
    if (!editing) return;
    const product = products.find((p) => p.id === editing.id);
    if (!product) return;
    let newValue: string | number = draft;
    if (["price", "cost", "stock"].includes(editing.field)) {
      newValue = parseFloat(draft);
      if (isNaN(newValue) || newValue < 0) {
        toast.error("Please enter a valid non-negative number");
        return;
      }
      if (editing.field === "price" && newValue < product.cost) {
        toast.error(`Price $${newValue.toFixed(2)} is below cost $${product.cost.toFixed(2)}`);
        return;
      }
    }
    snapshot("edit", `${product.name}: ${editing.field} → ${newValue}`);
    setProducts((prev) =>
      prev.map((p) =>
        p.id === editing.id ? { ...p, [editing.field]: newValue } : p
      )
    );
    toast.success(`Updated ${editing.field} for ${product.name}`, {
      description: `New value: ${newValue}`,
    });
    cancelEdit();
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      commitEdit();
    } else if (e.key === "Escape") {
      e.preventDefault();
      cancelEdit();
    }
  };

  const addRow = () => {
    const newId = `PRD-${String(nextId).padStart(3, "0")}`;
    const newProduct: Product = {
      id: newId,
      name: "New Product",
      sku: `NX-${2000 + nextId}`,
      category: "Peripherals",
      price: 0,
      cost: 0,
      stock: 0,
      status: "draft",
    };
    snapshot("add", `${newId} · New Product`);
    setProducts((prev) => [...prev, newProduct]);
    setNextId((n) => n + 1);
    toast.success(`Added new row ${newId}`, {
      description: "Click any cell to start editing.",
    });
    setEditing({ id: newId, field: "name" });
    setDraft("New Product");
  };

  const deleteRow = (id: string) => {
    const product = products.find((p) => p.id === id);
    if (!product) return;
    snapshot("delete", `${product.id} · ${product.name}`);
    setProducts((prev) => prev.filter((p) => p.id !== id));
    toast.error(`Deleted ${product.name}`, {
      description: "Undo from the side panel or below action bar.",
      action: {
        label: "Undo",
        onClick: () => undoLast(),
      },
    });
  };

  const undoLast = () => {
    if (history.length === 0) {
      toast.message("Nothing to undo");
      return;
    }
    const last = history[0];
    setProducts(last.snapshot);
    setHistory((prev) => prev.slice(1));
    toast.success(`Undid: ${last.action} — ${last.detail}`);
  };

  const resetAll = () => {
    snapshot("reset", "Reverted to original 10 products");
    setProducts(initialProducts);
    setNextId(11);
    toast.message("Reset to original product list");
  };

  const saveAll = () => {
    snapshot("save", `Persisted ${products.length} products to server`);
    toast.success(`Saved ${products.length} products`, {
      description: "Changes synced to inventory service.",
    });
  };

  const totalValue = products.reduce((s, p) => s + p.price * p.stock, 0);
  const totalCost = products.reduce((s, p) => s + p.cost * p.stock, 0);
  const margin = totalValue - totalCost;
  const lowStock = products.filter((p) => p.stock > 0 && p.stock < 50).length;
  const outOfStock = products.filter((p) => p.stock === 0).length;

  const renderCell = (p: Product, field: EditableField) => {
    const isEditing = editing?.id === p.id && editing.field === field;
    const value = p[field] as string | number;

    if (isEditing) {
      if (field === "category" || field === "status") {
        return (
          <Select
            value={draft}
            onValueChange={(v) => {
              setDraft(v);
              // Auto-commit on select
              setTimeout(() => {
                setEditing({ id: p.id, field });
                setDraft(v);
                requestAnimationFrame(() => {
                  snapshot("edit", `${p.name}: ${field} → ${v}`);
                  setProducts((prev) =>
                    prev.map((pp) => (pp.id === p.id ? { ...pp, [field]: v } : pp))
                  );
                  toast.success(`Updated ${field} for ${p.name}`, { description: `New value: ${v}` });
                  cancelEdit();
                });
              }, 0);
            }}
            open
          >
            <SelectTrigger className="h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {field === "category" ? (
                (["Audio", "Peripherals", "Cameras", "Lighting", "Furniture"] as const).map((c) => (
                  <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>
                ))
              ) : (
                (["active", "draft", "discontinued"] as const).map((s) => (
                  <SelectItem key={s} value={s} className="text-xs capitalize">{s}</SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        );
      }
      return (
        <div className="flex items-center gap-1">
          <Input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={handleKey}
            onBlur={commitEdit}
            type={["price", "cost", "stock"].includes(field) ? "number" : "text"}
            step={["price", "cost"].includes(field) ? "0.01" : "1"}
            min={0}
            className="h-7 text-xs"
          />
          <Button size="icon" variant="ghost" className="h-6 w-6 shrink-0" onMouseDown={(e) => { e.preventDefault(); commitEdit(); }}>
            <Check className="h-3.5 w-3.5 text-[color:var(--success)]" />
          </Button>
          <Button size="icon" variant="ghost" className="h-6 w-6 shrink-0" onMouseDown={(e) => { e.preventDefault(); cancelEdit(); }}>
            <X className="h-3.5 w-3.5 text-muted-foreground" />
          </Button>
        </div>
      );
    }

    return (
      <button
        onClick={() => startEdit(p.id, field, value)}
        className="group inline-flex items-center gap-1 rounded px-1 py-0.5 -mx-1 hover:bg-primary/10 hover:ring-1 hover:ring-primary/20 transition-colors w-full text-left"
      >
        <span className={cn("flex-1 truncate", field === "name" && "font-medium")}>
          {field === "price" || field === "cost" ? `$${Number(value).toFixed(2)}` : String(value)}
        </span>
        <PencilLine className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 shrink-0" />
      </button>
    );
  };

  return (
    <>
      <PageHeader
        title="Editable Table"
        description="Inline-editable product price list — click any cell to edit text, number, or select values. Save with Enter or the check icon, cancel with Esc or X. Add, delete, undo, and bulk save with toast feedback."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Tables" }, { label: "Editable Table" }]}
        icon={PencilLine}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={undoLast} disabled={history.length === 0}>
              <Undo2 className="h-3.5 w-3.5" /> Undo
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={resetAll}>
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={addRow}>
              <Plus className="h-3.5 w-3.5" /> Add row
            </Button>
            <Button size="sm" className="gap-1.5" onClick={saveAll}>
              <Save className="h-3.5 w-3.5" /> Save all
            </Button>
          </>
        }
      />

      {/* KPI strip — unique visual element */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Inventory Value</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">${(totalValue / 1000).toFixed(1)}K</p>
                <p className="text-xs text-muted-foreground mt-1.5 inline-flex items-center gap-1">
                  <DollarSign className="h-3 w-3" /> at retail price
                </p>
              </div>
              <span className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                <Package className="h-4 w-4" />
              </span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Gross Margin</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5">${(margin / 1000).toFixed(1)}K</p>
            <p className="text-xs text-[color:var(--success)] mt-1.5">
              {totalValue > 0 ? ((margin / totalValue) * 100).toFixed(1) : "0.0"}% margin rate
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Low Stock</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 text-[color:var(--warning)]">{lowStock}</p>
            <p className="text-xs text-muted-foreground mt-1.5">products below 50 units</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Out of Stock</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 text-[color:var(--danger)]">{outOfStock}</p>
            <p className="text-xs text-muted-foreground mt-1.5">needs reorder</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main editable table — spans 2/3 */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <span className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
                  <PencilLine className="h-4 w-4" />
                </span>
                Product Price List
              </CardTitle>
              <CardDescription className="text-xs">
                Click any cell to edit. Press <kbd className="text-[10px] bg-muted px-1 py-0.5 rounded border border-border">Enter</kbd> to save or <kbd className="text-[10px] bg-muted px-1 py-0.5 rounded border border-border">Esc</kbd> to cancel. Hover a cell to reveal the pencil icon.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border border-border overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/40 border-b border-border">
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-20">ID</th>
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2">Name</th>
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">SKU</th>
                        <th className="text-left text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-32">Category</th>
                        <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Price</th>
                        <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Cost</th>
                        <th className="text-right text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-20">Stock</th>
                        <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-24">Status</th>
                        <th className="text-center text-xs uppercase tracking-wide font-semibold text-muted-foreground px-3 py-2 w-12"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((p) => (
                        <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/30">
                          <td className="font-mono text-[11px] text-muted-foreground px-3 py-2">{p.id}</td>
                          <td className="px-3 py-2">{renderCell(p, "name")}</td>
                          <td className="px-3 py-2 font-mono text-xs">{renderCell(p, "sku")}</td>
                          <td className="px-3 py-2">{renderCell(p, "category")}</td>
                          <td className="px-3 py-2 text-right">{renderCell(p, "price")}</td>
                          <td className="px-3 py-2 text-right text-muted-foreground">{renderCell(p, "cost")}</td>
                          <td className="px-3 py-2 text-right">
                            <span className={cn(p.stock === 0 ? "text-[color:var(--danger)] font-medium" : p.stock < 50 ? "text-[color:var(--warning)] font-medium" : "tabular-nums")}>
                              {renderCell(p, "stock")}
                            </span>
                          </td>
                          <td className="px-3 py-2">
                            <div className="grid place-items-center">
                              {renderCell(p, "status")}
                            </div>
                          </td>
                          <td className="px-3 py-2 text-center">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-muted-foreground hover:text-destructive"
                              onClick={() => deleteRow(p.id)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="flex items-center justify-between mt-3">
                <p className="text-xs text-muted-foreground inline-flex items-center gap-1.5">
                  <AlertCircle className="h-3.5 w-3.5" />
                  Changes are local until you click <span className="font-medium text-foreground">Save all</span>.
                </p>
                <p className="text-xs text-muted-foreground font-mono">{products.length} rows · {history.length} actions in history</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Edit history panel — 1/3 sidebar */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-base">
                <span className="flex items-center gap-2">
                  <span className="grid place-items-center h-7 w-7 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
                    <History className="h-4 w-4" />
                  </span>
                  Edit History
                </span>
                <Badge variant="outline" className="text-[11px] font-mono">{history.length}</Badge>
              </CardTitle>
              <CardDescription className="text-xs">
                Last 8 changes — click Undo to roll back the most recent action.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
                {history.length === 0 ? (
                  <div className="text-center py-12">
                    <History className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground">No edits yet. Click a cell to begin.</p>
                  </div>
                ) : (
                  history.map((h, i) => (
                    <div
                      key={i}
                      className={cn(
                        "rounded-lg border border-border p-2.5 text-xs",
                        i === 0 && "bg-primary/5 border-primary/20"
                      )}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className={cn(
                            "inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                            h.action === "edit" && "bg-primary/12 text-primary",
                            h.action === "add" && "bg-[color:var(--success)]/12 text-[color:var(--success)]",
                            h.action === "delete" && "bg-destructive/12 text-destructive",
                            h.action === "save" && "bg-[color:var(--info)]/12 text-[color:var(--info)]",
                            h.action === "reset" && "bg-muted text-muted-foreground"
                          )}
                        >
                          {h.action}
                        </span>
                        <span className="font-mono text-[10px] text-muted-foreground">{h.ts}</span>
                        {i === 0 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 text-[11px] ml-auto gap-1"
                            onClick={undoLast}
                          >
                            <Undo2 className="h-3 w-3" /> Undo
                          </Button>
                        )}
                      </div>
                      <p className="text-xs text-foreground leading-snug">{h.detail}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{h.snapshot.length} rows in snapshot</p>
                    </div>
                  ))
                )}
              </div>
              {history.length > 0 && (
                <Button variant="outline" size="sm" className="w-full mt-3 gap-1.5" onClick={undoLast}>
                  <Undo2 className="h-3.5 w-3.5" /> Undo last action
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Edit-mode legend — unique visual element */}
      <Card className="mt-6">
        <CardContent className="pt-5">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="rounded-lg border border-border p-3 bg-muted/20">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-1">Text cell</p>
              <p className="text-xs text-muted-foreground">Click → text input appears → Enter saves, Esc cancels.</p>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/20">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-1">Number cell</p>
              <p className="text-xs text-muted-foreground">Validates non-negative; price must exceed cost; rejects bad input with toast.</p>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/20">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-1">Select cell</p>
              <p className="text-xs text-muted-foreground">Category & status open a dropdown; selection commits immediately.</p>
            </div>
            <div className="rounded-lg border border-border p-3 bg-muted/20">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-1">Row actions</p>
              <p className="text-xs text-muted-foreground">Trash icon deletes (with undo toast). "Add row" inserts a draft entry.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
