"use client";

import * as React from "react";
import {
  Server,
  DollarSign,
  TrendingUp,
  Activity,
  Gauge,
  Filter,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Users,
  Zap,
  type LucideIcon,
} from "lucide-react";
import {
  Area,
  ComposedChart,
  Line,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { DonutChart } from "@/components/charts";
import { useTheme } from "@/components/providers/theme-provider";
import { saasMrr, saasCohorts } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline SaaS data ---------- */

// MRR composition for the customer expansion donut (inline)
const mrrBreakdown = [
  { name: "Expansion", value: 24800, color: "var(--primary)" },
  { name: "New", value: 18400, color: "var(--success)" },
  { name: "Reactivated", value: 6200, color: "var(--warning)" },
  { name: "Churned", value: 8400, color: "var(--destructive)" },
];

// Plan distribution (inline) — Free / Starter / Pro / Enterprise
const planDistribution = [
  { name: "Free", count: 4280, value: 4280, mrr: 0, color: "oklch(0.68 0.04 75)" },
  { name: "Starter", count: 2840, value: 2840, mrr: 28400, color: "var(--info)" },
  { name: "Pro", count: 1840, value: 1840, mrr: 55200, color: "var(--primary)" },
  { name: "Enterprise", count: 420, value: 420, mrr: 28800, color: "var(--success)" },
];

// Trial conversion funnel — 4 stages (inline)
const trialFunnel = [
  { stage: "Trials Started", value: 1840, color: "var(--primary)", icon: Users },
  { stage: "Activated", value: 1240, color: "var(--info)", icon: Zap },
  { stage: "Engaged", value: 820, color: "var(--warning)", icon: Activity },
  { stage: "Converted", value: 480, color: "var(--success)", icon: Sparkles },
];

/* ---------- Helpers ---------- */

// Cohort table keys
const cohortKeys = ["m0", "m1", "m2", "m3", "m4", "m5", "m6"] as const;
const cohortLabels = ["M0", "M1", "M2", "M3", "M4", "M5", "M6"];

// Retention cell color for the cohort heatmap table — static class lookup
function retentionClass(v: number | null): string {
  if (v === null) return "bg-muted/40 text-muted-foreground/40";
  if (v >= 90) return "bg-[color:var(--success)] text-white";
  if (v >= 80) return "bg-[color:var(--success)]/65 text-white";
  if (v >= 70) return "bg-[color:var(--warning)]/75 text-white";
  if (v >= 60) return "bg-[color:var(--warning)]/45 text-foreground";
  return "bg-[color:var(--destructive)]/60 text-white";
}

// Mini heatmap cell color for the KPI card 5x2 grid (inline style — dynamic values)
function heatColor(v: number): string {
  if (v >= 90) return "var(--success)";
  if (v >= 80) return "color-mix(in oklch, var(--success) 60%, var(--warning))";
  if (v >= 70) return "var(--warning)";
  if (v >= 60) return "color-mix(in oklch, var(--warning) 55%, var(--destructive))";
  return "var(--destructive)";
}

/* ---------- SaaS MetricCard — data-dense heatmap + segmented bar ---------- */
// Distinct from all prior KPI cards: top-right 5x2 mini retention heatmap grid
// (previews the cohort table theme) + bottom segmented proportional bar showing
// the metric's composition. Top accent stripe gives each card a color identity.

type SaaSAccent = "emerald" | "violet" | "amber" | "rose";

function SaaSMetricCard({
  label,
  value,
  icon: Icon,
  trend,
  trendPositive,
  caption,
  accent,
  heatmap,
  segments,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  trend: { value: number; direction: "up" | "down" };
  trendPositive: boolean;
  caption: string;
  accent: SaaSAccent;
  heatmap: number[]; // 10 values for 5x2 grid
  segments: { label: string; value: number; color: string }[];
}) {
  const accentStripe: Record<SaaSAccent, string> = {
    emerald: "var(--success)",
    violet: "var(--primary)",
    amber: "var(--warning)",
    rose: "var(--destructive)",
  };
  const accentIcon: Record<SaaSAccent, string> = {
    emerald: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    violet: "bg-primary/15 text-primary",
    amber: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    rose: "bg-destructive/15 text-destructive",
  };
  const totalSeg = segments.reduce((s, x) => s + x.value, 0);

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      {/* Top accent stripe — color identity */}
      <div
        className="absolute top-0 left-0 right-0 h-0.5"
        style={{ background: accentStripe[accent] }}
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
            {label}
          </p>
          <p className="mt-1.5 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {/* 5x2 mini retention heatmap grid — previews cohort theme */}
          <div
            className="grid grid-cols-5 grid-rows-2 gap-[2px] p-1 rounded-md bg-muted/40"
            role="img"
            aria-label={`${label} retention heatmap`}
          >
            {heatmap.map((v, i) => (
              <span
                key={i}
                className="h-2 w-2 rounded-[2px]"
                style={{ background: heatColor(v) }}
                title={`${v}%`}
              />
            ))}
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg", accentIcon[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>
      </div>

      {/* Trend pill + caption */}
      <div className="mt-3 flex items-center gap-2 flex-wrap">
        <span
          className={cn(
            "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
            trendPositive
              ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
              : "bg-destructive/12 text-destructive"
          )}
        >
          {trend.direction === "up" ? (
            <ArrowUpRight className="h-3 w-3" />
          ) : (
            <ArrowDownRight className="h-3 w-3" />
          )}
          {Math.abs(trend.value)}%
        </span>
        <span className="text-xs text-muted-foreground truncate">{caption}</span>
      </div>

      {/* Segmented proportional bar — metric composition */}
      <div className="mt-3 -mb-1">
        <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-muted">
          {segments.map((s) => (
            <div
              key={s.label}
              className="h-full transition-all duration-500"
              style={{ width: `${(s.value / totalSeg) * 100}%`, background: s.color }}
            />
          ))}
        </div>
        <div className="mt-1.5 flex items-center justify-between gap-2 text-[10px] text-muted-foreground">
          {segments.map((s) => (
            <span key={s.label} className="inline-flex items-center gap-1 min-w-0">
              <span
                className="h-1.5 w-1.5 rounded-full shrink-0"
                style={{ background: s.color }}
              />
              <span className="truncate">{s.label}</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- Custom MRR + Churn combo chart (dual Y-axis) ---------- */
// The shared AreaTrendChart can't render an area + line on different scales,
// so we compose a custom ComposedChart: Area (MRR, left axis) + dashed Line
// (Churn, right axis). Theme-aware via useTheme.

function MrrChurnChart({ data, height }: { data: typeof saasMrr; height: number }) {
  const { theme } = useTheme();
  const grid = theme === "dark" ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)";
  const axis = theme === "dark" ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.5)";
  const tooltipBg = theme === "dark" ? "rgba(20,20,24,0.95)" : "rgba(255,255,255,0.95)";
  const tooltipBorder = theme === "dark" ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)";
  const tooltipText = theme === "dark" ? "#fff" : "#000";

  return (
    <ResponsiveContainer width="100%" height={height}>
      <ComposedChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <defs>
          <linearGradient id="saas-mrr-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--success)" stopOpacity={0.35} />
            <stop offset="100%" stopColor="var(--success)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke={grid} vertical={false} />
        <XAxis
          dataKey="month"
          stroke={axis}
          fontSize={11}
          tickLine={false}
          axisLine={false}
        />
        <YAxis
          yAxisId="left"
          stroke={axis}
          fontSize={11}
          tickLine={false}
          axisLine={false}
          tickFormatter={(v) => `$${(v / 1000).toFixed(0)}K`}
        />
        <YAxis
          yAxisId="right"
          orientation="right"
          stroke={axis}
          fontSize={11}
          tickLine={false}
          axisLine={false}
          tickFormatter={(v) => `$${(v / 1000).toFixed(1)}K`}
        />
        <Tooltip
          content={({ active, payload, label }: any) => {
            if (!active || !payload || !payload.length) return null;
            return (
              <div
                style={{
                  background: tooltipBg,
                  border: `1px solid ${tooltipBorder}`,
                  color: tooltipText,
                  borderRadius: 8,
                  padding: "8px 12px",
                  fontSize: 12,
                  boxShadow: "0 8px 24px -4px rgba(0,0,0,0.15)",
                  backdropFilter: "blur(8px)",
                }}
              >
                {label && <div className="font-medium mb-1">{label}</div>}
                <div className="space-y-0.5">
                  {payload.map((p: any, i: number) => (
                    <div key={i} className="flex items-center gap-2">
                      <span
                        className="inline-block h-2 w-2 rounded-full"
                        style={{ background: p.color || p.fill }}
                      />
                      <span className="opacity-70">{p.name}:</span>
                      <span className="font-medium tabular-nums">
                        ${Number(p.value).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          }}
        />
        <Area
          yAxisId="left"
          type="monotone"
          dataKey="mrr"
          name="MRR"
          stroke="var(--success)"
          strokeWidth={2.5}
          fill="url(#saas-mrr-grad)"
          dot={false}
          activeDot={{ r: 4, strokeWidth: 0 }}
        />
        <Line
          yAxisId="right"
          type="monotone"
          dataKey="churn"
          name="Churn"
          stroke="var(--destructive)"
          strokeWidth={2}
          strokeDasharray="5 4"
          dot={{ r: 2.5, strokeWidth: 0, fill: "var(--destructive)" }}
          activeDot={{ r: 4, strokeWidth: 0 }}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

/* ---------- Page ---------- */

export default function SaaSDashboardPage() {
  const totalCustomers = planDistribution.reduce((s, p) => s + p.count, 0);
  const totalPlanMrr = planDistribution.reduce((s, p) => s + p.mrr, 0);
  const netNewMrr =
    mrrBreakdown
      .filter((m) => m.name !== "Churned")
      .reduce((s, m) => s + m.value, 0) -
    mrrBreakdown.find((m) => m.name === "Churned")!.value;

  return (
    <>
      <PageHeader
        title="SaaS Metrics Dashboard"
        description="Monthly recurring revenue, cohort retention, plan distribution, and trial conversion — your subscription business at a glance."
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Dashboards" },
          { label: "SaaS Metrics" },
        ]}
        icon={Server}
        actions={
          <>
            <StatusBadge tone="success" dot className="gap-1.5">
              <Sparkles className="h-3 w-3" />
              New
            </StatusBadge>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Last 12 months
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="gap-1.5 bg-[color:var(--success)] text-[color:var(--success-foreground)] hover:bg-[color:var(--success)]/90"
            >
              <Zap className="h-3.5 w-3.5" /> Upgrade cohort
            </Button>
          </>
        }
      />

      {/* KPI Row — SaaSMetricCard with mini heatmap + segmented bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <SaaSMetricCard
          label="MRR"
          value="$112,400"
          icon={DollarSign}
          trend={{ value: 5.2, direction: "up" }}
          trendPositive
          caption="vs. $106,840 last month"
          accent="emerald"
          heatmap={[82, 85, 88, 90, 92, 86, 89, 91, 93, 95]}
          segments={[
            { label: "New 41%", value: 41, color: "var(--success)" },
            { label: "Exp 55%", value: 55, color: "var(--primary)" },
            { label: "React 4%", value: 4, color: "var(--warning)" },
          ]}
        />
        <SaaSMetricCard
          label="ARR"
          value="$1.35M"
          icon={TrendingUp}
          trend={{ value: 18, direction: "up" }}
          trendPositive
          caption="annualized run-rate"
          accent="violet"
          heatmap={[80, 84, 87, 89, 91, 88, 90, 92, 93, 94]}
          segments={[
            { label: "Monthly 8%", value: 8, color: "var(--warning)" },
            { label: "Annual 92%", value: 92, color: "var(--primary)" },
          ]}
        />
        <SaaSMetricCard
          label="Net Churn"
          value="2.4%"
          icon={Activity}
          trend={{ value: 0.4, direction: "down" }}
          trendPositive
          caption="lower is better — improved"
          accent="rose"
          heatmap={[94, 92, 90, 88, 86, 91, 89, 87, 85, 83]}
          segments={[
            { label: "Voluntary 1.6%", value: 1.6, color: "var(--destructive)" },
            { label: "Invol 0.8%", value: 0.8, color: "var(--warning)" },
          ]}
        />
        <SaaSMetricCard
          label="LTV / CAC"
          value="3.8x"
          icon={Gauge}
          trend={{ value: 0.4, direction: "up" }}
          trendPositive
          caption="healthy — above 3x target"
          accent="amber"
          heatmap={[70, 74, 78, 82, 85, 78, 82, 86, 88, 90]}
          segments={[
            { label: "LTV 79%", value: 79, color: "var(--success)" },
            { label: "CAC 21%", value: 21, color: "var(--warning)" },
          ]}
        />
      </div>

      {/* MRR growth chart (2/3) + Customer expansion (1/3) */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-[color:var(--success)]" />
                MRR Growth
              </CardTitle>
              <CardDescription>
                Monthly recurring revenue (area) vs. churned MRR (dashed line) over the trailing 12 months.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs shrink-0">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)]" /> MRR
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-0.5 w-3 rounded-full bg-[color:var(--destructive)]" /> Churn
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <MrrChurnChart data={saasMrr} height={300} />
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-3 gap-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Current MRR</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">
                  ${saasMrr[saasMrr.length - 1].mrr.toLocaleString()}
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">12-mo Growth</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                  +
                  {(
                    ((saasMrr[saasMrr.length - 1].mrr - saasMrr[0].mrr) / saasMrr[0].mrr) *
                    100
                  ).toFixed(1)}
                  %
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Net New (mo)</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                  +${netNewMrr.toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-[color:var(--primary)]" />
              Customer Expansion
            </CardTitle>
            <CardDescription>MRR movement breakdown this month.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={mrrBreakdown}
              centerLabel="Net New"
              centerValue={`+$${netNewMrr.toLocaleString()}`}
              height={200}
            />
            <div className="mt-3 space-y-1.5">
              {mrrBreakdown.map((m) => {
                const total = mrrBreakdown.reduce((s, x) => s + x.value, 0);
                const pct = ((m.value / total) * 100).toFixed(1);
                const isChurn = m.name === "Churned";
                return (
                  <div key={m.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="h-2 w-2 rounded-full shrink-0"
                        style={{ background: m.color }}
                      />
                      <span className="text-muted-foreground truncate">{m.name}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={cn(
                          "font-medium tabular-nums",
                          isChurn && "text-[color:var(--destructive)]"
                        )}
                      >
                        {isChurn ? "−" : "+"}${m.value.toLocaleString()}
                      </span>
                      <span className="text-muted-foreground tabular-nums w-10 text-right">{pct}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cohort retention heatmap table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-[color:var(--primary)]" />
              Cohort Retention Analysis
            </CardTitle>
            <CardDescription>
              Monthly retention % by signup cohort. Color intensity reflects retention health
              (green = strong, red = weak). Empty cells indicate future months.
            </CardDescription>
          </div>
          {/* Heatmap legend */}
          <div className="hidden sm:flex items-center gap-1.5 text-[10px] text-muted-foreground shrink-0">
            <span>Low</span>
            <span className="h-3 w-4 rounded-sm bg-[color:var(--destructive)]/60" />
            <span className="h-3 w-4 rounded-sm bg-[color:var(--warning)]/45" />
            <span className="h-3 w-4 rounded-sm bg-[color:var(--warning)]/75" />
            <span className="h-3 w-4 rounded-sm bg-[color:var(--success)]/65" />
            <span className="h-3 w-4 rounded-sm bg-[color:var(--success)]" />
            <span>High</span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 sticky left-0 bg-muted/40">
                    Cohort
                  </th>
                  {cohortLabels.map((l) => (
                    <th
                      key={l}
                      className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-3 py-2.5"
                    >
                      {l}
                    </th>
                  ))}
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">
                    Avg
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {saasCohorts.map((c) => {
                  const values = cohortKeys.map((k) => c[k] as number | null);
                  const valid = values.filter((v): v is number => v !== null);
                  const avg =
                    valid.length > 0
                      ? Math.round(valid.reduce((s, v) => s + v, 0) / valid.length)
                      : null;
                  return (
                    <tr key={c.cohort} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-2.5 font-medium text-foreground whitespace-nowrap sticky left-0 bg-card">
                        {c.cohort}
                      </td>
                      {cohortKeys.map((k) => {
                        const v = c[k] as number | null;
                        return (
                          <td key={k} className="px-2 py-2 text-center">
                            <span
                              className={cn(
                                "inline-grid place-items-center h-9 w-14 rounded-md text-xs font-semibold tabular-nums transition-colors",
                                retentionClass(v)
                              )}
                            >
                              {v === null ? "—" : `${v}%`}
                            </span>
                          </td>
                        );
                      })}
                      <td className="px-4 py-2.5 text-right">
                        <span className="inline-block font-semibold tabular-nums text-foreground">
                          {avg !== null ? `${avg}%` : "—"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t border-border bg-muted/20 text-xs text-muted-foreground">
            <span className="font-medium text-foreground">Insight:</span> The Jun 2026 cohort shows
            the strongest M1 retention (96%) — your onboarding improvements are paying off. Focus
            on the Mar 2026 cohort, which dips to 79% by M4.
          </div>
        </CardContent>
      </Card>

      {/* Plan distribution (1/2) + Trial conversion funnel (1/2) */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Plan distribution */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Server className="h-4 w-4 text-[color:var(--info)]" />
              Plan Distribution
            </CardTitle>
            <CardDescription>
              {totalCustomers.toLocaleString()} active accounts across {planDistribution.length} tiers.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={planDistribution}
              centerLabel="Accounts"
              centerValue={totalCustomers.toLocaleString()}
              height={200}
            />
            <div className="mt-4 pt-3 border-t border-border space-y-2">
              {planDistribution.map((p) => {
                const pct = ((p.count / totalCustomers) * 100).toFixed(1);
                return (
                  <div
                    key={p.name}
                    className="flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="h-2.5 w-2.5 rounded-sm shrink-0"
                        style={{ background: p.color }}
                      />
                      <span className="font-medium text-foreground">{p.name}</span>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-muted-foreground tabular-nums">
                        {p.count.toLocaleString()}
                      </span>
                      <span className="font-semibold tabular-nums w-12 text-right">{pct}%</span>
                      <span className="text-muted-foreground tabular-nums w-16 text-right hidden sm:inline">
                        ${p.mrr.toLocaleString()}/mo
                      </span>
                    </div>
                  </div>
                );
              })}
              <div className="pt-2 mt-2 border-t border-border flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Total MRR from plans</span>
                <span className="font-semibold tabular-nums">
                  ${totalPlanMrr.toLocaleString()}/mo
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Trial conversion funnel */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Zap className="h-4 w-4 text-[color:var(--warning)]" />
              Trial Conversion Funnel
            </CardTitle>
            <CardDescription>
              4-stage journey from trial signup to paid conversion.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {trialFunnel.map((stage, i) => {
              const max = trialFunnel[0].value;
              const widthPct = (stage.value / max) * 100;
              const stepConv =
                i === 0 ? 100 : (stage.value / trialFunnel[i - 1].value) * 100;
              const totalConv = (stage.value / trialFunnel[0].value) * 100;
              const StageIcon = stage.icon;
              return (
                <div key={stage.stage}>
                  <div className="flex items-center justify-between gap-2 text-xs mb-1.5">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <StageIcon
                        className="h-3.5 w-3.5 shrink-0"
                        style={{ color: stage.color }}
                      />
                      <span className="font-medium text-foreground truncate">{stage.stage}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-semibold tabular-nums text-foreground">
                        {stage.value.toLocaleString()}
                      </span>
                      <span className="text-muted-foreground tabular-nums text-[10px]">
                        {totalConv.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  <div className="relative h-7 rounded-md bg-muted overflow-hidden">
                    <div
                      className="absolute inset-y-0 left-0 rounded-md transition-all duration-700 ease-out flex items-center justify-end pr-2"
                      style={{ width: `${widthPct}%`, background: stage.color, opacity: 0.85 }}
                    >
                      {i > 0 && (
                        <span className="text-[10px] font-medium text-white tabular-nums">
                          {stepConv.toFixed(0)}% step
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            <div className="pt-3 mt-3 border-t border-border grid grid-cols-2 gap-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Overall Conversion
                </p>
                <p className="text-lg font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                  {((trialFunnel[trialFunnel.length - 1].value / trialFunnel[0].value) * 100).toFixed(1)}%
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Trial → Activated
                </p>
                <p className="text-lg font-semibold text-[color:var(--primary)] tabular-nums mt-0.5">
                  {((trialFunnel[1].value / trialFunnel[0].value) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
