"use client";

import * as React from "react";
import {
  FolderOpen,
  Folder,
  File as FileIcon,
  FileText,
  FileImage,
  FileSpreadsheet,
  FileArchive,
  FileCode,
  Upload,
  Search,
  Grid as GridIcon,
  List as ListIcon,
  ChevronRight,
  Star,
  Clock,
  Users,
  Trash2,
  HardDrive,
  MoreVertical,
  Download,
  Share2,
  Pencil,
  MoveRight,
  Eye,
  Home,
  RotateCcw,
  Plus,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type FileKind = "folder" | "pdf" | "image" | "doc" | "spreadsheet" | "archive" | "code" | "video";

type FileItem = {
  id: string;
  name: string;
  kind: FileKind;
  size: string;
  sizeBytes: number;
  modified: string;
  owner: string;
  ownerAvatar: string;
  shared: number;
  starred: boolean;
};

const files: FileItem[] = [
  { id: "f1", name: "Q3 Roadmap", kind: "folder", size: "—", sizeBytes: 0, modified: "Jul 14, 2026", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", shared: 6, starred: true },
  { id: "f2", name: "Board Materials", kind: "folder", size: "—", sizeBytes: 0, modified: "Jul 12, 2026", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", shared: 4, starred: false },
  { id: "f3", name: "Customer Interviews", kind: "folder", size: "—", sizeBytes: 0, modified: "Jul 10, 2026", owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", shared: 8, starred: true },
  { id: "f4", name: "Brand Assets", kind: "folder", size: "—", sizeBytes: 0, modified: "Jul 04, 2026", owner: "Daniel Foster", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", shared: 12, starred: false },
  { id: "f5", name: "Q3-roadmap-v8.pdf", kind: "pdf", size: "4.2 MB", sizeBytes: 4404019, modified: "Jul 14, 2026", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", shared: 3, starred: true },
  { id: "f6", name: "ARR Projection.xlsx", kind: "spreadsheet", size: "1.1 MB", sizeBytes: 1153434, modified: "Jul 13, 2026", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", shared: 2, starred: false },
  { id: "f7", name: "Hero-banner-final.png", kind: "image", size: "820 KB", sizeBytes: 839680, modified: "Jul 11, 2026", owner: "Daniel Foster", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", shared: 5, starred: false },
  { id: "f8", name: "Onboarding-flow.fig", kind: "image", size: "12.4 MB", sizeBytes: 13002342, modified: "Jul 10, 2026", owner: "Daniel Foster", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", shared: 4, starred: true },
  { id: "f9", name: "Customer-interview-notes.docx", kind: "doc", size: "1.1 MB", sizeBytes: 1153434, modified: "Jul 09, 2026", owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", shared: 6, starred: false },
  { id: "f10", name: "postmortem-2026-07-08.pdf", kind: "pdf", size: "320 KB", sizeBytes: 327680, modified: "Jul 09, 2026", owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", shared: 9, starred: false },
  { id: "f11", name: "platform-monorepo.zip", kind: "archive", size: "48.2 MB", sizeBytes: 50541363, modified: "Jul 08, 2026", owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", shared: 2, starred: false },
  { id: "f12", name: "payment-service.ts", kind: "code", size: "18 KB", sizeBytes: 18432, modified: "Jul 08, 2026", owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", shared: 3, starred: false },
  { id: "f13", name: "Team-offsite-recap.mp4", kind: "video", size: "248 MB", sizeBytes: 260046848, modified: "Jul 05, 2026", owner: "Priya Sharma", ownerAvatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=40&h=40&fit=crop", shared: 14, starred: true },
  { id: "f14", name: "AWS-invoice-june-2026.pdf", kind: "pdf", size: "1.4 MB", sizeBytes: 1468006, modified: "Jul 04, 2026", owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", shared: 1, starred: false },
  { id: "f15", name: "Compensation-framework.docx", kind: "doc", size: "640 KB", sizeBytes: 655360, modified: "Jul 02, 2026", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", shared: 5, starred: false },
];

const breadcrumbs = ["Home", "Documents", "Projects"];

const quickAccess = [
  { key: "recent", label: "Recent", icon: Clock, count: 12 },
  { key: "starred", label: "Starred", icon: Star, count: 8 },
  { key: "shared", label: "Shared with me", icon: Users, count: 24 },
  { key: "trash", label: "Trash", icon: Trash2, count: 5 },
];

const storageByType = [
  { type: "Documents", color: "var(--primary)", size: "3.8 GB", pct: 45 },
  { type: "Images", color: "oklch(0.70 0.15 75)", size: "2.4 GB", pct: 28 },
  { type: "Video", color: "oklch(0.62 0.18 305)", size: "1.6 GB", pct: 19 },
  { type: "Other", color: "oklch(0.62 0.18 25)", size: "0.6 GB", pct: 8 },
];

export default function FileManagerPage() {
  const [view, setView] = React.useState<"grid" | "list">("grid");
  const [search, setSearch] = React.useState("");
  const [uploadOpen, setUploadOpen] = React.useState(false);
  const [activeQuick, setActiveQuick] = React.useState<string | null>("recent");
  const [filesState, setFilesState] = React.useState(files);

  const filteredFiles = filesState.filter((f) => !search || f.name.toLowerCase().includes(search.toLowerCase()));

  function toggleStar(id: string) {
    setFilesState((prev) => prev.map((f) => (f.id === id ? { ...f, starred: !f.starred } : f)));
  }

  return (
    <>
      <PageHeader
        title="File Manager"
        description="Browse, organize, and share files across your workspace."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "File Manager" }]}
        icon={FolderOpen}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("New folder created")}>
              <Plus className="h-3.5 w-3.5" /> New Folder
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => setUploadOpen(true)}>
              <Upload className="h-3.5 w-3.5" /> Upload
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 xl:grid-cols-[260px_1fr] gap-4">
        {/* SIDEBAR */}
        <div className="space-y-4">
          <Card>
            <CardContent className="p-3">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-1.5">Quick Access</p>
              <div className="space-y-0.5">
                {quickAccess.map((q) => {
                  const Icon = q.icon;
                  const active = activeQuick === q.key;
                  return (
                    <button
                      key={q.key}
                      onClick={() => { setActiveQuick(q.key); toast.message(`Showing ${q.label}`); }}
                      className={cn(
                        "w-full flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-sm transition-colors",
                        active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground"
                      )}
                    >
                      <span className="flex items-center gap-2">
                        <Icon className="h-3.5 w-3.5" />
                        {q.label}
                      </span>
                      <span className="text-[10px] tabular-nums text-muted-foreground">{q.count}</span>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Storage card */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                  <HardDrive className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Storage</p>
                  <p className="text-xs text-muted-foreground">8.4 GB of 15 GB</p>
                </div>
              </div>
              <Progress value={56} className="h-2 mb-3" />
              <div className="space-y-2">
                {storageByType.map((s) => (
                  <div key={s.type} className="flex items-center justify-between gap-2 text-xs">
                    <span className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full" style={{ background: s.color }} />
                      {s.type}
                    </span>
                    <span className="text-muted-foreground tabular-nums">{s.size}</span>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" className="w-full mt-3 text-xs gap-1.5" onClick={() => toast.success("Upgrade modal opened")}>
                <Plus className="h-3 w-3" /> Upgrade storage
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* MAIN */}
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            {/* Top bar */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-3 p-3 border-b">
              <nav className="flex items-center gap-1 text-xs text-muted-foreground flex-wrap">
                {breadcrumbs.map((b, i) => (
                  <React.Fragment key={b}>
                    {i > 0 && <ChevronRight className="h-3 w-3 opacity-50" />}
                    {i === 0 ? (
                      <button className="flex items-center gap-1 hover:text-foreground"><Home className="h-3 w-3" />{b}</button>
                    ) : i === breadcrumbs.length - 1 ? (
                      <span className="text-foreground font-medium">{b}</span>
                    ) : (
                      <button className="hover:text-foreground">{b}</button>
                    )}
                  </React.Fragment>
                ))}
              </nav>
              <div className="flex-1" />
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search files..." className="h-9 pl-8 text-sm" />
              </div>
              <div className="flex items-center gap-0.5 border rounded-md p-0.5">
                <Button variant={view === "grid" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("grid")}><GridIcon className="h-3.5 w-3.5" /></Button>
                <Button variant={view === "list" ? "secondary" : "ghost"} size="icon" className="h-7 w-7" onClick={() => setView("list")}><ListIcon className="h-3.5 w-3.5" /></Button>
              </div>
            </div>

            {/* Content */}
            {view === "grid" ? (
              <ScrollArea className="h-[calc(100vh-340px)]">
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 p-4">
                  {filteredFiles.map((f) => (
                    <div
                      key={f.id}
                      className="group relative rounded-lg border border-border bg-card p-3 hover:border-primary/40 hover:shadow-premium-sm transition-all cursor-pointer"
                      onClick={() => toast.message(`Opening ${f.name}`)}
                    >
                      <button
                        onClick={(e) => { e.stopPropagation(); toggleStar(f.id); }}
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Star className={cn("h-3.5 w-3.5", f.starred ? "text-[color:var(--warning)] fill-current opacity-100" : "text-muted-foreground hover:text-foreground")} />
                      </button>
                      <FileIconLarge kind={f.kind} />
                      <p className="text-sm font-medium truncate mt-2">{f.name}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{f.size} · {f.modified}</p>
                      <div className="flex items-center gap-1 mt-1.5">
                        {f.shared > 0 && (
                          <span className="inline-flex items-center gap-0.5 text-[9px] text-muted-foreground">
                            <Users className="h-2.5 w-2.5" />{f.shared}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b bg-muted/40">
                    <tr>
                      <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Name</th>
                      <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Owner</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Modified</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Size</th>
                      <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Shared</th>
                      <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-12"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filteredFiles.map((f) => (
                      <tr key={f.id} className="hover:bg-muted/30 transition-colors cursor-pointer group" onClick={() => toast.message(`Opening ${f.name}`)}>
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-2.5">
                            <FileIconSmall kind={f.kind} />
                            <span className="text-sm font-medium truncate">{f.name}</span>
                            {f.starred && <Star className="h-3 w-3 text-[color:var(--warning)] fill-current shrink-0" />}
                          </div>
                        </td>
                        <td className="px-4 py-2.5 hidden md:table-cell">
                          <div className="flex items-center gap-2">
                            <Avatar className="h-5 w-5">
                              <AvatarImage src={f.ownerAvatar} alt={f.owner} />
                              <AvatarFallback className="text-[8px]">{f.owner.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-muted-foreground">{f.owner}</span>
                          </div>
                        </td>
                        <td className="px-4 py-2.5 text-right text-xs text-muted-foreground hidden lg:table-cell">{f.modified}</td>
                        <td className="px-4 py-2.5 text-right text-xs text-muted-foreground tabular-nums">{f.size}</td>
                        <td className="px-4 py-2.5 text-center hidden sm:table-cell">
                          {f.shared > 0 ? (
                            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                              <Users className="h-3 w-3" />{f.shared}
                            </span>
                          ) : (
                            <span className="text-xs text-muted-foreground/50">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2.5 text-right" onClick={(e) => e.stopPropagation()}>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100"><MoreVertical className="h-3.5 w-3.5" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => toast.message(`Opening ${f.name}`)}><Eye className="h-3.5 w-3.5 mr-2" />Open</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => toast.success("Rename dialog opened")}><Pencil className="h-3.5 w-3.5 mr-2" />Rename</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => toast.success("Share dialog opened")}><Share2 className="h-3.5 w-3.5 mr-2" />Share</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => toast.success(`Downloading ${f.name}`)}><Download className="h-3.5 w-3.5 mr-2" />Download</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => toast.success("Move dialog opened")}><MoveRight className="h-3.5 w-3.5 mr-2" />Move to</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => toast.success("Moved to trash")}><Trash2 className="h-3.5 w-3.5 mr-2" />Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Upload dialog */}
      <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle>Upload Files</DialogTitle>
            <DialogDescription>Drag and drop files or browse from your computer.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-xl border-2 border-dashed border-border p-8 text-center hover:border-primary/40 hover:bg-primary/[0.02] transition-colors cursor-pointer" onClick={() => toast.success("File picker opened")}>
              <div className="grid place-items-center h-12 w-12 rounded-full bg-primary/10 text-primary mx-auto mb-3">
                <Upload className="h-5 w-5" />
              </div>
              <p className="text-sm font-medium">Drop files here</p>
              <p className="text-xs text-muted-foreground mt-1">or click to browse · max 100MB per file</p>
            </div>
            <div className="space-y-1.5">
              <p className="text-xs font-medium text-muted-foreground">Recent uploads</p>
              {[
                { name: "Q3-roadmap-v8.pdf", size: "4.2 MB", pct: 100 },
                { name: "Hero-banner-final.png", size: "820 KB", pct: 100 },
                { name: "postmortem-2026-07-08.pdf", size: "320 KB", pct: 64 },
              ].map((u) => (
                <div key={u.name} className="flex items-center gap-3 rounded-md border border-border p-2">
                  <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium truncate">{u.name}</p>
                    <Progress value={u.pct} className="h-1 mt-1" />
                  </div>
                  <span className="text-[10px] text-muted-foreground tabular-nums shrink-0">{u.size}</span>
                  {u.pct === 100 && <Check className="h-3.5 w-3.5 text-[color:var(--success)] shrink-0" />}
                </div>
              ))}
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setUploadOpen(false)}>Cancel</Button>
            <Button size="sm" className="gap-1.5" onClick={() => { toast.success("Upload started"); setUploadOpen(false); }}>
              <Upload className="h-3.5 w-3.5" /> Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function Check({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} className={className}>
      <polyline points="20 6 9 17 4 12" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function fileIconConfig(kind: FileKind): { Icon: any; color: string; bg: string } {
  switch (kind) {
    case "folder": return { Icon: Folder, color: "var(--primary)", bg: "bg-primary/12" };
    case "pdf": return { Icon: FileText, color: "var(--destructive)", bg: "bg-destructive/12" };
    case "image": return { Icon: FileImage, color: "oklch(0.70 0.15 75)", bg: "bg-[color:var(--warning)]/15" };
    case "doc": return { Icon: FileText, color: "var(--info)", bg: "bg-[color:var(--info)]/12" };
    case "spreadsheet": return { Icon: FileSpreadsheet, color: "oklch(0.62 0.18 140)", bg: "bg-[color:var(--success)]/12" };
    case "archive": return { Icon: FileArchive, color: "oklch(0.62 0.18 305)", bg: "bg-violet-500/12" };
    case "code": return { Icon: FileCode, color: "oklch(0.62 0.18 25)", bg: "bg-[color:var(--warning)]/12" };
    case "video": return { Icon: FileIcon, color: "oklch(0.62 0.18 250)", bg: "bg-[color:var(--info)]/12" };
    default: return { Icon: FileIcon, color: "var(--muted-foreground)", bg: "bg-muted" };
  }
}

function FileIconLarge({ kind }: { kind: FileKind }) {
  const { Icon, color, bg } = fileIconConfig(kind);
  return (
    <div className={cn("grid place-items-center h-12 w-12 rounded-lg", bg)}>
      <Icon className="h-6 w-6" style={{ color }} />
    </div>
  );
}

function FileIconSmall({ kind }: { kind: FileKind }) {
  const { Icon, color, bg } = fileIconConfig(kind);
  return (
    <div className={cn("grid place-items-center h-7 w-7 rounded-md shrink-0", bg)}>
      <Icon className="h-3.5 w-3.5" style={{ color }} />
    </div>
  );
}
