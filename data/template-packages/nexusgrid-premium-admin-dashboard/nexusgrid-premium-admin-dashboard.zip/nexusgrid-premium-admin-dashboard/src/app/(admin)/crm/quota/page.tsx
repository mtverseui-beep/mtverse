"use client";

import * as React from "react";
import {
  Target,
  DollarSign,
  CheckCircle2,
  TrendingUp,
  Crown,
  Download,
  Eye,
  ArrowUpRight,
  Award,
  Zap,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LineTrendChart } from "@/components/charts";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type QuotaStatus = "over" | "on-track" | "behind";

type Rep = {
  name: string;
  avatar: string;
  quota: number;
  attained: number;
  deals: number;
};

const reps: Rep[] = [
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", quota: 320, attained: 412, deals: 28 },
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", quota: 320, attained: 358, deals: 24 },
  { name: "Olivia Hartwell", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=40&h=40&fit=crop", quota: 320, attained: 252, deals: 18 },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", quota: 320, attained: 268, deals: 22 },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", quota: 320, attained: 218, deals: 19 },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", quota: 320, attained: 194, deals: 16 },
];

const teamAttainmentTrend = [
  { month: "Jan", attainment: 84 },
  { month: "Feb", attainment: 88 },
  { month: "Mar", attainment: 91 },
  { month: "Apr", attainment: 86 },
  { month: "May", attainment: 94 },
  { month: "Jun", attainment: 97 },
  { month: "Jul", attainment: 102 },
];

function statusOf(attained: number, quota: number): QuotaStatus {
  const pct = (attained / quota) * 100;
  if (pct >= 100) return "over";
  if (pct >= 80) return "on-track";
  return "behind";
}

const statusToneMap: Record<QuotaStatus, StatusTone> = {
  over: "success",
  "on-track": "primary",
  behind: "warning",
};

const statusLabelMap: Record<QuotaStatus, string> = {
  over: "Over quota",
  "on-track": "On track",
  behind: "Behind",
};

/* QuotaKpi — bullseye/target motif: small concentric circles representing quota attainment */
function QuotaKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  bullseyeValue,
  trend,
  trendPositive,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  bullseyeValue: number;
  trend: string;
  trendPositive: boolean;
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  const ringColor: Record<string, string> = {
    primary: "var(--primary)",
    success: "var(--success)",
    info: "var(--info)",
    warning: "var(--warning)",
  };
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {/* Bullseye motif — concentric circles */}
            <div className="relative h-12 w-12 grid place-items-center">
              <div className="absolute h-12 w-12 rounded-full border-2" style={{ borderColor: `color-mix(in srgb, ${ringColor[accent]} 25%, transparent)` }} />
              <div className="absolute h-8 w-8 rounded-full border-2" style={{ borderColor: `color-mix(in srgb, ${ringColor[accent]} 50%, transparent)` }} />
              <div className="absolute h-4 w-4 rounded-full" style={{ background: ringColor[accent], opacity: bullseyeValue / 100 }} />
              <span className="relative text-[9px] font-bold tabular-nums">{bullseyeValue}</span>
            </div>
            <div className={cn("grid place-items-center h-9 w-9 rounded-lg", accentMap[accent])}>
              <Icon className="h-4.5 w-4.5" />
            </div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">{hint}</p>
        <div className="flex items-center gap-1 mt-2 text-xs">
          {trendPositive ? (
            <ArrowUpRight className="h-3 w-3 text-[color:var(--success)]" />
          ) : (
            <TrendingUp className="h-3 w-3 text-destructive rotate-180" />
          )}
          <span className={cn("font-medium", trendPositive ? "text-[color:var(--success)]" : "text-destructive")}>
            {trend}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function QuotaPage() {
  const totalQuota = reps.reduce((s, r) => s + r.quota, 0);
  const totalAttained = reps.reduce((s, r) => s + r.attained, 0);
  const totalRemaining = Math.max(0, totalQuota - totalAttained);
  const avgAttainment = Math.round((totalAttained / totalQuota) * 100);

  // Sort reps by attainment desc for leaderboard
  const leaderboard = [...reps].sort((a, b) => b.attained - a.attained);

  return (
    <>
      <PageHeader
        title="Quota Tracking"
        description="Monitor team and individual progress against sales targets in real time."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Quota Tracking" }]}
        icon={Target}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Quota report exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Set quota form opened")}>
              <Target className="h-3.5 w-3.5" /> Set Quota
            </Button>
          </>
        }
      />

      {/* KPI Row — bullseye motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <QuotaKpi label="Total Quota" value={`$${(totalQuota / 1000).toFixed(1)}M`} hint="Q3 2026 team target" icon={DollarSign} accent="primary" bullseyeValue={100} trend="unchanged vs Q2" trendPositive={true} />
        <QuotaKpi label="Attained" value={`$${(totalAttained / 1000).toFixed(1)}M`} hint={`${(totalAttained / totalQuota * 100).toFixed(0)}% of quota`} icon={CheckCircle2} accent="success" bullseyeValue={avgAttainment} trend="+18.4% vs Q2" trendPositive={true} />
        <QuotaKpi label="Remaining" value={`$${(totalRemaining / 1000).toFixed(1)}M`} hint="to hit team quota" icon={Target} accent="warning" bullseyeValue={Math.max(0, 100 - avgAttainment)} trend="−$420K vs last wk" trendPositive={true} />
        <QuotaKpi label="Avg. Attainment" value={`${avgAttainment}%`} hint="across 6 reps" icon={TrendingUp} accent="info" bullseyeValue={avgAttainment} trend="+4.2pp vs Q2" trendPositive={true} />
      </div>

      {/* Team quota progress bar + Quarterly trend */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />
                Team Quota Progress
              </CardTitle>
              <CardDescription>
                ${totalAttained.toLocaleString()}K attained of ${totalQuota.toLocaleString()}K quota
              </CardDescription>
            </div>
            <StatusBadge tone={avgAttainment >= 100 ? "success" : avgAttainment >= 80 ? "primary" : "warning"} dot>
              {avgAttainment >= 100 ? "Over quota" : avgAttainment >= 80 ? "On track" : "Behind"}
            </StatusBadge>
          </CardHeader>
          <CardContent>
            {/* Big progress bar with markers */}
            <div className="relative pt-4 pb-10">
              <div className="h-3 w-full rounded-full bg-muted overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full transition-all duration-700 ease-out bg-gradient-to-r",
                    avgAttainment >= 100
                      ? "from-[color:var(--success)] to-[color:var(--success)]"
                      : avgAttainment >= 80
                      ? "from-primary to-primary"
                      : "from-[color:var(--warning)] to-[color:var(--warning)]"
                  )}
                  style={{ width: `${Math.min(100, avgAttainment)}%` }}
                />
              </div>
              {/* Markers */}
              {[0, 25, 50, 75, 100].map((m) => (
                <div
                  key={m}
                  className="absolute top-0 -translate-x-1/2 flex flex-col items-center gap-1"
                  style={{ left: `${m}%` }}
                >
                  <div className="h-4 w-px bg-border" />
                  <span className="text-[10px] text-muted-foreground tabular-nums">{m}%</span>
                </div>
              ))}
              {/* Current position indicator */}
              <div
                className="absolute -bottom-1 -translate-x-1/2 flex flex-col items-center gap-1"
                style={{ left: `${Math.min(100, avgAttainment)}%` }}
              >
                <div className="px-2 py-0.5 rounded-md bg-primary text-primary-foreground text-[10px] font-bold tabular-nums shadow-sm">
                  {avgAttainment}%
                </div>
                <Zap className="h-3 w-3 text-primary" />
              </div>
            </div>
            {/* Rep contributions */}
            <div className="mt-4 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground mb-3">Per-rep contribution to team attainment</p>
              <div className="flex h-3 w-full rounded-full overflow-hidden bg-muted">
                {leaderboard.map((r, i) => {
                  const colors = ["var(--success)", "var(--primary)", "var(--info)", "oklch(0.70 0.15 75)", "oklch(0.62 0.18 25)", "var(--warning)"];
                  return (
                    <div
                      key={r.name}
                      className="h-full transition-all duration-700"
                      style={{
                        width: `${(r.attained / totalAttained) * 100}%`,
                        background: colors[i % colors.length],
                      }}
                      title={`${r.name}: $${r.attained}K`}
                    />
                  );
                })}
              </div>
              <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
                {leaderboard.map((r, i) => {
                  const colors = ["var(--success)", "var(--primary)", "var(--info)", "oklch(0.70 0.15 75)", "oklch(0.62 0.18 25)", "var(--warning)"];
                  return (
                    <div key={r.name} className="flex items-center gap-1.5 text-xs">
                      <span className="h-2 w-2 rounded-full" style={{ background: colors[i % colors.length] }} />
                      <span className="text-muted-foreground truncate">{r.name}</span>
                      <span className="font-medium tabular-nums">${r.attained}K</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-[color:var(--info)]" />
              Team Attainment Trend
            </CardTitle>
            <CardDescription>Monthly attainment % over the year.</CardDescription>
          </CardHeader>
          <CardContent>
            <LineTrendChart
              data={teamAttainmentTrend}
              xKey="month"
              series={[
                { key: "attainment", name: "Attainment %", color: "var(--primary)" },
              ]}
              height={240}
              showGrid
            />
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-[10px] text-muted-foreground uppercase">Peak</p>
                <p className="text-sm font-semibold tabular-nums text-[color:var(--success)]">102%</p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase">Average</p>
                <p className="text-sm font-semibold tabular-nums">91.7%</p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase">Lowest</p>
                <p className="text-sm font-semibold tabular-nums text-[color:var(--warning)]">84%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quota leaderboard table */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Crown className="h-4 w-4 text-[color:var(--warning)]" />
              Quota Leaderboard
            </CardTitle>
            <CardDescription>Ranked by attainment — Q3 2026 to date.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1" onClick={() => toast.success("Leaderboard exported")}>
            Export <Download className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground w-16">Rank</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Sales Rep</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Quota</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Attained</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Attainment %</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right hidden md:table-cell">Deals Closed</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-center">Status</TableHead>
                <TableHead className="text-xs uppercase tracking-wide text-muted-foreground text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leaderboard.map((r, i) => {
                const pct = Math.round((r.attained / r.quota) * 100);
                const status = statusOf(r.attained, r.quota);
                return (
                  <TableRow key={r.name} className="hover:bg-muted/30">
                    <TableCell>
                      <div
                        className={cn(
                          "grid place-items-center h-8 w-8 rounded-lg shrink-0 font-bold tabular-nums",
                          i === 0 && "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
                          i === 1 && "bg-muted text-muted-foreground",
                          i === 2 && "bg-[color:var(--info)]/15 text-[color:var(--info)]",
                          i > 2 && "bg-muted/50 text-muted-foreground"
                        )}
                      >
                        {i === 0 ? <Crown className="h-4 w-4" /> : i + 1}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2.5">
                        <Avatar className="h-8 w-8 shrink-0">
                          <AvatarImage src={r.avatar} alt={r.name} />
                          <AvatarFallback className="text-[10px]">
                            {r.name.split(" ").map((p) => p[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{r.name}</p>
                          <p className="text-xs text-muted-foreground">Account Executive</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">${r.quota}K</TableCell>
                    <TableCell className="text-right tabular-nums font-semibold">${r.attained}K</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 w-32">
                        <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
                          <div
                            className={cn(
                              "h-full rounded-full transition-all duration-500",
                              status === "over"
                                ? "bg-[color:var(--success)]"
                                : status === "on-track"
                                ? "bg-primary"
                                : "bg-[color:var(--warning)]"
                            )}
                            style={{ width: `${Math.min(100, pct)}%` }}
                          />
                        </div>
                        <span
                          className={cn(
                            "text-xs font-semibold tabular-nums w-9 text-right",
                            status === "over"
                              ? "text-[color:var(--success)]"
                              : status === "on-track"
                              ? "text-primary"
                              : "text-[color:var(--warning)]"
                          )}
                        >
                          {pct}%
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums hidden md:table-cell">
                      <span className="inline-flex items-center gap-1 text-sm">
                        <Award className="h-3.5 w-3.5 text-muted-foreground" />
                        {r.deals}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <StatusBadge tone={statusToneMap[status]} dot>
                        {statusLabelMap[status]}
                      </StatusBadge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.message(`Opening ${r.name} quota detail`)}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
