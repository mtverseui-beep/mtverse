"use client";

import * as React from "react";
import {
  MessageCircle,
  CheckCircle2,
  AlertTriangle,
  Info,
  CircleX,
  Loader2,
  Heart,
  Star,
  Bell,
  Mail,
  ShieldCheck,
  CloudUpload,
  Database,
  Sparkles,
  RotateCcw,
  Undo2,
  MailCheck,
  PartyPopper,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function ToastsPage() {
  const [persistent, setPersistent] = React.useState(false);

  const fakePromise = () =>
    new Promise<{ name: string }>((resolve) =>
      setTimeout(() => resolve({ name: "release-notes.pdf" }), 1800)
    );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Toasts"
        description="Sonner-powered transient feedback — five types, actions, descriptions, promises and custom layouts."
        icon={MessageCircle}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/toasts" },
          { label: "Toasts" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("All active toasts dismissed", { description: "Cleared 4 notifications." })}>
            <RotateCcw /> Dismiss all
          </Button>
        }
      />

      {/* Standard types */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Standard types</CardTitle>
          <CardDescription>
            The five sonner toast types cover 99% of transient feedback needs.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => toast.success("Settings saved successfully.")}>
            <CheckCircle2 className="text-[color:var(--success)]" /> Success
          </Button>
          <Button variant="outline" onClick={() => toast.error("Failed to connect to the database.")}>
            <CircleX className="text-destructive" /> Error
          </Button>
          <Button variant="outline" onClick={() => toast.warning("Your session will expire in 5 minutes.")}>
            <AlertTriangle className="text-[color:var(--warning)]" /> Warning
          </Button>
          <Button variant="outline" onClick={() => toast.info("A new version of the docs is available.")}>
            <Info className="text-[color:var(--info)]" /> Info
          </Button>
          <Button variant="outline" onClick={() => toast("Default toast message with no icon or tone.")}>
            <MessageCircle /> Default
          </Button>
        </CardContent>
      </Card>

      {/* With description + actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">With descriptions & actions</CardTitle>
          <CardDescription>
            Add a longer description and a single action button for undoable operations.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() =>
              toast.success("Customer archived", {
                description: "Acme Corp has been moved to the archived list. They will no longer appear in reports.",
                action: { label: "Undo", onClick: () => toast.success("Customer restored") },
              })
            }
          >
            <Undo2 /> Archive with undo
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast("Email sent", {
                description: "Your weekly digest was sent to 248 subscribers at 9:00 AM.",
                action: { label: "View report", onClick: () => toast.message("Report opened") },
              })
            }
          >
            <Mail /> Send with view action
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast.error("Build failed", {
                description: "Step 4 of 6 exited with code 1. See the full log for stack traces.",
                action: { label: "View log", onClick: () => toast.message("Build log opened") },
              })
            }
          >
            <CircleX className="text-destructive" /> Error with action
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast.warning("Storage 92% full", {
                description: "Add 50 GB more for $9/mo or archive old projects to free space.",
                action: { label: "Upgrade", onClick: () => toast.message("Upgrade dialog opened") },
              })
            }
          >
            <AlertTriangle className="text-[color:var(--warning)]" /> Warning with action
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast.success("PR #1284 merged", {
                description: "12 files changed, +482 / -164 lines. Deployment to staging has started.",
                duration: 8000,
              })
            }
          >
            <PartyPopper /> Long-duration (8s)
          </Button>
        </CardContent>
      </Card>

      {/* Persistent vs auto-dismiss */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Persistent vs auto-dismiss</CardTitle>
          <CardDescription>
            Toggle persistence on — the next toast will stay until dismissed manually.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-4">
          <label className="flex items-center gap-2 cursor-pointer">
            <Switch checked={persistent} onCheckedChange={setPersistent} />
            <span className="text-sm">Persistent (no auto-dismiss)</span>
          </label>
          <Button
            variant="outline"
            onClick={() =>
              toast("This toast respects the toggle", {
                description: persistent
                  ? "It will stay on screen until you click the X button."
                  : "It will auto-dismiss after the default 4-second duration.",
                duration: persistent ? Infinity : 4000,
              })
            }
          >
            <Bell /> Trigger toast
          </Button>
          <span className="text-xs text-muted-foreground">
            Current mode: <strong className="text-foreground">{persistent ? "Persistent" : "Auto-dismiss (4s)"}</strong>
          </span>
        </CardContent>
      </Card>

      {/* Promise toast */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Promise toast</CardTitle>
          <CardDescription>
            Show loading → success / error states for any async operation.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button
            onClick={() =>
              toast.promise(fakePromise(), {
                loading: "Uploading release-notes.pdf…",
                success: (data) => `${data.name} uploaded successfully.`,
                error: "Upload failed. Please try again.",
              })
            }
          >
            <CloudUpload /> Upload a file
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast.promise(
                new Promise((_, reject) => setTimeout(() => reject(new Error("network")), 1800)),
                {
                  loading: "Syncing with Stripe…",
                  success: "Stripe sync complete — 24 invoices updated.",
                  error: "Stripe sync failed — check your API key.",
                }
              )
            }
          >
            <Database /> Failing promise
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              const id = toast.loading("Deploying to production…");
              setTimeout(() => toast.success("Deployment complete — live in 28 regions.", { id }), 2400);
            }}
          >
            <Loader2 /> Manual loading → success
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              const id = toast.loading("Running migrations…");
              setTimeout(() => toast.error("Migration 4 of 8 failed — rolling back.", { id }), 2200);
            }}
          >
            <Loader2 /> Manual loading → error
          </Button>
        </CardContent>
      </Card>

      {/* Custom layouts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Custom layouts</CardTitle>
          <CardDescription>
            Pass JSX as the message to render richer toast content.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() =>
              toast.custom(() => (
                <div className="w-full rounded-lg border bg-card p-3 shadow-lg flex items-start gap-3">
                  <div className="grid h-9 w-9 place-items-center rounded-lg bg-[color:var(--success)]/15 text-[color:var(--success)]">
                    <ShieldCheck className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold">2FA enabled</p>
                    <p className="text-xs text-muted-foreground">Your account is now protected with an authenticator app.</p>
                  </div>
                  <button onClick={() => toast.dismiss()} className="text-muted-foreground hover:text-foreground">
                    <CircleX className="h-4 w-4" />
                  </button>
                </div>
              ), { duration: 6000 })
            }
          >
            <ShieldCheck /> Custom security toast
          </Button>

          <Button
            variant="outline"
            onClick={() =>
              toast.custom(() => (
                <div className="w-full rounded-lg border bg-card p-3 shadow-lg">
                  <div className="flex items-start gap-3 mb-2">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" alt="Devon Park" />
                      <AvatarFallback>DP</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Devon Park</p>
                      <p className="text-xs text-muted-foreground">mentioned you in PR #1284</p>
                    </div>
                    <span className="text-[10px] text-muted-foreground">2m ago</span>
                  </div>
                  <p className="text-xs text-muted-foreground bg-muted/40 rounded-md p-2">
                    "Could you take a look at the auth flow before I merge this?"
                  </p>
                  <div className="flex gap-2 mt-2">
                    <Button size="sm" className="flex-1 h-7 text-xs" onClick={() => toast.success("Opening PR")}>View PR</Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => toast.dismiss()}>Dismiss</Button>
                  </div>
                </div>
              ), { duration: 8000 })
            }
          >
            <Mail /> Mention notification
          </Button>

          <Button
            variant="outline"
            onClick={() =>
              toast.custom(() => (
                <div className="w-full rounded-lg border bg-gradient-to-r from-primary/15 via-violet-500/10 to-amber-500/10 p-3 shadow-lg flex items-center gap-3">
                  <Sparkles className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold">NexusGrid 4.2 is here!</p>
                    <p className="text-xs text-muted-foreground">14 new dashboards, billing v2, audit exports.</p>
                  </div>
                  <Button size="sm" className="h-7 text-xs" onClick={() => toast.success("Changelog opened")}>
                    Read more
                  </Button>
                </div>
              ), { duration: 7000 })
            }
          >
            <Sparkles /> Promo banner toast
          </Button>

          <Button
            variant="outline"
            onClick={() =>
              toast.custom(() => (
                <div className="w-full rounded-lg border bg-card p-3 shadow-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium flex items-center gap-2">
                      <Heart className="h-4 w-4 text-rose-500" /> New reaction
                    </p>
                    <span className="text-[10px] text-muted-foreground">just now</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <strong className="text-foreground">Priya Shah</strong> reacted with a <Star className="inline h-3 w-3 text-amber-500" /> to your comment on NG-2041
                  </p>
                </div>
              ), { duration: 5000 })
            }
          >
            <Heart /> Reaction toast
          </Button>
        </CardContent>
      </Card>

      {/* Position + rich icon */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Rich icon toasts</CardTitle>
          <CardDescription>
            All toast types accept a custom <code className="rounded bg-muted px-1 text-xs">icon</code> prop.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() =>
              toast.success("Email verified", {
                description: "amara@nexusgrid.io is now verified. You can enable SSO.",
                icon: <MailCheck className="h-4 w-4" />,
              })
            }
          >
            <MailCheck /> Email verified
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast.success("Deploy complete", {
                description: "v4.2.0 is live across 28 regions in 4 minutes 12 seconds.",
                icon: <PartyPopper className="h-4 w-4" />,
              })
            }
          >
            <PartyPopper /> Deploy complete
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast.success("Subscribed to release notes", {
                description: "You'll get an email every time we ship a new version.",
                icon: <Sparkles className="h-4 w-4" />,
              })
            }
          >
            <Sparkles /> Subscribed
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              toast.error("Webhook delivery failed", {
                description: "Endpoint https://api.acme.io/hooks returned 503. Retrying in 5 min.",
                icon: <CircleX className="h-4 w-4" />,
              })
            }
          >
            <CircleX /> Webhook failed
          </Button>
        </CardContent>
      </Card>

      {/* Live dispatch helper */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Quick reference</CardTitle>
          <CardDescription>
            Each trigger above fires a real sonner toast — try them all.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 sm:grid-cols-2">
            {[
              { fn: () => toast.success("Done!"), label: "toast.success()", tone: "success" },
              { fn: () => toast.error("Oops!"), label: "toast.error()", tone: "destructive" },
              { fn: () => toast.warning("Careful!"), label: "toast.warning()", tone: "warning" },
              { fn: () => toast.info("Heads up!"), label: "toast.info()", tone: "info" },
              { fn: () => toast.message("Plain"), label: "toast.message()", tone: "neutral" },
              { fn: () => toast.loading("Loading…"), label: "toast.loading()", tone: "primary" },
              { fn: () => toast.promise(fakePromise(), { loading: "Working…", success: "Done", error: "Failed" }), label: "toast.promise()", tone: "violet" },
              { fn: () => toast.dismiss(), label: "toast.dismiss()", tone: "neutral" },
            ].map((item) => (
              <button
                key={item.label}
                onClick={item.fn}
                className="flex items-center justify-between rounded-md border bg-card p-3 hover:bg-accent transition-colors text-left"
              >
                <code className="text-xs">{item.label}</code>
                <Badge
                  className={cn(
                    "border-transparent",
                    item.tone === "success" && "bg-[color:var(--success)]/15 text-[color:var(--success)]",
                    item.tone === "destructive" && "bg-destructive/15 text-destructive",
                    item.tone === "warning" && "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
                    item.tone === "info" && "bg-[color:var(--info)]/15 text-[color:var(--info)]",
                    item.tone === "primary" && "bg-primary/15 text-primary",
                    item.tone === "violet" && "bg-violet-500/15 text-violet-500",
                    item.tone === "neutral" && "bg-muted text-muted-foreground"
                  )}
                >
                  {item.tone}
                </Badge>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Toasts page · 5 types · descriptions · actions · promises · persistent toggle · custom layouts
      </p>
    </div>
  );
}
