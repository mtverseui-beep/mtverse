"use client";

import * as React from "react";
import {
  Building2,
  Home,
  Clock,
  DollarSign,
  KeyRound,
  Filter,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Star,
  MapPin,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AreaTrendChart, DonutChart } from "@/components/charts";
import { propertyListings } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline real estate data ---------- */

// Property status breakdown — inline.
const propertyStatus = [
  { name: "Active",  value: 184, color: "oklch(0.62 0.13 165)" },
  { name: "Pending", value: 64,  color: "oklch(0.70 0.15 75)"   },
  { name: "Sold",    value: 28,  color: "oklch(0.55 0.20 25)"   },
  { name: "Expired", value: 12,  color: "var(--destructive)"    },
];

// Listings performance — 6 months new listings vs sold.
const listingsPerformance = [
  { month: "Feb", new: 38, sold: 18 },
  { month: "Mar", new: 44, sold: 22 },
  { month: "Apr", new: 52, sold: 26 },
  { month: "May", new: 48, sold: 31 },
  { month: "Jun", new: 56, sold: 28 },
  { month: "Jul", new: 62, sold: 28 },
];

// Top agents — 5 entries.
const topAgents = [
  { name: "Sophia Martinez", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", listings: 24, closed: 8, volume: 8420000 },
  { name: "Ethan Wright",    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", listings: 19, closed: 6, volume: 5680000 },
  { name: "Olivia Bennett",  avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", listings: 22, closed: 7, volume: 7240000 },
  { name: "Liam Anderson",   avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", listings: 16, closed: 5, volume: 4820000 },
  { name: "Ava Thompson",    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", listings: 14, closed: 4, volume: 3960000 },
];

// Recent viewings — 5 entries.
const recentViewings = [
  { property: "1284 Pacific Ave, San Francisco", agent: "Sophia Martinez", buyer: "Hugo & Lena Hayes",  date: "Jul 02, 2026", rating: 5 },
  { property: "47 Birchwood Drive, Austin",      agent: "Ethan Wright",    buyer: "Marcus Whitfield",   date: "Jul 02, 2026", rating: 4 },
  { property: "92 Riverside Lane, Boston",       agent: "Olivia Bennett",  buyer: "Priya & Dev Raman",  date: "Jul 01, 2026", rating: 5 },
  { property: "1405 Sunset Blvd, Los Angeles",   agent: "Liam Anderson",   buyer: "Eleanor Hayes",      date: "Jul 01, 2026", rating: 3 },
  { property: "820 Hillside Terrace, Seattle",   agent: "Ava Thompson",    buyer: "David Okafor",       date: "Jun 30, 2026", rating: 4 },
];

// Status badge tone for property listings.
const listingStatusTone: Record<string, StatusTone> = {
  active:  "success",
  pending: "warning",
  sold:    "primary",
  expired: "danger",
};

// Property type badge tone.
const propertyTypeTone: Record<string, StatusTone> = {
  "Condo":          "info",
  "Single Family":  "success",
  "Townhouse":      "violet",
};

function formatPrice(p: number) {
  if (p >= 1000000) return `$${(p / 1000000).toFixed(2)}M`;
  if (p >= 1000)    return `$${(p / 1000).toFixed(0)}K`;
  return `$${p.toLocaleString()}`;
}

function formatVolume(v: number) {
  if (v >= 1000000) return `$${(v / 1000000).toFixed(1)}M`;
  if (v >= 1000)    return `$${(v / 1000).toFixed(0)}K`;
  return `$${v.toLocaleString()}`;
}

/* ---------- Real estate KPI card — editorial / magazine feel ---------- */
// Distinct from all prior KPI cards:
// - Top "Nº 01" page-number style header on right with thin horizontal rule
//   (magazine-spread aesthetic — distinct from HR's gradient strip, logistics'
//   route line, projects' sprint strip, healthcare's ECG line, education's book spines)
// - Big value with tabular-nums (no sparkline, no quota bar — let the typography breathe
//   like an editorial spread)
// - Bottom byline-style caption + trend pill (italic-style muted text)
// - Editorial palette (emerald / amber / stone / crimson) — premium real-estate feel

function EditorialCard({
  index,
  label,
  value,
  unit,
  icon: Icon,
  accent,
  trend,
  byline,
}: {
  index: number;
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  accent: "emerald" | "amber" | "stone" | "crimson";
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  byline: string;
}) {
  // Static accent maps so Tailwind v4 can detect them
  const accentTile: Record<string, string> = {
    emerald: "bg-emerald-700/12 text-emerald-700 dark:text-emerald-400",
    amber:   "bg-amber-700/12 text-amber-700 dark:text-amber-400",
    stone:   "bg-stone-700/12 text-stone-700 dark:text-stone-300",
    crimson: "bg-rose-700/12 text-rose-700 dark:text-rose-400",
  };
  const accentText: Record<string, string> = {
    emerald: "text-emerald-700 dark:text-emerald-400",
    amber:   "text-amber-700 dark:text-amber-400",
    stone:   "text-stone-700 dark:text-stone-300",
    crimson: "text-rose-700 dark:text-rose-400",
  };
  const accentDot: Record<string, string> = {
    emerald: "bg-emerald-700 dark:bg-emerald-400",
    amber:   "bg-amber-700 dark:bg-amber-400",
    stone:   "bg-stone-700 dark:bg-stone-300",
    crimson: "bg-rose-700 dark:bg-rose-400",
  };

  const isUp = trend.direction === "up";

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card transition-all hover:shadow-premium-sm">
      {/* Top editorial rule + page-number header */}
      <div className="flex items-center gap-2 px-5 pt-4">
        <span className={cn("h-1.5 w-1.5 rounded-full shrink-0", accentDot[accent])} />
        <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground truncate">
          {label}
        </span>
        <span className="flex-1 h-px bg-border mx-1" />
        <span className="text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground tabular-nums shrink-0">
          Nº {String(index).padStart(2, "0")}
        </span>
      </div>

      <div className="px-5 pb-5 pt-3">
        <div className="flex items-end justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-semibold tracking-tight tabular-nums leading-none">{value}</span>
              {unit && <span className="text-sm font-semibold text-muted-foreground tabular-nums">{unit}</span>}
            </div>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentTile[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>

        {/* Byline + trend pill */}
        <div className="mt-4 pt-3 border-t border-border/60 flex items-center justify-between gap-2">
          <span className={cn("text-xs italic truncate", accentText[accent])}>{byline}</span>
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums shrink-0",
              trend.positive
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {Math.abs(trend.value)}%
          </span>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function RealEstateDashboardPage() {
  const totalListings = propertyStatus.reduce((s, x) => s + x.value, 0);
  const totalNew = listingsPerformance.reduce((s, x) => s + x.new, 0);
  const totalSold = listingsPerformance.reduce((s, x) => s + x.sold, 0);

  return (
    <>
      <PageHeader
        title="Real Estate Dashboard"
        description="Active listings, market performance, and agent productivity across your portfolio."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Real Estate" }]}
        icon={Building2}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> All regions
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5 bg-emerald-700 text-white hover:bg-emerald-700/90">
              <Plus className="h-3.5 w-3.5" /> New listing
            </Button>
          </>
        }
      />

      {/* KPI Row — EditorialCard with Nº header + byline caption */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <EditorialCard
          index={1}
          label="Active Listings"
          value="184"
          icon={Home}
          accent="emerald"
          trend={{ value: 6.4, direction: "up", positive: true }}
          byline="across 4 regions"
        />
        <EditorialCard
          index={2}
          label="Avg Days on Market"
          value="42"
          unit="days"
          icon={Clock}
          accent="amber"
          trend={{ value: 3.2, direction: "down", positive: true }}
          byline="6 days faster vs. last mo."
        />
        <EditorialCard
          index={3}
          label="Total Property Value"
          value="$48.2"
          unit="M"
          icon={DollarSign}
          accent="stone"
          trend={{ value: 8.1, direction: "up", positive: true }}
          byline="portfolio value this month"
        />
        <EditorialCard
          index={4}
          label="Closed This Month"
          value="28"
          icon={KeyRound}
          accent="crimson"
          trend={{ value: 12.5, direction: "up", positive: true }}
          byline="$11.4M in closed volume"
        />
      </div>

      {/* Property status donut + Listings performance area chart */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Home className="h-4 w-4 text-emerald-700 dark:text-emerald-400" />
              Property Status
            </CardTitle>
            <CardDescription>{totalListings} listings across all statuses.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={propertyStatus}
              centerLabel="Total"
              centerValue={totalListings.toString()}
              height={210}
            />
            <div className="mt-3 space-y-1.5 pt-3 border-t border-border">
              {propertyStatus.map((s) => {
                const pct = ((s.value / totalListings) * 100).toFixed(1);
                return (
                  <div key={s.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="h-2 w-2 rounded-full shrink-0" style={{ background: s.color }} />
                      <span className="text-muted-foreground">{s.name}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-medium tabular-nums">{s.value}</span>
                      <span className="text-muted-foreground tabular-nums w-10 text-right">{pct}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-700 dark:text-emerald-400" />
                Listings Performance
              </CardTitle>
              <CardDescription>
                New listings vs. sold · last 6 months · {totalNew} new, {totalSold} sold.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-700 dark:bg-emerald-400" /> New
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-amber-700 dark:bg-amber-400" /> Sold
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={listingsPerformance}
              xKey="month"
              series={[
                { key: "new",  name: "New Listings", color: "oklch(0.62 0.13 165)" },
                { key: "sold", name: "Sold",         color: "oklch(0.70 0.15 75)"  },
              ]}
              height={300}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total New</p>
                <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">{totalNew}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total Sold</p>
                <p className="text-sm font-semibold text-amber-700 dark:text-amber-400 tabular-nums mt-0.5">{totalSold}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Sell-Through</p>
                <p className="text-sm font-semibold text-foreground tabular-nums mt-0.5">
                  {((totalSold / totalNew) * 100).toFixed(0)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active listings table — full width, uses propertyListings */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="h-4 w-4 text-emerald-700 dark:text-emerald-400" />
              Active Listings
            </CardTitle>
            <CardDescription>Featured properties currently on the market.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            All listings <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Property</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Type</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Price</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Beds</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Baths</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Sqft</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {propertyListings.map((p) => (
                  <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="grid place-items-center h-9 w-9 rounded-lg bg-emerald-700/10 text-emerald-700 dark:text-emerald-400 shrink-0">
                          <Home className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-mono text-[10px] text-muted-foreground">{p.id}</p>
                          <p className="text-sm font-medium text-foreground truncate flex items-center gap-1">
                            <MapPin className="h-3 w-3 text-muted-foreground shrink-0" />
                            <span className="truncate">{p.address}</span>
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <StatusBadge tone={propertyTypeTone[p.type] ?? "neutral"}>{p.type}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold text-foreground">
                      {formatPrice(p.price)}
                    </td>
                    <td className="px-4 py-3 text-center tabular-nums text-foreground hidden md:table-cell">{p.beds}</td>
                    <td className="px-4 py-3 text-center tabular-nums text-foreground hidden md:table-cell">{p.baths}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-muted-foreground hidden lg:table-cell">
                      {p.sqft.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={listingStatusTone[p.status]} dot className="capitalize">{p.status}</StatusBadge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Top agents + Recent viewings */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Top agents */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <KeyRound className="h-4 w-4 text-emerald-700 dark:text-emerald-400" />
                Top Agents
              </CardTitle>
              <CardDescription>By closed volume this quarter.</CardDescription>
            </div>
            <StatusBadge tone="success" dot>Q3 rank</StatusBadge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-10">#</th>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Agent</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Listings</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Closed</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Volume</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {topAgents.map((a, i) => (
                    <tr key={i} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <span className={cn(
                          "inline-grid place-items-center h-6 w-6 rounded-md text-xs font-bold tabular-nums",
                          i === 0 && "bg-emerald-700/15 text-emerald-700 dark:text-emerald-400 ring-1 ring-inset ring-emerald-700/25",
                          i === 1 && "bg-stone-600/15 text-stone-700 dark:text-stone-300 ring-1 ring-inset ring-stone-600/25",
                          i === 2 && "bg-amber-700/15 text-amber-700 dark:text-amber-400 ring-1 ring-inset ring-amber-700/25",
                          i > 2 && "bg-muted text-muted-foreground"
                        )}>
                          {i + 1}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Avatar className="h-8 w-8 shrink-0">
                            <AvatarImage src={a.avatar} alt={a.name} />
                            <AvatarFallback className="text-[10px]">
                              {a.name.split(" ").map((n) => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="font-medium text-foreground truncate">{a.name}</p>
                            <p className="text-xs text-muted-foreground sm:hidden tabular-nums">
                              {a.listings} listings · {formatVolume(a.volume)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums text-foreground hidden sm:table-cell">{a.listings}</td>
                      <td className="px-4 py-3 text-right">
                        <span className="inline-flex items-center gap-1 text-xs font-semibold tabular-nums text-emerald-700 dark:text-emerald-400">
                          <KeyRound className="h-3 w-3" />
                          {a.closed}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums font-medium text-foreground hidden md:table-cell">
                        {formatVolume(a.volume)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Recent viewings */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <MapPin className="h-4 w-4 text-emerald-700 dark:text-emerald-400" />
                Recent Viewings
              </CardTitle>
              <CardDescription>Latest property tours and buyer feedback.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-2.5 max-h-[440px] overflow-y-auto pr-1 custom-scroll">
            {recentViewings.map((v, i) => (
              <div
                key={i}
                className="group flex items-start gap-3 rounded-lg border border-border bg-muted/20 p-3 hover:bg-muted/40 hover:border-emerald-700/25 transition-colors"
              >
                <div className="grid place-items-center h-9 w-9 rounded-lg bg-emerald-700/10 text-emerald-700 dark:text-emerald-400 shrink-0 mt-0.5">
                  <Home className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground truncate flex items-center gap-1">
                    <MapPin className="h-3 w-3 text-muted-foreground shrink-0" />
                    <span className="truncate">{v.property}</span>
                  </p>
                  <p className="text-xs text-muted-foreground truncate mt-0.5">
                    {v.buyer} · with {v.agent}
                  </p>
                  <div className="mt-1.5 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-muted-foreground tabular-nums">{v.date}</span>
                    <div className="flex items-center gap-0.5 shrink-0">
                      {Array.from({ length: 5 }).map((_, s) => (
                        <Star
                          key={s}
                          className={cn(
                            "h-3 w-3",
                            s < v.rating
                              ? "fill-amber-500 text-amber-500"
                              : "fill-muted text-muted-foreground/40"
                          )}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
