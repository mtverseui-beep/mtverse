"use client";

import * as React from "react";
import {
  Building2,
  Users,
  FolderGit2,
  HardDrive,
  Globe,
  Upload,
  Clock,
  Type,
  Check,
  AlertTriangle,
  Trash2,
  Shield,
  Sparkles,
  Copy,
  ExternalLink,
  RefreshCw,
  Plus,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Settings = {
  name: string;
  url: string;
  description: string;
  timezone: string;
  language: string;
  dateFormat: string;
  defaultLanding: string;
  visibility: "public" | "team" | "private";
};

const DEFAULTS: Settings = {
  name: "NexusGrid",
  url: "nexusgrid.io",
  description: "The infrastructure control plane for modern engineering teams. Build, ship, and observe at scale.",
  timezone: "UTC-08:00 Pacific",
  language: "English (US)",
  dateFormat: "MMM d, yyyy",
  defaultLanding: "Dashboards · Ecommerce",
  visibility: "team",
};

const DOMAINS = [
  { id: "d1", domain: "nexusgrid.io", primary: true, verified: true, ssl: "Active · renews Oct 2026", dns: "A record · 75.2.81.14" },
  { id: "d2", domain: "app.nexusgrid.io", primary: false, verified: true, ssl: "Active · auto-managed", dns: "CNAME → nexusgrid.io" },
  { id: "d3", domain: "docs.nexusgrid.io", primary: false, verified: true, ssl: "Active · auto-managed", dns: "CNAME → nexusgrid.io" },
  { id: "d4", domain: "status.nexusgrid.io", primary: false, verified: false, ssl: "Pending verification", dns: "Add TXT record" },
];

export default function WorkspacePage() {
  const [settings, setSettings] = React.useState<Settings>(DEFAULTS);
  const [saved, setSaved] = React.useState<Settings>(DEFAULTS);
  const [saving, setSaving] = React.useState(false);
  const [deleteTyped, setDeleteTyped] = React.useState("");

  const set = <K extends keyof Settings>(k: K, v: Settings[K]) =>
    setSettings((s) => ({ ...s, [k]: v }));

  const isDirty = JSON.stringify(settings) !== JSON.stringify(saved);
  const dirtyCount = Object.keys(settings).filter(
    (k) => (settings as Record<string, unknown>)[k] !== (saved as Record<string, unknown>)[k]
  ).length;

  const save = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSaved(settings);
      toast.success("Workspace settings saved", { description: "Changes are now live across all members." });
    }, 850);
  };

  const reset = () => {
    setSettings(saved);
    toast.message("Reverted to last saved state");
  };

  return (
    <>
      <PageHeader
        title="Workspace"
        description="The shared identity and defaults for everyone in your organization."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Workspace" }]}
        icon={Building2}
        actions={
          <div className="flex items-center gap-2">
            {isDirty ? (
              <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/40 text-amber-600 bg-amber-500/5">
                <AlertTriangle className="h-3 w-3" /> {dirtyCount} unsaved
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[10px] gap-1 border-emerald-500/40 text-emerald-600 bg-emerald-500/5">
                <Check className="h-3 w-3" /> Saved
              </Badge>
            )}
            <Button variant="outline" size="sm" className="gap-1.5" disabled={!isDirty || saving} onClick={reset}>
              <RefreshCw className="h-3.5 w-3.5" /> Reset
            </Button>
            <Button size="sm" className="gap-1.5" disabled={!isDirty || saving} onClick={save}>
              {saving ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              {saving ? "Saving…" : "Save changes"}
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT — STATS + IDENTITY */}
        <div className="lg:col-span-1 space-y-6">
          {/* LOGO + STATS */}
          <Card className="p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="grid place-items-center h-14 w-14 rounded-xl bg-primary text-primary-foreground text-xl font-bold shrink-0">
                N
              </div>
              <div className="min-w-0">
                <p className="text-base font-semibold truncate">{settings.name}</p>
                <p className="text-xs text-muted-foreground truncate">{settings.url}</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full text-xs gap-1.5" onClick={() => toast.message("Upload a workspace logo")}>
              <Upload className="h-3.5 w-3.5" /> Upload logo
            </Button>
            <p className="text-[11px] text-muted-foreground mt-2">SVG, PNG, or JPG. Max 1MB. 64×64 recommended.</p>

            <Separator className="my-4" />

            {/* Stats */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { icon: Users, label: "Members", value: "14" },
                { icon: FolderGit2, label: "Projects", value: "28" },
                { icon: HardDrive, label: "Storage", value: "84GB" },
              ].map((s) => (
                <div key={s.label} className="text-center">
                  <div className="grid place-items-center h-8 w-8 rounded-md bg-muted text-muted-foreground mx-auto mb-1">
                    <s.icon className="h-3.5 w-3.5" />
                  </div>
                  <p className="text-sm font-semibold tabular-nums leading-tight">{s.value}</p>
                  <p className="text-[10px] text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* VISIBILITY */}
          <Card className="p-5">
            <CardTitle className="text-base mb-1">Workspace visibility</CardTitle>
            <CardDescription className="text-xs mb-3">Who can discover this workspace.</CardDescription>
            <div className="space-y-2">
              {[
                { v: "public", label: "Public", desc: "Anyone with the link can request access." },
                { v: "team", label: "Team only", desc: "Only invited members can see this workspace." },
                { v: "private", label: "Private", desc: "Hidden from search and the org directory." },
              ].map((opt) => (
                <button
                  key={opt.v}
                  type="button"
                  onClick={() => set("visibility", opt.v as Settings["visibility"])}
                  className={cn(
                    "w-full text-left p-2.5 rounded-lg border transition-colors flex items-start gap-2",
                    settings.visibility === opt.v ? "border-primary bg-primary/[0.04] ring-1 ring-primary/20" : "border-border hover:bg-muted/30"
                  )}
                >
                  <div className={cn("grid place-items-center h-4 w-4 rounded-full border mt-0.5 shrink-0", settings.visibility === opt.v ? "border-primary bg-primary" : "border-border")}>
                    {settings.visibility === opt.v && <div className="h-1.5 w-1.5 rounded-full bg-primary-foreground" />}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{opt.label}</p>
                    <p className="text-[11px] text-muted-foreground">{opt.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </Card>

          {/* PLAN CARD */}
          <Card className="p-5 bg-gradient-to-br from-primary/[0.06] to-transparent border-primary/20">
            <div className="flex items-center gap-2 text-primary mb-1">
              <Sparkles className="h-4 w-4" />
              <p className="text-xs font-semibold uppercase tracking-wide">Pro plan</p>
            </div>
            <p className="text-sm font-medium">Renews Aug 14, 2026</p>
            <p className="text-xs text-muted-foreground mt-1">14 of 20 seats used · 84 of 250 GB stored.</p>
            <Button variant="outline" size="sm" className="w-full text-xs mt-3 gap-1.5" onClick={() => toast.message("Opening subscription")}>
              Manage subscription <ExternalLink className="h-3 w-3" />
            </Button>
          </Card>
        </div>

        {/* RIGHT — SETTINGS + DOMAINS + DANGER */}
        <div className="lg:col-span-2 space-y-6">
          {/* GENERAL SETTINGS */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="h-4 w-4 text-primary" /> General
              </CardTitle>
              <CardDescription>Identity and localisation defaults applied across the workspace.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="grid gap-1.5">
                  <Label className="text-xs">Workspace name</Label>
                  <Input value={settings.name} onChange={(e) => set("name", e.target.value)} />
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-xs flex items-center gap-1.5"><Globe className="h-3.5 w-3.5 text-muted-foreground" /> URL</Label>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground text-sm">https://</span>
                    <Input value={settings.url} onChange={(e) => set("url", e.target.value)} />
                  </div>
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Description</Label>
                <Textarea rows={3} value={settings.description} onChange={(e) => set("description", e.target.value)} />
                <p className="text-[11px] text-muted-foreground">{settings.description.length} / 240 characters</p>
              </div>
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="grid gap-1.5">
                  <Label className="text-xs flex items-center gap-1.5"><Clock className="h-3.5 w-3.5 text-muted-foreground" /> Default timezone</Label>
                  <Select value={settings.timezone} onValueChange={(v) => set("timezone", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["UTC", "UTC-08:00 Pacific", "UTC-05:00 Eastern", "UTC+00:00 London", "UTC+01:00 Berlin", "UTC+09:00 Tokyo"].map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-xs flex items-center gap-1.5"><Globe className="h-3.5 w-3.5 text-muted-foreground" /> Default language</Label>
                  <Select value={settings.language} onValueChange={(v) => set("language", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["English (US)", "English (UK)", "Deutsch", "Français", "日本語", "中文"].map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-xs flex items-center gap-1.5"><Type className="h-3.5 w-3.5 text-muted-foreground" /> Date format</Label>
                  <Select value={settings.dateFormat} onValueChange={(v) => set("dateFormat", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MMM d, yyyy">Jul 14, 2026</SelectItem>
                      <SelectItem value="d MMM yyyy">14 Jul 2026</SelectItem>
                      <SelectItem value="yyyy-MM-dd">2026-07-14</SelectItem>
                      <SelectItem value="MM/dd/yyyy">07/14/2026</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Default landing page</Label>
                <Select value={settings.defaultLanding} onValueChange={(v) => set("defaultLanding", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Dashboards · Ecommerce">Dashboards · Ecommerce</SelectItem>
                    <SelectItem value="Dashboards · Analytics">Dashboards · Analytics</SelectItem>
                    <SelectItem value="Projects · Kanban">Projects · Kanban</SelectItem>
                    <SelectItem value="Apps · Calendar">Apps · Calendar</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-muted-foreground">Where members land immediately after sign-in.</p>
              </div>
            </CardContent>
          </Card>

          {/* CUSTOM DOMAINS */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  <Globe className="h-4 w-4 text-primary" /> Custom domains
                </CardTitle>
                <CardDescription>Serve your workspace from your own domain with auto-managed SSL.</CardDescription>
              </div>
              <Button size="sm" className="gap-1.5 text-xs" onClick={() => toast.message("Add a custom domain")}>
                <Plus className="h-3.5 w-3.5" /> Add domain
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {DOMAINS.map((d) => (
                  <div key={d.id} className="p-4 hover:bg-muted/30 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0",
                        d.verified ? "bg-[color:var(--success)]/12 text-[color:var(--success)]" : "bg-[color:var(--warning)]/15 text-[color:var(--warning)]"
                      )}>
                        <Globe className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-medium font-mono">{d.domain}</p>
                          {d.primary && <Badge variant="outline" className="text-[9px] gap-1 border-primary/30 text-primary bg-primary/5">Primary</Badge>}
                          {d.verified ? (
                            <StatusBadge tone="success" dot>Verified</StatusBadge>
                          ) : (
                            <StatusBadge tone="warning" dot>Pending</StatusBadge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1.5 text-[11px] text-muted-foreground flex-wrap">
                          <span className="inline-flex items-center gap-1"><Shield className="h-3 w-3" /> {d.ssl}</span>
                          <span className="inline-flex items-center gap-1 font-mono"><Globe className="h-3 w-3" /> {d.dns}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { navigator.clipboard?.writeText(d.domain); toast.success("Domain copied"); }}>
                          <Copy className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-xs h-7" onClick={() => toast.message(`Managing ${d.domain}`)}>
                          Configure
                        </Button>
                      </div>
                    </div>
                    {!d.verified && (
                      <div className="mt-3 ml-12 rounded-lg border border-[color:var(--warning)]/30 bg-[color:var(--warning)]/[0.04] p-2.5 text-xs flex items-start gap-2">
                        <AlertTriangle className="h-3.5 w-3.5 text-[color:var(--warning)] mt-0.5 shrink-0" />
                        <div className="min-w-0">
                          <p className="font-medium text-[color:var(--warning)]">Verification required</p>
                          <p className="text-muted-foreground mt-0.5">Add this TXT record to your DNS:</p>
                          <code className="block font-mono text-[10px] bg-background border border-border rounded p-1.5 mt-1 break-all">nexusgrid-verify=abc123def456ghi789</code>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* DANGER ZONE */}
          <Card className="border-destructive/30">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-4 w-4" /> Danger zone
              </CardTitle>
              <CardDescription>Irreversible actions. Transfer ownership or delete the entire workspace.</CardDescription>
            </CardHeader>
            <CardContent className="grid sm:grid-cols-2 gap-4">
              <div className="flex items-center justify-between gap-3 p-4 rounded-lg border border-border">
                <div className="min-w-0">
                  <p className="text-sm font-medium">Transfer ownership</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Hand this workspace to another Owner.</p>
                </div>
                <Button variant="outline" size="sm" className="text-xs shrink-0" onClick={() => toast.message("Opening transfer flow")}>Transfer</Button>
              </div>
              <AlertDialog>
                <div className="flex items-center justify-between gap-3 p-4 rounded-lg border border-destructive/30 bg-destructive/[0.04]">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-destructive">Delete workspace</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Permanently erase all members, projects, and data.</p>
                  </div>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm" className="gap-1.5 text-xs shrink-0">
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </Button>
                  </AlertDialogTrigger>
                </div>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-destructive">Delete the “{settings.name}” workspace?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This permanently erases all 14 members, 28 projects, 84 GB of files, and the full audit history. The action cannot be undone. To confirm, type the workspace name <span className="font-mono font-semibold text-foreground">{settings.name}</span> below.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <Input
                    value={deleteTyped}
                    onChange={(e) => setDeleteTyped(e.target.value)}
                    placeholder={`Type ${settings.name} to confirm`}
                  />
                  <AlertDialogFooter>
                    <AlertDialogCancel onClick={() => setDeleteTyped("")}>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      disabled={deleteTyped !== settings.name}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      onClick={() => { setDeleteTyped(""); toast.error("Workspace deletion scheduled", { description: "All data will be purged within 30 days." }); }}
                    >
                      Permanently delete workspace
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
