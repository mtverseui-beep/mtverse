"use client";

import * as React from "react";
import {
  HelpCircle,
  Search,
  Rocket,
  CreditCard,
  SlidersHorizontal,
  Plug,
  Shield,
  UserCog,
  MessageSquare,
  ArrowRight,
  Mail,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";

type Category = {
  id: string;
  name: string;
  icon: React.ElementType;
  count: number;
  description: string;
};

const CATEGORIES: Category[] = [
  { id: "getting-started", name: "Getting Started", icon: Rocket, count: 4, description: "Onboarding basics" },
  { id: "billing", name: "Billing", icon: CreditCard, count: 3, description: "Plans and invoices" },
  { id: "features", name: "Features", icon: SlidersHorizontal, count: 2, description: "Product capabilities" },
  { id: "integrations", name: "Integrations", icon: Plug, count: 2, description: "Connecting tools" },
  { id: "security", name: "Security", icon: Shield, count: 1, description: "Account protection" },
  { id: "account", name: "Account", icon: UserCog, count: 2, description: "Profile and access" },
];

type QA = { category: string; q: string; a: string };

const FAQS: QA[] = [
  {
    category: "getting-started",
    q: "How do I create my first project?",
    a: "From the sidebar, click Projects then New Project. Give it a name, choose a template (Blank, Kanban, or Calendar) and invite collaborators by email. Everything you create in a project — tasks, files, and discussions — stays scoped to that workspace.",
  },
  {
    category: "getting-started",
    q: "What's the difference between a workspace and a project?",
    a: "A workspace is your organization's top-level container — it holds billing, members, and global settings. Projects live inside a workspace and are where day-to-day work happens. Most teams start with one workspace and many projects.",
  },
  {
    category: "getting-started",
    q: "Can I import data from another tool?",
    a: "Yes. We support CSV imports for tasks and contacts, plus direct migration from Asana, Trello, Jira, and Monday through our importer wizard. Go to Settings > Import to begin. Each importer preserves statuses, assignees, attachments, and comments where possible.",
  },
  {
    category: "getting-started",
    q: "How do I invite my team?",
    a: "Open Workspace Settings, navigate to Members, and click Invite. You can invite up to your plan's member limit by email, or generate a shareable invite link that expires in 7 days. New members receive an onboarding email with setup instructions.",
  },
  {
    category: "billing",
    q: "When am I billed?",
    a: "Billing starts the day you upgrade to a paid plan and recurs on the same calendar day each month (or year for annual plans). If your billing date falls on the 31st, we charge on the last day of shorter months.",
  },
  {
    category: "billing",
    q: "How do refunds work?",
    a: "We offer a no-questions-asked refund within 14 days of any new subscription or upgrade. Refunds for partial periods after that window are evaluated case-by-case. Contact billing@nexusgrid.io with your invoice number to start a refund request.",
  },
  {
    category: "billing",
    q: "Can I get an invoice with my company's VAT number?",
    a: "Absolutely. Add your company name, address, and tax ID under Settings > Billing > Tax Information. All future invoices will include this information. We can also re-issue past invoices on request.",
  },
  {
    category: "features",
    q: "Does NexusGrid support custom fields?",
    a: "Yes — on Starter and above. Custom fields can be text, number, date, dropdown, or formula. They can be added to any project and surfaced in table views, filters, and dashboards. Formula fields support over 40 functions.",
  },
  {
    category: "features",
    q: "How do dashboards work?",
    a: "Dashboards aggregate data from one or more projects into widgets — KPIs, charts, tables, and timelines. Drag widgets onto a grid, connect them to a data source, and share with viewers. Pro plans unlock real-time dashboards that refresh every 30 seconds.",
  },
  {
    category: "integrations",
    q: "Which integrations are available out of the box?",
    a: "We ship native integrations with Slack, Microsoft Teams, GitHub, GitLab, Jira, Linear, Zendesk, HubSpot, Salesforce, Google Drive, Dropbox, Notion, and Figma. Webhooks and a REST API cover anything we don't have a native connector for.",
  },
  {
    category: "integrations",
    q: "How do I set up the Slack integration?",
    a: "Go to Settings > Integrations > Slack and click Connect. Authorize the workspace, pick the channels you want notifications in, and select which events trigger messages (task created, status changed, comment added). You can fine-tune per project later.",
  },
  {
    category: "security",
    q: "Is two-factor authentication required?",
    a: "On Free and Starter, 2FA is optional but strongly recommended. Pro and Enterprise admins can enforce 2FA org-wide. We support TOTP apps (Authy, 1Password, Google Authenticator) and hardware keys via WebAuthn.",
  },
  {
    category: "account",
    q: "How do I change my email address?",
    a: "Visit Account > Profile, click Edit next to your email, and enter the new address. We send a verification link to the new email — once confirmed, the change takes effect immediately and your old email is released.",
  },
  {
    category: "account",
    q: "What happens to my data if I delete my account?",
    a: "Account deletion permanently removes your personal data within 30 days. Workspace data owned by your team remains accessible to remaining admins. If you're the last admin, you must transfer ownership before deletion. See our Privacy Policy for full details.",
  },
];

export default function FAQPage() {
  const [query, setQuery] = React.useState("");
  const [activeCategory, setActiveCategory] = React.useState<string>("all");

  const filtered = React.useMemo(() => {
    return FAQS.filter((f) => {
      const matchesCategory = activeCategory === "all" || f.category === activeCategory;
      const matchesQuery =
        query.trim() === "" ||
        f.q.toLowerCase().includes(query.toLowerCase()) ||
        f.a.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  const grouped = React.useMemo(() => {
    const map = new Map<string, QA[]>();
    filtered.forEach((f) => {
      if (!map.has(f.category)) map.set(f.category, []);
      map.get(f.category)!.push(f);
    });
    return map;
  }, [filtered]);

  return (
    <>
      <PageHeader
        title="Frequently Asked Questions"
        description="Browse common questions and answers across every category. Can't find what you're looking for? Our support team is one click away."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "FAQ" }]}
        icon={HelpCircle}
      />

      {/* SEARCH BAR */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search questions, e.g. 'how do I invite teammates'"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-9 h-11"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-6">
        {/* SIDEBAR */}
        <aside className="lg:sticky lg:top-4 lg:self-start">
          <Card>
            <CardContent className="p-3">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground px-2 py-1.5">Categories</p>
              <nav className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => setActiveCategory("all")}
                  className={cn(
                    "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm transition-colors text-left",
                    activeCategory === "all" ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground/80"
                  )}
                >
                  <HelpCircle className="h-4 w-4" />
                  <span className="flex-1">All questions</span>
                  <Badge variant="outline" className="text-[10px] h-4.5">{FAQS.length}</Badge>
                </button>
                {CATEGORIES.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setActiveCategory(c.id)}
                    className={cn(
                      "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm transition-colors text-left",
                      activeCategory === c.id ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted/60 text-foreground/80"
                    )}
                  >
                    <c.icon className="h-4 w-4" />
                    <span className="flex-1">{c.name}</span>
                    <Badge variant="outline" className="text-[10px] h-4.5">{c.count}</Badge>
                  </button>
                ))}
              </nav>
            </CardContent>
          </Card>
        </aside>

        {/* ACCORDIONS */}
        <div className="min-w-0">
          {filtered.length === 0 ? (
            <Card>
              <CardContent className="py-16 text-center">
                <div className="grid place-items-center h-12 w-12 rounded-full bg-muted text-muted-foreground mx-auto mb-3">
                  <Search className="h-5 w-5" strokeWidth={1.4} />
                </div>
                <p className="text-sm font-medium">No matching questions</p>
                <p className="text-xs text-muted-foreground mt-1">Try a different search term or category.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {Array.from(grouped.entries()).map(([cat, items]) => {
                const catMeta = CATEGORIES.find((c) => c.id === cat);
                return (
                  <Card key={cat}>
                    <CardContent className="p-0">
                      <div className="flex items-center gap-2.5 px-5 py-3 border-b border-border bg-muted/30">
                        {catMeta && (
                          <div className="grid place-items-center h-7 w-7 rounded-lg bg-primary/10 text-primary">
                            <catMeta.icon className="h-3.5 w-3.5" />
                          </div>
                        )}
                        <h3 className="text-sm font-semibold">{catMeta?.name ?? cat}</h3>
                        <Badge variant="outline" className="ml-auto text-[10px]">{items.length}</Badge>
                      </div>
                      <Accordion type="single" collapsible className="px-5">
                        {items.map((f, i) => (
                          <AccordionItem key={i} value={`${cat}-${i}`}>
                            <AccordionTrigger className="text-sm font-medium hover:no-underline">
                              {f.q}
                            </AccordionTrigger>
                            <AccordionContent className="text-sm text-muted-foreground leading-relaxed">
                              {f.a}
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {/* STILL HAVE QUESTIONS CTA */}
          <Card className="mt-6 overflow-hidden relative border-primary/30">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/[0.06] via-primary/[0.02] to-transparent" aria-hidden />
            <CardContent className="relative p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/12 text-primary shrink-0">
                <MessageSquare className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-base font-semibold">Still have questions?</h3>
                <p className="text-sm text-muted-foreground mt-0.5">Our support team typically responds within 4 hours during business days.</p>
              </div>
              <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
                <Button variant="outline" size="sm" className="gap-1.5 flex-1 sm:flex-none" asChild>
                  <a href="/contact-support">
                    <Mail className="h-3.5 w-3.5" /> Email support
                  </a>
                </Button>
                <Button size="sm" className="gap-1.5 flex-1 sm:flex-none">
                  Live chat <ArrowRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
