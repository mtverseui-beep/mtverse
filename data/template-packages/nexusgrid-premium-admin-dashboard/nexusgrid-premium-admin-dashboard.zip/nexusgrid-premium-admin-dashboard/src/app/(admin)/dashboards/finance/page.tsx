"use client";

import * as React from "react";
import {
  DollarSign,
  Wallet,
  PiggyBank,
  Clock,
  Filter,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  TrendingDown,
  Receipt,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Sparkline } from "@/components/common/kpi-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BarTrendChart, LineTrendChart, DonutChart } from "@/components/charts";
import { financeCashflow, financeExpenses, months } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline finance data ---------- */

// Profit margin % over months
const marginTrend = months.map((m, i) => {
  const margin = 32 + Math.round(Math.sin(i * 0.8) * 3 + i * 0.4);
  return { month: m, margin };
});

// Budget variance — 6 categories
const budgetVariance = [
  { category: "Payroll", budgeted: 140000, actual: 142000, tone: "warning" as StatusTone },
  { category: "Infrastructure", budgeted: 50000, actual: 48000, tone: "success" as StatusTone },
  { category: "Marketing", budgeted: 35000, actual: 38000, tone: "warning" as StatusTone },
  { category: "Operations", budgeted: 30000, actual: 28000, tone: "success" as StatusTone },
  { category: "R&D", budgeted: 45000, actual: 52000, tone: "danger" as StatusTone },
  { category: "Legal & Compliance", budgeted: 15000, actual: 12000, tone: "success" as StatusTone },
];

// Recent transactions
const transactions = [
  { date: "Jul 01", description: "Stripe payout — customer payments", category: "Revenue", amount: 84200, type: "inflow" as const },
  { date: "Jul 01", description: "AWS — monthly infrastructure", category: "Infrastructure", amount: 12400, type: "outflow" as const },
  { date: "Jun 30", description: "Payroll run — June cycle 2", category: "Payroll", amount: 71000, type: "outflow" as const },
  { date: "Jun 30", description: "Gusto — benefits & insurance", category: "Operations", amount: 8400, type: "outflow" as const },
  { date: "Jun 29", description: "HubSpot — annual subscription", category: "Marketing", amount: 18000, type: "outflow" as const },
  { date: "Jun 28", description: "Wire transfer — enterprise contract", category: "Revenue", amount: 124000, type: "inflow" as const },
];

// Sparkline series for KPIs
const revenueSpark = financeCashflow.map((c) => c.inflow);
const profitSpark = financeCashflow.map((c) => c.inflow - c.outflow);
const cashSpark = financeCashflow.map((c, i) => 2800000 + (c.inflow - c.outflow) * (i + 1) * 0.3);
const runwaySpark = months.map((_, i) => 18 + Math.round(Math.sin(i) * 1.5));

/* ---------- Finance KPI card — conservative ledger vibe ---------- */
// Distinct: left vertical accent bar + monospaced tabular numbers +
// ledger-style "previous value" comparison row + sparkline at bottom.

function FinanceKpiCard({
  label,
  value,
  icon: Icon,
  trend,
  previous,
  sparkData,
  sparkColor,
  stable = false,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  previous: string;
  sparkData: number[];
  sparkColor: string;
  stable?: boolean;
}) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      {/* Left vertical accent bar — ledger column marker */}
      <div className="absolute left-0 top-5 bottom-5 w-1 rounded-r-full bg-[color:var(--success)]" />

      <div className="pl-2.5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">{label}</p>
            <p className="mt-1.5 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
          </div>
          <div className="grid place-items-center h-9 w-9 rounded-lg shrink-0 bg-[color:var(--success)]/12 text-[color:var(--success)]">
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>

        {/* Ledger comparison row */}
        <div className="mt-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="tabular-nums">{previous}</span>
            <span className="opacity-60">prev.</span>
          </div>
          {stable ? (
            <span className="inline-flex items-center gap-1 rounded-md bg-muted px-1.5 py-0.5 text-xs font-medium text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground" />
              Stable
            </span>
          ) : (
            <span
              className={cn(
                "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
                trend.positive
                  ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                  : "bg-destructive/12 text-destructive"
              )}
            >
              {trend.direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {Math.abs(trend.value)}%
            </span>
          )}
        </div>

        {/* Sparkline */}
        <div className="mt-3 -mb-1">
          <Sparkline data={sparkData} color={sparkColor} width={260} height={32} />
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function FinanceDashboardPage() {
  const totalExpenses = financeExpenses.reduce((s, x) => s + x.value, 0);
  const netCash = financeCashflow.reduce((s, x) => s + (x.inflow - x.outflow), 0);

  return (
    <>
      <PageHeader
        title="Finance Dashboard"
        description="Cash position, P&L, budget variance, and runway — books closed through Jun 30, 2026."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Finance" }]}
        icon={DollarSign}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> FY 2026
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export ledger
            </Button>
            <Button size="sm" className="gap-1.5 bg-[color:var(--success)] text-[color:var(--success-foreground)] hover:bg-[color:var(--success)]/90">
              <Receipt className="h-3.5 w-3.5" /> Close month
            </Button>
          </>
        }
      />

      {/* KPI Row — FinanceKpiCard with ledger vibe */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <FinanceKpiCard
          label="Total Revenue"
          value="$1.84M"
          icon={DollarSign}
          previous="$1.56M"
          trend={{ value: 18, direction: "up", positive: true }}
          sparkData={revenueSpark}
          sparkColor="var(--success)"
        />
        <FinanceKpiCard
          label="Net Profit"
          value="$642K"
          icon={TrendingUp}
          previous="$527K"
          trend={{ value: 22, direction: "up", positive: true }}
          sparkData={profitSpark}
          sparkColor="var(--success)"
        />
        <FinanceKpiCard
          label="Cash Balance"
          value="$3.2M"
          icon={Wallet}
          previous="$3.08M"
          trend={{ value: 4, direction: "up", positive: true }}
          sparkData={cashSpark}
          sparkColor="var(--primary)"
        />
        <FinanceKpiCard
          label="Runway"
          value="18 months"
          icon={Clock}
          previous="18 months"
          trend={{ value: 0, direction: "up", positive: true }}
          sparkData={runwaySpark}
          sparkColor="var(--info)"
          stable
        />
      </div>

      {/* Cash flow chart + Expense breakdown */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Wallet className="h-4 w-4 text-[color:var(--success)]" />
                Cash Flow
              </CardTitle>
              <CardDescription>
                Monthly inflow vs. outflow. Net cash position:{" "}
                <span className={cn("font-medium tabular-nums", netCash >= 0 ? "text-[color:var(--success)]" : "text-destructive")}>
                  {netCash >= 0 ? "+" : "−"}${Math.abs(netCash).toLocaleString()}
                </span>
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)]" /> Inflow
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-destructive" /> Outflow
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={financeCashflow}
              xKey="month"
              series={[
                { key: "inflow", name: "Inflow ($)", color: "var(--success)" },
                { key: "outflow", name: "Outflow ($)", color: "var(--destructive)" },
              ]}
              height={300}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Expense Breakdown</CardTitle>
            <CardDescription>By category, current month.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={financeExpenses}
              centerLabel="Total"
              centerValue={`$${(totalExpenses / 1000).toFixed(0)}K`}
              height={200}
            />
            <div className="mt-3 space-y-1.5">
              {financeExpenses.map((e) => {
                const pct = ((e.value / totalExpenses) * 100).toFixed(1);
                return (
                  <div key={e.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="h-2 w-2 rounded-full shrink-0" style={{ background: e.color }} />
                      <span className="text-muted-foreground truncate">{e.name}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-medium tabular-nums">${e.value.toLocaleString()}</span>
                      <span className="text-muted-foreground tabular-nums w-10 text-right">{pct}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Budget variance table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <PiggyBank className="h-4 w-4 text-[color:var(--success)]" />
              Budget Variance
            </CardTitle>
            <CardDescription>Planned vs. actual spend by category for Q2 2026.</CardDescription>
          </div>
          <StatusBadge tone="success" dot>Within 4% of plan</StatusBadge>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Category</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Budgeted</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Actual</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Variance</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Variance %</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {budgetVariance.map((b) => {
                  const variance = b.actual - b.budgeted;
                  const variancePct = (variance / b.budgeted) * 100;
                  const isOver = variance > 0;
                  return (
                    <tr key={b.category} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-medium text-foreground">{b.category}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">${b.budgeted.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right tabular-nums font-medium">${b.actual.toLocaleString()}</td>
                      <td className={cn(
                        "px-4 py-3 text-right tabular-nums font-medium hidden sm:table-cell",
                        isOver ? "text-destructive" : "text-[color:var(--success)]"
                      )}>
                        {isOver ? "−" : "+"}${Math.abs(variance).toLocaleString()}
                      </td>
                      <td className={cn(
                        "px-4 py-3 text-right tabular-nums hidden md:table-cell",
                        isOver ? "text-destructive" : "text-[color:var(--success)]"
                      )}>
                        {isOver ? "+" : "−"}{Math.abs(variancePct).toFixed(1)}%
                      </td>
                      <td className="px-4 py-3 text-center">
                        <StatusBadge tone={b.tone} dot>
                          {b.tone === "success" ? "Under" : b.tone === "warning" ? "Slight over" : "Over budget"}
                        </StatusBadge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="border-t-2 border-border bg-muted/30">
                <tr>
                  <td className="px-4 py-3 font-semibold text-foreground">Total</td>
                  <td className="px-4 py-3 text-right tabular-nums font-semibold">
                    ${budgetVariance.reduce((s, b) => s + b.budgeted, 0).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums font-semibold">
                    ${budgetVariance.reduce((s, b) => s + b.actual, 0).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums font-semibold text-destructive hidden sm:table-cell">
                    −${budgetVariance.reduce((s, b) => s + (b.actual - b.budgeted), 0).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums font-semibold text-destructive hidden md:table-cell">
                    +{((budgetVariance.reduce((s, b) => s + (b.actual - b.budgeted), 0) / budgetVariance.reduce((s, b) => s + b.budgeted, 0)) * 100).toFixed(1)}%
                  </td>
                  <td className="px-4 py-3" />
                </tr>
              </tfoot>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Recent transactions + Profit margin trend */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Receipt className="h-4 w-4 text-primary" />
                Recent Transactions
              </CardTitle>
              <CardDescription>Latest ledger entries across all accounts.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View ledger <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y divide-border">
              {transactions.map((t, i) => {
                const isInflow = t.type === "inflow";
                return (
                  <li key={i} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors">
                    <div
                      className={cn(
                        "grid place-items-center h-9 w-9 rounded-lg shrink-0",
                        isInflow ? "bg-[color:var(--success)]/12 text-[color:var(--success)]" : "bg-destructive/12 text-destructive"
                      )}
                    >
                      {isInflow ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{t.description}</p>
                      <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                        <span className="tabular-nums">{t.date}</span>
                        <span className="opacity-40">·</span>
                        <span>{t.category}</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p
                        className={cn(
                          "text-sm font-semibold tabular-nums",
                          isInflow ? "text-[color:var(--success)]" : "text-foreground"
                        )}
                      >
                        {isInflow ? "+" : "−"}${t.amount.toLocaleString()}
                      </p>
                      <StatusBadge tone={isInflow ? "success" : "neutral"} className="mt-0.5 capitalize">
                        {t.type}
                      </StatusBadge>
                    </div>
                  </li>
                );
              })}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-[color:var(--success)]" />
              Profit Margin Trend
            </CardTitle>
            <CardDescription>Net margin % over the trailing 12 months.</CardDescription>
          </CardHeader>
          <CardContent>
            <LineTrendChart
              data={marginTrend}
              xKey="month"
              series={[
                { key: "margin", name: "Net Margin (%)", color: "var(--success)" },
              ]}
              height={260}
            />
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-3 gap-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Current</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                  {marginTrend[marginTrend.length - 1].margin}%
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Avg</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">
                  {(marginTrend.reduce((s, x) => s + x.margin, 0) / marginTrend.length).toFixed(1)}%
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">YoY Change</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">+4.2 pts</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
