"use client";

import * as React from "react";
import {
  LifeBuoy,
  Inbox,
  Clock,
  CheckCircle2,
  Star,
  Filter,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Eye,
  ThumbsUp,
  MessageSquare,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AreaTrendChart, DonutChart } from "@/components/charts";
import { supportTickets, supportSla } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline support data ---------- */

// 7-day ticket volume (inline)
const ticketVolume = [
  { day: "Mon", created: 42, resolved: 38 },
  { day: "Tue", created: 51, resolved: 44 },
  { day: "Wed", created: 38, resolved: 41 },
  { day: "Thu", created: 62, resolved: 55 },
  { day: "Fri", created: 48, resolved: 52 },
  { day: "Sat", created: 28, resolved: 24 },
  { day: "Sun", created: 22, resolved: 26 },
];

// Agent performance leaderboard (inline) — names align with supportTickets agents
const agents = [
  { rank: 1, name: "Elena Petrov", short: "Elena P.", role: "Senior Support Engineer", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", resolved: 156, avgResponse: "58m", csat: 4.9, online: true },
  { rank: 2, name: "Sarah Chen", short: "Sarah C.", role: "Support Lead", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", resolved: 142, avgResponse: "1h 12m", csat: 4.8, online: true },
  { rank: 3, name: "Aiko Tanaka", short: "Aiko T.", role: "Support Engineer", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", resolved: 134, avgResponse: "1h 18m", csat: 4.7, online: false },
  { rank: 4, name: "Marcus Reyes", short: "Marcus R.", role: "Support Engineer", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", resolved: 128, avgResponse: "1h 28m", csat: 4.6, online: true },
  { rank: 5, name: "James Okoro", short: "James O.", role: "Support Engineer", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", resolved: 118, avgResponse: "1h 42m", csat: 4.4, online: false },
];

// Agent avatar lookup by short name (for the active tickets table)
const agentLookup: Record<string, { name: string; avatar: string }> = Object.fromEntries(
  agents.map((a) => [a.short, { name: a.name, avatar: a.avatar }])
);

// KB insights — top 5 articles (inline)
const kbArticles = [
  { title: "Setting up SSO with SAML 2.0", views: 12480, helpful: 92, trend: 12, trendDir: "up" as const },
  { title: "API rate limits and quotas", views: 9840, helpful: 88, trend: 8, trendDir: "up" as const },
  { title: "Importing CSV files larger than 100MB", views: 8420, helpful: 76, trend: 24, trendDir: "up" as const },
  { title: "Configuring webhook retries", views: 6820, helpful: 84, trend: 3, trendDir: "down" as const },
  { title: "Billing and invoice FAQ", views: 5940, helpful: 91, trend: 5, trendDir: "up" as const },
];

/* ---------- Helpers ---------- */

// Priority tone mapping for badges
function priorityTone(p: string): StatusTone {
  switch (p) {
    case "urgent": return "danger";
    case "high": return "warning";
    case "medium": return "info";
    case "low": return "neutral";
    default: return "neutral";
  }
}

// Status tone mapping
function statusTone(s: string): StatusTone {
  switch (s) {
    case "open": return "warning";
    case "pending": return "info";
    case "resolved": return "success";
    default: return "neutral";
  }
}

/* ---------- SupportCard — ticket-ops feel with pulse bars + queue bar ---------- */
// Distinct from SaaS heatmap card: top-right 7-bar weekly "pulse" (peak
// highlighted in accent color) + bottom 4-segment "queue composition" bar.
// Uses priority/speed/status/rating colors tied to the ops theme.

type SupportAccent = "rose" | "amber" | "emerald" | "violet";

function SupportCard({
  label,
  value,
  icon: Icon,
  trend,
  trendPositive,
  caption,
  accent,
  pulse,
  queue,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  trend: { value: number; direction: "up" | "down" } | null;
  trendPositive: boolean;
  caption: string;
  accent: SupportAccent;
  pulse: number[]; // 7 daily values
  queue: { label: string; value: number; color: string }[];
}) {
  const accentColor: Record<SupportAccent, string> = {
    rose: "var(--destructive)",
    amber: "var(--warning)",
    emerald: "var(--success)",
    violet: "var(--primary)",
  };
  const accentIcon: Record<SupportAccent, string> = {
    rose: "bg-destructive/15 text-destructive",
    amber: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    emerald: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    violet: "bg-primary/15 text-primary",
  };

  const maxPulse = Math.max(...pulse);
  const peakIdx = pulse.indexOf(maxPulse);
  const totalQueue = queue.reduce((s, x) => s + x.value, 0);

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      {/* Left accent stripe — color identity */}
      <div
        className="absolute left-0 top-5 bottom-5 w-1 rounded-r-full"
        style={{ background: accentColor[accent] }}
      />
      <div className="pl-2.5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
              {label}
            </p>
            <p className="mt-1.5 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {/* 7-bar weekly pulse — peak highlighted */}
            <div
              className="flex items-end gap-[2px] h-8"
              role="img"
              aria-label={`${label} weekly pulse`}
            >
              {pulse.map((v, i) => {
                const h = Math.max(2, (v / maxPulse) * 28);
                const isPeak = i === peakIdx;
                return (
                  <span
                    key={i}
                    className="w-[3px] rounded-sm transition-all"
                    style={{
                      height: `${h}px`,
                      background: isPeak ? accentColor[accent] : "var(--muted-foreground)",
                      opacity: isPeak ? 1 : 0.35,
                    }}
                    title={`Day ${i + 1}: ${v}`}
                  />
                );
              })}
            </div>
            <div className={cn("grid place-items-center h-9 w-9 rounded-lg", accentIcon[accent])}>
              <Icon className="h-4.5 w-4.5" />
            </div>
          </div>
        </div>

        {/* Trend pill + caption */}
        <div className="mt-3 flex items-center gap-2 flex-wrap">
          {trend && (
            <span
              className={cn(
                "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
                trendPositive
                  ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                  : "bg-destructive/12 text-destructive"
              )}
            >
              {trend.direction === "up" ? (
                <ArrowUpRight className="h-3 w-3" />
              ) : (
                <ArrowDownRight className="h-3 w-3" />
              )}
              {Math.abs(trend.value)}
            </span>
          )}
          <span className="text-xs text-muted-foreground truncate">{caption}</span>
        </div>

        {/* Queue composition bar — 4-segment */}
        <div className="mt-3 -mb-1">
          <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-muted">
            {queue.map((q) => (
              <div
                key={q.label}
                className="h-full transition-all duration-500"
                style={{ width: `${(q.value / totalQueue) * 100}%`, background: q.color }}
              />
            ))}
          </div>
          <div className="mt-1.5 flex items-center justify-between gap-1 text-[10px] text-muted-foreground">
            {queue.map((q) => (
              <span key={q.label} className="inline-flex items-center gap-1 min-w-0">
                <span
                  className="h-1.5 w-1.5 rounded-full shrink-0"
                  style={{ background: q.color }}
                />
                <span className="truncate">{q.label}</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Star rating (filled / empty) ---------- */
function StarRating({ value, max = 5 }: { value: number; max?: number }) {
  return (
    <span className="inline-flex items-center gap-0.5" aria-label={`${value} out of ${max} stars`}>
      {Array.from({ length: max }, (_, i) => (
        <Star
          key={i}
          className={cn(
            "h-3 w-3",
            i < Math.round(value)
              ? "fill-[color:var(--warning)] text-[color:var(--warning)]"
              : "fill-none text-muted-foreground/40"
          )}
        />
      ))}
    </span>
  );
}

/* ---------- Page ---------- */

export default function SupportDashboardPage() {
  const totalSla = supportSla.reduce((s, x) => s + x.value, 0);
  const slaCompliance = Math.round(
    (supportSla.filter((s) => s.name !== "Breached SLA").reduce((s, x) => s + x.value, 0) /
      totalSla) *
      100
  );
  const totalCreated = ticketVolume.reduce((s, d) => s + d.created, 0);
  const totalResolved = ticketVolume.reduce((s, d) => s + d.resolved, 0);
  const maxResolved = Math.max(...agents.map((a) => a.resolved));

  return (
    <>
      <PageHeader
        title="Support Dashboard"
        description="Ticket volume, SLA compliance, agent performance, and knowledge base health — your support operations at a glance."
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Dashboards" },
          { label: "Support" },
        ]}
        icon={LifeBuoy}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Last 7 days
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="gap-1.5 bg-[color:var(--destructive)] text-white hover:bg-[color:var(--destructive)]/90"
            >
              <Plus className="h-3.5 w-3.5" /> New ticket
            </Button>
          </>
        }
      />

      {/* KPI Row — SupportCard with pulse bars + queue bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <SupportCard
          label="Open Tickets"
          value="248"
          icon={Inbox}
          trend={{ value: 12, direction: "up" }}
          trendPositive={false}
          caption="12 urgent need attention"
          accent="rose"
          pulse={[42, 51, 38, 62, 48, 28, 22]}
          queue={[
            { label: "Urgent 12", value: 12, color: "var(--destructive)" },
            { label: "High 68", value: 68, color: "var(--warning)" },
            { label: "Med 112", value: 112, color: "var(--info)" },
            { label: "Low 56", value: 56, color: "oklch(0.68 0.04 75)" },
          ]}
        />
        <SupportCard
          label="Avg Response"
          value="1h 24m"
          icon={Clock}
          trend={{ value: 18, direction: "down" }}
          trendPositive
          caption="faster than last week"
          accent="amber"
          pulse={[58, 52, 48, 42, 38, 44, 40]}
          queue={[
            { label: "<1h 142", value: 142, color: "var(--success)" },
            { label: "1-4h 72", value: 72, color: "var(--info)" },
            { label: "4-24h 28", value: 28, color: "var(--warning)" },
            { label: ">24h 6", value: 6, color: "var(--destructive)" },
          ]}
        />
        <SupportCard
          label="Resolution Rate"
          value="94%"
          icon={CheckCircle2}
          trend={{ value: 2, direction: "up" }}
          trendPositive
          caption="234 of 248 resolved"
          accent="emerald"
          pulse={[38, 44, 41, 55, 52, 24, 26]}
          queue={[
            { label: "Resolved 234", value: 234, color: "var(--success)" },
            { label: "Prog 8", value: 8, color: "var(--primary)" },
            { label: "Pending 4", value: 4, color: "var(--warning)" },
            { label: "Esc 2", value: 2, color: "var(--destructive)" },
          ]}
        />
        <SupportCard
          label="CSAT Score"
          value="4.6/5"
          icon={Star}
          trend={{ value: 0.2, direction: "up" }}
          trendPositive
          caption="1,284 ratings this week"
          accent="violet"
          pulse={[42, 48, 44, 52, 58, 38, 46]}
          queue={[
            { label: "5★ 840", value: 840, color: "var(--success)" },
            { label: "4★ 312", value: 312, color: "var(--primary)" },
            { label: "3★ 84", value: 84, color: "var(--warning)" },
            { label: "1-2★ 48", value: 48, color: "var(--destructive)" },
          ]}
        />
      </div>

      {/* Ticket volume trend (2/3) + SLA compliance (1/3) */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Inbox className="h-4 w-4 text-[color:var(--destructive)]" />
                Ticket Volume Trend
              </CardTitle>
              <CardDescription>
                Tickets created vs. resolved over the last 7 days. Net change:{" "}
                <span
                  className={cn(
                    "font-medium tabular-nums",
                    totalCreated - totalResolved > 0
                      ? "text-[color:var(--warning)]"
                      : "text-[color:var(--success)]"
                  )}
                >
                  {totalCreated - totalResolved > 0 ? "+" : "−"}
                  {Math.abs(totalCreated - totalResolved)} tickets
                </span>
                .
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs shrink-0">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--destructive)]" /> Created
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)]" /> Resolved
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={ticketVolume}
              xKey="day"
              series={[
                { key: "created", name: "Created", color: "var(--destructive)" },
                { key: "resolved", name: "Resolved", color: "var(--success)" },
              ]}
              height={300}
            />
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-3 gap-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Total Created</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">{totalCreated}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Total Resolved</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                  {totalResolved}
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Peak Day</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">
                  Thu ({Math.max(...ticketVolume.map((d) => d.created))})
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-[color:var(--success)]" />
              SLA Compliance
            </CardTitle>
            <CardDescription>Resolution time distribution across all tickets.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={supportSla}
              centerLabel="SLA met"
              centerValue={`${slaCompliance}%`}
              height={200}
            />
            <div className="mt-3 space-y-1.5">
              {supportSla.map((s) => {
                const pct = ((s.value / totalSla) * 100).toFixed(1);
                const isBreach = s.name === "Breached SLA";
                return (
                  <div key={s.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="h-2 w-2 rounded-full shrink-0"
                        style={{ background: s.color }}
                      />
                      <span
                        className={cn(
                          "truncate",
                          isBreach && "text-[color:var(--destructive)] font-medium"
                        )}
                      >
                        {s.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-medium tabular-nums">{s.value}</span>
                      <span className="text-muted-foreground tabular-nums w-10 text-right">{pct}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-3 pt-3 border-t border-border flex items-center gap-2 text-xs">
              <AlertCircle className="h-3.5 w-3.5 text-[color:var(--warning)] shrink-0" />
              <span className="text-muted-foreground">
                <span className="font-medium text-foreground">2 tickets</span> breached SLA this week —
                review escalation policy.
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active tickets table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Inbox className="h-4 w-4 text-[color:var(--destructive)]" />
              Active Tickets
            </CardTitle>
            <CardDescription>Latest tickets across all queues and priorities.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            View all <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Ticket</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Subject</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Priority</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Status</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Customer</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Agent</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {supportTickets.map((t) => {
                  const agent = agentLookup[t.agent];
                  return (
                    <tr key={t.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground whitespace-nowrap">{t.id}</td>
                      <td className="px-4 py-3 font-medium text-foreground">{t.subject}</td>
                      <td className="px-4 py-3 text-center">
                        <StatusBadge tone={priorityTone(t.priority)} dot className="capitalize">
                          {t.priority}
                        </StatusBadge>
                      </td>
                      <td className="px-4 py-3 text-center hidden sm:table-cell">
                        <StatusBadge tone={statusTone(t.status)} dot className="capitalize">
                          {t.status}
                        </StatusBadge>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{t.customer}</td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        {agent ? (
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={agent.avatar} alt={agent.name} />
                              <AvatarFallback className="text-[10px]">
                                {agent.name.split(" ").map((n) => n[0]).join("")}
                              </AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-muted-foreground">{t.agent}</span>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground/60">Unassigned</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right text-xs text-muted-foreground whitespace-nowrap">{t.created}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Agent performance (1/2) + KB insights (1/2) */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Agent performance leaderboard */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Star className="h-4 w-4 text-[color:var(--warning)]" />
                Agent Performance
              </CardTitle>
              <CardDescription>Top 5 agents by resolved tickets this week.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y divide-border">
              {agents.map((a) => {
                const rankColor =
                  a.rank === 1
                    ? "bg-[color:var(--warning)]/15 text-[color:var(--warning)]"
                    : a.rank === 2
                    ? "bg-muted text-muted-foreground"
                    : a.rank === 3
                    ? "bg-[oklch(0.70_0.12_55)]/20 text-[oklch(0.55_0.13_55)]"
                    : "bg-muted/60 text-muted-foreground/70";
                const barWidth = (a.resolved / maxResolved) * 100;
                return (
                  <li key={a.name} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors">
                    {/* Rank chip */}
                    <span
                      className={cn(
                        "grid place-items-center h-7 w-7 rounded-full text-xs font-bold tabular-nums shrink-0",
                        rankColor
                      )}
                    >
                      {a.rank}
                    </span>
                    {/* Avatar with online dot */}
                    <div className="relative shrink-0">
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={a.avatar} alt={a.name} />
                        <AvatarFallback className="text-xs">
                          {a.name.split(" ").map((n) => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span
                        className={cn(
                          "absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-card",
                          a.online ? "bg-[color:var(--success)]" : "bg-muted-foreground/40"
                        )}
                        title={a.online ? "Online" : "Offline"}
                      />
                    </div>
                    {/* Name + role + resolved bar */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-medium text-foreground truncate">{a.name}</p>
                        <span className="text-xs text-muted-foreground tabular-nums shrink-0 hidden sm:inline">
                          {a.role}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center gap-2">
                        <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                          <div
                            className="h-full rounded-full bg-[color:var(--success)]/70 transition-all duration-500"
                            style={{ width: `${barWidth}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-muted-foreground tabular-nums shrink-0 w-16 text-right">
                          {a.resolved} resolved
                        </span>
                      </div>
                    </div>
                    {/* Stats column */}
                    <div className="flex flex-col items-end gap-0.5 shrink-0 text-right">
                      <span className="inline-flex items-center gap-1 text-xs text-muted-foreground tabular-nums">
                        <Clock className="h-3 w-3" />
                        {a.avgResponse}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs font-medium tabular-nums">
                        <Star className="h-3 w-3 fill-[color:var(--warning)] text-[color:var(--warning)]" />
                        {a.csat.toFixed(1)}
                      </span>
                    </div>
                  </li>
                );
              })}
            </ul>
            <div className="px-4 py-3 border-t border-border bg-muted/20 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Elena Petrov</span> leads the team with a
              58-minute average response and 4.9 CSAT. Consider pairing her with James for mentoring.
            </div>
          </CardContent>
        </Card>

        {/* Knowledge base insights */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-[color:var(--info)]" />
                Knowledge Base Insights
              </CardTitle>
              <CardDescription>Top 5 most-viewed articles this month.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y divide-border">
              {kbArticles.map((article, i) => {
                const helpfulTone: StatusTone =
                  article.helpful >= 90 ? "success" : article.helpful >= 80 ? "info" : "warning";
                return (
                  <li key={article.title} className="px-4 py-3 hover:bg-muted/30 transition-colors">
                    <div className="flex items-start gap-3">
                      {/* Article icon tile */}
                      <div className="grid place-items-center h-8 w-8 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)] shrink-0">
                        <MessageSquare className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-medium text-foreground leading-tight line-clamp-2">
                            {article.title}
                          </p>
                          <span
                            className={cn(
                              "inline-flex items-center gap-0.5 text-xs font-medium tabular-nums shrink-0 mt-0.5",
                              article.trendDir === "up"
                                ? "text-[color:var(--success)]"
                                : "text-[color:var(--destructive)]"
                            )}
                          >
                            {article.trendDir === "up" ? (
                              <TrendingUp className="h-3 w-3" />
                            ) : (
                              <TrendingDown className="h-3 w-3" />
                            )}
                            {article.trend}%
                          </span>
                        </div>
                        <div className="mt-1.5 flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="inline-flex items-center gap-1 tabular-nums">
                            <Eye className="h-3 w-3" />
                            {article.views.toLocaleString()}
                          </span>
                          <span className="inline-flex items-center gap-1 tabular-nums">
                            <ThumbsUp className="h-3 w-3" />
                            {article.helpful}%
                          </span>
                          {/* Helpful % mini bar */}
                          <div className="flex-1 h-1 rounded-full bg-muted overflow-hidden hidden sm:block max-w-[80px]">
                            <div
                              className={cn(
                                "h-full rounded-full transition-all duration-500",
                                helpfulTone === "success" && "bg-[color:var(--success)]",
                                helpfulTone === "info" && "bg-[color:var(--info)]",
                                helpfulTone === "warning" && "bg-[color:var(--warning)]"
                              )}
                              style={{ width: `${article.helpful}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
            <div className="px-4 py-3 border-t border-border bg-muted/20 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">"Importing CSV files"</span> views surged
              +24% — consider expanding this article or surfacing it proactively in onboarding.
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
