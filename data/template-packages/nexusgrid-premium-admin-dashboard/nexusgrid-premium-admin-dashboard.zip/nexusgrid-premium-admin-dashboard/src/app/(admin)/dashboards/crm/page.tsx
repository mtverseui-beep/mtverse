"use client";

import * as React from "react";
import {
  Users,
  Handshake,
  Target,
  DollarSign,
  Clock,
  Phone,
  Mail,
  CalendarClock,
  StickyNote,
  Trophy,
  ChevronRight,
  Plus,
  Filter,
  Download,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Flame,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BarTrendChart } from "@/components/charts";
import {
  crmPipeline,
  crmActivities,
  dealsByStage,
  salesReps,
} from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline CRM-specific data (not in shared mock) ---------- */

const upcomingFollowUps = [
  { customer: "Globex Corp", contact: "Daniela Pierce", time: "Today · 2:30 PM", type: "call" as const, owner: "Sarah Chen" },
  { customer: "Initech", contact: "Bill Lumbergh", time: "Today · 4:00 PM", type: "meeting" as const, owner: "Marcus Reyes" },
  { customer: "Hooli", contact: "Gavin Belson", time: "Tomorrow · 10:00 AM", type: "email" as const, owner: "Elena Petrov" },
  { customer: "Acme Corp", contact: "Wile Coyote", time: "Tomorrow · 1:15 PM", type: "call" as const, owner: "James Okoro" },
  { customer: "Umbrella Inc", contact: "Alice M.", time: "Jul 04 · 11:00 AM", type: "meeting" as const, owner: "Aiko Tanaka" },
];

const topDeals = [
  { company: "Globex Corp", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=64&h=64&fit=crop", value: 84000, stage: "Negotiation", stageTone: "warning" as StatusTone, owner: salesReps[0], closeDate: "Jul 14, 2026", probability: 75 },
  { company: "Initech", logo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=64&h=64&fit=crop", value: 62500, stage: "Proposal", stageTone: "primary" as StatusTone, owner: salesReps[1], closeDate: "Jul 18, 2026", probability: 60 },
  { company: "Hooli", logo: "https://images.unsplash.com/photo-1620288627229-c5b1d2f80c8f?w=64&h=64&fit=crop", value: 124000, stage: "Negotiation", stageTone: "warning" as StatusTone, owner: salesReps[2], closeDate: "Jul 22, 2026", probability: 80 },
  { company: "Umbrella Inc", logo: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=64&h=64&fit=crop", value: 48200, stage: "Qualified", stageTone: "info" as StatusTone, owner: salesReps[4], closeDate: "Aug 02, 2026", probability: 35 },
  { company: "Acme Corp", logo: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=64&h=64&fit=crop", value: 96800, stage: "Proposal", stageTone: "primary" as StatusTone, owner: salesReps[3], closeDate: "Jul 28, 2026", probability: 55 },
  { company: "Soylent", logo: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=64&h=64&fit=crop", value: 152000, stage: "Won", stageTone: "success" as StatusTone, owner: salesReps[2], closeDate: "Jul 01, 2026", probability: 100 },
];

/* ---------- CRM KPI cards (custom — distinct from KpiCard) ---------- */

function CrmKpiCard({
  label,
  value,
  secondary,
  secondaryLabel,
  icon: Icon,
  accent,
  trend,
}: {
  label: string;
  value: string;
  secondary: string;
  secondaryLabel: string;
  icon: LucideIcon;
  accent: "primary" | "success" | "warning" | "info" | "violet";
  trend: { value: number; direction: "up" | "down"; positive: boolean };
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    violet: "bg-violet-500/12 text-violet-500",
  };
  const accentBar: Record<string, string> = {
    primary: "bg-primary",
    success: "bg-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]",
    info: "bg-[color:var(--info)]",
    violet: "bg-violet-500",
  };
  // Secondary value text color — static strings so Tailwind can detect them.
  const accentText: Record<string, string> = {
    primary: "text-primary",
    success: "text-[color:var(--success)]",
    warning: "text-[color:var(--warning)]",
    info: "text-[color:var(--info)]",
    violet: "text-violet-500",
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      {/* Accent edge — distinct from analytics/ecommerce cards */}
      <div className={cn("absolute left-0 top-5 bottom-5 w-1 rounded-r-full", accentBar[accent])} />
      <div className="flex items-start justify-between gap-3 pl-2">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
          <p className="mt-1.5 text-2xl font-semibold tracking-tight tabular-nums">{value}</p>
        </div>
        <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
          <Icon className="h-4.5 w-4.5" />
        </div>
      </div>

      {/* Secondary metric + trend — replaces sparkline with a stat row */}
      <div className="mt-3 pl-2 flex items-center justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[11px] text-muted-foreground uppercase tracking-wide truncate">{secondaryLabel}</p>
          <p className={cn("text-sm font-semibold tabular-nums", accentText[accent])}>
            {secondary}
          </p>
        </div>
        <span
          className={cn(
            "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium shrink-0",
            trend.positive
              ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
              : "bg-destructive/12 text-destructive"
          )}
        >
          {trend.direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {Math.abs(trend.value)}%
        </span>
      </div>
    </div>
  );
}

/* ---------- Activity feed helpers ---------- */

const activityConfig: Record<string, { icon: LucideIcon; tone: StatusTone; ring: string }> = {
  call: { icon: Phone, tone: "primary", ring: "bg-primary/12 text-primary" },
  email: { icon: Mail, tone: "info", ring: "bg-[color:var(--info)]/12 text-[color:var(--info)]" },
  meeting: { icon: CalendarClock, tone: "violet", ring: "bg-violet-500/12 text-violet-500" },
  note: { icon: StickyNote, tone: "neutral", ring: "bg-muted text-muted-foreground" },
  won: { icon: Trophy, tone: "success", ring: "bg-[color:var(--success)]/12 text-[color:var(--success)]" },
};

const followUpConfig: Record<string, { icon: LucideIcon; tone: StatusTone }> = {
  call: { icon: Phone, tone: "primary" },
  meeting: { icon: CalendarClock, tone: "violet" },
  email: { icon: Mail, tone: "info" },
};

/* ---------- Page ---------- */

export default function CrmDashboardPage() {
  const totalPipelineValue = crmPipeline.reduce((s, x) => s + x.amount, 0);
  const maxStageCount = Math.max(...crmPipeline.map((s) => s.value));

  return (
    <>
      <PageHeader
        title="CRM Dashboard"
        description="Pipeline health, deal velocity, and rep activity across your sales organization."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "CRM" }]}
        icon={Users}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> All reps
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="h-3.5 w-3.5" /> New deal
            </Button>
          </>
        }
      />

      {/* KPI Row — custom CrmKpiCard with accent edge + secondary metric */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <CrmKpiCard
          label="Open Deals"
          value="284"
          secondary="$1.6M"
          secondaryLabel="Pipeline value"
          icon={Handshake}
          accent="primary"
          trend={{ value: 6.8, direction: "up", positive: true }}
        />
        <CrmKpiCard
          label="Win Rate"
          value="42.8%"
          secondary="62 / 145"
          secondaryLabel="Won / closed Q2"
          icon={Target}
          accent="success"
          trend={{ value: 3.2, direction: "up", positive: true }}
        />
        <CrmKpiCard
          label="Avg. Deal Size"
          value="$5,840"
          secondary="−$82"
          secondaryLabel="vs. last quarter"
          icon={DollarSign}
          accent="warning"
          trend={{ value: 1.4, direction: "down", positive: false }}
        />
        <CrmKpiCard
          label="Sales Cycle"
          value="18 days"
          secondary="−2 days"
          secondaryLabel="Faster than Q1"
          icon={Clock}
          accent="violet"
          trend={{ value: 2, direction: "down", positive: true }}
        />
      </div>

      {/* Pipeline overview + deals won/lost */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        {/* Horizontal pipeline visualization — distinct from ecommerce funnel */}
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Pipeline Overview
              </CardTitle>
              <CardDescription>
                {crmPipeline.reduce((s, x) => s + x.value, 0)} active deals ·{" "}
                <span className="font-medium text-foreground tabular-nums">${(totalPipelineValue / 1000).toFixed(0)}K weighted</span>
              </CardDescription>
            </div>
            <StatusBadge tone="primary" dot>Live</StatusBadge>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
              {crmPipeline.map((stage, i) => {
                const barHeight = Math.max(20, (stage.value / maxStageCount) * 100);
                const isLast = i === crmPipeline.length - 1;
                return (
                  <div key={stage.stage} className="relative">
                    {/* Connector chevron between stages (desktop only) */}
                    {!isLast && (
                      <div className="hidden sm:flex absolute top-7 -right-2.5 z-10 h-5 w-5 items-center justify-center text-muted-foreground/60">
                        <ChevronRight className="h-4 w-4" />
                      </div>
                    )}
                    <div className="rounded-lg border border-border bg-muted/30 p-3 h-full flex flex-col">
                      <div className="flex items-center gap-1.5 mb-2">
                        <span className="h-2 w-2 rounded-full shrink-0" style={{ background: stage.color }} />
                        <span className="text-xs font-medium text-foreground truncate">{stage.stage}</span>
                      </div>
                      <p className="text-2xl font-semibold tabular-nums tracking-tight">{stage.value}</p>
                      <p className="text-xs text-muted-foreground tabular-nums mt-0.5">
                        ${(stage.amount / 1000).toFixed(0)}K
                      </p>
                      {/* Vertical bar at bottom — distinct from ecommerce's horizontal funnel bars */}
                      <div className="mt-3 flex-1 flex items-end">
                        <div
                          className="w-full rounded-md transition-all duration-700 ease-out"
                          style={{ height: `${barHeight}px`, background: stage.color, opacity: 0.85 }}
                        />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1.5 tabular-nums">
                        {((stage.value / crmPipeline.reduce((s, x) => s + x.value, 0)) * 100).toFixed(0)}% of pipe
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Deals won/lost stacked bar */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Deal Outcomes</CardTitle>
            <CardDescription>Won vs lost vs open by month.</CardDescription>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={dealsByStage}
              xKey="month"
              series={[
                { key: "won", name: "Won", color: "var(--success)" },
                { key: "open", name: "Open", color: "var(--primary)" },
                { key: "lost", name: "Lost", color: "var(--destructive)" },
              ]}
              stacked
              height={260}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Won</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums">82</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Open</p>
                <p className="text-sm font-semibold text-primary tabular-nums">186</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Lost</p>
                <p className="text-sm font-semibold text-destructive tabular-nums">28</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent activities + Upcoming follow-ups */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Flame className="h-4 w-4 text-[color:var(--warning)]" />
                Recent Activity
              </CardTitle>
              <CardDescription>Latest rep actions across all accounts.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent>
            <ol className="relative">
              {/* Timeline vertical line */}
              <span className="absolute left-[15px] top-2 bottom-2 w-px bg-border" aria-hidden />
              {crmActivities.map((a, i) => {
                const cfg = activityConfig[a.type] ?? activityConfig.note;
                const Icon = cfg.icon;
                const isLast = i === crmActivities.length - 1;
                return (
                  <li
                    key={i}
                    className={cn(
                      "relative flex gap-3 pl-0 pr-1 py-2.5",
                      !isLast && "border-b border-border/60"
                    )}
                  >
                    <div
                      className={cn(
                        "relative z-10 grid place-items-center h-8 w-8 rounded-full ring-4 ring-card shrink-0",
                        cfg.ring
                      )}
                    >
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <div className="min-w-0 flex-1 pt-0.5">
                      <p className="text-sm font-medium text-foreground leading-snug">{a.title}</p>
                      <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                        <span className="inline-flex items-center gap-1">
                          <Users className="h-3 w-3" /> {a.owner}
                        </span>
                        <span className="opacity-40">·</span>
                        <span className="tabular-nums">{a.time}</span>
                        <span className="opacity-40">·</span>
                        <StatusBadge tone={cfg.tone} className="capitalize">{a.type}</StatusBadge>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ol>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-primary" />
              Upcoming Follow-ups
            </CardTitle>
            <CardDescription>Next 48 hours of scheduled outreach.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2.5">
            {upcomingFollowUps.map((f, i) => {
              const cfg = followUpConfig[f.type];
              const Icon = cfg.icon;
              return (
                <div
                  key={i}
                  className="group flex items-center gap-3 rounded-lg border border-border bg-muted/20 p-3 hover:bg-muted/40 hover:border-primary/30 transition-colors cursor-pointer"
                >
                  <div className={cn(
                    "grid place-items-center h-9 w-9 rounded-lg shrink-0",
                    f.type === "call" && "bg-primary/12 text-primary",
                    f.type === "meeting" && "bg-violet-500/12 text-violet-500",
                    f.type === "email" && "bg-[color:var(--info)]/12 text-[color:var(--info)]"
                  )}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground truncate">{f.customer}</p>
                    <p className="text-xs text-muted-foreground truncate">{f.contact} · {f.owner}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs font-medium text-foreground tabular-nums whitespace-nowrap">{f.time}</p>
                    <StatusBadge tone={cfg.tone} className="mt-0.5 capitalize">{f.type}</StatusBadge>
                  </div>
                </div>
              );
            })}
            <Button variant="outline" size="sm" className="w-full text-xs mt-2 gap-1">
              <CalendarClock className="h-3.5 w-3.5" /> Open calendar
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Top deals table — full width */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base">Top Open Deals</CardTitle>
            <CardDescription>Highest-value opportunities by weighted amount.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            All deals <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Company</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Value</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Stage</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Owner</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden lg:table-cell">Expected Close</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Probability</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {topDeals.map((d, i) => (
                  <tr key={i} className="hover:bg-muted/30 transition-colors cursor-pointer">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={d.logo}
                          alt={`${d.company} logo`}
                          className="h-9 w-9 rounded-lg object-cover bg-muted shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="font-medium text-foreground truncate">{d.company}</p>
                          <p className="text-xs text-muted-foreground">Deal #NX-{1000 + i}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold">${d.value.toLocaleString()}</td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <StatusBadge tone={d.stageTone} dot>{d.stage}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-7 w-7">
                          <AvatarImage src={d.owner.avatar} alt={d.owner.name} />
                          <AvatarFallback className="text-[10px]">
                            {d.owner.name.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground truncate">{d.owner.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground tabular-nums hidden lg:table-cell">
                      {d.closeDate}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <div className="hidden sm:block h-1.5 w-16 rounded-full bg-muted overflow-hidden">
                          <div
                            className={cn(
                              "h-full rounded-full transition-all duration-700 ease-out",
                              d.probability >= 75 ? "bg-[color:var(--success)]" : d.probability >= 50 ? "bg-primary" : "bg-[color:var(--warning)]"
                            )}
                            style={{ width: `${d.probability}%` }}
                          />
                        </div>
                        <span className={cn(
                          "text-xs font-semibold tabular-nums w-9 text-right",
                          d.probability >= 75 ? "text-[color:var(--success)]" : d.probability >= 50 ? "text-primary" : "text-[color:var(--warning)]"
                        )}>
                          {d.probability}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
