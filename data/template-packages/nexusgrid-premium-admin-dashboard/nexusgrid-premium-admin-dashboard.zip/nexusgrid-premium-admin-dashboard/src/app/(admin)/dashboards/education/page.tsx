"use client";

import * as React from "react";
import {
  GraduationCap,
  Users,
  BookOpen,
  CheckCircle2,
  Award,
  Filter,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Star,
  FileText,
  CalendarCheck,
  Clapperboard,
  PenLine,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BarTrendChart, DonutChart } from "@/components/charts";
import { courseEnrollment } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline education data ---------- */

// Grade distribution — A/B/C/D/F. Inline since not in shared mock.
const gradeDistribution = [
  { name: "A", value: 38, color: "var(--success)" },
  { name: "B", value: 32, color: "oklch(0.70 0.15 75)"  },
  { name: "C", value: 18, color: "var(--info)" },
  { name: "D", value: 8,  color: "var(--warning)" },
  { name: "F", value: 4,  color: "var(--destructive)" },
];

// Top performing courses — 5 entries (extends courseEnrollment with instructor + grade).
const topCourses = [
  { name: "Computer Science 101", instructor: "Dr. Sarah Chen",   avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", students: 248, completion: 78, grade: "A-", gradeTone: "success" as StatusTone },
  { name: "Design Systems",       instructor: "Prof. Elena Petrov",avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", students: 184, completion: 84, grade: "A",  gradeTone: "success" as StatusTone },
  { name: "Data Analytics",       instructor: "Dr. Marcus Reyes",  avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", students: 162, completion: 71, grade: "B+", gradeTone: "info"    as StatusTone },
  { name: "Marketing Strategy",   instructor: "Prof. Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", students: 128, completion: 88, grade: "A",  gradeTone: "success" as StatusTone },
  { name: "Product Management",   instructor: "Dr. James Okoro",   avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", students: 112, completion: 82, grade: "B+", gradeTone: "info"    as StatusTone },
];

// Student activity timeline — 5 entries.
type ActivityType = "submitted" | "attended" | "graded" | "enrolled";
const studentActivities: Array<{
  student: string; avatar: string; action: ActivityType; course: string; time: string;
}> = [
  { student: "Olivia Bennett", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", action: "submitted", course: "Computer Science 101", time: "12 min ago" },
  { student: "Ethan Wright",   avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", action: "attended",  course: "Design Systems",        time: "45 min ago" },
  { student: "Sophia Martinez",avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", action: "graded",    course: "Data Analytics",        time: "1 hr ago"   },
  { student: "Liam Anderson",  avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", action: "enrolled",  course: "Marketing Strategy",    time: "2 hr ago"   },
  { student: "Ava Thompson",   avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", action: "submitted", course: "Product Management",    time: "3 hr ago"   },
];

const activityConfig: Record<ActivityType, { icon: LucideIcon; tone: StatusTone; ring: string; verb: string }> = {
  submitted: { icon: FileText,      tone: "info",    ring: "bg-[color:var(--info)]/12 text-[color:var(--info)]",          verb: "submitted an assignment in"   },
  attended:  { icon: CalendarCheck, tone: "success", ring: "bg-[color:var(--success)]/12 text-[color:var(--success)]",  verb: "attended a session of"        },
  graded:    { icon: PenLine,       tone: "warning", ring: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",  verb: "was graded in"                },
  enrolled:  { icon: BookOpen,      tone: "primary", ring: "bg-primary/12 text-primary",                                verb: "enrolled in"                  },
};

// Instructor leaderboard — 5 entries.
const instructors = [
  { name: "Dr. Sarah Chen",    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", courses: 8, rating: 4.9, students: 1280 },
  { name: "Prof. Elena Petrov",avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", courses: 6, rating: 4.8, students: 980  },
  { name: "Dr. Marcus Reyes",  avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", courses: 7, rating: 4.7, students: 1120 },
  { name: "Prof. Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", courses: 5, rating: 4.8, students: 740  },
  { name: "Dr. James Okoro",   avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", courses: 4, rating: 4.6, students: 560  },
];

/* ---------- Education KPI card — scholarly / library-card feel ---------- */
// Distinct from all prior KPI cards:
// - Top "book spine shelf" decoration (a row of vertical strokes of varying heights,
//   like books on a shelf — distinct from HR's gradient strip, logistics' route line,
//   projects' sprint strip, healthcare's ECG line, marketing's blur blob)
// - Warm scholarly palette (amber / orange / yellow / rose)
// - "scholar chip" — a letter-style badge on the right of the value (grade letter,
//   % glyph, etc.) styled like a course mark
// - Bottom "bookmark" ribbon progress bar with completion caption

function ScholarCard({
  label,
  value,
  unit,
  chip,
  icon: Icon,
  accent,
  trend,
  trendLabel,
  completion,
  completionLabel,
}: {
  label: string;
  value: string;
  unit?: string;
  chip?: string;
  icon: LucideIcon;
  accent: "amber" | "orange" | "yellow" | "rose";
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  trendLabel: string;
  completion: number;
  completionLabel: string;
}) {
  // Static accent maps so Tailwind v4 can detect them
  const accentSpine: Record<string, string> = {
    amber:  "bg-amber-600",
    orange: "bg-orange-600",
    yellow: "bg-yellow-600",
    rose:   "bg-rose-700",
  };
  const accentTile: Record<string, string> = {
    amber:  "bg-amber-600/12 text-amber-700 dark:text-amber-400",
    orange: "bg-orange-600/12 text-orange-700 dark:text-orange-400",
    yellow: "bg-yellow-600/15 text-yellow-700 dark:text-yellow-400",
    rose:   "bg-rose-700/12 text-rose-700 dark:text-rose-400",
  };
  const accentChip: Record<string, string> = {
    amber:  "bg-amber-600/10 text-amber-700 dark:text-amber-400 ring-amber-600/20",
    orange: "bg-orange-600/10 text-orange-700 dark:text-orange-400 ring-orange-600/20",
    yellow: "bg-yellow-600/15 text-yellow-700 dark:text-yellow-400 ring-yellow-600/25",
    rose:   "bg-rose-700/10 text-rose-700 dark:text-rose-400 ring-rose-700/20",
  };
  const accentBar: Record<string, string> = {
    amber:  "from-amber-500 to-amber-700",
    orange: "from-orange-500 to-orange-700",
    yellow: "from-yellow-500 to-yellow-600",
    rose:   "from-rose-500 to-rose-700",
  };
  const accentText: Record<string, string> = {
    amber:  "text-amber-700 dark:text-amber-400",
    orange: "text-orange-700 dark:text-orange-400",
    yellow: "text-yellow-700 dark:text-yellow-400",
    rose:   "text-rose-700 dark:text-rose-400",
  };

  // "Book spine shelf" heights — 8 vertical strokes of varying heights
  const spineHeights = [55, 70, 45, 85, 60, 75, 50, 90];
  const isUp = trend.direction === "up";

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card transition-all hover:shadow-premium-sm">
      {/* Top "book spine shelf" decoration — a row of vertical book-spine strokes */}
      <div className="flex items-end gap-[3px] h-3 px-3 pt-1.5" aria-hidden>
        {spineHeights.map((h, i) => (
          <div
            key={i}
            className={cn("flex-1 rounded-sm", accentSpine[accent])}
            style={{ height: `${h}%`, opacity: 0.45 + (i % 3) * 0.15 }}
          />
        ))}
      </div>

      <div className="p-5 pt-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
              {label}
            </p>
            <div className="mt-1.5 flex items-baseline gap-1.5">
              <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
              {unit && <span className="text-sm font-semibold text-muted-foreground tabular-nums">{unit}</span>}
              {chip && (
                <span className={cn(
                  "ml-1 inline-flex items-center justify-center rounded-md px-1.5 py-0.5 text-xs font-bold ring-1 ring-inset tabular-nums",
                  accentChip[accent]
                )}>
                  {chip}
                </span>
              )}
            </div>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentTile[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>

        {/* Bookmark-ribbon completion bar — distinct from sparkline / quota / sprint / ECG / route */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1.5">
            <span className="truncate">{completionLabel}</span>
            <span className={cn("font-semibold tabular-nums shrink-0", accentText[accent])}>{completion}%</span>
          </div>
          <div className="relative h-1.5 w-full rounded-full bg-muted overflow-hidden">
            <div
              className={cn("h-full rounded-full bg-gradient-to-r transition-all duration-700 ease-out", accentBar[accent])}
              style={{ width: `${completion}%` }}
            />
          </div>
        </div>

        {/* Trend pill + caption */}
        <div className="mt-3 flex items-center gap-1.5">
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
              trend.positive
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {Math.abs(trend.value)}%
          </span>
          <span className="text-xs text-muted-foreground truncate">{trendLabel}</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function EducationDashboardPage() {
  const totalStudents = topCourses.reduce((s, c) => s + c.students, 0);
  const maxStudents = Math.max(...courseEnrollment.map((c) => c.students));

  return (
    <>
      <PageHeader
        title="Education Dashboard"
        description="Enrollment trends, course performance, and instructor impact across your institution."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Education" }]}
        icon={GraduationCap}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Fall 2026
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5 bg-amber-700 text-white hover:bg-amber-700/90">
              <Plus className="h-3.5 w-3.5" /> New course
            </Button>
          </>
        }
      />

      {/* KPI Row — ScholarCard with book-spine shelf + bookmark ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <ScholarCard
          label="Active Students"
          value="12,840"
          icon={Users}
          accent="amber"
          trend={{ value: 6.8, direction: "up", positive: true }}
          trendLabel="vs. last term"
          completion={84}
          completionLabel="84% retention rate"
        />
        <ScholarCard
          label="Courses"
          value="284"
          icon={BookOpen}
          accent="orange"
          trend={{ value: 4.2, direction: "up", positive: true }}
          trendLabel="12 new this term"
          completion={72}
          completionLabel="72% with active enrollment"
        />
        <ScholarCard
          label="Completion Rate"
          value="78"
          unit="%"
          chip="B+"
          icon={CheckCircle2}
          accent="yellow"
          trend={{ value: 3.4, direction: "up", positive: true }}
          trendLabel="vs. last term"
          completion={78}
          completionLabel="Target: 85%"
        />
        <ScholarCard
          label="Avg Grade"
          value="84"
          unit="%"
          chip="B+"
          icon={Award}
          accent="rose"
          trend={{ value: 1.8, direction: "up", positive: true }}
          trendLabel="cohort-wide GPA"
          completion={84}
          completionLabel="Above B+ threshold"
        />
      </div>

      {/* Course enrollment + Grade distribution */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-amber-700 dark:text-amber-400" />
                Course Enrollment
              </CardTitle>
              <CardDescription>
                Students per course · {totalStudents.toLocaleString()} total enrollments across {courseEnrollment.length} top courses.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-amber-600" /> Students
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={courseEnrollment}
              xKey="name"
              series={[
                { key: "students", name: "Students", color: "oklch(0.62 0.13 65)" },
              ]}
              horizontal
              height={280}
            />
            <div className="mt-3 grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Top Course</p>
                <p className="text-sm font-semibold text-amber-700 dark:text-amber-400 mt-0.5 truncate">CS 101</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total Students</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">{totalStudents.toLocaleString()}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Avg Completion</p>
                <p className="text-sm font-semibold text-orange-700 dark:text-orange-400 tabular-nums mt-0.5">
                  {Math.round(courseEnrollment.reduce((s, c) => s + c.completion, 0) / courseEnrollment.length)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Grade distribution donut */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Award className="h-4 w-4 text-rose-700 dark:text-rose-400" />
              Grade Distribution
            </CardTitle>
            <CardDescription>Final grades issued this term.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={gradeDistribution}
              centerLabel="Avg Grade"
              centerValue="B+"
              height={210}
            />
            <div className="mt-3 space-y-1.5 pt-3 border-t border-border">
              {gradeDistribution.map((g) => (
                <div key={g.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="h-2 w-2 rounded-full shrink-0" style={{ background: g.color }} />
                    <span className="text-muted-foreground">Grade {g.name}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="font-medium tabular-nums">{g.value}%</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top performing courses table — full width */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Award className="h-4 w-4 text-amber-700 dark:text-amber-400" />
              Top Performing Courses
            </CardTitle>
            <CardDescription>By enrollment and completion this term.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            All courses <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Course</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Instructor</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Students</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell w-[28%]">Completion</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Avg Grade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {topCourses.map((c, i) => (
                  <tr key={i} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="grid place-items-center h-9 w-9 rounded-lg bg-amber-600/10 text-amber-700 dark:text-amber-400 shrink-0">
                          <BookOpen className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium text-foreground truncate">{c.name}</p>
                          <p className="text-xs text-muted-foreground sm:hidden truncate">{c.instructor}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <div className="flex items-center gap-2 min-w-0">
                        <Avatar className="h-7 w-7 shrink-0">
                          <AvatarImage src={c.avatar} alt={c.instructor} />
                          <AvatarFallback className="text-[10px]">
                            {c.instructor.replace(/^(Dr\.|Prof\.)\s/, "").split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-muted-foreground truncate">{c.instructor}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-medium text-foreground">{c.students}</td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                          <div
                            className={cn(
                              "h-full rounded-full transition-all duration-700 ease-out",
                              c.completion >= 85 ? "bg-[color:var(--success)]" : c.completion >= 75 ? "bg-amber-600" : "bg-[color:var(--warning)]"
                            )}
                            style={{ width: `${c.completion}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold tabular-nums w-9 text-right shrink-0">{c.completion}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <StatusBadge tone={c.gradeTone} className="font-bold">{c.grade}</StatusBadge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Student activity timeline + Instructor leaderboard */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Student activity timeline */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Clapperboard className="h-4 w-4 text-amber-700 dark:text-amber-400" />
                Student Activity
              </CardTitle>
              <CardDescription>Latest actions across your courses.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent>
            <ol className="relative">
              {/* Timeline vertical line */}
              <span className="absolute left-[19px] top-2 bottom-2 w-px bg-border" aria-hidden />
              {studentActivities.map((a, i) => {
                const cfg = activityConfig[a.action];
                const Icon = cfg.icon;
                const isLast = i === studentActivities.length - 1;
                return (
                  <li
                    key={i}
                    className={cn(
                      "relative flex gap-3 pl-0 pr-1 py-2.5",
                      !isLast && "border-b border-border/60"
                    )}
                  >
                    <div className="relative z-10 shrink-0">
                      <Avatar className="h-10 w-10 ring-2 ring-card">
                        <AvatarImage src={a.avatar} alt={a.student} />
                        <AvatarFallback className="text-[10px]">
                          {a.student.split(" ").map((n) => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className={cn(
                        "absolute -bottom-1 -right-1 grid place-items-center h-5 w-5 rounded-full ring-2 ring-card",
                        cfg.ring
                      )}>
                        <Icon className="h-2.5 w-2.5" />
                      </div>
                    </div>
                    <div className="min-w-0 flex-1 pt-0.5">
                      <p className="text-sm leading-snug">
                        <span className="font-medium text-foreground">{a.student}</span>{" "}
                        <span className="text-muted-foreground">{cfg.verb}</span>{" "}
                        <span className="font-medium text-foreground">{a.course}</span>
                      </p>
                      <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                        <span className="tabular-nums">{a.time}</span>
                        <span className="opacity-40">·</span>
                        <StatusBadge tone={cfg.tone} className="capitalize">{a.action}</StatusBadge>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ol>
          </CardContent>
        </Card>

        {/* Instructor leaderboard */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Star className="h-4 w-4 text-amber-700 dark:text-amber-400" />
                Instructor Leaderboard
              </CardTitle>
              <CardDescription>Top-rated faculty this term.</CardDescription>
            </div>
            <StatusBadge tone="warning" dot>Term rank</StatusBadge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-10">#</th>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Instructor</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Courses</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Rating</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Students</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {instructors.map((ins, i) => (
                    <tr key={i} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <span className={cn(
                          "inline-grid place-items-center h-6 w-6 rounded-md text-xs font-bold tabular-nums",
                          i === 0 && "bg-amber-500/15 text-amber-700 dark:text-amber-400 ring-1 ring-inset ring-amber-500/25",
                          i === 1 && "bg-orange-500/15 text-orange-700 dark:text-orange-400 ring-1 ring-inset ring-orange-500/25",
                          i === 2 && "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400 ring-1 ring-inset ring-yellow-500/25",
                          i > 2 && "bg-muted text-muted-foreground"
                        )}>
                          {i + 1}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Avatar className="h-8 w-8 shrink-0">
                            <AvatarImage src={ins.avatar} alt={ins.name} />
                            <AvatarFallback className="text-[10px]">
                              {ins.name.replace(/^(Dr\.|Prof\.)\s/, "").split(" ").map((n) => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="font-medium text-foreground truncate">{ins.name}</p>
                            <p className="text-xs text-muted-foreground sm:hidden tabular-nums">
                              {ins.courses} courses · {ins.rating} ★
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums text-foreground hidden sm:table-cell">{ins.courses}</td>
                      <td className="px-4 py-3 text-right">
                        <span className="inline-flex items-center gap-1 text-xs font-semibold tabular-nums text-amber-700 dark:text-amber-400">
                          <Star className="h-3 w-3 fill-current" />
                          {ins.rating}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted-foreground hidden md:table-cell">
                        {ins.students.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
