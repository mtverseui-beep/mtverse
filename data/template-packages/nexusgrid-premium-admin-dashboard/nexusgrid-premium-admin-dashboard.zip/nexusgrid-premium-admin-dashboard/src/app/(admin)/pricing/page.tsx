"use client";

import * as React from "react";
import {
  CreditCard,
  Check,
  X,
  Sparkles,
  Rocket,
  Zap,
  Building2,
  Shield,
  ArrowRight,
  HelpCircle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Plan = {
  id: string;
  name: string;
  icon: React.ElementType;
  tone: "neutral" | "primary" | "violet" | "warning";
  tagline: string;
  monthly: number;
  annual: number;
  features: string[];
  cta: string;
  popular?: boolean;
};

const PLANS: Plan[] = [
  {
    id: "free",
    name: "Free",
    icon: Sparkles,
    tone: "neutral",
    tagline: "For individuals exploring the platform.",
    monthly: 0,
    annual: 0,
    features: [
      "Up to 3 projects",
      "1 GB storage",
      "Community support",
      "Basic analytics",
      "7-day history",
    ],
    cta: "Start for free",
  },
  {
    id: "starter",
    name: "Starter",
    icon: Rocket,
    tone: "primary",
    tagline: "For freelancers and small teams.",
    monthly: 29,
    annual: 23,
    features: [
      "Up to 10 projects",
      "25 GB storage",
      "Email support (24h SLA)",
      "Advanced analytics",
      "90-day history",
      "Custom branding",
    ],
    cta: "Get Starter",
  },
  {
    id: "pro",
    name: "Pro",
    icon: Zap,
    tone: "violet",
    tagline: "For growing teams that need scale.",
    monthly: 99,
    annual: 79,
    features: [
      "Unlimited projects",
      "250 GB storage",
      "Priority support (4h SLA)",
      "Real-time analytics",
      "1-year history",
      "SSO & SAML",
      "Audit logs",
      "API access",
    ],
    cta: "Get Pro",
    popular: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    icon: Building2,
    tone: "warning",
    tagline: "For organizations with custom needs.",
    monthly: 0,
    annual: 0,
    features: [
      "Everything in Pro",
      "Unlimited storage",
      "Dedicated CSM",
      "99.99% uptime SLA",
      "Custom contracts",
      "On-prem option",
      "SOC 2 Type II",
    ],
    cta: "Contact sales",
  },
];

const COMPARISON_ROWS: { section: string; label: string; values: (string | boolean)[] }[] = [
  { section: "Core", label: "Projects", values: ["3", "10", "Unlimited", "Unlimited"] },
  { section: "Core", label: "Storage", values: ["1 GB", "25 GB", "250 GB", "Unlimited"] },
  { section: "Core", label: "Team members", values: ["1", "5", "20", "Unlimited"] },
  { section: "Core", label: "API calls / month", values: ["1K", "25K", "500K", "Custom"] },
  { section: "Analytics", label: "Basic dashboards", values: [true, true, true, true] },
  { section: "Analytics", label: "Real-time analytics", values: [false, false, true, true] },
  { section: "Analytics", label: "Custom reports", values: [false, true, true, true] },
  { section: "Analytics", label: "Data export", values: [false, true, true, true] },
  { section: "Security", label: "Two-factor auth", values: [true, true, true, true] },
  { section: "Security", label: "SSO & SAML", values: [false, false, true, true] },
  { section: "Security", label: "Audit logs", values: [false, false, true, true] },
  { section: "Security", label: "SOC 2 report", values: [false, false, false, true] },
  { section: "Support", label: "Community", values: [true, true, true, true] },
  { section: "Support", label: "Email support", values: [false, true, true, true] },
  { section: "Support", label: "Priority support", values: [false, false, true, true] },
  { section: "Support", label: "Dedicated CSM", values: [false, false, false, true] },
];

const FAQS = [
  {
    q: "Can I change plans at any time?",
    a: "Yes. You can upgrade or downgrade at any moment. Upgrades take effect immediately and we prorate the difference. Downgrades take effect at the end of your current billing cycle so you keep paid features for the period you've already paid for.",
  },
  {
    q: "What payment methods do you accept?",
    a: "We accept all major credit cards (Visa, Mastercard, American Express, Discover), ACH transfers for annual plans, and wire transfer for Enterprise contracts. Invoicing is available for Pro and Enterprise customers on annual billing.",
  },
  {
    q: "Is there a free trial for paid plans?",
    a: "Yes — Starter and Pro both come with a 14-day free trial. No credit card is required to start, and you can cancel anytime during the trial without being charged. Enterprise customers can request an extended evaluation period through sales.",
  },
  {
    q: "What happens when I hit my plan limits?",
    a: "We'll notify you by email when you reach 80% of any limit. If you exceed a soft limit, we won't cut off service — we'll reach out to discuss upgrading. Hard limits (like API rate caps) return a 429 status with a Retry-After header so you can implement backoff.",
  },
];

const toneRing: Record<string, string> = {
  neutral: "ring-border",
  primary: "ring-primary/40",
  violet: "ring-violet-500/40",
  warning: "ring-[color:var(--warning)]/40",
};

const toneIconBg: Record<string, string> = {
  neutral: "bg-muted text-muted-foreground",
  primary: "bg-primary/12 text-primary",
  violet: "bg-violet-500/12 text-violet-500",
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
};

export default function PricingPage() {
  const [cycle, setCycle] = React.useState<"monthly" | "annual">("monthly");

  return (
    <>
      <PageHeader
        title="Pricing"
        description="Simple, transparent pricing for teams of every size. No hidden fees, cancel anytime."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Pricing" }]}
        icon={CreditCard}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Sales team notified", { description: "We'll be in touch within one business day." })}>
            <Shield className="h-3.5 w-3.5" /> Talk to sales
          </Button>
        }
      />

      {/* BILLING CYCLE TOGGLE */}
      <div className="flex items-center justify-center mb-8">
        <div className="inline-flex items-center gap-1 p-1 rounded-full border border-border bg-card">
          <button
            type="button"
            onClick={() => setCycle("monthly")}
            className={cn(
              "px-5 py-2 rounded-full text-sm font-medium transition-all",
              cycle === "monthly" ? "bg-primary text-primary-foreground shadow-premium-xs" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Monthly
          </button>
          <button
            type="button"
            onClick={() => setCycle("annual")}
            className={cn(
              "px-5 py-2 rounded-full text-sm font-medium transition-all inline-flex items-center gap-2",
              cycle === "annual" ? "bg-primary text-primary-foreground shadow-premium-xs" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Annual
            <Badge variant="outline" className="text-[10px] py-0 h-4.5 px-1.5 border-[color:var(--success)]/40 text-[color:var(--success)] bg-[color:var(--success)]/5">Save 20%</Badge>
          </button>
        </div>
      </div>

      {/* PLAN CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 mb-12">
        {PLANS.map((p) => (
          <Card
            key={p.id}
            className={cn(
              "relative flex flex-col p-6 transition-all",
              p.popular ? `ring-2 ${toneRing[p.tone]} border-transparent shadow-premium-md` : "hover:shadow-premium-sm"
            )}
          >
            {p.popular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <Badge className="text-[10px] gap-1 bg-violet-500 text-white hover:bg-violet-500">
                  <Sparkles className="h-2.5 w-2.5" /> Most popular
                </Badge>
              </div>
            )}
            <div className="flex items-center gap-3 mb-4">
              <div className={cn("grid place-items-center h-11 w-11 rounded-xl", toneIconBg[p.tone])}>
                <p.icon className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-semibold">{p.name}</h3>
                <p className="text-[11px] text-muted-foreground line-clamp-1">{p.tagline}</p>
              </div>
            </div>

            <div className="mb-5">
              {p.id === "free" ? (
                <>
                  <p className="text-4xl font-semibold tabular-nums">$0<span className="text-lg text-muted-foreground font-normal">/mo</span></p>
                  <p className="text-[11px] text-muted-foreground mt-1">Free forever</p>
                </>
              ) : p.id === "enterprise" ? (
                <>
                  <p className="text-4xl font-semibold">Custom</p>
                  <p className="text-[11px] text-muted-foreground mt-1">Annual contracts</p>
                </>
              ) : (
                <>
                  <p className="text-4xl font-semibold tabular-nums">
                    ${cycle === "monthly" ? p.monthly : p.annual}
                    <span className="text-lg text-muted-foreground font-normal">/mo</span>
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-1">
                    {cycle === "annual" ? `Billed annually · $${(p.annual * 12).toLocaleString()}/yr` : "Billed monthly"}
                    {cycle === "annual" && (
                      <span className="text-[color:var(--success)] font-medium ml-1">· Save 20%</span>
                    )}
                  </p>
                </>
              )}
            </div>

            <Separator className="mb-4" />

            <ul className="space-y-2.5 flex-1 mb-5">
              {p.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <span className={cn("grid place-items-center h-4 w-4 rounded-full mt-0.5 shrink-0", p.popular ? "bg-violet-500/15 text-violet-500" : "bg-[color:var(--success)]/12 text-[color:var(--success)]")}>
                    <Check className="h-2.5 w-2.5" strokeWidth={3} />
                  </span>
                  <span className="text-foreground/90">{f}</span>
                </li>
              ))}
            </ul>

            <Button
              variant={p.popular ? "default" : "outline"}
              className="w-full gap-1.5"
              onClick={() => {
                if (p.id === "enterprise") toast.success("Sales team notified", { description: "We'll be in touch within one business day." });
                else toast.success(`Starting ${p.name} trial`, { description: "Check your email for next steps." });
              }}
            >
              {p.id === "enterprise" && <Shield className="h-4 w-4" />}
              {p.cta}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Card>
        ))}
      </div>

      {/* COMPARISON TABLE */}
      <Card className="mb-12">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Compare every feature</CardTitle>
          <CardDescription>A detailed breakdown of what's included in each plan.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-y border-border bg-muted/40">
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-3.5 min-w-[240px]">Feature</th>
                  {PLANS.map((p) => (
                    <th key={p.id} className="px-4 py-3.5 text-center min-w-[120px]">
                      <div className="flex flex-col items-center gap-1.5">
                        <p.icon className={cn("h-4 w-4", p.tone === "primary" ? "text-primary" : p.tone === "violet" ? "text-violet-500" : p.tone === "warning" ? "text-[color:var(--warning)]" : "text-muted-foreground")} />
                        <span className="text-xs font-semibold">{p.name}</span>
                        {p.popular && <StatusBadge tone="violet">Popular</StatusBadge>}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COMPARISON_ROWS.map((row, idx) => {
                  const showSection = idx === 0 || COMPARISON_ROWS[idx - 1].section !== row.section;
                  return (
                    <React.Fragment key={row.label}>
                      {showSection && (
                        <tr className="bg-muted/20">
                          <td colSpan={5} className="px-4 py-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                            {row.section}
                          </td>
                        </tr>
                      )}
                      <tr className="border-b border-border last:border-b-0 hover:bg-muted/20 transition-colors">
                        <td className="px-4 py-3 font-medium">{row.label}</td>
                        {row.values.map((v, i) => (
                          <td key={i} className="px-4 py-3 text-center">
                            {typeof v === "boolean" ? (
                              v ? <Check className="h-4 w-4 text-[color:var(--success)] mx-auto" /> : <X className="h-4 w-4 text-muted-foreground/30 mx-auto" />
                            ) : (
                              <span className="text-sm tabular-nums">{v}</span>
                            )}
                          </td>
                        ))}
                      </tr>
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* FAQ */}
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground mb-2">
            <HelpCircle className="h-3.5 w-3.5" /> FAQ
          </div>
          <h2 className="text-2xl font-semibold tracking-tight">Questions about pricing?</h2>
          <p className="text-sm text-muted-foreground mt-1">Everything you need to know before choosing a plan.</p>
        </div>
        <Card>
          <CardContent className="p-0">
            <Accordion type="single" collapsible className="px-6">
              {FAQS.map((faq, i) => (
                <AccordionItem key={i} value={`item-${i}`}>
                  <AccordionTrigger className="text-sm font-medium hover:no-underline">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground leading-relaxed">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-3">Still have questions?</p>
          <Button variant="outline" className="gap-1.5" asChild>
            <a href="/contact-support">
              Contact support <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </>
  );
}
