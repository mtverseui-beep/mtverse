"use client";

import * as React from "react";
import {
  MessageCircle,
  Calendar as CalendarIcon,
  Bell,
  Settings,
  Filter,
  User,
  Mail,
  Palette,
  Smile,
  AtSign,
  Hash,
  Bold,
  Italic,
  Link2,
  Clock,
  MapPin,
  Bookmark,
  Tag,
  Star,
  Heart,
  ThumbsUp,
  PartyPopper,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar } from "@/components/ui/calendar";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

export default function PopoversPage() {
  const [date, setDate] = React.useState<Date | undefined>(new Date(2026, 6, 15));
  const [palette, setPalette] = React.useState("#6366f1");
  const [notifications, setNotifications] = React.useState(3);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Popovers"
        description="Rich floating panels anchored to a trigger — all sides, forms, menus and calendar pickers."
        icon={MessageCircle}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/popovers" },
          { label: "Popovers" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Popover spec copied")}>
            <Sparkles /> Spec sheet
          </Button>
        }
      />

      {/* All sides */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">All four sides</CardTitle>
          <CardDescription>
            Popovers can be anchored top, right, bottom or left of the trigger with alignment options.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-6">
            {(["top", "right", "bottom", "left"] as const).map((side) => (
              <Popover key={side}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full capitalize">{side}</Button>
                </PopoverTrigger>
                <PopoverContent side={side} className="w-64">
                  <div className="space-y-2">
                    <p className="text-sm font-semibold capitalize">{side} popover</p>
                    <p className="text-xs text-muted-foreground">
                      Anchored to the {side} of the trigger. Popovers are richer than tooltips — they can host
                      forms, menus, calendars and any interactive content.
                    </p>
                  </div>
                </PopoverContent>
              </Popover>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* With rich content */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Notification popover</CardTitle>
            <CardDescription>
              Rich menu with header, scrollable list and footer action.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Bell /> Notifications
                  {notifications > 0 && (
                    <Badge className="bg-destructive text-white h-4 px-1 text-[10px]">{notifications}</Badge>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-80 p-0">
                <div className="flex items-center justify-between p-3 border-b">
                  <p className="text-sm font-semibold">Notifications</p>
                  <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => { setNotifications(0); toast.success("All marked as read"); }}>
                    Mark all read
                  </Button>
                </div>
                <div className="max-h-72 overflow-y-auto">
                  {[
                    { icon: AtSign, tone: "primary", title: "Priya Shah mentioned you", body: "in PR #1284 — \"could you take a look at the auth flow?\"", time: "2m ago", unread: true },
                    { icon: PartyPopper, tone: "success", title: "Release 4.2.0 shipped", body: "18 PRs merged. View the changelog for details.", time: "1h ago", unread: true },
                    { icon: Tag, tone: "info", title: "Tagged in Acme Corp", body: "You were tagged in the Acme Corp customer record.", time: "3h ago", unread: true },
                    { icon: Bookmark, tone: "violet", title: "Saved filter shared", body: "Devon shared a filter \"High-value churn risks\" with you.", time: "Yesterday", unread: false },
                  ].map((n, i) => (
                    <div key={i} className={cn("flex items-start gap-2.5 p-3 border-b last:border-b-0 hover:bg-accent", n.unread && "bg-primary/5")}>
                      <div
                        className={cn(
                          "grid h-8 w-8 shrink-0 place-items-center rounded-lg",
                          n.tone === "primary" && "bg-primary/15 text-primary",
                          n.tone === "success" && "bg-[color:var(--success)]/15 text-[color:var(--success)]",
                          n.tone === "info" && "bg-[color:var(--info)]/15 text-[color:var(--info)]",
                          n.tone === "violet" && "bg-violet-500/15 text-violet-500"
                        )}
                      >
                        <n.icon className="h-3.5 w-3.5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium">{n.title}</p>
                        <p className="text-xs text-muted-foreground line-clamp-2">{n.body}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{n.time}</p>
                      </div>
                      {n.unread && <span className="mt-1 h-2 w-2 rounded-full bg-primary shrink-0" />}
                    </div>
                  ))}
                </div>
                <div className="p-2 border-t">
                  <Button variant="ghost" size="sm" className="w-full" onClick={() => toast.message("Notification center opened")}>
                    View all notifications
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">User card popover</CardTitle>
            <CardDescription>
              Hover-card style detail popover with avatar, role and quick actions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" alt="Devon Park" />
                    <AvatarFallback>DP</AvatarFallback>
                  </Avatar>
                  Devon Park
                </Button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-72 p-0">
                <div className="h-16 bg-gradient-to-r from-primary/30 via-violet-500/20 to-amber-500/20 rounded-t-md" />
                <div className="px-4 pb-4 -mt-8">
                  <Avatar className="h-14 w-14 ring-4 ring-popover">
                    <AvatarImage src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop" alt="Devon Park" />
                    <AvatarFallback>DP</AvatarFallback>
                  </Avatar>
                  <div className="mt-2">
                    <p className="font-semibold">Devon Park</p>
                    <p className="text-sm text-muted-foreground">Engineering Lead · London</p>
                    <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                      <Mail className="h-3 w-3" /> devon@nexusgrid.io
                    </p>
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                    {[
                      { label: "PRs", value: "184" },
                      { label: "Reviews", value: "392" },
                      { label: "Repos", value: "27" },
                    ].map((s) => (
                      <div key={s.label} className="rounded-md border bg-muted/30 p-1.5">
                        <p className="text-sm font-semibold">{s.value}</p>
                        <p className="text-[10px] text-muted-foreground">{s.label}</p>
                      </div>
                    ))}
                  </div>
                  <Separator className="my-3" />
                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1" onClick={() => toast.success("Message sent to Devon")}>
                      <Mail /> Message
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => toast.message("Following Devon")}>
                      Follow
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </CardContent>
        </Card>
      </div>

      {/* Form popovers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Form popovers</CardTitle>
          <CardDescription>
            Popovers that host form inputs — quick add, comment, filter and configure.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          {/* Quick comment */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline"><MessageCircle /> Quick comment</Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-80">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold flex-1">Add a comment</p>
                  <Badge variant="secondary" className="text-[10px]">Visible to team</Badge>
                </div>
                <Textarea placeholder="Type your comment… @ to mention, # to link an issue" rows={4} />
                <div className="flex items-center gap-1">
                  {[Bold, Italic, Link2, AtSign, Hash, Smile].map((Icon, i) => (
                    <Button key={i} variant="ghost" size="icon" className="h-7 w-7" aria-label="format">
                      <Icon className="h-3.5 w-3.5" />
                    </Button>
                  ))}
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" size="sm">Cancel</Button>
                  <Button size="sm" onClick={() => toast.success("Comment posted")}>Comment</Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Filter popover */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline"><Filter /> Filter</Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-72">
              <div className="space-y-3">
                <p className="text-sm font-semibold">Filter customers</p>
                <div className="space-y-1.5">
                  <Label className="text-xs">Status</Label>
                  <div className="flex flex-wrap gap-1">
                    {["Active", "Trial", "Past due", "Churned"].map((s, i) => (
                      <Badge key={s} variant={i === 0 ? "default" : "outline"} className="cursor-pointer">{s}</Badge>
                    ))}
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Plan</Label>
                  <div className="flex flex-wrap gap-1">
                    {["Starter", "Pro", "Enterprise"].map((s, i) => (
                      <Badge key={s} variant={i === 1 ? "default" : "outline"} className="cursor-pointer">{s}</Badge>
                    ))}
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Monthly spend</Label>
                  <div className="flex gap-2">
                    <Input type="number" placeholder="Min" defaultValue={0} className="h-8" />
                    <Input type="number" placeholder="Max" defaultValue={5000} className="h-8" />
                  </div>
                </div>
                <Separator />
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => toast.message("Filters cleared")}>Clear</Button>
                  <Button size="sm" onClick={() => toast.success("Filters applied")}>Apply</Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Color palette */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="gap-2">
                <span className="h-4 w-4 rounded-full border" style={{ background: palette }} />
                <Palette /> Accent color
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-64">
              <div className="space-y-3">
                <p className="text-sm font-semibold">Pick accent color</p>
                <div className="grid grid-cols-6 gap-2">
                  {["#6366f1", "#8b5cf6", "#ec4899", "#f43f5e", "#f59e0b", "#10b981", "#06b6d4", "#3b82f6", "#84cc16", "#eab308", "#a855f7", "#64748b"].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => { setPalette(c); toast.success(`Accent set to ${c}`); }}
                      className={cn(
                        "h-8 w-8 rounded-md border-2 transition-transform hover:scale-110",
                        palette === c ? "border-foreground" : "border-transparent"
                      )}
                      style={{ background: c }}
                      aria-label={`Pick color ${c}`}
                    />
                  ))}
                </div>
                <Separator />
                <div className="space-y-1.5">
                  <Label className="text-xs">Custom hex</Label>
                  <Input value={palette} onChange={(e) => setPalette(e.target.value)} className="h-8 font-mono" />
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Settings popover */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline"><Settings /> Quick settings</Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-72">
              <div className="space-y-3">
                <p className="text-sm font-semibold">Quick settings</p>
                {[
                  { label: "Compact mode", on: false, icon: Filter },
                  { label: "Show avatars", on: true, icon: User },
                  { label: "Email digest", on: true, icon: Mail },
                  { label: "Sound effects", on: false, icon: Bell },
                ].map((s) => (
                  <label key={s.label} className="flex items-center justify-between cursor-pointer">
                    <span className="text-sm flex items-center gap-2">
                      <s.icon className="h-3.5 w-3.5 text-muted-foreground" />
                      {s.label}
                    </span>
                    <input type="checkbox" defaultChecked={s.on} className="h-4 w-4 accent-primary" />
                  </label>
                ))}
                <Separator />
                <Button variant="outline" size="sm" className="w-full" onClick={() => toast.message("All settings opened")}>
                  Open all settings
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </CardContent>
      </Card>

      {/* Calendar popover */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Calendar picker popover</CardTitle>
          <CardDescription>
            The most common popover use case — embed the Calendar component for date selection.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          {/* Single date */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start gap-2 font-normal">
                <CalendarIcon />
                {date ? format(date, "PPP") : "Pick a date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-auto p-0">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                captionLayout="dropdown-labels"
              />
              <div className="flex items-center justify-between border-t p-2 text-xs">
                <span className="text-muted-foreground">{date ? format(date, "EEEE, MMMM d, yyyy") : "No date"}</span>
                <Button size="sm" variant="ghost" onClick={() => toast.success(`Date set: ${date ? format(date, "yyyy-MM-dd") : "—"}`)}>
                  Done
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          {/* Time + place popover */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-start gap-2 font-normal">
                <Clock /> 14:30 — Standup with design team
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-72">
              <div className="space-y-3">
                <p className="text-sm font-semibold">Edit meeting</p>
                <div className="space-y-1.5">
                  <Label className="text-xs">Title</Label>
                  <Input defaultValue="Standup with design team" className="h-8" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs">Date</Label>
                    <Input defaultValue="2026-07-15" className="h-8" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Time</Label>
                    <Input defaultValue="14:30" className="h-8" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Location</Label>
                  <div className="relative">
                    <MapPin className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                    <Input defaultValue="Google Meet" className="h-8 pl-8" />
                  </div>
                </div>
                <Separator />
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" size="sm">Cancel</Button>
                  <Button size="sm" onClick={() => toast.success("Meeting saved")}>Save</Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </CardContent>
      </Card>

      {/* Reaction popover */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Emoji reaction popover</CardTitle>
          <CardDescription>
            Quick emoji picker — demonstrates a popover with a grid of selectable items.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline"><Smile /> React to comment</Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-72">
              <div className="space-y-3">
                <p className="text-sm font-semibold">Pick a reaction</p>
                <div className="grid grid-cols-6 gap-1">
                  {[
                    { icon: ThumbsUp, label: "Thumbs up", color: "text-[color:var(--info)]" },
                    { icon: Heart, label: "Heart", color: "text-rose-500" },
                    { icon: Star, label: "Star", color: "text-amber-500" },
                    { icon: PartyPopper, label: "Party", color: "text-violet-500" },
                    { icon: Smile, label: "Smile", color: "text-[color:var(--warning)]" },
                    { icon: Bookmark, label: "Bookmark", color: "text-[color:var(--success)]" },
                  ].map((r) => (
                    <button
                      key={r.label}
                      type="button"
                      onClick={() => toast.success(`Reacted with ${r.label}`)}
                      className={cn(
                        "grid h-9 w-9 place-items-center rounded-md hover:bg-accent transition-colors",
                        r.color
                      )}
                      aria-label={r.label}
                    >
                      <r.icon className="h-4 w-4" />
                    </button>
                  ))}
                </div>
                <Separator />
                <p className="text-[10px] text-muted-foreground">Recently used reactions appear here</p>
              </div>
            </PopoverContent>
          </Popover>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Popovers page · 4 sides · notifications · user card · forms · calendar · reactions
      </p>
    </div>
  );
}
