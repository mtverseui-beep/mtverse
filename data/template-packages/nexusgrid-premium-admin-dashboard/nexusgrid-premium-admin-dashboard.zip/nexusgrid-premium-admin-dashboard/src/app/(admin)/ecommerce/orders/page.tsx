"use client";

import * as React from "react";
import {
  ShoppingCart,
  Download,
  Plus,
  CheckCircle2,
  Clock,
  RotateCcw,
  Truck,
  MoreHorizontal,
  Eye,
  Printer,
  Mail,
  Copy,
  Trash2,
  CheckCheck,
  X,
  User,
  Package,
  CreditCard,
  CalendarDays,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { KpiCard, Sparkline } from "@/components/common/kpi-card";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";

type OrderStatus = "completed" | "processing" | "shipped" | "pending" | "cancelled" | "refunded";
type PaymentStatus = "paid" | "pending" | "refunded" | "failed";

type Order = {
  id: string;
  customer: string;
  email: string;
  avatar: string;
  date: string;
  items: number;
  total: number;
  payment: PaymentStatus;
  status: OrderStatus;
};

const orders: Order[] = [
  { id: "NX-3948", customer: "Sarah Chen", email: "sarah.chen@example.com", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", date: "2026-07-01", items: 3, total: 428.50, payment: "paid", status: "completed" },
  { id: "NX-3947", customer: "Marcus Reyes", email: "marcus.r@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", date: "2026-07-01", items: 1, total: 186.00, payment: "paid", status: "processing" },
  { id: "NX-3946", customer: "Elena Petrov", email: "elena.petrov@example.com", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", date: "2026-06-30", items: 5, total: 742.25, payment: "paid", status: "shipped" },
  { id: "NX-3945", customer: "James Okoro", email: "j.okoro@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", date: "2026-06-30", items: 2, total: 96.99, payment: "refunded", status: "refunded" },
  { id: "NX-3944", customer: "Aiko Tanaka", email: "aiko.t@example.com", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", date: "2026-06-30", items: 2, total: 312.00, payment: "pending", status: "pending" },
  { id: "NX-3943", customer: "David Kim", email: "d.kim@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", date: "2026-06-29", items: 4, total: 528.75, payment: "paid", status: "completed" },
  { id: "NX-3942", customer: "Lena Hoffmann", email: "lena.h@example.com", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", date: "2026-06-29", items: 1, total: 144.50, payment: "refunded", status: "cancelled" },
  { id: "NX-3941", customer: "Raj Patel", email: "raj.patel@example.com", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", date: "2026-06-29", items: 6, total: 1248.00, payment: "paid", status: "completed" },
  { id: "NX-3940", customer: "Mei Lin", email: "mei.lin@example.com", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", date: "2026-06-28", items: 3, total: 287.40, payment: "paid", status: "shipped" },
  { id: "NX-3939", customer: "Carlos Mendez", email: "c.mendez@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", date: "2026-06-28", items: 2, total: 178.20, payment: "pending", status: "pending" },
  { id: "NX-3938", customer: "Priya Sharma", email: "priya.s@example.com", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", date: "2026-06-27", items: 8, total: 1840.00, payment: "paid", status: "completed" },
  { id: "NX-3937", customer: "Noah Williams", email: "noah.w@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", date: "2026-06-27", items: 1, total: 89.99, payment: "failed", status: "cancelled" },
  { id: "NX-3936", customer: "Sofia Rossi", email: "sofia.rossi@example.com", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", date: "2026-06-26", items: 4, total: 612.30, payment: "paid", status: "completed" },
  { id: "NX-3935", customer: "Ahmed Hassan", email: "ahmed.h@example.com", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", date: "2026-06-26", items: 2, total: 245.00, payment: "paid", status: "processing" },
  { id: "NX-3934", customer: "Yuki Sato", email: "yuki.sato@example.com", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", date: "2026-06-25", items: 3, total: 398.75, payment: "paid", status: "shipped" },
  { id: "NX-3933", customer: "Olivia Bennett", email: "olivia.b@example.com", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", date: "2026-06-25", items: 5, total: 824.50, payment: "paid", status: "completed" },
  { id: "NX-3932", customer: "Lucas Moreau", email: "lucas.m@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", date: "2026-06-24", items: 1, total: 119.00, payment: "pending", status: "pending" },
  { id: "NX-3931", customer: "Isabella Costa", email: "i.costa@example.com", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", date: "2026-06-24", items: 7, total: 1428.00, payment: "paid", status: "completed" },
  { id: "NX-3930", customer: "Ethan Wright", email: "ethan.w@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", date: "2026-06-23", items: 2, total: 168.45, payment: "refunded", status: "refunded" },
  { id: "NX-3929", customer: "Charlotte Klein", email: "c.klein@example.com", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", date: "2026-06-23", items: 3, total: 354.20, payment: "paid", status: "shipped" },
  { id: "NX-3928", customer: "Daniel Foster", email: "d.foster@example.com", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", date: "2026-06-22", items: 4, total: 489.90, payment: "paid", status: "processing" },
  { id: "NX-3927", customer: "Amara Okafor", email: "amara.o@example.com", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", date: "2026-06-22", items: 2, total: 198.00, payment: "paid", status: "completed" },
];

const statusToneMap: Record<OrderStatus, "success" | "info" | "primary" | "warning" | "danger" | "neutral"> = {
  completed: "success",
  processing: "info",
  shipped: "primary",
  pending: "warning",
  cancelled: "danger",
  refunded: "neutral",
};

const paymentToneMap: Record<PaymentStatus, "success" | "warning" | "neutral" | "danger"> = {
  paid: "success",
  pending: "warning",
  refunded: "neutral",
  failed: "danger",
};

const orderTrend = [240, 268, 252, 284, 312, 298, 326, 318, 342, 364, 352, 388];
const pendingTrend = [42, 48, 38, 52, 46, 58, 49, 62, 54, 48, 41, 36];
const completedTrend = [186, 202, 196, 218, 240, 224, 252, 244, 268, 290, 286, 318];
const refundedTrend = [8, 6, 9, 7, 12, 10, 8, 11, 7, 9, 6, 8];

export default function OrdersPage() {
  const [createOpen, setCreateOpen] = React.useState(false);
  const [dateFilter, setDateFilter] = React.useState("30d");

  const columns: Column<Order>[] = React.useMemo(() => [
    {
      key: "id",
      header: "Order ID",
      sortable: true,
      sortAccessor: (r) => r.id,
      cell: (r) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            toast.message(`Opening order ${r.id} detail`);
          }}
          className="font-mono text-xs font-semibold text-primary hover:underline"
        >
          {r.id}
        </button>
      ),
      width: "w-28",
    },
    {
      key: "customer",
      header: "Customer",
      sortable: true,
      sortAccessor: (r) => r.customer,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <Avatar className="h-8 w-8">
            <AvatarImage src={r.avatar} alt={r.customer} />
            <AvatarFallback className="text-xs">{r.customer.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="font-medium text-foreground text-sm truncate">{r.customer}</p>
            <p className="text-xs text-muted-foreground truncate">{r.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: "date",
      header: "Date",
      sortable: true,
      sortAccessor: (r) => r.date,
      cell: (r) => <span className="font-mono text-xs text-muted-foreground">{r.date}</span>,
      width: "w-32",
    },
    {
      key: "items",
      header: "Items",
      sortable: true,
      sortAccessor: (r) => r.items,
      align: "right",
      cell: (r) => <span className="tabular-nums">{r.items}</span>,
      width: "w-20",
    },
    {
      key: "total",
      header: "Total",
      sortable: true,
      sortAccessor: (r) => r.total,
      align: "right",
      cell: (r) => <span className="tabular-nums font-medium">${r.total.toFixed(2)}</span>,
      width: "w-28",
    },
    {
      key: "payment",
      header: "Payment",
      sortable: true,
      sortAccessor: (r) => r.payment,
      filterable: true,
      filterAccessor: (r) => r.payment,
      filterOptions: [
        { label: "Paid", value: "paid" },
        { label: "Pending", value: "pending" },
        { label: "Refunded", value: "refunded" },
        { label: "Failed", value: "failed" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={paymentToneMap[r.payment]} dot className="capitalize">{r.payment}</StatusBadge>
      ),
      width: "w-28",
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Completed", value: "completed" },
        { label: "Processing", value: "processing" },
        { label: "Shipped", value: "shipped" },
        { label: "Pending", value: "pending" },
        { label: "Cancelled", value: "cancelled" },
        { label: "Refunded", value: "refunded" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={statusToneMap[r.status]} dot className="capitalize">{r.status}</StatusBadge>
      ),
      width: "w-32",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div onClick={(e) => e.stopPropagation()}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel className="text-xs">{r.id}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening order ${r.id} detail`)}>
                <Eye className="h-3.5 w-3.5" /> View details
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Invoice for ${r.id} sent to ${r.email}`)}>
                <Mail className="h-3.5 w-3.5" /> Email invoice
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Print dialog opened for ${r.id}`)}>
                <Printer className="h-3.5 w-3.5" /> Print
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Copied ${r.id} to clipboard`)}>
                <Copy className="h-3.5 w-3.5" /> Copy order ID
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`Cancelled order ${r.id}`)}>
                <Trash2 className="h-3.5 w-3.5" /> Cancel order
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      width: "w-16",
    },
  ], []);

  return (
    <>
      <PageHeader
        title="Orders"
        description="Manage and fulfill customer orders across all sales channels."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Orders" }]}
        icon={ShoppingCart}
        actions={
          <>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="h-9 w-[150px] text-xs gap-1.5">
                <CalendarDays className="h-3.5 w-3.5" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="ytd">Year to date</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Orders exported as CSV")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => setCreateOpen(true)}>
              <Plus className="h-3.5 w-3.5" /> Create Order
            </Button>
          </>
        }
      />

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Total Orders"
          value="3,284"
          icon={ShoppingCart}
          accent="primary"
          trend={{ value: 8.2, direction: "up" }}
          hint="vs last month"
          sparkline={<Sparkline data={orderTrend} color="var(--primary)" />}
        />
        <KpiCard
          label="Pending"
          value="142"
          icon={Clock}
          accent="warning"
          trend={{ value: 4.6, direction: "down", positive: true }}
          hint="awaiting fulfillment"
          sparkline={<Sparkline data={pendingTrend} color="var(--warning)" />}
        />
        <KpiCard
          label="Completed"
          value="2,894"
          icon={CheckCircle2}
          accent="success"
          trend={{ value: 11.4, direction: "up" }}
          hint="88% completion rate"
          sparkline={<Sparkline data={completedTrend} color="var(--success)" />}
        />
        <KpiCard
          label="Refunded"
          value="86"
          icon={RotateCcw}
          accent="destructive"
          trend={{ value: 1.2, direction: "down", positive: true }}
          hint="2.6% refund rate"
          sparkline={<Sparkline data={refundedTrend} color="var(--destructive)" />}
        />
      </div>

      {/* Orders DataTable */}
      <DataTable
        title="All Orders"
        data={orders}
        columns={columns}
        searchKeys={["id", "customer", "email"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening order ${r.id} detail`)}
        enableSelection
        enableExport
        enableDensity
        enableColumnVisibility
        pageSize={10}
        initialSort={{ key: "date", direction: "desc" }}
        bulkActions={[
          {
            label: "Mark completed",
            icon: CheckCheck,
            onClick: (sel) => toast.success(`Marked ${sel.length} order${sel.length > 1 ? "s" : ""} as completed`),
          },
          {
            label: "Export selected",
            icon: Download,
            onClick: (sel) => toast.success(`Exported ${sel.length} order${sel.length > 1 ? "s" : ""} as CSV`),
          },
          {
            label: "Delete",
            icon: Trash2,
            onClick: (sel) => toast.error(`Cancelled ${sel.length} order${sel.length > 1 ? "s" : ""}`),
          },
        ]}
        toolbarActions={
          <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={() => setCreateOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> <span className="hidden sm:inline">New</span>
          </Button>
        }
      />

      {/* Create Order Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-[520px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingCart className="h-4 w-4 text-primary" /> Create New Order
            </DialogTitle>
            <DialogDescription>
              Manually create an order for a customer. Items can be added after creation.
            </DialogDescription>
          </DialogHeader>
          <form
            className="grid gap-4 py-2"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const name = String(fd.get("customer") || "").trim();
              if (!name) {
                toast.error("Customer name is required");
                return;
              }
              toast.success(`Order created for ${name}`);
              setCreateOpen(false);
              (e.target as HTMLFormElement).reset();
            }}
          >
            <div className="grid gap-2">
              <Label htmlFor="customer" className="text-xs flex items-center gap-1.5">
                <User className="h-3.5 w-3.5 text-muted-foreground" /> Customer
              </Label>
              <Input id="customer" name="customer" placeholder="Sarah Chen" className="h-9" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="email" className="text-xs flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-muted-foreground" /> Email
                </Label>
                <Input id="email" name="email" type="email" placeholder="sarah@example.com" className="h-9" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="items" className="text-xs flex items-center gap-1.5">
                  <Package className="h-3.5 w-3.5 text-muted-foreground" /> Items
                </Label>
                <Input id="items" name="items" type="number" min={1} defaultValue={1} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="total" className="text-xs flex items-center gap-1.5">
                  <CreditCard className="h-3.5 w-3.5 text-muted-foreground" /> Total ($)
                </Label>
                <Input id="total" name="total" type="number" step="0.01" min={0} defaultValue={0} className="h-9" />
              </div>
              <div className="grid gap-2">
                <Label className="text-xs">Status</Label>
                <Select defaultValue="pending" name="status">
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setCreateOpen(false)}>
                <X className="h-3.5 w-3.5 mr-1" /> Cancel
              </Button>
              <Button type="submit" size="sm" className="gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Create Order
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Bottom insight cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Avg. Order Value</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">$96.42</p>
                <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1.5">
                  <ArrowUpRight className="h-3 w-3" /> +2.4% vs last month
                </p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary">
                <TrendingUp className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Shipments In Transit</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">218</p>
                <p className="text-xs text-[color:var(--info)] inline-flex items-center gap-0.5 mt-1.5">
                  <Truck className="h-3 w-3" /> 12 arriving today
                </p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
                <Truck className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Cancellation Rate</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">1.8%</p>
                <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1.5">
                  <ArrowDownRight className="h-3 w-3" /> −0.3% vs last month
                </p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-destructive/12 text-destructive">
                <X className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
