"use client";

import * as React from "react";
import {
  MousePointerClick,
  Plus,
  Trash2,
  Download,
  Mail,
  ChevronDown,
  ChevronRight,
  Loader2,
  Search,
  Settings,
  ArrowRight,
  Heart,
  Star,
  Github,
  Apple,
  Chrome,
  Eye,
  Copy,
  Save,
  Edit3,
  Filter,
  Check,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function Section({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent className="flex flex-wrap items-center gap-3">
        {children}
      </CardContent>
    </Card>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-xs font-medium text-muted-foreground mr-1 min-w-[64px]">
      {children}
    </span>
  );
}

export default function ButtonsPage() {
  const [loading, setLoading] = React.useState(false);

  const simulateLoading = () => {
    setLoading(true);
    toast.info("Processing payment…");
    setTimeout(() => {
      setLoading(false);
      toast.success("Payment of $1,290.00 captured successfully.");
    }, 2200);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Buttons"
        description="Triggers for actions across the dashboard — six variants, four sizes, loading and social patterns."
        icon={MousePointerClick}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/buttons" },
          { label: "Buttons" },
        ]}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => toast.message("Button spec sheet opened")}>
              <Copy /> Spec sheet
            </Button>
            <Button size="sm" onClick={() => toast.success("Saved to your component library")}>
              <Save /> Save preset
            </Button>
          </>
        }
      />

      <Section
        title="Variants"
        description="Six semantic styles covering primary, secondary, destructive, outline, ghost and link actions."
      >
        <Button onClick={() => toast.success("Primary action triggered")}>Primary</Button>
        <Button variant="secondary" onClick={() => toast.message("Secondary action")}>
          Secondary
        </Button>
        <Button variant="destructive" onClick={() => toast.error("Row deleted permanently")}>
          <Trash2 /> Delete
        </Button>
        <Button variant="outline" onClick={() => toast.message("Outline action")}>
          Outline
        </Button>
        <Button variant="ghost" onClick={() => toast.message("Ghost action")}>
          Ghost
        </Button>
        <Button variant="link" onClick={() => toast.message("Link action")}>
          Link button
        </Button>
      </Section>

      <Section
        title="Sizes"
        description="Four sizes from compact icon buttons through large CTA buttons."
      >
        <div className="flex items-center gap-3">
          <Label>Small</Label>
          <Button size="sm">Small</Button>
        </div>
        <div className="flex items-center gap-3">
          <Label>Default</Label>
          <Button size="default">Default</Button>
        </div>
        <div className="flex items-center gap-3">
          <Label>Large</Label>
          <Button size="lg">Large</Button>
        </div>
        <div className="flex items-center gap-3">
          <Label>Icon</Label>
          <Button size="icon" aria-label="Search">
            <Search />
          </Button>
        </div>
      </Section>

      <Section
        title="With icons"
        description="Icons can lead, trail, or stand alone inside a button."
      >
        <Button>
          <Plus /> New project
        </Button>
        <Button variant="outline">
          Continue <ArrowRight />
        </Button>
        <Button variant="secondary">
          <Filter /> Filter results
        </Button>
        <Button variant="outline" size="icon" aria-label="Settings">
          <Settings />
        </Button>
        <Button variant="ghost" size="icon" aria-label="Favorite">
          <Heart />
        </Button>
        <Button variant="outline" size="sm">
          <Star /> Star
        </Button>
      </Section>

      <Section
        title="Loading & disabled"
        description="Loading buttons show a spinner; disabled buttons are visually and functionally inert."
      >
        <Button disabled>
          <Loader2 className="animate-spin" /> Saving
        </Button>
        <Button variant="secondary" disabled>
          <Loader2 className="animate-spin" /> Syncing data
        </Button>
        <Button onClick={simulateLoading} disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="animate-spin" /> Processing…
            </>
          ) : (
            <>
              <Check /> Capture payment
            </>
          )}
        </Button>
        <Button disabled>Disabled</Button>
        <Button variant="outline" disabled>
          <Mail /> Send invite
        </Button>
        <Button variant="ghost" disabled>
          Cancel
        </Button>
      </Section>

      <Section
        title="Groups & split buttons"
        description="Cluster related actions; split buttons separate a default action from a secondary menu."
      >
        <div className="inline-flex rounded-md border overflow-hidden">
          <Button variant="ghost" className="rounded-r-none border-r">
            <Edit3 /> Edit
          </Button>
          <Button variant="ghost" className="rounded-none border-r">
            <Copy /> Duplicate
          </Button>
          <Button variant="ghost" className="rounded-l-none">
            <Trash2 /> Delete
          </Button>
        </div>

        <div className="inline-flex rounded-md border overflow-hidden">
          <Button variant="outline" className="rounded-r-none">
            <Download /> Export CSV
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="rounded-l-none border-l-0" aria-label="Export format">
                <ChevronDown />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Export format</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => toast.success("Exported as CSV")}>
                <Download /> Comma-separated (CSV)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Exported as JSON")}>
                <Download /> JSON
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Exported as XLSX")}>
                <Download /> Excel workbook
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast.success("Exported as PDF")}>
                <Download /> PDF report
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="inline-flex rounded-md border overflow-hidden">
          <Button variant="secondary" className="rounded-r-none">
            <Mail /> Email
          </Button>
          <Button variant="secondary" className="rounded-none border-l border-r">
            <Eye /> Preview
          </Button>
          <Button variant="secondary" className="rounded-l-none">
            <ChevronRight />
          </Button>
        </div>
      </Section>

      <Section
        title="Social sign-in"
        description="Brand-neutral social auth buttons using outline + ghost variants and lucide brand icons."
      >
        <Button variant="outline" onClick={() => toast.info("Redirecting to Google…")}>
          <Chrome className="text-rose-500" /> Continue with Google
        </Button>
        <Button variant="outline" onClick={() => toast.info("Redirecting to GitHub…")}>
          <Github /> Continue with GitHub
        </Button>
        <Button variant="outline" onClick={() => toast.info("Redirecting to Apple…")}>
          <Apple /> Continue with Apple
        </Button>
        <Button variant="ghost" onClick={() => toast.info("Redirecting to Google…")}>
          <Chrome /> Google
        </Button>
        <Button variant="ghost" onClick={() => toast.info("Redirecting to GitHub…")}>
          <Github /> GitHub
        </Button>
        <Button variant="ghost" onClick={() => toast.info("Redirecting to Apple…")}>
          <Apple /> Apple
        </Button>
        <Button size="icon" variant="outline" aria-label="Google">
          <Chrome className="text-rose-500" />
        </Button>
        <Button size="icon" variant="outline" aria-label="GitHub">
          <Github />
        </Button>
        <Button size="icon" variant="outline" aria-label="Apple">
          <Apple />
        </Button>
      </Section>

      <Section
        title="Icon button wall"
        description="Icon-only buttons use the `icon` size and require an accessible label."
      >
        {[
          { icon: Plus, label: "Add" },
          { icon: Edit3, label: "Edit" },
          { icon: Trash2, label: "Delete" },
          { icon: Copy, label: "Copy" },
          { icon: Save, label: "Save" },
          { icon: Search, label: "Search" },
          { icon: Settings, label: "Settings" },
          { icon: Filter, label: "Filter" },
          { icon: Mail, label: "Mail" },
          { icon: Heart, label: "Favorite" },
          { icon: Star, label: "Star" },
          { icon: Eye, label: "View" },
        ].map(({ icon: Icon, label }) => (
          <Button
            key={label}
            size="icon"
            variant="outline"
            aria-label={label}
            onClick={() => toast.message(`${label} button clicked`)}
          >
            <Icon />
          </Button>
        ))}
      </Section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Block & CTA buttons</CardTitle>
            <CardDescription>
              Full-width buttons for call-to-action banners, modals and footers.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" size="lg" onClick={() => toast.success("Welcome aboard!")}>
              <Plus /> Create your workspace
            </Button>
            <Button className="w-full" variant="outline" size="lg" onClick={() => toast.message("Tour resumed")}>
              Take the product tour
            </Button>
            <Button className="w-full" variant="secondary" size="lg" onClick={() => toast.message("Schedule opened")}>
              <Mail /> Book a demo with sales
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Toggle + checkbox menu</CardTitle>
            <CardDescription>
              A dropdown with checkbox items that toggle workspace preferences.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="w-full justify-between">
                  Workspace filters <ChevronDown />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64">
                <DropdownMenuLabel>Visible columns</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuCheckboxItem checked>Owner</DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem checked>Members</DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem checked>Plan</DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem>Status</DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem>Created date</DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem>Monthly spend</DropdownMenuCheckboxItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => toast.success("Filters applied")}>
                  <Check /> Apply filters
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Separator className="my-4" />
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">Owner: enabled</Badge>
              <Badge variant="secondary">Members: enabled</Badge>
              <Badge variant="outline">Plan: hidden</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Buttons page · 6 variants · 4 sizes · loading + social patterns · split + group compositions
      </p>
    </div>
  );
}
