"use client";

import * as React from "react";
import {
  Percent,
  Plus,
  Ticket,
  Gift,
  TrendingUp,
  Download,
  MoreHorizontal,
  Copy,
  Pencil,
  Trash2,
  CalendarDays,
  CheckCircle2,
  XCircle,
  Clock,
  Tag,
  DollarSign,
  Receipt,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type CouponType = "percentage" | "fixed" | "free-shipping";
type CouponStatus = "active" | "expired" | "scheduled" | "disabled";

type Coupon = {
  id: string;
  code: string;
  description: string;
  type: CouponType;
  value: number; // percentage or $ off
  usageLimit: number;
  used: number;
  status: CouponStatus;
  validFrom: string;
  validTo: string;
  revenueImpact: number;
};

const coupons: Coupon[] = [
  { id: "CPN-01", code: "WELCOME20", description: "20% off first order for new customers", type: "percentage", value: 20, usageLimit: 5000, used: 3842, status: "active", validFrom: "2026-01-01", validTo: "2026-12-31", revenueImpact: 84200 },
  { id: "CPN-02", code: "SUMMER50", description: "$50 off orders above $250", type: "fixed", value: 50, usageLimit: 1000, used: 824, status: "active", validFrom: "2026-06-01", validTo: "2026-08-31", revenueImpact: 124800 },
  { id: "CPN-03", code: "FREESHIP", description: "Free shipping on any order", type: "free-shipping", value: 0, usageLimit: 10000, used: 6218, status: "active", validFrom: "2026-01-01", validTo: "2026-12-31", revenueImpact: 48200 },
  { id: "CPN-04", code: "VIP15", description: "15% off for VIP customers only", type: "percentage", value: 15, usageLimit: 2000, used: 486, status: "active", validFrom: "2026-04-01", validTo: "2026-12-31", revenueImpact: 32600 },
  { id: "CPN-05", code: "FLASH24", description: "24-hour flash sale, 30% off", type: "percentage", value: 30, usageLimit: 500, used: 500, status: "expired", validFrom: "2026-06-20", validTo: "2026-06-21", revenueImpact: 28400 },
  { id: "CPN-06", code: "BACK2SCHOOL", description: "Back to school — $25 off backpacks", type: "fixed", value: 25, usageLimit: 800, used: 142, status: "scheduled", validFrom: "2026-08-15", validTo: "2026-09-15", revenueImpact: 0 },
  { id: "CPN-07", code: "BFCM2025", description: "Black Friday 40% off everything", type: "percentage", value: 40, usageLimit: 5000, used: 4892, status: "expired", validFrom: "2025-11-28", validTo: "2025-12-01", revenueImpact: 284600 },
  { id: "CPN-08", code: "REFER10", description: "$10 credit for referred friend", type: "fixed", value: 10, usageLimit: 2000, used: 1284, status: "active", validFrom: "2026-02-01", validTo: "2026-12-31", revenueImpact: 18400 },
  { id: "CPN-09", code: "NEWSLETTER", description: "15% off when subscribing to newsletter", type: "percentage", value: 15, usageLimit: 99999, used: 4820, status: "active", validFrom: "2026-01-01", validTo: "2026-12-31", revenueImpact: 62800 },
  { id: "CPN-10", code: "WINTER25", description: "Winter sale 25% off select items", type: "percentage", value: 25, usageLimit: 1500, used: 0, status: "scheduled", validFrom: "2026-12-01", validTo: "2026-12-31", revenueImpact: 0 },
  { id: "CPN-11", code: "ABANDONED10", description: "10% off recovery for abandoned carts", type: "percentage", value: 10, usageLimit: 3000, used: 412, status: "active", validFrom: "2026-03-01", validTo: "2026-12-31", revenueImpact: 14200 },
  { id: "CPN-12", code: "LOYALTY100", description: "$100 off for 5+ year customers", type: "fixed", value: 100, usageLimit: 200, used: 84, status: "active", validFrom: "2026-05-01", validTo: "2026-12-31", revenueImpact: 22400 },
];

const statusToneMap: Record<CouponStatus, "success" | "neutral" | "info" | "danger"> = {
  active: "success",
  expired: "neutral",
  scheduled: "info",
  disabled: "danger",
};

const typeIconMap: Record<CouponType, React.ComponentType<{ className?: string }>> = {
  percentage: Percent,
  fixed: DollarSign,
  "free-shipping": Gift,
};

// Coupon-style KPI card — code-tag motif
function CouponKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  trend,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "info" | "success" | "warning";
  trend: string;
}) {
  const accentMap = {
    primary: "bg-primary/10 text-primary",
    info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  const trendColor = {
    primary: "text-primary",
    info: "text-[color:var(--info)]",
    success: "text-[color:var(--success)]",
    warning: "text-[color:var(--warning)]",
  };
  return (
    <Card className="relative overflow-hidden">
      {/* perforated ticket edge decoration */}
      <div className="absolute top-0 bottom-0 left-0 w-1.5 flex flex-col justify-around items-center py-2 bg-muted/40 border-r border-dashed border-border">
        {Array.from({ length: 8 }).map((_, i) => (
          <span key={i} className="h-1 w-1 rounded-full bg-muted-foreground/30" />
        ))}
      </div>
      <CardContent className="pt-5 pb-4 pl-6">
        <div className="flex items-start justify-between mb-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
          <div className={cn("grid place-items-center h-8 w-8 rounded-lg shrink-0", accentMap[accent])}>
            <Icon className="h-4 w-4" />
          </div>
        </div>
        <p className="text-2xl font-semibold tabular-nums">{value}</p>
        <p className="text-xs text-muted-foreground mt-1">{hint}</p>
        <p className={cn("text-xs font-medium mt-2 inline-flex items-center gap-0.5", trendColor[accent])}>
          <TrendingUp className="h-3 w-3" /> {trend}
        </p>
      </CardContent>
    </Card>
  );
}

export default function CouponsPage() {
  const [createOpen, setCreateOpen] = React.useState(false);

  const columns: Column<Coupon>[] = React.useMemo(() => [
    {
      key: "code",
      header: "Code",
      sortable: true,
      sortAccessor: (r) => r.code,
      cell: (r) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigator.clipboard?.writeText(r.code);
            toast.success(`Copied ${r.code} to clipboard`);
          }}
          className="inline-flex items-center gap-1.5 font-mono text-xs font-semibold text-primary bg-primary/8 px-2 py-1 rounded hover:bg-primary/15 transition-colors"
        >
          {r.code}
          <Copy className="h-3 w-3 opacity-60" />
        </button>
      ),
      width: "w-32",
    },
    {
      key: "description",
      header: "Description",
      sortable: true,
      sortAccessor: (r) => r.description,
      cell: (r) => (
        <span className="text-sm text-foreground line-clamp-1">{r.description}</span>
      ),
    },
    {
      key: "type",
      header: "Type",
      sortable: true,
      sortAccessor: (r) => r.type,
      filterable: true,
      filterAccessor: (r) => r.type,
      filterOptions: [
        { label: "Percentage", value: "percentage" },
        { label: "Fixed Amount", value: "fixed" },
        { label: "Free Shipping", value: "free-shipping" },
      ],
      cell: (r) => {
        const Icon = typeIconMap[r.type];
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground capitalize">
            <Icon className="h-3.5 w-3.5" />
            {r.type.replace("-", " ")}
          </span>
        );
      },
      width: "w-36",
    },
    {
      key: "value",
      header: "Value",
      sortable: true,
      sortAccessor: (r) => r.value,
      align: "right",
      cell: (r) => (
        <span className="text-sm font-semibold tabular-nums">
          {r.type === "percentage" ? `${r.value}%` : r.type === "fixed" ? `$${r.value}` : "Free"}
        </span>
      ),
      width: "w-20",
    },
    {
      key: "used",
      header: "Usage",
      sortable: true,
      sortAccessor: (r) => r.used,
      cell: (r) => {
        const pct = r.usageLimit > 0 ? Math.min(100, (r.used / r.usageLimit) * 100) : 0;
        return (
          <div className="min-w-[120px]">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="tabular-nums font-medium">{r.used.toLocaleString()}</span>
              <span className="tabular-nums text-muted-foreground">/ {r.usageLimit.toLocaleString()}</span>
            </div>
            <Progress value={pct} className="h-1.5" />
          </div>
        );
      },
      width: "w-36",
    },
    {
      key: "revenueImpact",
      header: "Revenue",
      sortable: true,
      sortAccessor: (r) => r.revenueImpact,
      align: "right",
      cell: (r) => (
        <span className="text-sm font-medium tabular-nums text-[color:var(--success)]">
          ${r.revenueImpact.toLocaleString()}
        </span>
      ),
      width: "w-28",
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "Active", value: "active" },
        { label: "Scheduled", value: "scheduled" },
        { label: "Expired", value: "expired" },
        { label: "Disabled", value: "disabled" },
      ],
      align: "center",
      cell: (r) => {
        const Icon = r.status === "active" ? CheckCircle2 : r.status === "scheduled" ? Clock : r.status === "expired" ? XCircle : XCircle;
        return (
          <StatusBadge tone={statusToneMap[r.status]} dot className="capitalize">
            <Icon className="h-3 w-3" /> {r.status}
          </StatusBadge>
        );
      },
      width: "w-32",
    },
    {
      key: "validity",
      header: "Validity",
      cell: (r) => (
        <div className="text-xs text-muted-foreground font-mono">
          <div>{r.validFrom}</div>
          <div className="opacity-60">→ {r.validTo}</div>
        </div>
      ),
      width: "w-32",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div onClick={(e) => e.stopPropagation()}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel className="text-xs font-mono">{r.code}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Copied ${r.code}`)}>
                <Copy className="h-3.5 w-3.5" /> Copy code
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Editing ${r.code}`)}>
                <Pencil className="h-3.5 w-3.5" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`${r.code} ${r.status === "active" ? "disabled" : "enabled"}`)}>
                <XCircle className="h-3.5 w-3.5" /> {r.status === "active" ? "Disable" : "Enable"}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`Deleted ${r.code}`)}>
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      width: "w-16",
    },
  ], []);

  return (
    <>
      <PageHeader
        title="Coupons"
        description="Create and manage discount codes, track redemptions, and measure revenue impact."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Ecommerce" }, { label: "Coupons" }]}
        icon={Percent}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Coupons exported")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => setCreateOpen(true)}>
              <Plus className="h-3.5 w-3.5" /> Create Coupon
            </Button>
          </>
        }
      />

      {/* Coupon KPI cards — ticket/perforated-edge motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <CouponKpi label="Active Coupons" value="8" hint="2 scheduled, 2 expired" icon={Ticket} accent="primary" trend="+2 this month" />
        <CouponKpi label="Total Redemptions" value="24,820" hint="across all coupons" icon={Receipt} accent="info" trend="+18.4% vs last month" />
        <CouponKpi label="Revenue Impact" value="$712K" hint="attributed to discounts" icon={TrendingUp} accent="success" trend="+12.6% vs last month" />
        <CouponKpi label="Avg Discount" value="18.2%" hint="across all redemptions" icon={Tag} accent="warning" trend="−1.4% (margin up)" />
      </div>

      {/* Coupons DataTable */}
      <DataTable
        title="All Coupons"
        data={coupons}
        columns={columns}
        searchKeys={["code", "description"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening coupon ${r.code} detail`)}
        pageSize={10}
        enableExport
        enableDensity
        enableColumnVisibility
        initialSort={{ key: "used", direction: "desc" }}
      />

      {/* Create Coupon Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-[540px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Ticket className="h-4 w-4 text-primary" /> Create New Coupon
            </DialogTitle>
            <DialogDescription>
              Define a discount code, its rules, and validity window.
            </DialogDescription>
          </DialogHeader>
          <form
            className="grid gap-4 py-2"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const code = String(fd.get("code") || "").trim().toUpperCase();
              if (!code) {
                toast.error("Coupon code is required");
                return;
              }
              toast.success(`Coupon ${code} created`);
              setCreateOpen(false);
              (e.target as HTMLFormElement).reset();
            }}
          >
            <div className="grid gap-2">
              <Label htmlFor="code" className="text-xs flex items-center gap-1.5">
                <Tag className="h-3.5 w-3.5 text-muted-foreground" /> Coupon Code
              </Label>
              <Input id="code" name="code" placeholder="SUMMER20" className="h-9 font-mono uppercase" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="desc" className="text-xs">Description</Label>
              <Input id="desc" name="desc" placeholder="20% off summer collection" className="h-9" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label className="text-xs">Discount Type</Label>
                <Select defaultValue="percentage" name="type">
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage off</SelectItem>
                    <SelectItem value="fixed">Fixed amount off</SelectItem>
                    <SelectItem value="free-shipping">Free shipping</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="value" className="text-xs">Value</Label>
                <Input id="value" name="value" type="number" min={0} defaultValue={10} className="h-9" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="limit" className="text-xs flex items-center gap-1.5">
                  <Receipt className="h-3.5 w-3.5 text-muted-foreground" /> Usage Limit
                </Label>
                <Input id="limit" name="limit" type="number" min={1} defaultValue={1000} className="h-9" />
              </div>
              <div className="grid gap-2">
                <Label className="text-xs flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" /> Status
                </Label>
                <Select defaultValue="active" name="status">
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="disabled">Disabled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="from" className="text-xs">Valid From</Label>
                <Input id="from" name="from" type="date" defaultValue="2026-07-01" className="h-9" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="to" className="text-xs">Valid To</Label>
                <Input id="to" name="to" type="date" defaultValue="2026-12-31" className="h-9" />
              </div>
            </div>
            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setCreateOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" className="gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Create Coupon
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
