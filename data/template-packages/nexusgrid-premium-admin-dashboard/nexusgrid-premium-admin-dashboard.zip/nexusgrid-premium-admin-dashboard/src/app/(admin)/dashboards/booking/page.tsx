"use client";

import * as React from "react";
import {
  CalendarDays,
  CalendarCheck,
  DollarSign,
  Ban,
  Gauge,
  Filter,
  Download,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Sparkles,
  User,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BarTrendChart, DonutChart } from "@/components/charts";
import { bookings, weekdays } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline booking data ---------- */

// Weekly booking pattern — bookings per day of week (Mon–Sun) with peak hour.
const weeklyBookings = [
  { day: "Mon", bookings: 64, peakHour: "14:00" },
  { day: "Tue", bookings: 78, peakHour: "11:00" },
  { day: "Wed", bookings: 92, peakHour: "14:00" },
  { day: "Thu", bookings: 88, peakHour: "15:00" },
  { day: "Fri", bookings: 96, peakHour: "16:00" },
  { day: "Sat", bookings: 72, peakHour: "10:00" },
  { day: "Sun", bookings: 48, peakHour: "11:00" },
];

// Service utilization — 5 categories.
const serviceUtilization = [
  { name: "Spa",      value: 28, color: "oklch(0.62 0.20 320)" },
  { name: "Fitness",  value: 22, color: "oklch(0.65 0.18 165)" },
  { name: "Meeting",  value: 24, color: "oklch(0.62 0.13 250)" },
  { name: "Class",    value: 16, color: "oklch(0.70 0.15 75)"  },
  { name: "Therapy",  value: 10, color: "oklch(0.62 0.18 25)"  },
];

// Booking status tone map.
const bookingStatusTone: Record<string, StatusTone> = {
  confirmed:  "info",
  pending:    "warning",
  completed:  "success",
  cancelled:  "danger",
};

// Upcoming reservations — 5 entries.
const upcomingReservations = [
  { customer: "Olivia Bennett", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", service: "Spa Day Package",     time: "Today · 16:00", status: "confirmed", statusTone: "info"   as StatusTone },
  { customer: "Ethan Wright",   avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", service: "Personal Training",  time: "Today · 17:30", status: "confirmed", statusTone: "info"   as StatusTone },
  { customer: "Sophia Martinez",avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", service: "Conference Room A",   time: "Today · 18:00", status: "pending",   statusTone: "warning" as StatusTone },
  { customer: "Liam Anderson",  avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", service: "Yoga Class",          time: "Tomorrow · 08:00", status: "confirmed", statusTone: "info" as StatusTone },
  { customer: "Ava Thompson",   avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", service: "Massage Therapy",     time: "Tomorrow · 10:30", status: "confirmed", statusTone: "info" as StatusTone },
];

// Staff schedule — 5 entries.
type StaffStatus = "available" | "busy" | "off";
const staffSchedule: Array<{
  name: string; avatar: string; role: string; bookings: number; status: StaffStatus;
}> = [
  { name: "Maya Patel",      avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", role: "Spa Therapist",      bookings: 8, status: "busy"      },
  { name: "Daniel Cruz",     avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", role: "Personal Trainer",   bookings: 6, status: "available" },
  { name: "Hannah Lee",      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop", role: "Yoga Instructor",    bookings: 4, status: "available" },
  { name: "Ravi Deshmukh",   avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", role: "Massage Therapist",  bookings: 7, status: "busy"      },
  { name: "Greta Nilsson",   avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop", role: "Front Desk",         bookings: 0, status: "off"       },
];

const staffStatusConfig: Record<StaffStatus, { tone: StatusTone; label: string; dot: string }> = {
  available: { tone: "success", label: "Available", dot: "bg-[color:var(--success)]" },
  busy:      { tone: "warning", label: "In session", dot: "bg-[color:var(--warning)]" },
  off:       { tone: "neutral", label: "Off duty",   dot: "bg-muted-foreground" },
};

/* ---------- Booking KPI card — calendar / clock-face feel ---------- */
// Distinct from all prior KPI cards:
// - Top-right mini analog clock-face SVG (hour hand pointing to peak hour) — distinct
//   from HR's gradient strip, logistics' route line, projects' sprint strip,
//   healthcare's ECG line, education's book spines, real estate's Nº page number
// - "Peak hour" caption (calendar-driven, time-focused aesthetic)
// - Booking palette (violet / emerald / rose / amber) — warm + cool mix without indigo/blue
// - Big value with optional unit + a subtle "schedule" subline

function BookingCard({
  label,
  value,
  unit,
  icon: Icon,
  accent,
  trend,
  trendLabel,
  peakHour,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  accent: "violet" | "emerald" | "rose" | "amber";
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  trendLabel: string;
  peakHour: string; // "HH:MM" 24h format
}) {
  // Static accent maps so Tailwind v4 can detect them
  const accentTile: Record<string, string> = {
    violet:  "bg-violet-500/12 text-violet-600 dark:text-violet-400",
    emerald: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400",
    rose:    "bg-rose-500/12 text-rose-600 dark:text-rose-400",
    amber:   "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  };
  const accentText: Record<string, string> = {
    violet:  "text-violet-600 dark:text-violet-400",
    emerald: "text-emerald-600 dark:text-emerald-400",
    rose:    "text-rose-600 dark:text-rose-400",
    amber:   "text-amber-600 dark:text-amber-400",
  };
  const accentStroke: Record<string, string> = {
    violet:  "stroke-violet-500",
    emerald: "stroke-emerald-500",
    rose:    "stroke-rose-500",
    amber:   "stroke-amber-500",
  };
  const accentFill: Record<string, string> = {
    violet:  "fill-violet-500",
    emerald: "fill-emerald-500",
    rose:    "fill-rose-500",
    amber:   "fill-amber-500",
  };

  // Compute the angle (in degrees) for the hour hand based on peakHour.
  const [hh, mm] = peakHour.split(":").map(Number);
  const hourAngle = ((hh % 12) + mm / 60) * 30; // 360/12 = 30 deg per hour

  const isUp = trend.direction === "up";

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card transition-all hover:shadow-premium-sm">
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
              {label}
            </p>
            <div className="mt-1.5 flex items-baseline gap-1">
              <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
              {unit && <span className="text-sm font-semibold text-muted-foreground tabular-nums">{unit}</span>}
            </div>
          </div>

          {/* Mini analog clock-face SVG — calendar/time-driven motif */}
          <div className="relative shrink-0">
            <svg
              viewBox="0 0 40 40"
              className={cn("h-10 w-10", accentStroke[accent])}
              aria-hidden
            >
              {/* Clock face circle */}
              <circle cx="20" cy="20" r="18" fill="none" strokeWidth="1.5" className="opacity-40" />
              {/* 12 hour ticks (4 major + 8 minor) */}
              {Array.from({ length: 12 }).map((_, i) => {
                const angle = (i * 30 - 90) * (Math.PI / 180);
                const isMajor = i % 3 === 0;
                const r1 = isMajor ? 14 : 15.5;
                const r2 = 17;
                const x1 = 20 + Math.cos(angle) * r1;
                const y1 = 20 + Math.sin(angle) * r1;
                const x2 = 20 + Math.cos(angle) * r2;
                const y2 = 20 + Math.sin(angle) * r2;
                return (
                  <line
                    key={i}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    strokeWidth={isMajor ? 1.5 : 0.75}
                    className={cn(isMajor ? accentStroke[accent] : "stroke-muted-foreground", isMajor && "opacity-70")}
                  />
                );
              })}
              {/* Hour hand — rotated to peakHour */}
              <line
                x1="20"
                y1="20"
                x2="20"
                y2="10"
                strokeWidth="2"
                strokeLinecap="round"
                className={cn(accentStroke[accent], "opacity-90")}
                transform={`rotate(${hourAngle} 20 20)`}
              />
              {/* Center dot */}
              <circle cx="20" cy="20" r="1.6" className={accentFill[accent]} />
            </svg>
            <div className={cn("absolute -bottom-1 -right-1 grid place-items-center h-5 w-5 rounded-md ring-2 ring-card", accentTile[accent])}>
              <Icon className="h-2.5 w-2.5" />
            </div>
          </div>
        </div>

        {/* Peak-hour chip — calendar/time-driven */}
        <div className="mt-3 flex items-center gap-1.5">
          <Clock className={cn("h-3 w-3", accentText[accent])} />
          <span className={cn("text-xs font-medium tabular-nums", accentText[accent])}>Peak at {peakHour}</span>
        </div>

        {/* Trend pill + caption */}
        <div className="mt-2 flex items-center gap-1.5">
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
              trend.positive
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {Math.abs(trend.value)}%
          </span>
          <span className="text-xs text-muted-foreground truncate">{trendLabel}</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function BookingDashboardPage() {
  const peakDay = weeklyBookings.reduce((max, d) => (d.bookings > max.bookings ? d : max), weeklyBookings[0]);
  const totalWeekBookings = weeklyBookings.reduce((s, x) => s + x.bookings, 0);
  const totalServices = serviceUtilization.reduce((s, x) => s + x.value, 0);

  return (
    <>
      <PageHeader
        title="Booking Dashboard"
        description="Daily bookings, service utilization, and staff schedules across your booking operations."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "Booking" }]}
        icon={CalendarDays}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> This week
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5 bg-violet-600 text-white hover:bg-violet-600/90">
              <Plus className="h-3.5 w-3.5" /> New booking
            </Button>
          </>
        }
      />

      {/* KPI Row — BookingCard with mini clock-face + peak-hour chip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <BookingCard
          label="Bookings Today"
          value="84"
          icon={CalendarCheck}
          accent="violet"
          trend={{ value: 12, direction: "up", positive: true }}
          trendLabel="vs. yesterday"
          peakHour="14:00"
        />
        <BookingCard
          label="Revenue Today"
          value="$3,840"
          icon={DollarSign}
          accent="emerald"
          trend={{ value: 8.4, direction: "up", positive: true }}
          trendLabel="vs. yesterday"
          peakHour="16:00"
        />
        <BookingCard
          label="Cancellation Rate"
          value="4.2"
          unit="%"
          icon={Ban}
          accent="rose"
          trend={{ value: 0.8, direction: "down", positive: true }}
          trendLabel="lower is better"
          peakHour="09:00"
        />
        <BookingCard
          label="Utilization"
          value="72"
          unit="%"
          icon={Gauge}
          accent="amber"
          trend={{ value: 3.6, direction: "up", positive: true }}
          trendLabel="72 of 100 slots booked"
          peakHour="15:00"
        />
      </div>

      {/* Weekly booking pattern + Service utilization */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-violet-600 dark:text-violet-400" />
                Weekly Booking Pattern
              </CardTitle>
              <CardDescription>
                Bookings per day of week · {totalWeekBookings} total this week · peak day {peakDay.day} ({peakDay.bookings}).
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-violet-500" /> Bookings
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={weeklyBookings}
              xKey="day"
              series={[
                { key: "bookings", name: "Bookings", color: "oklch(0.62 0.20 305)" },
              ]}
              height={300}
            />
            {/* Peak-hour indicator strip — distinct mini-legend of each day's peak hour */}
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-7 gap-1.5">
              {weeklyBookings.map((d) => {
                const isPeak = d.day === peakDay.day;
                return (
                  <div
                    key={d.day}
                    className={cn(
                      "rounded-md border px-1.5 py-1.5 text-center transition-colors",
                      isPeak
                        ? "border-violet-500/40 bg-violet-500/10"
                        : "border-border bg-muted/20"
                    )}
                  >
                    <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">{d.day}</p>
                    <p className={cn(
                      "text-[11px] font-semibold tabular-nums mt-0.5",
                      isPeak ? "text-violet-600 dark:text-violet-400" : "text-foreground"
                    )}>
                      {d.bookings}
                    </p>
                    <p className="text-[9px] text-muted-foreground tabular-nums mt-0.5 hidden sm:block">{d.peakHour}</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Service utilization donut */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-violet-600 dark:text-violet-400" />
              Service Utilization
            </CardTitle>
            <CardDescription>{totalServices}% of bookings by service category.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart
              data={serviceUtilization}
              centerLabel="Bookings"
              centerValue={totalServices.toString()}
              height={210}
            />
            <div className="mt-3 space-y-1.5 pt-3 border-t border-border">
              {serviceUtilization.map((s) => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="h-2 w-2 rounded-full shrink-0" style={{ background: s.color }} />
                    <span className="text-muted-foreground">{s.name}</span>
                  </div>
                  <span className="font-medium tabular-nums">{s.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's bookings table — full width, uses bookings data */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarCheck className="h-4 w-4 text-violet-600 dark:text-violet-400" />
              Today&apos;s Bookings
            </CardTitle>
            <CardDescription>Live bookings across all services.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" className="text-xs gap-1">
            View all <ArrowUpRight className="h-3.5 w-3.5" />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-y border-border bg-muted/40">
                <tr>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Booking</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Customer</th>
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Service</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden md:table-cell">Date / Time</th>
                  <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                  <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs font-medium text-foreground">{b.id}</span>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <span className="text-sm text-foreground">{b.customer}</span>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-foreground truncate">{b.service}</p>
                      <p className="text-xs text-muted-foreground sm:hidden truncate">{b.customer}</p>
                    </td>
                    <td className="px-4 py-3 text-right text-xs text-muted-foreground tabular-nums hidden md:table-cell">
                      {b.date} · {b.time}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge tone={bookingStatusTone[b.status]} dot className="capitalize">{b.status}</StatusBadge>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums font-medium text-foreground">
                      ${b.amount.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming reservations + Staff schedule */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Upcoming reservations */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-violet-600 dark:text-violet-400" />
                Upcoming Reservations
              </CardTitle>
              <CardDescription>Next 24 hours of scheduled services.</CardDescription>
            </div>
            <StatusBadge tone="info" dot>{upcomingReservations.length} upcoming</StatusBadge>
          </CardHeader>
          <CardContent className="space-y-2.5 max-h-[440px] overflow-y-auto pr-1 custom-scroll">
            {upcomingReservations.map((r, i) => (
              <div
                key={i}
                className="group flex items-center gap-3 rounded-lg border border-border bg-muted/20 p-3 hover:bg-muted/40 hover:border-violet-500/25 transition-colors"
              >
                <Avatar className="h-10 w-10 shrink-0">
                  <AvatarImage src={r.avatar} alt={r.customer} />
                  <AvatarFallback className="text-[10px]">
                    {r.customer.split(" ").map((n) => n[0]).join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground truncate">{r.customer}</p>
                  <p className="text-xs text-muted-foreground truncate">{r.service}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-medium text-foreground tabular-nums whitespace-nowrap flex items-center gap-1 justify-end">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    {r.time}
                  </p>
                  <StatusBadge tone={r.statusTone} className="mt-1 capitalize">{r.status}</StatusBadge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Staff schedule */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <User className="h-4 w-4 text-violet-600 dark:text-violet-400" />
                Staff Schedule
              </CardTitle>
              <CardDescription>Today&apos;s workload and availability.</CardDescription>
            </div>
            <StatusBadge tone="success" dot>On shift</StatusBadge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-y border-border bg-muted/40">
                  <tr>
                    <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Staff</th>
                    <th className="text-right font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 hidden sm:table-cell">Today</th>
                    <th className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {staffSchedule.map((s, i) => {
                    const cfg = staffStatusConfig[s.status];
                    return (
                      <tr key={i} className="hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="relative shrink-0">
                              <Avatar className="h-9 w-9">
                                <AvatarImage src={s.avatar} alt={s.name} />
                                <AvatarFallback className="text-[10px]">
                                  {s.name.split(" ").map((n) => n[0]).join("")}
                                </AvatarFallback>
                              </Avatar>
                              <span
                                className={cn(
                                  "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ring-2 ring-card",
                                  cfg.dot
                                )}
                                title={cfg.label}
                                aria-label={`Status: ${cfg.label}`}
                              />
                            </div>
                            <div className="min-w-0">
                              <p className="font-medium text-foreground truncate">{s.name}</p>
                              <p className="text-xs text-muted-foreground truncate">{s.role}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right hidden sm:table-cell">
                          <span className="inline-flex items-center gap-1 text-xs font-semibold tabular-nums text-violet-600 dark:text-violet-400">
                            <CalendarCheck className="h-3 w-3" />
                            {s.bookings} {s.bookings === 1 ? "booking" : "bookings"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <StatusBadge tone={cfg.tone} dot>{cfg.label}</StatusBadge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
