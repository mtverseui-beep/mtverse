"use client";

import * as React from "react";
import {
  User,
  UserPlus,
  UserCheck,
  TrendingUp,
  Upload,
  Plus,
  MoreHorizontal,
  Eye,
  Mail,
  Phone,
  Trash2,
  Star,
  ArrowUpRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DonutChart } from "@/components/charts";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type LeadStatus = "new" | "contacted" | "qualified" | "unqualified" | "converted";
type LeadSource = "Website" | "Referral" | "LinkedIn" | "Cold Outreach" | "Event" | "Partner";

type Lead = {
  id: string;
  name: string;
  avatar: string;
  company: string;
  industry: string;
  source: LeadSource;
  score: number;
  status: LeadStatus;
  owner: string;
  ownerAvatar: string;
  lastContact: string;
  value: number;
};

const leads: Lead[] = [
  { id: "LD-2041", name: "Daniela Pierce", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", company: "Globex Corp", industry: "SaaS", source: "Website", score: 88, status: "qualified", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", lastContact: "2 hr ago", value: 84000 },
  { id: "LD-2040", name: "Bill Lumbergh", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", company: "Initech", industry: "SaaS", source: "Referral", score: 72, status: "contacted", owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", lastContact: "Yesterday", value: 62500 },
  { id: "LD-2039", name: "Gavin Belson", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", company: "Hooli", industry: "Tech", source: "LinkedIn", score: 94, status: "qualified", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", lastContact: "3 hr ago", value: 124000 },
  { id: "LD-2038", name: "Alice Margolis", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", company: "Umbrella Inc", industry: "Healthcare", source: "Event", score: 56, status: "new", owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", lastContact: "2 days ago", value: 48200 },
  { id: "LD-2037", name: "Wile Coyote", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", company: "Acme Corp", industry: "Manufacturing", source: "Cold Outreach", score: 41, status: "contacted", owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", lastContact: "5 days ago", value: 96800 },
  { id: "LD-2036", name: "Sophie Lambert", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", company: "Stripe", industry: "Fintech", source: "Partner", score: 81, status: "qualified", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", lastContact: "Today", value: 156000 },
  { id: "LD-2035", name: "Marcus Halberd", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", company: "Plaid", industry: "Fintech", source: "LinkedIn", score: 67, status: "new", owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", lastContact: "4 hr ago", value: 72400 },
  { id: "LD-2034", name: "Yuki Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop", company: "Rakuten", industry: "Ecommerce", source: "Referral", score: 79, status: "contacted", owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", lastContact: "1 day ago", value: 58300 },
  { id: "LD-2033", name: "Olivia Hartwell", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", company: "Ro Health", industry: "Healthcare", source: "Website", score: 62, status: "qualified", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", lastContact: "6 hr ago", value: 91500 },
  { id: "LD-2032", name: "Daniel Whitmore", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", company: "Cloudflare", industry: "Infrastructure", source: "Event", score: 90, status: "qualified", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", lastContact: "Today", value: 184000 },
  { id: "LD-2031", name: "Priya Iyer", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop", company: "Freshworks", industry: "SaaS", source: "LinkedIn", score: 73, status: "new", owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", lastContact: "3 days ago", value: 67800 },
  { id: "LD-2030", name: "Lukas Werner", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop", company: "N26 Bank", industry: "Fintech", source: "Cold Outreach", score: 38, status: "unqualified", owner: "Marcus Reyes", ownerAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop", lastContact: "1 week ago", value: 42000 },
  { id: "LD-2029", name: "Camille Dubois", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=64&h=64&fit=crop", company: "Doctolib", industry: "Healthcare", source: "Referral", score: 84, status: "contacted", owner: "Elena Petrov", ownerAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop", lastContact: "Today", value: 102500 },
  { id: "LD-2028", name: "Rashid Al-Mansour", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=64&h=64&fit=crop", company: "Careem", industry: "Logistics", source: "Partner", score: 76, status: "qualified", owner: "Aiko Tanaka", ownerAvatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=40&h=40&fit=crop", lastContact: "2 hr ago", value: 88600 },
  { id: "LD-2027", name: "Mira Sundqvist", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=64&h=64&fit=crop", company: "Klarna", industry: "Fintech", source: "Website", score: 85, status: "converted", owner: "Sarah Chen", ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop", lastContact: "Today", value: 142000 },
  { id: "LD-2026", name: "Hiroshi Nakamura", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop", company: "Mercari", industry: "Ecommerce", source: "Event", score: 58, status: "new", owner: "James Okoro", ownerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop", lastContact: "4 days ago", value: 53400 },
];

const statusToneMap: Record<LeadStatus, StatusTone> = {
  new: "info",
  contacted: "primary",
  qualified: "success",
  unqualified: "danger",
  converted: "violet",
};

const leadSources: { name: string; value: number; color: string }[] = [
  { name: "Website", value: 42, color: "var(--primary)" },
  { name: "Referral", value: 28, color: "oklch(0.70 0.15 75)" },
  { name: "LinkedIn", value: 36, color: "oklch(0.58 0.13 250)" },
  { name: "Cold Outreach", value: 18, color: "var(--info)" },
  { name: "Event", value: 14, color: "oklch(0.62 0.18 25)" },
  { name: "Partner", value: 22, color: "oklch(0.62 0.18 305)" },
];

/* LeadKpi — score-ring motif: a small SVG donut ring on the right showing a key rate */
function LeadKpi({
  label,
  value,
  hint,
  icon: Icon,
  accent,
  ringValue,
  ringColor,
  trend,
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "primary" | "success" | "info" | "warning";
  ringValue: number;
  ringColor: string;
  trend: string;
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    success: "bg-[color:var(--success)]/15 text-[color:var(--success)]",
    info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
    warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  };
  const R = 18;
  const C = 2 * Math.PI * R;
  const dash = (ringValue / 100) * C;
  return (
    <Card>
      <CardContent className="pt-5 pb-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
            <p className="text-2xl font-semibold tabular-nums mt-1.5 tracking-tight">{value}</p>
            <p className="text-xs text-muted-foreground mt-1">{hint}</p>
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
            <div className={cn("grid place-items-center h-9 w-9 rounded-lg", accentMap[accent])}>
              <Icon className="h-4.5 w-4.5" />
            </div>
            {/* Score ring */}
            <div className="relative h-12 w-12">
              <svg className="h-12 w-12 -rotate-90" viewBox="0 0 44 44">
                <circle cx="22" cy="22" r={R} fill="none" stroke="var(--muted)" strokeWidth="4" />
                <circle
                  cx="22"
                  cy="22"
                  r={R}
                  fill="none"
                  stroke={ringColor}
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeDasharray={`${dash} ${C - dash}`}
                />
              </svg>
              <div className="absolute inset-0 grid place-items-center">
                <span className="text-[10px] font-bold tabular-nums">{ringValue}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 mt-3 text-xs">
          <TrendingUp className="h-3 w-3 text-[color:var(--success)]" />
          <span className="text-[color:var(--success)] font-medium">{trend}</span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function LeadsPage() {
  const columns: Column<Lead>[] = React.useMemo(
    () => [
      {
        key: "lead",
        header: "Lead",
        sortable: true,
        sortAccessor: (r) => r.name,
        cell: (r) => (
          <div className="flex items-center gap-2.5 min-w-0">
            <Avatar className="h-8 w-8 shrink-0">
              <AvatarImage src={r.avatar} alt={r.name} />
              <AvatarFallback className="text-[10px]">
                {r.name.split(" ").map((p) => p[0]).join("")}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="font-medium text-sm text-foreground truncate">{r.name}</p>
              <p className="text-xs text-muted-foreground truncate">
                {r.company} · {r.industry}
              </p>
            </div>
          </div>
        ),
      },
      {
        key: "source",
        header: "Source",
        sortable: true,
        sortAccessor: (r) => r.source,
        filterable: true,
        filterAccessor: (r) => r.source,
        filterOptions: [
          { label: "Website", value: "Website" },
          { label: "Referral", value: "Referral" },
          { label: "LinkedIn", value: "LinkedIn" },
          { label: "Cold Outreach", value: "Cold Outreach" },
          { label: "Event", value: "Event" },
          { label: "Partner", value: "Partner" },
        ],
        cell: (r) => (
          <span className="inline-flex items-center gap-1.5 text-xs">
            <span className="h-1.5 w-1.5 rounded-full bg-primary/60" />
            {r.source}
          </span>
        ),
        width: "w-32",
      },
      {
        key: "score",
        header: "Score",
        sortable: true,
        sortAccessor: (r) => r.score,
        cell: (r) => (
          <div className="flex items-center gap-2 w-32">
            <div className="h-1.5 w-16 rounded-full bg-muted overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full transition-all duration-500",
                  r.score >= 75
                    ? "bg-[color:var(--success)]"
                    : r.score >= 50
                    ? "bg-primary"
                    : "bg-[color:var(--warning)]"
                )}
                style={{ width: `${r.score}%` }}
              />
            </div>
            <span
              className={cn(
                "text-xs font-semibold tabular-nums",
                r.score >= 75
                  ? "text-[color:var(--success)]"
                  : r.score >= 50
                  ? "text-primary"
                  : "text-[color:var(--warning)]"
              )}
            >
              {r.score}
            </span>
          </div>
        ),
        width: "w-32",
      },
      {
        key: "status",
        header: "Status",
        sortable: true,
        sortAccessor: (r) => r.status,
        filterable: true,
        filterAccessor: (r) => r.status,
        filterOptions: [
          { label: "New", value: "new" },
          { label: "Contacted", value: "contacted" },
          { label: "Qualified", value: "qualified" },
          { label: "Unqualified", value: "unqualified" },
          { label: "Converted", value: "converted" },
        ],
        align: "center",
        cell: (r) => (
          <StatusBadge tone={statusToneMap[r.status]} dot className="capitalize">
            {r.status}
          </StatusBadge>
        ),
        width: "w-32",
      },
      {
        key: "owner",
        header: "Owner",
        sortable: true,
        sortAccessor: (r) => r.owner,
        cell: (r) => (
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={r.ownerAvatar} alt={r.owner} />
              <AvatarFallback className="text-[9px]">
                {r.owner.split(" ").map((p) => p[0]).join("")}
              </AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground truncate">{r.owner}</span>
          </div>
        ),
        width: "w-36",
      },
      {
        key: "lastContact",
        header: "Last Contact",
        sortable: true,
        sortAccessor: (r) => r.lastContact,
        cell: (r) => (
          <span className="text-xs text-muted-foreground">{r.lastContact}</span>
        ),
        width: "w-32",
      },
      {
        key: "value",
        header: "Value",
        sortable: true,
        sortAccessor: (r) => r.value,
        align: "right",
        cell: (r) => (
          <span className="font-medium tabular-nums">${r.value.toLocaleString()}</span>
        ),
        width: "w-28",
      },
      {
        key: "actions",
        header: "Actions",
        align: "right",
        hideable: false,
        cell: (r) => (
          <div onClick={(e) => e.stopPropagation()}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-44">
                <DropdownMenuLabel className="text-xs">{r.id}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening lead ${r.id}`)}>
                  <Eye className="h-3.5 w-3.5" /> View profile
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Email drafted to ${r.name}`)}>
                  <Mail className="h-3.5 w-3.5" /> Send email
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Call scheduled with ${r.name}`)}>
                  <Phone className="h-3.5 w-3.5" /> Log call
                </DropdownMenuItem>
                <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`${r.name} marked as qualified`)}>
                  <Star className="h-3.5 w-3.5" /> Mark qualified
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${r.name} removed`)}>
                  <Trash2 className="h-3.5 w-3.5" /> Remove
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        ),
        width: "w-16",
      },
    ],
    []
  );

  return (
    <>
      <PageHeader
        title="Leads"
        description="Capture, score, and qualify inbound prospects before they hit the pipeline."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "CRM & Sales" }, { label: "Leads" }]}
        icon={User}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Import dialog opened")}>
              <Upload className="h-3.5 w-3.5" /> Import
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Add lead form opened")}>
              <Plus className="h-3.5 w-3.5" /> Add Lead
            </Button>
          </>
        }
      />

      {/* KPI Row — score-ring motif */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <LeadKpi label="Total Leads" value="1,284" hint="across 6 sources" icon={User} accent="primary" ringValue={68} ringColor="var(--primary)" trend="+12.4% this month" />
        <LeadKpi label="New This Week" value="86" hint="38 from website" icon={UserPlus} accent="info" ringValue={42} ringColor="var(--info)" trend="+8.2% vs last week" />
        <LeadKpi label="Qualified" value="412" hint="32% of all leads" icon={UserCheck} accent="success" ringValue={32} ringColor="var(--success)" trend="+4.6% qualification rate" />
        <LeadKpi label="Conversion Rate" value="18.6%" hint="lead → customer" icon={TrendingUp} accent="warning" ringValue={19} ringColor="var(--warning)" trend="+2.1pp vs last quarter" />
      </div>

      {/* Sources donut + Pipeline conversion mini panel */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Lead Sources</CardTitle>
            <CardDescription>Where your prospects come from.</CardDescription>
          </CardHeader>
          <CardContent>
            <DonutChart data={leadSources} centerLabel="Total" centerValue="160" height={220} />
            <div className="mt-3 grid grid-cols-2 gap-2 pt-3 border-t border-border">
              {leadSources.map((s) => (
                <div key={s.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="h-2 w-2 rounded-full shrink-0" style={{ background: s.color }} />
                    <span className="text-muted-foreground truncate">{s.name}</span>
                  </div>
                  <span className="font-medium tabular-nums">{s.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="xl:col-span-2">
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Lead Lifecycle Conversion
              </CardTitle>
              <CardDescription>Funnel from raw lead to converted customer.</CardDescription>
            </div>
            <StatusBadge tone="primary" dot>Live</StatusBadge>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {[
                { stage: "New", count: 542, pct: 100, color: "var(--info)" },
                { stage: "Contacted", count: 384, pct: 71, color: "var(--primary)" },
                { stage: "Qualified", count: 218, pct: 40, color: "oklch(0.70 0.15 75)" },
                { stage: "Proposal", count: 142, pct: 26, color: "oklch(0.62 0.18 25)" },
                { stage: "Converted", count: 96, pct: 18, color: "var(--success)" },
              ].map((s, i, arr) => (
                <div key={s.stage} className="relative">
                  {i < arr.length - 1 && (
                    <div className="hidden sm:block absolute top-1/2 -right-2 z-10 -translate-y-1/2 text-muted-foreground/40">
                      <ArrowUpRight className="h-3.5 w-3.5 rotate-45" />
                    </div>
                  )}
                  <div className="rounded-lg border border-border bg-muted/30 p-3 h-full">
                    <p className="text-xs text-muted-foreground truncate">{s.stage}</p>
                    <p className="text-2xl font-semibold tabular-nums mt-1">{s.count}</p>
                    <div className="mt-2 h-1.5 w-full rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${s.pct}%`, background: s.color }} />
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-1.5 tabular-nums">{s.pct}% of new</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-border grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">Avg. Lead Score</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5">68 / 100</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Avg. Response Time</p>
                <p className="text-lg font-semibold tabular-nums mt-0.5">4h 12m</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Best Converting Source</p>
                <p className="text-lg font-semibold mt-0.5">Referral</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Leads DataTable */}
      <DataTable
        title="All Leads"
        data={leads}
        columns={columns}
        searchKeys={["name", "company", "id"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening lead ${r.id}`)}
        enableSelection
        enableExport
        enableDensity
        enableColumnVisibility
        pageSize={10}
        initialSort={{ key: "score", direction: "desc" }}
        bulkActions={[
          {
            label: "Mark qualified",
            icon: UserCheck,
            onClick: (sel) => toast.success(`Marked ${sel.length} lead${sel.length > 1 ? "s" : ""} as qualified`),
          },
          {
            label: "Assign owner",
            icon: User,
            onClick: (sel) => toast.message(`Assigning ${sel.length} lead${sel.length > 1 ? "s" : ""}…`),
          },
          {
            label: "Export selected",
            icon: Upload,
            onClick: (sel) => toast.success(`Exported ${sel.length} lead${sel.length > 1 ? "s" : ""} as CSV`),
          },
          {
            label: "Delete",
            icon: Trash2,
            onClick: (sel) => toast.error(`Removed ${sel.length} lead${sel.length > 1 ? "s" : ""}`),
          },
        ]}
      />
    </>
  );
}
