"use client";

import * as React from "react";
import {
  Activity,
  Server,
  Database,
  HardDrive,
  Mail,
  Cpu,
  ListChecks,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Bell,
  Plus,
  MoreHorizontal,
  Clock,
  Zap,
  Users,
  Timer,
  Shield,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { KpiCard, Sparkline } from "@/components/common/kpi-card";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { AreaTrendChart } from "@/components/charts";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type ServiceStatus = "operational" | "degraded" | "down";

type Service = {
  id: string;
  name: string;
  icon: any;
  status: ServiceStatus;
  uptime: number;
  responseTime: number;
  lastIncident: string;
  description: string;
};

const services: Service[] = [
  { id: "s1", name: "API Gateway", icon: Server, status: "operational", uptime: 99.99, responseTime: 84, lastIncident: "14 days ago", description: "Public REST + GraphQL endpoints" },
  { id: "s2", name: "PostgreSQL Cluster", icon: Database, status: "operational", uptime: 99.98, responseTime: 12, lastIncident: "32 days ago", description: "Primary read/write replica (us-west-2)" },
  { id: "s3", name: "Redis Cache", icon: Cpu, status: "degraded", uptime: 98.42, responseTime: 4, lastIncident: "2 hours ago", description: "Session store + rate limiting" },
  { id: "s4", name: "Background Workers", icon: ListChecks, status: "operational", uptime: 99.94, responseTime: 0, lastIncident: "6 days ago", description: "Async job processing (BullMQ)" },
  { id: "s5", name: "Object Storage", icon: HardDrive, status: "operational", uptime: 99.99, responseTime: 142, lastIncident: "21 days ago", description: "S3 bucket · customer uploads" },
  { id: "s6", name: "Email Delivery", icon: Mail, status: "operational", uptime: 99.86, responseTime: 1280, lastIncident: "11 days ago", description: "Transactional + marketing (Postmark)" },
];

const statusConfig: Record<ServiceStatus, { tone: StatusTone; label: string; color: string }> = {
  operational: { tone: "success", label: "Operational", color: "var(--success)" },
  degraded: { tone: "warning", label: "Degraded", color: "var(--warning)" },
  down: { tone: "danger", label: "Down", color: "var(--destructive)" },
};

type Incident = {
  id: string;
  severity: "low" | "medium" | "high" | "critical";
  service: string;
  title: string;
  description: string;
  time: string;
  status: "investigating" | "identified" | "monitoring" | "resolved";
};

const incidents: Incident[] = [
  { id: "INC-2048", severity: "high", service: "Redis Cache", title: "Elevated cache miss rate", description: "Following the 14:32 UTC deploy, cache hit ratio dropped from 96% to 71%. Engineering is rolling back the config change.", time: "2h ago", status: "investigating" },
  { id: "INC-2047", severity: "medium", service: "API Gateway", title: "Increased p99 latency on /v1/payments", description: "p99 latency on the payments endpoint peaked at 480ms (normal: 120ms) for 12 minutes. Resolved by scaling up the connection pool.", time: "Yesterday", status: "resolved" },
  { id: "INC-2046", severity: "low", service: "Email Delivery", title: "Delayed marketing campaign sends", description: "A batch of 14k marketing emails experienced a 22-minute delay due to upstream throttling. No customer impact.", time: "2 days ago", status: "resolved" },
  { id: "INC-2045", severity: "critical", service: "PostgreSQL Cluster", title: "Read replica connection exhaustion", description: "Connection pool maxed at 8 (target: 80) during rolling deploy. ~12% of read requests timed out over 47 minutes. Mitigated by config fix.", time: "6 days ago", status: "resolved" },
  { id: "INC-2044", severity: "medium", service: "Object Storage", title: "S3 503 errors in us-east-1", description: "Upstream S3 incident caused intermittent 503s on upload. Resolved when AWS confirmed full service restoration.", time: "11 days ago", status: "resolved" },
];

type AlertRule = {
  id: string;
  name: string;
  condition: string;
  threshold: string;
  lastTriggered: string;
  enabled: boolean;
  severity: "low" | "medium" | "high";
};

const initialAlertRules: AlertRule[] = [
  { id: "a1", name: "API p99 latency", condition: "p99 latency > 250ms for 5 min", threshold: "> 250ms", lastTriggered: "Yesterday · 2:14pm", enabled: true, severity: "high" },
  { id: "a2", name: "DB connection pool", condition: "active connections > 60", threshold: "> 60", lastTriggered: "6 days ago", enabled: true, severity: "critical" },
  { id: "a3", name: "Error rate spike", condition: "5xx errors > 1% for 2 min", threshold: "> 1%", lastTriggered: "3 days ago", enabled: true, severity: "high" },
  { id: "a4", name: "Cache miss ratio", condition: "miss ratio < 80% for 10 min", threshold: "< 80%", lastTriggered: "2h ago", enabled: true, severity: "medium" },
  { id: "a5", name: "Disk usage", condition: "disk usage > 85%", threshold: "> 85%", lastTriggered: "Never", enabled: false, severity: "low" },
];

// Deterministic latency data — values must match on server and client to avoid hydration mismatch.
// Using a pseudo-random based on index (not Math.random which gives different values per render).
const latencyData = Array.from({ length: 24 }, (_, i) => {
  const hour = `${pad(i)}:00`;
  const base = 110 + Math.sin(i / 3) * 18;
  const noise = (i === 14 ? 60 : i === 15 ? 40 : i === 16 ? 20 : 0);
  // Deterministic "noise" using sine — same value on server and client
  const detNoise = Math.sin(i * 7.3) * 4;
  const detErrors = Math.max(0, Math.round(Math.abs(Math.sin(i * 3.1)) * 4 + (noise > 30 ? 2 : 0)));
  return { hour, latency: Math.round(base + noise + detNoise), errors: detErrors };
});

const sparkUptime = [99.91, 99.93, 99.95, 99.97, 99.96, 99.98, 99.98];
const sparkLatency = [142, 138, 128, 132, 126, 122, 124];
const sparkUsers = [6200, 6800, 7100, 7400, 7900, 8100, 8420];
const sparkErrors = [0.05, 0.04, 0.06, 0.03, 0.04, 0.02, 0.02];

function pad(n: number) { return n.toString().padStart(2, "0"); }

const severityConfig: Record<Incident["severity"], { tone: StatusTone; color: string; label: string }> = {
  low: { tone: "info", color: "var(--info)", label: "Low" },
  medium: { tone: "warning", color: "var(--warning)", label: "Medium" },
  high: { tone: "danger", color: "var(--destructive)", label: "High" },
  critical: { tone: "danger", color: "var(--destructive)", label: "Critical" },
};

const incidentStatusConfig: Record<Incident["status"], { tone: StatusTone; label: string }> = {
  investigating: { tone: "warning", label: "Investigating" },
  identified: { tone: "info", label: "Identified" },
  monitoring: { tone: "primary", label: "Monitoring" },
  resolved: { tone: "success", label: "Resolved" },
};

export default function MonitoringPage() {
  const [rules, setRules] = React.useState(initialAlertRules);

  function toggleRule(id: string) {
    setRules((prev) => prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)));
    const r = rules.find((x) => x.id === id);
    toast.success(r && r.enabled ? "Alert rule disabled" : "Alert rule enabled", { description: r?.name });
  }

  const operationalCount = services.filter((s) => s.status === "operational").length;
  const degradedCount = services.filter((s) => s.status === "degraded").length;
  const downCount = services.filter((s) => s.status === "down").length;

  return (
    <>
      <PageHeader
        title="System Monitoring"
        description="Real-time visibility into service health, performance, and incidents."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Apps" }, { label: "Monitoring" }]}
        icon={Activity}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Status page opened")}>
              <Shield className="h-3.5 w-3.5" /> Status Page
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Incident created")}>
              <Plus className="h-3.5 w-3.5" /> New Incident
            </Button>
          </>
        }
      />

      {/* Overall status banner */}
      <Card className="mb-6 border-[color:var(--warning)]/30 bg-gradient-to-r from-[color:var(--warning)]/[0.05] to-transparent">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <div className="grid place-items-center h-10 w-10 rounded-full bg-[color:var(--warning)]/15 text-[color:var(--warning)] shrink-0">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">Partial service degradation</p>
              <p className="text-xs text-muted-foreground mt-0.5">{operationalCount} of {services.length} services operational · {degradedCount} degraded · {downCount} down</p>
            </div>
            <StatusBadge tone="warning" dot>Active incident</StatusBadge>
          </div>
        </CardContent>
      </Card>

      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard
          label="Uptime (30d)"
          value="99.98%"
          icon={CheckCircle2}
          accent="success"
          trend={{ value: 0.04, direction: "up", positive: true }}
          hint="SLA target: 99.9%"
          sparkline={<Sparkline data={sparkUptime} color="var(--success)" />}
        />
        <KpiCard
          label="Avg Response Time"
          value="124ms"
          icon={Timer}
          accent="info"
          trend={{ value: 8.2, direction: "down", positive: true }}
          hint="vs last hour"
          sparkline={<Sparkline data={sparkLatency} color="var(--info)" />}
        />
        <KpiCard
          label="Active Users"
          value="8,420"
          icon={Users}
          accent="primary"
          trend={{ value: 14.6, direction: "up" }}
          hint="live now"
          sparkline={<Sparkline data={sparkUsers} color="var(--primary)" />}
        />
        <KpiCard
          label="Error Rate"
          value="0.02%"
          icon={Zap}
          accent="destructive"
          trend={{ value: 0.01, direction: "down", positive: true }}
          hint="4xx + 5xx / total"
          sparkline={<Sparkline data={sparkErrors} color="var(--destructive)" />}
        />
      </div>

      {/* Service health + chart */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Service Health</CardTitle>
                <CardDescription>Real-time status across all critical services.</CardDescription>
              </div>
              <Button variant="ghost" size="sm" className="text-xs" onClick={() => toast.message("Opening detailed view")}>View all</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {services.map((s) => {
                const cfg = statusConfig[s.status];
                const Icon = s.icon;
                return (
                  <div key={s.id} className="rounded-lg border border-border p-3 hover:border-primary/30 transition-colors">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="grid place-items-center h-8 w-8 rounded-md bg-muted shrink-0">
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{s.name}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{s.description}</p>
                        </div>
                      </div>
                      <StatusBadge tone={cfg.tone} dot className="text-[9px] shrink-0">{cfg.label}</StatusBadge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center mt-2">
                      <div>
                        <p className="text-[9px] uppercase tracking-wide text-muted-foreground">Uptime</p>
                        <p className="text-xs font-semibold tabular-nums">{s.uptime}%</p>
                      </div>
                      <div>
                        <p className="text-[9px] uppercase tracking-wide text-muted-foreground">Resp.</p>
                        <p className="text-xs font-semibold tabular-nums">{s.responseTime}ms</p>
                      </div>
                      <div>
                        <p className="text-[9px] uppercase tracking-wide text-muted-foreground">Last incident</p>
                        <p className="text-xs font-medium text-muted-foreground">{s.lastIncident}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Latency (24h)</CardTitle>
                <CardDescription>p95 response time, hourly.</CardDescription>
              </div>
              <StatusBadge tone="success" dot>Live</StatusBadge>
            </div>
          </CardHeader>
          <CardContent>
            <AreaTrendChart
              data={latencyData}
              xKey="hour"
              series={[{ key: "latency", name: "Latency (ms)", color: "var(--primary)" }]}
              height={260}
            />
            <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-border">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Min</p>
                <p className="text-sm font-semibold tabular-nums">{Math.min(...latencyData.map((d) => d.latency))}ms</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Avg</p>
                <p className="text-sm font-semibold tabular-nums">{Math.round(latencyData.reduce((s, d) => s + d.latency, 0) / latencyData.length)}ms</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Peak</p>
                <p className="text-sm font-semibold tabular-nums text-[color:var(--warning)]">{Math.max(...latencyData.map((d) => d.latency))}ms</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Incidents + alert rules */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Incidents */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Recent Incidents</CardTitle>
                <CardDescription>Last 14 days · 5 incidents logged.</CardDescription>
              </div>
              <Button variant="ghost" size="sm" className="text-xs" onClick={() => toast.message("Opening incident log")}>All incidents</Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[420px]">
              <div className="divide-y">
                {incidents.map((inc) => {
                  const sev = severityConfig[inc.severity];
                  const stat = incidentStatusConfig[inc.status];
                  return (
                    <div key={inc.id} className="p-4 hover:bg-muted/30 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className="grid place-items-center h-8 w-8 rounded-md shrink-0" style={{ background: `color-mix(in srgb, ${sev.color} 12%, transparent)`, color: sev.color }}>
                          {inc.severity === "critical" ? <XCircle className="h-4 w-4" /> : inc.severity === "high" ? <AlertTriangle className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-medium">{inc.title}</span>
                            <StatusBadge tone={sev.tone} className="text-[9px]">{sev.label}</StatusBadge>
                            <StatusBadge tone={stat.tone} className="text-[9px]">{stat.label}</StatusBadge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{inc.description}</p>
                          <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                            <span className="font-mono">{inc.id}</span>
                            <span>·</span>
                            <span>{inc.service}</span>
                            <span>·</span>
                            <span className="flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{inc.time}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Alert rules */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Alert Rules</CardTitle>
                <CardDescription>{rules.filter((r) => r.enabled).length} of {rules.length} rules active.</CardDescription>
              </div>
              <Button size="sm" variant="outline" className="gap-1.5 text-xs h-7" onClick={() => toast.success("Rule builder opened")}>
                <Plus className="h-3 w-3" /> New Rule
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {rules.map((r) => (
                <div key={r.id} className="p-3 flex items-center gap-3 hover:bg-muted/30 transition-colors">
                  <div className={cn(
                    "grid place-items-center h-9 w-9 rounded-md shrink-0",
                    r.severity === "critical" || r.severity === "high" ? "bg-destructive/10 text-destructive" : r.severity === "medium" ? "bg-[color:var(--warning)]/12 text-[color:var(--warning)]" : "bg-[color:var(--info)]/12 text-[color:var(--info)]"
                  )}>
                    <Bell className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium truncate">{r.name}</p>
                      <StatusBadge tone={severityConfig[r.severity as Incident["severity"]].tone} className="text-[9px]">{severityConfig[r.severity as Incident["severity"]].label}</StatusBadge>
                    </div>
                    <p className="text-xs text-muted-foreground truncate mt-0.5">{r.condition}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">Last triggered: {r.lastTriggered}</p>
                  </div>
                  <Switch checked={r.enabled} onCheckedChange={() => toggleRule(r.id)} />
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0"><MoreHorizontal className="h-3.5 w-3.5" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => toast.success("Edit rule opened")}>Edit rule</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toast.success("Duplicated")}>Duplicate</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toast.success("Test alert fired")}>Send test alert</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
