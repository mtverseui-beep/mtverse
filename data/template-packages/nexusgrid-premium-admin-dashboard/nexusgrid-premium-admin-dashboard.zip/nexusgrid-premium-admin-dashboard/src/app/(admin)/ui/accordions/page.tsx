"use client";

import * as React from "react";
import {
  ChevronDownSquare,
  CreditCard,
  Shield,
  Users,
  HelpCircle,
  FileText,
  Lock,
  Globe,
  Database,
  Server,
  Cloud,
  Bell,
  Code,
  Zap,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/common/status-badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function AccordionsPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Accordions"
        description="Collapsible content sections — single, multiple, with icons, chevrons, nested and FAQ patterns."
        icon={ChevronDownSquare}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "UI Components", href: "/ui/accordions" },
          { label: "Accordions" },
        ]}
        actions={
          <Button variant="outline" size="sm" onClick={() => toast.success("Accordion spec copied")}>
            <FileText /> Spec sheet
          </Button>
        }
      />

      {/* Single open */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Single open (default)</CardTitle>
          <CardDescription>
            Only one item is expanded at a time — the previous collapses when you open a new one.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" defaultValue="item-1" className="rounded-lg border px-4">
            <AccordionItem value="item-1">
              <AccordionTrigger>What happens when my trial ends?</AccordionTrigger>
              <AccordionContent>
                After your 14-day trial ends, your workspace is automatically moved to the Free plan.
                You keep all your data, but premium features (audit logs, advanced analytics, SSO) become read-only.
                Re-upgrade any time from Billing to restore full access.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>Can I change my plan later?</AccordionTrigger>
              <AccordionContent>
                Yes — you can upgrade or downgrade at any time. Upgrades take effect immediately and we prorate the
                difference. Downgrades take effect at the end of your current billing cycle.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>Do you offer discounts for non-profits?</AccordionTrigger>
              <AccordionContent>
                Verified non-profits receive 50% off any paid plan. Educational institutions get free Pro for up to 100
                seats. Reach out to our team from the Contact sales flow to apply.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
              <AccordionContent>
                We accept Visa, Mastercard, American Express and Discover. Enterprise plans can also pay by ACH transfer
                or wire. Invoiced billing is available for plans starting at $500 / month.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Multiple open */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Multiple open</CardTitle>
          <CardDescription>
            Independent items can all be expanded simultaneously — useful for comparison content.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" defaultValue={["m1", "m3"]} className="rounded-lg border px-4">
            <AccordionItem value="m1">
              <AccordionTrigger>
                <span className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-primary" />
                  Billing & invoicing
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">Configure how customers are billed:</p>
                <ul className="space-y-1.5 text-sm text-muted-foreground list-disc pl-4">
                  <li>Automatic invoicing on the 1st of each month</li>
                  <li>Net-15 payment terms for Enterprise</li>
                  <li>Tax-exempt status for verified non-profits</li>
                  <li>Dunning emails at day 1, 3 and 7 of past due</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="m2">
              <AccordionTrigger>
                <span className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-[color:var(--success)]" />
                  Security & compliance
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">Workspace security defaults:</p>
                <ul className="space-y-1.5 text-sm text-muted-foreground list-disc pl-4">
                  <li>SOC 2 Type II certified since 2024</li>
                  <li>Require 2FA for all admins (recommended)</li>
                  <li>Session timeout of 8 hours by default</li>
                  <li>IP allowlist enforced for SSO logins</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="m3">
              <AccordionTrigger>
                <span className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-[color:var(--info)]" />
                  Team & permissions
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">Member roles available:</p>
                <ul className="space-y-1.5 text-sm text-muted-foreground list-disc pl-4">
                  <li>Owner — full control including billing</li>
                  <li>Admin — manage members and settings</li>
                  <li>Editor — create and edit content</li>
                  <li>Viewer — read-only access</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="m4">
              <AccordionTrigger>
                <span className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-violet-500" />
                  Data residency
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">Choose where your data is stored:</p>
                <ul className="space-y-1.5 text-sm text-muted-foreground list-disc pl-4">
                  <li>US (us-east-1, us-west-2)</li>
                  <li>EU (eu-central-1, eu-west-1)</li>
                  <li>APAC (ap-southeast-1, ap-northeast-1)</li>
                  <li>On-prem deployment available on Enterprise</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* With icons + chevrons + status */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">With status badges</CardTitle>
          <CardDescription>
            Triggers can carry badges, status dots or count indicators for richer scannability.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" defaultValue="s1" className="rounded-lg border px-4">
            <AccordionItem value="s1">
              <AccordionTrigger>
                <span className="flex items-center gap-3 flex-1">
                  <Database className="h-4 w-4 text-primary" />
                  <span>Database migration — v2.4.0</span>
                  <StatusBadge tone="success" dot>Completed</StatusBadge>
                </span>
              </AccordionTrigger>
              <AccordionContent>
                Migration completed at 02:14 UTC. 1.2M rows migrated in 8 minutes with zero downtime.
                All read replicas are in sync. Rollback window expires in 24 hours.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="s2">
              <AccordionTrigger>
                <span className="flex items-center gap-3 flex-1">
                  <Server className="h-4 w-4 text-[color:var(--info)]" />
                  <span>API gateway upgrade</span>
                  <StatusBadge tone="info" dot>In progress</StatusBadge>
                </span>
              </AccordionTrigger>
              <AccordionContent>
                Rolling out new gateway across 6 regions. Currently at 64% complete.
                Expected finish in 22 minutes. No customer impact detected.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="s3">
              <AccordionTrigger>
                <span className="flex items-center gap-3 flex-1">
                  <Cloud className="h-4 w-4 text-[color:var(--warning)]" />
                  <span>CDN cache purge</span>
                  <StatusBadge tone="warning" dot>Scheduled</StatusBadge>
                </span>
              </AccordionTrigger>
              <AccordionContent>
                Scheduled for 04:00 UTC tonight. Will invalidate cached assets across 28 edge locations.
                Expect brief increase in origin requests for ~5 minutes.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="s4">
              <AccordionTrigger>
                <span className="flex items-center gap-3 flex-1">
                  <Lock className="h-4 w-4 text-destructive" />
                  <span>SSL certificate renewal</span>
                  <StatusBadge tone="danger" dot>Action required</StatusBadge>
                </span>
              </AccordionTrigger>
              <AccordionContent>
                Certificate for *.acme.com expires in 12 days. Auto-renewal is disabled.
                Please verify DNS validation records and re-enable Let's Encrypt in the SSL settings.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Nested accordions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Nested accordions</CardTitle>
          <CardDescription>
            Accordions inside accordions for hierarchical content like multi-step settings.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" defaultValue="parent-1" className="rounded-lg border px-4">
            <AccordionItem value="parent-1">
              <AccordionTrigger>
                <span className="flex items-center gap-2">
                  <Code className="h-4 w-4 text-primary" /> Developer settings
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Configure API access, webhooks and integration tokens.
                </p>
                <Accordion type="multiple" className="rounded-md border bg-muted/30 px-3">
                  <AccordionItem value="nested-1">
                    <AccordionTrigger className="text-sm">API keys</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-xs text-muted-foreground mb-2">3 active keys</p>
                      <div className="space-y-1.5">
                        {[
                          { name: "Production backend", scope: "read_write", age: "62 days" },
                          { name: "Staging CI runner", scope: "read_only", age: "14 days" },
                          { name: "Marketing dashboard", scope: "analytics", age: "5 days" },
                        ].map((k) => (
                          <div key={k.name} className="rounded border bg-card p-2 text-xs flex items-center justify-between">
                            <div>
                              <p className="font-medium">{k.name}</p>
                              <p className="text-muted-foreground">scope: {k.scope} · created {k.age} ago</p>
                            </div>
                            <Badge variant="secondary" className="text-[10px]">{k.scope}</Badge>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="nested-2">
                    <AccordionTrigger className="text-sm">Webhooks</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-xs text-muted-foreground mb-2">4 endpoints configured</p>
                      <div className="space-y-1.5">
                        {[
                          { url: "https://api.acme.io/hooks/billing", status: "active" },
                          { url: "https://crm.acme.io/webhooks/leads", status: "active" },
                          { url: "https://legacy.acme.io/notify", status: "failing" },
                        ].map((w) => (
                          <div key={w.url} className="rounded border bg-card p-2 text-xs flex items-center justify-between gap-2">
                            <span className="truncate font-mono text-[11px]">{w.url}</span>
                            <StatusBadge tone={w.status === "active" ? "success" : "danger"} dot>
                              {w.status}
                            </StatusBadge>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="nested-3">
                    <AccordionTrigger className="text-sm">Rate limits</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-xs text-muted-foreground">
                        Per-key rate limits, burst allowance and quota windows are configured here.
                        Default: 1,000 req/min, 10,000 req/hour.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="parent-2">
              <AccordionTrigger>
                <span className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-amber-500" /> Webhooks & automations
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">
                  Automations fire on workspace events. Configure triggers, conditions and actions.
                  Common patterns: notify Slack on new ticket, sync customer to CRM on payment, send
                  weekly digest every Monday at 09:00 local time.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="parent-3">
              <AccordionTrigger>
                <span className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-[color:var(--info)]" /> Notification preferences
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground">
                  Fine-grained control over which events trigger email, push, SMS and in-app notifications.
                  Channel-level quiet hours are also configured here.
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* FAQ-style */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <HelpCircle className="h-4 w-4" /> Frequently asked questions
          </CardTitle>
          <CardDescription>
            Clean FAQ pattern used on marketing, docs and help pages.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="space-y-2">
            {[
              {
                q: "How is my data backed up?",
                a: "We take encrypted snapshots every 6 hours and store them in 3 geographically distinct regions. Snapshots are retained for 30 days. You can also export your workspace data as a JSON or CSV archive from Settings → Data export.",
              },
              {
                q: "Can I self-host NexusGrid?",
                a: "Self-hosting is available on the Enterprise plan. We provide a Docker Compose stack for staging and a Helm chart for production Kubernetes. Your team owns the deployment; we provide updates and 24/7 support.",
              },
              {
                q: "What is your uptime SLA?",
                a: "We commit to 99.95% uptime on Pro and 99.99% on Enterprise. The SLA excludes scheduled maintenance (announced at least 7 days in advance) and force-majeure events. Service credits are issued automatically if we miss the SLA.",
              },
              {
                q: "Do you support SSO and SAML?",
                a: "Yes — Pro plans support Google and Microsoft SSO. Enterprise adds SAML 2.0 with any identity provider (Okta, OneLogin, Azure AD, etc.) and SCIM for automated user provisioning.",
              },
              {
                q: "How do I cancel my subscription?",
                a: "Cancel any time from Billing → Manage subscription. You keep access until the end of your current billing cycle, after which your workspace is downgraded to the Free plan. Your data is retained for 90 days in case you change your mind.",
              },
              {
                q: "What programming languages do your SDKs support?",
                a: "We ship first-party SDKs for JavaScript/TypeScript, Python, Go, Ruby, PHP and Java. Community SDKs exist for Rust, Elixir and Swift. All SDKs are MIT-licensed and published to their respective package managers.",
              },
            ].map((item, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="border rounded-lg px-4 data-[state=open]:bg-muted/30"
              >
                <AccordionTrigger className="text-sm">{item.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center pb-6">
        Accordions page · single · multiple · with status badges · nested · FAQ pattern
      </p>
    </div>
  );
}
