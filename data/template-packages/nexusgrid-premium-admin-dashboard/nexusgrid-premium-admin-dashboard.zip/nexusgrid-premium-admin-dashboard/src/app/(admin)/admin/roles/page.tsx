"use client";

import * as React from "react";
import {
  Shield,
  Crown,
  UserCog,
  PenSquare,
  Eye,
  UserX,
  Plus,
  Users,
  Lock,
  CheckCircle2,
  Settings2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Role = {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  tone: "warning" | "danger" | "primary" | "info" | "neutral" | "violet";
  members: number;
  permissions: number;
  system: boolean;
  color: string;
};

const ROLES: Role[] = [
  { id: "r1", name: "Owner", description: "Full control including billing, deletion, and ownership transfer.", icon: Crown, tone: "warning", members: 1, permissions: 48, system: true, color: "amber" },
  { id: "r2", name: "Admin", description: "Manage members, roles, integrations, and workspace settings.", icon: Shield, tone: "danger", members: 3, permissions: 42, system: true, color: "rose" },
  { id: "r3", name: "Manager", description: "Lead projects, assign work, and view reports across the team.", icon: UserCog, tone: "primary", members: 6, permissions: 28, system: true, color: "primary" },
  { id: "r4", name: "Editor", description: "Create and edit content, files, and tasks. Cannot manage members.", icon: PenSquare, tone: "info", members: 14, permissions: 18, system: true, color: "sky" },
  { id: "r5", name: "Viewer", description: "Read-only access to dashboards, reports, and shared files.", icon: Eye, tone: "neutral", members: 9, permissions: 8, system: true, color: "slate" },
  { id: "r6", name: "Guest", description: "Limited external access to specific resources, time-boxed.", icon: UserX, tone: "violet", members: 4, permissions: 4, system: true, color: "violet" },
  { id: "r7", name: "Billing Analyst", description: "Custom role: read invoices, manage payment methods, no API access.", icon: Settings2, tone: "info", members: 2, permissions: 12, system: false, color: "sky" },
];

const toneIcon: Record<string, string> = {
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  danger: "bg-destructive/15 text-destructive",
  primary: "bg-primary/15 text-primary",
  info: "bg-[color:var(--info)]/15 text-[color:var(--info)]",
  neutral: "bg-muted text-muted-foreground",
  violet: "bg-violet-500/15 text-violet-500",
};

const RESOURCES = ["Users", "Projects", "Orders", "Reports", "Settings", "Billing", "API Keys", "Webhooks"];
const ACTIONS = ["View", "Create", "Edit", "Delete", "Admin"] as const;

type PermMatrix = Record<string, Record<string, boolean>>;

const DEFAULT_MATRIX: PermMatrix = {
  Users:     { View: true, Create: true, Edit: true, Delete: false, Admin: false },
  Projects:  { View: true, Create: true, Edit: true, Delete: true, Admin: false },
  Orders:    { View: true, Create: true, Edit: true, Delete: false, Admin: false },
  Reports:   { View: true, Create: true, Edit: false, Delete: false, Admin: false },
  Settings:  { View: true, Create: false, Edit: false, Delete: false, Admin: false },
  Billing:   { View: true, Create: false, Edit: false, Delete: false, Admin: false },
  "API Keys": { View: false, Create: false, Edit: false, Delete: false, Admin: false },
  Webhooks:  { View: false, Create: false, Edit: false, Delete: false, Admin: false },
};

export default function RolesPage() {
  const [selectedRole, setSelectedRole] = React.useState("r4");
  const [matrix, setMatrix] = React.useState<PermMatrix>(DEFAULT_MATRIX);
  const [createOpen, setCreateOpen] = React.useState(false);
  const [savedMatrix, setSavedMatrix] = React.useState<PermMatrix>(DEFAULT_MATRIX);

  const role = ROLES.find((r) => r.id === selectedRole)!;
  const isDirty = JSON.stringify(matrix) !== JSON.stringify(savedMatrix);
  const enabledCount = Object.values(matrix).reduce((acc, row) => acc + Object.values(row).filter(Boolean).length, 0);

  const toggle = (resource: string, action: string) =>
    setMatrix((prev) => ({
      ...prev,
      [resource]: { ...prev[resource], [action]: !prev[resource][action] },
    }));

  return (
    <>
      <PageHeader
        title="Roles"
        description="Define what each persona in your workspace can do. System roles are pre-configured; custom roles are yours to shape."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Roles" }]}
        icon={Shield}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setCreateOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> Create role
          </Button>
        }
      />

      {/* ROLES GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
        {ROLES.map((r) => (
          <Card
            key={r.id}
            className={cn(
              "p-5 cursor-pointer transition-all hover:shadow-premium-sm relative overflow-hidden",
              selectedRole === r.id ? "ring-2 ring-primary/50 border-primary/40" : "hover:border-primary/30"
            )}
            onClick={() => { setSelectedRole(r.id); setMatrix(DEFAULT_MATRIX); setSavedMatrix(DEFAULT_MATRIX); }}
          >
            {/* Accent corner */}
            <div className={cn("absolute top-0 left-0 right-0 h-1", `bg-${r.color}-500`)} style={{ background: r.tone === "warning" ? "var(--warning)" : r.tone === "danger" ? "var(--destructive)" : r.tone === "primary" ? "var(--primary)" : r.tone === "info" ? "var(--info)" : r.tone === "violet" ? "#8b5cf6" : "var(--muted-foreground)" }} />

            <div className="flex items-start justify-between mb-3">
              <div className={cn("grid place-items-center h-11 w-11 rounded-xl", toneIcon[r.tone])}>
                <r.icon className="h-5 w-5" />
              </div>
              {r.system ? (
                <Badge variant="outline" className="text-[9px] uppercase tracking-wide gap-1">
                  <Lock className="h-2.5 w-2.5" /> System
                </Badge>
              ) : (
                <Badge variant="outline" className="text-[9px] uppercase tracking-wide border-primary/30 text-primary">Custom</Badge>
              )}
            </div>

            <h3 className="text-base font-semibold">{r.name}</h3>
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2 min-h-[2.5rem]">{r.description}</p>

            <Separator className="my-3" />

            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground flex items-center gap-1"><Users className="h-2.5 w-2.5" /> Members</p>
                <p className="text-lg font-semibold tabular-nums leading-tight">{r.members}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-muted-foreground flex items-center gap-1"><Shield className="h-2.5 w-2.5" /> Perms</p>
                <p className="text-lg font-semibold tabular-nums leading-tight">{r.permissions}</p>
              </div>
            </div>
          </Card>
        ))}

        {/* CREATE ROLE CARD */}
        <Card
          className="p-5 border-dashed border-2 hover:border-primary/40 hover:bg-primary/[0.02] transition-colors cursor-pointer grid place-items-center min-h-[230px]"
          onClick={() => setCreateOpen(true)}
        >
          <div className="text-center">
            <div className="mx-auto grid place-items-center h-11 w-11 rounded-xl bg-primary/10 text-primary mb-2">
              <Plus className="h-5 w-5" />
            </div>
            <p className="text-sm font-medium">Create custom role</p>
            <p className="text-xs text-muted-foreground mt-1 max-w-[200px]">Tailor permissions for a unique persona in your org.</p>
          </div>
        </Card>
      </div>

      {/* PERMISSION MATRIX PREVIEW */}
      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-2 pb-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <role.icon className="h-4 w-4 text-primary" />
              {role.name} — permission matrix
            </CardTitle>
            <CardDescription>
              {role.system ? "Preview of system role permissions." : "Customize each resource/action pair."} Currently <span className="font-medium text-foreground">{enabledCount}</span> of {RESOURCES.length * ACTIONS.length} permissions enabled.
            </CardDescription>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {!role.system ? (
              <>
                <Button variant="outline" size="sm" className="text-xs gap-1.5" disabled={!isDirty} onClick={() => { setMatrix(savedMatrix); toast.message("Reverted"); }}>
                  Reset
                </Button>
                <Button size="sm" className="text-xs gap-1.5" disabled={!isDirty} onClick={() => { setSavedMatrix(matrix); toast.success(`${role.name} permissions saved`); }}>
                  <CheckCircle2 className="h-3.5 w-3.5" /> Save
                </Button>
              </>
            ) : (
              <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/40 text-amber-600 bg-amber-500/5">
                <Lock className="h-3 w-3" /> Read-only preview
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-y border-border bg-muted/40">
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 sticky left-0 bg-muted/40 min-w-[140px]">Resource</th>
                  {ACTIONS.map((a) => (
                    <th key={a} className="text-center font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-2.5 min-w-[80px]">{a}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {RESOURCES.map((res) => (
                  <tr key={res} className="hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-2.5 font-medium sticky left-0 bg-card">{res}</td>
                    {ACTIONS.map((a) => {
                      const checked = matrix[res][a];
                      const disabled = role.system;
                      return (
                        <td key={a} className="px-4 py-2.5 text-center">
                          <button
                            type="button"
                            disabled={disabled}
                            onClick={() => toggle(res, a)}
                            className={cn(
                              "inline-grid place-items-center h-6 w-6 rounded-md border transition-all",
                              checked
                                ? "bg-primary border-primary text-primary-foreground"
                                : "bg-card border-border text-transparent hover:border-primary/40",
                              disabled && "opacity-50 cursor-not-allowed hover:border-border"
                            )}
                          >
                            {checked && <CheckCircle2 className="h-3.5 w-3.5" />}
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Legend */}
          <div className="px-4 py-3 border-t border-border bg-muted/20 flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-4">
              <span className="inline-flex items-center gap-1.5">
                <span className="inline-grid place-items-center h-4 w-4 rounded bg-primary text-primary-foreground"><CheckCircle2 className="h-2.5 w-2.5" /></span>
                Enabled
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="inline-grid place-items-center h-4 w-4 rounded border border-border" />
                Disabled
              </span>
            </div>
            {!role.system && (
              <span className="text-[11px]">{isDirty ? "Unsaved changes" : "All changes saved"}</span>
            )}
          </div>
        </CardContent>
      </Card>

      {/* CREATE ROLE DIALOG */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create custom role</DialogTitle>
            <DialogDescription>Define a new persona with a tailored set of permissions.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-1.5">
              <Label className="text-xs">Role name</Label>
              <Input placeholder="e.g. Release Manager" />
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">Description</Label>
              <Textarea rows={2} placeholder="Briefly describe what this role can do." />
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs">Base on existing role</Label>
              <Select>
                <SelectTrigger><SelectValue placeholder="Start from scratch" /></SelectTrigger>
                <SelectContent>
                  {ROLES.filter((r) => r.system).map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground">
              You'll be able to fine-tune permissions in the matrix after creating the role.
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button className="gap-1.5" onClick={() => { setCreateOpen(false); toast.success("Role created", { description: "You can now customize permissions." }); }}>
              <Plus className="h-3.5 w-3.5" /> Create role
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
