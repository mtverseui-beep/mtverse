"use client";

import * as React from "react";
import {
  NotebookText,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  ListTodo,
  Link2,
  Image as ImageIcon,
  Code,
  Quote,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Undo2,
  Redo2,
  Type,
  Save,
  Cloud,
  CheckCircle2,
  Loader2,
  Eye,
  Code2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Tool = {
  cmd: string;
  icon: React.ElementType;
  label: string;
  arg?: string;
  group?: number;
};

const TOOLS: Tool[] = [
  { cmd: "undo", icon: Undo2, label: "Undo", group: 1 },
  { cmd: "redo", icon: Redo2, label: "Redo", group: 1 },
  { cmd: "bold", icon: Bold, label: "Bold", group: 2 },
  { cmd: "italic", icon: Italic, label: "Italic", group: 2 },
  { cmd: "underline", icon: Underline, label: "Underline", group: 2 },
  { cmd: "strikeThrough", icon: Strikethrough, label: "Strikethrough", group: 2 },
  { cmd: "formatBlock", icon: Heading1, label: "Heading 1", arg: "h1", group: 3 },
  { cmd: "formatBlock", icon: Heading2, label: "Heading 2", arg: "h2", group: 3 },
  { cmd: "formatBlock", icon: Heading3, label: "Heading 3", arg: "h3", group: 3 },
  { cmd: "formatBlock", icon: Type, label: "Paragraph", arg: "p", group: 3 },
  { cmd: "insertUnorderedList", icon: List, label: "Bullet list", group: 4 },
  { cmd: "insertOrderedList", icon: ListOrdered, label: "Numbered list", group: 4 },
  { cmd: "formatBlock", icon: Quote, label: "Quote", arg: "blockquote", group: 4 },
  { cmd: "formatBlock", icon: Code, label: "Code block", arg: "pre", group: 4 },
  { cmd: "justifyLeft", icon: AlignLeft, label: "Align left", group: 5 },
  { cmd: "justifyCenter", icon: AlignCenter, label: "Align center", group: 5 },
  { cmd: "justifyRight", icon: AlignRight, label: "Align right", group: 5 },
  { cmd: "justifyFull", icon: AlignJustify, label: "Justify", group: 5 },
];

const INITIAL = `<h1>Welcome to Aurora Release Notes</h1>
<p>This editor supports <strong>bold</strong>, <em>italic</em>, <u>underline</u> and <s>strikethrough</s> formatting out of the box. Use the toolbar above to structure your content.</p>
<h2>Highlights</h2>
<ul>
  <li>Real-time character and word count</li>
  <li>Auto-save indicator every 4 seconds</li>
  <li>HTML and Markdown preview tabs</li>
</ul>
<blockquote>Tip: paste content from anywhere and the formatting will be preserved.</blockquote>`;

// Very small HTML → Markdown converter for preview purposes
function htmlToMarkdown(html: string): string {
  let md = html;
  md = md.replace(/<h1[^>]*>(.*?)<\/h1>/gi, "# $1\n\n");
  md = md.replace(/<h2[^>]*>(.*?)<\/h2>/gi, "## $1\n\n");
  md = md.replace(/<h3[^>]*>(.*?)<\/h3>/gi, "### $1\n\n");
  md = md.replace(/<strong[^>]*>(.*?)<\/strong>/gi, "**$1**");
  md = md.replace(/<b[^>]*>(.*?)<\/b>/gi, "**$1**");
  md = md.replace(/<em[^>]*>(.*?)<\/em>/gi, "*$1*");
  md = md.replace(/<i[^>]*>(.*?)<\/i>/gi, "*$1*");
  md = md.replace(/<u[^>]*>(.*?)<\/u>/gi, "$1");
  md = md.replace(/<s[^>]*>(.*?)<\/s>/gi, "~~$1~~");
  md = md.replace(/<strike[^>]*>(.*?)<\/strike>/gi, "~~$1~~");
  md = md.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (_, c) => c.trim().split("\n").map((l: string) => `> ${l}`).join("\n") + "\n\n");
  md = md.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, "```\n$1\n```\n\n");
  md = md.replace(/<code[^>]*>(.*?)<\/code>/gi, "`$1`");
  md = md.replace(/<li[^>]*>(.*?)<\/li>/gi, "- $1\n");
  md = md.replace(/<\/?(ul|ol)[^>]*>/gi, "\n");
  md = md.replace(/<a [^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/gi, "[$2]($1)");
  md = md.replace(/<img [^>]*src="([^"]+)"[^>]*alt="([^"]*)"[^>]*\/?>/gi, "![$2]($1)");
  md = md.replace(/<br\s*\/?>/gi, "\n");
  md = md.replace(/<\/p>/gi, "\n\n");
  md = md.replace(/<[^>]+>/g, "");
  md = md.replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"');
  md = md.replace(/\n{3,}/g, "\n\n");
  return md.trim();
}

export default function RichTextPage() {
  const editorRef = React.useRef<HTMLDivElement>(null);
  const [html, setHtml] = React.useState(INITIAL);
  const [active, setActive] = React.useState<Record<string, boolean>>({});
  const [savedAt, setSavedAt] = React.useState<Date | null>(null);
  const [saving, setSaving] = React.useState(false);
  const [dirty, setDirty] = React.useState(false);
  const [editorText, setEditorText] = React.useState("");

  // Initialise editor content
  React.useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== INITIAL) {
      editorRef.current.innerHTML = INITIAL;
      setEditorText(editorRef.current.innerText);
    }
  }, []);

  // Track active formatting on selection change
  const refreshActive = React.useCallback(() => {
    if (typeof document === "undefined") return;
    const next: Record<string, boolean> = {};
    ["bold", "italic", "underline", "strikeThrough", "insertUnorderedList", "insertOrderedList", "justifyLeft", "justifyCenter", "justifyRight", "justifyFull"].forEach((c) => {
      try {
        if (document.queryCommandState(c)) next[c] = true;
      } catch {
        // ignore
      }
    });
    setActive(next);
  }, []);

  const exec = (cmd: string, arg?: string) => {
    editorRef.current?.focus();
    document.execCommand(cmd, false, arg);
    refreshActive();
    handleInput();
  };

  const insertLink = () => {
    const url = window.prompt("Enter URL", "https://");
    if (url) {
      exec("createLink", url);
      toast.success("Link inserted");
    }
  };

  const insertImage = () => {
    const url = window.prompt("Enter image URL", "https://images.unsplash.com/photo-1551434678-e076c223a692?w=800");
    if (url) {
      exec("insertImage", url);
      toast.success("Image inserted");
    }
  };

  const insertTodo = () => {
    exec("insertUnorderedList");
  };

  const handleInput = () => {
    if (!editorRef.current) return;
    setHtml(editorRef.current.innerHTML);
    setEditorText(editorRef.current.innerText);
    setDirty(true);
  };

  // Auto-save simulation
  React.useEffect(() => {
    if (!dirty) return;
    setSaving(true);
    const t = setTimeout(() => {
      setSaving(false);
      setSavedAt(new Date());
      setDirty(false);
    }, 1500);
    return () => clearTimeout(t);
  }, [html, dirty]);

  const wordCount = editorText.trim() ? editorText.trim().split(/\s+/).length : 0;
  const charCount = editorText.length;

  const ToolButton = ({ t }: { t: Tool }) => (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      className={cn("h-7 w-7", active[t.cmd] && "bg-accent text-primary")}
      onClick={() => exec(t.cmd, t.arg)}
      title={t.label}
      aria-label={t.label}
    >
      <t.icon className="h-4 w-4" />
    </Button>
  );

  return (
    <>
      <PageHeader
        title="Rich Text Editor"
        description="A custom contentEditable editor with toolbar, live preview and auto-save."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Rich Text Editor" }]}
        icon={NotebookText}
        actions={
          <div className="flex items-center gap-2 rounded-lg border bg-card px-3 py-1.5">
            {saving ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
                <span className="text-xs text-muted-foreground">Saving…</span>
              </>
            ) : savedAt ? (
              <>
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                <span className="text-xs text-muted-foreground">Saved {savedAt.toLocaleTimeString()}</span>
              </>
            ) : (
              <>
                <Cloud className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Auto-save on</span>
              </>
            )}
          </div>
        }
      />

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Release notes — Aurora v3.4</CardTitle>
              <CardDescription>Draft visible to all workspace members. Auto-saves every few seconds.</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Draft saved manually")}>
                <Save className="h-3.5 w-3.5" /> Save now
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="grid gap-0">
          {/* Toolbar */}
          <div className="flex items-center flex-wrap gap-1 rounded-t-lg border border-b-0 bg-muted/40 p-1.5">
            {TOOLS.map((t, i) => {
              const prevGroup = i > 0 ? TOOLS[i - 1].group : 0;
              const showSep = t.group !== prevGroup && i > 0;
              return (
                <React.Fragment key={t.label}>
                  {showSep && <Separator orientation="vertical" className="h-5 mx-0.5" />}
                  <ToolButton t={t} />
                </React.Fragment>
              );
            })}
            <Separator orientation="vertical" className="h-5 mx-0.5" />
            <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={insertLink} title="Insert link" aria-label="Insert link">
              <Link2 className="h-4 w-4" />
            </Button>
            <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={insertImage} title="Insert image" aria-label="Insert image">
              <ImageIcon className="h-4 w-4" />
            </Button>
            <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={insertTodo} title="Insert todo" aria-label="Insert todo">
              <ListTodo className="h-4 w-4" />
            </Button>
          </div>

          {/* Editor + Preview tabs */}
          <Tabs defaultValue="editor" className="gap-0">
            <div className="flex items-center justify-between border-x border-b px-2 py-1.5">
              <TabsList className="h-7">
                <TabsTrigger value="editor" className="text-xs gap-1">
                  <NotebookText className="h-3 w-3" /> Editor
                </TabsTrigger>
                <TabsTrigger value="html" className="text-xs gap-1">
                  <Code2 className="h-3 w-3" /> HTML
                </TabsTrigger>
                <TabsTrigger value="md" className="text-xs gap-1">
                  <Eye className="h-3 w-3" /> Markdown
                </TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                <Badge variant="outline" className="text-[10px] tabular-nums">{wordCount} words</Badge>
                <Badge variant="outline" className="text-[10px] tabular-nums">{charCount} chars</Badge>
              </div>
            </div>

            <TabsContent value="editor" className="mt-0">
              <div
                ref={editorRef}
                contentEditable
                suppressContentEditableWarning
                onInput={handleInput}
                onKeyDown={(e) => {
                  // Avoid toolbar shortcuts stealing focus
                  if ((e.metaKey || e.ctrlKey) && ["b", "i", "u"].includes(e.key)) {
                    setTimeout(refreshActive, 0);
                  }
                }}
                onMouseUp={refreshActive}
                onKeyUp={refreshActive}
                className="min-h-[420px] max-h-[560px] overflow-y-auto rounded-b-lg border bg-background p-5 outline-none prose-sm [&_h1]:text-2xl [&_h1]:font-semibold [&_h1]:mb-2 [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:mt-4 [&_h2]:mb-2 [&_h3]:text-base [&_h3]:font-semibold [&_h3]:mt-3 [&_h3]:mb-1 [&_p]:my-2 [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:my-2 [&_ol]:list-decimal [&_ol]:pl-6 [&_ol]:my-2 [&_blockquote]:border-l-4 [&_blockquote]:border-primary [&_blockquote]:pl-4 [&_blockquote]:italic [&_blockquote]:text-muted-foreground [&_pre]:bg-muted [&_pre]:rounded-md [&_pre]:p-3 [&_pre]:overflow-x-auto [&_pre]:font-mono [&_pre]:text-xs [&_a]:text-primary [&_a]:underline [&_img]:rounded-md [&_img]:max-w-full"
              />
            </TabsContent>

            <TabsContent value="html" className="mt-0">
              <pre className="min-h-[420px] max-h-[560px] overflow-auto rounded-b-lg border bg-muted/30 p-4 text-xs font-mono whitespace-pre-wrap break-words">
                {html}
              </pre>
            </TabsContent>

            <TabsContent value="md" className="mt-0">
              <pre className="min-h-[420px] max-h-[560px] overflow-auto rounded-b-lg border bg-muted/30 p-4 text-xs font-mono whitespace-pre-wrap break-words">
                {htmlToMarkdown(html)}
              </pre>
            </TabsContent>
          </Tabs>

          {/* Footer */}
          <div className="flex items-center justify-between pt-3 text-[11px] text-muted-foreground">
            <div className="flex items-center gap-3">
              <span>Reading time: ~{Math.max(1, Math.round(wordCount / 200))} min</span>
              <Separator orientation="vertical" className="h-3" />
              <span>{html.split("<").length - 1} HTML tags</span>
            </div>
            <span>Press Ctrl/Cmd+B, +I, +U for quick formatting</span>
          </div>
        </CardContent>
      </Card>

      {/* Helper card */}
      <Card className="mt-6 bg-muted/30">
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { t: "Keyboard shortcuts", d: "Standard rich-text shortcuts (Ctrl+B/I/U) work natively inside the editor.", icon: Type },
              { t: "Live preview", d: "Switch to HTML or Markdown tabs to inspect the underlying output instantly.", icon: Code2 },
              { t: "Auto-save", d: "Content is saved to local state after 1.5s of inactivity — extend with your API.", icon: Cloud },
            ].map((tip) => (
              <div key={tip.t} className="flex items-start gap-3">
                <div className="grid place-items-center h-8 w-8 rounded-lg bg-background shrink-0">
                  <tip.icon className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">{tip.t}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{tip.d}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </>
  );
}
