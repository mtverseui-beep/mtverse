"use client";

import * as React from "react";
import {
  CreditCard,
  Crown,
  Check,
  X,
  Sparkles,
  Zap,
  Building2,
  Rocket,
  Shield,
  Calendar,
  TrendingUp,
  AlertTriangle,
  Trash2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Plan = {
  id: string;
  name: string;
  icon: React.ElementType;
  tone: "neutral" | "primary" | "violet" | "warning";
  tagline: string;
  monthly: number;
  annual: number;
  features: string[];
  notIncluded: string[];
  current?: boolean;
  cta: string;
  popular?: boolean;
};

const PLANS: Plan[] = [
  {
    id: "free",
    name: "Free",
    icon: Sparkles,
    tone: "neutral",
    tagline: "For solo builders kicking the tires.",
    monthly: 0,
    annual: 0,
    features: [
      "Up to 3 team members",
      "5 GB file storage",
      "10K API calls / month",
      "Community support",
      "7-day audit log retention",
    ],
    notIncluded: ["SSO & SAML", "Custom roles", "Priority support", "Webhook deliveries"],
    cta: "Downgrade to Free",
  },
  {
    id: "starter",
    name: "Starter",
    icon: Rocket,
    tone: "primary",
    tagline: "For small teams getting serious.",
    monthly: 99,
    annual: 79,
    features: [
      "Up to 8 team members",
      "50 GB file storage",
      "100K API calls / month",
      "50K webhook deliveries",
      "Email support · 24h SLA",
      "30-day audit log retention",
    ],
    notIncluded: ["SSO & SAML", "Custom roles", "Priority support"],
    cta: "Choose Starter",
  },
  {
    id: "pro",
    name: "Pro",
    icon: Zap,
    tone: "violet",
    tagline: "For growing teams that need power and scale.",
    monthly: 249,
    annual: 199,
    features: [
      "Up to 20 team members",
      "250 GB file storage",
      "1M API calls / month",
      "500K webhook deliveries",
      "Advanced role permissions",
      "SSO & SAML",
      "Priority support · 4h SLA",
      "90-day audit log retention",
    ],
    notIncluded: ["Dedicated CSM", "Custom contracts"],
    current: true,
    popular: true,
    cta: "Current plan",
  },
  {
    id: "enterprise",
    name: "Enterprise",
    icon: Building2,
    tone: "warning",
    tagline: "For orgs with security and compliance needs.",
    monthly: 0,
    annual: 0,
    features: [
      "Unlimited team members",
      "Unlimited storage",
      "Custom API limits",
      "Dedicated CSM",
      "99.99% uptime SLA",
      "Custom contracts & invoicing",
      "On-prem deployment option",
      "SOC 2 Type II report",
    ],
    notIncluded: [],
    cta: "Contact sales",
  },
];

const toneRing: Record<string, string> = {
  neutral: "ring-border",
  primary: "ring-primary/40",
  violet: "ring-violet-500/40",
  warning: "ring-[color:var(--warning)]/40",
};

const toneIconBg: Record<string, string> = {
  neutral: "bg-muted text-muted-foreground",
  primary: "bg-primary/12 text-primary",
  violet: "bg-violet-500/12 text-violet-500",
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
};

const toneBadge: Record<string, "neutral" | "primary" | "violet" | "warning"> = {
  neutral: "neutral",
  primary: "primary",
  violet: "violet",
  warning: "warning",
};

export default function SubscriptionPage() {
  const [cycle, setCycle] = React.useState<"monthly" | "annual">("monthly");
  const [cancelTyped, setCancelTyped] = React.useState("");

  const annualSavings = (plan: Plan) => {
    if (plan.monthly === 0 || plan.annual === 0) return null;
    const monthlyYearly = plan.monthly * 12;
    const annualYearly = plan.annual * 12;
    return Math.round(((monthlyYearly - annualYearly) / monthlyYearly) * 100);
  };

  return (
    <>
      <PageHeader
        title="Subscription"
        description="Your plan, your cycle, your terms. Compare every tier and switch when you're ready."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Admin" }, { label: "Subscription" }]}
        icon={CreditCard}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening billing portal")}>
            <CreditCard className="h-3.5 w-3.5" /> Manage billing
          </Button>
        }
      />

      {/* CURRENT PLAN BANNER */}
      <Card className="mb-6 relative overflow-hidden border-primary/30">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/[0.06] via-primary/[0.02] to-transparent" aria-hidden />
        <CardContent className="relative p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="grid place-items-center h-14 w-14 rounded-xl bg-primary/12 text-primary shrink-0">
              <Zap className="h-7 w-7" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <h2 className="text-xl font-semibold">Pro plan</h2>
                <StatusBadge tone="success" dot>Active</StatusBadge>
                <Badge variant="outline" className="text-[10px] gap-1 border-primary/30 text-primary bg-primary/5">
                  <Crown className="h-2.5 w-2.5" /> Most popular
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                You're billed <span className="font-medium text-foreground">${cycle === "monthly" ? "249" : "199"}/mo</span> on the {cycle} cycle. Next renewal: <span className="font-medium text-foreground">Aug 14, 2026</span>.
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={() => toast.message("Opening invoices")}>
                <Calendar className="h-3.5 w-3.5" /> View invoices
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* BILLING CYCLE TOGGLE */}
      <div className="flex items-center justify-center mb-6">
        <div className="inline-flex items-center gap-1 p-1 rounded-full border border-border bg-card">
          <button
            type="button"
            onClick={() => setCycle("monthly")}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-medium transition-all",
              cycle === "monthly" ? "bg-primary text-primary-foreground shadow-premium-xs" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Monthly
          </button>
          <button
            type="button"
            onClick={() => setCycle("annual")}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-medium transition-all inline-flex items-center gap-1.5",
              cycle === "annual" ? "bg-primary text-primary-foreground shadow-premium-xs" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Annual
            <Badge variant="outline" className="text-[9px] py-0 h-4 border-[color:var(--success)]/40 text-[color:var(--success)] bg-[color:var(--success)]/5">Save 20%</Badge>
          </button>
        </div>
      </div>

      {/* PLAN COMPARISON CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {PLANS.map((p) => {
          const savings = annualSavings(p);
          return (
            <Card
              key={p.id}
              className={cn(
                "relative flex flex-col p-5 transition-all",
                p.current ? `ring-2 ${toneRing[p.tone]} border-transparent shadow-premium-md` : "hover:shadow-premium-sm",
                p.popular && !p.current && "ring-1 ring-violet-500/30"
              )}
            >
              {p.popular && (
                <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                  <Badge className="text-[10px] gap-1 bg-violet-500 text-white hover:bg-violet-500">
                    <Sparkles className="h-2.5 w-2.5" /> Most popular
                  </Badge>
                </div>
              )}
              <div className="flex items-center gap-2.5 mb-3">
                <div className={cn("grid place-items-center h-10 w-10 rounded-lg", toneIconBg[p.tone])}>
                  <p.icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold">{p.name}</h3>
                  <p className="text-[11px] text-muted-foreground line-clamp-1">{p.tagline}</p>
                </div>
              </div>

              <div className="mb-4">
                {p.id === "free" ? (
                  <>
                    <p className="text-3xl font-semibold tabular-nums">$0<span className="text-base text-muted-foreground font-normal">/mo</span></p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">Free forever</p>
                  </>
                ) : p.id === "enterprise" ? (
                  <>
                    <p className="text-3xl font-semibold">Custom</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">Annual contracts</p>
                  </>
                ) : (
                  <>
                    <p className="text-3xl font-semibold tabular-nums">
                      ${cycle === "monthly" ? p.monthly : p.annual}
                      <span className="text-base text-muted-foreground font-normal">/mo</span>
                    </p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">
                      {cycle === "annual" ? `Billed annually · $${(p.annual * 12).toLocaleString()}/yr` : "Billed monthly"}
                      {savings && cycle === "annual" && (
                        <span className="text-[color:var(--success)] font-medium ml-1">· Save {savings}%</span>
                      )}
                    </p>
                  </>
                )}
              </div>

              <Separator className="mb-3" />

              <ul className="space-y-1.5 flex-1 mb-4">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-xs">
                    <Check className="h-3.5 w-3.5 text-[color:var(--success)] shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </li>
                ))}
                {p.notIncluded.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-xs text-muted-foreground/60">
                    <X className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0 mt-0.5" />
                    <span className="line-through">{f}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={p.current ? "outline" : p.id === "free" ? "outline" : "default"}
                className="w-full text-xs gap-1.5"
                disabled={p.current}
                onClick={() => {
                  if (p.id === "enterprise") toast.success("Sales team notified", { description: "We'll be in touch within 1 business day." });
                  else if (p.id === "free") toast.success("Downgrade scheduled", { description: "Your plan changes at the end of the cycle." });
                  else toast.success(`Switching to ${p.name}`, { description: `New rate: $${cycle === "monthly" ? p.monthly : p.annual}/mo.` });
                }}
              >
                {p.current && <Check className="h-3.5 w-3.5" />}
                {p.id === "enterprise" && <Shield className="h-3.5 w-3.5" />}
                {p.cta}
              </Button>
            </Card>
          );
        })}
      </div>

      {/* COMPARISON TABLE */}
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" /> Detailed feature comparison
          </CardTitle>
          <CardDescription>The full breakdown across every plan.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-y border-border bg-muted/40">
                  <th className="text-left font-medium text-xs uppercase tracking-wide text-muted-foreground px-4 py-3 min-w-[220px]">Feature</th>
                  {PLANS.map((p) => (
                    <th key={p.id} className="px-4 py-3 text-center min-w-[120px]">
                      <div className="flex flex-col items-center gap-1">
                        <p.icon className={cn("h-4 w-4", p.tone === "primary" ? "text-primary" : p.tone === "violet" ? "text-violet-500" : p.tone === "warning" ? "text-[color:var(--warning)]" : "text-muted-foreground")} />
                        <span className="text-xs font-semibold">{p.name}</span>
                        {p.current && <StatusBadge tone="success" dot>Current</StatusBadge>}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {[
                  { label: "Team members", values: ["3", "8", "20", "Unlimited"] },
                  { label: "File storage", values: ["5 GB", "50 GB", "250 GB", "Unlimited"] },
                  { label: "API calls / month", values: ["10K", "100K", "1M", "Custom"] },
                  { label: "Webhook deliveries", values: ["—", "50K", "500K", "Unlimited"] },
                  { label: "Audit log retention", values: ["7 days", "30 days", "90 days", "1 year"] },
                  { label: "SSO & SAML", values: [false, false, true, true] },
                  { label: "Custom roles", values: [false, false, true, true] },
                  { label: "Priority support", values: [false, false, true, true] },
                  { label: "Dedicated CSM", values: [false, false, false, true] },
                  { label: "Uptime SLA", values: ["—", "99.9%", "99.95%", "99.99%"] },
                ].map((row) => (
                  <tr key={row.label} className="hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-2.5 font-medium">{row.label}</td>
                    {row.values.map((v, i) => (
                      <td key={i} className="px-4 py-2.5 text-center">
                        {typeof v === "boolean" ? (
                          v ? <Check className="h-4 w-4 text-[color:var(--success)] mx-auto" /> : <X className="h-4 w-4 text-muted-foreground/30 mx-auto" />
                        ) : (
                          <span className="text-sm tabular-nums">{v}</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* DANGER ZONE */}
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-4 w-4" /> Cancel subscription
          </CardTitle>
          <CardDescription>Downgrade to the Free plan at the end of your current billing cycle.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-destructive/20 bg-destructive/[0.02] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-sm font-medium">What happens when you cancel?</p>
              <ul className="text-xs text-muted-foreground mt-1.5 space-y-0.5 list-disc list-inside">
                <li>Your plan remains active until <span className="font-medium text-foreground">Aug 14, 2026</span>.</li>
                <li>After that, you'll be moved to Free with limited features.</li>
                <li>Excess team members and data may be archived.</li>
                <li>Billing history and invoices are retained for 7 years.</li>
              </ul>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" className="gap-1.5 shrink-0">
                  <Trash2 className="h-3.5 w-3.5" /> Cancel subscription
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-destructive">Cancel your Pro subscription?</AlertDialogTitle>
                  <AlertDialogDescription>
                    You'll keep Pro features until Aug 14, 2026, then move to the Free plan. To confirm, type <span className="font-mono font-semibold text-foreground">CANCEL</span> below.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <input
                  type="text"
                  value={cancelTyped}
                  onChange={(e) => setCancelTyped(e.target.value)}
                  placeholder="Type CANCEL to confirm"
                  className="font-mono h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
                />
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setCancelTyped("")}>Keep my plan</AlertDialogCancel>
                  <AlertDialogAction
                    disabled={cancelTyped !== "CANCEL"}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    onClick={() => { setCancelTyped(""); toast.error("Subscription cancelled", { description: "You'll move to Free on Aug 14, 2026." }); }}
                  >
                    Cancel subscription
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
