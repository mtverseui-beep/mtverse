"use client";

import * as React from "react";
import {
  Users,
  UserPlus,
  UserMinus,
  Heart,
  Filter,
  Download,
  Check,
  X,
  CalendarDays,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BarTrendChart, DonutChart } from "@/components/charts";
import { hrHeadcount, hrAttrition, salesReps } from "@/data/mock-data";
import { cn } from "@/lib/utils";

/* ---------- Inline HR data ---------- */

// Employee directory preview — 6 cards. People-centric, warm accents.
const employees = [
  { name: "Sarah Chen", role: "Staff Engineer", dept: "Engineering", deptTone: "primary" as StatusTone, status: "active" as const, avatar: salesReps[0].avatar },
  { name: "Marcus Reyes", role: "Account Executive", dept: "Sales", deptTone: "warning" as StatusTone, status: "away" as const, avatar: salesReps[1].avatar },
  { name: "Elena Petrov", role: "Product Designer", dept: "Design", deptTone: "violet" as StatusTone, status: "active" as const, avatar: salesReps[2].avatar },
  { name: "James Okoro", role: "DevOps Engineer", dept: "Engineering", deptTone: "primary" as StatusTone, status: "offline" as const, avatar: salesReps[3].avatar },
  { name: "Aiko Tanaka", role: "Marketing Manager", dept: "Marketing", deptTone: "info" as StatusTone, status: "active" as const, avatar: salesReps[4].avatar },
  { name: "David Kim", role: "Customer Success", dept: "Support", deptTone: "success" as StatusTone, status: "away" as const, avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
];

// Pending leave requests — 4 items
const leaveRequests = [
  { name: "Sarah Chen", avatar: salesReps[0].avatar, dates: "Jul 08 – Jul 12", type: "Vacation", typeTone: "info" as StatusTone, days: 5 },
  { name: "James Okoro", avatar: salesReps[3].avatar, dates: "Jul 10 – Jul 11", type: "Personal", typeTone: "violet" as StatusTone, days: 2 },
  { name: "Elena Petrov", avatar: salesReps[2].avatar, dates: "Jul 15 – Jul 19", type: "Vacation", typeTone: "info" as StatusTone, days: 5 },
  { name: "Aiko Tanaka", avatar: salesReps[4].avatar, dates: "Jul 22", type: "Sick", typeTone: "warning" as StatusTone, days: 1 },
];

// Department distribution data — derived from hrHeadcount for the footer donut
const deptDistribution = hrHeadcount.map((d, i) => {
  const palette = [
    "var(--primary)",
    "oklch(0.70 0.15 75)",
    "var(--info)",
    "oklch(0.62 0.18 25)",
    "oklch(0.58 0.13 250)",
    "oklch(0.62 0.18 305)",
  ];
  return { name: d.dept, value: d.current, color: palette[i % palette.length] };
});

/* ---------- HR KPI card — people-centric, warm accents ---------- */
// Distinct from all existing KPI cards:
// - Top horizontal warm accent strip (gradient bar) — distinct from
//   CRM/finance left-edge accent, marketing gradient blob, projects sprint strip
// - Mini 7-week bar trend (warm tinted) instead of sparkline or quota bar
// - Warm color palette (amber / orange / rose / yellow) throughout
// - Icon tile uses warm tinted background

function HrKpiCard({
  label,
  value,
  unit,
  icon: Icon,
  trend,
  trendLabel,
  trendDirection, // whether "up" is good (positive) or bad
  sparkData,
  accent,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: LucideIcon;
  trend: { value: number; direction: "up" | "down" };
  trendLabel: string;
  trendDirection: "good" | "bad"; // is "up" good or bad?
  sparkData: number[];
  accent: "amber" | "orange" | "rose" | "yellow";
}) {
  // Static accent maps so Tailwind v4 can detect them
  const accentStrip: Record<string, string> = {
    amber: "from-amber-500/0 via-amber-500 to-amber-500/0",
    orange: "from-orange-500/0 via-orange-500 to-orange-500/0",
    rose: "from-rose-500/0 via-rose-500 to-rose-500/0",
    yellow: "from-yellow-500/0 via-yellow-500 to-yellow-500/0",
  };
  const accentTile: Record<string, string> = {
    amber: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
    orange: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
    rose: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
    yellow: "bg-yellow-500/15 text-yellow-600 dark:text-yellow-400",
  };
  const accentBar: Record<string, string> = {
    amber: "bg-amber-500",
    orange: "bg-orange-500",
    rose: "bg-rose-500",
    yellow: "bg-yellow-500",
  };

  const isUp = trend.direction === "up";
  const isGood = trendDirection === "good" ? isUp : !isUp;

  const max = Math.max(...sparkData);
  const min = Math.min(...sparkData);
  const range = max - min || 1;

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card transition-all hover:shadow-premium-sm">
      {/* Top warm accent strip — distinct from left-edge + gradient blob */}
      <div className={cn("h-1 w-full bg-gradient-to-r", accentStrip[accent])} />

      <div className="p-5 pt-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
              {label}
            </p>
            <div className="mt-1.5 flex items-baseline gap-1">
              <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
              {unit && <span className="text-sm font-semibold text-muted-foreground tabular-nums">{unit}</span>}
            </div>
          </div>
          <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentTile[accent])}>
            <Icon className="h-4.5 w-4.5" />
          </div>
        </div>

        {/* Mini 7-week bar trend — distinct from sparkline */}
        <div className="mt-3 flex items-end gap-1 h-8" aria-hidden>
          {sparkData.map((v, i) => {
            const h = ((v - min) / range) * 100;
            const opacity = 0.35 + (i / (sparkData.length - 1)) * 0.65;
            return (
              <div
                key={i}
                className={cn("flex-1 rounded-sm transition-all", accentBar[accent])}
                style={{ height: `${Math.max(8, h)}%`, opacity }}
              />
            );
          })}
        </div>

        {/* Trend pill + caption */}
        <div className="mt-3 flex items-center gap-1.5">
          <span
            className={cn(
              "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium tabular-nums",
              isGood
                ? "bg-[color:var(--success)]/12 text-[color:var(--success)]"
                : "bg-destructive/12 text-destructive"
            )}
          >
            {isUp ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
            {Math.abs(trend.value)}
          </span>
          <span className="text-xs text-muted-foreground truncate">{trendLabel}</span>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function HrDashboardPage() {
  const totalHeadcount = hrHeadcount.reduce((s, x) => s + x.current, 0);
  const totalOpen = hrHeadcount.reduce((s, x) => s + x.openRoles, 0);
  const totalTeam = totalHeadcount + totalOpen;
  const maxDeptSize = Math.max(...hrHeadcount.map((d) => d.current + d.openRoles));

  return (
    <>
      <PageHeader
        title="HR Dashboard"
        description="Headcount, hiring, attrition, and team sentiment across the organization."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Dashboards" }, { label: "HR" }]}
        icon={Users}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="h-3.5 w-3.5" /> Q3 2026
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5 bg-amber-600 text-white hover:bg-amber-600/90">
              <UserPlus className="h-3.5 w-3.5" /> Open role
            </Button>
          </>
        }
      />

      {/* KPI Row — HrKpiCard with warm accent strip + mini bar trend */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <HrKpiCard
          label="Headcount"
          value="228"
          icon={Users}
          accent="amber"
          trend={{ value: 12, direction: "up" }}
          trendDirection="good"
          trendLabel="net new this Q"
          sparkData={[210, 214, 218, 216, 221, 224, 228]}
        />
        <HrKpiCard
          label="Open Roles"
          value="21"
          icon={UserPlus}
          accent="orange"
          trend={{ value: 4, direction: "down" }}
          trendDirection="good"
          trendLabel="vs. 25 last month"
          sparkData={[25, 24, 26, 23, 22, 23, 21]}
        />
        <HrKpiCard
          label="Attrition"
          value="4.2"
          unit="%"
          icon={UserMinus}
          accent="rose"
          trend={{ value: 0.4, direction: "up" }}
          trendDirection="bad"
          trendLabel="higher is worse"
          sparkData={[3.4, 3.6, 3.8, 3.9, 4.0, 4.1, 4.2]}
        />
        <HrKpiCard
          label="Satisfaction"
          value="8.4"
          unit="/10"
          icon={Heart}
          accent="yellow"
          trend={{ value: 0.2, direction: "up" }}
          trendDirection="good"
          trendLabel="pulse survey score"
          sparkData={[7.8, 8.0, 7.9, 8.1, 8.2, 8.3, 8.4]}
        />
      </div>

      {/* Headcount by dept + Hiring & attrition trend */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                Headcount by Department
              </CardTitle>
              <CardDescription>
                Current team and open roles — {totalTeam} total positions.
              </CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" /> Current
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-amber-500" /> Open
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={hrHeadcount}
              xKey="dept"
              series={[
                { key: "current", name: "Current", color: "var(--primary)" },
                { key: "openRoles", name: "Open Roles", color: "oklch(0.75 0.18 75)" },
              ]}
              stacked
              horizontal
              height={280}
            />
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-3 gap-2">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total HC</p>
                <p className="text-sm font-semibold tabular-nums mt-0.5">{totalHeadcount}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Open Roles</p>
                <p className="text-sm font-semibold text-amber-600 dark:text-amber-400 tabular-nums mt-0.5">{totalOpen}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Largest Dept</p>
                <p className="text-sm font-semibold mt-0.5">Engineering</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                Hiring & Attrition Trend
              </CardTitle>
              <CardDescription>Monthly hires vs. departures over the trailing year.</CardDescription>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)]" /> Hires
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-rose-500" /> Departures
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <BarTrendChart
              data={hrAttrition}
              xKey="month"
              series={[
                { key: "hires", name: "Hires", color: "var(--success)" },
                { key: "departures", name: "Departures", color: "oklch(0.65 0.20 20)" },
              ]}
              height={280}
            />
            <div className="mt-3 pt-3 border-t border-border grid grid-cols-3 gap-2">
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total Hires</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                  {hrAttrition.reduce((s, x) => s + x.hires, 0)}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Total Exits</p>
                <p className="text-sm font-semibold text-rose-500 tabular-nums mt-0.5">
                  {hrAttrition.reduce((s, x) => s + x.departures, 0)}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Net Growth</p>
                <p className="text-sm font-semibold text-[color:var(--success)] tabular-nums mt-0.5">
                  +{hrAttrition.reduce((s, x) => s + x.hires - x.departures, 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Employee directory + Leave requests */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-6">
        <Card className="xl:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                Employee Directory
              </CardTitle>
              <CardDescription>A preview of your team across departments.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs gap-1">
              View all <ArrowUpRight className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {employees.map((e) => {
                const statusDot = e.status === "active"
                  ? "bg-[color:var(--success)]"
                  : e.status === "away"
                  ? "bg-[color:var(--warning)]"
                  : "bg-muted-foreground";
                const statusLabel = e.status === "active" ? "Active" : e.status === "away" ? "Away" : "Offline";
                return (
                  <div
                    key={e.name}
                    className="group relative flex flex-col gap-3 rounded-lg border border-border bg-muted/20 p-4 hover:bg-muted/40 hover:border-amber-500/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative shrink-0">
                        <Avatar className="h-11 w-11 ring-2 ring-card">
                          <AvatarImage src={e.avatar} alt={e.name} />
                          <AvatarFallback className="text-xs">
                            {e.name.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <span
                          className={cn(
                            "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ring-2 ring-card",
                            statusDot
                          )}
                          title={statusLabel}
                          aria-label={`Status: ${statusLabel}`}
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-foreground truncate">{e.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{e.role}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <StatusBadge tone={e.deptTone}>{e.dept}</StatusBadge>
                      <span className="text-[10px] text-muted-foreground capitalize">{statusLabel}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Leave requests — pending approvals */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                Leave Requests
              </CardTitle>
              <CardDescription>{leaveRequests.length} pending approvals.</CardDescription>
            </div>
            <StatusBadge tone="warning" dot>Pending</StatusBadge>
          </CardHeader>
          <CardContent className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1 custom-scroll">
            {leaveRequests.map((r, i) => (
              <div
                key={i}
                className="rounded-lg border border-border bg-muted/20 p-3 hover:bg-muted/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Avatar className="h-9 w-9 shrink-0">
                    <AvatarImage src={r.avatar} alt={r.name} />
                    <AvatarFallback className="text-[10px]">
                      {r.name.split(" ").map((n) => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground truncate">{r.name}</p>
                    <p className="text-xs text-muted-foreground tabular-nums truncate">
                      {r.dates} · {r.days} day{r.days > 1 ? "s" : ""}
                    </p>
                  </div>
                  <StatusBadge tone={r.typeTone}>{r.type}</StatusBadge>
                </div>
                {/* Approve / reject buttons — UI only */}
                <div className="mt-3 flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 flex-1 text-xs gap-1 border-[color:var(--success)]/30 text-[color:var(--success)] hover:bg-[color:var(--success)]/10 hover:text-[color:var(--success)]"
                  >
                    <Check className="h-3 w-3" /> Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 flex-1 text-xs gap-1 border-destructive/30 text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    <X className="h-3 w-3" /> Reject
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Department distribution donut — full width footer card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              Department Distribution
            </CardTitle>
            <CardDescription>Share of total headcount across the organization.</CardDescription>
          </div>
          <StatusBadge tone="primary" dot>{totalHeadcount} employees</StatusBadge>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6 items-center">
            <div className="mx-auto w-full max-w-[280px]">
              <DonutChart
                data={deptDistribution}
                centerLabel="Total"
                centerValue={totalHeadcount.toString()}
                height={240}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {deptDistribution.map((d) => {
                const pct = ((d.value / totalHeadcount) * 100).toFixed(1);
                const widthPct = (d.value / maxDeptSize) * 100;
                return (
                  <div key={d.name} className="rounded-lg border border-border bg-muted/20 p-3">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="h-2 w-2 rounded-full shrink-0" style={{ background: d.color }} />
                        <span className="font-medium text-foreground truncate">{d.name}</span>
                      </div>
                      <span className="text-muted-foreground tabular-nums shrink-0">{pct}%</span>
                    </div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg font-semibold tabular-nums">{d.value}</span>
                      <span className="text-[10px] text-muted-foreground">employees</span>
                    </div>
                    <div className="mt-2 h-1.5 w-full rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-700 ease-out"
                        style={{ width: `${widthPct}%`, background: d.color }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
