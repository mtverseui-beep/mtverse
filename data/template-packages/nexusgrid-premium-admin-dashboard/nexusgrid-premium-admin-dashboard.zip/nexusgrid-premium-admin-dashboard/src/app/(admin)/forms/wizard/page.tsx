"use client";

import * as React from "react";
import {
  Loader,
  Mail,
  Lock,
  Eye,
  EyeOff,
  User,
  CalendarDays,
  UploadCloud,
  Building2,
  MapPin,
  Globe,
  Check,
  CheckCircle2,
  ArrowLeft,
  ArrowRight,
  UserCircle,
  Home,
  Sparkles,
  FileText,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { format } from "date-fns";

type WizardData = {
  email: string;
  password: string;
  fullName: string;
  dob?: Date;
  avatar: string | null;
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
};

const STEPS = [
  { id: 1, title: "Account", description: "Sign-in credentials", icon: Mail },
  { id: 2, title: "Personal", description: "Profile details", icon: User },
  { id: 3, title: "Address", description: "Shipping location", icon: Home },
  { id: 4, title: "Review", description: "Confirm and submit", icon: FileText },
];

export default function FormWizardPage() {
  const [step, setStep] = React.useState(1);
  const [data, setData] = React.useState<WizardData>({
    email: "",
    password: "",
    fullName: "",
    dob: undefined,
    avatar: null,
    street: "",
    city: "",
    state: "",
    zip: "",
    country: "us",
  });
  const [errors, setErrors] = React.useState<Partial<Record<keyof WizardData, string>>>({});
  const [showPwd, setShowPwd] = React.useState(false);
  const [done, setDone] = React.useState(false);

  const set = <K extends keyof WizardData>(k: K, v: WizardData[K]) => {
    setData((d) => ({ ...d, [k]: v }));
    setErrors((e) => ({ ...e, [k]: undefined }));
  };

  const validateStep = (s: number): boolean => {
    const e: Partial<Record<keyof WizardData, string>> = {};
    if (s === 1) {
      if (!data.email) e.email = "Email is required";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) e.email = "Enter a valid email";
      if (!data.password) e.password = "Password is required";
      else if (data.password.length < 8) e.password = "Use at least 8 characters";
    }
    if (s === 2) {
      if (!data.fullName) e.fullName = "Name is required";
      else if (data.fullName.length < 2) e.fullName = "Name is too short";
      if (!data.dob) e.dob = "Pick your date of birth";
    }
    if (s === 3) {
      if (!data.street) e.street = "Street is required";
      if (!data.city) e.city = "City is required";
      if (!data.state) e.state = "State is required";
      if (!data.zip) e.zip = "Postal code is required";
      else if (!/^[\w\s-]{3,}$/.test(data.zip)) e.zip = "Invalid postal code";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (!validateStep(step)) {
      toast.error("Please fix the errors before continuing");
      return;
    }
    setStep((s) => Math.min(4, s + 1));
  };

  const back = () => setStep((s) => Math.max(1, s - 1));

  const finalize = () => {
    setDone(true);
    toast.success("Welcome to Aurora!", { description: `Account created for ${data.fullName}` });
  };

  const onAvatar = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast.error("Please upload an image file");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => set("avatar", reader.result as string);
    reader.readAsDataURL(f);
  };

  if (done) {
    return (
      <>
        <PageHeader
          title="Form Wizard"
          description="A guided four-step flow with per-step validation and a final review screen."
          breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Form Wizard" }]}
          icon={Loader}
        />
        <Card className="max-w-xl mx-auto text-center">
          <CardContent className="py-12 grid place-items-center gap-4">
            <div className="grid place-items-center h-16 w-16 rounded-full bg-emerald-500/10 text-emerald-500">
              <CheckCircle2 className="h-8 w-8" />
            </div>
            <div>
              <h2 className="text-xl font-semibold">You're all set, {data.fullName.split(" ")[0]}!</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Your Aurora account has been created. A verification email is on its way to{" "}
                <span className="font-medium text-foreground">{data.email}</span>.
              </p>
            </div>
            <div className="grid gap-1.5 w-full max-w-sm mt-4 text-xs text-left rounded-lg border p-4 bg-muted/30">
              <div className="flex justify-between"><span className="text-muted-foreground">Email</span><span className="font-medium">{data.email}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Name</span><span className="font-medium">{data.fullName}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Date of birth</span><span className="font-medium">{data.dob ? format(data.dob, "PPP") : "—"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Address</span><span className="font-medium text-right max-w-[60%] truncate">{data.street}, {data.city}</span></div>
            </div>
            <Button onClick={() => { setStep(1); setDone(false); setData({ email: "", password: "", fullName: "", dob: undefined, avatar: null, street: "", city: "", state: "", zip: "", country: "us" }); }}>
              Create another account
            </Button>
          </CardContent>
        </Card>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Form Wizard"
        description="A guided four-step flow with per-step validation and a final review screen."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Form Wizard" }]}
        icon={Loader}
        actions={<Badge variant="secondary" className="text-[10px] uppercase tracking-wide">Step {step} of 4</Badge>}
      />

      {/* Progress */}
      <Card className="mb-6">
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {STEPS.map((s) => {
              const isDone = step > s.id;
              const isCurrent = step === s.id;
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => {
                    if (s.id < step) setStep(s.id);
                  }}
                  disabled={s.id > step}
                  className={cn(
                    "flex items-center gap-3 text-left rounded-lg border p-3 transition-colors",
                    isCurrent && "border-primary bg-primary/5 ring-1 ring-primary/30",
                    isDone && "border-emerald-500/40 bg-emerald-500/5",
                    !isCurrent && !isDone && "border-border bg-card",
                    s.id < step && "cursor-pointer hover:bg-accent/40",
                    s.id > step && "opacity-60 cursor-not-allowed"
                  )}
                >
                  <div
                    className={cn(
                      "grid place-items-center h-9 w-9 rounded-full shrink-0 text-sm font-semibold",
                      isDone && "bg-emerald-500 text-white",
                      isCurrent && !isDone && "bg-primary text-primary-foreground",
                      !isCurrent && !isDone && "bg-muted text-muted-foreground"
                    )}
                  >
                    {isDone ? <Check className="h-4 w-4" /> : s.id}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <s.icon className="h-3.5 w-3.5 text-muted-foreground" />
                      <p className="text-sm font-medium truncate">{s.title}</p>
                    </div>
                    <p className="text-[11px] text-muted-foreground truncate">{s.description}</p>
                  </div>
                </button>
              );
            })}
          </div>
          {/* Progress bar */}
          <div className="mt-4 h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-500"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            {(() => {
              const Icon = STEPS[step - 1].icon;
              return (
                <div className="grid place-items-center h-8 w-8 rounded-lg bg-primary/10 text-primary">
                  <Icon className="h-4 w-4" />
                </div>
              );
            })()}
            <div>
              <CardTitle className="text-base">{STEPS[step - 1].title}</CardTitle>
              <CardDescription>{STEPS[step - 1].description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="grid gap-5">
          {/* STEP 1: Account */}
          {step === 1 && (
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="grid gap-1.5 sm:col-span-2">
                <Label className="text-xs flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-muted-foreground" /> Email address
                </Label>
                <Input
                  type="email"
                  placeholder="you@example.com"
                  value={data.email}
                  onChange={(e) => set("email", e.target.value)}
                  aria-invalid={!!errors.email}
                />
                {errors.email && <p className="text-[11px] text-destructive">{errors.email}</p>}
              </div>
              <div className="grid gap-1.5 sm:col-span-2">
                <Label className="text-xs flex items-center gap-1.5">
                  <Lock className="h-3.5 w-3.5 text-muted-foreground" /> Password
                </Label>
                <div className="relative">
                  <Input
                    type={showPwd ? "text" : "password"}
                    placeholder="At least 8 characters"
                    value={data.password}
                    onChange={(e) => set("password", e.target.value)}
                    aria-invalid={!!errors.password}
                    className="pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd((s) => !s)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                    aria-label={showPwd ? "Hide password" : "Show password"}
                  >
                    {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.password && <p className="text-[11px] text-destructive">{errors.password}</p>}
              </div>
              <div className="sm:col-span-2 rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground flex items-start gap-2">
                <Sparkles className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                <span>Use a strong, unique password. We recommend enabling two-factor authentication after sign-up.</span>
              </div>
            </div>
          )}

          {/* STEP 2: Personal */}
          {step === 2 && (
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2 flex items-center gap-4">
                <Avatar className="h-20 w-20 border-2 border-dashed border-border">
                  {data.avatar ? (
                    <img src={data.avatar} alt="Avatar preview" className="h-full w-full object-cover rounded-full" />
                  ) : null}
                  <AvatarFallback>
                    <UserCircle className="h-10 w-10 text-muted-foreground" />
                  </AvatarFallback>
                </Avatar>
                <div className="grid gap-1.5">
                  <Label className="text-xs">Profile picture</Label>
                  <p className="text-[11px] text-muted-foreground">JPG, PNG or GIF up to 2MB. Square aspect ratio recommended.</p>
                  <div className="flex gap-2">
                    <label>
                      <input type="file" accept="image/*" onChange={onAvatar} className="hidden" />
                      <span className="inline-flex items-center gap-1.5 rounded-md border bg-background px-3 h-8 text-xs cursor-pointer hover:bg-accent">
                        <UploadCloud className="h-3.5 w-3.5" /> Upload
                      </span>
                    </label>
                    {data.avatar && (
                      <Button variant="ghost" size="sm" onClick={() => set("avatar", null)} className="h-8 text-xs">
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
              </div>
              <Separator className="sm:col-span-2" />
              <div className="grid gap-1.5">
                <Label className="text-xs flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5 text-muted-foreground" /> Full name
                </Label>
                <Input
                  placeholder="Sarah Chen"
                  value={data.fullName}
                  onChange={(e) => set("fullName", e.target.value)}
                  aria-invalid={!!errors.fullName}
                />
                {errors.fullName && <p className="text-[11px] text-destructive">{errors.fullName}</p>}
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" /> Date of birth
                </Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !data.dob && "text-muted-foreground",
                        errors.dob && "border-destructive"
                      )}
                    >
                      <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                      {data.dob ? format(data.dob, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={data.dob}
                      onSelect={(d) => set("dob", d)}
                      disabled={(d) => d > new Date() || d < new Date("1900-01-01")}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                {errors.dob && <p className="text-[11px] text-destructive">{errors.dob}</p>}
              </div>
            </div>
          )}

          {/* STEP 3: Address */}
          {step === 3 && (
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="grid gap-1.5 sm:col-span-2">
                <Label className="text-xs flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-muted-foreground" /> Street address
                </Label>
                <Input
                  placeholder="1140 Mission St, Suite 400"
                  value={data.street}
                  onChange={(e) => set("street", e.target.value)}
                  aria-invalid={!!errors.street}
                />
                {errors.street && <p className="text-[11px] text-destructive">{errors.street}</p>}
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs flex items-center gap-1.5">
                  <Building2 className="h-3.5 w-3.5 text-muted-foreground" /> City
                </Label>
                <Input
                  placeholder="San Francisco"
                  value={data.city}
                  onChange={(e) => set("city", e.target.value)}
                  aria-invalid={!!errors.city}
                />
                {errors.city && <p className="text-[11px] text-destructive">{errors.city}</p>}
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">State / Province</Label>
                <Input
                  placeholder="CA"
                  value={data.state}
                  onChange={(e) => set("state", e.target.value)}
                  aria-invalid={!!errors.state}
                />
                {errors.state && <p className="text-[11px] text-destructive">{errors.state}</p>}
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs">Postal code</Label>
                <Input
                  placeholder="94103"
                  value={data.zip}
                  onChange={(e) => set("zip", e.target.value)}
                  aria-invalid={!!errors.zip}
                  className="font-mono text-xs"
                />
                {errors.zip && <p className="text-[11px] text-destructive">{errors.zip}</p>}
              </div>
              <div className="grid gap-1.5">
                <Label className="text-xs flex items-center gap-1.5">
                  <Globe className="h-3.5 w-3.5 text-muted-foreground" /> Country
                </Label>
                <Select value={data.country} onValueChange={(v) => set("country", v)}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">United States</SelectItem>
                    <SelectItem value="ca">Canada</SelectItem>
                    <SelectItem value="uk">United Kingdom</SelectItem>
                    <SelectItem value="de">Germany</SelectItem>
                    <SelectItem value="fr">France</SelectItem>
                    <SelectItem value="jp">Japan</SelectItem>
                    <SelectItem value="au">Australia</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* STEP 4: Review */}
          {step === 4 && (
            <div className="grid gap-4">
              <p className="text-xs text-muted-foreground">
                Please review your information below. Use the Back button to make changes, or click Create account to finish.
              </p>
              {[
                { label: "Account", icon: Mail, rows: [["Email", data.email], ["Password", "•".repeat(data.password.length || 0) || "—"]] },
                { label: "Personal", icon: User, rows: [["Full name", data.fullName || "—"], ["Date of birth", data.dob ? format(data.dob, "PPP") : "—"]] },
                { label: "Address", icon: Home, rows: [["Street", data.street || "—"], ["City, State", `${data.city || "—"}, ${data.state || "—"}`], ["ZIP, Country", `${data.zip || "—"}, ${(data.country || "").toUpperCase()}`]] },
              ].map((sec) => (
                <div key={sec.label} className="rounded-lg border">
                  <div className="flex items-center gap-2 px-4 py-2.5 border-b bg-muted/30">
                    <sec.icon className="h-3.5 w-3.5 text-primary" />
                    <span className="text-xs font-semibold uppercase tracking-wider">{sec.label}</span>
                  </div>
                  <div className="grid gap-2 p-4 text-xs">
                    {sec.rows.map(([k, v]) => (
                      <div key={k} className="flex justify-between gap-4">
                        <span className="text-muted-foreground">{k}</span>
                        <span className="font-medium text-right truncate max-w-[70%]">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-between pt-4 border-t">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={back}
              disabled={step === 1}
              className="gap-1.5"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Back
            </Button>
            <div className="flex items-center gap-1.5">
              {STEPS.map((s) => (
                <span
                  key={s.id}
                  className={cn(
                    "h-1.5 rounded-full transition-all",
                    s.id === step ? "w-6 bg-primary" : s.id < step ? "w-1.5 bg-emerald-500" : "w-1.5 bg-muted-foreground/30"
                  )}
                />
              ))}
            </div>
            {step < 4 ? (
              <Button type="button" size="sm" onClick={next} className="gap-1.5">
                Continue <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            ) : (
              <Button type="button" size="sm" onClick={finalize} className="gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5" /> Create account
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </>
  );
}
