"use client";

import * as React from "react";
import {
  Flag,
  Plus,
  Filter,
  Search,
  ChevronRight,
  GitBranch,
  CalendarDays,
  TrendingUp,
  CircleDot,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  Layers,
  Download,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type InitiativeStatus = "planned" | "in-progress" | "completed" | "at-risk";

type Initiative = {
  id: string;
  title: string;
  owner: string;
  ownerAvatar: string;
  status: InitiativeStatus;
  progress: number;
  startQ: number; // 1-4
  startMonth: number; // 0-11
  spanMonths: number;
  dependencies: string[];
  description: string;
};

const team = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop" },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop" },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop" },
  { name: "David Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
];

const initiatives: Initiative[] = [
  { id: "INI-001", title: "Atlas Mobile Platform 2.0", owner: team[0].name, ownerAvatar: team[0].avatar, status: "in-progress", progress: 68, startQ: 1, startMonth: 0, spanMonths: 9, dependencies: ["INI-003"], description: "End-to-end rebuild of mobile app with native modules and new design system." },
  { id: "INI-002", title: "Pulse Analytics Platform", owner: team[1].name, ownerAvatar: team[1].avatar, status: "in-progress", progress: 42, startQ: 2, startMonth: 4, spanMonths: 6, dependencies: [], description: "Self-serve analytics with cohort queries, real-time dashboards, and export APIs." },
  { id: "INI-003", title: "Design System Refresh", owner: team[4].name, ownerAvatar: team[4].avatar, status: "completed", progress: 100, startQ: 1, startMonth: 0, spanMonths: 4, dependencies: [], description: "New component library, accessibility pass, and Figma → code sync pipeline." },
  { id: "INI-004", title: "Vertex Payment Gateway", owner: team[2].name, ownerAvatar: team[2].avatar, status: "at-risk", progress: 28, startQ: 2, startMonth: 5, spanMonths: 7, dependencies: ["INI-009"], description: "PCI-DSS Level 1 certified gateway with multi-currency settlement and fraud detection." },
  { id: "INI-005", title: "Nimbus Cloud Migration", owner: team[3].name, ownerAvatar: team[3].avatar, status: "in-progress", progress: 92, startQ: 1, startMonth: 2, spanMonths: 5, dependencies: ["INI-003"], description: "Lift-and-shift from on-prem to multi-region AWS with zero-downtime cutover." },
  { id: "INI-006", title: "Orbit Data Pipeline", owner: team[5].name, ownerAvatar: team[5].avatar, status: "in-progress", progress: 56, startQ: 2, startMonth: 3, spanMonths: 6, dependencies: ["INI-005"], description: "Real-time event streaming backbone with Kafka, replay, and idempotent consumers." },
  { id: "INI-007", title: "Helix CRM Integration", owner: team[0].name, ownerAvatar: team[0].avatar, status: "in-progress", progress: 64, startQ: 2, startMonth: 4, spanMonths: 5, dependencies: ["INI-006"], description: "Bi-directional sync with Salesforce/Hubspot, dedup rules, and lead scoring." },
  { id: "INI-008", title: "Aurora Brand Refresh", owner: team[4].name, ownerAvatar: team[4].avatar, status: "planned", progress: 18, startQ: 3, startMonth: 6, spanMonths: 4, dependencies: ["INI-003"], description: "New visual identity, marketing site, and content guidelines for launch." },
  { id: "INI-009", title: "Security & Compliance Audit", owner: team[3].name, ownerAvatar: team[3].avatar, status: "in-progress", progress: 45, startQ: 1, startMonth: 1, spanMonths: 8, dependencies: [], description: "SOC2 Type II + PCI-DSS audit prep, pen-testing, and remediation tracking." },
  { id: "INI-010", title: "Quasar SDK v3", owner: team[1].name, ownerAvatar: team[1].avatar, status: "completed", progress: 100, startQ: 1, startMonth: 1, spanMonths: 4, dependencies: [], description: "Public SDK with typed clients, retry logic, and webhook verification helpers." },
  { id: "INI-011", title: "Observability Stack", owner: team[5].name, ownerAvatar: team[5].avatar, status: "planned", progress: 12, startQ: 4, startMonth: 9, spanMonths: 3, dependencies: ["INI-006"], description: "Unified tracing, metrics, and logs with SLO-based alerting and runbooks." },
  { id: "INI-012", title: "International Expansion", owner: team[2].name, ownerAvatar: team[2].avatar, status: "at-risk", progress: 22, startQ: 3, startMonth: 7, spanMonths: 5, dependencies: ["INI-004", "INI-009"], description: "Multi-region launch in EMEA + APAC with localized pricing and compliance." },
];

const statusTone: Record<InitiativeStatus, StatusTone> = {
  planned: "info",
  "in-progress": "primary",
  completed: "success",
  "at-risk": "warning",
};
const statusColor: Record<InitiativeStatus, string> = {
  planned: "var(--info)",
  "in-progress": "var(--primary)",
  completed: "var(--success)",
  "at-risk": "var(--warning)",
};
const statusIcon: Record<InitiativeStatus, typeof Clock> = {
  planned: CircleDot,
  "in-progress": TrendingUp,
  completed: CheckCircle2,
  "at-risk": AlertTriangle,
};

const quarters = [
  { label: "Q1", months: ["Jan", "Feb", "Mar"], range: [0, 3] },
  { label: "Q2", months: ["Apr", "May", "Jun"], range: [3, 6] },
  { label: "Q3", months: ["Jul", "Aug", "Sep"], range: [6, 9] },
  { label: "Q4", months: ["Oct", "Nov", "Dec"], range: [9, 12] },
];
const allMonths = quarters.flatMap((q) => q.months);

/* ---------- Page ---------- */

export default function RoadmapPage() {
  const [statusFilter, setStatusFilter] = React.useState<string>("all");
  const [ownerFilter, setOwnerFilter] = React.useState<string>("all");
  const [search, setSearch] = React.useState("");

  const counts = {
    all: initiatives.length,
    planned: initiatives.filter((i) => i.status === "planned").length,
    "in-progress": initiatives.filter((i) => i.status === "in-progress").length,
    completed: initiatives.filter((i) => i.status === "completed").length,
    "at-risk": initiatives.filter((i) => i.status === "at-risk").length,
  };

  const filtered = React.useMemo(() => {
    return initiatives.filter((i) => {
      if (statusFilter !== "all" && i.status !== statusFilter) return false;
      if (ownerFilter !== "all" && i.owner !== ownerFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        if (!i.title.toLowerCase().includes(q) && !i.id.toLowerCase().includes(q) && !i.description.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [statusFilter, ownerFilter, search]);

  return (
    <>
      <PageHeader
        title="Roadmap"
        description="Strategic initiatives across fiscal year 2026 with quarterly delivery targets."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: "Roadmap" }]}
        icon={Flag}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Roadmap exported as PDF")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New initiative form opened")}>
              <Plus className="h-3.5 w-3.5" /> New Initiative
            </Button>
          </>
        }
      />

      {/* Status summary strip — 4 colored stat tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {(["planned", "in-progress", "completed", "at-risk"] as InitiativeStatus[]).map((s) => {
          const Icon = statusIcon[s];
          return (
            <button
              key={s}
              onClick={() => setStatusFilter(statusFilter === s ? "all" : s)}
              className={cn(
                "text-left rounded-xl border bg-card p-4 transition-all hover:shadow-premium-sm",
                statusFilter === s ? "border-primary/40 ring-1 ring-primary/20" : "border-border"
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <div
                  className="grid place-items-center h-8 w-8 rounded-lg"
                  style={{ background: `color-mix(in srgb, ${statusColor[s]} 14%, transparent)`, color: statusColor[s] }}
                >
                  <Icon className="h-4 w-4" />
                </div>
                <span className="text-2xl font-semibold tabular-nums">{counts[s]}</span>
              </div>
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground capitalize">{s.replace("-", " ")}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                {Math.round((counts[s] / counts.all) * 100)}% of portfolio
              </p>
            </button>
          );
        })}
      </div>

      {/* Filter bar */}
      <Card className="mb-4">
        <CardContent className="p-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                placeholder="Search initiatives by title, ID, or description…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="h-9 pl-8 text-xs"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-9 w-[160px] text-xs gap-1.5">
                <Filter className="h-3.5 w-3.5" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="planned">Planned</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="at-risk">At Risk</SelectItem>
              </SelectContent>
            </Select>
            <Select value={ownerFilter} onValueChange={setOwnerFilter}>
              <SelectTrigger className="h-9 w-[160px] text-xs gap-1.5">
                <Avatar className="h-4 w-4">
                  <AvatarFallback className="text-[8px]">O</AvatarFallback>
                </Avatar>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Owners</SelectItem>
                {team.map((m) => (
                  <SelectItem key={m.name} value={m.name}>{m.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-xs text-muted-foreground ml-auto hidden sm:inline-flex items-center gap-1.5">
              <CalendarDays className="h-3.5 w-3.5" />
              FY 2026 · Showing {filtered.length} of {initiatives.length}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timeline (Gantt-style) */}
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Layers className="h-4 w-4 text-violet-500" />
            Initiative Timeline — FY 2026
          </CardTitle>
          <CardDescription>Horizontal bars span initiative durations across quarters. Hover for details.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <div className="min-w-[920px]">
              {/* Quarter header */}
              <div className="grid grid-cols-4 border-b border-border bg-muted/30">
                {quarters.map((q) => (
                  <div key={q.label} className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground border-r border-border last:border-r-0 flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-violet-500/40" />
                    {q.label} 2026
                  </div>
                ))}
              </div>
              {/* Month header */}
              <div className="grid grid-cols-12 border-b border-border">
                {allMonths.map((m, i) => (
                  <div key={m} className={cn("px-2 py-1.5 text-[10px] font-medium text-muted-foreground text-center border-r border-border last:border-r-0", i === 6 && "bg-primary/5 text-primary font-semibold")}>
                    {m}
                  </div>
                ))}
              </div>
              {/* Today line — Jul 6 ~ 6.2/12 */}
              <div className="relative">
                <div className="absolute top-0 bottom-0 z-10 pointer-events-none" style={{ left: "51.6%" }}>
                  <div className="h-full w-px bg-primary/50" />
                  <div className="absolute -top-1 -translate-x-1/2 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-primary text-primary-foreground">TODAY</div>
                </div>
                {/* Initiative rows */}
                <div className="divide-y divide-border">
                  {filtered.map((ini) => {
                    const left = (ini.startMonth / 12) * 100;
                    const width = (ini.spanMonths / 12) * 100;
                    const color = statusColor[ini.status];
                    const Icon = statusIcon[ini.status];
                    return (
                      <div key={ini.id} className="grid grid-cols-12 relative h-11 hover:bg-muted/20 transition-colors group">
                        {/* Initiative label overlay (left) */}
                        <div className="absolute left-2 top-1/2 -translate-y-1/2 z-20 max-w-[180px]">
                          <p className="text-xs font-medium text-foreground truncate">{ini.title}</p>
                          <p className="text-[10px] text-muted-foreground font-mono">{ini.id} · {ini.owner.split(" ")[0]}</p>
                        </div>
                        <div className="col-span-12 relative">
                          <div
                            className="absolute top-1/2 -translate-y-1/2 h-6 rounded-md flex items-center px-2 shadow-sm overflow-hidden group-hover:brightness-110 transition-all cursor-pointer"
                            style={{
                              left: `${left}%`,
                              width: `${width}%`,
                              background: `color-mix(in srgb, ${color} 18%, transparent)`,
                              border: `1px solid color-mix(in srgb, ${color} 40%, transparent)`,
                            }}
                            onClick={() => toast.message(`Opening ${ini.id}`, { description: ini.title })}
                          >
                            {/* Progress fill */}
                            <div
                              className="absolute inset-y-0 left-0 rounded-md"
                              style={{ width: `${ini.progress}%`, background: `color-mix(in srgb, ${color} 50%, transparent)` }}
                            />
                            {/* Icon + % label */}
                            <Icon className="h-3 w-3 shrink-0 relative z-10" style={{ color }} />
                            <span className="text-[10px] font-semibold tabular-nums ml-1.5 relative z-10" style={{ color }}>
                              {ini.progress}%
                            </span>
                            {ini.dependencies.length > 0 && (
                              <span className="ml-auto inline-flex items-center gap-0.5 text-[9px] px-1 py-0.5 rounded bg-card/80 relative z-10" title={`Depends on: ${ini.dependencies.join(", ")}`}>
                                <GitBranch className="h-2.5 w-2.5" />
                                {ini.dependencies.length}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
          {/* Legend */}
          <div className="px-4 py-3 border-t border-border flex items-center gap-4 flex-wrap text-xs">
            {(["planned", "in-progress", "completed", "at-risk"] as InitiativeStatus[]).map((s) => (
              <span key={s} className="inline-flex items-center gap-1.5 capitalize">
                <span className="h-2 w-4 rounded-sm" style={{ background: statusColor[s] }} />
                {s.replace("-", " ")}
              </span>
            ))}
            <span className="ml-auto inline-flex items-center gap-1.5 text-muted-foreground">
              <GitBranch className="h-3.5 w-3.5" /> Dependency count shown on each bar
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Initiative detail cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((ini) => {
          const Icon = statusIcon[ini.status];
          return (
            <Card key={ini.id} className="hover:shadow-premium-sm transition-all">
              <CardContent className="pt-5">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-[10px] text-muted-foreground">{ini.id}</span>
                      <StatusBadge tone={statusTone[ini.status]} dot className="capitalize text-[10px]">
                        {ini.status.replace("-", " ")}
                      </StatusBadge>
                    </div>
                    <h3 className="font-semibold text-foreground leading-snug">{ini.title}</h3>
                  </div>
                  <div
                    className="grid place-items-center h-8 w-8 rounded-lg shrink-0"
                    style={{ background: `color-mix(in srgb, ${statusColor[ini.status]} 14%, transparent)`, color: statusColor[ini.status] }}
                  >
                    <Icon className="h-4 w-4" />
                  </div>
                </div>

                <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{ini.description}</p>

                {/* Progress */}
                <div className="mb-3">
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                    <span>Completion</span>
                    <span className="font-semibold tabular-nums" style={{ color: statusColor[ini.status] }}>{ini.progress}%</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ background: statusColor[ini.status], width: `${ini.progress}%` }}
                    />
                  </div>
                </div>

                {/* Owner + dates */}
                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={ini.ownerAvatar} alt={ini.owner} />
                      <AvatarFallback className="text-[9px]">{ini.owner.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <p className="text-[10px] text-muted-foreground leading-none">Owner</p>
                      <p className="text-xs font-medium truncate">{ini.owner}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-muted-foreground leading-none">Duration</p>
                    <p className="text-xs font-medium font-mono">Q{ini.startQ} · {ini.spanMonths}mo</p>
                  </div>
                </div>

                {/* Dependencies */}
                {ini.dependencies.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-border">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wide flex items-center gap-1 mb-1.5">
                      <GitBranch className="h-3 w-3" /> Depends on
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {ini.dependencies.map((d) => (
                        <span key={d} className="inline-flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                          {d}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full mt-3 h-7 text-xs gap-1"
                  onClick={() => toast.message(`Opening ${ini.id} detail`)}
                >
                  View detail <ArrowRight className="h-3 w-3" />
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </>
  );
}
