"use client";

import * as React from "react";
import {
  ListTodo,
  Plus,
  Download,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Loader2,
  MoreHorizontal,
  Eye,
  Pencil,
  Trash2,
  UserPlus,
  CheckCheck,
  Calendar,
  Timer,
  ArrowUpRight,
  ArrowDownRight,
  type LucideIcon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge, type StatusTone } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/* ---------- Types & data ---------- */

type TaskStatus = "todo" | "in-progress" | "review" | "done" | "blocked";
type Priority = "low" | "medium" | "high" | "critical";

type Task = {
  id: string;
  title: string;
  projectId: string;
  project: string;
  projectColor: string;
  assignee: string;
  assigneeAvatar: string;
  priority: Priority;
  status: TaskStatus;
  due: string;
  dueIn: string;
  overdue: boolean;
  dueToday: boolean;
  progress: number;
  timeLogged: number; // hours
  timeEstimate: number; // hours
  mine: boolean;
};

const teamPool = [
  { name: "Sarah Chen", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=64&h=64&fit=crop" },
  { name: "Marcus Reyes", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
  { name: "Elena Petrov", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop" },
  { name: "James Okoro", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop" },
  { name: "Aiko Tanaka", avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=64&h=64&fit=crop" },
  { name: "David Kim", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop" },
  { name: "Priya Sharma", avatar: "https://images.unsplash.com/photo-1558897103-3257-45a9-b9b6b6c5b5e9?w=64&h=64&fit=crop" },
];

const projList = [
  { id: "PRJ-014", name: "Atlas Mobile Redesign", color: "var(--primary)" },
  { id: "PRJ-013", name: "Pulse Analytics Platform", color: "var(--info)" },
  { id: "PRJ-012", name: "Vertex Payment Gateway", color: "var(--destructive)" },
  { id: "PRJ-011", name: "Nimbus Cloud Migration", color: "var(--success)" },
  { id: "PRJ-009", name: "Orbit Data Pipeline", color: "oklch(0.62 0.18 305)" },
  { id: "PRJ-008", name: "Helix CRM Integration", color: "oklch(0.70 0.15 75)" },
];

const statusTone: Record<TaskStatus, StatusTone> = {
  todo: "neutral",
  "in-progress": "primary",
  review: "violet",
  done: "success",
  blocked: "danger",
};
const priorityTone: Record<Priority, StatusTone> = {
  low: "neutral",
  medium: "info",
  high: "warning",
  critical: "danger",
};

const tasks: Task[] = [
  { id: "TSK-1042", title: "Implement biometric login flow", projectId: "PRJ-014", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", assignee: teamPool[0].name, assigneeAvatar: teamPool[0].avatar, priority: "high", status: "in-progress", due: "Jul 08, 2026", dueIn: "in 2 days", overdue: false, dueToday: false, progress: 65, timeLogged: 11, timeEstimate: 16, mine: true },
  { id: "TSK-1041", title: "Design token refresh rate limiting", projectId: "PRJ-014", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", assignee: teamPool[1].name, assigneeAvatar: teamPool[1].avatar, priority: "medium", status: "review", due: "Jul 07, 2026", dueIn: "tomorrow", overdue: false, dueToday: false, progress: 90, timeLogged: 8, timeEstimate: 8, mine: false },
  { id: "TSK-1040", title: "Migrate analytics dashboards to v2 schema", projectId: "PRJ-013", project: "Pulse Analytics Platform", projectColor: "var(--info)", assignee: teamPool[2].name, assigneeAvatar: teamPool[2].avatar, priority: "high", status: "in-progress", due: "Jul 10, 2026", dueIn: "in 4 days", overdue: false, dueToday: false, progress: 42, timeLogged: 18, timeEstimate: 32, mine: false },
  { id: "TSK-1039", title: "PCI-DSS compliance audit prep", projectId: "PRJ-012", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", assignee: teamPool[3].name, assigneeAvatar: teamPool[3].avatar, priority: "critical", status: "blocked", due: "Jul 06, 2026", dueIn: "today", overdue: false, dueToday: true, progress: 12, timeLogged: 4, timeEstimate: 24, mine: true },
  { id: "TSK-1038", title: "Refactor checkout reducer", projectId: "PRJ-014", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", assignee: teamPool[0].name, assigneeAvatar: teamPool[0].avatar, priority: "medium", status: "done", due: "Jul 04, 2026", dueIn: "2 days ago", overdue: false, dueToday: false, progress: 100, timeLogged: 12, timeEstimate: 10, mine: true },
  { id: "TSK-1037", title: "Set up Kafka topic backfill job", projectId: "PRJ-009", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", assignee: teamPool[5].name, assigneeAvatar: teamPool[5].avatar, priority: "high", status: "in-progress", due: "Jul 12, 2026", dueIn: "in 6 days", overdue: false, dueToday: false, progress: 58, timeLogged: 14, timeEstimate: 20, mine: false },
  { id: "TSK-1036", title: "Cutover runbook for prod migration", projectId: "PRJ-011", project: "Nimbus Cloud Migration", projectColor: "var(--success)", assignee: teamPool[3].name, assigneeAvatar: teamPool[3].avatar, priority: "critical", status: "review", due: "Jul 06, 2026", dueIn: "today", overdue: false, dueToday: true, progress: 88, timeLogged: 9, timeEstimate: 10, mine: false },
  { id: "TSK-1035", title: "Webhook retry backoff strategy", projectId: "PRJ-013", project: "Pulse Analytics Platform", projectColor: "var(--info)", assignee: teamPool[1].name, assigneeAvatar: teamPool[1].avatar, priority: "low", status: "todo", due: "Jul 15, 2026", dueIn: "in 9 days", overdue: false, dueToday: false, progress: 0, timeLogged: 0, timeEstimate: 8, mine: false },
  { id: "TSK-1034", title: "Salesforce OAuth2 connector", projectId: "PRJ-008", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", assignee: teamPool[0].name, assigneeAvatar: teamPool[0].avatar, priority: "high", status: "in-progress", due: "Jul 09, 2026", dueIn: "in 3 days", overdue: false, dueToday: false, progress: 48, timeLogged: 16, timeEstimate: 28, mine: true },
  { id: "TSK-1033", title: "Wire fraud detection alerts", projectId: "PRJ-012", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", assignee: teamPool[2].name, assigneeAvatar: teamPool[2].avatar, priority: "critical", status: "in-progress", due: "Jul 04, 2026", dueIn: "2 days ago", overdue: true, dueToday: false, progress: 32, timeLogged: 22, timeEstimate: 30, mine: false },
  { id: "TSK-1032", title: "Onboarding tour redesign", projectId: "PRJ-014", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", assignee: teamPool[4].name, assigneeAvatar: teamPool[4].avatar, priority: "low", status: "todo", due: "Jul 18, 2026", dueIn: "in 12 days", overdue: false, dueToday: false, progress: 0, timeLogged: 0, timeEstimate: 12, mine: false },
  { id: "TSK-1031", title: "DNS failover drill documentation", projectId: "PRJ-011", project: "Nimbus Cloud Migration", projectColor: "var(--success)", assignee: teamPool[3].name, assigneeAvatar: teamPool[3].avatar, priority: "medium", status: "done", due: "Jul 02, 2026", dueIn: "4 days ago", overdue: false, dueToday: false, progress: 100, timeLogged: 6, timeEstimate: 6, mine: false },
  { id: "TSK-1030", title: "Cohort retention query optimization", projectId: "PRJ-013", project: "Pulse Analytics Platform", projectColor: "var(--info)", assignee: teamPool[5].name, assigneeAvatar: teamPool[5].avatar, priority: "medium", status: "in-progress", due: "Jul 03, 2026", dueIn: "3 days ago", overdue: true, dueToday: false, progress: 25, timeLogged: 11, timeEstimate: 18, mine: false },
  { id: "TSK-1029", title: "Push notification A/B framework", projectId: "PRJ-014", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", assignee: teamPool[0].name, assigneeAvatar: teamPool[0].avatar, priority: "medium", status: "todo", due: "Jul 20, 2026", dueIn: "in 14 days", overdue: false, dueToday: false, progress: 0, timeLogged: 0, timeEstimate: 14, mine: true },
  { id: "TSK-1028", title: "Field-level encryption for PII", projectId: "PRJ-012", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", assignee: teamPool[3].name, assigneeAvatar: teamPool[3].avatar, priority: "high", status: "review", due: "Jul 08, 2026", dueIn: "in 2 days", overdue: false, dueToday: false, progress: 82, timeLogged: 19, timeEstimate: 22, mine: false },
  { id: "TSK-1027", title: "Hubspot contact sync job", projectId: "PRJ-008", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", assignee: teamPool[6].name, assigneeAvatar: teamPool[6].avatar, priority: "medium", status: "in-progress", due: "Jul 11, 2026", dueIn: "in 5 days", overdue: false, dueToday: false, progress: 55, timeLogged: 7, timeEstimate: 12, mine: false },
  { id: "TSK-1026", title: "Schema validation library upgrade", projectId: "PRJ-009", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", assignee: teamPool[5].name, assigneeAvatar: teamPool[5].avatar, priority: "low", status: "done", due: "Jun 30, 2026", dueIn: "6 days ago", overdue: false, dueToday: false, progress: 100, timeLogged: 4, timeEstimate: 5, mine: false },
  { id: "TSK-1025", title: "Mobile crash report symbolication", projectId: "PRJ-014", project: "Atlas Mobile Redesign", projectColor: "var(--primary)", assignee: teamPool[1].name, assigneeAvatar: teamPool[1].avatar, priority: "high", status: "in-progress", due: "Jul 05, 2026", dueIn: "yesterday", overdue: true, dueToday: false, progress: 38, timeLogged: 9, timeEstimate: 14, mine: false },
  { id: "TSK-1024", title: "CSP header hardening for web app", projectId: "PRJ-011", project: "Nimbus Cloud Migration", projectColor: "var(--success)", assignee: teamPool[3].name, assigneeAvatar: teamPool[3].avatar, priority: "medium", status: "todo", due: "Jul 14, 2026", dueIn: "in 8 days", overdue: false, dueToday: false, progress: 0, timeLogged: 0, timeEstimate: 8, mine: false },
  { id: "TSK-1023", title: "Pipeline replay & idempotency tests", projectId: "PRJ-009", project: "Orbit Data Pipeline", projectColor: "oklch(0.62 0.18 305)", assignee: teamPool[5].name, assigneeAvatar: teamPool[5].avatar, priority: "high", status: "review", due: "Jul 09, 2026", dueIn: "in 3 days", overdue: false, dueToday: false, progress: 75, timeLogged: 13, timeEstimate: 16, mine: false },
  { id: "TSK-1022", title: "Lead deduplication rules engine", projectId: "PRJ-008", project: "Helix CRM Integration", projectColor: "oklch(0.70 0.15 75)", assignee: teamPool[6].name, assigneeAvatar: teamPool[6].avatar, priority: "medium", status: "todo", due: "Jul 22, 2026", dueIn: "in 16 days", overdue: false, dueToday: false, progress: 0, timeLogged: 0, timeEstimate: 18, mine: false },
  { id: "TSK-1021", title: "Refund webhook idempotency layer", projectId: "PRJ-012", project: "Vertex Payment Gateway", projectColor: "var(--destructive)", assignee: teamPool[2].name, assigneeAvatar: teamPool[2].avatar, priority: "critical", status: "done", due: "Jun 28, 2026", dueIn: "8 days ago", overdue: false, dueToday: false, progress: 100, timeLogged: 21, timeEstimate: 20, mine: false },
];

/* ---------- TaskKpi — checkbox-counter strip motif ---------- */

function TaskKpi({
  label,
  value,
  icon: Icon,
  accent,
  total,
  done,
  trend,
  caption,
}: {
  label: string;
  value: string;
  icon: LucideIcon;
  accent: "primary" | "success" | "warning" | "danger";
  total: number;
  done: number;
  trend: { value: number; direction: "up" | "down"; positive: boolean };
  caption: string;
}) {
  const accentMap: Record<string, string> = {
    primary: "bg-primary/12 text-primary",
    success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]/12 text-[color:var(--warning)]",
    danger: "bg-destructive/12 text-destructive",
  };
  const accentStrip: Record<string, string> = {
    primary: "bg-primary",
    success: "bg-[color:var(--success)]",
    warning: "bg-[color:var(--warning)]",
    danger: "bg-destructive",
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-border bg-card p-5 transition-all hover:shadow-premium-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">
            {label}
          </p>
          <div className="mt-1.5 flex items-baseline gap-1.5">
            <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
            <span className={cn("inline-flex items-center gap-0.5 text-xs font-medium tabular-nums", trend.positive ? "text-[color:var(--success)]" : "text-destructive")}>
              {trend.direction === "up" ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {Math.abs(trend.value)}%
            </span>
          </div>
        </div>
        <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", accentMap[accent])}>
          <Icon className="h-4.5 w-4.5" />
        </div>
      </div>

      {/* Checkbox-counter strip — 8 segments */}
      <div className="mt-4 flex items-center gap-1">
        {Array.from({ length: 8 }).map((_, i) => {
          const ratio = total > 0 ? done / total : 0;
          const filled = i < Math.round(ratio * 8);
          return (
            <div
              key={i}
              className={cn(
                "h-3 flex-1 rounded-sm transition-all flex items-center justify-center",
                filled ? cn(accentStrip[accent], "text-white") : "bg-muted text-muted-foreground/40"
              )}
            >
              {filled && <CheckCircle2 className="h-2 w-2" strokeWidth={3} />}
            </div>
          );
        })}
        <span className="text-[10px] font-semibold text-muted-foreground tabular-nums ml-2 whitespace-nowrap">
          {done}/{total}
        </span>
      </div>

      <p className="mt-2 text-[11px] text-muted-foreground truncate">{caption}</p>
    </div>
  );
}

/* ---------- Page ---------- */

export default function TasksPage() {
  const [filter, setFilter] = React.useState<"all" | "mine" | "today" | "overdue" | "completed">("all");

  const totalTasks = tasks.length;
  const inProgress = tasks.filter((t) => t.status === "in-progress").length;
  const completed = tasks.filter((t) => t.status === "done").length;
  const overdue = tasks.filter((t) => t.overdue).length;

  const counts = {
    all: totalTasks,
    mine: tasks.filter((t) => t.mine).length,
    today: tasks.filter((t) => t.dueToday).length,
    overdue: tasks.filter((t) => t.overdue).length,
    completed: tasks.filter((t) => t.status === "done").length,
  };

  const filtered = React.useMemo(() => {
    switch (filter) {
      case "mine": return tasks.filter((t) => t.mine);
      case "today": return tasks.filter((t) => t.dueToday);
      case "overdue": return tasks.filter((t) => t.overdue);
      case "completed": return tasks.filter((t) => t.status === "done");
      default: return tasks;
    }
  }, [filter]);

  const columns: Column<Task>[] = React.useMemo(() => [
    {
      key: "title",
      header: "Task",
      sortable: true,
      sortAccessor: (r) => r.title,
      cell: (r) => (
        <div className="flex items-start gap-2.5 min-w-0">
          <div className="grid place-items-center h-7 w-7 rounded-md bg-muted text-muted-foreground shrink-0 mt-0.5">
            <ListTodo className="h-3.5 w-3.5" />
          </div>
          <div className="min-w-0">
            <p className="font-medium text-foreground text-sm truncate">{r.title}</p>
            <p className="text-[10px] text-muted-foreground font-mono">{r.id}</p>
          </div>
        </div>
      ),
    },
    {
      key: "project",
      header: "Project",
      sortable: true,
      sortAccessor: (r) => r.project,
      filterable: true,
      filterAccessor: (r) => r.projectId,
      filterOptions: projList.map((p) => ({ label: p.name, value: p.id })),
      cell: (r) => (
        <span
          className="inline-flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded-md ring-1 ring-inset"
          style={{
            color: r.projectColor,
            background: `color-mix(in srgb, ${r.projectColor} 12%, transparent)`,
            borderColor: `color-mix(in srgb, ${r.projectColor} 25%, transparent)`,
          }}
        >
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: r.projectColor }} />
          {r.project}
        </span>
      ),
      width: "w-48",
    },
    {
      key: "assignee",
      header: "Assignee",
      sortable: true,
      sortAccessor: (r) => r.assignee,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7">
            <AvatarImage src={r.assigneeAvatar} alt={r.assignee} />
            <AvatarFallback className="text-[10px]">{r.assignee.split(" ").map((n) => n[0]).join("")}</AvatarFallback>
          </Avatar>
          <span className="text-xs text-muted-foreground truncate">{r.assignee}</span>
        </div>
      ),
      width: "w-36",
    },
    {
      key: "priority",
      header: "Priority",
      sortable: true,
      sortAccessor: (r) => r.priority,
      filterable: true,
      filterAccessor: (r) => r.priority,
      filterOptions: [
        { label: "Low", value: "low" },
        { label: "Medium", value: "medium" },
        { label: "High", value: "high" },
        { label: "Critical", value: "critical" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={priorityTone[r.priority]} className="capitalize">{r.priority}</StatusBadge>
      ),
      width: "w-28",
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      sortAccessor: (r) => r.status,
      filterable: true,
      filterAccessor: (r) => r.status,
      filterOptions: [
        { label: "To Do", value: "todo" },
        { label: "In Progress", value: "in-progress" },
        { label: "Review", value: "review" },
        { label: "Done", value: "done" },
        { label: "Blocked", value: "blocked" },
      ],
      align: "center",
      cell: (r) => (
        <StatusBadge tone={statusTone[r.status]} dot className="capitalize">{r.status.replace("-", " ")}</StatusBadge>
      ),
      width: "w-32",
    },
    {
      key: "due",
      header: "Due Date",
      sortable: true,
      sortAccessor: (r) => r.due,
      cell: (r) => (
        <div className="text-right">
          <p className={cn("text-xs font-mono tabular-nums", r.overdue ? "text-destructive font-semibold" : r.dueToday ? "text-[color:var(--warning)] font-semibold" : "text-muted-foreground")}>
            {r.due}
          </p>
          <p className={cn("text-[10px]", r.overdue ? "text-destructive" : r.dueToday ? "text-[color:var(--warning)]" : "text-muted-foreground")}>
            {r.overdue ? "OVERDUE · " : ""}{r.dueIn}
          </p>
        </div>
      ),
      width: "w-32",
      align: "right",
    },
    {
      key: "progress",
      header: "Progress",
      sortable: true,
      sortAccessor: (r) => r.progress,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className="h-1.5 w-20 rounded-full bg-muted overflow-hidden shrink-0">
            <div
              className={cn(
                "h-full rounded-full transition-all",
                r.progress === 100 ? "bg-[color:var(--success)]" : r.progress >= 75 ? "bg-primary" : r.progress >= 40 ? "bg-violet-500" : r.progress > 0 ? "bg-[color:var(--warning)]" : "bg-muted-foreground/30"
              )}
              style={{ width: `${r.progress}%` }}
            />
          </div>
          <span className="text-xs font-semibold tabular-nums w-9 shrink-0">{r.progress}%</span>
        </div>
      ),
      width: "w-40",
    },
    {
      key: "time",
      header: "Time Tracked",
      sortable: true,
      sortAccessor: (r) => r.timeLogged,
      align: "right",
      cell: (r) => (
        <div className="text-right">
          <p className="text-xs font-semibold tabular-nums inline-flex items-center gap-1">
            <Timer className="h-3 w-3 text-muted-foreground" />
            {r.timeLogged}h
          </p>
          <p className="text-[10px] text-muted-foreground tabular-nums">/ {r.timeEstimate}h est</p>
        </div>
      ),
      width: "w-28",
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      hideable: false,
      cell: (r) => (
        <div onClick={(e) => e.stopPropagation()}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="text-xs">{r.id}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Opening ${r.id}`)}>
                <Eye className="h-3.5 w-3.5" /> View task
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.message(`Editing ${r.id}`)}>
                <Pencil className="h-3.5 w-3.5" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs gap-2" onClick={() => toast.success(`Reassigned ${r.id}`)}>
                <UserPlus className="h-3.5 w-3.5" /> Reassign
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {r.status !== "done" && (
                <DropdownMenuItem className="text-xs gap-2 text-[color:var(--success)] focus:text-[color:var(--success)]" onClick={() => toast.success(`${r.id} marked complete`)}>
                  <CheckCheck className="h-3.5 w-3.5" /> Mark complete
                </DropdownMenuItem>
              )}
              <DropdownMenuItem className="text-xs gap-2 text-destructive focus:text-destructive" onClick={() => toast.error(`${r.id} deleted`)}>
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ),
      width: "w-16",
    },
  ], []);

  return (
    <>
      <PageHeader
        title="Tasks"
        description="Track every task across active projects, from backlog to delivery."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: "Tasks" }]}
        icon={ListTodo}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Tasks exported as CSV")}>
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New task drawer opened")}>
              <Plus className="h-3.5 w-3.5" /> New Task
            </Button>
          </>
        }
      />

      {/* KPI row — TaskKpi with checkbox-counter strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <TaskKpi
          label="Total Tasks"
          value={String(totalTasks)}
          icon={ListTodo}
          accent="primary"
          total={totalTasks}
          done={completed}
          trend={{ value: 14, direction: "up", positive: true }}
          caption="across 6 active projects"
        />
        <TaskKpi
          label="In Progress"
          value={String(inProgress)}
          icon={Loader2}
          accent="warning"
          total={inProgress}
          done={Math.round(inProgress * 0.55)}
          trend={{ value: 6, direction: "up", positive: true }}
          caption="avg. 54% complete · 7 in review"
        />
        <TaskKpi
          label="Completed (7d)"
          value={String(completed + 18)}
          icon={CheckCircle2}
          accent="success"
          total={completed + 18}
          done={completed + 18}
          trend={{ value: 22, direction: "up", positive: true }}
          caption="velocity up · 18 closed this week"
        />
        <TaskKpi
          label="Overdue"
          value={String(overdue)}
          icon={AlertTriangle}
          accent="danger"
          total={overdue}
          done={0}
          trend={{ value: 2, direction: "down", positive: true }}
          caption="2 critical · 1 high priority"
        />
      </div>

      {/* Filter tabs */}
      <div className="mb-4">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
          <TabsList className="h-9">
            <TabsTrigger value="all" className="text-xs gap-1.5">
              All <span className="text-[10px] text-muted-foreground tabular-nums">({counts.all})</span>
            </TabsTrigger>
            <TabsTrigger value="mine" className="text-xs gap-1.5">
              My Tasks <span className="text-[10px] text-muted-foreground tabular-nums">({counts.mine})</span>
            </TabsTrigger>
            <TabsTrigger value="today" className="text-xs gap-1.5">
              Due Today <span className="text-[10px] text-muted-foreground tabular-nums">({counts.today})</span>
            </TabsTrigger>
            <TabsTrigger value="overdue" className="text-xs gap-1.5">
              Overdue <span className="text-[10px] text-destructive tabular-nums">({counts.overdue})</span>
            </TabsTrigger>
            <TabsTrigger value="completed" className="text-xs gap-1.5">
              Completed <span className="text-[10px] text-muted-foreground tabular-nums">({counts.completed})</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Tasks DataTable */}
      <DataTable
        title={`Tasks — ${filter === "all" ? "All" : filter === "mine" ? "My Tasks" : filter === "today" ? "Due Today" : filter === "overdue" ? "Overdue" : "Completed"}`}
        data={filtered}
        columns={columns}
        searchKeys={["title", "id", "assignee", "project"]}
        getRowId={(r) => r.id}
        onRowClick={(r) => toast.message(`Opening ${r.id}`)}
        enableSelection
        enableExport
        enableDensity
        enableColumnVisibility
        pageSize={10}
        initialSort={{ key: "due", direction: "asc" }}
        bulkActions={[
          {
            label: "Mark complete",
            icon: CheckCheck,
            onClick: (sel) => toast.success(`Marked ${sel.length} task${sel.length > 1 ? "s" : ""} complete`),
          },
          {
            label: "Reassign",
            icon: UserPlus,
            onClick: (sel) => toast.message(`Reassigning ${sel.length} task${sel.length > 1 ? "s" : ""}`),
          },
          {
            label: "Export selected",
            icon: Download,
            onClick: (sel) => toast.success(`Exported ${sel.length} task${sel.length > 1 ? "s" : ""} as CSV`),
          },
          {
            label: "Delete",
            icon: Trash2,
            onClick: (sel) => toast.error(`Deleted ${sel.length} task${sel.length > 1 ? "s" : ""}`),
          },
        ]}
      />

      {/* Bottom insight band */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Avg. Cycle Time</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">3.4 days</p>
                <p className="text-xs text-[color:var(--success)] inline-flex items-center gap-0.5 mt-1.5">
                  <ArrowDownRight className="h-3 w-3" /> −0.6d vs last sprint
                </p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/12 text-primary">
                <Clock className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Time Logged (7d)</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">286h</p>
                <p className="text-xs text-muted-foreground mt-1.5">82% of capacity · 5.2h/task avg</p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--info)]/12 text-[color:var(--info)]">
                <Timer className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Due This Week</p>
                <p className="text-2xl font-semibold tabular-nums mt-1.5">14</p>
                <p className="text-xs text-[color:var(--warning)] inline-flex items-center gap-0.5 mt-1.5">
                  <Calendar className="h-3 w-3" /> 4 closing tomorrow
                </p>
              </div>
              <div className="grid place-items-center h-9 w-9 rounded-lg bg-[color:var(--warning)]/12 text-[color:var(--warning)]">
                <Calendar className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
