"use client";

import * as React from "react";
import {
  UploadCloud,
  FileText,
  FileImage,
  FileVideo,
  FileArchive,
  X,
  CheckCircle2,
  Loader2,
  UserCircle,
  ImageIcon,
  AlertCircle,
  HardDrive,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type UploadedFile = {
  id: string;
  name: string;
  size: number;
  type: string;
  preview?: string;
  progress: number;
  status: "uploading" | "done" | "error";
};

const MAX_SIZE = 10 * 1024 * 1024; // 10MB
const ACCEPTED = ["image/png", "image/jpeg", "image/webp", "image/gif", "application/pdf", "text/plain", "video/mp4", "application/zip"];

function formatBytes(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / (1024 * 1024)).toFixed(2)} MB`;
}

function FileIcon({ type, className }: { type: string; className?: string }) {
  if (type.startsWith("image/")) return <FileImage className={className} />;
  if (type.startsWith("video/")) return <FileVideo className={className} />;
  if (type === "application/pdf") return <FileText className={className} />;
  if (type === "application/zip" || type === "application/x-zip-compressed") return <FileArchive className={className} />;
  return <FileText className={className} />;
}

function useUploads() {
  const [files, setFiles] = React.useState<UploadedFile[]>([]);
  const add = React.useCallback((incoming: File[]) => {
    const valid: UploadedFile[] = [];
    incoming.forEach((f) => {
      if (!ACCEPTED.includes(f.type)) {
        toast.error(`${f.name}: unsupported file type`);
        return;
      }
      if (f.size > MAX_SIZE) {
        toast.error(`${f.name}: exceeds 10MB limit`);
        return;
      }
      const id = `${f.name}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const preview = f.type.startsWith("image/") ? URL.createObjectURL(f) : undefined;
      valid.push({ id, name: f.name, size: f.size, type: f.type, preview, progress: 0, status: "uploading" });
    });
    if (valid.length === 0) return;
    setFiles((cur) => [...cur, ...valid]);

    valid.forEach((file) => {
      let p = 0;
      const tick = () => {
        p += Math.random() * 18 + 6;
        if (p >= 100) {
          p = 100;
          setFiles((cur) => cur.map((f) => (f.id === file.id ? { ...f, progress: 100, status: "done" } : f)));
          toast.success(`${file.name} uploaded`);
          return;
        }
        setFiles((cur) => cur.map((f) => (f.id === file.id ? { ...f, progress: Math.round(p) } : f)));
        setTimeout(tick, 220 + Math.random() * 200);
      };
      setTimeout(tick, 150);
    });
  }, []);
  const remove = (id: string) => {
    setFiles((cur) => {
      const f = cur.find((x) => x.id === id);
      if (f?.preview) URL.revokeObjectURL(f.preview);
      return cur.filter((x) => x.id !== id);
    });
  };
  const clear = () => {
    files.forEach((f) => f.preview && URL.revokeObjectURL(f.preview));
    setFiles([]);
  };
  return { files, add, remove, clear };
}

function FileRow({ f, onRemove }: { f: UploadedFile; onRemove: (id: string) => void }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border p-2.5">
      <div className="grid place-items-center h-10 w-10 rounded-md bg-muted shrink-0 overflow-hidden">
        {f.preview ? (
          <img src={f.preview} alt="" className="h-full w-full object-cover" />
        ) : (
          <FileIcon type={f.type} className="h-5 w-5 text-muted-foreground" />
        )}
      </div>
      <div className="min-w-0 flex-1 grid gap-1">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-medium truncate">{f.name}</span>
          <span className="text-[10px] text-muted-foreground tabular-nums shrink-0">{formatBytes(f.size)}</span>
        </div>
        {f.status === "done" ? (
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-600">
            <CheckCircle2 className="h-3 w-3" /> Uploaded
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Progress value={f.progress} className="h-1.5" />
            <span className="text-[10px] text-muted-foreground tabular-nums w-9 text-right">{f.progress}%</span>
          </div>
        )}
      </div>
      <button
        type="button"
        onClick={() => onRemove(f.id)}
        className="grid place-items-center h-7 w-7 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent shrink-0"
        aria-label={`Remove ${f.name}`}
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

export default function FileUploadPage() {
  const dropzone = useUploads();
  const browser = useUploads();
  const avatarRef = React.useRef<HTMLInputElement>(null);
  const browseRef = React.useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = React.useState(false);
  const [avatar, setAvatar] = React.useState<{ url: string; name: string } | null>(null);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length) dropzone.add(files);
  };

  const onAvatar = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast.error("Avatar must be an image");
      return;
    }
    if (avatar?.url) URL.revokeObjectURL(avatar.url);
    setAvatar({ url: URL.createObjectURL(f), name: f.name });
    toast.success("Avatar updated");
  };

  const totalSize = [...dropzone.files, ...browser.files].reduce((s, f) => s + f.size, 0);

  return (
    <>
      <PageHeader
        title="File Upload"
        description="Three production upload patterns — drag-and-drop, click-to-browse and circular avatar upload."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "File Upload" }]}
        icon={UploadCloud}
        actions={
          <Badge variant="secondary" className="text-[10px] uppercase tracking-wide gap-1">
            <HardDrive className="h-3 w-3" /> {formatBytes(totalSize)} queued
          </Badge>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* DRAG & DROP */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <UploadCloud className="h-4 w-4 text-primary" /> Drag & Drop Zone
            </CardTitle>
            <CardDescription>Drop files anywhere on the dashed area, or click to browse. Multiple files supported.</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              onClick={() => browseRef.current?.click()}
              className={cn(
                "grid place-items-center text-center gap-3 rounded-xl border-2 border-dashed p-10 cursor-pointer transition-colors",
                dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 hover:bg-accent/30"
              )}
            >
              <input
                ref={browseRef}
                type="file"
                multiple
                accept={ACCEPTED.join(",")}
                className="hidden"
                onChange={(e) => {
                  if (e.target.files) dropzone.add(Array.from(e.target.files));
                  e.target.value = "";
                }}
              />
              <div className={cn(
                "grid place-items-center h-14 w-14 rounded-full transition-colors",
                dragOver ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
              )}>
                <UploadCloud className="h-7 w-7" />
              </div>
              <div>
                <p className="text-sm font-medium">{dragOver ? "Drop your files here" : "Drag files here, or click to browse"}</p>
                <p className="text-xs text-muted-foreground mt-1">PNG, JPG, WebP, GIF, PDF, TXT, MP4, ZIP · up to 10MB each</p>
              </div>
            </div>

            {dropzone.files.length > 0 && (
              <div className="mt-4 grid gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium">{dropzone.files.length} file{dropzone.files.length > 1 ? "s" : ""} queued</span>
                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={dropzone.clear}>
                    <X className="h-3 w-3" /> Clear all
                  </Button>
                </div>
                <div className="grid gap-2 max-h-80 overflow-y-auto pr-1">
                  {dropzone.files.map((f) => (
                    <FileRow key={f.id} f={f} onRemove={dropzone.remove} />
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* CLICK TO BROWSE */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" /> Click to Browse
            </CardTitle>
            <CardDescription>A traditional file input styled to match the design system.</CardDescription>
          </CardHeader>
          <CardContent>
            <label
              htmlFor="browse-input"
              className="flex items-center gap-3 rounded-lg border p-3 cursor-pointer hover:bg-accent/40 transition-colors"
            >
              <div className="grid place-items-center h-10 w-10 rounded-md bg-primary/10 text-primary shrink-0">
                <FileText className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium">Choose files to upload</p>
                <p className="text-xs text-muted-foreground">PNG, JPG, PDF, TXT · up to 10MB</p>
              </div>
              <Button type="button" variant="outline" size="sm" className="shrink-0">Browse</Button>
              <input
                id="browse-input"
                type="file"
                multiple
                accept={ACCEPTED.join(",")}
                className="hidden"
                onChange={(e) => {
                  if (e.target.files) browser.add(Array.from(e.target.files));
                  e.target.value = "";
                }}
              />
            </label>

            {browser.files.length > 0 && (
              <div className="mt-4 grid gap-2 max-h-72 overflow-y-auto pr-1">
                {browser.files.map((f) => (
                  <FileRow key={f.id} f={f} onRemove={browser.remove} />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* AVATAR UPLOAD */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <ImageIcon className="h-4 w-4 text-primary" /> Avatar Upload
            </CardTitle>
            <CardDescription>Circular preview with hover-to-replace affordance.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center gap-4">
              <div className="relative group">
                <button
                  type="button"
                  onClick={() => avatarRef.current?.click()}
                  className="relative h-32 w-32 rounded-full overflow-hidden border-4 border-background ring-2 ring-border grid place-items-center bg-muted group-hover:ring-primary transition-all"
                >
                  {avatar ? (
                    <img src={avatar.url} alt="Avatar" className="h-full w-full object-cover" />
                  ) : (
                    <UserCircle className="h-16 w-16 text-muted-foreground" />
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity grid place-items-center">
                    <div className="flex flex-col items-center gap-1 text-white">
                      <UploadCloud className="h-5 w-5" />
                      <span className="text-[10px] font-medium">Change</span>
                    </div>
                  </div>
                </button>
                {avatar && (
                  <button
                    type="button"
                    onClick={() => { URL.revokeObjectURL(avatar.url); setAvatar(null); toast.message("Avatar removed"); }}
                    className="absolute -top-1 -right-1 grid place-items-center h-7 w-7 rounded-full bg-destructive text-white shadow-sm hover:bg-destructive/90"
                    aria-label="Remove avatar"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              <input ref={avatarRef} type="file" accept="image/*" onChange={onAvatar} className="hidden" />
              <div className="text-center">
                <p className="text-sm font-medium">{avatar ? avatar.name : "No avatar selected"}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Square image · JPG, PNG, WebP · up to 2MB</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => avatarRef.current?.click()} className="gap-1.5">
                  <UploadCloud className="h-3.5 w-3.5" /> {avatar ? "Replace" : "Upload"}
                </Button>
                {avatar && (
                  <Button variant="ghost" size="sm" onClick={() => { URL.revokeObjectURL(avatar.url); setAvatar(null); }} className="gap-1.5 text-destructive hover:text-destructive">
                    <X className="h-3.5 w-3.5" /> Remove
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* RESTRICTIONS / INFO */}
        <Card className="lg:col-span-2 bg-muted/30">
          <CardContent>
            <div className="grid sm:grid-cols-3 gap-4">
              <Info icon={CheckCircle2} title="Accepted formats" tone="text-emerald-500" lines={["Images: PNG, JPG, WebP, GIF", "Documents: PDF, TXT", "Media: MP4, ZIP"]} />
              <Info icon={AlertCircle} title="Size limits" tone="text-amber-500" lines={["Max 10MB per file", "Max 50 files per upload", "Avatars: 2MB, square"]} />
              <Info icon={Loader2} title="Upload behaviour" tone="text-primary" lines={["Simulated progress for demo", "Per-file retry on failure", "Auto thumbnail generation"]} />
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}

function Info({ icon: Icon, title, lines, tone }: { icon: React.ElementType; title: string; lines: string[]; tone: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="grid place-items-center h-8 w-8 rounded-lg bg-background shrink-0">
        <Icon className={cn("h-4 w-4", tone)} />
      </div>
      <div>
        <p className="text-sm font-medium">{title}</p>
        <ul className="mt-1 grid gap-0.5 text-xs text-muted-foreground">
          {lines.map((l) => (
            <li key={l} className="flex items-center gap-1.5">
              <Separator orientation="vertical" className="h-2.5 w-px bg-muted-foreground/40" />
              {l}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
