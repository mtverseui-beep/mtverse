"use client";

import * as React from "react";
import {
  CalendarClock,
  Calendar as CalendarIcon,
  Clock,
  CalendarRange,
  Repeat,
  ChevronUp,
  ChevronDown,
  CheckCircle2,
  Globe,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { format, type DateRange } from "date-fns";

function pad(n: number) {
  return n.toString().padStart(2, "0");
}

function TimePicker({
  value,
  onChange,
}: {
  value: { h: number; m: number; period: "AM" | "PM" };
  onChange: (v: { h: number; m: number; period: "AM" | "PM" }) => void;
}) {
  const bump = (key: "h" | "m", delta: number) => {
    if (key === "h") {
      let next = value.h + delta;
      if (next < 1) next = 12;
      if (next > 12) next = 1;
      onChange({ ...value, h: next });
    } else {
      let next = value.m + delta;
      if (next < 0) next = 59;
      if (next > 59) next = 0;
      onChange({ ...value, m: next });
    }
  };
  const togglePeriod = () =>
    onChange({ ...value, period: value.period === "AM" ? "PM" : "AM" });

  return (
    <div className="inline-flex items-stretch rounded-lg border bg-background overflow-hidden">
      <div className="grid place-items-center px-2 bg-muted/40">
        <Clock className="h-3.5 w-3.5 text-muted-foreground" />
      </div>
      <div className="flex flex-col items-center justify-center px-2 py-1.5">
        <button type="button" onClick={() => bump("h", 1)} className="text-muted-foreground hover:text-foreground">
          <ChevronUp className="h-3 w-3" />
        </button>
        <span className="text-sm font-mono tabular-nums w-7 text-center">{pad(value.h)}</span>
        <button type="button" onClick={() => bump("h", -1)} className="text-muted-foreground hover:text-foreground">
          <ChevronDown className="h-3 w-3" />
        </button>
      </div>
      <div className="grid place-items-center text-sm font-mono">:</div>
      <div className="flex flex-col items-center justify-center px-2 py-1.5">
        <button type="button" onClick={() => bump("m", 5)} className="text-muted-foreground hover:text-foreground">
          <ChevronUp className="h-3 w-3" />
        </button>
        <span className="text-sm font-mono tabular-nums w-7 text-center">{pad(value.m)}</span>
        <button type="button" onClick={() => bump("m", -5)} className="text-muted-foreground hover:text-foreground">
          <ChevronDown className="h-3 w-3" />
        </button>
      </div>
      <button
        type="button"
        onClick={togglePeriod}
        className="px-2 text-xs font-medium bg-muted/40 hover:bg-muted transition-colors"
      >
        {value.period}
      </button>
    </div>
  );
}

const WEEKDAYS = [
  { v: "mon", l: "M" },
  { v: "tue", l: "T" },
  { v: "wed", l: "W" },
  { v: "thu", l: "T" },
  { v: "fri", l: "F" },
  { v: "sat", l: "S" },
  { v: "sun", l: "S" },
];

export default function DateTimePage() {
  const [single, setSingle] = React.useState<Date | undefined>(new Date(2026, 6, 15));
  const [range, setRange] = React.useState<DateRange | undefined>({
    from: new Date(2026, 6, 10),
    to: new Date(2026, 6, 20),
  });
  const [time, setTime] = React.useState<{ h: number; m: number; period: "AM" | "PM" }>({ h: 2, m: 30, period: "PM" });
  const [combinedDate, setCombinedDate] = React.useState<Date | undefined>(new Date(2026, 6, 18));
  const [combinedTime, setCombinedTime] = React.useState<{ h: number; m: number; period: "AM" | "PM" }>({ h: 9, m: 15, period: "AM" });
  const [freq, setFreq] = React.useState("weekly");
  const [days, setDays] = React.useState<string[]>(["mon", "wed", "fri"]);
  const [tz, setTz] = React.useState("UTC-08:00 Pacific");

  const toggleDay = (d: string) => {
    setDays((cur) => (cur.includes(d) ? cur.filter((x) => x !== d) : [...cur, d]));
  };

  const combinedDisplay = React.useMemo(() => {
    if (!combinedDate) return "Not set";
    let h = combinedTime.h;
    if (combinedTime.period === "PM" && h !== 12) h += 12;
    if (combinedTime.period === "AM" && h === 12) h = 0;
    const dt = new Date(combinedDate);
    dt.setHours(h, combinedTime.m, 0, 0);
    return format(dt, "PPP · p");
  }, [combinedDate, combinedTime]);

  return (
    <>
      <PageHeader
        title="Date & Time Picker"
        description="Five production-ready picker patterns covering single dates, ranges, times and recurring schedules."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Date & Time Picker" }]}
        icon={CalendarClock}
        actions={
          <Select value={tz} onValueChange={setTz}>
            <SelectTrigger className="h-9 w-[200px] text-xs gap-1.5">
              <Globe className="h-3.5 w-3.5" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {["UTC", "UTC-08:00 Pacific", "UTC-05:00 Eastern", "UTC+00:00 London", "UTC+01:00 Berlin", "UTC+09:00 Tokyo", "UTC+10:00 Sydney"].map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SINGLE DATE */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarIcon className="h-4 w-4 text-primary" /> Single Date Picker
            </CardTitle>
            <CardDescription>Calendar popover with month and year navigation.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  {single ? format(single, "PPP") : <span className="text-muted-foreground">Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={single}
                  onSelect={setSingle}
                  initialFocus
                  captionLayout="dropdown"
                />
              </PopoverContent>
            </Popover>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Selected</span><span className="font-medium">{single ? format(single, "PPP") : "—"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">ISO format</span><span className="font-mono">{single ? single.toISOString().split("T")[0] : "—"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Unix timestamp</span><span className="font-mono">{single ? Math.floor(single.getTime() / 1000) : "—"}</span></div>
            </div>
          </CardContent>
        </Card>

        {/* DATE RANGE */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarRange className="h-4 w-4 text-primary" /> Date Range Picker
            </CardTitle>
            <CardDescription>Pick a start and end date in a single calendar.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left font-normal">
                  <CalendarRange className="h-4 w-4 text-muted-foreground" />
                  {range?.from ? (
                    range.to ? (
                      <>{format(range.from, "LLL d")} — {format(range.to, "LLL d, yyyy")}</>
                    ) : (
                      format(range.from, "PPP")
                    )
                  ) : (
                    <span className="text-muted-foreground">Pick a date range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="range"
                  selected={range}
                  onSelect={setRange}
                  numberOfMonths={2}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Start</span><span className="font-medium">{range?.from ? format(range.from, "PPP") : "—"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">End</span><span className="font-medium">{range?.to ? format(range.to, "PPP") : "—"}</span></div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Duration</span>
                <span className="font-medium">
                  {range?.from && range?.to
                    ? `${Math.round((range.to.getTime() - range.from.getTime()) / (1000 * 60 * 60 * 24))} days`
                    : "—"}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* TIME PICKER */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" /> Time Picker
            </CardTitle>
            <CardDescription>Hour and minute selector with AM/PM toggle, 5-minute stepping.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="flex items-center justify-center py-2">
              <TimePicker value={time} onChange={setTime} />
            </div>
            <div className="rounded-lg border bg-muted/30 p-3 grid gap-1.5 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Selected time</span><span className="font-mono">{pad(time.h)}:{pad(time.m)} {time.period}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">24h format</span><span className="font-mono">{pad(time.period === "PM" && time.h !== 12 ? time.h + 12 : time.period === "AM" && time.h === 12 ? 0 : time.h)}:{pad(time.m)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">ISO time</span><span className="font-mono">{pad(time.period === "PM" && time.h !== 12 ? time.h + 12 : time.period === "AM" && time.h === 12 ? 0 : time.h)}:{pad(time.m)}:00</span></div>
            </div>
          </CardContent>
        </Card>

        {/* DATE + TIME COMBINED */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-primary" /> Date + Time Combined
            </CardTitle>
            <CardDescription>Compose a precise moment using both pickers together.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="flex flex-col sm:flex-row gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="flex-1 justify-start text-left font-normal">
                    <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                    {combinedDate ? format(combinedDate, "PPP") : <span className="text-muted-foreground">Pick date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={combinedDate} onSelect={setCombinedDate} initialFocus />
                </PopoverContent>
              </Popover>
              <div className="flex-1 grid place-items-center sm:place-items-end">
                <TimePicker value={combinedTime} onChange={setCombinedTime} />
              </div>
            </div>
            <div className="rounded-lg border bg-primary/5 border-primary/30 p-3 text-xs flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Event scheduled for</p>
                <p className="font-medium text-sm">{combinedDisplay}</p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => toast.success("Event added to calendar", { description: combinedDisplay })}>
              Add to calendar
            </Button>
          </CardContent>
        </Card>

        {/* RECURRING */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Repeat className="h-4 w-4 text-primary" /> Recurring Schedule
            </CardTitle>
            <CardDescription>Define a repeating pattern with frequency and day-of-week selection.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-5">
            <div className="grid lg:grid-cols-3 gap-4">
              <div className="grid gap-2">
                <Label className="text-xs">Frequency</Label>
                <RadioGroup value={freq} onValueChange={setFreq} className="grid gap-2">
                  {[
                    { v: "daily", t: "Daily", d: "Every day at the same time" },
                    { v: "weekly", t: "Weekly", d: "On selected days of the week" },
                    { v: "monthly", t: "Monthly", d: "On the same day each month" },
                  ].map((o) => (
                    <Label
                      key={o.v}
                      className={cn(
                        "flex items-start gap-3 rounded-lg border p-2.5 cursor-pointer transition-colors",
                        freq === o.v ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "hover:bg-accent/40"
                      )}
                    >
                      <RadioGroupItem value={o.v} className="mt-0.5" />
                      <div>
                        <span className="text-xs font-medium block">{o.t}</span>
                        <span className="text-[11px] text-muted-foreground">{o.d}</span>
                      </div>
                    </Label>
                  ))}
                </RadioGroup>
              </div>

              <div className="grid gap-2">
                <Label className="text-xs">Repeat every</Label>
                <div className="flex items-center gap-2">
                  <Input type="number" defaultValue={1} min={1} max={30} className="w-20" />
                  <span className="text-xs text-muted-foreground">
                    {freq === "daily" ? "days" : freq === "weekly" ? "weeks" : "months"}
                  </span>
                </div>
                <Label className="text-xs mt-2">Starting</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="text-xs">{format(new Date(2026, 6, 1), "PPP")}</span>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" initialFocus />
                  </PopoverContent>
                </Popover>
                <Label className="text-xs mt-2">Until</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="text-xs">{format(new Date(2026, 11, 31), "PPP")}</span>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" initialFocus />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="grid gap-2">
                <Label className="text-xs">On days {freq === "weekly" ? "(required)" : "(weekly only)"}</Label>
                <div className={cn("grid gap-1.5", freq !== "weekly" && "opacity-50 pointer-events-none")}>
                  <div className="grid grid-cols-7 gap-1">
                    {WEEKDAYS.map((d, i) => (
                      <button
                        key={d.v}
                        type="button"
                        onClick={() => toggleDay(d.v)}
                        className={cn(
                          "h-10 rounded-md border text-xs font-medium transition-colors",
                          days.includes(d.v)
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background hover:bg-accent"
                        )}
                        title={["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"][i]}
                      >
                        {d.l}
                      </button>
                    ))}
                  </div>
                </div>
                <Label className="text-xs mt-2">At time</Label>
                <TimePicker value={time} onChange={setTime} />
                <Separator className="my-1" />
                <div className="flex items-center gap-2">
                  <Checkbox id="ends" defaultChecked />
                  <Label htmlFor="ends" className="text-xs font-normal">End after 12 occurrences</Label>
                </div>
              </div>
            </div>

            <div className="rounded-lg border bg-muted/30 p-4 grid gap-2 text-xs">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Summary</p>
              <p className="text-sm font-medium">
                {freq === "daily" && "Every day"}
                {freq === "weekly" && days.length > 0
                  ? `Every week on ${days.join(", ").toUpperCase()}`
                  : freq === "weekly" && "Select at least one weekday"}
                {freq === "monthly" && "Every month on day 1"}
                {" at "}
                <span className="font-mono">{pad(time.h)}:{pad(time.m)} {time.period}</span>
                {" "}<span className="text-muted-foreground">({tz})</span>
              </p>
              <div className="flex flex-wrap gap-1.5 mt-1">
                <Badge variant="outline" className="text-[10px] gap-1">
                  <Repeat className="h-3 w-3" /> 12 occurrences
                </Badge>
                <Badge variant="outline" className="text-[10px]">Until Dec 31, 2026</Badge>
                <Badge variant="outline" className="text-[10px]">{tz}</Badge>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => toast.message("Schedule cancelled")}>Cancel</Button>
              <Button size="sm" onClick={() => toast.success("Recurring schedule saved")}>Save schedule</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
