"use client";

import * as React from "react";
import {
  LifeBuoy,
  Search,
  Rocket,
  CreditCard,
  SlidersHorizontal,
  Plug,
  Code,
  Wrench,
  ArrowRight,
  TicketCheck,
  MessageSquare,
  BookOpen,
  Users,
  TrendingUp,
  Clock,
  Eye,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Category = {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  articles: number;
  tone: "primary" | "violet" | "warning" | "info" | "success" | "danger";
};

const CATEGORIES: Category[] = [
  { id: "getting-started", name: "Getting Started", description: "Set up your workspace and invite your team in minutes.", icon: Rocket, articles: 24, tone: "primary" },
  { id: "billing", name: "Account & Billing", description: "Manage plans, payment methods, invoices, and renewals.", icon: CreditCard, articles: 18, tone: "info" },
  { id: "features", name: "Features", description: "Learn what NexusGrid can do and how to make the most of it.", icon: SlidersHorizontal, articles: 42, tone: "violet" },
  { id: "integrations", name: "Integrations", description: "Connect NexusGrid with the tools your team already uses.", icon: Plug, articles: 31, tone: "success" },
  { id: "api", name: "API & Developers", description: "REST API reference, webhooks, SDKs, and authentication.", icon: Code, articles: 27, tone: "warning" },
  { id: "troubleshooting", name: "Troubleshooting", description: "Common issues, error codes, and how to resolve them.", icon: Wrench, articles: 19, tone: "danger" },
];

const POPULAR_ARTICLES = [
  { id: "1", title: "How to invite team members to your workspace", category: "Getting Started", views: 24890, time: "3 min read" },
  { id: "2", title: "Setting up SSO with Google Workspace", category: "Account & Billing", views: 18420, time: "5 min read" },
  { id: "3", title: "Creating custom dashboards with widgets", category: "Features", views: 16730, time: "8 min read" },
  { id: "4", title: "Webhook events and payload reference", category: "API & Developers", views: 14520, time: "12 min read" },
  { id: "5", title: "Connecting NexusGrid to Slack notifications", category: "Integrations", views: 12890, time: "4 min read" },
  { id: "6", title: "Resolving 429 rate limit responses", category: "Troubleshooting", views: 9840, time: "6 min read" },
];

const QUICK_ACTIONS = [
  { icon: TicketCheck, title: "Submit a ticket", description: "Get a response within 4 hours.", tone: "primary" as const, action: () => toast.success("Opening ticket form") },
  { icon: MessageSquare, title: "Live chat", description: "Chat with our team Mon-Fri 9-6 EST.", tone: "violet" as const, action: () => toast.success("Connecting to live chat") },
  { icon: BookOpen, title: "Documentation", description: "Browse our full reference docs.", tone: "info" as const, action: () => toast.success("Opening docs") },
  { icon: Users, title: "Community", description: "Join 12,000+ members in our forum.", tone: "success" as const, action: () => toast.success("Opening community") },
];

const toneBg: Record<string, string> = {
  primary: "bg-primary/12 text-primary",
  violet: "bg-violet-500/12 text-violet-500",
  warning: "bg-[color:var(--warning)]/15 text-[color:var(--warning)]",
  info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
  success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
  danger: "bg-destructive/12 text-destructive",
};

const toneAccent: Record<string, string> = {
  primary: "text-primary",
  violet: "text-violet-500",
  warning: "text-[color:var(--warning)]",
  info: "text-[color:var(--info)]",
  success: "text-[color:var(--success)]",
  danger: "text-destructive",
};

export default function HelpCenterPage() {
  return (
    <>
      <PageHeader
        title="Help Center"
        description="Find answers, learn from guides, and reach our support team — all in one place."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Help Center" }]}
        icon={LifeBuoy}
      />

      {/* HERO SEARCH */}
      <Card className="mb-6 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.08] via-violet-500/[0.04] to-transparent" aria-hidden />
        <CardContent className="relative p-8 sm:p-10 text-center">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-primary/10 text-primary text-[11px] font-medium mb-4">
            <LifeBuoy className="h-3 w-3" /> We're here to help
          </div>
          <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight mb-2">How can we help you today?</h2>
          <p className="text-sm text-muted-foreground mb-6 max-w-xl mx-auto">
            Search our knowledge base of 161 articles, or browse by category below.
          </p>
          <div className="relative max-w-2xl mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Try 'how to set up SSO' or 'reset password'"
              className="pl-11 pr-28 h-12 text-sm shadow-premium-xs"
            />
            <Button size="sm" className="absolute right-1.5 top-1/2 -translate-y-1/2 h-9 gap-1.5">
              Search <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div className="flex items-center justify-center gap-2 mt-4 text-xs text-muted-foreground flex-wrap">
            <span>Popular:</span>
            {["Inviting users", "API keys", "Webhooks", "Custom roles"].map((t) => (
              <button key={t} className="px-2 py-0.5 rounded-md border border-border bg-card hover:bg-muted/60 transition-colors">
                {t}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* CATEGORIES GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {CATEGORIES.map((c) => (
          <Card key={c.id} className="group hover:shadow-premium-md transition-all cursor-pointer overflow-hidden">
            <CardContent className="p-5">
              <div className="flex items-start gap-3.5">
                <div className={cn("grid place-items-center h-11 w-11 rounded-xl shrink-0", toneBg[c.tone])}>
                  <c.icon className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2 mb-0.5">
                    <h3 className="text-sm font-semibold">{c.name}</h3>
                    <ArrowRight className={cn("h-3.5 w-3.5 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all", toneAccent[c.tone])} />
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{c.description}</p>
                  <div className="flex items-center gap-1.5 mt-2.5">
                    <Badge variant="outline" className="text-[10px] gap-1">
                      <BookOpen className="h-2.5 w-2.5" /> {c.articles} articles
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* POPULAR ARTICLES + QUICK ACTIONS */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" /> Popular articles
              </CardTitle>
              <CardDescription>Most-read guides this month.</CardDescription>
            </div>
            <Button variant="ghost" size="sm" className="text-xs">View all</Button>
          </CardHeader>
          <CardContent className="p-0">
            <ul className="divide-y divide-border">
              {POPULAR_ARTICLES.map((a, idx) => (
                <li key={a.id}>
                  <button className="w-full flex items-center gap-3 px-5 py-3 hover:bg-muted/40 transition-colors text-left group">
                    <span className="grid place-items-center h-7 w-7 rounded-md bg-muted text-muted-foreground text-xs font-semibold shrink-0">
                      {idx + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">{a.title}</p>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px] text-muted-foreground">
                        <Badge variant="outline" className="text-[9px] h-4">{a.category}</Badge>
                        <span className="flex items-center gap-0.5">
                          <Clock className="h-2.5 w-2.5" /> {a.time}
                        </span>
                        <span className="flex items-center gap-0.5">
                          <Eye className="h-2.5 w-2.5" /> {a.views.toLocaleString()}
                        </span>
                      </div>
                    </div>
                    <ArrowRight className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                  </button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Quick actions</CardTitle>
              <CardDescription>Other ways to get help.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {QUICK_ACTIONS.map((a) => (
                <button
                  key={a.title}
                  onClick={a.action}
                  className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/60 transition-colors text-left group"
                >
                  <div className={cn("grid place-items-center h-9 w-9 rounded-lg shrink-0", toneBg[a.tone])}>
                    <a.icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{a.title}</p>
                    <p className="text-[11px] text-muted-foreground line-clamp-1">{a.description}</p>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                </button>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-violet-500/[0.06] to-transparent border-violet-500/20">
            <CardContent className="p-5">
              <div className="flex items-center gap-2 text-violet-500 mb-1.5">
                <LifeBuoy className="h-4 w-4" />
                <span className="text-[11px] font-semibold uppercase tracking-wide">Support hours</span>
              </div>
              <p className="text-sm font-medium mb-3">Monday — Friday</p>
              <p className="text-xs text-muted-foreground">9:00 AM — 6:00 PM EST</p>
              <p className="text-xs text-muted-foreground">Weekend: email only</p>
              <div className="mt-3 pt-3 border-t border-border/60 flex items-center gap-1.5 text-xs">
                <span className="h-2 w-2 rounded-full bg-[color:var(--success)] animate-pulse" />
                <span className="text-[color:var(--success)] font-medium">Currently online</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
