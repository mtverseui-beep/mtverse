"use client";

import * as React from "react";
import {
  Cog,
  Settings2,
  Palette,
  Bell,
  Shield,
  Terminal,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Sun,
  Moon,
  Monitor,
  Type,
  Clock,
  Globe,
  Mail,
  MessageSquare,
  Webhook,
  Trash2,
  Eye,
  EyeOff,
  Loader2,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const SECTIONS = [
  { v: "general", label: "General", icon: Settings2 },
  { v: "appearance", label: "Appearance", icon: Palette },
  { v: "notifications", label: "Notifications", icon: Bell },
  { v: "privacy", label: "Privacy", icon: Shield },
  { v: "advanced", label: "Advanced", icon: Terminal },
];

type Settings = {
  workspaceName: string;
  workspaceDesc: string;
  timezone: string;
  language: string;
  dateFormat: string;
  theme: "light" | "dark" | "system";
  accent: string;
  fontSize: number;
  density: "comfortable" | "compact" | "spacious";
  sidebarPos: "left" | "right";
  emailOnMention: boolean;
  emailOnComment: boolean;
  emailOnTask: boolean;
  emailOnWeekly: boolean;
  digestFreq: string;
  quietStart: string;
  quietEnd: string;
  profileVisibility: "public" | "team" | "private";
  searchVisibility: boolean;
  dataSharing: boolean;
  apiAccess: boolean;
  betaFeatures: boolean;
};

const DEFAULTS: Settings = {
  workspaceName: "Aurora Workspace",
  workspaceDesc: "The primary workspace for the Aurora product team — covering design, engineering and operations.",
  timezone: "UTC-08:00 Pacific",
  language: "English (US)",
  dateFormat: "MMM d, yyyy",
  theme: "system",
  accent: "#6366f1",
  fontSize: 14,
  density: "comfortable",
  sidebarPos: "left",
  emailOnMention: true,
  emailOnComment: true,
  emailOnTask: false,
  emailOnWeekly: true,
  digestFreq: "daily",
  quietStart: "22:00",
  quietEnd: "08:00",
  profileVisibility: "team",
  searchVisibility: true,
  dataSharing: false,
  apiAccess: true,
  betaFeatures: false,
};

const ACCENTS = [
  { name: "Indigo", hex: "#6366f1" },
  { name: "Emerald", hex: "#10b981" },
  { name: "Amber", hex: "#f59e0b" },
  { name: "Rose", hex: "#f43f5e" },
  { name: "Sky", hex: "#0ea5e9" },
  { name: "Violet", hex: "#8b5cf6" },
];

function Row({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium">{title}</p>
        {desc && <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

export default function SettingsFormPage() {
  const [section, setSection] = React.useState("general");
  const [settings, setSettings] = React.useState<Settings>(DEFAULTS);
  const [savedSnapshot, setSavedSnapshot] = React.useState<Settings>(DEFAULTS);
  const [saving, setSaving] = React.useState(false);

  const set = <K extends keyof Settings>(k: K, v: Settings[K]) =>
    setSettings((s) => ({ ...s, [k]: v }));

  const isDirty = JSON.stringify(settings) !== JSON.stringify(savedSnapshot);
  const dirtyCount = Object.keys(settings).filter(
    (k) => (settings as Record<string, unknown>)[k] !== (savedSnapshot as Record<string, unknown>)[k]
  ).length;

  const save = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSavedSnapshot(settings);
      toast.success("Settings saved", {
        description: "Your changes have been applied across the workspace.",
      });
    }, 900);
  };

  const reset = () => {
    setSettings(savedSnapshot);
    toast.message("Reverted to last saved state");
  };

  return (
    <>
      <PageHeader
        title="Settings Form"
        description="Tabbed settings with sections, unsaved-changes tracking and a danger zone."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Forms" }, { label: "Settings Form" }]}
        icon={Cog}
        actions={
          <div className="flex items-center gap-2">
            {isDirty ? (
              <Badge variant="outline" className="text-[10px] gap-1 border-amber-500/40 text-amber-600 bg-amber-500/5">
                <AlertTriangle className="h-3 w-3" /> {dirtyCount} unsaved change{dirtyCount > 1 ? "s" : ""}
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[10px] gap-1 border-emerald-500/40 text-emerald-600 bg-emerald-500/5">
                <CheckCircle2 className="h-3 w-3" /> All changes saved
              </Badge>
            )}
          </div>
        }
      />

      <Tabs value={section} onValueChange={setSection} className="grid lg:grid-cols-[220px_1fr] gap-6">
        {/* SIDEBAR TABS */}
        <div className="lg:sticky lg:top-4 lg:self-start">
          <Card className="p-2">
            <TabsList className="grid grid-cols-5 lg:grid-cols-1 gap-1 h-auto bg-transparent p-0">
              {SECTIONS.map((s) => (
                <TabsTrigger
                  key={s.v}
                  value={s.v}
                  className="justify-start gap-2 px-3 py-2 text-xs data-[state=active]:bg-accent data-[state=active]:shadow-none rounded-md"
                >
                  <s.icon className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">{s.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </Card>
        </div>

        {/* CONTENT */}
        <div className="grid gap-6">
          {/* GENERAL */}
          <TabsContent value="general" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Settings2 className="h-4 w-4 text-primary" /> General
                </CardTitle>
                <CardDescription>Basic workspace configuration and localisation preferences.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <div className="grid gap-1.5">
                  <Label className="text-xs">Workspace name</Label>
                  <Input
                    value={settings.workspaceName}
                    onChange={(e) => set("workspaceName", e.target.value)}
                  />
                </div>
                <div className="grid gap-1.5">
                  <Label className="text-xs">Description</Label>
                  <Textarea
                    rows={3}
                    value={settings.workspaceDesc}
                    onChange={(e) => set("workspaceDesc", e.target.value)}
                  />
                  <p className="text-[11px] text-muted-foreground">{settings.workspaceDesc.length} / 240 characters</p>
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="grid gap-1.5">
                    <Label className="text-xs flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5 text-muted-foreground" /> Timezone
                    </Label>
                    <Select value={settings.timezone} onValueChange={(v) => set("timezone", v)}>
                      <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {["UTC", "UTC-08:00 Pacific", "UTC-05:00 Eastern", "UTC+00:00 London", "UTC+01:00 Berlin", "UTC+09:00 Tokyo"].map((t) => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs flex items-center gap-1.5">
                      <Globe className="h-3.5 w-3.5 text-muted-foreground" /> Language
                    </Label>
                    <Select value={settings.language} onValueChange={(v) => set("language", v)}>
                      <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="English (US)">English (US)</SelectItem>
                        <SelectItem value="English (UK)">English (UK)</SelectItem>
                        <SelectItem value="Deutsch">Deutsch</SelectItem>
                        <SelectItem value="Français">Français</SelectItem>
                        <SelectItem value="日本語">日本語</SelectItem>
                        <SelectItem value="中文">中文</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs flex items-center gap-1.5">
                      <Type className="h-3.5 w-3.5 text-muted-foreground" /> Date format
                    </Label>
                    <Select value={settings.dateFormat} onValueChange={(v) => set("dateFormat", v)}>
                      <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MMM d, yyyy">Jul 1, 2026</SelectItem>
                        <SelectItem value="d MMM yyyy">1 Jul 2026</SelectItem>
                        <SelectItem value="yyyy-MM-dd">2026-07-01</SelectItem>
                        <SelectItem value="MM/dd/yyyy">07/01/2026</SelectItem>
                        <SelectItem value="dd.MM.yyyy">01.07.2026</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* APPEARANCE */}
          <TabsContent value="appearance" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Palette className="h-4 w-4 text-primary" /> Appearance
                </CardTitle>
                <CardDescription>Customise how NexusGrid looks across your devices.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <div>
                  <Label className="text-xs mb-2 block">Theme</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { v: "light", l: "Light", icon: Sun },
                      { v: "dark", l: "Dark", icon: Moon },
                      { v: "system", l: "System", icon: Monitor },
                    ].map((t) => (
                      <button
                        key={t.v}
                        type="button"
                        onClick={() => set("theme", t.v as Settings["theme"])}
                        className={cn(
                          "rounded-lg border p-3 grid gap-2 place-items-center text-xs transition-colors",
                          settings.theme === t.v ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "hover:bg-accent/40"
                        )}
                      >
                        <t.icon className={cn("h-5 w-5", settings.theme === t.v ? "text-primary" : "text-muted-foreground")} />
                        {t.l}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-xs mb-2 block">Accent color</Label>
                  <div className="flex flex-wrap gap-2">
                    {ACCENTS.map((c) => (
                      <button
                        key={c.hex}
                        type="button"
                        onClick={() => set("accent", c.hex)}
                        className={cn(
                          "h-9 w-9 rounded-full ring-2 ring-offset-2 ring-offset-background transition-all",
                          settings.accent === c.hex ? "ring-foreground scale-110" : "ring-transparent hover:ring-border"
                        )}
                        style={{ backgroundColor: c.hex }}
                        title={c.name}
                        aria-label={`Pick ${c.name}`}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-xs mb-2 block">Font size — {settings.fontSize}px</Label>
                  <Slider
                    value={[settings.fontSize]}
                    onValueChange={(v) => set("fontSize", v[0])}
                    min={12}
                    max={18}
                    step={1}
                  />
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>A</span><span className="text-base">A</span>
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Density</Label>
                    <Select value={settings.density} onValueChange={(v) => set("density", v as Settings["density"])}>
                      <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="compact">Compact</SelectItem>
                        <SelectItem value="comfortable">Comfortable</SelectItem>
                        <SelectItem value="spacious">Spacious</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Sidebar position</Label>
                    <Select value={settings.sidebarPos} onValueChange={(v) => set("sidebarPos", v as Settings["sidebarPos"])}>
                      <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="left">Left</SelectItem>
                        <SelectItem value="right">Right</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* NOTIFICATIONS */}
          <TabsContent value="notifications" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Bell className="h-4 w-4 text-primary" /> Notifications
                </CardTitle>
                <CardDescription>Choose what triggers an email and when to mute them.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-2">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mt-1 mb-1">Email me when…</p>
                <Row title="I'm mentioned in a comment" desc="Includes @mentions in tasks, docs and threads.">
                  <Switch checked={settings.emailOnMention} onCheckedChange={(v) => set("emailOnMention", v)} />
                </Row>
                <Separator />
                <Row title="Someone comments on my work" desc="Replies to your tasks, PRs and designs.">
                  <Switch checked={settings.emailOnComment} onCheckedChange={(v) => set("emailOnComment", v)} />
                </Row>
                <Separator />
                <Row title="A task is assigned to me" desc="Includes reassignments and delegation.">
                  <Switch checked={settings.emailOnTask} onCheckedChange={(v) => set("emailOnTask", v)} />
                </Row>
                <Separator />
                <Row title="Weekly summary digest" desc="A Monday-morning recap of last week's activity.">
                  <Switch checked={settings.emailOnWeekly} onCheckedChange={(v) => set("emailOnWeekly", v)} />
                </Row>
                <Separator />
                <div className="grid sm:grid-cols-3 gap-4 mt-2">
                  <div className="grid gap-1.5">
                    <Label className="text-xs flex items-center gap-1.5">
                      <Mail className="h-3.5 w-3.5 text-muted-foreground" /> Digest frequency
                    </Label>
                    <Select value={settings.digestFreq} onValueChange={(v) => set("digestFreq", v)}>
                      <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realtime">Realtime</SelectItem>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Quiet hours start</Label>
                    <Input type="time" value={settings.quietStart} onChange={(e) => set("quietStart", e.target.value)} className="font-mono" />
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs">Quiet hours end</Label>
                    <Input type="time" value={settings.quietEnd} onChange={(e) => set("quietEnd", e.target.value)} className="font-mono" />
                  </div>
                </div>
                <div className="rounded-lg border bg-muted/30 p-3 mt-2 text-xs flex items-start gap-2">
                  <Bell className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <p className="text-muted-foreground">
                    During quiet hours ({settings.quietStart}–{settings.quietEnd}), non-urgent notifications are batched and delivered when the window ends.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* PRIVACY */}
          <TabsContent value="privacy" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="h-4 w-4 text-primary" /> Privacy
                </CardTitle>
                <CardDescription>Control who can see your profile and how your data is used.</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-4">
                <div className="grid gap-1.5">
                  <Label className="text-xs">Profile visibility</Label>
                  <div className="grid sm:grid-cols-3 gap-2">
                    {[
                      { v: "public", l: "Public", d: "Anyone can find you", icon: Globe },
                      { v: "team", l: "Team only", d: "Workspace members", icon: Eye },
                      { v: "private", l: "Private", d: "Invite-only", icon: EyeOff },
                    ].map((o) => (
                      <button
                        key={o.v}
                        type="button"
                        onClick={() => set("profileVisibility", o.v as Settings["profileVisibility"])}
                        className={cn(
                          "rounded-lg border p-3 text-left transition-colors",
                          settings.profileVisibility === o.v ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "hover:bg-accent/40"
                        )}
                      >
                        <o.icon className={cn("h-4 w-4 mb-1.5", settings.profileVisibility === o.v ? "text-primary" : "text-muted-foreground")} />
                        <p className="text-xs font-medium">{o.l}</p>
                        <p className="text-[10px] text-muted-foreground">{o.d}</p>
                      </button>
                    ))}
                  </div>
                </div>
                <Separator />
                <Row title="Allow search indexing" desc="Your profile appears in workspace search results.">
                  <Switch checked={settings.searchVisibility} onCheckedChange={(v) => set("searchVisibility", v)} />
                </Row>
                <Separator />
                <Row title="Share usage analytics" desc="Anonymised data helps us improve the product. No personal info is shared.">
                  <Switch checked={settings.dataSharing} onCheckedChange={(v) => set("dataSharing", v)} />
                </Row>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ADVANCED */}
          <TabsContent value="advanced" className="mt-0">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Terminal className="h-4 w-4 text-primary" /> Developer options
                  </CardTitle>
                  <CardDescription>Power-user settings and experimental features.</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-2">
                  <Row title="API access" desc="Enable personal access tokens and webhooks.">
                    <Switch checked={settings.apiAccess} onCheckedChange={(v) => set("apiAccess", v)} />
                  </Row>
                  <Separator />
                  <Row title="Beta features" desc="Get early access to unreleased features. May be unstable.">
                    <Switch checked={settings.betaFeatures} onCheckedChange={(v) => set("betaFeatures", v)} />
                  </Row>
                  {settings.betaFeatures && (
                    <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs flex items-start gap-2">
                      <Sparkles className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                      <p className="text-amber-700 dark:text-amber-400">
                        You now have access to <strong>AI-powered insights</strong>, <strong>bulk actions v2</strong> and <strong>real-time collaboration cursors</strong>. Find them in the labs section.
                      </p>
                    </div>
                  )}
                  <Separator />
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div className="rounded-lg border p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Webhook className="h-3.5 w-3.5 text-primary" />
                        <p className="text-xs font-medium">Webhooks</p>
                      </div>
                      <p className="text-[11px] text-muted-foreground">4 active endpoints</p>
                    </div>
                    <div className="rounded-lg border p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <MessageSquare className="h-3.5 w-3.5 text-primary" />
                        <p className="text-xs font-medium">API tokens</p>
                      </div>
                      <p className="text-[11px] text-muted-foreground">2 personal tokens</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* DANGER ZONE */}
              <Card className="border-destructive/40">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2 text-destructive">
                    <AlertTriangle className="h-4 w-4" /> Danger zone
                  </CardTitle>
                  <CardDescription>Irreversible and destructive actions — proceed with caution.</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-3">
                  <div className="flex items-center justify-between gap-3 rounded-lg border border-destructive/30 p-3">
                    <div>
                      <p className="text-sm font-medium">Export workspace data</p>
                      <p className="text-xs text-muted-foreground">Download all projects, tasks and files as a ZIP archive.</p>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => toast.success("Export started — we'll email you when it's ready")}>
                      Export
                    </Button>
                  </div>
                  <div className="flex items-center justify-between gap-3 rounded-lg border border-destructive/30 p-3">
                    <div>
                      <p className="text-sm font-medium">Transfer ownership</p>
                      <p className="text-xs text-muted-foreground">Hand this workspace over to another admin member.</p>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => toast.message("Opening transfer dialog")}>
                      Transfer
                    </Button>
                  </div>
                  <div className="flex items-center justify-between gap-3 rounded-lg border border-destructive/40 bg-destructive/5 p-3">
                    <div>
                      <p className="text-sm font-medium text-destructive">Delete workspace</p>
                      <p className="text-xs text-muted-foreground">Permanently delete this workspace and all of its data. This cannot be undone.</p>
                    </div>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm" className="gap-1.5">
                          <Trash2 className="h-3.5 w-3.5" /> Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete "{settings.workspaceName}"?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete the workspace, including all projects, tasks, files and history. This action is irreversible.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <div className="rounded-md border bg-muted/30 p-3 text-xs">
                          <p className="text-muted-foreground mb-1.5">Type the workspace name to confirm:</p>
                          <Input placeholder={settings.workspaceName} className="bg-background" />
                        </div>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            className="bg-destructive text-white hover:bg-destructive/90"
                            onClick={() => toast.error("Workspace deletion scheduled", { description: "You have 30 days to cancel" })}
                          >
                            Delete workspace
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* STICKY ACTION BAR */}
          <div className={cn(
            "sticky bottom-4 z-10 flex items-center justify-between gap-2 rounded-xl border bg-background/95 backdrop-blur p-3 shadow-sm transition-opacity",
            !isDirty && "opacity-60"
          )}>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {isDirty ? (
                <>
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                  You have {dirtyCount} unsaved change{dirtyCount > 1 ? "s" : ""}
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                  All changes are saved
                </>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="gap-1.5" onClick={reset} disabled={!isDirty || saving}>
                <RotateCcw className="h-3.5 w-3.5" /> Reset
              </Button>
              <Button size="sm" className="gap-1.5" onClick={save} disabled={!isDirty || saving}>
                {saving ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> Saving…
                  </>
                ) : (
                  <>
                    <Save className="h-3.5 w-3.5" /> Save changes
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </Tabs>
    </>
  );
}
