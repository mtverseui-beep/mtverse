"use client";

import * as React from "react";
import {
  PackageOpen,
  ShoppingCart,
  Box,
  Users,
  SearchX,
  BellOff,
  Inbox,
  FolderOpen,
  ShieldOff,
  WifiOff,
  Plus,
  RefreshCw,
  ArrowRight,
  Mail,
  Upload,
  Home,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type EmptyStateDef = {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  tone: "primary" | "violet" | "warning" | "info" | "success" | "danger" | "neutral";
  cta: { label: string; icon?: React.ElementType; variant?: "default" | "outline" };
  secondary?: { label: string; icon?: React.ElementType };
  hasSearch?: boolean;
  custom?: "cart" | "permission" | "offline";
};

const STATES: EmptyStateDef[] = [
  {
    id: "orders",
    title: "No orders yet",
    description: "When customers place orders, they'll appear here with full details and status tracking.",
    icon: ShoppingCart,
    tone: "primary",
    cta: { label: "Create order", icon: Plus },
    secondary: { label: "Import orders", icon: Upload },
  },
  {
    id: "products",
    title: "Your product catalog is empty",
    description: "Add your first product to start selling. You can add manually or import from a CSV file.",
    icon: Box,
    tone: "violet",
    cta: { label: "Add product", icon: Plus },
    secondary: { label: "Import CSV", icon: Upload },
  },
  {
    id: "customers",
    title: "No customers found",
    description: "As customers sign up and place orders, your customer list will populate here automatically.",
    icon: Users,
    tone: "info",
    cta: { label: "Invite customer", icon: Mail },
  },
  {
    id: "cart",
    title: "Your cart is empty",
    description: "Browse our catalog and add items to your cart to get started with checkout.",
    icon: ShoppingCart,
    tone: "warning",
    cta: { label: "Browse products", icon: ArrowRight },
    custom: "cart",
  },
  {
    id: "search",
    title: "No results found",
    description: "Try adjusting your search terms or filters to find what you're looking for.",
    icon: SearchX,
    tone: "neutral",
    cta: { label: "Clear filters", icon: RefreshCw },
    hasSearch: true,
  },
  {
    id: "notifications",
    title: "You're all caught up",
    description: "No new notifications. We'll let you know when something needs your attention.",
    icon: BellOff,
    tone: "success",
    cta: { label: "Notification settings" },
  },
  {
    id: "inbox",
    title: "Inbox zero achieved",
    description: "You have no unread messages. Take a break — you've earned it.",
    icon: Inbox,
    tone: "primary",
    cta: { label: "Compose message", icon: Plus },
  },
  {
    id: "files",
    title: "No files in this folder",
    description: "Drag files here to upload, or click the button below to browse your computer.",
    icon: FolderOpen,
    tone: "violet",
    cta: { label: "Upload files", icon: Upload },
  },
  {
    id: "permission",
    title: "Access denied",
    description: "You don't have permission to view this page. Contact your workspace admin if you believe this is an error.",
    icon: ShieldOff,
    tone: "danger",
    cta: { label: "Back to home", icon: Home, variant: "outline" },
    secondary: { label: "Request access", icon: Mail },
    custom: "permission",
  },
  {
    id: "offline",
    title: "You're offline",
    description: "We can't reach our servers. Check your internet connection and try again.",
    icon: WifiOff,
    tone: "warning",
    cta: { label: "Retry connection", icon: RefreshCw },
    custom: "offline",
  },
];

const toneBg: Record<string, string> = {
  primary: "bg-primary/10 text-primary",
  violet: "bg-violet-500/10 text-violet-500",
  warning: "bg-[color:var(--warning)]/12 text-[color:var(--warning)]",
  info: "bg-[color:var(--info)]/12 text-[color:var(--info)]",
  success: "bg-[color:var(--success)]/12 text-[color:var(--success)]",
  danger: "bg-destructive/12 text-destructive",
  neutral: "bg-muted text-muted-foreground",
};

const toneRing: Record<string, string> = {
  primary: "ring-primary/20",
  violet: "ring-violet-500/20",
  warning: "ring-[color:var(--warning)]/25",
  info: "ring-[color:var(--info)]/20",
  success: "ring-[color:var(--success)]/20",
  danger: "ring-destructive/20",
  neutral: "ring-border",
};

export default function EmptyStatesPage() {
  return (
    <>
      <PageHeader
        title="Empty States"
        description="A library of empty state designs for every common scenario. Each one is consistent, helpful, and actionable."
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Empty States" }]}
        icon={PackageOpen}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {STATES.map((s) => (
          <Card key={s.id} className="overflow-hidden">
            <CardHeader className="pb-2 pt-3.5 px-4 border-b border-border bg-muted/30 flex flex-row items-center justify-between">
              <CardTitle className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                {s.id.replace(/-/g, " ")}
              </CardTitle>
              <span className={cn(
                "px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase ring-1 ring-inset",
                toneBg[s.tone], toneRing[s.tone]
              )}>
                {s.tone}
              </span>
            </CardHeader>
            <CardContent className="p-6">
              {/* THE EMPTY STATE ITSELF */}
              <div className="flex flex-col items-center justify-center text-center rounded-xl border border-dashed border-border bg-card/40 py-10 px-5 relative overflow-hidden">
                {/* Decorative pattern */}
                {s.custom === "cart" && (
                  <div className="absolute inset-0 opacity-[0.04] pointer-events-none" aria-hidden>
                    <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(circle, currentColor 1px, transparent 1px)", backgroundSize: "16px 16px" }} />
                  </div>
                )}
                {s.custom === "permission" && (
                  <div className="absolute inset-0 bg-gradient-to-b from-destructive/[0.04] to-transparent" aria-hidden />
                )}
                {s.custom === "offline" && (
                  <div className="absolute inset-0 bg-gradient-to-b from-[color:var(--warning)]/[0.05] to-transparent" aria-hidden />
                )}

                <div className="relative">
                  {/* Icon stack for visual richness */}
                  {s.custom === "cart" ? (
                    <div className="relative mb-4">
                      <div className={cn("grid place-items-center h-16 w-16 rounded-2xl", toneBg[s.tone])}>
                        <s.icon className="h-7 w-7" strokeWidth={1.5} />
                      </div>
                      <div className="absolute -top-2 -right-2 grid place-items-center h-7 w-7 rounded-full bg-card border-2 border-border shadow-premium-xs">
                        <span className="text-xs font-bold text-muted-foreground">0</span>
                      </div>
                    </div>
                  ) : s.custom === "permission" ? (
                    <div className="relative mb-4">
                      <div className={cn("grid place-items-center h-16 w-16 rounded-2xl", toneBg[s.tone])}>
                        <s.icon className="h-7 w-7" strokeWidth={1.5} />
                      </div>
                      <div className="absolute -bottom-1 -right-1 grid place-items-center h-6 w-6 rounded-full bg-card border-2 border-border">
                        <ShieldOff className="h-3 w-3 text-destructive" />
                      </div>
                    </div>
                  ) : s.custom === "offline" ? (
                    <div className="relative mb-4">
                      <div className={cn("grid place-items-center h-16 w-16 rounded-2xl", toneBg[s.tone])}>
                        <s.icon className="h-7 w-7" strokeWidth={1.5} />
                      </div>
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-16 w-16 rounded-2xl border-2 border-dashed border-current opacity-30 animate-ping" style={{ animationDuration: "2.5s" }} />
                    </div>
                  ) : (
                    <div className={cn("grid place-items-center h-16 w-16 rounded-2xl mb-4", toneBg[s.tone])}>
                      <s.icon className="h-7 w-7" strokeWidth={1.5} />
                    </div>
                  )}

                  <h3 className="text-base font-semibold text-foreground">{s.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1.5 max-w-xs leading-relaxed">{s.description}</p>

                  {s.hasSearch && (
                    <div className="mt-4 w-full max-w-xs">
                      <Input placeholder="Try a different search..." className="text-center h-9" />
                    </div>
                  )}

                  <div className="mt-5 flex items-center justify-center gap-2 flex-wrap">
                    <Button
                      size="sm"
                      variant={s.cta.variant ?? "default"}
                      className="gap-1.5"
                      onClick={() => toast.success(s.cta.label)}
                    >
                      {s.cta.icon && <s.cta.icon className="h-3.5 w-3.5" />}
                      {s.cta.label}
                    </Button>
                    {s.secondary && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="gap-1.5 text-muted-foreground"
                        onClick={() => toast.message(s.secondary!.label)}
                      >
                        {s.secondary.icon && <s.secondary.icon className="h-3.5 w-3.5" />}
                        {s.secondary.label}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  );
}
