"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Eye,
  EyeOff,
  Loader2,
  Lock,
  LogOut,
  ShieldAlert,
  Unlock,
} from "lucide-react";
import { AuthShell } from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

const USER = {
  name: "Sarah Chen",
  email: "sarah@brightline.co",
  role: "Workspace Owner",
  avatar:
    "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=192&auto=format&fit=crop",
};

export default function LockScreenPage() {
  const router = useRouter();
  const [password, setPassword] = React.useState("");
  const [showPwd, setShowPwd] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [now, setNow] = React.useState<Date | null>(null);

  React.useEffect(() => {
    setNow(new Date());
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!password) {
      toast.error("Enter your password", { description: "Your password is required to unlock." });
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Welcome back", { description: `Session unlocked for ${USER.name}.` });
    router.push("/dashboards/ecommerce");
  }

  const timeStr = now
    ? now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true })
    : "--:--";
  const dateStr = now
    ? now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })
    : "Loading…";

  return (
    <AuthShell
      brand={{
        headline: "Your session is locked, not gone",
        subheadline:
          "We lock idle sessions after 15 minutes of inactivity to keep your workspace safe. Re-enter your password to pick up exactly where you left off.",
        showcaseImage:
          "https://images.unsplash.com/photo-1505761671935-60b3a7427bad?q=80&w=1600&auto=format&fit=crop",
        customers: ["Brightline", "Vela", "Apex Labs", "Cohere"],
      }}
    >
      <div className="space-y-6">
        {/* Live clock */}
        <div className="text-center space-y-1">
          <div className="text-4xl font-semibold tabular-nums tracking-tight">{timeStr}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider">{dateStr}</div>
        </div>

        {/* User preview card */}
        <div className="rounded-2xl border bg-card p-5 shadow-premium-sm">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img
                src={USER.avatar}
                alt={USER.name}
                className="h-14 w-14 rounded-full object-cover ring-2 ring-border"
              />
              <span className="absolute -bottom-0.5 -right-0.5 grid place-items-center h-5 w-5 rounded-full bg-amber-500 text-white ring-2 ring-card">
                <Lock className="h-2.5 w-2.5" />
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold truncate">{USER.name}</div>
              <div className="text-xs text-muted-foreground truncate">{USER.email}</div>
              <div className="text-[11px] font-medium text-primary mt-0.5">{USER.role}</div>
            </div>
          </div>
        </div>

        {/* Lock notice */}
        <div className="flex items-start gap-2.5 rounded-md border border-amber-500/30 bg-amber-500/10 p-3">
          <ShieldAlert className="h-4 w-4 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
          <p className="text-[11px] text-foreground/80 leading-relaxed">
            Session locked due to inactivity. Re-enter your password to resume. For your safety, unsaved
            changes remain in memory.
          </p>
        </div>

        {/* Unlock form */}
        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="password" className="text-xs flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5 text-muted-foreground" /> Password
            </Label>
            <div className="relative">
              <Input
                id="password"
                type={showPwd ? "text" : "password"}
                placeholder="Enter your password to unlock"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pr-9"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPwd((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                aria-label={showPwd ? "Hide password" : "Show password"}
              >
                {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <Button type="submit" className="w-full gap-1.5" disabled={loading}>
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Unlock className="h-4 w-4" />
            )}
            {loading ? "Unlocking…" : "Unlock workspace"}
          </Button>
        </form>

        <div className="flex items-center justify-between text-xs">
          <Link
            href="/auth/forgot-password"
            className="font-medium text-primary hover:underline"
          >
            Forgot password?
          </Link>
          <Link
            href="/auth/signin"
            className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sign in as different user
          </Link>
        </div>
      </div>
    </AuthShell>
  );
}
