"use client";

import * as React from "react";
import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle2,
  Loader2,
  MailCheck,
  MailQuestion,
  RefreshCw,
} from "lucide-react";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from "@/components/ui/input-otp";
import { AuthShell } from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const EMAIL = "sarah@brightline.co";
const COUNTDOWN_FROM = 60;

export default function VerifyEmailPage() {
  const [code, setCode] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const [seconds, setSeconds] = React.useState(COUNTDOWN_FROM);

  React.useEffect(() => {
    if (seconds <= 0) return;
    const id = window.setInterval(() => {
      setSeconds((s) => Math.max(0, s - 1));
    }, 1000);
    return () => window.clearInterval(id);
  }, [seconds]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (code.length !== 6) {
      toast.error("Enter all 6 digits", { description: "Your verification code must be 6 digits long." });
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    setDone(true);
    toast.success("Email verified", {
      description: "Your account is now fully activated.",
    });
  }

  function resend() {
    if (seconds > 0) return;
    setSeconds(COUNTDOWN_FROM);
    toast.success("Verification code resent", {
      description: `A new code was sent to ${EMAIL}.`,
    });
  }

  return (
    <AuthShell
      brand={{
        headline: "One last step to activate your account",
        subheadline:
          "We've sent a 6-digit verification code to your inbox. Enter it below to confirm ownership of your email address.",
        showcaseImage:
          "https://images.unsplash.com/photo-1596526131083-e8c633c948d2?q=80&w=1600&auto=format&fit=crop",
        customers: ["Vela", "Brightline", "Cohere", "Apex Labs"],
      }}
    >
      <div className="space-y-6">
        {!done ? (
          <>
            <div className="space-y-1.5">
              <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/10 text-primary mb-2">
                <MailCheck className="h-6 w-6" />
              </div>
              <h1 className="text-2xl font-semibold tracking-tight">Verify your email</h1>
              <p className="text-sm text-muted-foreground">
                Enter the 6-digit code we sent to{" "}
                <span className="font-medium text-foreground">{EMAIL}</span>
              </p>
            </div>

            <form onSubmit={onSubmit} className="space-y-5" noValidate>
              <div className="flex flex-col items-center gap-2">
                <InputOTP
                  maxLength={6}
                  value={code}
                  onChange={(v) => setCode(v)}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={1} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={2} className="h-12 w-12 text-base" />
                  </InputOTPGroup>
                  <InputOTPSeparator />
                  <InputOTPGroup>
                    <InputOTPSlot index={3} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={4} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={5} className="h-12 w-12 text-base" />
                  </InputOTPGroup>
                </InputOTP>
                <p className="text-[11px] text-muted-foreground">
                  Tip: the code is valid for 10 minutes.
                </p>
              </div>

              <Button type="submit" className="w-full" disabled={loading || code.length !== 6}>
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" />
                )}
                {loading ? "Verifying…" : "Verify email"}
              </Button>
            </form>

            <div className="flex items-center justify-between text-xs">
              <Link
                href="/auth/signup"
                className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors"
              >
                <MailQuestion className="h-3.5 w-3.5" />
                Wrong email? Change
              </Link>
              <button
                type="button"
                onClick={resend}
                disabled={seconds > 0}
                className="inline-flex items-center gap-1.5 font-medium text-primary hover:underline disabled:text-muted-foreground disabled:no-underline disabled:cursor-not-allowed"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                {seconds > 0 ? `Resend in ${seconds}s` : "Resend code"}
              </button>
            </div>

            <Link
              href="/auth/signin"
              className="inline-flex items-center justify-center gap-1.5 w-full text-xs font-medium text-muted-foreground hover:text-foreground transition-colors pt-1"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to sign in
            </Link>
          </>
        ) : (
          <div className="space-y-6 text-center">
            <div className="relative mx-auto grid place-items-center h-24 w-24">
              <span className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
              <span
                className="absolute inset-2 rounded-full bg-emerald-500/30 animate-ping"
                style={{ animationDelay: "0.3s" }}
              />
              <div className="relative grid place-items-center h-16 w-16 rounded-full bg-emerald-500 text-white shadow-premium-md animate-scale-in">
                <CheckCircle2 className="h-9 w-9" />
              </div>
            </div>

            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">Email verified</h1>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                Your email <span className="font-medium text-foreground">{EMAIL}</span> has been confirmed.
                Welcome to NexusGrid — let&apos;s get you to your dashboard.
              </p>
            </div>

            <Button asChild className="w-full gap-1.5">
              <Link href="/dashboards/ecommerce">
                Continue to dashboard
              </Link>
            </Button>
          </div>
        )}
      </div>
    </AuthShell>
  );
}
