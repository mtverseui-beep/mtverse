"use client";

import * as React from "react";
import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle2,
  HelpCircle,
  KeyRound,
  Loader2,
  Shield,
  Smartphone,
} from "lucide-react";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from "@/components/ui/input-otp";
import { AuthShell } from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

export default function TwoFactorPage() {
  const [code, setCode] = React.useState("");
  const [backupMode, setBackupMode] = React.useState(false);
  const [backup, setBackup] = React.useState("");
  const [trusted, setTrusted] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [done, setDone] = React.useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (backupMode) {
      if (backup.trim().length < 8) {
        toast.error("Invalid backup code", {
          description: "Backup codes are 10 characters, formatted like XXXX-XXXX-XX.",
        });
        return;
      }
    } else {
      if (code.length !== 6) {
        toast.error("Enter all 6 digits", { description: "Your authenticator code must be 6 digits." });
        return;
      }
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    setDone(true);
    toast.success("Two-factor verified", {
      description: trusted ? "This device is now trusted for 30 days." : "Welcome back.",
    });
  }

  return (
    <AuthShell
      brand={{
        headline: "An extra layer of security, by design",
        subheadline:
          "Two-factor authentication keeps your account safe even if your password leaks. Generate codes from any authenticator app.",
        showcaseImage:
          "https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=1600&auto=format&fit=crop",
        customers: ["Brightline", "Vela", "Apex Labs", "Cohere"],
      }}
    >
      <div className="space-y-6">
        {!done ? (
          <>
            <div className="space-y-1.5">
              <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/10 text-primary mb-2">
                {backupMode ? <KeyRound className="h-6 w-6" /> : <Smartphone className="h-6 w-6" />}
              </div>
              <h1 className="text-2xl font-semibold tracking-tight">
                {backupMode ? "Enter a backup code" : "Two-factor authentication"}
              </h1>
              <p className="text-sm text-muted-foreground">
                {backupMode
                  ? "Enter one of the 10 backup codes you saved when you set up 2FA."
                  : "Open your authenticator app (1Password, Authy, Google Authenticator) and enter the 6-digit code."}
              </p>
            </div>

            <form onSubmit={onSubmit} className="space-y-5" noValidate>
              {!backupMode ? (
                <div className="flex flex-col items-center gap-2">
                  <InputOTP maxLength={6} value={code} onChange={(v) => setCode(v)}>
                    <InputOTPGroup>
                      <InputOTPSlot index={0} className="h-12 w-12 text-base" />
                      <InputOTPSlot index={1} className="h-12 w-12 text-base" />
                      <InputOTPSlot index={2} className="h-12 w-12 text-base" />
                    </InputOTPGroup>
                    <InputOTPSeparator />
                    <InputOTPGroup>
                      <InputOTPSlot index={3} className="h-12 w-12 text-base" />
                      <InputOTPSlot index={4} className="h-12 w-12 text-base" />
                      <InputOTPSlot index={5} className="h-12 w-12 text-base" />
                    </InputOTPGroup>
                  </InputOTP>
                  <p className="text-[11px] text-muted-foreground">Codes refresh every 30 seconds.</p>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <Label htmlFor="backup" className="text-xs flex items-center gap-1.5">
                    <KeyRound className="h-3.5 w-3.5 text-muted-foreground" /> Backup code
                  </Label>
                  <Input
                    id="backup"
                    placeholder="XXXX-XXXX-XX"
                    value={backup}
                    onChange={(e) => setBackup(e.target.value.toUpperCase())}
                    className="font-mono tracking-widest h-11"
                    autoComplete="one-time-code"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Each backup code can only be used once. You saved these when enabling 2FA.
                  </p>
                </div>
              )}

              <div className="flex items-start gap-2.5 rounded-md border p-3">
                <Checkbox
                  id="trusted"
                  checked={trusted}
                  onCheckedChange={(v) => setTrusted(v === true)}
                  className="mt-0.5"
                />
                <div className="grid gap-0.5">
                  <Label htmlFor="trusted" className="text-xs font-medium cursor-pointer">
                    Trust this device for 30 days
                  </Label>
                  <p className="text-[11px] text-muted-foreground">
                    Skip 2FA on this device until the trust expires. Don&apos;t enable on shared computers.
                  </p>
                </div>
              </div>

              <Button type="submit" className="w-full gap-1.5" disabled={loading}>
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Shield className="h-4 w-4" />
                )}
                {loading ? "Verifying…" : "Verify and continue"}
              </Button>
            </form>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  setBackupMode((s) => !s);
                  setCode("");
                  setBackup("");
                }}
                className="w-full text-center text-xs font-medium text-primary hover:underline"
              >
                {backupMode ? "Use authenticator code instead" : "Use a backup code instead"}
              </button>
              <Separator />
              <div className="flex items-center justify-between text-xs">
                <Link
                  href="/auth/signin"
                  className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  Back to sign in
                </Link>
                <Link
                  href="/auth/forgot-password"
                  className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <HelpCircle className="h-3.5 w-3.5" />
                  Need help?
                </Link>
              </div>
            </div>
          </>
        ) : (
          <div className="space-y-6 text-center">
            <div className="relative mx-auto grid place-items-center h-24 w-24">
              <span className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
              <div className="relative grid place-items-center h-16 w-16 rounded-full bg-emerald-500 text-white shadow-premium-md animate-scale-in">
                <CheckCircle2 className="h-9 w-9" />
              </div>
            </div>

            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">Identity confirmed</h1>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                {trusted
                  ? "This device is now trusted for 30 days. You won't be asked for a code again until then."
                  : "You're signed in securely. Take me to your dashboard."}
              </p>
            </div>

            <Button asChild className="w-full gap-1.5">
              <Link href="/dashboards/ecommerce">
                Continue to dashboard
              </Link>
            </Button>
          </div>
        )}
      </div>
    </AuthShell>
  );
}
