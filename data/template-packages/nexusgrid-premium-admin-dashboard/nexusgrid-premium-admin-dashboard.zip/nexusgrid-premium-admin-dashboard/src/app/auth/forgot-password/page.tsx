"use client";

import * as React from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Clock,
  Loader2,
  Mail,
  MailCheck,
} from "lucide-react";
import { AuthShell } from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function ForgotPasswordPage() {
  const [email, setEmail] = React.useState("");
  const [error, setError] = React.useState<string | undefined>();
  const [loading, setLoading] = React.useState(false);
  const [sent, setSent] = React.useState(false);

  function validate() {
    if (!email) {
      setError("Email is required");
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Enter a valid email address");
      return false;
    }
    setError(undefined);
    return true;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    setSent(true);
    toast.success("Reset link sent", {
      description: `Check ${email} for instructions.`,
    });
  }

  return (
    <AuthShell
      brand={{
        headline: "Recover access in three quick steps",
        subheadline:
          "Tell us your work email and we'll send a secure, time-limited reset link. The link expires in 30 minutes.",
        showcaseImage:
          "https://images.unsplash.com/photo-1516302752625-fcc3c50ae61f?q=80&w=1600&auto=format&fit=crop",
        customers: ["Northwind", "Lumen", "Vela", "Apex Labs", "Cohere"],
      }}
    >
      <div className="space-y-6">
        {!sent ? (
          <>
            <div className="space-y-1.5">
              <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/10 text-primary mb-2">
                <Mail className="h-6 w-6" />
              </div>
              <h1 className="text-2xl font-semibold tracking-tight">Forgot password?</h1>
              <p className="text-sm text-muted-foreground">
                No worries — enter your work email and we&apos;ll send you reset instructions.
              </p>
            </div>

            <form onSubmit={onSubmit} className="space-y-4" noValidate>
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-muted-foreground" /> Work email
                </Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  placeholder="you@company.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError(undefined);
                  }}
                  aria-invalid={!!error}
                />
                {error && <p className="text-[11px] text-destructive">{error}</p>}
              </div>

              <Button type="submit" className="w-full gap-1.5" disabled={loading}>
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ArrowRight className="h-4 w-4" />
                )}
                {loading ? "Sending reset link…" : "Send reset link"}
              </Button>
            </form>

            <div className="rounded-md bg-muted/50 p-3 flex items-start gap-2.5">
              <Clock className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                The reset link expires in <span className="font-medium text-foreground">30 minutes</span>. If you
                don&apos;t receive an email within a few minutes, check your spam folder or contact your workspace admin.
              </p>
            </div>
          </>
        ) : (
          <div className="space-y-6 text-center">
            <div className="relative mx-auto grid place-items-center h-20 w-20">
              <span className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
              <div className="relative grid place-items-center h-16 w-16 rounded-full bg-emerald-500 text-white shadow-premium-md">
                <CheckCircle2 className="h-8 w-8" />
              </div>
            </div>

            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">Check your email</h1>
              <p className="text-sm text-muted-foreground">
                We&apos;ve sent a password reset link to
              </p>
              <p className="text-sm font-medium text-foreground">{email}</p>
            </div>

            <div className="rounded-md border bg-muted/40 p-4 text-left">
              <div className="flex items-start gap-3">
                <div className="grid place-items-center h-9 w-9 rounded-lg bg-primary/10 text-primary shrink-0">
                  <MailCheck className="h-4.5 w-4.5" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-medium">Didn&apos;t get the email?</p>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">
                    Check your spam folder, verify the address is correct, or try resending. The link is valid for
                    30 minutes.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={() => {
                  setSent(false);
                  setEmail("");
                }}
              >
                Use a different email
              </Button>
              <Link
                href="/auth/signin"
                className="inline-flex items-center justify-center gap-1.5 w-full text-xs font-medium text-muted-foreground hover:text-foreground transition-colors pt-2"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                Back to sign in
              </Link>
            </div>
          </div>
        )}

        {!sent && (
          <Link
            href="/auth/signin"
            className="inline-flex items-center justify-center gap-1.5 w-full text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to sign in
          </Link>
        )}
      </div>
    </AuthShell>
  );
}
