"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Building2,
  Eye,
  EyeOff,
  Github,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
  User,
} from "lucide-react";
import {
  AuthShell,
  PasswordStrengthBar,
} from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

export default function SignUpPage() {
  const router = useRouter();
  const [form, setForm] = React.useState({
    name: "",
    email: "",
    company: "",
    password: "",
    confirm: "",
    terms: false,
  });
  const [showPwd, setShowPwd] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [errors, setErrors] = React.useState<Record<string, string>>({});

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    if (errors[key as string]) {
      setErrors((p) => {
        const n = { ...p };
        delete n[key as string];
        return n;
      });
    }
  }

  function validate() {
    const next: Record<string, string> = {};
    if (!form.name.trim()) next.name = "Full name is required";
    else if (form.name.trim().length < 2) next.name = "Name must be at least 2 characters";
    if (!form.email) next.email = "Work email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = "Enter a valid email address";
    if (!form.company.trim()) next.company = "Company name is required";
    if (!form.password) next.password = "Password is required";
    else if (form.password.length < 8) next.password = "Use at least 8 characters";
    else if (!/[A-Z]/.test(form.password) || !/[0-9]/.test(form.password))
      next.password = "Mix uppercase letters and numbers";
    if (form.confirm !== form.password) next.confirm = "Passwords do not match";
    if (!form.terms) next.terms = "Please accept the terms to continue";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    toast.success("Account created", {
      description: `Welcome to NexusGrid, ${form.name.split(" ")[0]}. Let's set up your workspace.`,
    });
    router.push("/auth/onboarding");
  }

  return (
    <AuthShell
      brand={{
        headline: "Where high-velocity teams run their operations",
        subheadline:
          "Start free in under two minutes. Connect your data, invite teammates, and ship your first dashboard before lunch.",
        showcaseImage:
          "https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=1600&auto=format&fit=crop",
        customers: ["Brightline", "Northwind", "Vela", "Apex Labs", "Cohere", "Helix"],
        testimonial: {
          quote:
            "We onboarded 38 engineers in a single afternoon. The invite flow, roles, and SSO just worked out of the box.",
          author: "Devon Park",
          role: "Head of Platform, Cohere",
          avatar:
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=128&auto=format&fit=crop",
        },
      }}
    >
      <div className="space-y-6">
        <div className="space-y-1.5">
          <h1 className="text-2xl font-semibold tracking-tight">Create your account</h1>
          <p className="text-sm text-muted-foreground">
            14-day Pro trial. No credit card required. Cancel anytime.
          </p>
        </div>

        {/* Social sign-up */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <SocialButton icon={GoogleIcon} label="Google" onClick={() => toast.info("Redirecting to Google…")} />
          <SocialButton icon={Github} label="GitHub" onClick={() => toast.info("Redirecting to GitHub…")} />
          <SocialButton icon={ShieldCheck} label="SSO" onClick={() => toast.info("Contact your IT admin for SSO")} />
        </div>

        <div className="relative">
          <Separator />
          <span className="absolute left-1/2 -translate-x-1/2 -top-2.5 bg-background px-3 text-[11px] text-muted-foreground uppercase tracking-wider">
            or sign up with email
          </span>
        </div>

        <form onSubmit={onSubmit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="name" className="text-xs flex items-center gap-1.5">
              <User className="h-3.5 w-3.5 text-muted-foreground" /> Full name
            </Label>
            <Input
              id="name"
              placeholder="Sarah Chen"
              autoComplete="name"
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              aria-invalid={!!errors.name}
            />
            {errors.name && <p className="text-[11px] text-destructive">{errors.name}</p>}
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-xs flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-muted-foreground" /> Work email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="sarah@company.com"
                autoComplete="email"
                value={form.email}
                onChange={(e) => set("email", e.target.value)}
                aria-invalid={!!errors.email}
              />
              {errors.email && <p className="text-[11px] text-destructive">{errors.email}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="company" className="text-xs flex items-center gap-1.5">
                <Building2 className="h-3.5 w-3.5 text-muted-foreground" /> Company
              </Label>
              <Input
                id="company"
                placeholder="Acme Inc."
                autoComplete="organization"
                value={form.company}
                onChange={(e) => set("company", e.target.value)}
                aria-invalid={!!errors.company}
              />
              {errors.company && <p className="text-[11px] text-destructive">{errors.company}</p>}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="password" className="text-xs flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5 text-muted-foreground" /> Password
            </Label>
            <div className="relative">
              <Input
                id="password"
                type={showPwd ? "text" : "password"}
                placeholder="Create a strong password"
                autoComplete="new-password"
                value={form.password}
                onChange={(e) => set("password", e.target.value)}
                aria-invalid={!!errors.password}
                className="pr-9"
              />
              <button
                type="button"
                onClick={() => setShowPwd((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                aria-label={showPwd ? "Hide password" : "Show password"}
              >
                {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <PasswordStrengthBar password={form.password} />
            {errors.password && <p className="text-[11px] text-destructive">{errors.password}</p>}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="confirm" className="text-xs flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-muted-foreground" /> Confirm password
            </Label>
            <div className="relative">
              <Input
                id="confirm"
                type={showConfirm ? "text" : "password"}
                placeholder="Re-enter your password"
                autoComplete="new-password"
                value={form.confirm}
                onChange={(e) => set("confirm", e.target.value)}
                aria-invalid={!!errors.confirm}
                className="pr-9"
              />
              <button
                type="button"
                onClick={() => setShowConfirm((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                aria-label={showConfirm ? "Hide password" : "Show password"}
              >
                {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {errors.confirm && <p className="text-[11px] text-destructive">{errors.confirm}</p>}
          </div>

          <div className="rounded-md border p-3">
            <div className="flex items-start gap-2.5">
              <Checkbox
                id="terms"
                checked={form.terms}
                onCheckedChange={(v) => set("terms", v === true)}
                className="mt-0.5"
              />
              <div className="grid gap-0.5">
                <Label htmlFor="terms" className="text-xs font-medium cursor-pointer">
                  I agree to the Terms of Service and Privacy Policy
                </Label>
                <p className="text-[11px] text-muted-foreground">
                  By creating an account you consent to receive transactional emails. Unsubscribe anytime.
                </p>
                {errors.terms && <p className="text-[11px] text-destructive mt-1">{errors.terms}</p>}
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full gap-1.5" disabled={loading}>
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <ArrowRight className="h-4 w-4" />
            )}
            {loading ? "Creating account…" : "Create account"}
          </Button>
        </form>

        <p className="text-center text-xs text-muted-foreground">
          Already have an account?{" "}
          <Link href="/auth/signin" className="font-medium text-primary hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </AuthShell>
  );
}

function SocialButton({
  icon: Icon,
  label,
  onClick,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  onClick: () => void;
}) {
  return (
    <Button type="button" variant="outline" onClick={onClick} className="gap-2 h-10">
      <Icon className="h-4 w-4" />
      <span className="text-xs font-medium">{label}</span>
    </Button>
  );
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.76h3.56c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.56-2.76c-.98.66-2.23 1.06-3.72 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
    </svg>
  );
}
