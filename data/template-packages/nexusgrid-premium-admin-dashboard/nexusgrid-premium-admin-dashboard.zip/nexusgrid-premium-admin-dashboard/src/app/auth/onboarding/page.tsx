"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  Check,
  CheckCircle2,
  Cloud,
  Crown,
  Loader2,
  Mail,
  Plus,
  Rocket,
  Trash2,
  Upload,
  User,
  Users,
  X,
} from "lucide-react";
import { AuthShell } from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const STEPS = [
  { key: "workspace", label: "Workspace", icon: Building2 },
  { key: "profile", label: "Profile", icon: User },
  { key: "teammates", label: "Invite team", icon: Users },
  { key: "plan", label: "Choose plan", icon: Crown },
] as const;

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = React.useState(0);

  // Step 1 — workspace
  const [workspaceName, setWorkspaceName] = React.useState("");
  const [workspaceUrl, setWorkspaceUrl] = React.useState("");

  // Step 2 — profile
  const [avatar, setAvatar] = React.useState<string | null>(null);
  const [role, setRole] = React.useState("");
  const [department, setDepartment] = React.useState("");

  // Step 3 — teammates
  const [emails, setEmails] = React.useState<string[]>([""]);

  // Step 4 — plan
  const [plan, setPlan] = React.useState<"free" | "pro" | "enterprise" | null>(null);
  const [billing, setBilling] = React.useState<"monthly" | "annual">("annual");

  const [completing, setCompleting] = React.useState(false);

  function next() {
    if (step === 0) {
      if (!workspaceName.trim()) {
        toast.error("Workspace name required", { description: "Give your workspace a name to continue." });
        return;
      }
    }
    if (step === 1) {
      if (!role) {
        toast.error("Select your role", { description: "Pick the role that best describes you." });
        return;
      }
    }
    setStep((s) => Math.min(STEPS.length - 1, s + 1));
  }

  function back() {
    setStep((s) => Math.max(0, s - 1));
  }

  function skip() {
    setStep((s) => Math.min(STEPS.length - 1, s + 1));
    toast.message("Step skipped", { description: "You can complete this later in Settings." });
  }

  function addEmailField() {
    setEmails((e) => [...e, ""]);
  }

  function removeEmailField(idx: number) {
    setEmails((e) => e.filter((_, i) => i !== idx));
  }

  function updateEmail(idx: number, value: string) {
    setEmails((e) => e.map((v, i) => (i === idx ? value : v)));
  }

  async function complete() {
    if (!plan) {
      toast.error("Select a plan", { description: "Choose a plan to finish setup." });
      return;
    }
    setCompleting(true);
    await new Promise((r) => setTimeout(r, 1100));
    setCompleting(false);
    toast.success("Workspace ready", {
      description: `Welcome to ${workspaceName || "your workspace"}. Taking you to the dashboard.`,
    });
    router.push("/dashboards/ecommerce");
  }

  // Auto-derive workspace URL from name
  React.useEffect(() => {
    if (workspaceName.trim()) {
      setWorkspaceUrl(
        workspaceName
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "")
      );
    }
  }, [workspaceName]);

  return (
    <AuthShell
      wide
      brand={{
        headline: "Let's set up your NexusGrid workspace",
        subheadline:
          "Four quick steps and you'll have a fully configured workspace with your team, your role, and your plan — ready to ship.",
        showcaseImage:
          "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=1600&auto=format&fit=crop",
        customers: ["Brightline", "Vela", "Apex Labs", "Cohere", "Helix"],
      }}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="space-y-1.5">
          <Badge variant="secondary" className="mb-1">
            <Rocket className="h-3 w-3 mr-1" /> Onboarding
          </Badge>
          <h1 className="text-2xl font-semibold tracking-tight">Welcome to NexusGrid</h1>
          <p className="text-sm text-muted-foreground">
            Set up your workspace in less than two minutes. You can change everything later.
          </p>
        </div>

        {/* Progress */}
        <Progress current={step} />

        {/* Step content */}
        <div className="min-h-[280px]">
          {step === 0 && (
            <StepWorkspace
              workspaceName={workspaceName}
              setWorkspaceName={setWorkspaceName}
              workspaceUrl={workspaceUrl}
            />
          )}
          {step === 1 && (
            <StepProfile
              avatar={avatar}
              setAvatar={setAvatar}
              role={role}
              setRole={setRole}
              department={department}
              setDepartment={setDepartment}
            />
          )}
          {step === 2 && (
            <StepTeammates
              emails={emails}
              addEmailField={addEmailField}
              removeEmailField={removeEmailField}
              updateEmail={updateEmail}
            />
          )}
          {step === 3 && (
            <StepPlan
              plan={plan}
              setPlan={setPlan}
              billing={billing}
              setBilling={setBilling}
            />
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t">
          <Button
            type="button"
            variant="ghost"
            onClick={back}
            disabled={step === 0}
            className="gap-1.5"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <div className="flex items-center gap-2">
            {step < STEPS.length - 1 && (
              <Button
                type="button"
                variant="ghost"
                onClick={skip}
                className="text-muted-foreground"
              >
                Skip for now
              </Button>
            )}
            {step < STEPS.length - 1 ? (
              <Button type="button" onClick={next} className="gap-1.5">
                Continue
                <ArrowRight className="h-4 w-4" />
              </Button>
            ) : (
              <Button type="button" onClick={complete} disabled={completing} className="gap-1.5">
                {completing ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" />
                )}
                {completing ? "Setting up workspace…" : "Complete setup"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </AuthShell>
  );
}

/* ----------------------------- Progress bar ----------------------------- */
function Progress({ current }: { current: number }) {
  return (
    <div className="flex items-center gap-2">
      {STEPS.map((s, i) => {
        const done = i < current;
        const active = i === current;
        const Icon = s.icon;
        return (
          <div key={s.key} className="flex items-center gap-2 flex-1">
            <div className="flex items-center gap-2 min-w-0">
              <div
                className={cn(
                  "grid place-items-center h-8 w-8 rounded-full shrink-0 transition-colors",
                  done && "bg-primary text-primary-foreground",
                  active && "bg-primary text-primary-foreground ring-4 ring-primary/20",
                  !done && !active && "bg-muted text-muted-foreground"
                )}
              >
                {done ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
              </div>
              <div className="min-w-0 hidden sm:block">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Step {i + 1}
                </div>
                <div
                  className={cn(
                    "text-xs font-medium truncate",
                    active ? "text-foreground" : "text-muted-foreground"
                  )}
                >
                  {s.label}
                </div>
              </div>
            </div>
            {i < STEPS.length - 1 && (
              <div
                className={cn(
                  "h-0.5 flex-1 rounded-full transition-colors",
                  i < current ? "bg-primary" : "bg-muted"
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ----------------------------- Step 1: Workspace ----------------------------- */
function StepWorkspace({
  workspaceName,
  setWorkspaceName,
  workspaceUrl,
}: {
  workspaceName: string;
  setWorkspaceName: (v: string) => void;
  workspaceUrl: string;
}) {
  return (
    <div className="space-y-5 animate-fade-in-up">
      <div className="space-y-1">
        <h2 className="text-lg font-semibold">Name your workspace</h2>
        <p className="text-xs text-muted-foreground">
          This is how your team will identify the workspace. You can rename it anytime.
        </p>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="ws-name" className="text-xs flex items-center gap-1.5">
          <Building2 className="h-3.5 w-3.5 text-muted-foreground" /> Workspace name
        </Label>
        <Input
          id="ws-name"
          placeholder="Acme Operations"
          value={workspaceName}
          onChange={(e) => setWorkspaceName(e.target.value)}
          autoFocus
        />
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="ws-url" className="text-xs flex items-center gap-1.5">
          <Cloud className="h-3.5 w-3.5 text-muted-foreground" /> Workspace URL
        </Label>
        <div className="flex items-center rounded-md border bg-background focus-within:ring-2 focus-within:ring-ring/50 transition-shadow">
          <span className="pl-3 pr-1 text-xs text-muted-foreground font-mono select-none">
            https://
          </span>
          <input
            id="ws-url"
            value={workspaceUrl || "your-workspace"}
            onChange={() => {
              /* derived from name */
            }}
            readOnly
            className="flex-1 bg-transparent py-2 pr-3 text-xs font-mono outline-none"
          />
          <span className="pr-3 text-xs text-muted-foreground font-mono select-none">
            .nexusgrid.app
          </span>
        </div>
        <p className="text-[11px] text-muted-foreground">
          Your workspace URL is auto-generated from the name. Custom domains are available on Pro and above.
        </p>
      </div>

      {/* Workspace type presets */}
      <div className="space-y-2">
        <div className="text-xs font-medium">Or pick a template</div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Startup", desc: "Lean team" },
            { label: "Agency", desc: "Multi-client" },
            { label: "Enterprise", desc: "Large org" },
          ].map((t) => (
            <button
              key={t.label}
              type="button"
              onClick={() => setWorkspaceName(t.label + " Workspace")}
              className={cn(
                "rounded-lg border p-3 text-left transition-colors hover:border-primary/50 hover:bg-accent/40",
                workspaceName === t.label + " Workspace" && "border-primary bg-primary/5"
              )}
            >
              <div className="text-xs font-semibold">{t.label}</div>
              <div className="text-[10px] text-muted-foreground">{t.desc}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- Step 2: Profile ----------------------------- */
function StepProfile({
  avatar,
  setAvatar,
  role,
  setRole,
  department,
  setDepartment,
}: {
  avatar: string | null;
  setAvatar: (v: string | null) => void;
  role: string;
  setRole: (v: string) => void;
  department: string;
  setDepartment: (v: string) => void;
}) {
  const fileInput = React.useRef<HTMLInputElement>(null);

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 4 * 1024 * 1024) {
      toast.error("Image too large", { description: "Pick an image under 4 MB." });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setAvatar(reader.result as string);
    reader.readAsDataURL(f);
  }

  return (
    <div className="space-y-5 animate-fade-in-up">
      <div className="space-y-1">
        <h2 className="text-lg font-semibold">Set up your profile</h2>
        <p className="text-xs text-muted-foreground">
          Add a photo, your role, and your department so teammates can recognize you.
        </p>
      </div>

      {/* Avatar upload */}
      <div className="flex items-center gap-4">
        <div className="relative">
          {avatar ? (
            <img
              src={avatar}
              alt="Avatar preview"
              className="h-20 w-20 rounded-full object-cover ring-2 ring-border"
            />
          ) : (
            <div className="grid place-items-center h-20 w-20 rounded-full bg-muted text-muted-foreground ring-2 ring-border">
              <User className="h-8 w-8" />
            </div>
          )}
          <button
            type="button"
            onClick={() => fileInput.current?.click()}
            className="absolute -bottom-1 -right-1 grid place-items-center h-7 w-7 rounded-full bg-primary text-primary-foreground ring-2 ring-background hover:bg-primary/90 transition-colors"
            aria-label="Upload avatar"
          >
            <Upload className="h-3.5 w-3.5" />
          </button>
          <input
            ref={fileInput}
            type="file"
            accept="image/*"
            onChange={onFile}
            className="hidden"
          />
        </div>
        <div className="space-y-1">
          <div className="text-sm font-medium">Profile photo</div>
          <p className="text-[11px] text-muted-foreground">PNG, JPG, or GIF. Max 4 MB.</p>
          {avatar && (
            <button
              type="button"
              onClick={() => setAvatar(null)}
              className="text-[11px] text-destructive hover:underline"
            >
              Remove photo
            </button>
          )}
        </div>
      </div>

      {/* Role + Department */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label className="text-xs flex items-center gap-1.5">
            <User className="h-3.5 w-3.5 text-muted-foreground" /> Your role
          </Label>
          <Select value={role} onValueChange={setRole}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="founder">Founder / Executive</SelectItem>
              <SelectItem value="product">Product Manager</SelectItem>
              <SelectItem value="engineering">Engineer</SelectItem>
              <SelectItem value="design">Designer</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
              <SelectItem value="sales">Sales</SelectItem>
              <SelectItem value="ops">Operations</SelectItem>
              <SelectItem value="finance">Finance</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5 text-muted-foreground" /> Department
          </Label>
          <Select value={department} onValueChange={setDepartment}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="engineering">Engineering</SelectItem>
              <SelectItem value="product">Product</SelectItem>
              <SelectItem value="design">Design</SelectItem>
              <SelectItem value="growth">Growth & Marketing</SelectItem>
              <SelectItem value="revenue">Revenue</SelectItem>
              <SelectItem value="ops">Operations</SelectItem>
              <SelectItem value="people">People</SelectItem>
              <SelectItem value="finance">Finance</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Role quick-pick chips */}
      <div className="space-y-2">
        <div className="text-[11px] font-medium text-muted-foreground">Quick pick</div>
        <div className="flex flex-wrap gap-2">
          {[
            { v: "founder", l: "Founder" },
            { v: "product", l: "Product" },
            { v: "engineering", l: "Engineer" },
            { v: "design", l: "Designer" },
            { v: "marketing", l: "Marketing" },
          ].map((r) => (
            <button
              key={r.v}
              type="button"
              onClick={() => setRole(r.v)}
              className={cn(
                "rounded-full border px-3 py-1 text-[11px] font-medium transition-colors",
                role === r.v
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border hover:bg-accent/40"
              )}
            >
              {r.l}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- Step 3: Teammates ----------------------------- */
function StepTeammates({
  emails,
  addEmailField,
  removeEmailField,
  updateEmail,
}: {
  emails: string[];
  addEmailField: () => void;
  removeEmailField: (idx: number) => void;
  updateEmail: (idx: number, v: string) => void;
}) {
  const validEmails = emails.filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e));

  function sendInvites() {
    if (validEmails.length === 0) {
      toast.error("Add at least one email", { description: "Enter a valid email to invite." });
      return;
    }
    toast.success(`${validEmails.length} invitation${validEmails.length > 1 ? "s" : ""} queued`, {
      description: "We'll send invites once setup completes.",
    });
  }

  return (
    <div className="space-y-5 animate-fade-in-up">
      <div className="space-y-1">
        <h2 className="text-lg font-semibold">Invite your teammates</h2>
        <p className="text-xs text-muted-foreground">
          Add up to 10 teammates now — they&apos;ll receive an invitation once setup is complete.
        </p>
      </div>

      <div className="space-y-2.5">
        {emails.map((email, idx) => (
          <div key={idx} className="flex items-center gap-2">
            <div className="relative flex-1">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                type="email"
                placeholder="teammate@company.com"
                value={email}
                onChange={(e) => updateEmail(idx, e.target.value)}
                className="pl-9"
              />
            </div>
            {emails.length > 1 && (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeEmailField(idx)}
                aria-label="Remove email"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={addEmailField}
          disabled={emails.length >= 10}
          className="gap-1.5"
        >
          <Plus className="h-3.5 w-3.5" />
          Add another
        </Button>
        <div className="text-[11px] text-muted-foreground">
          {validEmails.length > 0
            ? `${validEmails.length} valid email${validEmails.length > 1 ? "s" : ""} ready`
            : "Optional — skip to invite later"}
        </div>
      </div>

      {validEmails.length > 0 && (
        <div className="rounded-md border bg-muted/40 p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="text-[11px] font-medium">Invitation preview</div>
            <button
              type="button"
              onClick={sendInvites}
              className="text-[11px] font-medium text-primary hover:underline"
            >
              Send test invite
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {validEmails.map((e) => (
              <span
                key={e}
                className="inline-flex items-center gap-1 rounded-full bg-background border px-2 py-0.5 text-[10px] font-medium"
              >
                {e}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-start gap-2.5 rounded-md border border-dashed p-3">
        <Trash2 className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          Each invitee will get a personalized email with a one-click accept link. Invitations expire after 7 days.
        </p>
      </div>
    </div>
  );
}

/* ----------------------------- Step 4: Plan ----------------------------- */
const PLANS = [
  {
    key: "free" as const,
    name: "Free",
    price: { monthly: 0, annual: 0 },
    tagline: "For small teams getting started",
    icon: Rocket,
    features: [
      "Up to 3 members",
      "5 dashboards",
      "Community support",
      "1 GB storage",
    ],
    accent: "bg-muted text-muted-foreground",
  },
  {
    key: "pro" as const,
    name: "Pro",
    price: { monthly: 24, annual: 19 },
    tagline: "For growing teams that need more",
    icon: Crown,
    features: [
      "Unlimited members",
      "Unlimited dashboards",
      "Priority support",
      "100 GB storage",
      "Custom domains",
      "Advanced analytics",
    ],
    accent: "bg-primary text-primary-foreground",
    popular: true,
  },
  {
    key: "enterprise" as const,
    name: "Enterprise",
    price: { monthly: 89, annual: 72 },
    tagline: "For organizations at scale",
    icon: Building2,
    features: [
      "Everything in Pro",
      "SSO & SAML",
      "Dedicated success manager",
      "1 TB storage",
      "Audit logs & DLP",
      "99.99% uptime SLA",
    ],
    accent: "bg-foreground text-background",
  },
];

function StepPlan({
  plan,
  setPlan,
  billing,
  setBilling,
}: {
  plan: "free" | "pro" | "enterprise" | null;
  setPlan: (v: "free" | "pro" | "enterprise") => void;
  billing: "monthly" | "annual";
  setBilling: (v: "monthly" | "annual") => void;
}) {
  return (
    <div className="space-y-5 animate-fade-in-up">
      <div className="space-y-1">
        <h2 className="text-lg font-semibold">Choose your plan</h2>
        <p className="text-xs text-muted-foreground">
          Start with any plan. You can upgrade, downgrade, or cancel anytime from billing settings.
        </p>
      </div>

      {/* Billing toggle */}
      <div className="inline-flex items-center rounded-full border bg-background p-1">
        <button
          type="button"
          onClick={() => setBilling("monthly")}
          className={cn(
            "rounded-full px-4 py-1.5 text-xs font-medium transition-colors",
            billing === "monthly" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
          )}
        >
          Monthly
        </button>
        <button
          type="button"
          onClick={() => setBilling("annual")}
          className={cn(
            "rounded-full px-4 py-1.5 text-xs font-medium transition-colors inline-flex items-center gap-1.5",
            billing === "annual" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
          )}
        >
          Annual
          <span className={cn(
            "rounded-full px-1.5 py-0.5 text-[9px] font-semibold",
            billing === "annual" ? "bg-primary-foreground/20 text-primary-foreground" : "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
          )}>
            −20%
          </span>
        </button>
      </div>

      {/* Plan cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {PLANS.map((p) => {
          const Icon = p.icon;
          const selected = plan === p.key;
          return (
            <button
              key={p.key}
              type="button"
              onClick={() => setPlan(p.key)}
              className={cn(
                "relative rounded-xl border p-4 text-left transition-all",
                selected
                  ? "border-primary ring-2 ring-primary/20 bg-primary/5"
                  : "border-border hover:border-primary/40 hover:bg-accent/30"
              )}
            >
              {p.popular && (
                <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground text-[9px] px-2 py-0.5">
                    Most popular
                  </Badge>
                </div>
              )}
              <div className="flex items-center justify-between mb-3">
                <div className={cn("grid place-items-center h-9 w-9 rounded-lg", p.accent)}>
                  <Icon className="h-4.5 w-4.5" />
                </div>
                {selected && (
                  <span className="grid place-items-center h-5 w-5 rounded-full bg-primary text-primary-foreground">
                    <Check className="h-3 w-3" />
                  </span>
                )}
              </div>
              <div className="text-sm font-semibold">{p.name}</div>
              <div className="text-[11px] text-muted-foreground mb-3">{p.tagline}</div>
              <div className="flex items-baseline gap-1 mb-3">
                <span className="text-2xl font-semibold tabular-nums">
                  ${p.price[billing]}
                </span>
                <span className="text-[11px] text-muted-foreground">/user/mo</span>
              </div>
              <ul className="grid gap-1.5">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-1.5 text-[11px]">
                    <Check className="h-3 w-3 text-emerald-500 mt-0.5 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </button>
          );
        })}
      </div>

      <div className="text-[11px] text-muted-foreground text-center">
        All plans include a 14-day Pro trial. No credit card required to start.
      </div>
    </div>
  );
}
