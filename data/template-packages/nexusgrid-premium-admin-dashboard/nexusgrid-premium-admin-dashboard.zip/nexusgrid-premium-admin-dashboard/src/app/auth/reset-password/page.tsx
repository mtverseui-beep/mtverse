"use client";

import * as React from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  ShieldCheck,
} from "lucide-react";
import {
  AuthShell,
  PasswordChecklist,
  PasswordStrengthBar,
} from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function ResetPasswordPage() {
  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [showPwd, setShowPwd] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const [errors, setErrors] = React.useState<{ password?: string; confirm?: string }>({});

  function validate() {
    const next: typeof errors = {};
    if (!password) next.password = "Password is required";
    else if (password.length < 8) next.password = "Use at least 8 characters";
    else if (!/[A-Z]/.test(password) || !/[0-9]/.test(password) || !/[^a-zA-Z0-9]/.test(password))
      next.password = "Meet all the requirements below";
    if (confirm !== password) next.confirm = "Passwords do not match";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    setDone(true);
    toast.success("Password reset", {
      description: "You can now sign in with your new password.",
    });
  }

  return (
    <AuthShell
      brand={{
        headline: "Set a password you can actually trust",
        subheadline:
          "Choose a strong, unique password. We never store plaintext credentials and never share your data.",
        showcaseImage:
          "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=1600&auto=format&fit=crop",
        customers: ["Brightline", "Vela", "Apex Labs", "Cohere", "Helix"],
      }}
    >
      <div className="space-y-6">
        {!done ? (
          <>
            <div className="space-y-1.5">
              <div className="grid place-items-center h-12 w-12 rounded-xl bg-primary/10 text-primary mb-2">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h1 className="text-2xl font-semibold tracking-tight">Reset your password</h1>
              <p className="text-sm text-muted-foreground">
                Choose a new password for your NexusGrid account. Make it strong and unique.
              </p>
            </div>

            <form onSubmit={onSubmit} className="space-y-4" noValidate>
              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-xs flex items-center gap-1.5">
                  <Lock className="h-3.5 w-3.5 text-muted-foreground" /> New password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPwd ? "text" : "password"}
                    placeholder="Enter your new password"
                    autoComplete="new-password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (errors.password) setErrors((p) => ({ ...p, password: undefined }));
                    }}
                    aria-invalid={!!errors.password}
                    className="pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd((s) => !s)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                    aria-label={showPwd ? "Hide password" : "Show password"}
                  >
                    {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <PasswordStrengthBar password={password} />
                <PasswordChecklist password={password} />
                {errors.password && <p className="text-[11px] text-destructive">{errors.password}</p>}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="confirm" className="text-xs flex items-center gap-1.5">
                  <ShieldCheck className="h-3.5 w-3.5 text-muted-foreground" /> Confirm new password
                </Label>
                <div className="relative">
                  <Input
                    id="confirm"
                    type={showConfirm ? "text" : "password"}
                    placeholder="Re-enter your new password"
                    autoComplete="new-password"
                    value={confirm}
                    onChange={(e) => {
                      setConfirm(e.target.value);
                      if (errors.confirm) setErrors((p) => ({ ...p, confirm: undefined }));
                    }}
                    aria-invalid={!!errors.confirm}
                    className="pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm((s) => !s)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                    aria-label={showConfirm ? "Hide password" : "Show password"}
                  >
                    {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.confirm && <p className="text-[11px] text-destructive">{errors.confirm}</p>}
              </div>

              <Button type="submit" className="w-full gap-1.5" disabled={loading}>
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ArrowRight className="h-4 w-4" />
                )}
                {loading ? "Resetting password…" : "Reset password"}
              </Button>
            </form>

            <Link
              href="/auth/signin"
              className="inline-flex items-center justify-center gap-1.5 w-full text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to sign in
            </Link>
          </>
        ) : (
          <div className="space-y-6 text-center">
            <div className="relative mx-auto grid place-items-center h-20 w-20">
              <span className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
              <div className="relative grid place-items-center h-16 w-16 rounded-full bg-emerald-500 text-white shadow-premium-md">
                <CheckCircle2 className="h-8 w-8" />
              </div>
            </div>

            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">Password reset</h1>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                Your password has been updated successfully. You can now sign in with your new credentials.
              </p>
            </div>

            <div className="rounded-md border bg-muted/40 p-4 text-left">
              <div className="flex items-start gap-3">
                <ShieldCheck className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs font-medium">Security tip</p>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">
                    For extra protection, enable two-factor authentication from your account security settings after signing in.
                  </p>
                </div>
              </div>
            </div>

            <Button asChild className="w-full gap-1.5">
              <Link href="/auth/signin">
                Continue to sign in
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}
      </div>
    </AuthShell>
  );
}
