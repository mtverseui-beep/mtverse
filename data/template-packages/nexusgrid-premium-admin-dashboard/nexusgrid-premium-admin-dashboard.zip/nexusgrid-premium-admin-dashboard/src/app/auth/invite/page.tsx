"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
  User,
  XCircle,
} from "lucide-react";
import {
  AuthShell,
  PasswordChecklist,
  PasswordStrengthBar,
} from "@/components/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const INVITE = {
  inviterName: "Marcus Reyes",
  inviterEmail: "marcus@brightline.co",
  inviterRole: "Workspace Owner",
  inviterAvatar:
    "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=192&auto=format&fit=crop",
  workspaceName: "Brightline Operations",
  workspaceLogo: "B",
  roleOffered: "Admin",
  rolePermissions: [
    "Full access to all dashboards",
    "Manage team members and roles",
    "Billing and subscription controls",
    "Workspace-wide settings",
  ],
  invitedEmail: "you@brightline.co",
  expiresAt: "in 5 days",
};

export default function InviteTeamPage() {
  const router = useRouter();
  const [name, setName] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [showPwd, setShowPwd] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [declined, setDeclined] = React.useState(false);
  const [accepted, setAccepted] = React.useState(false);
  const [errors, setErrors] = React.useState<{ name?: string; password?: string }>({});

  function validate() {
    const next: typeof errors = {};
    if (!name.trim()) next.name = "Full name is required";
    else if (name.trim().length < 2) next.name = "Name must be at least 2 characters";
    if (!password) next.password = "Password is required";
    else if (password.length < 8) next.password = "Use at least 8 characters";
    else if (!/[A-Z]/.test(password) || !/[0-9]/.test(password) || !/[^a-zA-Z0-9]/.test(password))
      next.password = "Meet all the requirements below";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onAccept(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    setAccepted(true);
    toast.success("Invitation accepted", {
      description: `You're now an ${INVITE.roleOffered} at ${INVITE.workspaceName}.`,
    });
  }

  function onDecline() {
    setDeclined(true);
    toast.message("Invitation declined", {
      description: `${INVITE.inviterName} will be notified.`,
    });
  }

  return (
    <AuthShell
      brand={{
        headline: "Your team is one click away",
        subheadline:
          "You've been invited to join an active NexusGrid workspace. Accept to set up your account and access shared dashboards, projects, and billing.",
        showcaseImage:
          "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=1600&auto=format&fit=crop",
        customers: ["Brightline", "Vela", "Apex Labs", "Cohere"],
      }}
    >
      <div className="space-y-6">
        {accepted ? (
          <div className="space-y-6 text-center">
            <div className="relative mx-auto grid place-items-center h-24 w-24">
              <span className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
              <div className="relative grid place-items-center h-16 w-16 rounded-full bg-emerald-500 text-white shadow-premium-md animate-scale-in">
                <CheckCircle2 className="h-9 w-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">You&apos;re in!</h1>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                Welcome to <span className="font-medium text-foreground">{INVITE.workspaceName}</span>. Your{" "}
                {INVITE.roleOffered} role is active. Let&apos;s get you to the dashboard.
              </p>
            </div>
            <Button asChild className="w-full gap-1.5">
              <Link href="/dashboards/ecommerce">
                Open workspace
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        ) : declined ? (
          <div className="space-y-6 text-center">
            <div className="relative mx-auto grid place-items-center h-20 w-20">
              <div className="grid place-items-center h-16 w-16 rounded-full bg-muted text-muted-foreground shadow-premium-sm">
                <XCircle className="h-9 w-9" />
              </div>
            </div>
            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">Invitation declined</h1>
              <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                You chose not to join {INVITE.workspaceName}. {INVITE.inviterName} will be notified. You can
                still request a new invite later.
              </p>
            </div>
            <Button asChild variant="outline" className="w-full">
              <Link href="/auth/signin">Back to sign in</Link>
            </Button>
          </div>
        ) : (
          <>
            <div className="space-y-1.5">
              <Badge variant="secondary" className="mb-2">You&apos;ve been invited</Badge>
              <h1 className="text-2xl font-semibold tracking-tight">Join {INVITE.workspaceName}</h1>
              <p className="text-sm text-muted-foreground">
                {INVITE.inviterName} invited you to collaborate as an {INVITE.roleOffered}.
              </p>
            </div>

            {/* Invitation card */}
            <div className="rounded-2xl border bg-card p-5 shadow-premium-sm space-y-4">
              {/* Inviter row */}
              <div className="flex items-center gap-3">
                <img
                  src={INVITE.inviterAvatar}
                  alt={INVITE.inviterName}
                  className="h-10 w-10 rounded-full object-cover ring-2 ring-border"
                />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold truncate">{INVITE.inviterName}</div>
                  <div className="text-[11px] text-muted-foreground truncate">
                    {INVITE.inviterRole} · {INVITE.inviterEmail}
                  </div>
                </div>
              </div>

              {/* Workspace + role */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg border bg-background p-3">
                  <div className="flex items-center gap-2">
                    <div className="grid place-items-center h-8 w-8 rounded-lg brand-gradient text-white text-xs font-bold">
                      {INVITE.workspaceLogo}
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Workspace</div>
                      <div className="text-xs font-medium truncate">{INVITE.workspaceName}</div>
                    </div>
                  </div>
                </div>
                <div className="rounded-lg border bg-background p-3">
                  <div className="flex items-center gap-2">
                    <div className="grid place-items-center h-8 w-8 rounded-lg bg-primary/10 text-primary">
                      <ShieldCheck className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Role</div>
                      <div className="text-xs font-medium truncate">{INVITE.roleOffered}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Permissions preview */}
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
                  With this role you can
                </div>
                <ul className="grid gap-1.5">
                  {INVITE.rolePermissions.map((p) => (
                    <li key={p} className="flex items-center gap-2 text-[11px]">
                      <span className="grid place-items-center h-3.5 w-3.5 rounded-full bg-emerald-500 text-white shrink-0">
                        <svg viewBox="0 0 12 12" className="h-2.5 w-2.5" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                          <path d="M2 6.5L5 9.5L10 3" />
                        </svg>
                      </span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center justify-between text-[11px] text-muted-foreground border-t pt-3">
                <span className="flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5" /> {INVITE.invitedEmail}
                </span>
                <span className="flex items-center gap-1.5">
                  <Building2 className="h-3.5 w-3.5" /> Expires {INVITE.expiresAt}
                </span>
              </div>
            </div>

            {/* Accept form */}
            <form onSubmit={onAccept} className="space-y-4" noValidate>
              <div className="space-y-1.5">
                <Label htmlFor="name" className="text-xs flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5 text-muted-foreground" /> Full name
                </Label>
                <Input
                  id="name"
                  placeholder="Your full name"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors((p) => ({ ...p, name: undefined }));
                  }}
                  aria-invalid={!!errors.name}
                />
                {errors.name && <p className="text-[11px] text-destructive">{errors.name}</p>}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-xs flex items-center gap-1.5">
                  <Lock className="h-3.5 w-3.5 text-muted-foreground" /> Create a password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPwd ? "text" : "password"}
                    placeholder="Choose a strong password"
                    autoComplete="new-password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (errors.password) setErrors((p) => ({ ...p, password: undefined }));
                    }}
                    aria-invalid={!!errors.password}
                    className="pr-9"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd((s) => !s)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center h-6 w-6 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
                    aria-label={showPwd ? "Hide password" : "Show password"}
                  >
                    {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <PasswordStrengthBar password={password} />
                <PasswordChecklist password={password} />
                {errors.password && <p className="text-[11px] text-destructive">{errors.password}</p>}
              </div>

              <Button type="submit" className="w-full gap-1.5" disabled={loading}>
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" />
                )}
                {loading ? "Accepting invitation…" : "Accept invitation"}
              </Button>
            </form>

            <button
              type="button"
              onClick={onDecline}
              className="w-full text-center text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Decline invitation
            </button>
          </>
        )}
      </div>
    </AuthShell>
  );
}
