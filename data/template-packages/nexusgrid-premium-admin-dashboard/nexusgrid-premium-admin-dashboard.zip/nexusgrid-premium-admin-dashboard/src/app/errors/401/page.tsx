"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowRight, ArrowLeft, Lock, KeyRound, ShieldCheck, Fingerprint } from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function UnauthorizedPage() {
  const [unlocking, setUnlocking] = React.useState(false);

  React.useEffect(() => {
    // Subtle hover shiver on the lock
    const id = window.setInterval(() => setUnlocking((u) => !u), 4200);
    return () => window.clearInterval(id);
  }, []);

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Radial dot pattern background */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.35] dark:opacity-[0.25]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 1px 1px, oklch(0.55 0.13 175 / 0.25) 1px, transparent 0)",
          backgroundSize: "28px 28px",
        }}
      />
      {/* Radial emerald glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 left-1/2 h-[480px] w-[480px] -translate-x-1/2 rounded-full opacity-40 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, oklch(0.55 0.13 175 / 0.35) 0%, transparent 70%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto grid min-h-screen max-w-6xl grid-cols-1 items-center gap-10 px-5 py-20 sm:px-8 lg:grid-cols-2 lg:gap-16">
        {/* Left: Vault door illustration */}
        <div className="order-2 flex justify-center lg:order-1">
          <div className="relative">
            <svg
              width="380"
              height="380"
              viewBox="0 0 380 380"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="h-[280px] w-[280px] sm:h-[340px] sm:w-[340px] lg:h-[380px] lg:w-[380px]"
              aria-hidden
            >
              <defs>
                <radialGradient id="vaultGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="oklch(0.55 0.13 175 / 0.4)" />
                  <stop offset="100%" stopColor="oklch(0.55 0.13 175 / 0)" />
                </radialGradient>
                <linearGradient id="vaultBody" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="oklch(0.68 0.14 175)" />
                  <stop offset="100%" stopColor="oklch(0.50 0.13 195)" />
                </linearGradient>
                <linearGradient id="vaultRing" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="oklch(0.95 0 0)" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="oklch(0.6 0 0)" stopOpacity="0.3" />
                </linearGradient>
                <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="0" dy="6" stdDeviation="10" floodColor="oklch(0.16 0.01 240 / 0.18)" />
                </filter>
              </defs>

              {/* Ambient glow */}
              <circle cx="190" cy="190" r="180" fill="url(#vaultGlow)" />

              {/* Vault outer ring */}
              <circle
                cx="190"
                cy="190"
                r="160"
                fill="none"
                stroke="url(#vaultRing)"
                strokeWidth="2"
                strokeDasharray="2 6"
                opacity="0.6"
              />
              <circle
                cx="190"
                cy="190"
                r="150"
                fill="none"
                stroke="oklch(0.55 0.13 175 / 0.35)"
                strokeWidth="1"
              />

              {/* Vault door body */}
              <g filter="url(#softShadow)">
                <circle cx="190" cy="190" r="135" fill="url(#vaultBody)" />
                <circle
                  cx="190"
                  cy="190"
                  r="135"
                  fill="none"
                  stroke="oklch(0.99 0 0 / 0.5)"
                  strokeWidth="1.5"
                />
                <circle
                  cx="190"
                  cy="190"
                  r="125"
                  fill="none"
                  stroke="oklch(0.13 0.01 240 / 0.3)"
                  strokeWidth="1"
                />

                {/* Spoke pattern */}
                {Array.from({ length: 12 }).map((_, i) => {
                  const angle = (i * 30 * Math.PI) / 180;
                  const x1 = 190 + Math.cos(angle) * 65;
                  const y1 = 190 + Math.sin(angle) * 65;
                  const x2 = 190 + Math.cos(angle) * 125;
                  const y2 = 190 + Math.sin(angle) * 125;
                  return (
                    <line
                      key={i}
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke="oklch(0.13 0.01 240 / 0.18)"
                      strokeWidth="1.5"
                    />
                  );
                })}

                {/* Bolt heads */}
                {Array.from({ length: 8 }).map((_, i) => {
                  const angle = (i * 45 * Math.PI) / 180;
                  const x = 190 + Math.cos(angle) * 118;
                  const y = 190 + Math.sin(angle) * 118;
                  return (
                    <g key={i}>
                      <circle cx={x} cy={y} r="6" fill="oklch(0.13 0.01 240 / 0.35)" />
                      <circle cx={x} cy={y} r="4" fill="oklch(0.99 0 0 / 0.4)" />
                    </g>
                  );
                })}

                {/* Inner hub */}
                <circle cx="190" cy="190" r="68" fill="oklch(0.13 0.01 240 / 0.3)" />
                <circle cx="190" cy="190" r="68" fill="none" stroke="oklch(0.99 0 0 / 0.25)" strokeWidth="1" />
              </g>

              {/* Lock shackle */}
              <g className={unlocking ? "origin-center" : ""} style={{ transformOrigin: "190px 190px" }}>
                <rect
                  x="178"
                  y="160"
                  width="24"
                  height="46"
                  rx="12"
                  fill="oklch(0.13 0.01 240 / 0.55)"
                />
                <path
                  d="M180 168 a10 10 0 0 1 20 0 v12"
                  fill="none"
                  stroke="oklch(0.99 0 0 / 0.85)"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              </g>

              {/* Keyhole */}
              <circle cx="190" cy="186" r="8" fill="oklch(0.99 0 0 / 0.95)" />
              <rect x="187" y="190" width="6" height="14" rx="1" fill="oklch(0.99 0 0 / 0.95)" />

              {/* Floating key sparkles */}
              <g opacity="0.85">
                <KeyRound
                  x={70}
                  y={70}
                  width={26}
                  height={26}
                  className="text-primary"
                />
                <KeyRound
                  x={290}
                  y={90}
                  width={18}
                  height={18}
                  className="text-primary/60"
                />
                <KeyRound
                  x={50}
                  y={280}
                  width={20}
                  height={20}
                  className="text-primary/50"
                />
              </g>
            </svg>

            {/* Status pill */}
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full border border-destructive/30 bg-destructive/10 px-4 py-1.5 backdrop-blur-sm">
              <span className="flex items-center gap-2 text-xs font-medium text-destructive">
                <Lock className="h-3 w-3" />
                Access locked
              </span>
            </div>
          </div>
        </div>

        {/* Right: Copy + actions */}
        <div className="order-1 space-y-7 lg:order-2">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <Fingerprint className="h-3.5 w-3.5" />
            HTTP 401 — Unauthorized
          </div>

          <div className="space-y-3">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
              Authentication
              <br />
              <span className="bg-gradient-to-r from-primary to-chart-4 bg-clip-text text-transparent">
                Required
              </span>
            </h1>
            <p className="max-w-md text-base text-muted-foreground">
              You need to sign in to access this area of NexusGrid. Your session may have
              expired, or this resource requires verified credentials.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Button asChild size="lg" className="group h-11 px-6">
              <Link href="/auth/signin">
                <ShieldCheck className="h-4 w-4" />
                Sign In
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-11">
              <Link href="/dashboards/analytics">
                <ArrowLeft className="h-4 w-4" />
                Back to Dashboard
              </Link>
            </Button>
          </div>

          {/* Hint cards */}
          <div className="grid gap-3 pt-4 sm:grid-cols-2">
            <div className="rounded-xl border border-border bg-card/50 p-4 backdrop-blur-sm">
              <div className="mb-1 flex items-center gap-2 text-xs font-medium text-muted-foreground">
                <KeyRound className="h-3.5 w-3.5 text-primary" />
                Session expired?
              </div>
              <p className="text-sm text-foreground/80">
                Sign in again to refresh your access token and continue where you left off.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card/50 p-4 backdrop-blur-sm">
              <div className="mb-1 flex items-center gap-2 text-xs font-medium text-muted-foreground">
                <Fingerprint className="h-3.5 w-3.5 text-primary" />
                Need an account?
              </div>
              <p className="text-sm text-foreground/80">
                Contact your workspace admin or{" "}
                <button
                  onClick={() => toast.info("Invite sent", { description: "Your admin will reach out shortly." })}
                  className="font-medium text-primary underline-offset-4 hover:underline"
                >
                  request an invite
                </button>
                .
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
