"use client";

import * as React from "react";
import Link from "next/link";
import {
  Gauge,
  ArrowLeft,
  Headphones,
  Activity,
  Zap,
  TrendingUp,
  RotateCcw,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

// Keep countdown defaults deterministic so prerendered HTML matches hydration.
const RESET_OFFSET_MS = 58 * 1000;
const RESET_WINDOW_SECONDS = 60;
const INITIAL_REMAINING_SECONDS = Math.ceil(RESET_OFFSET_MS / 1000);
const RESET_TIME_FORMAT: Intl.DateTimeFormatOptions = {
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
};

export default function RateLimitPage() {
  const [remainingSec, setRemainingSec] = React.useState(
    INITIAL_REMAINING_SECONDS
  );
  const [resetTimeLabel, setResetTimeLabel] = React.useState("--:--:--");

  React.useEffect(() => {
    const resetAtMs = Date.now() + RESET_OFFSET_MS;
    let timerId = 0;

    setResetTimeLabel(
      new Date(resetAtMs).toLocaleTimeString("en-US", RESET_TIME_FORMAT)
    );

    const syncCountdown = () => {
      const secondsLeft = Math.max(
        0,
        Math.ceil((resetAtMs - Date.now()) / 1000)
      );

      setRemainingSec(secondsLeft);

      if (secondsLeft <= 0 && timerId) {
        window.clearInterval(timerId);
      }
    };

    syncCountdown();
    timerId = window.setInterval(syncCountdown, 1000);

    return () => window.clearInterval(timerId);
  }, []);

  const LIMIT = 100;
  const USED = 100;
  const REMAINING = 0;
  const pct = (USED / LIMIT) * 100;
  const resetProgress = Math.min(
    100,
    Math.max(
      0,
      ((RESET_WINDOW_SECONDS - remainingSec) / RESET_WINDOW_SECONDS) * 100
    )
  );

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Grid background */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.4] dark:opacity-[0.3]"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.75 0.16 75 / 0.08) 1px, transparent 1px), linear-gradient(90deg, oklch(0.75 0.16 75 / 0.08) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />
      {/* Amber top glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-80"
        style={{
          background:
            "radial-gradient(ellipse at top, oklch(0.75 0.16 75 / 0.22) 0%, transparent 70%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Pill */}
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-warning/40 bg-warning/15 px-3 py-1 text-xs font-semibold text-warning">
          <Zap className="h-3.5 w-3.5" />
          HTTP 429 - Throttled
        </div>

        <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
          Too Many Requests
        </h1>
        <p className="mt-3 max-w-lg text-center text-base text-muted-foreground">
          You&apos;ve hit the rate limit for this endpoint. Let the meter cool down
          before sending more requests.
        </p>

        {/* Dashboard card */}
        <div className="mt-8 grid w-full max-w-3xl gap-5 rounded-2xl border border-border bg-card/70 p-6 shadow-premium-md backdrop-blur-sm lg:grid-cols-[260px_1fr]">
          {/* Speedometer */}
          <div className="flex flex-col items-center justify-center border-b border-border pb-5 lg:border-b-0 lg:border-r lg:pb-0 lg:pr-5">
            <Speedometer pct={pct} />
            <div className="mt-2 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-destructive">
              <Activity className="h-3.5 w-3.5" />
              Limit Exceeded
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3">
            <StatTile
              label="Request Limit"
              value={LIMIT.toString()}
              suffix="/min"
              icon={TrendingUp}
              tone="default"
            />
            <StatTile
              label="Used"
              value={USED.toString()}
              suffix="/min"
              icon={Gauge}
              tone="destructive"
            />
            <StatTile
              label="Remaining"
              value={REMAINING.toString()}
              icon={RotateCcw}
              tone="warning"
            />
            <StatTile
              label="Resets In"
              value={`${remainingSec}s`}
              icon={Zap}
              tone="default"
              mono
            />

            {/* Reset progress */}
            <div className="col-span-2 mt-1 rounded-xl border border-border bg-secondary/30 p-4">
              <div className="mb-2 flex items-center justify-between text-xs">
                <span className="font-medium text-muted-foreground">
                  Rate window reset
                </span>
                <span className="font-mono tabular-nums text-foreground">
                  {String(Math.floor(remainingSec / 60)).padStart(2, "0")}:
                  {String(remainingSec % 60).padStart(2, "0")}
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-warning to-destructive transition-all duration-1000 ease-linear"
                  style={{
                    width: `${resetProgress}%`,
                  }}
                />
              </div>
              <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground">
                <span>Window: {RESET_WINDOW_SECONDS}s</span>
                <span>Resets at {resetTimeLabel}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center">
          <Button
            onClick={() =>
              toast.info("Try again later", {
                description: `Retry available in ${remainingSec} seconds.`,
              })
            }
            size="lg"
            className="h-11"
            disabled={remainingSec > 0}
          >
            <RotateCcw className="h-4 w-4" />
            {remainingSec > 0 ? `Retry in ${remainingSec}s` : "Try Again"}
          </Button>
          <Button asChild variant="outline" size="lg" className="h-11">
            <Link href="/dashboards/analytics">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>

        {/* Support */}
        <div className="mt-6 text-sm text-muted-foreground">
          Hitting limits unexpectedly?{" "}
          <button
            onClick={() =>
              toast.info("Support notified", {
                description: "Our team will reach out about your rate limits.",
              })
            }
            className="inline-flex items-center gap-1 font-medium text-foreground underline-offset-4 hover:underline"
          >
            <Headphones className="h-3.5 w-3.5" />
            Contact Support
          </button>{" "}
          to upgrade your plan.
        </div>
      </div>
    </main>
  );
}

function Speedometer({ pct }: { pct: number }) {
  // Half-circle gauge: 180deg sweep
  const angle = (pct / 100) * 180; // 0..180
  const needleAngle = -90 + angle; // -90 (left) .. +90 (right)
  const r = 80;
  const cx = 100;
  const cy = 100;

  // Tick marks
  const ticks = Array.from({ length: 11 }).map((_, i) => {
    const t = (i / 10) * 180;
    const a = ((-90 + t) * Math.PI) / 180;
    const x1 = cx + Math.cos(a) * (r - 8);
    const y1 = cy + Math.sin(a) * (r - 8);
    const x2 = cx + Math.cos(a) * r;
    const y2 = cy + Math.sin(a) * r;
    return { x1, y1, x2, y2, i, isMajor: i % 2 === 0 };
  });

  return (
    <svg
      width="200"
      height="120"
      viewBox="0 0 200 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="h-[110px] w-[180px]"
      aria-hidden
    >
      <defs>
        <linearGradient id="gaugeArc" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="oklch(0.62 0.15 150)" />
          <stop offset="60%" stopColor="oklch(0.78 0.15 75)" />
          <stop offset="100%" stopColor="oklch(0.62 0.20 25)" />
        </linearGradient>
      </defs>

      {/* Arc background */}
      <path
        d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
        fill="none"
        stroke="oklch(0.7 0.01 240 / 0.2)"
        strokeWidth="10"
        strokeLinecap="round"
      />
      {/* Arc fill */}
      <path
        d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
        fill="none"
        stroke="url(#gaugeArc)"
        strokeWidth="10"
        strokeLinecap="round"
        strokeDasharray={`${(pct / 100) * Math.PI * r} ${Math.PI * r}`}
      />

      {/* Ticks */}
      {ticks.map((t) => (
        <line
          key={t.i}
          x1={t.x1}
          y1={t.y1}
          x2={t.x2}
          y2={t.y2}
          stroke="oklch(0.7 0.01 240 / 0.6)"
          strokeWidth={t.isMajor ? 2 : 1}
        />
      ))}

      {/* Needle */}
      <g
        style={{
          transform: `rotate(${needleAngle}deg)`,
          transformOrigin: `${cx}px ${cy}px`,
          transition: "transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)",
        }}
      >
        <line
          x1={cx}
          y1={cy}
          x2={cx}
          y2={cy - r + 16}
          stroke="oklch(0.62 0.20 25)"
          strokeWidth="3"
          strokeLinecap="round"
        />
      </g>
      <circle cx={cx} cy={cy} r="8" fill="oklch(0.30 0.01 240)" />
      <circle cx={cx} cy={cy} r="4" fill="oklch(0.62 0.20 25)" />
    </svg>
  );
}

function StatTile({
  label,
  value,
  suffix,
  icon: Icon,
  tone,
  mono,
}: {
  label: string;
  value: string;
  suffix?: string;
  icon: React.ComponentType<{ className?: string }>;
  tone: "default" | "warning" | "destructive";
  mono?: boolean;
}) {
  const toneClass =
    tone === "destructive"
      ? "border-destructive/30 bg-destructive/5 text-destructive"
      : tone === "warning"
      ? "border-warning/30 bg-warning/5 text-warning"
      : "border-border bg-secondary/30 text-foreground";

  return (
    <div className={`rounded-xl border p-4 ${toneClass}`}>
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <Icon className="h-3.5 w-3.5 opacity-70" />
      </div>
      <div
        className={`text-xl font-bold ${
          mono ? "font-mono tabular-nums" : ""
        }`}
      >
        {value}
        {suffix && (
          <span className="ml-1 text-xs font-normal text-muted-foreground">
            {suffix}
          </span>
        )}
      </div>
    </div>
  );
}