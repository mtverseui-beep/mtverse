"use client";

import * as React from "react";
import Link from "next/link";
import {
  Hammer,
  Wrench,
  Cog,
  CheckCircle2,
  Circle,
  Mail,
  Twitter,
  Github,
  Linkedin,
  Rocket,
  Loader2,
  ArrowLeft,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const PROGRESS = 60;
const TASKS = [
  { label: "Database migration", done: true },
  { label: "API gateway upgrade", done: true },
  { label: "Cache layer rollout", done: true },
  { label: "Search index rebuild", done: false },
  { label: "Final smoke tests", done: false },
];

// Static completion time displayed as a fixed countdown — module-level state must match
// between server and client. The live "now" comes from useEffect (client-only).
const COMPLETION_TIME_OFFSET_MIN = 18;

export default function MaintenancePage() {
  const [email, setEmail] = React.useState("");
  const [subscribed, setSubscribed] = React.useState(false);
  const [now, setNow] = React.useState<Date | null>(null);
  const [completionTime, setCompletionTime] = React.useState<Date | null>(null);

  React.useEffect(() => {
    const initialNow = new Date();
    setNow(initialNow);
    setCompletionTime(new Date(initialNow.getTime() + COMPLETION_TIME_OFFSET_MIN * 60 * 1000));
    const id = window.setInterval(() => setNow(new Date()), 30000);
    return () => window.clearInterval(id);
  }, []);

  function subscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter a valid email", {
        description: "We'll notify you when maintenance is complete.",
      });
      return;
    }
    setSubscribed(true);
    toast.success("You're on the list", {
      description: `We'll email ${email} when NexusGrid is back.`,
    });
  }

  const completionStr = (now && completionTime)
    ? completionTime.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
      })
    : "--:--";

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Hazard stripe pattern - industrial */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-24 opacity-30 dark:opacity-40"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg, oklch(0.75 0.16 75) 0px, oklch(0.75 0.16 75) 16px, oklch(0.16 0.01 240) 16px, oklch(0.16 0.01 240) 32px)",
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 h-24 opacity-30 dark:opacity-40"
        style={{
          backgroundImage:
            "repeating-linear-gradient(-45deg, oklch(0.75 0.16 75) 0px, oklch(0.75 0.16 75) 16px, oklch(0.16 0.01 240) 16px, oklch(0.16 0.01 240) 32px)",
        }}
      />
      {/* Center radial */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-25 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, oklch(0.75 0.16 75 / 0.4) 0%, transparent 70%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-4xl flex-col items-center justify-center px-5 py-24 sm:px-8">
        {/* Pill */}
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-warning/40 bg-warning/15 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-warning">
          <Cog className="h-3.5 w-3.5 animate-spin" style={{ animationDuration: "4s" }} />
          Scheduled Maintenance
        </div>

        <div className="grid w-full gap-10 lg:grid-cols-[1fr_1.2fr] lg:items-center">
          {/* Left: Progress ring + wrench */}
          <div className="order-2 flex justify-center lg:order-1">
            <div className="relative">
              <ProgressRing pct={PROGRESS} />
              {/* Spinning gear */}
              <div className="absolute -right-4 -top-4">
                <Cog
                  className="h-10 w-10 text-primary"
                  style={{ animation: "spinSlow 8s linear infinite" }}
                />
                <style>{`
                  @keyframes spinSlow {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                  }
                `}</style>
              </div>
              {/* Wrench badge */}
              <div className="absolute -bottom-3 -left-3 flex h-12 w-12 items-center justify-center rounded-full border border-warning/40 bg-warning/15 text-warning shadow-premium-sm backdrop-blur-sm">
                <Wrench className="h-5 w-5" />
              </div>
            </div>
          </div>

          {/* Right: Copy + tasks */}
          <div className="order-1 space-y-5 lg:order-2">
            <div className="space-y-3">
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
                Under Maintenance
              </h1>
              <p className="text-base text-muted-foreground">
                We&apos;re upgrading NexusGrid to serve you better. New search,
                faster reports, and a refreshed activity feed are on the way.
              </p>
            </div>

            {/* Task list */}
            <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur-sm">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Rollout progress
                </span>
                <span className="text-xs text-muted-foreground">
                  Expected completion ~{" "}
                  <span className="font-mono font-medium text-foreground">
                    {completionStr}
                  </span>
                </span>
              </div>
              <ul className="space-y-2">
                {TASKS.map((t) => (
                  <li
                    key={t.label}
                    className="flex items-center gap-2 text-sm"
                  >
                    {t.done ? (
                      <CheckCircle2 className="h-4 w-4 text-success" />
                    ) : (
                      <Circle className="h-4 w-4 text-muted-foreground/50" />
                    )}
                    <span
                      className={
                        t.done
                          ? "text-foreground"
                          : "text-muted-foreground"
                      }
                    >
                      {t.label}
                    </span>
                    {!t.done && (
                      <Loader2 className="ml-auto h-3.5 w-3.5 animate-spin text-primary" />
                    )}
                  </li>
                ))}
              </ul>
            </div>

            {/* Subscribe */}
            <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur-sm">
              <div className="mb-2 flex items-center gap-2 text-sm font-medium">
                <Mail className="h-4 w-4 text-primary" />
                Get notified when we&apos;re back
              </div>
              {subscribed ? (
                <div className="flex items-center gap-2 rounded-lg border border-success/30 bg-success/10 px-3 py-2 text-sm font-medium text-success">
                  <CheckCircle2 className="h-4 w-4" />
                  You&apos;re subscribed.
                </div>
              ) : (
                <form
                  onSubmit={subscribe}
                  className="flex flex-col gap-2 sm:flex-row"
                >
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                    className="h-10 flex-1 bg-background"
                  />
                  <Button type="submit" className="h-10">
                    <Rocket className="h-4 w-4" />
                    Notify Me
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Social + back link */}
        <div className="mt-10 flex w-full max-w-2xl flex-col items-center gap-5 border-t border-border pt-6 sm:flex-row sm:justify-between">
          <Button asChild variant="ghost" size="sm">
            <Link href="/dashboards/analytics">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Follow updates:</span>
            {[
              { icon: Twitter, label: "Twitter" },
              { icon: Github, label: "GitHub" },
              { icon: Linkedin, label: "LinkedIn" },
            ].map((s) => (
              <button
                key={s.label}
                onClick={() => toast.info(`Opening ${s.label}…`)}
                aria-label={s.label}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card/60 text-muted-foreground transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:text-primary"
              >
                <s.icon className="h-4 w-4" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Hidden lucide for tree-shaking alignment */}
      <Hammer className="sr-only" />
    </main>
  );
}

function ProgressRing({ pct }: { pct: number }) {
  const r = 90;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;

  return (
    <div className="relative grid place-items-center">
      <svg
        width="220"
        height="220"
        viewBox="0 0 220 220"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-[200px] w-[200px] sm:h-[220px] sm:w-[220px]"
        aria-hidden
      >
        <defs>
          <linearGradient id="maintRing" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="oklch(0.78 0.15 75)" />
            <stop offset="100%" stopColor="oklch(0.55 0.13 175)" />
          </linearGradient>
        </defs>
        {/* Track */}
        <circle
          cx="110"
          cy="110"
          r={r}
          fill="none"
          stroke="oklch(0.7 0.01 240 / 0.15)"
          strokeWidth="14"
        />
        {/* Progress */}
        <circle
          cx="110"
          cy="110"
          r={r}
          fill="none"
          stroke="url(#maintRing)"
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          transform="rotate(-90 110 110)"
          style={{ transition: "stroke-dashoffset 0.8s ease" }}
        />
        {/* Tick markers */}
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * 2 * Math.PI - Math.PI / 2;
          return (
            <circle
              key={i}
              cx={110 + Math.cos(a) * (r - 22)}
              cy={110 + Math.sin(a) * (r - 22)}
              r="1.5"
              fill="oklch(0.7 0.01 240 / 0.4)"
            />
          );
        })}
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="bg-gradient-to-br from-warning to-primary bg-clip-text text-4xl font-black tabular-nums text-transparent sm:text-5xl">
          {pct}%
        </div>
        <div className="mt-1 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          Complete
        </div>
      </div>
    </div>
  );
}
