"use client";

import * as React from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ShieldX,
  ShieldAlert,
  Mail,
  UserCog,
  Crown,
  ArrowRight,
  Check,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function ForbiddenPage() {
  const [requesting, setRequesting] = React.useState(false);

  async function requestAccess() {
    setRequesting(true);
    await new Promise((r) => setTimeout(r, 900));
    setRequesting(false);
    toast.success("Access request submitted", {
      description: "Your workspace admin will review your request for Admin role.",
    });
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Diagonal stripe pattern */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.06] dark:opacity-[0.08]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg, oklch(0.58 0.22 27) 0px, oklch(0.58 0.22 27) 1.5px, transparent 1.5px, transparent 22px)",
        }}
      />
      {/* Top red wash */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-72"
        style={{
          background:
            "linear-gradient(to bottom, oklch(0.58 0.22 27 / 0.18) 0%, transparent 100%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Shield illustration */}
        <div className="relative mb-8 animate-fade-in-up">
          <svg
            width="200"
            height="220"
            viewBox="0 0 200 220"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-[180px] w-[180px] sm:h-[200px] sm:w-[200px]"
            aria-hidden
          >
            <defs>
              <linearGradient id="shieldGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.68 0.20 25)" />
                <stop offset="100%" stopColor="oklch(0.52 0.22 27)" />
              </linearGradient>
              <linearGradient id="shieldInner" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.20 0.05 27)" />
                <stop offset="100%" stopColor="oklch(0.14 0.02 27)" />
              </linearGradient>
              <filter id="shieldShadow" x="-30%" y="-30%" width="160%" height="160%">
                <feDropShadow dx="0" dy="8" stdDeviation="14" floodColor="oklch(0.58 0.22 27 / 0.4)" />
              </filter>
            </defs>

            <g filter="url(#shieldShadow)">
              {/* Shield body */}
              <path
                d="M100 18 L170 42 V110 C170 158 140 192 100 206 C60 192 30 158 30 110 V42 Z"
                fill="url(#shieldGrad)"
              />
              <path
                d="M100 18 L170 42 V110 C170 158 140 192 100 206 C60 192 30 158 30 110 V42 Z"
                fill="none"
                stroke="oklch(0.99 0 0 / 0.5)"
                strokeWidth="2"
              />
              {/* Shield inner */}
              <path
                d="M100 32 L158 52 V108 C158 148 134 178 100 190 C66 178 42 148 42 108 V52 Z"
                fill="url(#shieldInner)"
              />

              {/* No-entry circle */}
              <circle cx="100" cy="108" r="38" fill="oklch(0.99 0 0 / 0.05)" />
              <circle
                cx="100"
                cy="108"
                r="38"
                fill="none"
                stroke="oklch(0.99 0 0 / 0.9)"
                strokeWidth="5"
              />
              {/* Diagonal slash */}
              <line
                x1="73"
                y1="81"
                x2="127"
                y2="135"
                stroke="oklch(0.99 0 0 / 0.95)"
                strokeWidth="5"
                strokeLinecap="round"
              />
            </g>

            {/* Highlight glow on top */}
            <path
              d="M100 18 L170 42 V72 C170 72 130 56 100 56 C70 56 30 72 30 72 V42 Z"
              fill="oklch(0.99 0 0 / 0.12)"
            />
          </svg>

          {/* Floating caution badge */}
          <div className="absolute -right-3 -top-2 rotate-6 rounded-md border border-destructive/40 bg-destructive/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-destructive backdrop-blur-sm">
            Denied
          </div>
        </div>

        {/* Code pill */}
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-destructive/30 bg-destructive/10 px-3 py-1 text-xs font-medium text-destructive">
          <ShieldX className="h-3.5 w-3.5" />
          HTTP 403 — Forbidden
        </div>

        <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
          Access Forbidden
        </h1>
        <p className="mt-4 max-w-lg text-center text-base text-muted-foreground">
          You don&apos;t have permission to access this resource. Your current role
          doesn&apos;t match the required permission level for this area.
        </p>

        {/* Role comparison card */}
        <div className="mt-8 w-full max-w-md rounded-2xl border border-border bg-card/70 p-5 shadow-premium backdrop-blur-sm">
          <div className="mb-4 flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <UserCog className="h-3.5 w-3.5" />
            Permission Comparison
          </div>
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
            <div className="rounded-xl border border-border bg-secondary/40 p-3 text-center">
              <div className="mb-1.5 inline-flex h-8 w-8 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <UserCog className="h-4 w-4" />
              </div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Your role
              </div>
              <div className="mt-0.5 text-sm font-semibold">Viewer</div>
            </div>

            <div className="flex flex-col items-center">
              <div className="rounded-full border border-border bg-background px-2 py-1 text-[10px] font-medium text-muted-foreground">
                vs
              </div>
              <ArrowRight className="mt-1 h-4 w-4 text-muted-foreground" />
            </div>

            <div className="relative rounded-xl border border-primary/30 bg-primary/10 p-3 text-center">
              <div className="mb-1.5 inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-primary">
                <Crown className="h-4 w-4" />
              </div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Required
              </div>
              <div className="mt-0.5 text-sm font-semibold text-primary">Admin</div>
              <Check className="absolute -right-1.5 -top-1.5 h-4 w-4 rounded-full bg-primary text-primary-foreground" />
            </div>
          </div>

          <div className="mt-4 rounded-lg bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
            <ShieldAlert className="mr-1 inline h-3 w-3" />
            Resource path:{" "}
            <code className="rounded bg-background/80 px-1 py-0.5 font-mono text-foreground">
              /admin/audit-logs
            </code>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-8 flex w-full max-w-md flex-col gap-3 sm:flex-row">
          <Button
            onClick={requestAccess}
            disabled={requesting}
            className="h-11 flex-1"
          >
            {requesting ? (
              <>
                <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-primary-foreground/40 border-t-primary-foreground" />
                Submitting…
              </>
            ) : (
              <>
                <ShieldAlert className="h-4 w-4" />
                Request Access
              </>
            )}
          </Button>
          <Button asChild variant="outline" className="h-11 flex-1">
            <Link href="/dashboards/analytics">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>

        {/* Contact admin */}
        <div className="mt-6 text-center text-sm text-muted-foreground">
          Need urgent access?{" "}
          <button
            onClick={() =>
              toast.info("Admin contacted", {
                description: "An email has been sent to your workspace admin.",
              })
            }
            className="inline-flex items-center gap-1 font-medium text-foreground underline-offset-4 hover:underline"
          >
            <Mail className="h-3.5 w-3.5" />
            Contact your admin
          </button>
        </div>
      </div>
    </main>
  );
}
