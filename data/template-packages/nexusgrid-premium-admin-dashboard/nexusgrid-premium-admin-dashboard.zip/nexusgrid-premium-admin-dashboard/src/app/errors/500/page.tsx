"use client";

import * as React from "react";
import Link from "next/link";
import {
  RefreshCw,
  Bug,
  AlertOctagon,
  Server,
  Activity,
  Copy,
  Check,
  ExternalLink,
  Terminal,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

// Static error ID — module-level constants must match between server and client.
// A real app would generate this on the server and pass it via props, but for a demo
// dashboard we use a fixed value to avoid hydration mismatch from Math.random()/Date.now().
const ERROR_ID = "NGX-7K9M2Q-X4B8";

const STACK_TRACE = `Error: Cannot read property 'aggregate' of undefined
    at computeRevenueRollup (src/lib/analytics.ts:142:18)
    at AnalyticsResolver.dashboard (src/server/resolvers/analytics.ts:88:22)
    at processTicksAndRejections (node:internal/process/task_queues:95:5)
    at async handleRequest (src/server/router.ts:204:7)`;

export default function ServerErrorPage() {
  const [copied, setCopied] = React.useState(false);
  const [retrying, setRetrying] = React.useState(false);

  async function copyErrorId() {
    try {
      await navigator.clipboard.writeText(ERROR_ID);
      setCopied(true);
      toast.success("Error ID copied", { description: ERROR_ID });
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error("Could not copy", { description: "Copy the ID manually." });
    }
  }

  async function retry() {
    setRetrying(true);
    await new Promise((r) => setTimeout(r, 1100));
    setRetrying(false);
    toast.info("Retrying request…", {
      description: "If the error persists, please report it.",
    });
  }

  function report() {
    toast.success("Issue report queued", {
      description: `Reference ${ERROR_ID} in your ticket.`,
    });
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Circuit board pattern */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.08] dark:opacity-[0.12]"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.58 0.22 27 / 0.5) 1px, transparent 1px), linear-gradient(90deg, oklch(0.58 0.22 27 / 0.5) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />
      {/* Red radial */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/3 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-30 blur-3xl"
        style={{
          background:
            "radial-gradient(circle, oklch(0.58 0.22 27 / 0.5) 0%, transparent 70%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Broken server illustration */}
        <div className="relative mb-7">
          <svg
            width="240"
            height="180"
            viewBox="0 0 240 180"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-[140px] w-[200px] sm:h-[160px] sm:w-[220px]"
            aria-hidden
          >
            <defs>
              <linearGradient id="serverBody" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.30 0.02 240)" />
                <stop offset="100%" stopColor="oklch(0.20 0.01 240)" />
              </linearGradient>
              <linearGradient id="smokeGrad" x1="0" y1="1" x2="0" y2="0">
                <stop offset="0%" stopColor="oklch(0.58 0.22 27 / 0.6)" />
                <stop offset="100%" stopColor="oklch(0.58 0.22 27 / 0)" />
              </linearGradient>
              <filter id="serverShadow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="6" stdDeviation="10" floodColor="oklch(0 0 0 / 0.3)" />
              </filter>
            </defs>

            {/* Smoke plumes */}
            <g opacity="0.7">
              <ellipse cx="80" cy="40" rx="14" ry="22" fill="url(#smokeGrad)">
                <animate
                  attributeName="cy"
                  values="50;20;50"
                  dur="3s"
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="opacity"
                  values="0.7;0.1;0.7"
                  dur="3s"
                  repeatCount="indefinite"
                />
              </ellipse>
              <ellipse cx="160" cy="35" rx="12" ry="20" fill="url(#smokeGrad)">
                <animate
                  attributeName="cy"
                  values="45;15;45"
                  dur="3.5s"
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="opacity"
                  values="0.7;0.1;0.7"
                  dur="3.5s"
                  repeatCount="indefinite"
                />
              </ellipse>
              <ellipse cx="120" cy="20" rx="10" ry="16" fill="url(#smokeGrad)">
                <animate
                  attributeName="cy"
                  values="35;5;35"
                  dur="4s"
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="opacity"
                  values="0.6;0;0.6"
                  dur="4s"
                  repeatCount="indefinite"
                />
              </ellipse>
            </g>

            {/* Tilted broken server rack */}
            <g filter="url(#serverShadow)" style={{ transformOrigin: "120px 110px" }}>
              <g transform="rotate(-6 120 110)">
                {/* Rack body */}
                <rect x="40" y="60" width="160" height="100" rx="8" fill="url(#serverBody)" stroke="oklch(0.5 0.01 240 / 0.5)" strokeWidth="1.5" />

                {/* Server slots */}
                {[0, 1, 2, 3].map((i) => (
                  <g key={i}>
                    <rect x="50" y={70 + i * 22} width="140" height="18" rx="3" fill="oklch(0.16 0.01 240)" />
                    {/* Status LEDs */}
                    <circle cx="58" cy={79 + i * 22} r="2" fill={i === 1 ? "oklch(0.58 0.22 27)" : "oklch(0.30 0.02 240)"} />
                    <circle cx="66" cy={79 + i * 22} r="2" fill="oklch(0.30 0.02 240)" />
                    {/* Vents */}
                    <rect x="78" y={76 + i * 22} width="60" height="2" fill="oklch(0.5 0.01 240 / 0.4)" />
                    <rect x="78" y={81 + i * 22} width="60" height="2" fill="oklch(0.5 0.01 240 / 0.4)" />
                    {/* Activity LED */}
                    <circle cx="178" cy={79 + i * 22} r="2.5" fill={i === 1 ? "oklch(0.58 0.22 27)" : "oklch(0.62 0.15 150)"} className={i === 1 ? "" : ""}>
                      {i !== 1 && (
                        <animate
                          attributeName="opacity"
                          values="1;0.3;1"
                          dur="1.5s"
                          repeatCount="indefinite"
                          begin={`${i * 0.3}s`}
                        />
                      )}
                    </circle>
                  </g>
                ))}

                {/* Crack */}
                <path
                  d="M 120 60 L 110 75 L 125 90 L 115 105 L 130 120 L 122 135 L 138 155"
                  stroke="oklch(0.58 0.22 27)"
                  strokeWidth="2"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray="3 4"
                />

                {/* Spark */}
                <g transform="translate(125 92)">
                  <path d="M0 -6 L2 -2 L6 0 L2 2 L0 6 L-2 2 L-6 0 L-2 -2 Z" fill="oklch(0.78 0.15 75)">
                    <animate
                      attributeName="opacity"
                      values="0;1;0"
                      dur="0.5s"
                      repeatCount="indefinite"
                    />
                  </path>
                </g>
              </g>
            </g>

            {/* Ground shadow */}
            <ellipse cx="120" cy="172" rx="80" ry="6" fill="oklch(0 0 0 / 0.25)" />
          </svg>

          {/* Error badge */}
          <div className="absolute -right-4 -top-2 -rotate-6 rounded-md border border-destructive/50 bg-destructive px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-destructive-foreground shadow-premium-sm">
            Crash
          </div>
        </div>

        {/* Pill */}
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-destructive/30 bg-destructive/10 px-3 py-1 text-xs font-medium text-destructive">
          <AlertOctagon className="h-3.5 w-3.5" />
          HTTP 500 — Internal Server Error
        </div>

        <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
          Something broke on our end
        </h1>
        <p className="mt-3 max-w-lg text-center text-base text-muted-foreground">
          Our team has been notified. Try again in a moment, or reference the error
          ID below when contacting support.
        </p>

        {/* Terminal-style error card */}
        <div className="mt-7 w-full overflow-hidden rounded-xl border border-border bg-card/80 shadow-premium backdrop-blur-sm">
          {/* Terminal header */}
          <div className="flex items-center justify-between border-b border-border bg-muted/40 px-4 py-2.5">
            <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <Terminal className="h-3.5 w-3.5 text-destructive" />
              nexus-error.log
            </div>
            <div className="flex items-center gap-1.5">
              <div className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
              <div className="h-2.5 w-2.5 rounded-full bg-warning/70" />
              <div className="h-2.5 w-2.5 rounded-full bg-success/70" />
            </div>
          </div>

          {/* Error ID row */}
          <div className="flex items-center justify-between gap-3 border-b border-border bg-secondary/20 px-4 py-3">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-mono text-muted-foreground">error_id:</span>
              <code className="font-mono text-sm font-semibold text-foreground">{ERROR_ID}</code>
            </div>
            <button
              onClick={copyErrorId}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1 text-xs font-medium text-foreground transition-colors hover:bg-accent"
            >
              {copied ? (
                <>
                  <Check className="h-3 w-3 text-success" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="h-3 w-3" />
                  Copy
                </>
              )}
            </button>
          </div>

          {/* Stack trace */}
          <pre className="overflow-x-auto px-4 py-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
            <span className="text-destructive">{STACK_TRACE.split("\n")[0]}</span>
            {"\n"}
            {STACK_TRACE.split("\n").slice(1).map((line, i) => (
              <React.Fragment key={i}>
                {line}
                {"\n"}
              </React.Fragment>
            ))}
          </pre>
        </div>

        {/* Actions */}
        <div className="mt-7 flex flex-col gap-3 sm:flex-row">
          <Button onClick={retry} disabled={retrying} size="lg" className="h-11">
            {retrying ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                Retrying…
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4" />
                Try Again
              </>
            )}
          </Button>
          <Button onClick={report} variant="outline" size="lg" className="h-11">
            <Bug className="h-4 w-4" />
            Report Issue
          </Button>
        </div>

        {/* Footer links */}
        <div className="mt-7 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <Server className="h-3.5 w-3.5 text-primary" />
            Server region: us-east-1
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Activity className="h-3.5 w-3.5 text-primary" />
            Uptime: 99.94%
          </span>
          <button
            onClick={() => toast.info("Opening status page…")}
            className="inline-flex items-center gap-1 font-medium text-foreground underline-offset-4 hover:underline"
          >
            View status page
            <ExternalLink className="h-3 w-3" />
          </button>
        </div>
      </div>
    </main>
  );
}
