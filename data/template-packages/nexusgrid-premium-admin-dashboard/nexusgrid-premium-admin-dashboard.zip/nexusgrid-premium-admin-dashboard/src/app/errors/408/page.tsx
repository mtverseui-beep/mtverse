"use client";

import * as React from "react";
import Link from "next/link";
import {
  ArrowLeft,
  RefreshCw,
  Clock,
  Hourglass,
  Timer,
  ServerCog,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const RETRY_SECONDS = 15;

export default function TimeoutPage() {
  const [countdown, setCountdown] = React.useState(RETRY_SECONDS);
  const [retried, setRetried] = React.useState(0);
  const [autoRetry, setAutoRetry] = React.useState(true);

  React.useEffect(() => {
    if (!autoRetry) return;
    if (countdown <= 0) {
      // Auto retry
      setAutoRetry(false);
      toast.success("Retrying your request…", {
        description: "Hang tight — reconnecting now.",
      });
      return;
    }
    const id = window.setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => window.clearTimeout(id);
  }, [countdown, autoRetry]);

  function manualRetry() {
    setRetried((r) => r + 1);
    setCountdown(RETRY_SECONDS);
    setAutoRetry(true);
    toast.info(`Retry attempt #${retried + 1}`, {
      description: "Re-sending your request to the server.",
    });
  }

  const progress = ((RETRY_SECONDS - countdown) / RETRY_SECONDS) * 100;

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Vertical gradient */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, oklch(0.75 0.16 75 / 0.10) 0%, transparent 40%, transparent 60%, oklch(0.55 0.13 175 / 0.08) 100%)",
        }}
      />
      {/* Concentric rings */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/3 -translate-x-1/2 -translate-y-1/2 opacity-30"
        style={{
          backgroundImage:
            "repeating-radial-gradient(circle at center, oklch(0.75 0.16 75 / 0.18) 0px, oklch(0.75 0.16 75 / 0.18) 1px, transparent 1px, transparent 60px)",
          width: "800px",
          height: "800px",
          maxWidth: "100vw",
          maxHeight: "100vh",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Hourglass illustration */}
        <div className="relative mb-8">
          <svg
            width="180"
            height="220"
            viewBox="0 0 180 220"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-[180px] w-[180px]"
            aria-hidden
          >
            <defs>
              <linearGradient id="hgGlass" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.85 0.05 75 / 0.5)" />
                <stop offset="100%" stopColor="oklch(0.65 0.10 75 / 0.3)" />
              </linearGradient>
              <linearGradient id="hgSand" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.78 0.15 75)" />
                <stop offset="100%" stopColor="oklch(0.65 0.16 60)" />
              </linearGradient>
              <linearGradient id="hgFrame" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.45 0.02 240)" />
                <stop offset="100%" stopColor="oklch(0.30 0.01 240)" />
              </linearGradient>
              <filter id="hgShadow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="6" stdDeviation="10" floodColor="oklch(0.16 0.01 240 / 0.18)" />
              </filter>
            </defs>

            <g filter="url(#hgShadow)">
              {/* Top & bottom plates */}
              <rect x="20" y="14" width="140" height="14" rx="3" fill="url(#hgFrame)" />
              <rect x="20" y="192" width="140" height="14" rx="3" fill="url(#hgFrame)" />
              {/* Pillars */}
              <rect x="22" y="28" width="6" height="164" fill="url(#hgFrame)" />
              <rect x="152" y="28" width="6" height="164" fill="url(#hgFrame)" />

              {/* Glass body */}
              <path
                d="M40 32 H140 L100 110 L140 188 H40 L80 110 Z"
                fill="url(#hgGlass)"
                stroke="oklch(0.40 0.02 240 / 0.5)"
                strokeWidth="1.5"
              />

              {/* Top sand pile (shrinking) */}
              <clipPath id="topClip">
                <path d="M40 32 H140 L100 110 L80 110 Z" />
              </clipPath>
              <g clipPath="url(#topClip)">
                <rect
                  x="40"
                  y={32 + (1 - progress / 100) * 0}
                  width="100"
                  height={78 * (1 - progress / 100)}
                  fill="url(#hgSand)"
                />
              </g>

              {/* Bottom sand pile (growing) */}
              <clipPath id="bottomClip">
                <path d="M80 110 L100 110 L140 188 H40 Z" />
              </clipPath>
              <g clipPath="url(#bottomClip)">
                <path
                  d={`M40 188 L140 188 L${100 - 30 * (progress / 100) + 30 * (1 - progress / 100)} ${188 - 78 * (progress / 100)} L${100 + 30 * (progress / 100) - 30 * (1 - progress / 100)} ${188 - 78 * (progress / 100)} Z`}
                  fill="url(#hgSand)"
                  opacity={progress / 100 > 0 ? 1 : 0}
                />
              </g>

              {/* Falling sand stream */}
              <line
                x1="90"
                y1="110"
                x2="90"
                y2="188"
                stroke="oklch(0.78 0.15 75)"
                strokeWidth="1.5"
                strokeLinecap="round"
                opacity={progress > 5 && progress < 95 ? 0.9 : 0}
              />

              {/* Center neck */}
              <rect x="86" y="106" width="8" height="8" fill="oklch(0.40 0.02 240)" opacity="0.3" />
            </g>
          </svg>

          {/* Ticking clock badge */}
          <div className="absolute -right-3 top-6 flex h-12 w-12 items-center justify-center rounded-full border border-warning/40 bg-warning/15 text-warning backdrop-blur-sm">
            <Clock className="h-5 w-5" />
          </div>
        </div>

        {/* Pill */}
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-warning/30 bg-warning/10 px-3 py-1 text-xs font-medium text-warning">
          <Timer className="h-3.5 w-3.5" />
          HTTP 408 — Request Timeout
        </div>

        <h1 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">
          The request timed out
        </h1>
        <p className="mt-3 text-center text-base text-muted-foreground">
          The server didn&apos;t respond in time. This usually clears up on its own —
          give it another try in a moment.
        </p>

        {/* Retry countdown card */}
        <div className="mt-7 w-full rounded-2xl border border-border bg-card/70 p-5 shadow-premium backdrop-blur-sm">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <RefreshCw className="h-3.5 w-3.5" />
              Auto-retry
            </div>
            <div className="font-mono text-2xl font-bold tabular-nums text-foreground">
              {String(Math.floor(countdown / 60)).padStart(2, "0")}:
              {String(countdown % 60).padStart(2, "0")}
            </div>
          </div>

          {/* Progress bar */}
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-gradient-to-r from-warning to-primary transition-all duration-1000 ease-linear"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {autoRetry ? "Retrying automatically…" : "Auto-retry paused"}
            </span>
            <span>
              Attempt #{retried + (autoRetry ? 1 : 0)}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex w-full flex-col gap-3 sm:flex-row">
          <Button onClick={manualRetry} size="lg" className="h-11 flex-1">
            <RefreshCw className="h-4 w-4" />
            Try Again Now
          </Button>
          <Button asChild variant="outline" size="lg" className="h-11 flex-1">
            <Link href="/dashboards/analytics">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>

        {/* Footer hint */}
        <div className="mt-6 flex items-center gap-1.5 text-xs text-muted-foreground">
          <ServerCog className="h-3.5 w-3.5 text-primary" />
          Repeated timeouts? Check our{" "}
          <button
            onClick={() => toast.info("Opening status page…")}
            className="font-medium text-foreground underline-offset-4 hover:underline"
          >
            status page
          </button>
          .
        </div>
      </div>

      {/* Hourglass icon ghost */}
      <Hourglass className="sr-only" />
    </main>
  );
}
