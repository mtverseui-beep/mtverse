"use client";

import * as React from "react";
import Link from "next/link";
import {
  Wrench,
  Hammer,
  ArrowLeft,
  Mail,
  Bell,
  ExternalLink,
  Clock,
  CheckCircle2,
  Cog,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const ETA_MINUTES = 23;

export default function ServiceUnavailablePage() {
  const [email, setEmail] = React.useState("");
  const [subscribed, setSubscribed] = React.useState(false);
  const [eta, setEta] = React.useState(ETA_MINUTES * 60);

  React.useEffect(() => {
    const id = window.setInterval(() => {
      setEta((e) => (e > 0 ? e - 1 : 0));
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  function subscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter a valid email", {
        description: "We'll notify you the moment service is restored.",
      });
      return;
    }
    setSubscribed(true);
    toast.success("Subscribed to updates", {
      description: `We'll email ${email} when NexusGrid is back online.`,
    });
  }

  const mm = String(Math.floor(eta / 60)).padStart(2, "0");
  const ss = String(eta % 60).padStart(2, "0");

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Blueprint grid */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.5] dark:opacity-[0.4]"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.55 0.13 175 / 0.10) 1px, transparent 1px), linear-gradient(90deg, oklch(0.55 0.13 175 / 0.10) 1px, transparent 1px)",
          backgroundSize: "24px 24px",
        }}
      />
      {/* Major grid lines */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "linear-gradient(oklch(0.55 0.13 175 / 0.15) 2px, transparent 2px), linear-gradient(90deg, oklch(0.55 0.13 175 / 0.15) 2px, transparent 2px)",
          backgroundSize: "120px 120px",
        }}
      />
      {/* Amber corner wash */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 h-72"
        style={{
          background:
            "linear-gradient(to top, oklch(0.75 0.16 75 / 0.15) 0%, transparent 100%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Maintenance illustration */}
        <div className="relative mb-7">
          <svg
            width="260"
            height="200"
            viewBox="0 0 260 200"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-[170px] w-[220px] sm:h-[190px] sm:w-[250px]"
            aria-hidden
          >
            <defs>
              <linearGradient id="wrenchGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="oklch(0.78 0.15 75)" />
                <stop offset="100%" stopColor="oklch(0.65 0.16 60)" />
              </linearGradient>
              <linearGradient id="cogGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="oklch(0.55 0.13 175)" />
                <stop offset="100%" stopColor="oklch(0.45 0.13 195)" />
              </linearGradient>
              <filter id="maintShadow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="6" stdDeviation="8" floodColor="oklch(0.16 0.01 240 / 0.18)" />
              </filter>
            </defs>

            {/* Spinning cog behind */}
            <g
              filter="url(#maintShadow)"
              style={{
                transformOrigin: "70px 110px",
                animation: "spinSlow 12s linear infinite",
              }}
            >
              <CogShape cx={70} cy={110} r={42} teeth={10} fill="url(#cogGrad)" />
              <circle cx={70} cy={110} r={18} fill="oklch(0.16 0.01 240)" />
              <circle cx={70} cy={110} r={18} fill="none" stroke="oklch(0.99 0 0 / 0.2)" strokeWidth="1" />
              <circle cx={70} cy={110} r={6} fill="url(#cogGrad)" />
            </g>

            {/* Wrench */}
            <g
              filter="url(#maintShadow)"
              transform="rotate(45 170 100)"
            >
              {/* Handle */}
              <rect x={150} y={95} width={80} height={14} rx={4} fill="url(#wrenchGrad)" />
              <rect x={150} y={95} width={80} height={14} rx={4} fill="none" stroke="oklch(0.40 0.05 60 / 0.5)" strokeWidth="1" />
              {/* Head */}
              <path
                d="M 220 88 L 240 88 L 240 80 L 252 92 L 252 112 L 240 124 L 240 116 L 220 116 Z"
                fill="url(#wrenchGrad)"
                stroke="oklch(0.40 0.05 60 / 0.5)"
                strokeWidth="1"
              />
              {/* Highlight */}
              <rect x={155} y={97} width={70} height={3} rx={1.5} fill="oklch(0.99 0 0 / 0.4)" />
            </g>

            {/* Hammer top-right */}
            <g
              filter="url(#maintShadow)"
              transform="rotate(-25 220 50)"
            >
              <rect x={195} y={48} width={50} height={14} rx={2} fill="oklch(0.45 0.02 240)" />
              <rect x={150} y={46} width={48} height={18} rx={2} fill="url(#wrenchGrad)" />
              <rect x={150} y={48} width={48} height={3} fill="oklch(0.99 0 0 / 0.4)" />
            </g>

            {/* Floor stripe */}
            <line x1="20" y1="180" x2="240" y2="180" stroke="oklch(0.55 0.13 175 / 0.4)" strokeWidth="2" strokeDasharray="6 4" />

            {/* Sparks */}
            <g fill="oklch(0.78 0.15 75)">
              <circle cx={130} cy={140} r={2}>
                <animate attributeName="opacity" values="0;1;0" dur="1.5s" repeatCount="indefinite" />
              </circle>
              <circle cx={140} cy={150} r={1.5}>
                <animate attributeName="opacity" values="0;1;0" dur="1.5s" begin="0.4s" repeatCount="indefinite" />
              </circle>
              <circle cx={120} cy={155} r={1}>
                <animate attributeName="opacity" values="0;1;0" dur="1.5s" begin="0.8s" repeatCount="indefinite" />
              </circle>
            </g>
          </svg>

          <style>{`
            @keyframes spinSlow {
              from { transform: rotate(0deg); }
              to { transform: rotate(360deg); }
            }
          `}</style>

          {/* Status badge */}
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 rounded-full border border-warning/40 bg-warning/15 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-warning backdrop-blur-sm">
            Under Maintenance
          </div>
        </div>

        {/* Pill */}
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-warning/30 bg-warning/10 px-3 py-1 text-xs font-medium text-warning">
          <Hammer className="h-3.5 w-3.5" />
          HTTP 503 — Service Unavailable
        </div>

        <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
          We&apos;ll be right back
        </h1>
        <p className="mt-3 max-w-lg text-center text-base text-muted-foreground">
          NexusGrid is temporarily offline for scheduled maintenance. We&apos;re
          deploying infrastructure upgrades to make things faster and more reliable.
        </p>

        {/* ETR card */}
        <div className="mt-7 grid w-full max-w-lg grid-cols-2 gap-3">
          <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur-sm">
            <div className="mb-1 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              <Clock className="h-3 w-3 text-warning" />
              Est. Recovery
            </div>
            <div className="font-mono text-2xl font-bold tabular-nums text-foreground">
              {mm}:{ss}
            </div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              ~{Math.ceil(eta / 60)} min remaining
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card/70 p-4 backdrop-blur-sm">
            <div className="mb-1 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              <Cog className="h-3 w-3 text-primary" />
              Maintenance Type
            </div>
            <div className="text-sm font-semibold text-foreground">
              Infra Upgrade
            </div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              v4.12.0 → v4.13.0
            </div>
          </div>
        </div>

        {/* Subscribe */}
        <div className="mt-6 w-full max-w-lg rounded-2xl border border-border bg-card/70 p-5 shadow-premium-sm backdrop-blur-sm">
          <div className="mb-3 flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Bell className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold">Get notified</div>
              <div className="text-xs text-muted-foreground">
                We&apos;ll email you when service is restored.
              </div>
            </div>
          </div>
          {subscribed ? (
            <div className="flex items-center gap-2 rounded-lg border border-success/30 bg-success/10 px-4 py-3 text-sm font-medium text-success">
              <CheckCircle2 className="h-4 w-4" />
              You&apos;re subscribed — we&apos;ll email you the moment we&apos;re back.
            </div>
          ) : (
            <form onSubmit={subscribe} className="flex flex-col gap-2 sm:flex-row">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="h-11 flex-1 bg-background"
              />
              <Button type="submit" size="lg" className="h-11">
                <Mail className="h-4 w-4" />
                Notify Me
              </Button>
            </form>
          )}
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Button asChild variant="outline" size="lg" className="h-11">
            <Link href="/dashboards/analytics">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
          <Button
            onClick={() => toast.info("Opening status page…")}
            variant="ghost"
            size="lg"
            className="h-11"
          >
            <ExternalLink className="h-4 w-4" />
            View Status Page
          </Button>
        </div>

        {/* Status line */}
        <div className="mt-7 flex items-center gap-2 text-xs text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-warning opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-warning" />
          </span>
          Last incident update: 2 minutes ago
        </div>
      </div>

      {/* Hidden lucide for tree-shaking alignment */}
      <Wrench className="sr-only" />
    </main>
  );
}

function CogShape({
  cx,
  cy,
  r,
  teeth,
  fill,
}: {
  cx: number;
  cy: number;
  r: number;
  teeth: number;
  fill: string;
}) {
  const path: string[] = [];
  const innerR = r * 0.85;
  const toothHalf = (Math.PI * 2) / (teeth * 2);
  for (let i = 0; i < teeth; i++) {
    const a0 = (i / teeth) * Math.PI * 2;
    const a1 = a0 + toothHalf * 0.7;
    const a2 = a0 + toothHalf;
    const a3 = a0 + toothHalf * 1.3;
    const a4 = a0 + (Math.PI * 2) / teeth;
    path.push(
      `M ${cx + Math.cos(a0) * innerR} ${cy + Math.sin(a0) * innerR} ` +
        `L ${cx + Math.cos(a1) * r} ${cy + Math.sin(a1) * r} ` +
        `L ${cx + Math.cos(a3) * r} ${cy + Math.sin(a3) * r} ` +
        `L ${cx + Math.cos(a4) * innerR} ${cy + Math.sin(a4) * innerR}`
    );
  }
  return <path d={path.join(" ") + " Z"} fill={fill} />;
}
