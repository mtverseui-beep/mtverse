"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Wifi,
  WifiOff,
  RefreshCw,
  CloudOff,
  HardDrive,
  CheckCircle2,
  ArrowRight,
  Database,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function OfflinePage() {
  const router = useRouter();
  const [online, setOnline] = React.useState<boolean>(true);
  const [reconnecting, setReconnecting] = React.useState(false);
  const [redirectIn, setRedirectIn] = React.useState(3);

  // Initialize from navigator (after mount to avoid SSR mismatch)
  React.useEffect(() => {
    setOnline(navigator.onLine);

    function onOnline() {
      setOnline(true);
      toast.success("Back online!", {
        description: "Redirecting you to your dashboard…",
      });
    }
    function onOffline() {
      setOnline(false);
      setRedirectIn(3);
    }
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  // Redirect countdown when back online
  React.useEffect(() => {
    if (!online) return;
    if (redirectIn <= 0) {
      router.push("/dashboards/analytics");
      return;
    }
    const id = window.setTimeout(() => setRedirectIn((s) => s - 1), 1000);
    return () => window.clearTimeout(id);
  }, [online, redirectIn, router]);

  function tryAgain() {
    setReconnecting(true);
    setTimeout(() => {
      setReconnecting(false);
      if (navigator.onLine) {
        setOnline(true);
        toast.success("Connection restored", {
          description: "You're back online.",
        });
      } else {
        toast.error("Still offline", {
          description: "Check your network connection and try again.",
        });
      }
    }, 1100);
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Radial signal rings */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
      >
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-muted-foreground/20"
            style={{
              width: `${(i + 1) * 220}px`,
              height: `${(i + 1) * 220}px`,
              opacity: online ? 0.35 : 0.15,
              animation: `pulseRing 3s ease-out ${i * 0.5}s infinite`,
            }}
          />
        ))}
        <style>{`
          @keyframes pulseRing {
            0% { transform: translate(-50%, -50%) scale(0.7); opacity: 0.5; }
            100% { transform: translate(-50%, -50%) scale(1.1); opacity: 0; }
          }
        `}</style>
      </div>

      {/* Muted backdrop */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background: online
            ? "radial-gradient(circle at 50% 50%, oklch(0.62 0.15 150 / 0.10) 0%, transparent 60%)"
            : "radial-gradient(circle at 50% 50%, oklch(0.5 0.01 240 / 0.08) 0%, transparent 60%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-2xl flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Wifi icon with status */}
        <div className="relative mb-7">
          <svg
            width="220"
            height="180"
            viewBox="0 0 220 180"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-[160px] w-[200px] sm:h-[180px] sm:w-[220px]"
            aria-hidden
          >
            <defs>
              <linearGradient id="wifiOn" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.62 0.15 150)" />
                <stop offset="100%" stopColor="oklch(0.50 0.13 175)" />
              </linearGradient>
              <linearGradient id="wifiOff" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="oklch(0.60 0.01 240)" />
                <stop offset="100%" stopColor="oklch(0.45 0.01 240)" />
              </linearGradient>
            </defs>

            {/* Outer arcs */}
            <g
              stroke={online ? "url(#wifiOn)" : "url(#wifiOff)"}
              strokeWidth="6"
              fill="none"
              strokeLinecap="round"
              opacity={online ? 0.95 : 0.55}
            >
              <path d="M 30 100 A 110 110 0 0 1 190 100" />
              <path d="M 60 110 A 80 80 0 0 1 160 110" opacity="0.85" />
              <path d="M 90 120 A 50 50 0 0 1 130 120" opacity="0.7" />
            </g>

            {/* Center dot */}
            <circle
              cx="110"
              cy="140"
              r="9"
              fill={online ? "url(#wifiOn)" : "url(#wifiOff)"}
            />

            {/* When offline: red slash */}
            {!online && (
              <line
                x1="40"
                y1="40"
                x2="180"
                y2="160"
                stroke="oklch(0.58 0.22 27)"
                strokeWidth="6"
                strokeLinecap="round"
              />
            )}

            {/* When online: green check */}
            {online && (
              <g>
                <circle
                  cx="180"
                  cy="40"
                  r="18"
                  fill="oklch(0.62 0.15 150)"
                  stroke="oklch(0.99 0 0)"
                  strokeWidth="2"
                />
                <path
                  d="M 173 40 L 178 45 L 187 35"
                  stroke="oklch(0.99 0 0)"
                  strokeWidth="3"
                  fill="none"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            )}
          </svg>

          {/* Status pill */}
          <div
            className={`absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full border px-3 py-1 text-[10px] font-bold uppercase tracking-wider backdrop-blur-sm ${
              online
                ? "border-success/40 bg-success/15 text-success"
                : "border-muted-foreground/30 bg-muted/30 text-muted-foreground"
            }`}
          >
            {online ? "Connected" : "No Signal"}
          </div>
        </div>

        {/* Pill */}
        <div
          className={`mb-4 inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium ${
            online
              ? "border-success/30 bg-success/10 text-success"
              : "border-border bg-muted/30 text-muted-foreground"
          }`}
        >
          {online ? (
            <>
              <Wifi className="h-3.5 w-3.5" />
              Connection restored
            </>
          ) : (
            <>
              <WifiOff className="h-3.5 w-3.5" />
              You&apos;re offline
            </>
          )}
        </div>

        <h1 className="text-center text-4xl font-bold tracking-tight sm:text-5xl">
          {online ? "Back online!" : "You\u2019re offline"}
        </h1>
        <p className="mt-3 max-w-md text-center text-base text-muted-foreground">
          {online ? (
            <>
              Your connection is back. Redirecting you to your dashboard in{" "}
              <span className="font-semibold text-foreground">{redirectIn}s</span>…
            </>
          ) : (
            <>
              Check your internet connection. We&apos;ll automatically detect when
              you&apos;re back online.
            </>
          )}
        </p>

        {/* Actions */}
        {!online && (
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Button
              onClick={tryAgain}
              disabled={reconnecting}
              size="lg"
              className="h-11"
            >
              {reconnecting ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Checking…
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" />
                  Try Again
                </>
              )}
            </Button>
            <Button asChild variant="outline" size="lg" className="h-11">
              <Link href="/dashboards/analytics">
                Go to Dashboard
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}

        {online && (
          <Button asChild size="lg" className="mt-7 h-11">
            <Link href="/dashboards/analytics">
              <ArrowRight className="h-4 w-4" />
              Go now
            </Link>
          </Button>
        )}

        {/* Cached content indicator */}
        {!online && (
          <div className="mt-8 w-full max-w-md rounded-2xl border border-border bg-card/70 p-5 shadow-premium-sm backdrop-blur-sm">
            <div className="mb-3 flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Database className="h-4 w-4" />
              </div>
              <div className="text-sm font-semibold">Cached content available</div>
            </div>
            <p className="mb-3 text-xs text-muted-foreground">
              You can still view these items from your last visit while offline:
            </p>
            <ul className="space-y-2">
              {[
                { icon: HardDrive, label: "Analytics snapshot", meta: "Last sync 3m ago" },
                { icon: HardDrive, label: "CRM contacts list", meta: "Last sync 8m ago" },
                { icon: HardDrive, label: "Recent invoices", meta: "Last sync 12m ago" },
              ].map((item) => (
                <li
                  key={item.label}
                  className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 px-3 py-2 text-xs"
                >
                  <span className="flex items-center gap-2 text-foreground">
                    <item.icon className="h-3.5 w-3.5 text-muted-foreground" />
                    {item.label}
                  </span>
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <CheckCircle2 className="h-3 w-3 text-success" />
                    {item.meta}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Footer */}
        {!online && (
          <div className="mt-7 flex items-center gap-1.5 text-xs text-muted-foreground">
            <CloudOff className="h-3.5 w-3.5" />
            Listening for connection changes…
          </div>
        )}
      </div>
    </main>
  );
}
