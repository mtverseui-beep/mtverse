"use client";

import * as React from "react";
import Link from "next/link";
import {
  Rocket,
  ArrowLeft,
  Mail,
  Sparkles,
  Bell,
  CheckCircle2,
  Telescope,
  ArrowRight,
  Calendar,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

// Countdown offset — kept as a constant (not Date.now() at module load) so server
// and client render the same initial HTML. The actual launch time is computed in
// useEffect (client-only) to drive the live countdown.
const LAUNCH_OFFSET_MS =
  14 * 24 * 60 * 60 * 1000 + 6 * 60 * 60 * 1000 + 32 * 60 * 1000;

function useCountdown() {
  const [launchAt, setLaunchAt] = React.useState<Date | null>(null);
  const [now, setNow] = React.useState<number | null>(null);

  React.useEffect(() => {
    const target = new Date(Date.now() + LAUNCH_OFFSET_MS);
    setLaunchAt(target);
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const target = launchAt ?? new Date(LAUNCH_OFFSET_MS);
  const ms = Math.max(0, target.getTime() - (now ?? target.getTime()));
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const seconds = Math.floor((ms / 1000) % 60);
  return { days, hours, minutes, seconds, ready: now !== null, launchAt };
}

export default function ComingSoonPage() {
  const { days, hours, minutes, seconds, ready, launchAt } = useCountdown();
  const [email, setEmail] = React.useState("");
  const [subscribed, setSubscribed] = React.useState(false);

  function subscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter a valid email", {
        description: "We'll add you to the early access list.",
      });
      return;
    }
    setSubscribed(true);
    toast.success("Welcome aboard", {
      description: `${email} is on the early access list. We'll be in touch!`,
    });
  }

  const launchDateStr = launchAt
    ? launchAt.toLocaleDateString("en-US", {
        weekday: "long",
        month: "long",
        day: "numeric",
        year: "numeric",
      })
    : "Coming soon";

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Sunrise gradient backdrop */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, oklch(0.20 0.04 280 / 0.25) 0%, oklch(0.55 0.13 175 / 0.10) 40%, oklch(0.75 0.16 75 / 0.18) 75%, oklch(0.65 0.18 25 / 0.20) 100%)",
        }}
      />

      {/* Stars at the top */}
      <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-1/2 overflow-hidden">
        {Array.from({ length: 40 }).map((_, i) => {
          const seed = i * 7919;
          const x = (seed * 23) % 100;
          const y = (seed * 11) % 50;
          const size = ((seed * 5) % 3) + 1;
          const delay = ((seed * 3) % 40) / 10;
          return (
            <div
              key={i}
              className="absolute rounded-full bg-foreground"
              style={{
                left: `${x}%`,
                top: `${y}%`,
                width: `${size}px`,
                height: `${size}px`,
                opacity: 0.5,
                animation: `twinkle 3s ease-in-out ${delay}s infinite`,
              }}
            />
          );
        })}
        <style>{`
          @keyframes twinkle {
            0%, 100% { opacity: 0.2; }
            50% { opacity: 0.8; }
          }
          @keyframes rocketFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
          }
        `}</style>
      </div>

      {/* Sun glow at bottom */}
      <div
        aria-hidden
        className="pointer-events-none absolute bottom-0 left-1/2 h-64 w-[800px] max-w-[100vw] -translate-x-1/2 rounded-[100%] opacity-50 blur-3xl"
        style={{
          background:
            "radial-gradient(ellipse at bottom, oklch(0.78 0.15 75 / 0.5) 0%, oklch(0.65 0.18 25 / 0.3) 40%, transparent 70%)",
        }}
      />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-4xl flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Pill */}
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
          <Sparkles className="h-3.5 w-3.5" />
          NexusGrid Labs · Preview
        </div>

        <div className="grid w-full items-center gap-10 lg:grid-cols-[1fr_1.1fr]">
          {/* Left: Rocket illustration */}
          <div className="order-2 flex justify-center lg:order-1">
            <div className="relative">
              <svg
                width="260"
                height="320"
                viewBox="0 0 260 320"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="h-[260px] w-[210px] sm:h-[300px] sm:w-[245px]"
                style={{ animation: "rocketFloat 4s ease-in-out infinite" }}
                aria-hidden
              >
                <defs>
                  <linearGradient id="rocketBody" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="oklch(0.99 0 0)" />
                    <stop offset="100%" stopColor="oklch(0.85 0.01 240)" />
                  </linearGradient>
                  <linearGradient id="rocketTip" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.65 0.18 25)" />
                    <stop offset="100%" stopColor="oklch(0.55 0.13 175)" />
                  </linearGradient>
                  <linearGradient id="flame" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.78 0.15 75)" />
                    <stop offset="60%" stopColor="oklch(0.65 0.18 25)" />
                    <stop offset="100%" stopColor="oklch(0.65 0.18 25 / 0)" />
                  </linearGradient>
                  <linearGradient id="window" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="oklch(0.55 0.13 175)" />
                    <stop offset="100%" stopColor="oklch(0.40 0.13 195)" />
                  </linearGradient>
                </defs>

                {/* Flame */}
                <g>
                  <path
                    d="M 110 230 Q 130 280 130 290 Q 130 280 150 230 Z"
                    fill="url(#flame)"
                  >
                    <animate
                      attributeName="d"
                      values="M 110 230 Q 130 280 130 290 Q 130 280 150 230 Z; M 108 230 Q 130 295 132 300 Q 130 295 152 230 Z; M 110 230 Q 130 280 130 290 Q 130 280 150 230 Z"
                      dur="0.6s"
                      repeatCount="indefinite"
                    />
                  </path>
                  <path
                    d="M 118 235 Q 130 270 130 278 Q 130 270 142 235 Z"
                    fill="oklch(0.99 0 0 / 0.7)"
                  >
                    <animate
                      attributeName="d"
                      values="M 118 235 Q 130 270 130 278 Q 130 270 142 235 Z; M 116 235 Q 130 280 130 290 Q 130 280 144 235 Z; M 118 235 Q 130 270 130 278 Q 130 270 142 235 Z"
                      dur="0.6s"
                      repeatCount="indefinite"
                    />
                  </path>
                </g>

                {/* Fins */}
                <path
                  d="M 110 200 L 80 230 L 110 220 Z"
                  fill="oklch(0.65 0.18 25)"
                />
                <path
                  d="M 150 200 L 180 230 L 150 220 Z"
                  fill="oklch(0.55 0.13 175)"
                />

                {/* Body */}
                <path
                  d="M 110 80 Q 110 60 130 40 Q 150 60 150 80 L 150 220 L 110 220 Z"
                  fill="url(#rocketBody)"
                  stroke="oklch(0.6 0.01 240)"
                  strokeWidth="1.5"
                />

                {/* Tip */}
                <path
                  d="M 110 80 Q 130 40 150 80 Z"
                  fill="url(#rocketTip)"
                />

                {/* Window */}
                <circle cx="130" cy="120" r="14" fill="oklch(0.20 0.01 240)" />
                <circle cx="130" cy="120" r="11" fill="url(#window)" />
                <ellipse cx="126" cy="116" rx="3" ry="4" fill="oklch(0.99 0 0 / 0.7)" />

                {/* Body details */}
                <line x1="110" y1="160" x2="150" y2="160" stroke="oklch(0.6 0.01 240)" strokeWidth="1" />
                <line x1="110" y1="180" x2="150" y2="180" stroke="oklch(0.6 0.01 240)" strokeWidth="1" />
                <rect x="120" y="195" width="20" height="6" rx="1" fill="oklch(0.55 0.13 175)" />

                {/* Highlight */}
                <path
                  d="M 116 90 L 116 215"
                  stroke="oklch(0.99 0 0 / 0.5)"
                  strokeWidth="2"
                  strokeLinecap="round"
                />

                {/* Side sparkles */}
                <g fill="oklch(0.78 0.15 75)">
                  <circle cx="60" cy="100" r="2">
                    <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite" />
                  </circle>
                  <circle cx="200" cy="140" r="2.5">
                    <animate attributeName="opacity" values="0;1;0" dur="2s" begin="0.5s" repeatCount="indefinite" />
                  </circle>
                  <circle cx="50" cy="180" r="1.5">
                    <animate attributeName="opacity" values="0;1;0" dur="2s" begin="1s" repeatCount="indefinite" />
                  </circle>
                  <circle cx="210" cy="80" r="1.5">
                    <animate attributeName="opacity" values="0;1;0" dur="2s" begin="1.5s" repeatCount="indefinite" />
                  </circle>
                </g>
              </svg>

              {/* Launch pad base */}
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2">
                <div className="h-1.5 w-32 rounded-full bg-gradient-to-r from-transparent via-foreground/30 to-transparent" />
              </div>
            </div>
          </div>

          {/* Right: Copy + countdown */}
          <div className="order-1 space-y-5 lg:order-2">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
              Something amazing
              <br />
              <span className="bg-gradient-to-r from-chart-3 via-chart-2 to-primary bg-clip-text text-transparent">
                is launching soon
              </span>
            </h1>
            <p className="text-base text-muted-foreground">
              We&apos;re putting the finishing touches on{" "}
              <span className="font-medium text-foreground">NexusGrid AI Insights</span>
              {" "}— a brand new way to surface revenue anomalies, churn risks, and
              growth opportunities automatically. Get on the early access list below.
            </p>

            {/* Countdown */}
            <div>
              <div className="mb-2 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                <Calendar className="h-3.5 w-3.5 text-primary" />
                Launching {launchDateStr}
              </div>
              <div className="grid grid-cols-4 gap-2 sm:gap-3">
                {[
                  { label: "Days", value: days },
                  { label: "Hours", value: hours },
                  { label: "Minutes", value: minutes },
                  { label: "Seconds", value: seconds },
                ].map((unit) => (
                  <div
                    key={unit.label}
                    className="rounded-xl border border-border bg-card/70 px-2 py-3 text-center shadow-premium-sm backdrop-blur-sm"
                  >
                    <div className="font-mono text-2xl font-bold tabular-nums text-foreground sm:text-3xl">
                      {ready ? String(unit.value).padStart(2, "0") : "--"}
                    </div>
                    <div className="mt-0.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      {unit.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Email subscribe */}
            <div className="rounded-2xl border border-border bg-card/70 p-4 backdrop-blur-sm">
              <div className="mb-2 flex items-center gap-2 text-sm font-medium">
                <Bell className="h-4 w-4 text-primary" />
                Join the early access list
              </div>
              {subscribed ? (
                <div className="flex items-center gap-2 rounded-lg border border-success/30 bg-success/10 px-3 py-2.5 text-sm font-medium text-success">
                  <CheckCircle2 className="h-4 w-4" />
                  You&apos;re on the list — we&apos;ll reach out before launch.
                </div>
              ) : (
                <form
                  onSubmit={subscribe}
                  className="flex flex-col gap-2 sm:flex-row"
                >
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                    className="h-11 flex-1 bg-background"
                  />
                  <Button type="submit" size="lg" className="h-11">
                    <Mail className="h-4 w-4" />
                    Get Early Access
                  </Button>
                </form>
              )}
              <div className="mt-2 flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <Sparkles className="h-3 w-3 text-primary" />
                Be first to try the private beta — no credit card needed.
              </div>
            </div>

            {/* Back link */}
            <div className="flex items-center gap-2">
              <Button asChild variant="ghost" size="sm">
                <Link href="/dashboards/analytics">
                  <ArrowLeft className="h-4 w-4" />
                  Back to Dashboard
                </Link>
              </Button>
              <span className="text-xs text-muted-foreground">·</span>
              <button
                onClick={() => toast.info("Opening roadmap…")}
                className="inline-flex items-center gap-1 text-xs font-medium text-foreground underline-offset-4 hover:underline"
              >
                <Telescope className="h-3.5 w-3.5" />
                See what else we&apos;re building
                <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
