"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Search,
  ArrowLeft,
  LayoutDashboard,
  Compass,
  Sparkles,
  Users,
  TrendingUp,
  ShoppingCart,
  Star,
} from "lucide-react";
import { BrandLogo } from "@/components/common/brand-logo";
import { ErrorThemeToggle } from "@/components/common/error-theme-toggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const QUICK_LINKS = [
  { href: "/dashboards/analytics", label: "Analytics", icon: TrendingUp },
  { href: "/dashboards/crm", label: "CRM", icon: Users },
  { href: "/dashboards/ecommerce", label: "Ecommerce", icon: ShoppingCart },
  { href: "/dashboards/saas", label: "SaaS", icon: LayoutDashboard },
];

export default function NotFoundPage() {
  const pathname = usePathname();
  const [query, setQuery] = React.useState("");

  function onSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) {
      toast.error("Enter a search term", {
        description: "Type something to search across your workspace.",
      });
      return;
    }
    toast.info(`Searching for "${query}"…`, {
      description: "We'll let you know if we find a match.",
    });
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Cosmic dark canvas */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 20%, oklch(0.22 0.04 280 / 0.35) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, oklch(0.55 0.13 175 / 0.18) 0%, transparent 55%)",
        }}
      />

      {/* Stars */}
      <Stars />

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="transition-opacity hover:opacity-80">
          <BrandLogo size="sm" />
        </Link>
        <ErrorThemeToggle />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center px-5 py-20 sm:px-8">
        {/* Huge 404 numerals as design */}
        <div className="relative mb-2 flex select-none items-center justify-center">
          <span
            className="bg-gradient-to-b from-foreground/85 to-foreground/30 bg-clip-text text-[140px] font-black tracking-tighter text-transparent sm:text-[200px] lg:text-[240px]"
            style={{ lineHeight: 0.85 }}
          >
            4
          </span>
          <div className="relative mx-1 sm:mx-3">
            <span
              className="bg-gradient-to-b from-foreground/85 to-foreground/30 bg-clip-text text-[140px] font-black tracking-tighter text-transparent sm:text-[200px] lg:text-[240px]"
              style={{ lineHeight: 0.85 }}
            >
              0
            </span>
            {/* Tiny astronaut orbiting the 0 */}
            <Astronaut />
          </div>
          <span
            className="bg-gradient-to-b from-foreground/85 to-foreground/30 bg-clip-text text-[140px] font-black tracking-tighter text-transparent sm:text-[200px] lg:text-[240px]"
            style={{ lineHeight: 0.85 }}
          >
            4
          </span>
        </div>

        {/* Code pill */}
        <div className="mb-3 mt-2 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur-sm">
          <Compass className="h-3.5 w-3.5 text-primary" />
          HTTP 404 — Lost in space
        </div>

        <h1 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">
          This page drifted off course
        </h1>
        <p className="mt-3 max-w-md text-center text-base text-muted-foreground">
          The URL you tried to visit doesn&apos;t exist in this workspace.
        </p>

        {/* Attempted URL */}
        <div className="mt-4 max-w-lg rounded-lg border border-border bg-card/50 px-3 py-2 text-center font-mono text-xs text-muted-foreground backdrop-blur-sm">
          <span className="text-foreground/70">Attempted:</span>{" "}
          <span className="text-foreground">{pathname || "/errors/404"}</span>
        </div>

        {/* Search */}
        <form onSubmit={onSearch} className="mt-7 w-full max-w-lg">
          <div className="group relative">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
            <Input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search dashboards, customers, orders…"
              className="h-12 rounded-xl border-border bg-card/70 pl-10 pr-28 text-sm shadow-premium-sm backdrop-blur-sm"
            />
            <Button
              type="submit"
              size="sm"
              className="absolute right-1.5 top-1/2 h-9 -translate-y-1/2"
            >
              Search
            </Button>
          </div>
        </form>

        {/* Actions */}
        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <Button asChild size="lg" className="h-11">
            <Link href="/dashboards/analytics">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="h-11">
            <Link href="/dashboards/analytics">
              <LayoutDashboard className="h-4 w-4" />
              Browse Dashboards
            </Link>
          </Button>
        </div>

        {/* Quick links */}
        <div className="mt-10 w-full max-w-2xl">
          <div className="mb-3 flex items-center justify-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Popular destinations
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {QUICK_LINKS.map((q) => (
              <Link
                key={q.href}
                href={q.href}
                className="group flex flex-col items-center gap-2 rounded-xl border border-border bg-card/50 p-3 text-center backdrop-blur-sm transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:bg-primary/5"
              >
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary/20">
                  <q.icon className="h-4 w-4" />
                </div>
                <span className="text-xs font-medium">{q.label}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Footer hint */}
        <div className="mt-10 flex items-center gap-1.5 text-xs text-muted-foreground">
          <Star className="h-3 w-3 text-primary" />
          Tip: Try the command palette with{" "}
          <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-[10px]">
            ⌘K
          </kbd>
        </div>
      </div>
    </main>
  );
}

function Astronaut() {
  return (
    <svg
      width="64"
      height="64"
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="absolute left-1/2 top-1/2 hidden h-12 w-12 -translate-x-1/2 -translate-y-1/2 sm:block"
      style={{ animation: "float 4s ease-in-out infinite" }}
      aria-hidden
    >
      <defs>
        <linearGradient id="astroSuit" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.95 0 0)" />
          <stop offset="100%" stopColor="oklch(0.75 0.01 240)" />
        </linearGradient>
        <linearGradient id="astroVisor" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="oklch(0.55 0.13 175)" />
          <stop offset="100%" stopColor="oklch(0.45 0.13 195)" />
        </linearGradient>
      </defs>
      {/* Helmet */}
      <circle cx="32" cy="22" r="13" fill="url(#astroSuit)" stroke="oklch(0.6 0.01 240)" strokeWidth="1" />
      {/* Visor */}
      <ellipse cx="32" cy="22" rx="9" ry="8" fill="url(#astroVisor)" />
      <ellipse cx="29" cy="19" rx="2.5" ry="3" fill="oklch(0.99 0 0 / 0.7)" />
      {/* Body */}
      <path
        d="M22 38 Q22 33 32 33 Q42 33 42 38 L42 50 Q42 54 32 54 Q22 54 22 50 Z"
        fill="url(#astroSuit)"
        stroke="oklch(0.6 0.01 240)"
        strokeWidth="1"
      />
      {/* Chest panel */}
      <rect x="28" y="40" width="8" height="6" rx="1" fill="oklch(0.55 0.13 175)" />
      <circle cx="30" cy="43" r="0.8" fill="oklch(0.99 0 0)" />
      {/* Arms */}
      <path d="M22 38 L16 46" stroke="oklch(0.7 0.01 240)" strokeWidth="3" strokeLinecap="round" />
      <path d="M42 38 L48 46" stroke="oklch(0.7 0.01 240)" strokeWidth="3" strokeLinecap="round" />
      {/* Antenna */}
      <line x1="32" y1="9" x2="32" y2="5" stroke="oklch(0.6 0.01 240)" strokeWidth="1" />
      <circle cx="32" cy="4" r="1.5" fill="oklch(0.55 0.13 175)" />
    </svg>
  );
}

function Stars() {
  // Static deterministic stars for SSR safety
  const stars = React.useMemo(
    () =>
      Array.from({ length: 60 }).map((_, i) => {
        const seed = i * 9973;
        const x = (seed * 31) % 100;
        const y = (seed * 17) % 100;
        const size = ((seed * 7) % 3) + 1;
        const delay = ((seed * 13) % 40) / 10;
        return { x, y, size, delay, id: i };
      }),
    []
  );

  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {stars.map((s) => (
        <div
          key={s.id}
          className="absolute rounded-full bg-foreground"
          style={{
            left: `${s.x}%`,
            top: `${s.y}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            opacity: 0.4,
            animation: `twinkle 3s ease-in-out ${s.delay}s infinite`,
          }}
        />
      ))}
      <style>{`
        @keyframes twinkle {
          0%, 100% { opacity: 0.15; }
          50% { opacity: 0.7; }
        }
        @keyframes float {
          0%, 100% { transform: translate(-50%, -50%) translateY(0); }
          50% { transform: translate(-50%, -50%) translateY(-6px); }
        }
      `}</style>
    </div>
  );
}
