"use client";

import Link from "next/link";
import { BrandLogo } from "@/components/common/brand-logo";
import { Button } from "@/components/ui/button";
import { Home, Search, ArrowLeft } from "lucide-react";
import { useCommandPalette } from "@/components/providers/command-palette-provider";

export default function NotFound() {
  const { setOpen } = useCommandPalette();
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top bar */}
      <header className="border-b border-border bg-background/85 backdrop-blur-md px-4 h-16 flex items-center">
        <Link href="/">
          <BrandLogo size="sm" />
        </Link>
      </header>

      <main className="flex-1 grid place-items-center px-4 py-12">
        <div className="max-w-xl text-center">
          {/* Custom SVG illustration — constellation map */}
          <div className="relative mx-auto h-48 w-48 mb-8">
            <svg viewBox="0 0 200 200" fill="none" className="absolute inset-0">
              <defs>
                <radialGradient id="glow" cx="50%" cy="50%">
                  <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
                </radialGradient>
              </defs>
              <circle cx="100" cy="100" r="80" fill="url(#glow)" />
              {/* Stars */}
              {[
                [50, 60],
                [120, 40],
                [160, 90],
                [80, 130],
                [140, 150],
                [100, 100],
              ].map(([x, y], i) => (
                <g key={i}>
                  <circle cx={x} cy={y} r={i === 5 ? 4 : 2.5} fill="var(--primary)" />
                  {i === 5 && (
                    <circle
                      cx={x}
                      cy={y}
                      r={8}
                      fill="none"
                      stroke="var(--primary)"
                      strokeOpacity="0.4"
                      strokeWidth="1"
                    />
                  )}
                </g>
              ))}
              {/* Constellation lines */}
              <g stroke="var(--primary)" strokeOpacity="0.35" strokeWidth="1" strokeDasharray="2 3">
                <path d="M50 60 L100 100 L120 40" />
                <path d="M100 100 L160 90 L140 150 L80 130 Z" />
              </g>
            </svg>
            <div className="absolute inset-x-0 bottom-0 text-center">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Lost in space
              </span>
            </div>
          </div>

          <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-2">
            Error 404
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight mb-3">
            Page not found
          </h1>
          <p className="text-sm text-muted-foreground max-w-md mx-auto mb-8">
            The page you're looking for doesn't exist or has been moved. Try searching for
            what you need, or return to the dashboard.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
            <Button asChild className="gap-1.5">
              <Link href="/dashboards/ecommerce">
                <Home className="h-4 w-4" /> Back to Dashboard
              </Link>
            </Button>
            <Button
              variant="outline"
              className="gap-1.5"
              onClick={() => setOpen(true)}
            >
              <Search className="h-4 w-4" /> Search Pages
            </Button>
          </div>

          <div className="mt-8 text-xs text-muted-foreground">
            <p>Quick links:</p>
            <div className="mt-2 flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
              <Link href="/dashboards/analytics" className="hover:text-foreground">Analytics</Link>
              <Link href="/ecommerce/orders" className="hover:text-foreground">Orders</Link>
              <Link href="/crm/leads" className="hover:text-foreground">Leads</Link>
              <Link href="/apps/calendar" className="hover:text-foreground">Calendar</Link>
              <Link href="/account/profile" className="hover:text-foreground">Profile</Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
