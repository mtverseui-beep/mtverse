"use client";

import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { BrandLogo } from "@/components/common/brand-logo";
import { AlertTriangle, RotateCcw, Home } from "lucide-react";
import Link from "next/link";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border bg-background/85 backdrop-blur-md px-4 h-16 flex items-center">
        <Link href="/">
          <BrandLogo size="sm" />
        </Link>
      </header>
      <main className="flex-1 grid place-items-center px-4 py-12">
        <div className="max-w-md text-center">
          <div className="mx-auto h-14 w-14 grid place-items-center rounded-full bg-destructive/12 text-destructive mb-5">
            <AlertTriangle className="h-6 w-6" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight mb-2">
            Something went wrong
          </h1>
          <p className="text-sm text-muted-foreground mb-6">
            An unexpected error occurred while rendering this page. Try again, or return to
            the dashboard.
          </p>
          {error.digest && (
            <p className="text-xs text-muted-foreground mb-6 font-mono">
              Error ID: {error.digest}
            </p>
          )}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
            <Button onClick={reset} className="gap-1.5">
              <RotateCcw className="h-4 w-4" /> Try Again
            </Button>
            <Button asChild variant="outline" className="gap-1.5">
              <Link href="/dashboards/ecommerce">
                <Home className="h-4 w-4" /> Back to Dashboard
              </Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
