"use client";
// Hash-based router — gives real routes (/#/patients, /#/settings/profile)
// while staying on the single `/` route per sandbox constraint.
import { useEffect, useState, useCallback } from "react";

export interface Route {
  path: string;
  segments: string[];
}

function parse(): Route {
  if (typeof window === "undefined") return { path: "", segments: [] };
  const raw = window.location.hash.replace(/^#\/?/, "");
  return { path: raw, segments: raw ? raw.split("/").filter(Boolean) : [] };
}

export function useHashRoute(): [Route, (path: string) => void] {
  const [route, setRoute] = useState<Route>({ path: "dashboard", segments: ["dashboard"] });

  useEffect(() => {
    const r = parse();
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setRoute(r.path === "" ? { path: "dashboard", segments: ["dashboard"] } : r);
    const onHash = () => {
      const p = parse();
      setRoute(p.path === "" ? { path: "dashboard", segments: ["dashboard"] } : p);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = useCallback((path: string) => {
    const clean = path.replace(/^\/+/, "");
    window.location.hash = `/${clean}`;
  }, []);

  return [route, navigate];
}
