"use client";
import { useEffect, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useHealthStore } from "@/store/health-store";
import { patientName, fmtAge, fmtDate } from "@/lib/health/format";
import { Avatar } from "./Avatar";
import { cn } from "@/lib/utils";

export function PatientSearch() {
  const patients = useHealthStore((s) => s.patients);
  const selectPatient = useHealthStore((s) => s.selectPatient);
  const setActiveTab = useHealthStore((s) => s.setActiveTab);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [open, setOpen] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  // Debounce 150ms
  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 150);
    return () => clearTimeout(t);
  }, [query]);

  const results = debounced.length > 0
    ? patients
        .filter((p) => {
          const q = debounced.toLowerCase();
          return (
            patientName(p).toLowerCase().includes(q) ||
            p.mrn.toLowerCase().includes(q) ||
            p.dob.includes(debounced) ||
            p.room.toLowerCase().includes(q) ||
            p.phone.includes(debounced)
          );
        })
        .slice(0, 8)
    : [];

  // Clamp activeIdx when results change (adjust-during-render pattern)
  const safeActiveIdx = Math.min(activeIdx, Math.max(0, results.length - 1));
  if (safeActiveIdx !== activeIdx) setActiveIdx(safeActiveIdx);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  const selectResult = (patientId: string) => {
    selectPatient(patientId);
    setActiveTab("roster");
    setQuery("");
    setOpen(false);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (!open || results.length === 0) return;
    if (e.key === "ArrowDown") { e.preventDefault(); setActiveIdx((i) => Math.min(i + 1, results.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActiveIdx((i) => Math.max(i - 1, 0)); }
    else if (e.key === "Enter") { e.preventDefault(); const r = results[safeActiveIdx]; if (r) selectResult(r.id); }
    else if (e.key === "Escape") { setOpen(false); }
  };

  return (
    <div ref={containerRef} className="relative flex-1 max-w-xl mx-4">
      <div className="relative" role="search">
        <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onKeyDown={onKeyDown}
          placeholder="Search patients by name, MRN, DOB, room, or phone…"
          aria-label="Patient search"
          aria-controls="search-results"
          aria-autocomplete="list"
          aria-activedescendant={open && results[safeActiveIdx] ? `search-result-${safeActiveIdx}` : undefined}
          className="w-full h-11 pl-11 pr-10 text-sm rounded-[12px] border bg-[var(--surface)] focus-ring outline-none transition-colors hover:border-[var(--border-strong)] text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]"
          style={{ borderColor: "var(--border)" }}
        />
        {query && (
          <button
            type="button"
            onClick={() => { setQuery(""); setOpen(false); }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] hover:text-[var(--foreground)] cursor-pointer focus-ring rounded-[6px] p-0.5"
            aria-label="Clear search"
          >
            <X size={16} />
          </button>
        )}
      </div>

      <AnimatePresence>
        {open && debounced.length > 0 && (
          <motion.div
            id="search-results"
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="absolute top-full mt-2 w-full rounded-[14px] border overflow-hidden z-50"
            style={{ background: "var(--popover)", borderColor: "var(--border)", boxShadow: "var(--shadow-lg)" }}
            role="listbox"
            aria-label="Patient search results"
          >
            <div className="px-3 py-2 text-[11px] font-medium text-[var(--foreground-muted)] border-b" style={{ borderColor: "var(--border)" }} role="status" aria-live="polite">
              {results.length} patient{results.length !== 1 ? "s" : ""} found
            </div>
            {results.length === 0 ? (
              <div className="px-4 py-8 text-center text-sm text-[var(--foreground-muted)]">
                No patients match &ldquo;{debounced}&rdquo;
              </div>
            ) : (
              <div className="max-h-[400px] overflow-y-auto">
                {results.map((p, i) => (
                  <button
                    key={p.id}
                    id={`search-result-${i}`}
                    type="button"
                    role="option"
                    aria-selected={i === safeActiveIdx}
                    onMouseEnter={() => setActiveIdx(i)}
                    onClick={() => selectResult(p.id)}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2.5 text-left transition-colors cursor-pointer",
                      i === safeActiveIdx ? "bg-[var(--surface-hover)]" : "",
                    )}
                  >
                    <Avatar seed={p.avatarSeed} name={patientName(p)} size={36} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-[var(--foreground)] truncate">{patientName(p)}</span>
                        <StatusBadge status={p.status} />
                      </div>
                      <div className="text-[11px] text-[var(--foreground-muted)] font-mono">
                        {p.mrn} · {fmtAge(p.dob)}y · {p.room}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatusBadge({ status }: { status: "stable" | "watch" | "critical" }) {
  const styles = {
    stable: { bg: "var(--success-soft)", color: "var(--success)" },
    watch: { bg: "var(--warning-soft)", color: "var(--warning)" },
    critical: { bg: "var(--critical-soft)", color: "var(--critical)" },
  }[status];
  return (
    <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wide" style={{ background: styles.bg, color: styles.color }}>
      {status}
    </span>
  );
}
