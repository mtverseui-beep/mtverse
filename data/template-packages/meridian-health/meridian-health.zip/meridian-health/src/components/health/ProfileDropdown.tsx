"use client";
import {
  User, Settings, Accessibility, Keyboard, HelpCircle, LogOut, ChevronDown, Clock,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar } from "./Avatar";
import { useHashRoute } from "@/hooks/use-hash-route";
import { toast } from "sonner";

const USER = {
  name: "Dr. Sarah Chen",
  role: "Internal Medicine · Attending",
  seed: "sarah-chen",
  shift: "Day shift · 07:00–19:00",
  accountId: "MD-4291",
};

const ITEMS: { icon: typeof User; label: string; path: string; shortcut?: string }[] = [
  { icon: User, label: "My profile", path: "profile" },
  { icon: Settings, label: "Account settings", path: "settings/account" },
  { icon: Accessibility, label: "Appearance", path: "settings/appearance" },
  { icon: Clock, label: "Shift information", path: "settings/notifications" },
  { icon: Keyboard, label: "Keyboard shortcuts", path: "settings/security", shortcut: "⌘/" },
  { icon: HelpCircle, label: "Help & support", path: "help" },
];

export function ProfileDropdown() {
  const [, navigate] = useHashRoute();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Profile menu"
          className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-[12px] border hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer"
          style={{ borderColor: "var(--border)", background: "var(--surface)" }}
        >
          <Avatar seed={USER.seed} name={USER.name} size={32} />
          <div className="hidden sm:flex flex-col items-start leading-none">
            <span className="text-xs font-semibold text-[var(--foreground)]">{USER.name.split(" ").slice(-2).join(" ")}</span>
            <span className="text-[10px] text-[var(--foreground-muted)]">Attending</span>
          </div>
          <ChevronDown size={14} className="text-[var(--foreground-muted)]" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-64 p-0 font-sans"
        style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "16px", boxShadow: "var(--shadow-xl)", overflow: "hidden" }}
      >
        <div className="flex items-center gap-3 px-4 py-3.5 border-b" style={{ borderColor: "var(--border)", background: "linear-gradient(135deg, var(--primary-soft), transparent)" }}>
          <Avatar seed={USER.seed} name={USER.name} size={40} ring />
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold truncate">{USER.name}</p>
            <p className="text-[11px] text-[var(--foreground-muted)] truncate">{USER.role}</p>
          </div>
        </div>
        <div className="flex items-center justify-between px-4 py-2 border-b text-[10px] font-mono" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <span className="flex items-center gap-1.5 text-[var(--foreground-muted)]"><Clock size={10} /> {USER.shift}</span>
          <span className="text-[var(--foreground)]">{USER.accountId}</span>
        </div>
        <div className="py-1.5">
          {ITEMS.map((item) => (
            <DropdownMenuItem key={item.label} className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 gap-2.5 px-2.5 py-2 text-sm" onClick={() => navigate(item.path)}>
              <item.icon size={15} className="text-[var(--foreground-muted)]" />
              <span className="flex-1">{item.label}</span>
              {item.shortcut && <span className="text-[10px] font-mono text-[var(--foreground-muted)] px-1.5 py-0.5 rounded border" style={{ borderColor: "var(--border)" }}>{item.shortcut}</span>}
            </DropdownMenuItem>
          ))}
        </div>
        <DropdownMenuSeparator style={{ background: "var(--border)" }} />
        <div className="py-1.5">
          <DropdownMenuItem className="cursor-pointer focus:bg-[var(--critical-soft)] rounded-[8px] mx-1 gap-2.5 px-2.5 py-2 text-sm text-[var(--critical)]" onClick={() => toast.info("Sign out", { description: "Session ended. (Demo)" })}>
            <LogOut size={15} /> <span>Sign out</span>
          </DropdownMenuItem>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
