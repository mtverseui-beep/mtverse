"use client";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function BrandMark({ size = 32, onClick }: { size?: number; onClick?: () => void }) {
  const content = (
    <div className="flex items-center gap-2.5 shrink-0">
      <img src="/icon.svg" alt="Meridian Health" width={size} height={size} style={{ display: "block" }} />
      <div className="flex flex-col leading-none">
        <span className="font-semibold tracking-tight text-[var(--foreground)]" style={{ fontSize: size * 0.5 }}>
          Meridian
        </span>
        <span className="text-[var(--foreground-muted)] font-medium uppercase tracking-[0.12em]" style={{ fontSize: size * 0.26 }}>
          Health
        </span>
      </div>
    </div>
  );
  if (onClick) {
    return (
      <motion.button
        type="button"
        onClick={onClick}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={cn("cursor-pointer focus-ring rounded-[10px]")}
        aria-label="Meridian Health home"
      >
        {content}
      </motion.button>
    );
  }
  return content;
}
