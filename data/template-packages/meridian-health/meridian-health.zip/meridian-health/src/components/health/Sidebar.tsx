"use client";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, Users, Calendar, Stethoscope, BarChart3, Settings,
  ChevronLeft, ChevronRight, Bell, Search, Activity,
} from "lucide-react";
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from "@/components/ui/tooltip";
import { useHealthStore } from "@/store/health-store";
import { Avatar } from "./Avatar";
import { cn } from "@/lib/utils";
import type { Route } from "@/hooks/use-hash-route";

interface SidebarProps {
  route: Route;
  navigate: (path: string) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const NAV_GROUPS: { label: string; items: { path: string; label: string; icon: React.ComponentType<{ size?: number; className?: string }>; badgeKey?: "criticalCount" | "taskCount" }[] }[] = [
  {
    label: "Overview",
    items: [
      { path: "dashboard", label: "Dashboard", icon: LayoutDashboard },
      { path: "patients", label: "Patients", icon: Users },
      { path: "appointments", label: "Appointments", icon: Calendar },
    ],
  },
  {
    label: "Clinical",
    items: [
      { path: "care-team", label: "Care Team", icon: Stethoscope },
      { path: "reports", label: "Reports", icon: BarChart3 },
    ],
  },
  {
    label: "System",
    items: [
      { path: "settings/profile", label: "Settings", icon: Settings },
    ],
  },
];

export function Sidebar({ route, navigate, collapsed, onToggleCollapse }: SidebarProps) {
  const patients = useHealthStore((s) => s.patients);
  const tasks = useHealthStore((s) => s.tasks);
  const criticalCount = patients.filter((p) => p.status === "critical").length;
  const taskCount = tasks.filter((t) => t.status === "pending" || t.status === "overdue").length;
  const badges: Record<string, number> = { criticalCount, taskCount };

  const currentTop = route.segments[0] ?? "dashboard";

  return (
    <TooltipProvider delayDuration={collapsed ? 200 : 99999}>
      <motion.aside
        initial={false}
        animate={{ width: collapsed ? 72 : 248 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
        className="shrink-0 border-r flex flex-col h-full"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
        aria-label="Primary navigation"
      >
        {/* Brand */}
        <div className="h-[72px] flex items-center px-4 border-b shrink-0" style={{ borderColor: "var(--border)" }}>
          <button type="button" onClick={() => navigate("dashboard")} className="flex items-center gap-2.5 cursor-pointer focus-ring rounded-[8px] min-w-0" aria-label="Meridian Health home">
            <img src="/icon.svg" alt="Meridian Health" width={32} height={32} style={{ display: "block", filter: "drop-shadow(0 2px 6px rgba(13,148,136,0.25))" }} className="shrink-0" />
            <AnimatePresence>
              {!collapsed && (
                <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }} transition={{ duration: 0.15 }} className="flex flex-col leading-none min-w-0">
                  <span className="text-sm font-semibold tracking-tight text-[var(--foreground)]">Meridian</span>
                  <span className="text-[10px] text-[var(--foreground-muted)] font-medium uppercase tracking-[0.12em]">Health</span>
                </motion.div>
              )}
            </AnimatePresence>
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-4" role="navigation">
          {NAV_GROUPS.map((group) => (
            <div key={group.label}>
              <AnimatePresence>
                {!collapsed && (
                  <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] px-3 mb-1.5">
                    {group.label}
                  </motion.p>
                )}
              </AnimatePresence>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = currentTop === item.path.split("/")[0] || (item.path === "settings/profile" && currentTop === "settings");
                  const badge = item.badgeKey ? badges[item.badgeKey] : undefined;
                  const button = (
                    <button
                      key={item.path}
                      type="button"
                      onClick={() => navigate(item.path)}
                      aria-current={active ? "page" : undefined}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-2 rounded-[10px] text-sm font-medium transition-colors cursor-pointer focus-ring relative",
                        active
                          ? "text-[var(--primary)]"
                          : "text-[var(--foreground-secondary)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]",
                        collapsed && "justify-center px-0",
                      )}
                      style={active ? { background: "var(--primary-soft)" } : undefined}
                    >
                      <Icon size={18} className="shrink-0" />
                      <AnimatePresence>
                        {!collapsed && (
                          <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 text-left truncate">
                            {item.label}
                          </motion.span>
                        )}
                      </AnimatePresence>
                      {!collapsed && badge !== undefined && badge > 0 && (
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full text-white" style={{ background: item.path === "patients" ? "var(--critical)" : "var(--warning)" }}>
                          {badge}
                        </span>
                      )}
                      {collapsed && badge !== undefined && badge > 0 && (
                        <span className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ background: item.path === "patients" ? "var(--critical)" : "var(--warning)" }} />
                      )}
                    </button>
                  );
                  if (collapsed) {
                    return (
                      <Tooltip key={item.path}>
                        <TooltipTrigger asChild>{button}</TooltipTrigger>
                        <TooltipContent side="right" sideOffset={12} className="font-sans text-xs" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "8px", boxShadow: "var(--shadow-md)" }}>
                          {item.label}
                        </TooltipContent>
                      </Tooltip>
                    );
                  }
                  return button;
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Collapse toggle */}
        <div className="px-2 py-2 border-t shrink-0" style={{ borderColor: "var(--border)" }}>
          <button type="button" onClick={onToggleCollapse} className={cn("w-full flex items-center gap-3 px-3 py-2 rounded-[10px] text-xs font-medium text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring", collapsed && "justify-center px-0")} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            {!collapsed && <span>Collapse</span>}
          </button>
        </div>

        {/* User mini-profile */}
        <div className="p-2 border-t shrink-0" style={{ borderColor: "var(--border)" }}>
          <button type="button" onClick={() => navigate("profile")} className={cn("w-full flex items-center gap-2.5 p-2 rounded-[10px] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring", collapsed && "justify-center")} aria-label="View profile">
            <Avatar seed="sarah-chen" name="Dr. Sarah Chen" size={32} />
            {!collapsed && (
              <div className="flex-1 min-w-0 text-left">
                <p className="text-xs font-semibold text-[var(--foreground)] truncate">Dr. Sarah Chen</p>
                <p className="text-[10px] text-[var(--foreground-muted)] truncate">Attending · Day shift</p>
              </div>
            )}
          </button>
        </div>
      </motion.aside>
    </TooltipProvider>
  );
}
