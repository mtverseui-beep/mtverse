"use client";
import { useMemo, useState } from "react";
import { ResponsiveLine } from "@nivo/line";
import { useHealthStore } from "@/store/health-store";
import { NOW } from "@/lib/health/format";
import { VITAL_RANGES } from "@/lib/health/types";
import { cn } from "@/lib/utils";

type RangeKey = "24h" | "48h" | "7d" | "30d";
const RANGES: { key: RangeKey; label: string; hours: number }[] = [
  { key: "24h", label: "24H", hours: 24 },
  { key: "48h", label: "48H", hours: 48 },
  { key: "7d", label: "7D", hours: 168 },
  { key: "30d", label: "30D", hours: 720 },
];

const SERIES = [
  { key: "hr", label: "Heart Rate", color: "#EF4444", unit: "bpm" },
  { key: "bpSys", label: "Systolic BP", color: "#0D9488", unit: "mmHg" },
  { key: "bpDia", label: "Diastolic BP", color: "#14B8A6", unit: "mmHg" },
  { key: "spo2", label: "SpO₂", color: "#3B82F6", unit: "%" },
  { key: "temp", label: "Temperature", color: "#F59E0B", unit: "°C" },
] as const;

export function VitalsTab({ patientId }: { patientId: string }) {
  const vitals = useHealthStore((s) => s.vitals);
  const [range, setRange] = useState<RangeKey>("7d");
  const [visible, setVisible] = useState<Record<string, boolean>>({ hr: true, bpSys: true, bpDia: true, spo2: true, temp: true });

  const data = useMemo(() => {
    const all = vitals[patientId] ?? [];
    const hours = RANGES.find((r) => r.key === range)!.hours;
    const cutoff = NOW - hours * 3600000;
    const filtered = all.filter((v) => new Date(v.timestamp).getTime() >= cutoff);
    return SERIES.filter((s) => visible[s.key]).map((s) => ({
      id: s.label,
      color: s.color,
      data: filtered.map((v) => ({
        x: new Date(v.timestamp).getTime(),
        y: v[s.key as "hr" | "bpSys" | "bpDia" | "spo2" | "temp"],
      })),
    }));
  }, [vitals, patientId, range, visible]);

  return (
    <div className="p-4 space-y-3">
      {/* Range switcher */}
      <div className="flex items-center rounded-[10px] border overflow-hidden" style={{ borderColor: "var(--border)" }} role="tablist" aria-label="Time range">
        {RANGES.map((r) => (
          <button key={r.key} type="button" role="tab" aria-selected={range === r.key} onClick={() => setRange(r.key)} className={cn("flex-1 py-1.5 text-xs font-mono font-semibold transition-colors cursor-pointer focus-ring", range === r.key ? "text-white" : "text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]")} style={range === r.key ? { background: "var(--primary)" } : undefined}>
            {r.label}
          </button>
        ))}
      </div>

      {/* Legend toggles */}
      <div className="flex flex-wrap gap-1.5">
        {SERIES.map((s) => {
          const active = visible[s.key];
          return (
            <button key={s.key} type="button" onClick={() => setVisible((v) => ({ ...v, [s.key]: !v[s.key] }))} className={cn("flex items-center gap-1.5 px-2 py-1 text-[10px] font-medium rounded-[6px] border transition-all cursor-pointer focus-ring", !active && "opacity-40")} style={{ borderColor: active ? s.color : "var(--border)", background: active ? `${s.color}15` : "var(--surface)" }} aria-pressed={active}>
              <span className="w-2 h-2 rounded-full" style={{ background: s.color, opacity: active ? 1 : 0.4 }} />
              <span style={{ color: active ? s.color : "var(--foreground-muted)" }}>{s.label}</span>
            </button>
          );
        })}
      </div>

      {/* Chart */}
      <div className="rounded-[12px] border p-3" style={{ borderColor: "var(--border)", background: "var(--surface)", height: 320 }}>
        <ResponsiveLine
          data={data}
          margin={{ top: 8, right: 12, bottom: 28, left: 44 }}
          xScale={{ type: "linear" }}
          yScale={{ type: "linear", min: "auto", max: "auto", stacked: false }}
          axisBottom={{
            format: (v) => new Date(v).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
            tickSize: 0,
            tickPadding: 8,
            legend: "",
          }}
          axisLeft={{
            tickSize: 0,
            tickPadding: 8,
          }}
          gridXValues={5}
          gridYValues={5}
          enableGridX={true}
          enableGridY={true}
          enablePoints={false}
          enableSlices="x"
          crosshairType="cross"
          useMesh={true}
          theme={{
            background: "transparent",
            text: { fill: "var(--foreground-muted)", fontSize: 10, fontFamily: "var(--font-sans)" },
            axis: { ticks: { line: { stroke: "var(--border)" }, text: { fill: "var(--foreground-muted)" } } },
            grid: { line: { stroke: "var(--border)", strokeDasharray: "2 4" } },
            crosshair: { line: { stroke: "var(--border-strong)", strokeWidth: 1, strokeDasharray: "3 3" } },
          }}
          colors={{ datum: "color" }}
          lineWidth={2}
          sliceTooltip={({ slice }) => {
            const ts = slice.points[0]?.data.x as number;
            return (
              <div className="rounded-[10px] border p-2.5 text-xs" style={{ background: "var(--popover)", borderColor: "var(--border)", boxShadow: "var(--shadow-lg)" }}>
                <div className="font-mono text-[10px] text-[var(--foreground-muted)] mb-1.5">{new Date(ts).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</div>
                {slice.points.map((p) => (
                  <div key={p.id} className="flex items-center gap-2 py-0.5">
                    <span className="w-2 h-2 rounded-full" style={{ background: p.seriesColor }} />
                    <span className="text-[var(--foreground-secondary)]">{p.seriesId}</span>
                    <span className="font-mono font-semibold ml-auto" style={{ color: "var(--foreground)" }}>{p.data.y as number}</span>
                  </div>
                ))}
              </div>
            );
          }}
        />
      </div>

      {/* Reference ranges */}
      <div className="rounded-[10px] border p-3" style={{ borderColor: "var(--border)", background: "var(--surface-subtle)" }}>
        <h4 className="text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] mb-2">Reference Ranges</h4>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
          {SERIES.map((s) => {
            const range = VITAL_RANGES[s.key as keyof typeof VITAL_RANGES];
            if (!range) return null;
            return (
              <div key={s.key} className="flex items-center justify-between text-[11px]">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ background: s.color }} />
                  <span className="text-[var(--foreground-secondary)]">{s.label}</span>
                </span>
                <span className="font-mono text-[var(--foreground-muted)]">{range.min}–{range.max} {range.unit}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
