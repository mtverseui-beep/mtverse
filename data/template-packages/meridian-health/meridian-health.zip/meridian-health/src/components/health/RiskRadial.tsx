"use client";
export function RiskRadial({ score, size = 44 }: { score: number; size?: number }) {
  const level = score <= 30 ? "Low" : score <= 70 ? "Mod" : "High";
  const color = score <= 30 ? "#10B981" : score <= 70 ? "#F59E0B" : "#FB7185";
  const radius = size / 2 - 4;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }} role="img" aria-label={`Risk score ${score}, ${level === "Low" ? "low risk" : level === "Mod" ? "moderate risk" : "high risk"}`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="var(--border)" strokeWidth={3} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={3}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono font-bold leading-none text-[var(--foreground)]" style={{ fontSize: size * 0.28 }}>{score}</span>
        <span className="font-semibold leading-none mt-0.5" style={{ fontSize: size * 0.16, color }}>{level}</span>
      </div>
    </div>
  );
}
