"use client";
import { useHealthStore } from "@/store/health-store";
import { fmtRelative } from "@/lib/health/format";
import { Check, Pause, History, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Medication } from "@/lib/health/types";

const STATUS_STYLES: Record<Medication["status"], { bg: string; color: string; label: string }> = {
  scheduled: { bg: "var(--surface-hover)", color: "var(--foreground-secondary)", label: "Scheduled" },
  due: { bg: "var(--warning-soft)", color: "var(--warning)", label: "Due now" },
  overdue: { bg: "var(--critical-soft)", color: "var(--critical)", label: "Overdue" },
  administered: { bg: "var(--success-soft)", color: "var(--success)", label: "Given" },
  held: { bg: "var(--info-soft)", color: "var(--info)", label: "Held" },
  cancelled: { bg: "var(--surface-hover)", color: "var(--foreground-muted)", label: "Cancelled" },
};

export function MedicationsTab({ patientId }: { patientId: string }) {
  const medications = useHealthStore((s) => s.medications);
  const administer = useHealthStore((s) => s.administerMedication);
  const ptMeds = medications.filter((m) => m.patientId === patientId);

  return (
    <div className="p-4 space-y-2">
      {ptMeds.length === 0 ? (
        <div className="text-center py-8 text-xs text-[var(--foreground-muted)]">No medications on record.</div>
      ) : (
        ptMeds.map((m) => {
          const s = STATUS_STYLES[m.status];
          return (
            <div key={m.id} className={cn("rounded-[10px] border p-3", m.status === "overdue" && "ring-1 ring-[var(--critical)]")} style={{ borderColor: "var(--border)", background: m.status === "overdue" ? "var(--critical-soft)" : "var(--surface)" }}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-[var(--foreground)]">{m.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: s.bg, color: s.color }}>{s.label}</span>
                  </div>
                  <div className="text-[11px] text-[var(--foreground-secondary)] font-mono mt-0.5">
                    {m.dose} · {m.route} · {m.frequency}
                  </div>
                  {m.instructions && <div className="text-[11px] text-[var(--foreground-muted)] mt-1 italic">"{m.instructions}"</div>}
                </div>
              </div>
              <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t" style={{ borderColor: "var(--border)" }}>
                <div className="text-[10px] font-mono text-[var(--foreground-muted)]">
                  {m.lastAdministered ? `Last: ${fmtRelative(m.lastAdministered)}` : "Not yet given"} · Next: {fmtRelative(m.nextDue)}
                </div>
                <div className="flex items-center gap-1">
                  {m.status === "overdue" && <AlertCircle size={12} className="text-[var(--critical)]" />}
                  <button type="button" onClick={() => toast.info("Medication history", { description: `Full MAR for ${m.name}` })} className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label="View history"><History size={13} /></button>
                  {m.status !== "held" && m.status !== "cancelled" && m.status !== "administered" && (
                    <>
                      <button type="button" onClick={() => toast.info("Medication held", { description: m.name })} className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--warning)] hover:bg-[var(--warning-soft)] transition-colors cursor-pointer focus-ring" aria-label="Hold medication"><Pause size={13} /></button>
                      <button type="button" onClick={() => { administer(m.id); toast.success("Medication administered", { description: `${m.name} ${m.dose} ${m.route}` }); }} className="flex items-center gap-1 px-2.5 h-7 rounded-[6px] text-[11px] font-semibold text-white cursor-pointer focus-ring transition-colors hover:brightness-110" style={{ background: "var(--primary)" }} aria-label="Mark administered"><Check size={13} /> Give</button>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}
