"use client";
import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Sun, Moon, Monitor } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type ThemeOption = "light" | "dark" | "system";
const OPTIONS: { id: ThemeOption; label: string; icon: React.ComponentType<{ size?: number }> }[] = [
  { id: "light", label: "Light", icon: Sun },
  { id: "dark", label: "Dark", icon: Moon },
  { id: "system", label: "System", icon: Monitor },
];

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);
  const current = (theme as ThemeOption) ?? "light";
  const CurrentIcon = mounted ? OPTIONS.find((o) => o.id === current)?.icon ?? Sun : Sun;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Toggle theme"
          className="w-10 h-10 rounded-[10px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer"
        >
          <AnimatePresence mode="wait" initial={false}>
            <motion.span
              key={mounted ? current : "placeholder"}
              initial={{ opacity: 0, rotate: -90, scale: 0.5 }}
              animate={{ opacity: 1, rotate: 0, scale: 1 }}
              exit={{ opacity: 0, rotate: 90, scale: 0.5 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
            >
              <CurrentIcon size={18} />
            </motion.span>
          </AnimatePresence>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-40 font-sans"
        style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "14px", boxShadow: "var(--shadow-lg)" }}
      >
        {OPTIONS.map((opt) => {
          const Icon = opt.icon;
          const active = mounted && current === opt.id;
          return (
            <DropdownMenuItem
              key={opt.id}
              onClick={() => setTheme(opt.id)}
              className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 gap-2.5 px-2.5 py-2 text-sm"
            >
              <Icon size={15} />
              <span className="flex-1">{opt.label}</span>
              {active && <motion.span layoutId="theme-active" className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--primary)" }} />}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
