"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronRight, Plus, FileText, Stethoscope, Pill, FlaskConical, Image as ImageIcon,
  Wrench, LogOut, ClipboardList, Save, X,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useHealthStore } from "@/store/health-store";
import { fmtDateTime, fmtRelative } from "@/lib/health/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { VisitNode, VisitType } from "@/lib/health/types";

const TYPE_META: Record<VisitType, { icon: React.ComponentType<{ size?: number }>; color: string; bg: string }> = {
  admission: { icon: LogOut, color: "var(--secondary)", bg: "var(--secondary-soft)" },
  "physician-note": { icon: Stethoscope, color: "var(--primary)", bg: "var(--primary-soft)" },
  "nursing-note": { icon: ClipboardList, color: "var(--info)", bg: "var(--info-soft)" },
  medication: { icon: Pill, color: "var(--warning)", bg: "var(--warning-soft)" },
  lab: { icon: FlaskConical, color: "var(--info)", bg: "var(--info-soft)" },
  imaging: { icon: ImageIcon, color: "var(--secondary)", bg: "var(--secondary-soft)" },
  procedure: { icon: Wrench, color: "var(--critical)", bg: "var(--critical-soft)" },
  "discharge-planning": { icon: FileText, color: "var(--success)", bg: "var(--success-soft)" },
};

export function TimelineTab({ patientId }: { patientId: string }) {
  const visits = useHealthStore((s) => s.visits);
  const addNote = useHealthStore((s) => s.addVisitNote);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [addOpen, setAddOpen] = useState(false);

  const ptVisits = visits.filter((v) => v.patientId === patientId);

  const toggle = (id: string) => {
    setExpanded((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)]">{ptVisits.length} visits</h3>
        <button type="button" onClick={() => setAddOpen(true)} className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-[8px] text-white cursor-pointer focus-ring transition-colors hover:brightness-110" style={{ background: "var(--primary)" }}>
          <Plus size={12} /> Add note
        </button>
      </div>

      {ptVisits.length === 0 ? (
        <div className="text-center py-8 text-xs text-[var(--foreground-muted)]">No visit history.</div>
      ) : (
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-[15px] top-2 bottom-2 w-px" style={{ background: "var(--border)" }} />
          <div className="space-y-1">
            {ptVisits.map((v, i) => {
              const meta = TYPE_META[v.type];
              const Icon = meta.icon;
              const isExpanded = expanded.has(v.id);
              return (
                <div key={v.id} className="relative pl-10">
                  {/* Node */}
                  <div className="absolute left-0 top-1 w-8 h-8 rounded-[8px] flex items-center justify-center z-10" style={{ background: meta.bg, color: meta.color }}>
                    <Icon size={15} />
                  </div>
                  <button type="button" onClick={() => toggle(v.id)} className="w-full text-left rounded-[10px] border p-3 transition-colors hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" style={{ borderColor: "var(--border)", background: "var(--surface)" }} aria-expanded={isExpanded}>
                    <div className="flex items-center gap-2">
                      <ChevronRight size={14} className={cn("text-[var(--foreground-muted)] transition-transform shrink-0", isExpanded && "rotate-90")} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-[var(--foreground)] truncate">{v.title}</p>
                        <p className="text-[10px] text-[var(--foreground-muted)] font-mono">{v.author} · {fmtRelative(v.timestamp)}</p>
                      </div>
                      {v.priority === "urgent" && <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--warning-soft)", color: "var(--warning)" }}>Urgent</span>}
                      {v.priority === "critical" && <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--critical-soft)", color: "var(--critical)" }}>Critical</span>}
                    </div>
                    <AnimatePresence initial={false}>
                      {isExpanded && (
                        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
                          <div className="pt-2.5 mt-2.5 border-t space-y-2" style={{ borderColor: "var(--border)" }}>
                            <div className="flex items-center gap-3 text-[10px] font-mono text-[var(--foreground-muted)]">
                              <span>{fmtDateTime(v.timestamp)}</span>
                              <span>·</span>
                              <span>{v.author} ({v.authorRole})</span>
                              <span>·</span>
                              <span>{v.department}</span>
                            </div>
                            <p className="text-xs text-[var(--foreground-secondary)] leading-relaxed">{v.note}</p>
                            {v.attachments && v.attachments.length > 0 && (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {v.attachments.map((a, idx) => (
                                  <span key={idx} className="flex items-center gap-1 px-2 py-1 text-[10px] rounded-[6px] border" style={{ borderColor: "var(--border)", background: "var(--surface-subtle)" }}>
                                    <FileText size={11} className="text-[var(--foreground-muted)]" />
                                    {a.name}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <AddNoteDialog open={addOpen} onOpenChange={setAddOpen} patientId={patientId} onAdd={addNote} />
    </div>
  );
}

function AddNoteDialog({ open, onOpenChange, patientId, onAdd }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  patientId: string;
  onAdd: (note: Omit<VisitNode, "id">) => void;
}) {
  const [type, setType] = useState<VisitType>("physician-note");
  const [note, setNote] = useState("");
  const [priority, setPriority] = useState<"routine" | "urgent" | "critical">("routine");
  const [error, setError] = useState<string>();

  const submit = () => {
    if (!note.trim()) { setError("Note content is required"); return; }
    onAdd({
      patientId,
      type,
      timestamp: new Date().toISOString(),
      author: "Dr. Sarah Chen",
      authorRole: "MD",
      department: "Medicine",
      title: type === "physician-note" ? "Progress Note" : type === "nursing-note" ? "Nursing Note" : "Clinical Note",
      note: note.trim(),
      priority,
    });
    toast.success("Note saved", { description: "Added to visit timeline" });
    setNote(""); setType("physician-note"); setPriority("routine"); setError(undefined);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent aria-describedby={undefined} className="font-sans max-w-lg p-0 gap-0" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "18px", boxShadow: "var(--shadow-xl)" }}>
        <DialogHeader className="px-5 pt-5 pb-3 border-b" style={{ borderColor: "var(--border)" }}>
          <DialogTitle className="text-base font-semibold">Add Clinical Note</DialogTitle>
        </DialogHeader>
        <div className="px-5 py-4 space-y-4">
          <div>
            <label className="block text-xs font-medium text-[var(--foreground)] mb-1.5">Note type</label>
            <select value={type} onChange={(e) => setType(e.target.value as VisitType)} className="w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none cursor-pointer text-[var(--foreground)]" style={{ borderColor: "var(--border)" }} aria-label="Note type">
              <option value="physician-note">Physician note</option>
              <option value="nursing-note">Nursing note</option>
              <option value="medication">Medication</option>
              <option value="lab">Lab</option>
              <option value="imaging">Imaging</option>
              <option value="procedure">Procedure</option>
              <option value="discharge-planning">Discharge planning</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--foreground)] mb-1.5">Note</label>
            <textarea value={note} onChange={(e) => { setNote(e.target.value); setError(undefined); }} rows={5} placeholder="Enter clinical note…" className={cn("w-full px-3 py-2 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none resize-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]", error && "border-[var(--critical)]")} style={{ borderColor: error ? "var(--critical)" : "var(--border)" }} />
            {error && <p className="text-[11px] text-[var(--critical)] mt-1">{error}</p>}
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--foreground)] mb-1.5">Priority</label>
            <div className="flex gap-1.5">
              {(["routine", "urgent", "critical"] as const).map((p) => (
                <button key={p} type="button" onClick={() => setPriority(p)} className={cn("flex-1 py-1.5 text-xs font-medium rounded-[8px] border capitalize transition-all cursor-pointer focus-ring", priority === p ? "text-white" : "text-[var(--foreground-secondary)] hover:bg-[var(--surface-hover)]")} style={priority === p ? { background: p === "routine" ? "var(--primary)" : p === "urgent" ? "var(--warning)" : "var(--critical)", borderColor: "transparent" } : { borderColor: "var(--border)" }}>{p}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex items-center justify-end gap-2 px-5 py-4 border-t" style={{ borderColor: "var(--border)" }}>
          <button type="button" onClick={() => onOpenChange(false)} className="flex items-center gap-1.5 px-3 h-9 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><X size={14} /> Cancel</button>
          <button type="button" onClick={submit} className="flex items-center gap-1.5 px-4 h-9 text-xs font-semibold rounded-[10px] text-white cursor-pointer focus-ring hover:brightness-110" style={{ background: "var(--primary)" }}><Save size={14} /> Save note</button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
