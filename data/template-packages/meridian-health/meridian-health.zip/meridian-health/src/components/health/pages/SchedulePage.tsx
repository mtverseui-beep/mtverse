"use client";
import { useState } from "react";
import { DayPicker } from "react-day-picker";
import { motion } from "framer-motion";
import { Plus, Clock, User, Stethoscope, MapPin, CheckCircle2, Play, CalendarX } from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useHealthStore } from "@/store/health-store";
import { NOW } from "@/lib/health/format";
import { Avatar } from "../Avatar";
import { patientName } from "@/lib/health/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { format } from "date-fns";

const STATUS_STYLES = {
  scheduled: { bg: "var(--surface-hover)", color: "var(--foreground-secondary)", label: "Scheduled" },
  "checked-in": { bg: "var(--info-soft)", color: "var(--info)", label: "Checked in" },
  "in-progress": { bg: "var(--warning-soft)", color: "var(--warning)", label: "In progress" },
  completed: { bg: "var(--success-soft)", color: "var(--success)", label: "Completed" },
  cancelled: { bg: "var(--critical-soft)", color: "var(--critical)", label: "Cancelled" },
  "no-show": { bg: "var(--critical-soft)", color: "var(--critical)", label: "No-show" },
} as const;

const VISIT_TYPE_LABELS: Record<string, string> = {
  "follow-up": "Follow-up", "new-patient": "New patient", procedure: "Procedure",
  telehealth: "Telehealth", urgent: "Urgent", annual: "Annual exam",
};

export function SchedulePage() {
  const appointments = useHealthStore((s) => s.appointments);
  const patients = useHealthStore((s) => s.patients);
  const providers = useHealthStore((s) => s.providers);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date(NOW));
  const [newOpen, setNewOpen] = useState(false);

  const dateStr = format(selectedDate, "yyyy-MM-dd");
  const dayAppts = appointments.filter((a) => a.date === dateStr).sort((a, b) => a.startTime.localeCompare(b.startTime));
  const appointmentDates = new Set(appointments.map((a) => a.date));

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-[var(--foreground)] tracking-tight">Schedule</h1>
          <p className="text-sm text-[var(--foreground-muted)] mt-1">{dayAppts.length} appointment{dayAppts.length !== 1 ? "s" : ""} on {format(selectedDate, "MMMM d, yyyy")}</p>
        </div>
        <button type="button" onClick={() => setNewOpen(true)} className="flex items-center gap-1.5 px-4 h-9 text-sm font-semibold rounded-[10px] text-white cursor-pointer focus-ring hover:brightness-110" style={{ background: "var(--primary)" }}>
          <Plus size={15} /> New appointment
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[360px_1fr] gap-6">
        {/* Calendar */}
        <div className="rounded-[14px] border p-4 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
          <DayPicker
            mode="single"
            selected={selectedDate}
            onSelect={(d) => d && setSelectedDate(d)}
            modifiers={{ hasAppointment: (date) => appointmentDates.has(format(date, "yyyy-MM-dd")) }}
            modifiersClassNames={{
              hasAppointment: "rdp-has-appointment",
            }}
            classNames={{
              months: "flex flex-col",
              month: "flex flex-col gap-3",
              month_caption: "flex justify-center pt-1 relative items-center",
              caption_label: "text-sm font-semibold",
              nav: "flex items-center gap-1",
              button_previous: "inline-flex items-center justify-center w-7 h-7 rounded-[8px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring absolute left-1",
              button_next: "inline-flex items-center justify-center w-7 h-7 rounded-[8px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring absolute right-1",
              weekdays: "flex",
              weekday: "text-[10px] font-semibold uppercase text-[var(--foreground-muted)] w-8 text-center py-1",
              week: "flex w-full mt-1",
              day: "relative p-0 text-center text-xs focus-within:relative",
              day_button: "w-8 h-8 rounded-[8px] text-xs cursor-pointer hover:bg-[var(--surface-hover)] focus-ring outline-none transition-colors",
              selected: "bg-[var(--primary)] text-white hover:bg-[var(--primary-hover)] font-semibold",
              today: "ring-1 ring-[var(--primary)] font-semibold",
              outside: "text-[var(--foreground-muted)] opacity-50",
            }}
          />
          <div className="mt-4 pt-4 border-t" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-1.5 text-[11px] text-[var(--foreground-muted)]">
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--primary)" }} />
              Days with appointments
            </div>
          </div>
        </div>

        {/* Day schedule */}
        <div className="space-y-2">
          {dayAppts.length === 0 ? (
            <div className="rounded-[14px] border p-12 text-center bg-[var(--surface)]" style={{ borderColor: "var(--border)" }}>
              <CalendarX size={32} className="mx-auto text-[var(--foreground-muted)] mb-3" />
              <p className="text-sm font-semibold text-[var(--foreground)]">No appointments</p>
              <p className="text-xs text-[var(--foreground-muted)] mt-1">There are no appointments scheduled for this day.</p>
              <button type="button" onClick={() => setNewOpen(true)} className="mt-4 inline-flex items-center gap-1.5 px-3 h-8 text-xs font-semibold rounded-[8px] text-white cursor-pointer focus-ring" style={{ background: "var(--primary)" }}>
                <Plus size={13} /> Schedule one
              </button>
            </div>
          ) : (
            dayAppts.map((a) => {
              const patient = patients.find((p) => p.id === a.patientId);
              const provider = providers.find((p) => p.id === a.providerId);
              if (!patient || !provider) return null;
              const s = STATUS_STYLES[a.status];
              return (
                <motion.div key={a.id} layout initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="rounded-[12px] border p-4 bg-[var(--surface)] flex items-center gap-4" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-xs)" }}>
                  <div className="flex flex-col items-center justify-center w-16 shrink-0">
                    <span className="text-sm font-mono font-bold text-[var(--foreground)]">{a.startTime}</span>
                    <span className="text-[10px] text-[var(--foreground-muted)]">{a.durationMin}min</span>
                  </div>
                  <div className="w-px h-12" style={{ background: "var(--border)" }} />
                  <Avatar seed={patient.avatarSeed} name={patientName(patient)} size={40} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-[var(--foreground)] truncate">{patientName(patient)}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: s.bg, color: s.color }}>{s.label}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-[var(--foreground-muted)] mt-0.5">
                      <span className="flex items-center gap-1"><Stethoscope size={11} /> {provider.name}</span>
                      <span className="flex items-center gap-1"><MapPin size={11} /> {a.room}</span>
                      <span className="flex items-center gap-1"><User size={11} /> {VISIT_TYPE_LABELS[a.visitType]}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {a.status === "scheduled" && <button type="button" onClick={() => toast.success("Patient checked in", { description: patientName(patient) })} className="px-2.5 h-7 text-[11px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}>Check in</button>}
                    {(a.status === "checked-in" || a.status === "scheduled") && <button type="button" onClick={() => toast.success("Visit started", { description: patientName(patient) })} className="flex items-center gap-1 px-2.5 h-7 text-[11px] font-semibold rounded-[6px] text-white cursor-pointer focus-ring" style={{ background: "var(--primary)" }}><Play size={11} /> Start</button>}
                    {a.status !== "completed" && a.status !== "cancelled" && <button type="button" onClick={() => toast.info("Reschedule", { description: `Reschedule ${patientName(patient)}` })} className="px-2.5 h-7 text-[11px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-muted)]" style={{ borderColor: "var(--border)" }}>Reschedule</button>}
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>

      <NewAppointmentDialog open={newOpen} onOpenChange={setNewOpen} defaultDate={selectedDate} />
    </div>
  );
}

function NewAppointmentDialog({ open, onOpenChange, defaultDate }: { open: boolean; onOpenChange: (v: boolean) => void; defaultDate: Date }) {
  const patients = useHealthStore((s) => s.patients);
  const providers = useHealthStore((s) => s.providers);
  const [patientId, setPatientId] = useState("");
  const [providerId, setProviderId] = useState("");
  const [time, setTime] = useState("09:00");
  const [duration, setDuration] = useState("30");
  const [visitType, setVisitType] = useState("follow-up");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string>();

  const submit = () => {
    if (!patientId || !providerId) { setError("Patient and provider are required"); return; }
    toast.success("Appointment created", { description: `${patientName(patients.find((p) => p.id === patientId)!)} · ${format(defaultDate, "MMM d")} at ${time}` });
    setPatientId(""); setProviderId(""); setNotes(""); setError(undefined);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent aria-describedby={undefined} className="font-sans max-w-lg p-0 gap-0" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "18px", boxShadow: "var(--shadow-xl)" }}>
        <DialogHeader className="px-5 pt-5 pb-3 border-b" style={{ borderColor: "var(--border)" }}>
          <DialogTitle className="text-base font-semibold">New Appointment</DialogTitle>
          <p className="text-xs text-[var(--foreground-muted)] mt-0.5">{format(defaultDate, "EEEE, MMMM d, yyyy")}</p>
        </DialogHeader>
        <div className="px-5 py-4 space-y-3.5">
          <Field label="Patient" required>
            <select value={patientId} onChange={(e) => { setPatientId(e.target.value); setError(undefined); }} className="w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none cursor-pointer text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>
              <option value="">Select patient…</option>
              {patients.slice(0, 12).map((p) => <option key={p.id} value={p.id}>{patientName(p)} · {p.mrn}</option>)}
            </select>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Provider" required>
              <select value={providerId} onChange={(e) => { setProviderId(e.target.value); setError(undefined); }} className="w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none cursor-pointer text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>
                <option value="">Select…</option>
                {providers.filter((p) => p.role === "physician" || p.role === "specialist").map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
            <Field label="Visit type">
              <select value={visitType} onChange={(e) => setVisitType(e.target.value)} className="w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none cursor-pointer text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>
                {Object.entries(VISIT_TYPE_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Time">
              <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none font-mono text-[var(--foreground)]" style={{ borderColor: "var(--border)" }} />
            </Field>
            <Field label="Duration (min)">
              <select value={duration} onChange={(e) => setDuration(e.target.value)} className="w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none cursor-pointer text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>
                <option value="15">15</option>
                <option value="30">30</option>
                <option value="45">45</option>
                <option value="60">60</option>
              </select>
            </Field>
          </div>
          <Field label="Notes">
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Optional notes…" className="w-full px-3 py-2 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none resize-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]" style={{ borderColor: "var(--border)" }} />
          </Field>
          {error && <p className="text-[11px] text-[var(--critical)]">{error}</p>}
        </div>
        <div className="flex items-center justify-end gap-2 px-5 py-4 border-t" style={{ borderColor: "var(--border)" }}>
          <button type="button" onClick={() => onOpenChange(false)} className="px-3 h-9 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}>Cancel</button>
          <button type="button" onClick={submit} className="px-4 h-9 text-xs font-semibold rounded-[10px] text-white cursor-pointer focus-ring hover:brightness-110" style={{ background: "var(--primary)" }}>Create appointment</button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[var(--foreground)] mb-1.5">{label}{required && <span className="text-[var(--critical)] ml-0.5">*</span>}</label>
      {children}
    </div>
  );
}
