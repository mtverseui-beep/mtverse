"use client";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Phone, MessageSquare, Activity, Pill, ClipboardList, LayoutDashboard, Plus } from "lucide-react";
import { useHealthStore } from "@/store/health-store";
import { Avatar } from "./Avatar";
import { OverviewTab } from "./panel/OverviewTab";
import { VitalsTab } from "./panel/VitalsTab";
import { MedicationsTab } from "./panel/MedicationsTab";
import { TimelineTab } from "./panel/TimelineTab";
import { CallDialog, MessageDialog } from "./CallMessageDialogs";
import { patientName, fmtAge, fmtDate } from "@/lib/health/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Patient } from "@/lib/health/types";

const TABS = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "vitals", label: "Vitals Trend", icon: Activity },
  { id: "medications", label: "Medications", icon: Pill },
  { id: "timeline", label: "Visit Timeline", icon: ClipboardList },
] as const;

export function PatientPanel() {
  const panelOpen = useHealthStore((s) => s.panelOpen);
  const selectedPatientId = useHealthStore((s) => s.selectedPatientId);
  const panelTab = useHealthStore((s) => s.panelTab);
  const setPanelTab = useHealthStore((s) => s.setPanelTab);
  const setPanelOpen = useHealthStore((s) => s.setPanelOpen);
  const patients = useHealthStore((s) => s.patients);
  const [callOpen, setCallOpen] = useState(false);
  const [messageOpen, setMessageOpen] = useState(false);

  const patient = patients.find((p) => p.id === selectedPatientId) ?? null;

  // Escape closes panel
  useEffect(() => {
    if (!panelOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPanelOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [panelOpen, setPanelOpen]);

  return (
    <AnimatePresence>
      {panelOpen && patient && (
        <>
          {/* Overlay for tablet/mobile */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-black/20 lg:hidden"
            onClick={() => setPanelOpen(false)}
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="fixed lg:absolute right-0 top-0 bottom-0 z-50 w-full sm:w-[420px] flex flex-col bg-[var(--surface)] border-l"
            style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-xl)" }}
            role="complementary"
            aria-label={`Patient chart for ${patientName(patient)}`}
          >
            {/* Header */}
            <header className="px-5 py-4 border-b" style={{ borderColor: "var(--border)" }}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar seed={patient.avatarSeed} name={patientName(patient)} size={48} ring />
                  <div className="min-w-0">
                    <h2 className="text-base font-semibold text-[var(--foreground)] truncate">{patientName(patient)}</h2>
                    <div className="flex items-center gap-2 text-[11px] text-[var(--foreground-muted)] font-mono">
                      <span>{patient.mrn}</span>
                      <span>·</span>
                      <span>{fmtAge(patient.dob)}{patient.sex}</span>
                      <span>·</span>
                      <span>{patient.room}</span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-1">
                      <StatusBadge status={patient.status} />
                      <CodeBadge code={patient.codeStatus} />
                      {patient.isolation !== "NONE" && <IsolationBadge isolation={patient.isolation} />}
                    </div>
                  </div>
                </div>
                <button type="button" onClick={() => setPanelOpen(false)} className="w-8 h-8 rounded-[8px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring shrink-0" aria-label="Close panel">
                  <X size={18} />
                </button>
              </div>
              {/* Quick actions */}
              <div className="flex items-center gap-1.5 mt-3">
                <button type="button" onClick={() => setCallOpen(true)} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-medium rounded-[8px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}>
                  <Phone size={13} /> Call
                </button>
                <button type="button" onClick={() => setMessageOpen(true)} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-medium rounded-[8px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}>
                  <MessageSquare size={13} /> Message
                </button>
              </div>
            </header>

            {/* Tabs */}
            <nav className="flex items-center border-b px-2" style={{ borderColor: "var(--border)" }} role="tablist" aria-label="Patient chart sections">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                const active = panelTab === tab.id;
                return (
                  <button key={tab.id} type="button" role="tab" aria-selected={active} tabIndex={active ? 0 : -1} onClick={() => setPanelTab(tab.id)} className={cn("relative flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium transition-colors focus-ring cursor-pointer", active ? "text-[var(--primary)]" : "text-[var(--foreground-muted)] hover:text-[var(--foreground)]")}>
                    <Icon size={14} />
                    <span className="hidden sm:inline">{tab.label}</span>
                    {active && <motion.span layoutId="panel-tab-active" className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full" style={{ background: "var(--primary)" }} transition={{ type: "spring", stiffness: 500, damping: 30 }} />}
                  </button>
                );
              })}
            </nav>

            {/* Content */}
            <div className="flex-1 overflow-y-auto" role="tabpanel">
              {panelTab === "overview" && <OverviewTab patientId={patient.id} />}
              {panelTab === "vitals" && <VitalsTab patientId={patient.id} />}
              {panelTab === "medications" && <MedicationsTab patientId={patient.id} />}
              {panelTab === "timeline" && <TimelineTab patientId={patient.id} />}
            </div>
          </motion.aside>
          <CallDialog patient={patient} open={callOpen} onOpenChange={setCallOpen} />
          <MessageDialog patient={patient} open={messageOpen} onOpenChange={setMessageOpen} />
        </>
      )}
    </AnimatePresence>
  );
}

function StatusBadge({ status }: { status: "stable" | "watch" | "critical" }) {
  const styles = {
    stable: { bg: "var(--success-soft)", color: "var(--success)" },
    watch: { bg: "var(--warning-soft)", color: "var(--warning)" },
    critical: { bg: "var(--critical-soft)", color: "var(--critical)" },
  }[status];
  return <span className={cn("text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wide", status === "critical" && "critical-pulse")} style={{ background: styles.bg, color: styles.color }}>{status}</span>;
}
function CodeBadge({ code }: { code: string }) {
  if (code === "FULL") return null;
  return <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wide" style={{ background: "var(--info-soft)", color: "var(--info)" }}>{code}</span>;
}
function IsolationBadge({ isolation }: { isolation: string }) {
  return <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wide" style={{ background: "var(--warning-soft)", color: "var(--warning)" }}>{isolation}</span>;
}
