"use client";
import { useState, useEffect } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, PhoneOff, MessageSquare, Send, X, User } from "lucide-react";
import { Avatar } from "./Avatar";
import { patientName } from "@/lib/health/format";
import { Button } from "./Button";
import { Field, Textarea } from "./Field";
import { toast } from "sonner";
import type { Patient } from "@/lib/health/types";

// ---------- Call Dialog ----------
export function CallDialog({ patient, open, onOpenChange }: { patient: Patient | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  const [callState, setCallState] = useState<"dialing" | "connected" | "ended">("dialing");
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    if (!open) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setCallState("dialing");
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setDuration(0);
      return;
    }
    const dialTimer = setTimeout(() => setCallState("connected"), 2500);
    return () => clearTimeout(dialTimer);
  }, [open]);

  useEffect(() => {
    if (callState !== "connected") return;
    const id = setInterval(() => setDuration((d) => d + 1), 1000);
    return () => clearInterval(id);
  }, [callState]);

  if (!patient) return null;
  const fmtDur = `${String(Math.floor(duration / 60)).padStart(2, "0")}:${String(duration % 60).padStart(2, "0")}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent aria-describedby={undefined} className="font-sans max-w-sm p-0 gap-0" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "18px", boxShadow: "var(--shadow-xl)" }}>
        <DialogHeader className="px-5 pt-5 pb-3 sr-only">
          <DialogTitle>Call patient</DialogTitle>
        </DialogHeader>
        <div className="p-8 flex flex-col items-center text-center">
          <div className="relative mb-4">
            <Avatar seed={patient.avatarSeed} name={patientName(patient)} size={80} ring />
            {callState === "dialing" && (
              <motion.span
                className="absolute inset-0 rounded-full border-2"
                style={{ borderColor: "var(--primary)" }}
                animate={{ scale: [1, 1.3], opacity: [0.8, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
              />
            )}
          </div>
          <h3 className="text-base font-semibold">{patientName(patient)}</h3>
          <p className="text-xs text-[var(--foreground-muted)] mt-1 font-mono">{patient.phone}</p>
          <p className="text-[11px] text-[var(--foreground-muted)] mt-1">{patient.room} · {patient.mrn}</p>

          <div className="mt-4 h-6 flex items-center justify-center">
            {callState === "dialing" && (
              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-sm font-medium" style={{ color: "var(--primary)" }}>
                Dialing…
              </motion.p>
            )}
            {callState === "connected" && (
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full" style={{ background: "var(--success)" }} />
                <span className="text-sm font-mono font-semibold" style={{ color: "var(--success)" }}>{fmtDur}</span>
              </div>
            )}
            {callState === "ended" && <p className="text-sm font-medium text-[var(--foreground-muted)]">Call ended · {fmtDur}</p>}
          </div>

          <div className="flex items-center gap-3 mt-6">
            {callState !== "ended" && (
              <button
                type="button"
                onClick={() => { setCallState("ended"); setTimeout(() => onOpenChange(false), 1500); }}
                className="w-14 h-14 rounded-full flex items-center justify-center text-white cursor-pointer focus-ring transition-transform hover:scale-105"
                style={{ background: "var(--critical)", boxShadow: "var(--shadow-md)" }}
                aria-label="End call"
              >
                <PhoneOff size={22} />
              </button>
            )}
            {callState === "ended" && (
              <Button variant="primary" size="md" onClick={() => onOpenChange(false)}>Close</Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ---------- Message Dialog ----------
export function MessageDialog({ patient, open, onOpenChange }: { patient: Patient | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (!open) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setMessage("");
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setSent(false);
    }
  }, [open]);

  if (!patient) return null;
  const send = () => {
    if (!message.trim()) { toast.error("Message cannot be empty"); return; }
    setSent(true);
    toast.success("Message sent", { description: `Secure message to ${patient.lastName}'s care team` });
    setTimeout(() => onOpenChange(false), 1500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent aria-describedby={undefined} className="font-sans max-w-lg p-0 gap-0" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "18px", boxShadow: "var(--shadow-xl)" }}>
        <DialogHeader className="px-5 pt-5 pb-3 border-b" style={{ borderColor: "var(--border)" }}>
          <DialogTitle className="text-base font-semibold flex items-center gap-2">
            <MessageSquare size={18} style={{ color: "var(--primary)" }} />
            Secure Message
          </DialogTitle>
        </DialogHeader>
        <div className="px-5 py-4 space-y-4">
          <div className="flex items-center gap-3 p-3 rounded-[10px]" style={{ background: "var(--surface-subtle)" }}>
            <Avatar seed={patient.avatarSeed} name={patientName(patient)} size={40} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">{patientName(patient)}</p>
              <p className="text-[11px] text-[var(--foreground-muted)] font-mono">{patient.mrn} · {patient.room}</p>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>Care team</span>
          </div>
          <Field label="Message" required>
            <Textarea
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={`Send a secure message to ${patient.lastName}'s care team regarding clinical care, orders, or coordination…`}
              disabled={sent}
            />
          </Field>
          {sent && (
            <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 p-3 rounded-[10px]" style={{ background: "var(--success-soft)" }}>
              <Send size={14} style={{ color: "var(--success)" }} />
              <span className="text-xs font-medium" style={{ color: "var(--success)" }}>Message delivered to care team</span>
            </motion.div>
          )}
        </div>
        <div className="flex items-center justify-end gap-2 px-5 py-4 border-t" style={{ borderColor: "var(--border)" }}>
          <button type="button" onClick={() => onOpenChange(false)} className="flex items-center gap-1.5 px-3 h-9 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><X size={14} /> Cancel</button>
          <Button variant="primary" size="md" icon={Send} onClick={send} loading={sent} disabled={sent}>{sent ? "Sent" : "Send message"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
