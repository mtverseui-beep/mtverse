"use client";
import { useMemo, useState } from "react";
import { ResponsiveLine } from "@nivo/line";
import { ResponsiveBar } from "@nivo/bar";
import { Download, FileText, TrendingUp, TrendingDown, Activity, BedDouble, Pill, CalendarCheck, RotateCcw, AlertTriangle } from "lucide-react";
import { useHealthStore } from "@/store/health-store";
import { NOW } from "@/lib/health/format";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const RANGES = [
  { key: "7d", label: "7 days" },
  { key: "30d", label: "30 days" },
  { key: "90d", label: "90 days" },
] as const;

export function ReportsPage() {
  const patients = useHealthStore((s) => s.patients);
  const appointments = useHealthStore((s) => s.appointments);
  const medications = useHealthStore((s) => s.medications);
  const tasks = useHealthStore((s) => s.tasks);
  const [range, setRange] = useState<(typeof RANGES)[number]["key"]>("30d");

  const stats = useMemo(() => {
    const critical = patients.filter((p) => p.status === "critical").length;
    const losTotal = patients.reduce((a, p) => a + (NOW - new Date(p.admitDate).getTime()) / 86400000, 0);
    const avgLos = (losTotal / patients.length).toFixed(1);
    const medCompliance = medications.filter((m) => m.status === "administered").length;
    const medTotal = medications.filter((m) => m.status !== "held" && m.status !== "cancelled").length;
    const medRate = medTotal > 0 ? Math.round((medCompliance / medTotal) * 100) : 0;
    const apptCompleted = appointments.filter((a) => a.status === "completed").length;
    const apptTotal = appointments.length;
    const apptRate = apptTotal > 0 ? Math.round((apptCompleted / apptTotal) * 100) : 0;
    const highRisk = patients.filter((p) => p.riskScore > 70).length;
    return { critical, avgLos, medRate, apptRate, apptCompleted, apptTotal, highRisk, medCompliance, medTotal };
  }, [patients, appointments, medications]);

  // Trend data — admissions/discharges over time
  const trendData = useMemo(() => {
    const days = range === "7d" ? 7 : range === "30d" ? 30 : 90;
    const today = new Date(NOW);
    const adm: { x: number; y: number }[] = [];
    const dis: { x: number; y: number }[] = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(today); d.setDate(d.getDate() - i);
      const ts = d.getTime();
      adm.push({ x: ts, y: Math.floor(3 + Math.sin(i / 3) * 2 + Math.random() * 3) });
      dis.push({ x: ts, y: Math.floor(2 + Math.cos(i / 4) * 1.5 + Math.random() * 2) });
    }
    return [
      { id: "Admissions", color: "var(--primary)", data: adm },
      { id: "Discharges", color: "var(--secondary)", data: dis },
    ];
  }, [range]);

  // Status distribution
  const statusData = useMemo(() => {
    const stable = patients.filter((p) => p.status === "stable").length;
    const watch = patients.filter((p) => p.status === "watch").length;
    const critical = patients.filter((p) => p.status === "critical").length;
    return [
      { id: "Stable", value: stable, color: "var(--success)" },
      { id: "Watch", value: watch, color: "var(--warning)" },
      { id: "Critical", value: critical, color: "var(--critical)" },
    ];
  }, [patients]);

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-[var(--foreground)] tracking-tight">Reports &amp; Analytics</h1>
          <p className="text-sm text-[var(--foreground-muted)] mt-1">Clinical outcomes and operational metrics</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-[10px] border overflow-hidden" style={{ borderColor: "var(--border)" }}>
            {RANGES.map((r) => (
              <button key={r.key} type="button" onClick={() => setRange(r.key)} className={cn("px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer focus-ring", range === r.key ? "text-white" : "text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]")} style={range === r.key ? { background: "var(--primary)" } : undefined}>{r.label}</button>
            ))}
          </div>
          <button type="button" onClick={() => toast.success("CSV exported", { description: "Report data downloaded" })} className="flex items-center gap-1.5 px-3 h-8 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><Download size={13} /> CSV</button>
          <button type="button" onClick={() => toast.success("PDF generated", { description: "Report PDF downloaded" })} className="flex items-center gap-1.5 px-3 h-8 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><FileText size={13} /> PDF</button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={BedDouble} label="Avg length of stay" value={`${stats.avgLos} days`} delta="-0.3d" trend="down" good />
        <StatCard icon={AlertTriangle} label="Critical patients" value={String(stats.critical)} delta="+2" trend="up" bad />
        <StatCard icon={Pill} label="Medication compliance" value={`${stats.medRate}%`} delta="+4%" trend="up" good />
        <StatCard icon={CalendarCheck} label="Appointment completion" value={`${stats.apptRate}%`} delta="+1%" trend="up" good />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Admissions/Discharges trend */}
        <div className="lg:col-span-2 rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
          <h3 className="text-sm font-semibold text-[var(--foreground)] mb-1">Admissions &amp; Discharges</h3>
          <p className="text-[11px] text-[var(--foreground-muted)] mb-4">Daily counts over selected period</p>
          <div style={{ height: 260 }}>
            <ResponsiveLine
              data={trendData}
              margin={{ top: 8, right: 12, bottom: 28, left: 36 }}
              xScale={{ type: "linear" }}
              yScale={{ type: "linear", min: 0, max: "auto" }}
              axisBottom={{ format: (v) => new Date(v).toLocaleDateString("en-US", { month: "short", day: "numeric" }), tickSize: 0, tickPadding: 8 }}
              axisLeft={{ tickSize: 0, tickPadding: 8 }}
              enablePoints={false}
              enableSlices="x"
              useMesh
              lineWidth={2}
              theme={{
                background: "transparent",
                text: { fill: "var(--foreground-muted)", fontSize: 10 },
                axis: { ticks: { text: { fill: "var(--foreground-muted)" } } },
                grid: { line: { stroke: "var(--border)", strokeDasharray: "2 4" } },
                crosshair: { line: { stroke: "var(--border-strong)", strokeWidth: 1, strokeDasharray: "3 3" } },
              }}
              colors={{ datum: "color" }}
              sliceTooltip={({ slice }) => (
                <div className="rounded-[10px] border p-2.5 text-xs" style={{ background: "var(--popover)", borderColor: "var(--border)", boxShadow: "var(--shadow-lg)" }}>
                  <div className="font-mono text-[10px] text-[var(--foreground-muted)] mb-1.5">{new Date(slice.points[0].data.x as number).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</div>
                  {slice.points.map((p) => (
                    <div key={p.id} className="flex items-center gap-2 py-0.5">
                      <span className="w-2 h-2 rounded-full" style={{ background: p.seriesColor }} />
                      <span className="text-[var(--foreground-secondary)]">{p.seriesId}</span>
                      <span className="font-mono font-semibold ml-auto">{p.data.y as number}</span>
                    </div>
                  ))}
                </div>
              )}
            />
          </div>
        </div>

        {/* Patient status distribution */}
        <div className="rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
          <h3 className="text-sm font-semibold text-[var(--foreground)] mb-1">Patient Status</h3>
          <p className="text-[11px] text-[var(--foreground-muted)] mb-4">Current distribution</p>
          <div style={{ height: 200 }}>
            <ResponsiveBar
              data={statusData}
              keys={["value"]}
              indexBy="id"
              layout="horizontal"
              margin={{ top: 4, right: 12, bottom: 4, left: 56 }}
              padding={0.3}
              borderRadius={6}
              colors={({ data }) => data.color}
              enableGridX
              enableGridY={false}
              axisLeft={{ tickSize: 0, tickPadding: 8 }}
              axisBottom={null}
              theme={{
                background: "transparent",
                text: { fill: "var(--foreground-muted)", fontSize: 11 },
                axis: { ticks: { text: { fill: "var(--foreground-secondary)" } } },
                grid: { line: { stroke: "var(--border)" } },
              }}
              labelSkipWidth={36}
              labelTextColor="white"
              label={({ value }) => String(value)}
              isInteractive={false}
            />
          </div>
        </div>
      </div>

      {/* Additional metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <MetricCard icon={RotateCcw} title="Readmission risk" value={`${Math.round((stats.highRisk / patients.length) * 100)}%`} subtitle={`${stats.highRisk} high-risk patients`} />
        <MetricCard icon={Activity} title="Total admissions" value={String(patients.length)} subtitle="Currently admitted" />
        <MetricCard icon={Pill} title="Medications administered" value={String(stats.medCompliance)} subtitle={`of ${stats.medTotal} scheduled`} />
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, delta, trend, good, bad }: { icon: React.ComponentType<{ size?: number }>; label: string; value: string; delta: string; trend: "up" | "down"; good?: boolean; bad?: boolean }) {
  const deltaColor = (good && trend === "up") || (bad && trend === "up") ? (bad ? "var(--critical)" : "var(--success)") : trend === "down" && bad ? "var(--success)" : "var(--foreground-muted)";
  return (
    <div className="rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-wider font-medium text-[var(--foreground-muted)]">{label}</p>
          <p className="text-2xl font-bold font-mono text-[var(--foreground)] mt-1.5">{value}</p>
        </div>
        <div className="w-9 h-9 rounded-[10px] flex items-center justify-center" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>
          <Icon size={18} />
        </div>
      </div>
      <div className="flex items-center gap-1 mt-2 text-xs font-mono" style={{ color: deltaColor }}>
        {trend === "up" ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
        <span>{delta}</span>
        <span className="text-[var(--foreground-muted)] ml-1">vs last period</span>
      </div>
    </div>
  );
}

function MetricCard({ icon: Icon, title, value, subtitle }: { icon: React.ComponentType<{ size?: number }>; title: string; value: string; subtitle: string }) {
  return (
    <div className="rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-[8px] flex items-center justify-center" style={{ background: "var(--surface-hover)", color: "var(--foreground-muted)" }}>
          <Icon size={16} />
        </div>
        <h4 className="text-sm font-semibold text-[var(--foreground)]">{title}</h4>
      </div>
      <p className="text-2xl font-bold font-mono text-[var(--foreground)]">{value}</p>
      <p className="text-[11px] text-[var(--foreground-muted)] mt-1">{subtitle}</p>
    </div>
  );
}
