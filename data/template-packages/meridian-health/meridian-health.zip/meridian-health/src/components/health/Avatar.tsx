"use client";
import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";

interface AvatarProps {
  seed: string;
  name: string;
  size?: number;
  className?: string;
  ring?: boolean;
}

export function Avatar({ seed, name, size = 36, className, ring }: AvatarProps) {
  const [errored, setErrored] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const id = useMemo(() => {
    let h = 0;
    for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
    return (h % 70) + 1;
  }, [seed]);
  const init = name.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0]).join("").toUpperCase();
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setErrored(false);
    setLoaded(false);
  }, [seed]);
  return (
    <span
      className={cn("relative inline-flex items-center justify-center overflow-hidden shrink-0", className)}
      style={{
        width: size, height: size, borderRadius: "50%",
        background: "linear-gradient(135deg, var(--primary), var(--primary-hover))",
        boxShadow: ring ? "0 0 0 2px var(--surface), 0 0 0 3px var(--primary)" : undefined,
      }}
    >
      {!loaded && (
        <span className="absolute inset-0 flex items-center justify-center font-semibold text-white" style={{ fontSize: size * 0.36 }}>
          {init}
        </span>
      )}
      {!errored && (
        <img
          src={`https://i.pravatar.cc/${size * 2}?img=${id}`}
          alt={name}
          width={size}
          height={size}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          onError={() => setErrored(true)}
          className={cn("absolute inset-0 w-full h-full object-cover transition-opacity duration-200", loaded ? "opacity-100" : "opacity-0")}
        />
      )}
    </span>
  );
}
