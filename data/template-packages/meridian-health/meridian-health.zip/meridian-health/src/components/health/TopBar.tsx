"use client";
import { useEffect, useState } from "react";
import { Search, Bell, Zap, Menu } from "lucide-react";
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from "@/components/ui/tooltip";
import { useHealthStore } from "@/store/health-store";
import { BrandMark } from "./BrandMark";
import { PatientSearch } from "./PatientSearch";
import { TaskInboxDropdown } from "./TaskInboxDropdown";
import { NotificationsDropdown } from "./NotificationsDropdown";
import { ProfileDropdown } from "./ProfileDropdown";
import { ThemeToggle } from "./ThemeToggle";
import type { Route } from "@/hooks/use-hash-route";

const ROUTE_LABELS: Record<string, string> = {
  dashboard: "Dashboard", patients: "Patients", appointments: "Appointments",
  "care-team": "Care Team", reports: "Reports", settings: "Settings", profile: "My Profile",
  account: "Account", appearance: "Appearance", notifications: "Notifications", security: "Security",
};

interface TopBarProps {
  route: Route;
  onOpenCommand: () => void;
  onToggleSidebar: () => void;
}

export function TopBar({ route, onOpenCommand, onToggleSidebar }: TopBarProps) {
  const [now, setNow] = useState<string | null>(null);

  useEffect(() => {
    const tick = () => setNow(new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }));
    tick();
    const id = setInterval(tick, 30000);
    return () => clearInterval(id);
  }, []);

  const crumbs = route.segments.map((s) => ROUTE_LABELS[s] ?? s.charAt(0).toUpperCase() + s.slice(1));

  return (
    <TooltipProvider delayDuration={200}>
      <header
        className="h-[72px] flex items-center px-4 gap-3 border-b glass sticky top-0 z-40"
        style={{ borderColor: "var(--border)" }}
        role="banner"
      >
        <button type="button" onClick={onToggleSidebar} className="lg:hidden w-10 h-10 rounded-[10px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label="Toggle sidebar">
          <Menu size={20} />
        </button>

        <div className="hidden lg:flex items-center gap-2 text-sm shrink-0">
          <span className="text-[var(--foreground-muted)]">Meridian Health</span>
          {crumbs.map((c, i) => (
            <span key={i} className="flex items-center gap-2">
              <span className="text-[var(--border-strong)]">/</span>
              <span className={i === crumbs.length - 1 ? "text-[var(--foreground)] font-semibold" : "text-[var(--foreground-muted)]"}>{c}</span>
            </span>
          ))}
        </div>

        <div className="hidden md:block w-px h-8 mx-1" style={{ background: "var(--border)" }} />

        <PatientSearch />

        <div className="flex items-center gap-1 shrink-0">
          {now && (
            <div className="hidden xl:flex flex-col items-end mr-2 leading-none">
              <span className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">Shift time</span>
              <span className="text-sm font-mono font-semibold text-[var(--foreground)]">{now}</span>
            </div>
          )}
          <TaskInboxDropdown />
          <Tooltip>
            <TooltipTrigger asChild>
              <button type="button" aria-label="Quick actions" className="w-10 h-10 rounded-[10px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--primary)] hover:bg-[var(--primary-soft)] transition-colors focus-ring cursor-pointer">
                <Zap size={18} />
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="font-sans text-xs" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)" }}>Quick actions</TooltipContent>
          </Tooltip>
          <NotificationsDropdown />
          <ThemeToggle />
          <ProfileDropdown />
        </div>
      </header>
    </TooltipProvider>
  );
}
