"use client";
import { forwardRef } from "react";
import { cn } from "@/lib/utils";
import { AlertCircle } from "lucide-react";

export function Field({ label, description, error, required, children, className, htmlFor }: { label?: string; description?: string; error?: string; required?: boolean; children: React.ReactNode; className?: string; htmlFor?: string }) {
  return (
    <div className={cn("space-y-1.5", className)}>
      {label && <label htmlFor={htmlFor} className="block text-xs font-medium text-[var(--foreground)]">{label}{required && <span className="text-[var(--critical)] ml-0.5">*</span>}</label>}
      {children}
      {description && !error && <p className="text-[11px] text-[var(--foreground-muted)] leading-relaxed">{description}</p>}
      {error && <p className="text-[11px] text-[var(--critical)] flex items-center gap-1"><AlertCircle size={11} />{error}</p>}
    </div>
  );
}

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  invalid?: boolean;
  leading?: React.ReactNode;
  trailing?: React.ReactNode;
}
export const Input = forwardRef<HTMLInputElement, InputProps>(({ className, invalid, leading, trailing, ...props }, ref) => (
  <div className="relative">
    {leading && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none">{leading}</span>}
    <input ref={ref} className={cn("w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none transition-colors hover:border-[var(--border-strong)] text-[var(--foreground)] placeholder:text-[var(--foreground-muted)] font-sans", leading && "pl-9", trailing && "pr-16", invalid && "border-[var(--critical)]", className)} style={{ borderColor: invalid ? "var(--critical)" : "var(--border)" }} {...props} />
    {trailing && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] text-[10px] cursor-pointer">{trailing}</span>}
  </div>
));
Input.displayName = "Input";

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  invalid?: boolean;
}
export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(({ className, invalid, ...props }, ref) => (
  <textarea ref={ref} className={cn("w-full px-3 py-2 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none transition-colors hover:border-[var(--border-strong)] resize-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)] leading-relaxed", invalid && "border-[var(--critical)]", className)} style={{ borderColor: invalid ? "var(--critical)" : "var(--border)" }} {...props} />
));
Textarea.displayName = "Textarea";
