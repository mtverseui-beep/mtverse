"use client";
import { useState, useEffect } from "react";
import { TopBar } from "./TopBar";
import { Sidebar } from "./Sidebar";
import { PatientPanel } from "./PatientPanel";
import { DashboardPage } from "./pages/DashboardPage";
import { RosterPage } from "./pages/RosterPage";
import { SchedulePage } from "./pages/SchedulePage";
import { CareTeamPage } from "./pages/CareTeamPage";
import { ReportsPage } from "./pages/ReportsPage";
import { SettingsPage } from "./pages/SettingsPage";
import { ProfilePage } from "./pages/ProfilePage";
import { HelpPage } from "./pages/HelpPage";
import { useHashRoute } from "@/hooks/use-hash-route";
import { ScrollArea } from "@/components/ui/scroll-area";

export function HealthApp() {
  const [route, navigate] = useHashRoute();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
    const stored = localStorage.getItem("meridian-health-sidebar");
    if (stored === "collapsed") setCollapsed(true);
  }, []);

  const toggleCollapse = () => {
    const next = !collapsed;
    setCollapsed(next);
    localStorage.setItem("meridian-health-sidebar", next ? "collapsed" : "expanded");
  };

  const top = route.segments[0] ?? "dashboard";

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--background)" }}>
        <div className="flex flex-col items-center gap-4">
          <img src="/icon.svg" alt="Meridian Health" width={48} height={48} />
          <span className="text-xs text-[var(--foreground-muted)] font-mono">Loading…</span>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex overflow-hidden" style={{ background: "var(--background)" }}>
      {/* Desktop sidebar */}
      <div className="hidden lg:block h-full">
        <Sidebar route={route} navigate={navigate} collapsed={collapsed} onToggleCollapse={toggleCollapse} />
      </div>

      {/* Mobile sidebar drawer */}
      {mobileSidebarOpen && (
        <>
          <div className="fixed inset-0 z-50 bg-black/40 lg:hidden" onClick={() => setMobileSidebarOpen(false)} />
          <div className="fixed left-0 top-0 bottom-0 z-50 lg:hidden">
            <Sidebar route={route} navigate={(p) => { navigate(p); setMobileSidebarOpen(false); }} collapsed={false} onToggleCollapse={() => setMobileSidebarOpen(false)} />
          </div>
        </>
      )}

      {/* Main column */}
      <div className="flex flex-col flex-1 min-w-0">
        <TopBar route={route} onOpenCommand={() => {}} onToggleSidebar={() => setMobileSidebarOpen(true)} />
        <main className="flex-1 overflow-hidden relative">
          <ScrollArea className="h-full">
            {top === "dashboard" && <DashboardPage navigate={navigate} />}
            {top === "patients" && <RosterPage />}
            {top === "appointments" && <SchedulePage />}
            {top === "care-team" && <CareTeamPage />}
            {top === "reports" && <ReportsPage />}
            {top === "settings" && <SettingsPage route={route} navigate={navigate} />}
            {top === "profile" && <ProfilePage navigate={navigate} />}
            {top === "help" && <HelpPage />}
          </ScrollArea>
          <PatientPanel />
        </main>
      </div>
    </div>
  );
}
