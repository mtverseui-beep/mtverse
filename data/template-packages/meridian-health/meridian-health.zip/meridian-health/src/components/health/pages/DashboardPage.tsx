"use client";
import { motion } from "framer-motion";
import {
  Users, AlertTriangle, Activity, CalendarClock, CheckCircle2, Clock,
  BedDouble, TrendingUp, TrendingDown, ArrowRight, Pill, FlaskConical,
} from "lucide-react";
import { useHealthStore } from "@/store/health-store";
import { Avatar } from "../Avatar";
import { patientName, fmtRelative, fmtTime } from "@/lib/health/format";
import { cn } from "@/lib/utils";
import type { Route } from "@/hooks/use-hash-route";

interface DashboardPageProps {
  navigate: (path: string) => void;
}

export function DashboardPage({ navigate }: DashboardPageProps) {
  const patients = useHealthStore((s) => s.patients);
  const appointments = useHealthStore((s) => s.appointments);
  const tasks = useHealthStore((s) => s.tasks);
  const alerts = useHealthStore((s) => s.alerts);
  const medications = useHealthStore((s) => s.medications);
  const providers = useHealthStore((s) => s.providers);
  const selectPatient = useHealthStore((s) => s.selectPatient);

  const critical = patients.filter((p) => p.status === "critical");
  const watch = patients.filter((p) => p.status === "watch");
  const stable = patients.filter((p) => p.status === "stable");
  const todayAppts = appointments.slice(0, 5);
  const pendingTasks = tasks.filter((t) => t.status === "pending" || t.status === "overdue").slice(0, 5);
  const criticalAlerts = alerts.filter((a) => a.severity === "critical" && !a.acknowledged).slice(0, 4);
  const overdueMeds = medications.filter((m) => m.status === "overdue").slice(0, 4);
  const onShiftProviders = providers.filter((p) => p.availability === "available" || p.availability === "busy");

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[var(--foreground)] tracking-tight">Welcome back, Dr. Chen</h1>
        <p className="text-sm text-[var(--foreground-muted)] mt-1">You have {critical.length} critical patients, {pendingTasks.length} pending tasks, and {todayAppts.length} appointments today.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total Patients" value={String(patients.length)} sublabel={`${stable.length} stable · ${watch.length} watch`} accent onClick={() => navigate("patients")} />
        <StatCard icon={AlertTriangle} label="Critical" value={String(critical.length)} sublabel="Require attention" critical onClick={() => navigate("patients")} />
        <StatCard icon={CalendarClock} label="Appointments" value={String(todayAppts.length)} sublabel="Scheduled today" onClick={() => navigate("appointments")} />
        <StatCard icon={CheckCircle2} label="Pending Tasks" value={String(pendingTasks.length)} sublabel={`${tasks.filter(t => t.status === "overdue").length} overdue`} warning onClick={() => navigate("patients")} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Critical patients */}
        <div className="lg:col-span-2 space-y-6">
          <Card title="Critical Patients" action={<button type="button" onClick={() => navigate("patients")} className="text-xs font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer flex items-center gap-1">View all <ArrowRight size={12} /></button>}>
            {critical.length === 0 ? (
              <EmptyRow text="No critical patients" />
            ) : (
              <div className="space-y-2">
                {critical.slice(0, 4).map((p) => {
                  const attending = providers.find((pr) => pr.id === p.attendingId);
                  return (
                    <motion.button
                      key={p.id}
                      type="button"
                      whileHover={{ x: 2 }}
                      onClick={() => { selectPatient(p.id); navigate("patients"); }}
                      className="w-full flex items-center gap-3 p-3 rounded-[10px] border text-left cursor-pointer focus-ring transition-colors hover:bg-[var(--surface-hover)]"
                      style={{ borderColor: "var(--border)", background: "var(--critical-soft)" }}
                    >
                      <Avatar seed={p.avatarSeed} name={patientName(p)} size={40} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-[var(--foreground)] truncate">{patientName(p)}</span>
                          <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase critical-pulse" style={{ background: "var(--critical)", color: "white" }}>Critical</span>
                        </div>
                        <p className="text-[11px] text-[var(--foreground-secondary)] truncate">{p.primaryCondition} · {p.room}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-[10px] text-[var(--foreground-muted)]">Risk</p>
                        <p className="text-sm font-mono font-bold" style={{ color: "var(--critical)" }}>{p.riskScore}</p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            )}
          </Card>

          {/* Today's appointments */}
          <Card title="Today's Appointments" action={<button type="button" onClick={() => navigate("appointments")} className="text-xs font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer flex items-center gap-1">View all <ArrowRight size={12} /></button>}>
            {todayAppts.length === 0 ? (
              <EmptyRow text="No appointments today" />
            ) : (
              <div className="space-y-1">
                {todayAppts.map((a) => {
                  const patient = patients.find((p) => p.id === a.patientId);
                  const provider = providers.find((p) => p.id === a.providerId);
                  if (!patient || !provider) return null;
                  return (
                    <div key={a.id} className="flex items-center gap-3 p-2.5 rounded-[8px] hover:bg-[var(--surface-hover)] transition-colors">
                      <div className="flex flex-col items-center justify-center w-14 shrink-0">
                        <span className="text-sm font-mono font-bold text-[var(--foreground)]">{a.startTime}</span>
                        <span className="text-[10px] text-[var(--foreground-muted)]">{a.durationMin}min</span>
                      </div>
                      <div className="w-px h-8" style={{ background: "var(--border)" }} />
                      <Avatar seed={patient.avatarSeed} name={patientName(patient)} size={32} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-[var(--foreground)] truncate">{patientName(patient)}</p>
                        <p className="text-[10px] text-[var(--foreground-muted)] truncate">{provider.name} · {a.room}</p>
                      </div>
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>{a.visitType}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Right column — alerts + tasks + overdue meds */}
        <div className="space-y-6">
          <Card title="Critical Alerts" icon={AlertTriangle} iconColor="var(--critical)">
            {criticalAlerts.length === 0 ? (
              <EmptyRow text="No critical alerts" />
            ) : (
              <div className="space-y-2">
                {criticalAlerts.map((a) => {
                  const patient = patients.find((p) => p.id === a.patientId);
                  return (
                    <div key={a.id} className="flex items-start gap-2 p-2 rounded-[8px]" style={{ background: "var(--critical-soft)" }}>
                      <AlertTriangle size={14} className="shrink-0 mt-0.5 critical-pulse" style={{ color: "var(--critical)" }} />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-[var(--foreground)]">{a.title}</p>
                        <p className="text-[11px] text-[var(--foreground-secondary)]">{a.description}</p>
                        {patient && <p className="text-[10px] text-[var(--foreground-muted)] mt-0.5">{patientName(patient)} · {fmtRelative(a.timestamp)}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          <Card title="Overdue Medications" icon={Pill} iconColor="var(--warning)">
            {overdueMeds.length === 0 ? (
              <EmptyRow text="No overdue medications" />
            ) : (
              <div className="space-y-1.5">
                {overdueMeds.map((m) => {
                  const patient = patients.find((p) => p.id === m.patientId);
                  if (!patient) return null;
                  return (
                    <div key={m.id} className="flex items-center gap-2 p-2 rounded-[8px]" style={{ background: "var(--surface-subtle)" }}>
                      <Pill size={13} className="shrink-0" style={{ color: "var(--warning)" }} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-[var(--foreground)] truncate">{m.name} {m.dose}</p>
                        <p className="text-[10px] text-[var(--foreground-muted)] truncate">{patientName(patient)} · due {fmtRelative(m.nextDue)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          <Card title="On-Shift Team" icon={Activity} iconColor="var(--primary)">
            <div className="space-y-1.5">
              {onShiftProviders.slice(0, 5).map((p) => (
                <div key={p.id} className="flex items-center gap-2 p-1.5 rounded-[8px] hover:bg-[var(--surface-hover)] transition-colors">
                  <div className="relative">
                    <Avatar seed={p.avatarSeed} name={p.name} size={28} />
                    <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2" style={{ background: p.availability === "available" ? "var(--success)" : "var(--warning)", borderColor: "var(--surface)" }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-[var(--foreground)] truncate">{p.name}</p>
                    <p className="text-[10px] text-[var(--foreground-muted)] truncate">{p.specialty}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sublabel, accent, critical, warning, onClick }: { icon: React.ComponentType<{ size?: number; className?: string }>; label: string; value: string; sublabel: string; accent?: boolean; critical?: boolean; warning?: boolean; onClick?: () => void }) {
  const color = critical ? "var(--critical)" : warning ? "var(--warning)" : accent ? "var(--primary)" : "var(--foreground-secondary)";
  const bg = critical ? "var(--critical-soft)" : warning ? "var(--warning-soft)" : accent ? "var(--primary-soft)" : "var(--surface-hover)";
  return (
    <motion.button
      type="button"
      whileHover={{ y: -2 }}
      onClick={onClick}
      className="rounded-[14px] border p-5 bg-[var(--surface)] text-left cursor-pointer focus-ring transition-colors hover:border-[var(--border-strong)]"
      style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-wider font-medium text-[var(--foreground-muted)]">{label}</p>
          <p className="text-3xl font-bold font-mono mt-1.5" style={{ color: critical ? "var(--critical)" : "var(--foreground)" }}>{value}</p>
          <p className="text-[11px] text-[var(--foreground-muted)] mt-1">{sublabel}</p>
        </div>
        <div className="w-10 h-10 rounded-[10px] flex items-center justify-center" style={{ background: bg, color }}>
          <Icon size={18} />
        </div>
      </div>
    </motion.button>
  );
}

function Card({ title, icon: Icon, iconColor, action, children }: { title: string; icon?: React.ComponentType<{ size?: number; style?: React.CSSProperties }>; iconColor?: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="rounded-[14px] border bg-[var(--surface)] overflow-hidden" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
      <header className="flex items-center justify-between px-5 py-3.5 border-b" style={{ borderColor: "var(--border)" }}>
        <div className="flex items-center gap-2">
          {Icon && <Icon size={16} style={{ color: iconColor }} />}
          <h3 className="text-sm font-semibold text-[var(--foreground)]">{title}</h3>
        </div>
        {action}
      </header>
      <div className="p-4">{children}</div>
    </section>
  );
}

function EmptyRow({ text }: { text: string }) {
  return <p className="text-xs text-[var(--foreground-muted)] py-4 text-center">{text}</p>;
}
