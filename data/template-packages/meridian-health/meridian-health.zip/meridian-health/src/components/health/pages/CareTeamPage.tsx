"use client";
import { useHealthStore } from "@/store/health-store";
import { Avatar } from "../Avatar";
import { Phone, MessageSquare, UserPlus, Mail } from "lucide-react";
import { toast } from "sonner";

const ROLE_LABELS: Record<string, string> = {
  physician: "Physician", nurse: "Nurse", specialist: "Specialist",
  pharmacist: "Pharmacist", "care-coordinator": "Care Coordinator",
};
const AVAILABILITY_STYLES = {
  available: { bg: "var(--success-soft)", color: "var(--success)", label: "Available", dot: "var(--success)" },
  busy: { bg: "var(--warning-soft)", color: "var(--warning)", label: "Busy", dot: "var(--warning)" },
  "in-procedure": { bg: "var(--critical-soft)", color: "var(--critical)", label: "In procedure", dot: "var(--critical)" },
  "off-shift": { bg: "var(--surface-hover)", color: "var(--foreground-muted)", label: "Off shift", dot: "var(--foreground-muted)" },
} as const;

export function CareTeamPage() {
  const providers = useHealthStore((s) => s.providers);
  const patients = useHealthStore((s) => s.patients);

  const grouped = {
    physician: providers.filter((p) => p.role === "physician"),
    nurse: providers.filter((p) => p.role === "nurse"),
    specialist: providers.filter((p) => p.role === "specialist"),
    pharmacist: providers.filter((p) => p.role === "pharmacist"),
    "care-coordinator": providers.filter((p) => p.role === "care-coordinator"),
  };

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-[var(--foreground)] tracking-tight">Care Team</h1>
          <p className="text-sm text-[var(--foreground-muted)] mt-1">{providers.length} team members across all departments</p>
        </div>
        <button type="button" onClick={() => toast.info("Assign patient", { description: "Patient assignment form would open" })} className="flex items-center gap-1.5 px-4 h-9 text-sm font-semibold rounded-[10px] text-white cursor-pointer focus-ring hover:brightness-110" style={{ background: "var(--primary)" }}>
          <UserPlus size={15} /> Assign patient
        </button>
      </div>

      {Object.entries(grouped).map(([role, members]) => members.length > 0 && (
        <section key={role} className="mb-8">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-[var(--foreground-muted)] mb-3">{ROLE_LABELS[role]} ({members.length})</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {members.map((p) => {
              const avail = AVAILABILITY_STYLES[p.availability];
              const ptCount = patients.filter((pt) => pt.attendingId === p.id || pt.nurseId === p.id).length;
              return (
                <div key={p.id} className="rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
                  <div className="flex items-start gap-3">
                    <div className="relative">
                      <Avatar seed={p.avatarSeed} name={p.name} size={48} ring={p.availability === "available"} />
                      <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2" style={{ background: avail.dot, borderColor: "var(--surface)" }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-[var(--foreground)] truncate">{p.name}</p>
                      <p className="text-[11px] text-[var(--foreground-muted)]">{p.specialty}</p>
                      <span className="inline-flex items-center gap-1 mt-1 text-[10px] px-1.5 py-0.5 rounded-full font-semibold" style={{ background: avail.bg, color: avail.color }}>
                        <span className="w-1.5 h-1.5 rounded-full" style={{ background: avail.dot }} />
                        {avail.label}
                      </span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-4 text-[11px]">
                    <div>
                      <span className="text-[var(--foreground-muted)]">Shift</span>
                      <p className="font-medium text-[var(--foreground)] capitalize">{p.shift}</p>
                    </div>
                    <div>
                      <span className="text-[var(--foreground-muted)]">Patients</span>
                      <p className="font-medium text-[var(--foreground)]">{ptCount} active</p>
                    </div>
                    <div>
                      <span className="text-[var(--foreground-muted)]">Location</span>
                      <p className="font-medium text-[var(--foreground)]">{p.room}</p>
                    </div>
                    <div>
                      <span className="text-[var(--foreground-muted)]">Pager</span>
                      <p className="font-mono font-medium text-[var(--foreground)]">{p.pager}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 mt-4 pt-4 border-t" style={{ borderColor: "var(--border)" }}>
                    <button type="button" onClick={() => toast.success(`Calling ${p.name}`, { description: `${p.phone} · ${p.pager}`, duration: 4000 })} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-medium rounded-[8px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><Phone size={13} /> Call</button>
                    <button type="button" onClick={() => toast.success(`Message sent to ${p.name}`, { description: `Secure message delivered to ${p.email}`, duration: 4000 })} className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-medium rounded-[8px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><MessageSquare size={13} /> Message</button>
                    <button type="button" onClick={() => toast.success(`Email to ${p.name}`, { description: p.email, duration: 4000 })} className="w-8 h-8 flex items-center justify-center rounded-[8px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-muted)]" style={{ borderColor: "var(--border)" }} aria-label="Email"><Mail size={13} /></button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
