"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { HelpCircle, Search, MessageSquare, Book, Video, LifeBuoy, ChevronDown, Send, Mail, Clock, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Field, Input, Textarea } from "../Field";
import { Button } from "../Button";

const FAQ = [
  { q: "How do I add a new patient to the roster?", a: "Patient registration is handled through the ADT system. New admissions appear automatically in the roster within 60 seconds of registration." },
  { q: "How do I administer a medication?", a: "Open the patient's chart, navigate to the Medications tab, find the due medication, and click 'Give'. The MAR is updated immediately and the next due time is calculated." },
  { q: "Can I customize my dashboard?", a: "Yes. Go to Settings → Account to change your default landing page, and Settings → Appearance to adjust theme and density." },
  { q: "How do critical alerts work?", a: "Critical alerts fire automatically when a patient's vitals fall outside safe ranges, a critical lab value results, or a code is called. They appear in the notifications bell with aria-live assertive." },
  { q: "Is the data HIPAA compliant?", a: "All patient data is encrypted in transit (TLS 1.3) and at rest (AES-256). Access is role-based and fully audited. BAA available on request." },
  { q: "How do I contact the on-call pharmacist?", a: "Go to Care Team, filter by Pharmacist role, and use the Call or Message button. The on-call pharmacist is highlighted with a green availability dot." },
];

const RESOURCES = [
  { icon: Book, title: "Clinical Documentation", desc: "Templates and note-writing guides", action: "Read docs" },
  { icon: Video, title: "Training Videos", desc: "Role-based walkthroughs", action: "Watch" },
  { icon: LifeBuoy, title: "System Status", desc: "Real-time uptime and incidents", action: "Check status" },
  { icon: MessageSquare, title: "Clinical IT Support", desc: "24/7 support for clinicians", action: "Contact" },
];

const TICKETS = [
  { id: "T-4821", subject: "Vitals not auto-refreshing on iPad", status: "OPEN", priority: "MEDIUM", updatedAt: "1h ago" },
  { id: "T-4815", subject: "MAR showing wrong time for med administration", status: "RESOLVED", priority: "HIGH", updatedAt: "1d ago" },
  { id: "T-4790", subject: "Cannot export patient list to CSV", status: "RESOLVED", priority: "LOW", updatedAt: "3d ago" },
];

export function HelpPage() {
  const [search, setSearch] = useState("");
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const filtered = FAQ.filter(f => f.q.toLowerCase().includes(search.toLowerCase()) || f.a.toLowerCase().includes(search.toLowerCase()));
  const submit = () => {
    if (!subject.trim() || !message.trim()) { toast.error("Please fill in all fields"); return; }
    setSending(true);
    setTimeout(() => { setSending(false); toast.success("Support ticket created", { description: `Ticket #T-${Math.floor(1000 + Math.random() * 9000)}` }); setSubject(""); setMessage(""); }, 1200);
  };
  return (
    <div className="p-6 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[var(--foreground)] tracking-tight">Help &amp; Support</h1>
        <p className="text-sm text-[var(--foreground-muted)] mt-1">Find answers, browse resources, or contact clinical IT support.</p>
      </div>
      <div className="rounded-[16px] border bg-[var(--surface)] p-6 mb-6 relative overflow-hidden" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
        <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, var(--primary-soft), transparent 70%)" }} />
        <div className="relative">
          <div className="flex items-center gap-2 mb-3"><HelpCircle size={18} style={{ color: "var(--primary)" }} /><h2 className="text-base font-semibold">How can we help?</h2></div>
          <div className="relative max-w-xl"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" /><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search the knowledge base…" className="pl-10 h-11 text-sm" /></div>
        </div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {RESOURCES.map((r) => <motion.button key={r.title} whileHover={{ y: -2 }} onClick={() => toast.info(r.title, { description: r.desc })} className="rounded-[14px] border p-5 text-left cursor-pointer focus-ring bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
          <div className="w-10 h-10 rounded-[10px] flex items-center justify-center mb-3" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}><r.icon size={18} /></div>
          <p className="text-sm font-semibold text-[var(--foreground)]">{r.title}</p>
          <p className="text-[11px] text-[var(--foreground-muted)] mt-1 leading-relaxed">{r.desc}</p>
          <p className="text-[11px] text-[var(--primary)] mt-3 font-medium">{r.action} →</p>
        </motion.button>)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="rounded-[14px] border bg-[var(--surface)] overflow-hidden" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
            <div className="px-5 py-4 border-b" style={{ borderColor: "var(--border)" }}><h3 className="text-sm font-semibold">Frequently asked questions</h3><p className="text-[11px] text-[var(--foreground-muted)] mt-0.5">{filtered.length} articles</p></div>
            <div className="divide-y" style={{ borderColor: "var(--border)" }}>
              <AnimatePresence initial={false}>
                {filtered.map((f, i) => (
                  <motion.div key={i} layout>
                    <button type="button" onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between gap-3 px-5 py-3.5 text-left cursor-pointer hover:bg-[var(--surface-hover)] transition-colors focus-ring">
                      <span className={cn("text-sm", openFaq === i ? "font-semibold text-[var(--primary)]" : "font-medium text-[var(--foreground)]")}>{f.q}</span>
                      <motion.span animate={{ rotate: openFaq === i ? 180 : 0 }} transition={{ duration: 0.15 }}><ChevronDown size={15} className="text-[var(--foreground-muted)] shrink-0" /></motion.span>
                    </button>
                    <AnimatePresence initial={false}>
                      {openFaq === i && <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden"><p className="px-5 pb-4 text-xs text-[var(--foreground-muted)] leading-relaxed">{f.a}</p></motion.div>}
                    </AnimatePresence>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
        <div className="space-y-4">
          <div className="rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
            <div className="flex items-center gap-2 mb-4"><Mail size={16} style={{ color: "var(--primary)" }} /><h3 className="text-sm font-semibold">Contact support</h3></div>
            <div className="space-y-3">
              <Field label="Subject" required><Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Briefly describe your issue" /></Field>
              <Field label="Message" required><Textarea rows={4} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Describe in detail…" /></Field>
              <Button variant="primary" size="md" icon={Send} className="w-full" loading={sending} onClick={submit}>{sending ? "Sending…" : "Submit ticket"}</Button>
              <p className="text-[10px] text-[var(--foreground-muted)] text-center flex items-center justify-center gap-1"><Clock size={10} />Avg response: 2 hours</p>
            </div>
          </div>
          <div className="rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
            <h3 className="text-sm font-semibold mb-3">Your tickets</h3>
            <div className="space-y-2">
              {TICKETS.map((t) => (
                <div key={t.id} className="flex items-center gap-3 px-3 py-2 rounded-[8px] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer">
                  <div className="w-7 h-7 rounded-[6px] flex items-center justify-center shrink-0" style={{ background: t.status === "RESOLVED" ? "var(--success-soft)" : "var(--warning-soft)", color: t.status === "RESOLVED" ? "var(--success)" : "var(--warning)" }}>{t.status === "RESOLVED" ? <CheckCircle2 size={13} /> : <Clock size={13} />}</div>
                  <div className="flex-1 min-w-0"><p className="text-xs font-medium text-[var(--foreground)] truncate">{t.subject}</p><p className="text-[10px] text-[var(--foreground-muted)] font-mono">{t.id} · {t.updatedAt}</p></div>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: t.priority === "HIGH" ? "var(--critical-soft)" : "var(--surface-hover)", color: t.priority === "HIGH" ? "var(--critical)" : "var(--foreground-muted)" }}>{t.priority}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
