"use client";
import { useMemo, useRef, useState, useEffect } from "react";
import {
  flexRender, getCoreRowModel, getFilteredRowModel, getSortedRowModel, getPaginationRowModel,
  useReactTable, type ColumnDef, type SortingState, type RowSelectionState, type VisibilityState,
} from "@tanstack/react-table";
import {
  Search, ChevronUp, ChevronDown, ChevronsUpDown, ChevronLeft, ChevronRight,
  Settings2, Download, Printer, Rows3, Rows4, MoreHorizontal, Phone, MessageSquare, Eye,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import { useHealthStore } from "@/store/health-store";
import { Avatar } from "./Avatar";
import { RiskRadial } from "./RiskRadial";
import { patientName, fmtAge, fmtRelative } from "@/lib/health/format";
import { VITAL_RANGES, isVitalOutOfRange } from "@/lib/health/types";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Patient } from "@/lib/health/types";

const STATUS_STYLES = {
  stable: { bg: "var(--success-soft)", color: "var(--success)", label: "Stable" },
  watch: { bg: "var(--warning-soft)", color: "var(--warning)", label: "Watch" },
  critical: { bg: "var(--critical-soft)", color: "var(--critical)", label: "Critical" },
} as const;

export function RosterTable() {
  const patients = useHealthStore((s) => s.patients);
  const providers = useHealthStore((s) => s.providers);
  const vitals = useHealthStore((s) => s.vitals);
  const selectPatient = useHealthStore((s) => s.selectPatient);
  const selectedPatientId = useHealthStore((s) => s.selectedPatientId);

  const [sorting, setSorting] = useState<SortingState>([{ id: "riskScore", desc: true }]);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [globalFilter, setGlobalFilter] = useState("");
  const [density, setDensity] = useState<"comfortable" | "compact">("comfortable");
  const [pageSize, setPageSize] = useState(20);

  const latestVitals = useMemo(() => {
    const map: Record<string, { hr: number; bpSys: number; bpDia: number; spo2: number; temp: number; timestamp: string }> = {};
    for (const p of patients) {
      const vs = vitals[p.id];
      if (vs && vs.length > 0) {
        const last = vs[vs.length - 1];
        map[p.id] = { hr: last.hr, bpSys: last.bpSys, bpDia: last.bpDia, spo2: last.spo2, temp: last.temp, timestamp: last.timestamp };
      }
    }
    return map;
  }, [patients, vitals]);

  const columns = useMemo<ColumnDef<Patient>[]>(() => [
    {
      id: "select",
      size: 40,
      header: ({ table }) => (
        <input type="checkbox" checked={table.getIsAllPageRowsSelected()} ref={(el) => { if (el) el.indeterminate = !!table.getIsSomePageRowsSelected(); }} onChange={table.getToggleAllPageRowsSelectedHandler()} className="w-4 h-4 rounded cursor-pointer accent-[var(--primary)]" aria-label="Select all" />
      ),
      cell: ({ row }) => (
        <input type="checkbox" checked={row.getIsSelected()} onChange={row.getToggleSelectedHandler()} className="w-4 h-4 rounded cursor-pointer accent-[var(--primary)]" aria-label={`Select ${row.original.lastName}`} />
      ),
      enableSorting: false, enableHiding: false,
    },
    {
      id: "patient",
      accessorFn: (p) => `${p.lastName} ${p.firstName}`,
      header: "Patient",
      size: 220,
      cell: ({ row }) => {
        const p = row.original;
        return (
          <button type="button" onClick={() => selectPatient(p.id)} className="flex items-center gap-3 text-left cursor-pointer focus-ring rounded-[8px] p-0.5 -m-0.5 hover:opacity-80 transition-opacity">
            <Avatar seed={p.avatarSeed} name={patientName(p)} size={density === "compact" ? 32 : 36} />
            <div className="min-w-0">
              <div className="text-sm font-semibold text-[var(--foreground)] truncate">{patientName(p)}</div>
              <div className="text-[11px] text-[var(--foreground-muted)] font-mono">{p.mrn} · {fmtAge(p.dob)}{p.sex}</div>
            </div>
          </button>
        );
      },
    },
    {
      accessorKey: "room",
      header: "Room",
      size: 90,
      cell: ({ row }) => <span className="text-xs font-mono text-[var(--foreground-secondary)]">{row.original.room}</span>,
    },
    {
      accessorKey: "primaryCondition",
      header: "Primary Condition",
      size: 200,
      cell: ({ row }) => <span className="text-xs text-[var(--foreground-secondary)] truncate block max-w-[180px]">{row.original.primaryCondition}</span>,
    },
    {
      id: "attending",
      accessorFn: (p) => providers.find((pr) => pr.id === p.attendingId)?.name ?? "",
      header: "Attending",
      size: 160,
      cell: ({ row }) => {
        const att = providers.find((pr) => pr.id === row.original.attendingId);
        return <span className="text-xs text-[var(--foreground-secondary)]">{att?.name ?? "—"}</span>;
      },
    },
    {
      accessorKey: "riskScore",
      header: "Risk",
      size: 90,
      cell: ({ row }) => <RiskRadial score={row.original.riskScore} size={44} />,
    },
    {
      id: "vitals",
      header: "Last Vitals",
      size: 220,
      cell: ({ row }) => {
        const v = latestVitals[row.original.id];
        if (!v) return <span className="text-xs text-[var(--foreground-muted)]">—</span>;
        return (
          <div className="flex items-center gap-2 text-[11px] font-mono">
            <VitalChip label="HR" value={v.hr} unit="" oor={isVitalOutOfRange("hr", v.hr)} />
            <VitalChip label="BP" value={`${v.bpSys}/${v.bpDia}`} unit="" oor={isVitalOutOfRange("bpSys", v.bpSys) || isVitalOutOfRange("bpDia", v.bpDia)} />
            <VitalChip label="SpO₂" value={v.spo2} unit="%" oor={isVitalOutOfRange("spo2", v.spo2)} />
            <VitalChip label="T" value={v.temp.toFixed(1)} unit="°" oor={isVitalOutOfRange("temp", v.temp)} />
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      size: 100,
      cell: ({ row }) => {
        const s = STATUS_STYLES[row.original.status];
        return <span className={cn("text-[10px] px-2 py-1 rounded-full font-semibold uppercase tracking-wide", row.original.status === "critical" && "critical-pulse")} style={{ background: s.bg, color: s.color }}>{s.label}</span>;
      },
    },
    {
      id: "lastUpdated",
      header: "Updated",
      size: 100,
      cell: ({ row }) => {
        const v = latestVitals[row.original.id];
        return <span className="text-[11px] text-[var(--foreground-muted)] font-mono">{v ? fmtRelative(v.timestamp) : "—"}</span>;
      },
    },
    {
      id: "actions",
      header: "",
      size: 50,
      enableSorting: false,
      enableHiding: false,
      cell: ({ row }) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button type="button" className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label={`Actions for ${row.original.lastName}`}>
              <MoreHorizontal size={15} />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44 font-sans" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "12px", boxShadow: "var(--shadow-lg)" }}>
            <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">{row.original.lastName}, {row.original.firstName}</DropdownMenuLabel>
            <DropdownMenuSeparator style={{ background: "var(--border)" }} />
            <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 text-xs gap-2" onClick={() => selectPatient(row.original.id)}><Eye size={13} /> View chart</DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 text-xs gap-2" onClick={() => toast.success(`Calling ${row.original.lastName}`, { description: row.original.phone, duration: 4000 })}><Phone size={13} /> Call</DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 text-xs gap-2" onClick={() => toast.success("Message sent", { description: `Secure message to ${row.original.lastName}'s care team`, duration: 4000 })}><MessageSquare size={13} /> Message</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ], [providers, latestVitals, selectPatient, density, selectPatient]);

  const table = useReactTable({
    data: patients, columns,
    state: { sorting, rowSelection, columnVisibility, globalFilter },
    enableRowSelection: true,
    onSortingChange: setSorting, onRowSelectionChange: setRowSelection, onColumnVisibilityChange: setColumnVisibility, onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(), getFilteredRowModel: getFilteredRowModel(), getSortedRowModel: getSortedRowModel(), getPaginationRowModel: getPaginationRowModel(),
    getRowId: (r) => r.id,
    initialState: { pagination: { pageSize } },
    globalFilterFn: (row, _col, filterValue) => {
      const v = String(filterValue).toLowerCase();
      const p = row.original;
      return patientName(p).toLowerCase().includes(v) || p.mrn.toLowerCase().includes(v) || p.room.toLowerCase().includes(v) || p.primaryCondition.toLowerCase().includes(v);
    },
  });

  useEffect(() => { table.setPageSize(pageSize); }, [pageSize, table]);

  const selectedRows = table.getSelectedRowModel().rows.map((r) => r.original);
  const rowH = density === "compact" ? "py-1.5" : "py-3";

  return (
    <div className="flex flex-col gap-3">
      {/* Toolbar */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
          <input value={globalFilter} onChange={(e) => setGlobalFilter(e.target.value)} placeholder="Filter roster…" className="w-full h-9 pl-9 pr-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)] transition-colors hover:border-[var(--border-strong)]" style={{ borderColor: "var(--border)" }} aria-label="Filter roster" />
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" className="h-9 px-3 inline-flex items-center gap-1.5 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring text-[var(--foreground-muted)] hover:text-[var(--foreground)]" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
                {density === "compact" ? <Rows4 size={14} /> : <Rows3 size={14} />}
                <span className="hidden sm:inline capitalize">{density}</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40 font-sans" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "12px", boxShadow: "var(--shadow-lg)" }}>
              <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">Density</DropdownMenuLabel>
              {(["comfortable", "compact"] as const).map((d) => (
                <DropdownMenuItem key={d} className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 text-xs capitalize gap-2" onClick={() => setDensity(d)}>
                  {d} {density === d && <span className="ml-auto text-[var(--primary)]">✓</span>}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" className="h-9 px-3 inline-flex items-center gap-1.5 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring text-[var(--foreground-muted)] hover:text-[var(--foreground)]" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
                <Settings2 size={14} /><span className="hidden sm:inline">Columns</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44 font-sans" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "12px", boxShadow: "var(--shadow-lg)" }}>
              <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">Toggle columns</DropdownMenuLabel>
              <DropdownMenuSeparator style={{ background: "var(--border)" }} />
              {table.getAllColumns().filter((c) => c.getCanHide()).map((col) => (
                <DropdownMenuCheckboxItem key={col.id} checked={col.getIsVisible()} onCheckedChange={(v) => col.toggleVisibility(!!v)} className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 text-sm capitalize">{col.id.replace(/-/g, " ")}</DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <button type="button" onClick={() => toast.success("CSV exported", { description: `${patients.length} patients exported to roster.csv` })} className="h-9 px-3 inline-flex items-center gap-1.5 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring text-[var(--foreground-muted)] hover:text-[var(--foreground)]" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
            <Download size={14} /><span className="hidden sm:inline">Export</span>
          </button>
          <button type="button" onClick={() => toast.info("Print view", { description: "Opening print-friendly roster…" })} className="h-9 px-3 inline-flex items-center gap-1.5 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring text-[var(--foreground-muted)] hover:text-[var(--foreground)]" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
            <Printer size={14} /><span className="hidden sm:inline">Print</span>
          </button>
        </div>
      </div>

      {/* Bulk action bar */}
      {selectedRows.length > 0 && (
        <div className="flex items-center gap-3 px-4 py-2.5 rounded-[12px] border" style={{ background: "var(--primary-soft)", borderColor: "var(--primary)" }}>
          <span className="text-xs font-semibold text-[var(--primary)]">{selectedRows.length} selected</span>
          <div className="flex items-center gap-2 ml-auto">
            <button type="button" onClick={() => toast.success("Exported selected", { description: `${selectedRows.length} patients exported` })} className="px-3 py-1 text-xs font-medium rounded-[8px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>Export</button>
            <button type="button" onClick={() => { setRowSelection({}); toast.success("Selection cleared"); }} className="px-3 py-1 text-xs font-medium rounded-[8px] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-muted)]">Clear</button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="rounded-[14px] border overflow-hidden bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              {table.getHeaderGroups().map((hg) => (
                <tr key={hg.id} className="border-b" style={{ borderColor: "var(--border)", background: "var(--surface-subtle)" }}>
                  {hg.headers.map((header) => (
                    <th key={header.id} className={cn("px-4 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap", rowH, header.column.getCanSort() && "cursor-pointer hover:text-[var(--foreground)] select-none")} style={{ width: header.getSize() !== 150 ? header.getSize() : undefined }}>
                      {header.isPlaceholder ? null : (
                        <div className="flex items-center gap-1.5" onClick={header.column.getToggleSortingHandler()}>
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          {header.column.getCanSort() && (
                            <span className="opacity-50">
                              {header.column.getIsSorted() === "asc" ? <ChevronUp size={12} /> : header.column.getIsSorted() === "desc" ? <ChevronDown size={12} /> : <ChevronsUpDown size={12} className="opacity-40" />}
                            </span>
                          )}
                        </div>
                      )}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody>
              {table.getRowModel().rows.map((row) => {
                const isSelected = selectedPatientId === row.original.id;
                return (
                  <tr
                    key={row.id}
                    data-state={row.getIsSelected() ? "selected" : undefined}
                    onClick={() => selectPatient(row.original.id)}
                    onKeyDown={(e) => { if (e.key === "Enter") selectPatient(row.original.id); }}
                    tabIndex={0}
                    className={cn("border-b last:border-0 transition-colors cursor-pointer outline-none", rowH, isSelected ? "bg-[var(--primary-soft)]" : row.getIsSelected() ? "bg-[var(--surface-subtle)]" : "hover:bg-[var(--surface-hover)]")}
                    style={{ borderColor: "var(--border)" }}
                    aria-selected={isSelected}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="px-4" onClick={cell.column.id === "select" ? (e) => e.stopPropagation() : undefined}>
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t gap-2 flex-wrap" style={{ borderColor: "var(--border)", background: "var(--surface-subtle)" }}>
          <div className="flex items-center gap-2 text-[11px] font-mono text-[var(--foreground-muted)]">
            <span>{table.getFilteredRowModel().rows.length} patients</span>
            <span className="text-[var(--border-strong)]">|</span>
            <select value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))} className="text-xs rounded-[6px] border bg-[var(--surface)] px-1.5 py-0.5 cursor-pointer" style={{ borderColor: "var(--border)" }} aria-label="Page size">
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
            </select>
            <span>per page</span>
          </div>
          <div className="flex items-center gap-1">
            <button type="button" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} className="w-8 h-8 rounded-[8px] border flex items-center justify-center disabled:opacity-40 hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" style={{ borderColor: "var(--border)" }} aria-label="Previous page"><ChevronLeft size={15} /></button>
            <span className="text-[11px] font-mono text-[var(--foreground-muted)] px-2">{table.getState().pagination.pageIndex + 1} / {table.getPageCount() || 1}</span>
            <button type="button" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} className="w-8 h-8 rounded-[8px] border flex items-center justify-center disabled:opacity-40 hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" style={{ borderColor: "var(--border)" }} aria-label="Next page"><ChevronRight size={15} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}

function VitalChip({ label, value, unit, oor }: { label: string; value: string | number; unit: string; oor: boolean }) {
  return (
    <span className="flex items-center gap-0.5" style={{ color: oor ? "var(--critical)" : "var(--foreground-secondary)" }} title={oor ? "Out of range" : undefined}>
      <span className="text-[var(--foreground-muted)] text-[9px]">{label}</span>
      <span className="font-semibold">{value}{unit}</span>
    </span>
  );
}
