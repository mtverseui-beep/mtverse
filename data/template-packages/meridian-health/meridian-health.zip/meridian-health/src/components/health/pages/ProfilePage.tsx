"use client";
import { motion } from "framer-motion";
import {
  Mail, Phone, MapPin, Calendar, Award, Activity, Users, Stethoscope,
  Clock, Star, TrendingUp, Edit,
} from "lucide-react";
import { Avatar } from "../Avatar";
import { useHealthStore } from "@/store/health-store";
import { fmtDate } from "@/lib/health/format";
import type { Route } from "@/hooks/use-hash-route";

interface ProfilePageProps {
  navigate: (path: string) => void;
}

const USER = {
  name: "Dr. Sarah Chen",
  role: "Attending Physician · Internal Medicine",
  seed: "sarah-chen",
  email: "s.chen@meridian.health",
  phone: "(555) 010-1200",
  location: "Meridian General Hospital · SF",
  joined: "2019-03-15",
  license: "MD-CA-42910",
  npi: "1234567890",
  bio: "Board-certified internist with 12 years of experience in hospital medicine. Special interest in critical care and quality improvement. Attending on the Medical ICU and teaching service.",
};

const ACHIEVEMENTS = [
  { icon: Award, label: "Top Performer", desc: "Q2 2026 patient outcomes", color: "var(--primary)" },
  { icon: Star, label: "Teaching Award", desc: "Resident voted, 2024", color: "#F59E0B" },
  { icon: Activity, label: "1000+ Patients", desc: "Career milestone", color: "var(--info)" },
  { icon: TrendingUp, label: "Quality Champion", desc: "Lowest readmission rate", color: "var(--success)" },
];

const ACTIVITY = [
  { id: "a1", text: "Admitted Henderson, R. to ICU-204", time: "2h ago", type: "admission" },
  { id: "a2", text: "Completed discharge summary for Almeida, S.", time: "4h ago", type: "discharge" },
  { id: "a3", text: "Reviewed labs for Kowalski, D.", time: "5h ago", type: "lab" },
  { id: "a4", text: "Consult requested: Nephrology for Brennan, M.", time: "6h ago", type: "consult" },
  { id: "a5", text: "Note signed: Progress note for Reed, T.", time: "8h ago", type: "note" },
];

export function ProfilePage({ navigate }: ProfilePageProps) {
  const patients = useHealthStore((s) => s.patients);
  const providers = useHealthStore((s) => s.providers);
  const user = providers.find((p) => p.id === "p1");
  const activePatients = patients.filter((p) => p.attendingId === "p1").length;

  return (
    <div className="p-6 lg:p-8 max-w-5xl mx-auto">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-[16px] border bg-[var(--surface)] p-6 mb-6 relative overflow-hidden"
        style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}
      >
        <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, var(--primary-soft), transparent 70%)", opacity: 0.6 }} />
        <div className="relative flex items-start gap-5 flex-wrap">
          <Avatar seed={USER.seed} name={USER.name} size={96} ring />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-bold text-[var(--foreground)]">{USER.name}</h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wide" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>Attending</span>
            </div>
            <p className="text-sm text-[var(--foreground-muted)] mt-0.5">{USER.role}</p>
            <p className="text-xs text-[var(--foreground-muted)] mt-3 max-w-xl leading-relaxed">{USER.bio}</p>
            <div className="flex items-center gap-4 mt-4 text-xs text-[var(--foreground-muted)] flex-wrap">
              <span className="flex items-center gap-1.5"><Mail size={12} />{USER.email}</span>
              <span className="flex items-center gap-1.5"><Phone size={12} />{USER.phone}</span>
              <span className="flex items-center gap-1.5"><MapPin size={12} />{USER.location}</span>
              <span className="flex items-center gap-1.5"><Calendar size={12} />Since {fmtDate(USER.joined)}</span>
            </div>
          </div>
          <button type="button" onClick={() => navigate("settings/profile")} className="flex items-center gap-1.5 px-3 h-9 text-xs font-semibold rounded-[10px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}>
            <Edit size={13} /> Edit profile
          </button>
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatBox icon={Users} label="Active Patients" value={String(activePatients)} accent />
        <StatBox icon={Stethoscope} label="Consults" value="24" />
        <StatBox icon={Clock} label="Shift Hours" value="1,240" />
        <StatBox icon={Award} label="Patient Rating" value="4.9/5" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Credentials */}
        <div className="lg:col-span-2 space-y-6">
          <Card title="Credentials & Licensing">
            <div className="grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
              <Row label="Medical License" value={USER.license} />
              <Row label="NPI Number" value={USER.npi} />
              <Row label="Board Certification" value="Internal Medicine · 2015" />
              <Row label="DEA Number" value="BC429101" />
              <Row label="Hospital Privileges" value="Meridian General" />
              <Row label="Education" value="MD, UCSF School of Medicine" />
              <Row label="Residency" value="Internal Medicine · Cedars-Sinai" />
              <Row label="Fellowship" value="Critical Care · Johns Hopkins" />
            </div>
          </Card>

          <Card title="Recent Activity">
            <div className="space-y-1">
              {ACTIVITY.map((a, i) => (
                <div key={a.id} className="flex items-start gap-3 py-2.5 relative">
                  {i < ACTIVITY.length - 1 && <div className="absolute left-[11px] top-9 bottom-0 w-px" style={{ background: "var(--border)" }} />}
                  <div className="w-6 h-6 rounded-[6px] flex items-center justify-center shrink-0 z-10" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>
                    <Activity size={12} />
                  </div>
                  <div className="flex-1 min-w-0 pt-0.5">
                    <p className="text-xs font-medium text-[var(--foreground)]">{a.text}</p>
                  </div>
                  <span className="text-[10px] font-mono text-[var(--foreground-muted)] shrink-0 pt-1">{a.time}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Achievements */}
        <div>
          <Card title="Achievements">
            <div className="space-y-2">
              {ACHIEVEMENTS.map((a) => {
                const Icon = a.icon;
                return (
                  <div key={a.label} className="flex items-center gap-3 p-2.5 rounded-[10px] hover:bg-[var(--surface-hover)] transition-colors">
                    <div className="w-9 h-9 rounded-[10px] flex items-center justify-center shrink-0" style={{ background: `${a.color}1f`, color: a.color }}>
                      <Icon size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-[var(--foreground)]">{a.label}</p>
                      <p className="text-[10px] text-[var(--foreground-muted)]">{a.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatBox({ icon: Icon, label, value, accent }: { icon: React.ComponentType<{ size?: number }>; label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-[14px] border p-5 bg-[var(--surface)]" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-wider font-medium text-[var(--foreground-muted)]">{label}</p>
          <p className="text-2xl font-bold font-mono text-[var(--foreground)] mt-1.5">{value}</p>
        </div>
        <div className="w-9 h-9 rounded-[10px] flex items-center justify-center" style={{ background: accent ? "var(--primary-soft)" : "var(--surface-hover)", color: accent ? "var(--primary)" : "var(--foreground-muted)" }}>
          <Icon size={16} />
        </div>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-[14px] border bg-[var(--surface)] overflow-hidden" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
      <header className="px-5 py-3.5 border-b" style={{ borderColor: "var(--border)" }}>
        <h3 className="text-sm font-semibold text-[var(--foreground)]">{title}</h3>
      </header>
      <div className="p-5">{children}</div>
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span className="text-[10px] text-[var(--foreground-muted)] uppercase tracking-wide">{label}</span>
      <p className="text-xs font-medium text-[var(--foreground)] mt-0.5">{value}</p>
    </div>
  );
}
