"use client";
import { useHealthStore } from "@/store/health-store";
import { fmtDate, fmtLengthOfStay } from "@/lib/health/format";
import { VITAL_RANGES, isVitalOutOfRange } from "@/lib/health/types";
import { Check, Plus, AlertTriangle, FlaskConical, Image, ShieldAlert, Footprints, Pill } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function OverviewTab({ patientId }: { patientId: string }) {
  const patients = useHealthStore((s) => s.patients);
  const providers = useHealthStore((s) => s.providers);
  const vitals = useHealthStore((s) => s.vitals);
  const medications = useHealthStore((s) => s.medications);
  const tasks = useHealthStore((s) => s.tasks);
  const alerts = useHealthStore((s) => s.alerts);
  const completeTask = useHealthStore((s) => s.completeTask);

  const patient = patients.find((p) => p.id === patientId);
  if (!patient) return null;

  const attending = providers.find((p) => p.id === patient.attendingId);
  const nurse = providers.find((p) => p.id === patient.nurseId);
  const ptVitals = vitals[patientId] ?? [];
  const lastVital = ptVitals[ptVitals.length - 1];
  const ptMeds = medications.filter((m) => m.patientId === patientId);
  const ptTasks = tasks.filter((t) => t.patientId === patientId);
  const ptAlerts = alerts.filter((a) => a.patientId === patientId);
  const overdueMeds = ptMeds.filter((m) => m.status === "overdue");

  return (
    <div className="p-4 space-y-4">
      {/* Patient Summary */}
      <Section title="Patient Summary">
        <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
          <Row label="Age" value={`${patient.age} years`} />
          <Row label="DOB" value={fmtDate(patient.dob)} />
          <Row label="Sex" value={patient.sex === "M" ? "Male" : patient.sex === "F" ? "Female" : "Other"} />
          <Row label="Blood type" value={patient.bloodType} />
          <Row label="Primary diagnosis" value={patient.primaryDiagnosis} fullWidth />
          <Row label="Allergies" value={patient.allergies.join(", ")} fullWidth highlight={patient.allergies[0] !== "None recorded"} />
          {patient.secondaryConditions.length > 0 && <Row label="Secondary" value={patient.secondaryConditions.join(", ")} fullWidth />}
          <Row label="Insurance" value={patient.insurance} fullWidth />
        </div>
      </Section>

      {/* Current Admission */}
      <Section title="Current Admission">
        <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
          <Row label="Admit date" value={fmtDate(patient.admitDate)} />
          <Row label="Length of stay" value={fmtLengthOfStay(patient.admitDate)} />
          <Row label="Attending" value={attending?.name ?? "—"} fullWidth />
          <Row label="Primary nurse" value={nurse?.name ?? "—"} fullWidth />
          <Row label="Code status" value={patient.codeStatus} highlight={patient.codeStatus !== "FULL"} />
          <Row label="Fall risk" value={patient.fallRisk ? "Yes" : "No"} highlight={patient.fallRisk} />
        </div>
      </Section>

      {/* Latest Vitals */}
      <Section title="Latest Vitals">
        {lastVital ? (
          <div className="grid grid-cols-3 gap-2">
            <VitalCard label="HR" value={lastVital.hr} unit="bpm" range="60-100" oor={isVitalOutOfRange("hr", lastVital.hr)} />
            <VitalCard label="BP" value={`${lastVital.bpSys}/${lastVital.bpDia}`} unit="mmHg" range="90-120" oor={isVitalOutOfRange("bpSys", lastVital.bpSys) || isVitalOutOfRange("bpDia", lastVital.bpDia)} />
            <VitalCard label="RR" value={lastVital.rr} unit="rpm" range="12-20" oor={isVitalOutOfRange("rr", lastVital.rr)} />
            <VitalCard label="SpO₂" value={lastVital.spo2} unit="%" range="95-100" oor={isVitalOutOfRange("spo2", lastVital.spo2)} />
            <VitalCard label="Temp" value={lastVital.temp.toFixed(1)} unit="°C" range="36.1-37.2" oor={isVitalOutOfRange("temp", lastVital.temp)} />
            <VitalCard label="Pain" value={lastVital.pain} unit="/10" range="0-3" oor={lastVital.pain > 3} />
          </div>
        ) : (
          <p className="text-xs text-[var(--foreground-muted)]">No vitals recorded.</p>
        )}
      </Section>

      {/* Active Alerts */}
      {ptAlerts.length > 0 && (
        <Section title="Active Alerts">
          <div className="space-y-1.5">
            {ptAlerts.slice(0, 5).map((a) => (
              <div key={a.id} className="flex items-start gap-2 p-2 rounded-[8px]" style={{ background: a.severity === "critical" ? "var(--critical-soft)" : a.severity === "warning" ? "var(--warning-soft)" : "var(--info-soft)" }}>
                <AlertTriangle size={14} className="shrink-0 mt-0.5" style={{ color: a.severity === "critical" ? "var(--critical)" : a.severity === "warning" ? "var(--warning)" : "var(--info)" }} />
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-[var(--foreground)]">{a.title}</p>
                  <p className="text-[11px] text-[var(--foreground-secondary)]">{a.description}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Tasks */}
      <Section title="Tasks" action={<button type="button" onClick={() => toast.info("Add task", { description: "Task form would open here" })} className="flex items-center gap-1 text-[11px] font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer focus-ring rounded-[6px] px-1.5 py-0.5"><Plus size={12} /> Add</button>}>
        <div className="space-y-1.5">
          {ptTasks.filter((t) => t.status !== "completed").slice(0, 5).map((t) => (
            <div key={t.id} className="flex items-center gap-2 p-2 rounded-[8px] border" style={{ borderColor: "var(--border)", background: t.status === "overdue" ? "var(--critical-soft)" : "var(--surface)" }}>
              <button type="button" onClick={() => { completeTask(t.id); toast.success("Task completed", { description: t.title }); }} className="w-5 h-5 rounded-full border-2 flex items-center justify-center hover:border-[var(--primary)] hover:bg-[var(--primary-soft)] transition-colors cursor-pointer focus-ring shrink-0" style={{ borderColor: t.status === "overdue" ? "var(--critical)" : "var(--border-strong)" }} aria-label={`Complete task: ${t.title}`}>
                <Check size={11} className="text-transparent hover:text-[var(--primary)]" />
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-[var(--foreground)] truncate">{t.title}</p>
                <p className="text-[10px] text-[var(--foreground-muted)] font-mono">Due {t.dueTime}</p>
              </div>
              {t.status === "overdue" && <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--critical-soft)", color: "var(--critical)" }}>Overdue</span>}
            </div>
          ))}
          {ptTasks.filter((t) => t.status !== "completed").length === 0 && <p className="text-xs text-[var(--foreground-muted)] py-2 text-center">No pending tasks.</p>}
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <section>
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)]">{title}</h3>
        {action}
      </div>
      {children}
    </section>
  );
}
function Row({ label, value, fullWidth, highlight }: { label: string; value: string; fullWidth?: boolean; highlight?: boolean }) {
  return (
    <div className={cn("flex flex-col gap-0.5", fullWidth && "col-span-2")}>
      <span className="text-[10px] text-[var(--foreground-muted)] uppercase tracking-wide">{label}</span>
      <span className={cn("text-xs font-medium", highlight ? "text-[var(--critical)]" : "text-[var(--foreground)]")}>{value}</span>
    </div>
  );
}
function VitalCard({ label, value, unit, range, oor }: { label: string; value: string | number; unit: string; range: string; oor: boolean }) {
  return (
    <div className="rounded-[10px] border p-2.5" style={{ borderColor: oor ? "var(--critical)" : "var(--border)", background: oor ? "var(--critical-soft)" : "var(--surface)" }}>
      <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--foreground-muted)]">{label}</div>
      <div className="flex items-baseline gap-0.5 mt-1">
        <span className="text-lg font-mono font-bold" style={{ color: oor ? "var(--critical)" : "var(--foreground)" }}>{value}</span>
        <span className="text-[10px] text-[var(--foreground-muted)]">{unit}</span>
      </div>
      <div className="text-[9px] text-[var(--foreground-muted)] font-mono mt-0.5">Ref {range}</div>
    </div>
  );
}
