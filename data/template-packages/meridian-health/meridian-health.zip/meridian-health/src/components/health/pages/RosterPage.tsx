"use client";
import { RosterTable } from "../RosterTable";
import { useHealthStore } from "@/store/health-store";

export function RosterPage() {
  const patients = useHealthStore((s) => s.patients);
  const criticalCount = patients.filter((p) => p.status === "critical").length;
  const watchCount = patients.filter((p) => p.status === "watch").length;
  const stableCount = patients.filter((p) => p.status === "stable").length;

  return (
    <div className="p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-[var(--foreground)] tracking-tight">Patient Roster</h1>
          <p className="text-sm text-[var(--foreground-muted)] mt-1">
            {patients.length} patients · <span className="text-[var(--critical)] font-semibold">{criticalCount} critical</span> · <span className="text-[var(--warning)] font-semibold">{watchCount} watch</span> · <span className="text-[var(--success)] font-semibold">{stableCount} stable</span>
          </p>
        </div>
      </div>
      <RosterTable />
    </div>
  );
}
