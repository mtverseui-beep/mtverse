"use client";
import { useState } from "react";
import { Bell, Check, CheckCheck, AlertTriangle, Info, Pill, Calendar, Activity } from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { motion, AnimatePresence } from "framer-motion";
import { useHealthStore } from "@/store/health-store";
import { cn } from "@/lib/utils";

const ICONS = {
  "lab-result": { icon: Activity, color: "var(--info)" },
  "medication-overdue": { icon: Pill, color: "var(--warning)" },
  "appointment-reminder": { icon: Calendar, color: "var(--secondary)" },
  "critical-alert": { icon: AlertTriangle, color: "var(--critical)" },
  "task-assigned": { icon: Check, color: "var(--primary)" },
  message: { icon: Info, color: "var(--info)" },
} as const;

export function NotificationsDropdown() {
  const notifications = useHealthStore((s) => s.notifications);
  const markRead = useHealthStore((s) => s.markNotificationRead);
  const markAllRead = useHealthStore((s) => s.markAllNotificationsRead);
  const unread = notifications.filter((n) => !n.read).length;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
          className="relative w-10 h-10 rounded-[10px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer"
        >
          <Bell size={18} />
          {unread > 0 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 500, damping: 25 }}
              className="absolute top-1.5 right-1.5 min-w-[16px] h-[16px] px-1 rounded-full flex items-center justify-center text-[9px] font-bold text-white font-mono"
              style={{ background: unread > 0 && notifications.some(n => n.severity === "critical") ? "var(--critical)" : "var(--primary)" }}
            >
              {unread}
            </motion.span>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-[380px] p-0 font-sans"
        style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "16px", boxShadow: "var(--shadow-xl)", overflow: "hidden" }}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">Notifications</h3>
            {unread > 0 && (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>
                {unread} new
              </span>
            )}
          </div>
          {unread > 0 && (
            <button type="button" onClick={markAllRead} className="flex items-center gap-1 text-[11px] font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer focus-ring rounded-[6px] px-1.5 py-0.5">
              <CheckCheck size={12} /> Mark all read
            </button>
          )}
        </div>
        <div className="max-h-[400px] overflow-y-auto">
          <AnimatePresence initial={false}>
            {notifications.map((n) => {
              const meta = ICONS[n.type];
              const Icon = meta.icon;
              return (
                <motion.button
                  key={n.id}
                  type="button"
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => markRead(n.id)}
                  className={cn("w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-[var(--surface-hover)] transition-colors cursor-pointer border-b last:border-0 relative", !n.read && "bg-[var(--surface-subtle)]")}
                  style={{ borderColor: "var(--border)" }}
                  aria-live={n.severity === "critical" ? "assertive" : "polite"}
                >
                  {!n.read && <span className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full" style={{ background: n.severity === "critical" ? "var(--critical)" : "var(--primary)" }} />}
                  <span className="shrink-0 w-8 h-8 rounded-[8px] flex items-center justify-center" style={{ background: n.severity === "critical" ? "var(--critical-soft)" : "var(--surface-hover)", color: n.severity === "critical" ? "var(--critical)" : meta.color }}>
                    <Icon size={15} />
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between gap-2">
                      <p className={cn("text-xs font-semibold truncate", !n.read ? "text-[var(--foreground)]" : "text-[var(--foreground-secondary)]")}>{n.title}</p>
                      <span className="text-[10px] text-[var(--foreground-muted)] shrink-0 font-mono">{n.time}</span>
                    </div>
                    <p className="text-[11px] text-[var(--foreground-muted)] mt-0.5 leading-relaxed line-clamp-2">{n.body}</p>
                  </div>
                </motion.button>
              );
            })}
          </AnimatePresence>
        </div>
        <DropdownMenuSeparator style={{ background: "var(--border)" }} />
        <button type="button" className="w-full px-4 py-2.5 text-xs font-medium text-[var(--primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring">
          View all notifications
        </button>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
