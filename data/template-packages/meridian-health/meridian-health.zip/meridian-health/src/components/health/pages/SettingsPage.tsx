"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { User, Settings as SettingsIcon, Palette, Bell, Shield, Check } from "lucide-react";
import { SettingsCard, Toggle, SettingRow } from "../settings/_shared";
import { useTheme } from "next-themes";
import { Button } from "../Button";
import { Field, Input, Textarea } from "../Field";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { Route } from "@/hooks/use-hash-route";

interface SettingsPageProps {
  route: Route;
  navigate: (path: string) => void;
}

const SECTIONS = [
  { id: "profile", label: "Profile", icon: User, description: "Your personal information" },
  { id: "account", label: "Account", icon: SettingsIcon, description: "Account preferences" },
  { id: "appearance", label: "Appearance", icon: Palette, description: "Theme & display" },
  { id: "notifications", label: "Notifications", icon: Bell, description: "Alerts & emails" },
  { id: "security", label: "Security", icon: Shield, description: "2FA & sessions" },
] as const;

export function SettingsPage({ route, navigate }: SettingsPageProps) {
  const active = route.segments[1] ?? "profile";

  return (
    <div className="p-6 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[var(--foreground)] tracking-tight">Settings</h1>
        <p className="text-sm text-[var(--foreground-muted)] mt-1">Manage your account, preferences, and security.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-6">
        <nav className="rounded-[14px] border p-2 bg-[var(--surface)] h-fit sticky top-6" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }} aria-label="Settings sections">
          {SECTIONS.map((s) => {
            const Icon = s.icon;
            const isActive = active === s.id;
            return (
              <button key={s.id} type="button" onClick={() => navigate(`settings/${s.id}`)} aria-current={isActive ? "page" : undefined} className={cn("w-full flex items-center gap-2.5 px-3 py-2 rounded-[10px] text-sm transition-colors cursor-pointer focus-ring text-left", isActive ? "text-[var(--primary)]" : "text-[var(--foreground-secondary)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]")} style={isActive ? { background: "var(--primary-soft)" } : undefined}>
                <Icon size={15} />
                <span className="flex-1 font-medium">{s.label}</span>
                {isActive && <motion.span layoutId="settings-active" className="w-1 h-4 rounded-full" style={{ background: "var(--primary)" }} />}
              </button>
            );
          })}
        </nav>
        <motion.div key={active} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }} className="space-y-4">
          {active === "profile" && <ProfileSettings />}
          {active === "account" && <AccountSettings />}
          {active === "appearance" && <AppearanceSettings />}
          {active === "notifications" && <NotificationSettings />}
          {active === "security" && <SecuritySettings />}
        </motion.div>
      </div>
    </div>
  );
}

function ProfileSettings() {
  const [name, setName] = useState("Dr. Sarah Chen");
  const [email, setEmail] = useState("s.chen@meridian.health");
  const [phone, setPhone] = useState("(555) 010-1200");
  const [bio, setBio] = useState("Board-certified internist with 12 years of experience in hospital medicine.");
  return (
    <>
      <SettingsCard title="Personal information" description="Update your personal details.">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Full name" required><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="Email" required><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          <Field label="Phone"><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
          <Field label="Title"><Input value="Attending Physician" readOnly /></Field>
          <Field label="Bio" className="md:col-span-2"><Textarea rows={3} value={bio} onChange={(e) => setBio(e.target.value)} /></Field>
        </div>
        <div className="flex justify-end mt-5"><Button variant="primary" size="md" icon={Check} onClick={() => toast.success("Profile updated")}>Save changes</Button></div>
      </SettingsCard>
    </>
  );
}

function AccountSettings() {
  const [defaultView, setDefaultView] = useState("dashboard");
  const [confirmDischarge, setConfirmDischarge] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  return (
    <>
      <SettingsCard title="Clinical preferences" description="Customize your clinical workflow defaults.">
        <Field label="Default landing page">
          <select value={defaultView} onChange={(e) => setDefaultView(e.target.value)} className="w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none cursor-pointer text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>
            <option value="dashboard">Dashboard</option>
            <option value="patients">Patient roster</option>
            <option value="appointments">Appointments</option>
          </select>
        </Field>
        <div className="mt-4"><SettingRow>
          <Toggle checked={confirmDischarge} onCheckedChange={setConfirmDischarge} label="Confirm discharge orders" description="Require confirmation before submitting discharge summaries." />
          <Toggle checked={autoRefresh} onCheckedChange={setAutoRefresh} label="Auto-refresh vitals" description="Update vital signs every 30 seconds while viewing patient charts." />
        </SettingRow></div>
        <div className="flex justify-end mt-5"><Button variant="primary" size="md" icon={Check} onClick={() => toast.success("Preferences saved")}>Save</Button></div>
      </SettingsCard>
    </>
  );
}

function AppearanceSettings() {
  const { theme, setTheme } = useTheme();
  const [density, setDensity] = useState<"comfortable" | "compact">("comfortable");
  const [reducedMotion, setReducedMotion] = useState(false);
  const themes = [{ id: "light", label: "Light" }, { id: "dark", label: "Dark" }, { id: "system", label: "System" }] as const;
  return (
    <>
      <SettingsCard title="Theme" description="Choose how Meridian Health looks.">
        <div className="grid grid-cols-3 gap-3">
          {themes.map((t) => {
            const isActive = theme === t.id;
            return <button key={t.id} type="button" onClick={() => setTheme(t.id)} className={cn("relative rounded-[12px] border p-4 flex flex-col items-center gap-2 transition-all cursor-pointer focus-ring", isActive ? "border-[var(--primary)]" : "border-[var(--border)] hover:border-[var(--border-strong)]")} style={isActive ? { background: "var(--primary-soft)" } : { background: "var(--surface)" }}>
              <span className={cn("text-sm font-medium", isActive ? "text-[var(--primary)]" : "text-[var(--foreground)]")}>{t.label}</span>
              {isActive && <motion.span layoutId="theme-active" className="absolute top-2 right-2 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: "var(--primary)" }}><Check size={10} className="text-white" /></motion.span>}
            </button>;
          })}
        </div>
      </SettingsCard>
      <SettingsCard title="Display" description="Adjust density and motion.">
        <SettingRow>
          <div className="py-3">
            <p className="text-sm font-medium text-[var(--foreground)] mb-2">Density</p>
            <div className="grid grid-cols-2 gap-2">
              {(["comfortable", "compact"] as const).map((d) => <button key={d} type="button" onClick={() => setDensity(d)} className={cn("rounded-[10px] border p-3 text-left transition-all cursor-pointer focus-ring", density === d ? "border-[var(--primary)]" : "border-[var(--border)]")} style={density === d ? { background: "var(--primary-soft)" } : { background: "var(--surface)" }}>
                <p className={cn("text-sm font-medium capitalize", density === d ? "text-[var(--primary)]" : "text-[var(--foreground)]")}>{d}</p>
                <p className="text-[11px] text-[var(--foreground-muted)] mt-0.5">{d === "comfortable" ? "More spacing" : "Tighter spacing"}</p>
              </button>)}
            </div>
          </div>
          <Toggle checked={reducedMotion} onCheckedChange={setReducedMotion} label="Reduce motion" description="Minimize animations and transitions." />
        </SettingRow>
      </SettingsCard>
    </>
  );
}

function NotificationSettings() {
  const [critical, setCritical] = useState(true);
  const [taskAssigned, setTaskAssigned] = useState(true);
  const [labResults, setLabResults] = useState(true);
  const [appointmentReminders, setAppointmentReminders] = useState(false);
  const [shiftSummary, setShiftSummary] = useState(true);
  return (
    <SettingsCard title="Notification preferences" description="Choose what alerts you receive.">
      <SettingRow>
        <Toggle checked={critical} onCheckedChange={setCritical} label="Critical alerts" description="Immediate alerts for critical patients and out-of-range vitals." />
        <Toggle checked={taskAssigned} onCheckedChange={setTaskAssigned} label="Task assignments" description="When a task is assigned to you." />
        <Toggle checked={labResults} onCheckedChange={setLabResults} label="Lab results" description="When lab results are available." />
        <Toggle checked={appointmentReminders} onCheckedChange={setAppointmentReminders} label="Appointment reminders" description="15 minutes before each appointment." />
        <Toggle checked={shiftSummary} onCheckedChange={setShiftSummary} label="Shift summary email" description="Daily summary at end of shift." />
      </SettingRow>
      <div className="flex justify-end mt-5"><Button variant="primary" size="md" icon={Check} onClick={() => toast.success("Notification preferences saved")}>Save preferences</Button></div>
    </SettingsCard>
  );
}

function SecuritySettings() {
  const [twoFA, setTwoFA] = useState(true);
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [showPw, setShowPw] = useState(false);
  const changePassword = () => {
    if (newPw.length < 8) { toast.error("Password must be at least 8 characters"); return; }
    if (newPw !== confirmPw) { toast.error("Passwords don't match"); return; }
    toast.success("Password changed");
    setCurrentPw(""); setNewPw(""); setConfirmPw("");
  };
  return (
    <>
      <SettingsCard title="Two-factor authentication" description="Extra security for your account.">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[10px] flex items-center justify-center" style={{ background: twoFA ? "var(--success-soft)" : "var(--surface-hover)", color: twoFA ? "var(--success)" : "var(--foreground-muted)" }}><Shield size={18} /></div>
            <div>
              <p className="text-sm font-medium text-[var(--foreground)] flex items-center gap-2">Authenticator app {twoFA && <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--success-soft)", color: "var(--success)" }}>Enabled</span>}</p>
              <p className="text-xs text-[var(--foreground-muted)] mt-0.5">{twoFA ? "Protected via authenticator" : "Not enabled"}</p>
            </div>
          </div>
          <Button variant={twoFA ? "outline" : "primary"} size="md" onClick={() => { setTwoFA(!twoFA); toast.success(twoFA ? "2FA disabled" : "2FA enabled"); }}>{twoFA ? "Disable" : "Enable"}</Button>
        </div>
      </SettingsCard>
      <SettingsCard title="Change password" description="Use a strong, unique password.">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Field label="Current password" required><Input type={showPw ? "text" : "password"} value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} /></Field>
          <Field label="New password" required><Input type={showPw ? "text" : "password"} value={newPw} onChange={(e) => setNewPw(e.target.value)} trailing={<button type="button" onClick={() => setShowPw(v => !v)} className="cursor-pointer focus-ring" aria-label="Toggle visibility">{showPw ? "Hide" : "Show"}</button>} /></Field>
          <Field label="Confirm" required><Input type={showPw ? "text" : "password"} value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} /></Field>
        </div>
        <div className="flex justify-end mt-4"><Button variant="primary" size="md" onClick={changePassword}>Update password</Button></div>
      </SettingsCard>
    </>
  );
}
