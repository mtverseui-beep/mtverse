"use client";
import { useState } from "react";
import { Inbox, Check, Clock, AlertCircle, User } from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { motion, AnimatePresence } from "framer-motion";
import { useHealthStore } from "@/store/health-store";
import { useHashRoute } from "@/hooks/use-hash-route";
import { patientName, fmtRelative } from "@/lib/health/format";
import { Avatar } from "./Avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function TaskInboxDropdown() {
  const tasks = useHealthStore((s) => s.tasks);
  const patients = useHealthStore((s) => s.patients);
  const completeTask = useHealthStore((s) => s.completeTask);
  const selectPatient = useHealthStore((s) => s.selectPatient);
  const [, navigate] = useHashRoute();

  const pending = tasks.filter((t) => t.status === "pending" || t.status === "overdue");
  const overdue = pending.filter((t) => t.status === "overdue");
  const sorted = [...pending].sort((a, b) => {
    if (a.status === "overdue" && b.status !== "overdue") return -1;
    if (b.status === "overdue" && a.status !== "overdue") return 1;
    return new Date(a.dueTime).getTime() - new Date(b.dueTime).getTime();
  }).slice(0, 12);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={`Task inbox, ${pending.length} pending`}
          className="relative w-10 h-10 rounded-[10px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer"
        >
          <Inbox size={18} />
          {pending.length > 0 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 500, damping: 25 }}
              className="absolute top-1.5 right-1.5 min-w-[16px] h-[16px] px-1 rounded-full flex items-center justify-center text-[9px] font-bold text-white font-mono"
              style={{ background: overdue.length > 0 ? "var(--warning)" : "var(--primary)" }}
            >
              {pending.length}
            </motion.span>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-[400px] p-0 font-sans"
        style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "16px", boxShadow: "var(--shadow-xl)", overflow: "hidden" }}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">Task Inbox</h3>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>
              {pending.length} pending
            </span>
            {overdue.length > 0 && (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full" style={{ background: "var(--critical-soft)", color: "var(--critical)" }}>
                {overdue.length} overdue
              </span>
            )}
          </div>
        </div>
        <div className="max-h-[420px] overflow-y-auto">
          {sorted.length === 0 ? (
            <div className="px-4 py-10 text-center">
              <div className="w-12 h-12 rounded-[12px] flex items-center justify-center mx-auto mb-3" style={{ background: "var(--success-soft)" }}>
                <Check size={22} style={{ color: "var(--success)" }} />
              </div>
              <p className="text-sm font-medium text-[var(--foreground)]">All caught up</p>
              <p className="text-xs text-[var(--foreground-muted)] mt-1">No pending tasks.</p>
            </div>
          ) : (
            <AnimatePresence initial={false}>
              {sorted.map((t) => {
                const patient = patients.find((p) => p.id === t.patientId);
                if (!patient) return null;
                const isOverdue = t.status === "overdue";
                return (
                  <motion.div
                    key={t.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0, height: 0 }}
                    className="flex items-start gap-3 px-4 py-3 border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors"
                    style={{ borderColor: "var(--border)", background: isOverdue ? "var(--critical-soft)" : undefined }}
                  >
                    <button
                      type="button"
                      onClick={() => { completeTask(t.id); toast.success("Task completed", { description: t.title }); }}
                      className="w-5 h-5 rounded-full border-2 flex items-center justify-center hover:border-[var(--primary)] hover:bg-[var(--primary-soft)] transition-colors cursor-pointer focus-ring shrink-0 mt-0.5"
                      style={{ borderColor: isOverdue ? "var(--critical)" : "var(--border-strong)" }}
                      aria-label={`Complete task: ${t.title}`}
                    >
                      <Check size={11} className="text-transparent hover:text-[var(--primary)]" />
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-semibold text-[var(--foreground)] truncate">{t.title}</p>
                        {isOverdue && <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase critical-pulse" style={{ background: "var(--critical)", color: "white" }}>Overdue</span>}
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <button
                          type="button"
                          onClick={() => { selectPatient(patient.id); navigate("patients"); }}
                          className="flex items-center gap-1 text-[10px] text-[var(--foreground-muted)] hover:text-[var(--primary)] transition-colors cursor-pointer focus-ring rounded-[4px]"
                        >
                          <Avatar seed={patient.avatarSeed} name={patientName(patient)} size={16} />
                          <span className="font-mono">{patient.lastName}, {patient.firstName[0]}.</span>
                          <span>· {patient.room}</span>
                        </button>
                      </div>
                      <div className="flex items-center gap-1 mt-1 text-[10px] font-mono" style={{ color: isOverdue ? "var(--critical)" : "var(--foreground-muted)" }}>
                        <Clock size={10} />
                        <span>{isOverdue ? "Overdue · " : "Due "}{fmtRelative(t.dueTime)}</span>
                        <span className="text-[var(--border-strong)]">·</span>
                        <span className="capitalize">{t.category}</span>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
        <DropdownMenuSeparator style={{ background: "var(--border)" }} />
        <button
          type="button"
          onClick={() => navigate("patients")}
          className="w-full px-4 py-2.5 text-xs font-medium text-[var(--primary)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring"
        >
          View all tasks
        </button>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
