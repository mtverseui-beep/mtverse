"use client";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function SettingsCard({ title, description, children, actions }: { title: string; description?: string; children: React.ReactNode; actions?: React.ReactNode }) {
  return (
    <section className="rounded-[14px] border bg-[var(--surface)] overflow-hidden" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-sm)" }}>
      <header className="px-5 py-4 border-b flex items-start justify-between gap-3" style={{ borderColor: "var(--border)" }}>
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-[var(--foreground)]">{title}</h3>
          {description && <p className="text-xs text-[var(--foreground-muted)] mt-0.5 leading-relaxed">{description}</p>}
        </div>
        {actions && <div className="shrink-0">{actions}</div>}
      </header>
      <div className="p-5">{children}</div>
    </section>
  );
}

export function Toggle({ checked, onCheckedChange, label, description }: { checked: boolean; onCheckedChange: (v: boolean) => void; label: string; description?: string }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5">
      <div className="min-w-0">
        <p className="text-sm font-medium text-[var(--foreground)]">{label}</p>
        {description && <p className="text-xs text-[var(--foreground-muted)] mt-0.5 leading-relaxed">{description}</p>}
      </div>
      <button type="button" role="switch" aria-checked={checked} aria-label={label} onClick={() => onCheckedChange(!checked)} className="relative w-10 h-6 rounded-full transition-colors shrink-0 cursor-pointer focus-ring" style={{ background: checked ? "var(--primary)" : "var(--border-strong)" }}>
        <motion.span layout transition={{ type: "spring", stiffness: 500, damping: 30 }} className="absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm" style={{ left: checked ? "22px" : "2px" }} />
      </button>
    </div>
  );
}

export function SettingRow({ children }: { children: React.ReactNode }) {
  return <div className="divide-y" style={{ borderColor: "var(--border)" }}>{children}</div>;
}
