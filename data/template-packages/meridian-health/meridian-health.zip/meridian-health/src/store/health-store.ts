"use client";
import { create } from "zustand";
import { buildHealthData, type HealthData } from "@/lib/health/mock-data";
import type { Notification, Task, VisitNode } from "@/lib/health/types";

interface HealthState extends HealthData {
  selectedPatientId: string | null;
  panelOpen: boolean;
  panelTab: "overview" | "vitals" | "medications" | "timeline";
  searchQuery: string;
  searchOpen: boolean;
  commandOpen: boolean;
  activeTab: "roster" | "schedule" | "care-team" | "reports";
  // Actions
  selectPatient: (id: string | null) => void;
  setPanelOpen: (open: boolean) => void;
  setPanelTab: (tab: HealthState["panelTab"]) => void;
  setSearchQuery: (q: string) => void;
  setSearchOpen: (open: boolean) => void;
  setCommandOpen: (open: boolean) => void;
  setActiveTab: (tab: HealthState["activeTab"]) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  completeTask: (id: string) => void;
  addTask: (task: Omit<Task, "id">) => void;
  administerMedication: (medId: string) => void;
  addVisitNote: (note: Omit<VisitNode, "id">) => void;
}

const _data = buildHealthData();
let _taskSeq = _data.tasks.length;
let _visitSeq = _data.visits.length;

export const useHealthStore = create<HealthState>((set) => ({
  ..._data,
  selectedPatientId: null,
  panelOpen: false,
  panelTab: "overview",
  searchQuery: "",
  searchOpen: false,
  commandOpen: false,
  activeTab: "roster",

  selectPatient: (id) =>
    set((s) => ({
      selectedPatientId: id,
      panelOpen: id !== null,
    })),
  setPanelOpen: (open) => set({ panelOpen: open, selectedPatientId: open ? undefined : null }),
  setPanelTab: (tab) => set({ panelTab: tab }),
  setSearchQuery: (q) => set({ searchQuery: q, searchOpen: q.length > 0 }),
  setSearchOpen: (open) => set({ searchOpen: open }),
  setCommandOpen: (open) => set({ commandOpen: open }),
  setActiveTab: (tab) => set({ activeTab: tab }),

  markNotificationRead: (id) =>
    set((s) => ({
      notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
    })),
  markAllNotificationsRead: () =>
    set((s) => ({
      notifications: s.notifications.map((n) => ({ ...n, read: true })),
    })),

  completeTask: (id) =>
    set((s) => ({
      tasks: s.tasks.map((t) => (t.id === id ? { ...t, status: "completed" } : t)),
    })),
  addTask: (task) =>
    set((s) => ({
      tasks: [{ ...task, id: `task-${++_taskSeq}` }, ...s.tasks],
    })),

  administerMedication: (medId) =>
    set((s) => ({
      medications: s.medications.map((m) =>
        m.id === medId
          ? { ...m, status: "administered", lastAdministered: new Date().toISOString(), nextDue: new Date(Date.now() + 8 * 3600000).toISOString() }
          : m,
      ),
    })),

  addVisitNote: (note) =>
    set((s) => ({
      visits: [{ ...note, id: `visit-${++_visitSeq}` }, ...s.visits],
    })),
}));
