// Clinical formatters — all relative time is anchored to a fixed module-load
// timestamp to guarantee server/client render match (no hydration mismatch).
import { format } from "date-fns";

// Fixed anchor set once per page load. Both server and client compute this
// at module evaluation time; since the mock data also uses this anchor,
// relative times are deterministic.
export const NOW = new Date("2026-08-01T07:00:00Z").getTime();

export function fmtDate(iso: string): string {
  return format(new Date(iso), "MMM d, yyyy");
}
export function fmtDateTime(iso: string): string {
  return format(new Date(iso), "MMM d, yyyy · HH:mm");
}
export function fmtTime(iso: string): string {
  return format(new Date(iso), "HH:mm");
}
export function fmtRelative(iso: string): string {
  const diff = NOW - new Date(iso).getTime();
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  if (day < 7) return `${day}d ago`;
  const wk = Math.floor(day / 7);
  if (wk < 5) return `${wk}w ago`;
  const mo = Math.floor(day / 30);
  return `${mo}mo ago`;
}
export function fmtAge(dob: string): number {
  const birth = new Date(dob);
  const anchor = new Date(NOW);
  let age = anchor.getFullYear() - birth.getFullYear();
  const m = anchor.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && anchor.getDate() < birth.getDate())) age--;
  return age;
}
export function fmtLengthOfStay(admitIso: string): string {
  const hours = Math.floor((NOW - new Date(admitIso).getTime()) / 3600000);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  const remH = hours % 24;
  return `${days}d ${remH}h`;
}
export function fmtTemp(c: number): string {
  return `${c.toFixed(1)}°C`;
}
export function patientName(p: { firstName: string; lastName: string; preferredName?: string }): string {
  return p.preferredName ? `${p.firstName} "${p.preferredName}" ${p.lastName}` : `${p.firstName} ${p.lastName}`;
}
export function initials(name: string): string {
  return name.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0]).join("").toUpperCase();
}
