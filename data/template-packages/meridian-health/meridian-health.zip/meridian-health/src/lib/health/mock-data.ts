// ============================================================
// Meridian Health — Deterministic mock clinical data
// Realistic patients, vitals, medications, visits, providers.
// ============================================================
import type {
  Alert,
  Appointment,
  Medication,
  Notification,
  Patient,
  Provider,
  Task,
  VisitNode,
  Vital,
} from "./types";
import { NOW } from "./format";

// ---------- Seeded PRNG ----------
function xmur3(str: string) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return h >>> 0;
  };
}
function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
type Rng = () => number;
const makeRng = (seed: string): Rng => mulberry32(xmur3(seed)());
const rint = (rng: Rng, lo: number, hi: number) => Math.floor(rng() * (hi - lo + 1)) + lo;
const rfloat = (rng: Rng, lo: number, hi: number) => rng() * (hi - lo) + lo;
const pick = <T>(rng: Rng, arr: T[]): T => arr[Math.floor(rng() * arr.length)];

// ---------- Providers ----------
const PROVIDER_SEED: Omit<Provider, "patientIds" | "availability">[] = [
  { id: "p1", name: "Dr. Sarah Chen", role: "physician", specialty: "Internal Medicine", avatarSeed: "sarah-chen", shift: "day", phone: "555-0101", pager: "555-9101", email: "s.chen@meridian.health", room: "Med Bay A" },
  { id: "p2", name: "Dr. James Okoro", role: "physician", specialty: "Cardiology", avatarSeed: "james-okoro", shift: "day", phone: "555-0102", pager: "555-9102", email: "j.okoro@meridian.health", room: "Cardiology" },
  { id: "p3", name: "Dr. Maria Santos", role: "physician", specialty: "Pulmonology", avatarSeed: "maria-santos", shift: "evening", phone: "555-0103", pager: "555-9103", email: "m.santos@meridian.health", room: "Pulmonology" },
  { id: "p4", name: "Dr. David Kim", role: "specialist", specialty: "Nephrology", avatarSeed: "david-kim", shift: "day", phone: "555-0104", pager: "555-9104", email: "d.kim@meridian.health", room: "Nephrology" },
  { id: "p5", name: "Dr. Aisha Patel", role: "specialist", specialty: "Endocrinology", avatarSeed: "aisha-patel", shift: "evening", phone: "555-0105", pager: "555-9105", email: "a.patel@meridian.health", room: "Endocrine Clinic" },
  { id: "p6", name: "Nurse Olivia Brown", role: "nurse", specialty: "ICU", avatarSeed: "olivia-brown", shift: "day", phone: "555-0201", pager: "555-9201", email: "o.brown@meridian.health", room: "ICU Station" },
  { id: "p7", name: "Nurse Marcus Reid", role: "nurse", specialty: "Medical-Surgical", avatarSeed: "marcus-reid", shift: "night", phone: "555-0202", pager: "555-9202", email: "m.reid@meridian.health", room: "Med-Surg Station" },
  { id: "p8", name: "Nurse Yuki Tanaka", role: "nurse", specialty: "Telemetry", avatarSeed: "yuki-tanaka", shift: "day", phone: "555-0203", pager: "555-9203", email: "y.tanaka@meridian.health", room: "Telemetry" },
  { id: "p9", name: "Pharm. Robert Liu", role: "pharmacist", specialty: "Clinical Pharmacy", avatarSeed: "robert-liu", shift: "day", phone: "555-0301", pager: "555-9301", email: "r.liu@meridian.health", room: "Pharmacy" },
  { id: "p10", name: "Emma Walsh, RN", role: "care-coordinator", specialty: "Discharge Planning", avatarSeed: "emma-walsh", shift: "day", phone: "555-0401", pager: "555-9401", email: "e.walsh@meridian.health", room: "Care Coordination" },
];

// ---------- Patient seeds (realistic clinical content) ----------
const PATIENT_SEED = [
  { first: "Robert", last: "Henderson", cond: "Acute Myocardial Infarction", dx: "NSTEMI with secondary HF", age: 68, sex: "M", blood: "A+", room: "ICU-204", attending: "p2", risk: 82, status: "critical", isolation: "NONE", code: "FULL", fall: false },
  { first: "Margaret", last: "Osei", cond: "Type 2 Diabetes Mellitus", dx: "T2DM with diabetic nephropathy", age: 61, sex: "F", blood: "O+", room: "MED-301", attending: "p1", risk: 45, status: "watch", isolation: "NONE", code: "FULL", fall: true },
  { first: "James", last: "Carter", cond: "Community-Acquired Pneumonia", dx: "CAP, right lower lobe", age: 54, sex: "M", blood: "B+", room: "MED-305", attending: "p3", risk: 38, status: "watch", isolation: "DROPLET", code: "FULL", fall: false },
  { first: "Eleanor", last: "Vance", cond: "Cerebrovascular Accident", dx: "Ischemic stroke, left MCA", age: 79, sex: "F", blood: "A-", room: "ICU-201", attending: "p1", risk: 88, status: "critical", isolation: "NONE", code: "DNR/DNI", fall: true },
  { first: "Michael", last: "Brennan", cond: "Chronic Kidney Disease Stage 4", dx: "CKD4 secondary to HTN", age: 58, sex: "M", blood: "O-", room: "MED-308", attending: "p4", risk: 52, status: "watch", isolation: "NONE", code: "FULL", fall: false },
  { first: "Sofia", last: "Almeida", cond: "Post-Operative Recovery", dx: "S/P laparoscopic cholecystectomy", age: 42, sex: "F", blood: "AB+", room: "SURG-102", attending: "p1", risk: 18, status: "stable", isolation: "NONE", code: "FULL", fall: false },
  { first: "Harold", last: "Fischer", cond: "Congestive Heart Failure", dx: "HFrEF EF 28%, NYHA III", age: 73, sex: "M", blood: "A+", room: "TELE-401", attending: "p2", risk: 64, status: "watch", isolation: "NONE", code: "DNR", fall: true },
  { first: "Diane", last: "Kowalski", cond: "Sepsis Recovery", dx: "Sepsis, urinary source, resolving", age: 66, sex: "F", blood: "B-", room: "ICU-203", attending: "p1", risk: 71, status: "critical", isolation: "CONTACT", code: "FULL", fall: true },
  { first: "Thomas", last: "Reed", cond: "COPD Exacerbation", dx: "AECOPD, on BiPAP", age: 71, sex: "M", blood: "O+", room: "MED-302", attending: "p3", risk: 58, status: "watch", isolation: "DROPLET", code: "FULL", fall: false },
  { first: "Priya", last: "Sharma", cond: "Gestational Diabetes", dx: "GDM at 32 weeks", age: 34, sex: "F", blood: "B+", room: "MAT-201", attending: "p5", risk: 22, status: "stable", isolation: "NONE", code: "FULL", fall: false },
  { first: "Victor", last: "Romero", cond: "Acute Pancreatitis", dx: "Mild acute pancreatitis", age: 49, sex: "M", blood: "A+", room: "MED-306", attending: "p1", risk: 35, status: "stable", isolation: "NONE", code: "FULL", fall: false },
  { first: "Beatrice", last: "Lund", cond: "Hip Fracture Post-Fall", dx: "R intertrochanteric fracture s/p ORIF", age: 84, sex: "F", blood: "O+", room: "ORT-104", attending: "p1", risk: 67, status: "watch", isolation: "NONE", code: "DNR", fall: true },
  { first: "Nathan", last: "Cole", cond: "Acute Lymphoblastic Leukemia", dx: "ALL induction phase", age: 28, sex: "M", blood: "AB-", room: "ONC-201", attending: "p4", risk: 55, status: "watch", isolation: "NEUTROPENIC", code: "FULL", fall: false },
  { first: "Grace", last: "Park", cond: "Pre-eclampsia", dx: "Severe pre-eclampsia at 36 weeks", age: 31, sex: "F", blood: "A+", room: "MAT-203", attending: "p5", risk: 74, status: "critical", isolation: "NONE", code: "FULL", fall: false },
  { first: "Arthur", last: "Doyle", cond: "Atrial Fibrillation", dx: "New-onset AFib, rate-controlled", age: 76, sex: "M", blood: "B+", room: "TELE-403", attending: "p2", risk: 41, status: "stable", isolation: "NONE", code: "DNR", fall: true },
  { first: "Lucia", last: "Marino", cond: "Gastroenteritis", dx: "Acute gastroenteritis, dehydrated", age: 45, sex: "F", blood: "O-", room: "MED-309", attending: "p1", risk: 15, status: "stable", isolation: "CONTACT", code: "FULL", fall: false },
  { first: "Edward", last: "Singh", cond: "Cellulitis, Lower Extremity", dx: "L leg cellulitis, MRSA", age: 57, sex: "M", blood: "A+", room: "MED-307", attending: "p1", risk: 28, status: "stable", isolation: "CONTACT", code: "FULL", fall: false },
  { first: "Helen", last: "Torres", cond: "End-Stage Liver Disease", dx: "ESLD, MELD 22, awaiting transplant", age: 63, sex: "F", blood: "O+", room: "ICU-202", attending: "p4", risk: 79, status: "critical", isolation: "NONE", code: "DNR/DNI", fall: true },
  { first: "Oliver", last: "Bennett", cond: "Status Epilepticus", dx: "Post-ictal, levetiracetam started", age: 39, sex: "M", blood: "AB+", room: "ICU-205", attending: "p1", risk: 76, status: "critical", isolation: "NONE", code: "FULL", fall: true },
  { first: "Charlotte", last: "Webb", cond: "Deep Vein Thrombosis", dx: "L DVT, on heparin drip", age: 52, sex: "F", blood: "A-", room: "MED-303", attending: "p2", risk: 44, status: "watch", isolation: "NONE", code: "FULL", fall: false },
  { first: "George", last: "Muller", cond: "Benign Prostatic Hyperplasia", dx: "BPH with retention, post-TURP", age: 69, sex: "M", blood: "B+", room: "SURG-105", attending: "p1", risk: 12, status: "stable", isolation: "NONE", code: "FULL", fall: false },
  { first: "Isabel", last: "Costa", cond: "Thyroid Storm", dx: "Thyrotoxic crisis, stabilizing", age: 47, sex: "F", blood: "O+", room: "ICU-206", attending: "p5", risk: 85, status: "critical", isolation: "NONE", code: "FULL", fall: false },
  { first: "Raymond", last: "Holt", cond: "Diverticulitis", dx: "Uncomplicated diverticulitis", age: 62, sex: "M", blood: "A+", room: "MED-304", attending: "p1", risk: 20, status: "stable", isolation: "NONE", code: "FULL", fall: false },
];

const ALLERGIES = ["Penicillin", "Sulfa", "Latex", "Iodine", "NSAIDs", "Morphine", "None recorded"];
const SECONDARY_DX = ["Hypertension", "Hyperlipidemia", "Hypothyroidism", "GERD", "Anxiety", "Depression", "Osteoarthritis", "Obesity", "Sleep Apnea", "Chronic Pain"];

// ---------- Build patients ----------
export function buildPatients(): Patient[] {
  const rng = makeRng("meridian-health-patients-v1");
  const now = NOW;
  return PATIENT_SEED.map((s, i) => {
    const dobYear = new Date().getFullYear() - s.age;
    const dobMonth = rint(rng, 1, 12);
    const dobDay = rint(rng, 1, 28);
    const admitDaysAgo = s.status === "critical" ? rint(rng, 1, 5) : rint(rng, 2, 14);
    const secondaryCount = rint(rng, 1, 3);
    const secondaries: string[] = [];
    for (let j = 0; j < secondaryCount; j++) {
      const dx = pick(rng, SECONDARY_DX);
      if (!secondaries.includes(dx)) secondaries.push(dx);
    }
    const allergyCount = rint(rng, 0, 2);
    const allergies: string[] = [];
    for (let j = 0; j < allergyCount; j++) {
      const a = pick(rng, ALLERGIES);
      if (!allergies.includes(a)) allergies.push(a);
    }
    if (allergies.length === 0) allergies.push("None recorded");
    return {
      id: `pt-${1001 + i}`,
      mrn: `MRN-${50001 + i}`,
      firstName: s.first,
      lastName: s.last,
      dob: `${dobYear}-${String(dobMonth).padStart(2, "0")}-${String(dobDay).padStart(2, "0")}`,
      age: s.age,
      sex: s.sex as Patient["sex"],
      bloodType: s.blood as Patient["bloodType"],
      avatarSeed: `${s.first}-${s.last}`.toLowerCase(),
      room: s.room,
      primaryCondition: s.cond,
      secondaryConditions: secondaries,
      primaryDiagnosis: s.dx,
      allergies,
      attendingId: s.attending,
      nurseId: pick(rng, ["p6", "p7", "p8"]),
      riskScore: s.risk,
      status: s.status as Patient["status"],
      admitDate: new Date(now - admitDaysAgo * 86400000 - rint(rng, 0, 12) * 3600000).toISOString(),
      careTeamIds: [s.attending, "p6", "p7", "p9"].filter((v, idx, arr) => arr.indexOf(v) === idx),
      phone: `555-${rint(rng, 1000, 9999)}`,
      emergencyContact: `${pick(rng, ["Spouse", "Son", "Daughter", "Sibling"])}`,
      insurance: pick(rng, ["Blue Cross Blue Shield", "Aetna", "UnitedHealth", "Cigna", "Medicare", "Medicaid"]),
      codeStatus: s.code as Patient["codeStatus"],
      isolation: s.isolation as Patient["isolation"],
      fallRisk: s.fall,
    } satisfies Patient;
  });
}

// ---------- Build providers (assign patients) ----------
export function buildProviders(patients: Patient[]): Provider[] {
  const availabilities: Provider["availability"][] = ["available", "busy", "in-procedure", "available", "available"];
  return PROVIDER_SEED.map((p, i) => {
    const patientIds = patients
      .filter((pt) => pt.attendingId === p.id || pt.nurseId === p.id || pt.careTeamIds.includes(p.id))
      .map((pt) => pt.id);
    return {
      ...p,
      patientIds,
      availability: p.shift === "night" ? "off-shift" : availabilities[i % availabilities.length],
    } satisfies Provider;
  });
}

// ---------- Build vitals (last 30 days, 4 readings/day) ----------
export function buildVitals(patients: Patient[]): Record<string, Vital[]> {
  const rng = makeRng("meridian-health-vitals-v1");
  const result: Record<string, Vital[]> = {};
  const now = NOW;
  for (const pt of patients) {
    const readings: Vital[] = [];
    const days = 30;
    const baseHR = pt.status === "critical" ? rint(rng, 95, 115) : pt.status === "watch" ? rint(rng, 78, 92) : rint(rng, 65, 80);
    const baseSys = pt.status === "critical" ? rint(rng, 145, 165) : rint(rng, 118, 135);
    const baseDia = pt.status === "critical" ? rint(rng, 88, 98) : rint(rng, 72, 84);
    const baseSpo2 = pt.status === "critical" ? rint(rng, 90, 94) : rint(rng, 96, 99);
    const baseTemp = pt.status === "critical" ? rfloat(rng, 37.8, 38.9) : rfloat(rng, 36.4, 37.0);
    for (let d = days - 1; d >= 0; d--) {
      for (let h = 0; h < 4; h++) {
        const hour = h * 6 + rint(rng, 0, 3);
        const ts = new Date(now - d * 86400000);
        ts.setHours(hour, rint(rng, 0, 59), 0, 0);
        // Occasional out-of-range spikes for critical/watch
        const spike = rng() < (pt.status === "critical" ? 0.35 : pt.status === "watch" ? 0.15 : 0.05);
        readings.push({
          patientId: pt.id,
          timestamp: ts.toISOString(),
          hr: baseHR + (spike ? rint(rng, 15, 35) : rint(rng, -8, 8)),
          bpSys: baseSys + (spike ? rint(rng, 15, 30) : rint(rng, -10, 10)),
          bpDia: baseDia + (spike ? rint(rng, 8, 18) : rint(rng, -6, 6)),
          rr: rint(rng, 14, 22) + (spike ? rint(rng, 3, 8) : 0),
          spo2: Math.min(100, baseSpo2 + (spike ? -rint(rng, 4, 9) : rint(rng, -1, 2))),
          temp: +(baseTemp + (spike ? rfloat(rng, 0.3, 1.2) : rfloat(rng, -0.3, 0.3))).toFixed(1),
          pain: pt.status === "critical" ? rint(rng, 4, 8) : rint(rng, 0, 4),
        });
      }
    }
    result[pt.id] = readings;
  }
  return result;
}

// ---------- Build medications ----------
const MED_CATALOG = [
  { name: "Metoprolol Tartrate", dose: "25 mg", route: "PO", freq: "BID", instr: "Hold if HR < 55" },
  { name: "Lisinopril", dose: "10 mg", route: "PO", freq: "QD", instr: "Monitor BP and renal function" },
  { name: "Atorvastatin", dose: "40 mg", route: "PO", freq: "QHS", instr: "Take at bedtime" },
  { name: "Apixaban", dose: "5 mg", route: "PO", freq: "BID", instr: "Bleeding precautions" },
  { name: "Furosemide", dose: "40 mg", route: "PO", freq: "QD", instr: "Monitor I/O and K+" },
  { name: "Pantoprazole", dose: "40 mg", route: "IV", freq: "QD", instr: "Stress ulcer prophylaxis" },
  { name: "Insulin Lispro", dose: "per sliding scale", route: "SC", freq: "AC + HS", instr: "Check glucose before administration" },
  { name: "Levetiracetam", dose: "500 mg", route: "IV", freq: "BID", instr: "For seizure prophylaxis" },
  { name: "Ceftriaxone", dose: "1 g", route: "IV", freq: "QD", instr: "For pneumonia" },
  { name: "Acetaminophen", dose: "650 mg", route: "PO", freq: "Q6H PRN", instr: "For pain/fever" },
  { name: "Morphine", dose: "2 mg", route: "IV", freq: "Q4H PRN", instr: "For severe pain" },
  { name: "Heparin Drip", dose: "per protocol", route: "IV", freq: "Continuous", instr: "Titrate per aPTT" },
];

export function buildMedications(patients: Patient[]): Medication[] {
  const rng = makeRng("meridian-health-meds-v1");
  const now = NOW;
  const meds: Medication[] = [];
  let seq = 1;
  for (const pt of patients) {
    const count = rint(rng, 3, 6);
    const selected = [...MED_CATALOG].sort(() => rng() - 0.5).slice(0, count);
    for (const m of selected) {
      const lastHoursAgo = rint(rng, 1, 12);
      const nextHoursAway = rint(rng, 1, 8);
      const lastAdmin = new Date(now - lastHoursAgo * 3600000).toISOString();
      const nextDue = new Date(now + nextHoursAway * 3600000).toISOString();
      const overdue = nextHoursAway < 0;
      const dueSoon = nextHoursAway <= 2;
      const status: Medication["status"] = overdue ? "overdue" : dueSoon ? "due" : rng() < 0.1 ? "held" : "scheduled";
      meds.push({
        id: `med-${seq++}`,
        patientId: pt.id,
        name: m.name,
        dose: m.dose,
        route: m.route as Medication["route"],
        frequency: m.freq,
        lastAdministered: status === "held" ? null : lastAdmin,
        nextDue,
        status,
        prescribedBy: pt.attendingId,
        instructions: m.instr,
      });
    }
  }
  return meds;
}

// ---------- Build visit timeline ----------
const VISIT_TEMPLATES = [
  { type: "admission", title: "Admitted from ED", author: "ED Physician", dept: "Emergency", note: "Patient arrived via EMS with acute presentation. Initial assessment completed, admitted for further management." },
  { type: "physician-note", title: "Attending Progress Note", author: "", dept: "", note: "Patient reviewed on rounds. Vitals trending. Plan: continue current management, repeat labs AM." },
  { type: "nursing-note", title: "Shift Assessment", author: "", dept: "Nursing", note: "Patient alert and oriented x3. Tolerated diet. Pain controlled with PRN. IV site patent." },
  { type: "medication", title: "Medication Administration", author: "", dept: "Nursing", note: "Administered scheduled medications per MAR. No adverse reactions observed." },
  { type: "lab", title: "Laboratory Results", author: "Lab", dept: "Pathology", note: "CBC, BMP resulted. WBC 11.2, Hgb 11.8, Creatinine 1.4. Values trended, no critical action required." },
  { type: "imaging", title: "Chest X-Ray", author: "Radiology", dept: "Radiology", note: "PA/lateral CXR: No acute cardiopulmonary process. Heart size normal. Lungs clear." },
  { type: "procedure", title: "Central Line Placement", author: "", dept: "Interventional", note: "Right IJ central line placed under sterile technique. US-guided. No complications. Dressing clean dry intact." },
  { type: "discharge-planning", title: "Discharge Planning Note", author: "", dept: "Care Coordination", note: "Case management consulted. Anticipated discharge in 2-3 days pending clinical stability. SNF placement being arranged." },
] as const;

export function buildVisits(patients: Patient[], providers: Provider[]): VisitNode[] {
  const rng = makeRng("meridian-health-visits-v1");
  const now = NOW;
  const visits: VisitNode[] = [];
  let seq = 1;
  for (const pt of patients) {
    const attending = providers.find((p) => p.id === pt.attendingId);
    const nurse = providers.find((p) => p.id === pt.nurseId);
    const visitCount = rint(rng, 6, 12);
    const admitTime = new Date(pt.admitDate).getTime();
    for (let v = 0; v < visitCount; v++) {
      const template = VISIT_TEMPLATES[v % VISIT_TEMPLATES.length];
      const ts = new Date(admitTime + (v / visitCount) * (now - admitTime) + rint(rng, 0, 4) * 3600000).toISOString();
      const author = template.type === "nursing-note" || template.type === "medication"
        ? (nurse?.name ?? "Nursing Staff")
        : (attending?.name ?? "Physician");
      const authorRole = template.type === "nursing-note" || template.type === "medication"
        ? "RN"
        : template.type === "lab" || template.type === "imaging"
          ? "Technician"
          : "MD";
      visits.push({
        id: `visit-${seq++}`,
        patientId: pt.id,
        type: template.type,
        timestamp: ts,
        author,
        authorRole,
        department: template.dept || (authorRole === "RN" ? "Nursing" : "Medicine"),
        title: template.title,
        note: template.note,
        attachments: rng() < 0.25 ? [{ name: "lab-report.pdf", type: "pdf" }] : undefined,
        priority: pt.status === "critical" && template.type === "physician-note" ? "urgent" : "routine",
      });
    }
  }
  return visits.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

// ---------- Build appointments (next 7 days) ----------
export function buildAppointments(patients: Patient[], providers: Provider[]): Appointment[] {
  const rng = makeRng("meridian-health-appts-v1");
  const now = NOW;
  const appts: Appointment[] = [];
  let seq = 1;
  const visitTypes: Appointment["visitType"][] = ["follow-up", "new-patient", "procedure", "telehealth", "urgent", "annual"];
  const statuses: Appointment["status"][] = ["scheduled", "checked-in", "in-progress", "completed", "cancelled", "no-show"];
  for (let d = 0; d < 7; d++) {
    const dayDate = new Date(now + d * 86400000);
    const count = d === 0 ? rint(rng, 4, 7) : rint(rng, 3, 9);
    for (let a = 0; a < count; a++) {
      const patient = pick(rng, patients);
      const provider = pick(rng, providers.filter((p) => p.role === "physician" || p.role === "specialist"));
      const hour = rint(rng, 8, 16);
      const minute = pick(rng, [0, 15, 30, 45]);
      appts.push({
        id: `appt-${seq++}`,
        patientId: patient.id,
        providerId: provider.id,
        date: dayDate.toISOString().split("T")[0],
        startTime: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
        durationMin: pick(rng, [15, 30, 45, 60]),
        visitType: pick(rng, visitTypes),
        room: `${pick(rng, ["Clinic A", "Clinic B", "Exam 1", "Exam 2", "Telehealth"])}-${rint(rng, 1, 9)}`,
        status: d === 0 ? pick(rng, ["scheduled", "checked-in", "in-progress", "completed"]) : d > 0 ? "scheduled" : pick(rng, statuses),
        notes: rng() < 0.3 ? "Patient requested earlier slot if available." : undefined,
      });
    }
  }
  return appts.sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime));
}

// ---------- Build tasks ----------
export function buildTasks(patients: Patient[]): Task[] {
  const rng = makeRng("meridian-health-tasks-v1");
  const now = NOW;
  const tasks: Task[] = [];
  let seq = 1;
  const taskTemplates: { title: string; cat: Task["category"]; desc: string }[] = [
    { title: "Administer scheduled medications", cat: "medication", desc: "Round of scheduled meds due" },
    { title: "Draw AM labs", cat: "lab", desc: "CBC, BMP, and medication levels" },
    { title: "Obtain chest X-ray", cat: "imaging", desc: "Portable CXR ordered" },
    { title: "Complete fall risk assessment", cat: "assessment", desc: "Morse fall scale" },
    { title: "Document nursing note", cat: "documentation", desc: "End-of-shift documentation" },
    { title: "Nephrology consult", cat: "consult", desc: "Evaluate for dialysis readiness" },
    { title: "Wound care assessment", cat: "assessment", desc: "Assess surgical site" },
    { title: "PT/OT evaluation", cat: "consult", desc: "Mobility assessment for discharge planning" },
  ];
  for (const pt of patients) {
    const count = rint(rng, 2, 5);
    for (let i = 0; i < count; i++) {
      const t = pick(rng, taskTemplates);
      const dueIn = rint(rng, -2, 8);
      const dueTime = new Date(now + dueIn * 3600000).toISOString();
      const status: Task["status"] = dueIn < 0 ? "overdue" : dueIn < 2 ? "pending" : rng() < 0.15 ? "in-progress" : "pending";
      tasks.push({
        id: `task-${seq++}`,
        patientId: pt.id,
        title: t.title,
        description: t.desc,
        dueTime,
        priority: pt.status === "critical" ? (rng() < 0.4 ? "critical" : "urgent") : pt.status === "watch" ? (rng() < 0.3 ? "urgent" : "routine") : "routine",
        status,
        assignedTo: pt.nurseId,
        category: t.cat,
      });
    }
  }
  return tasks;
}

// ---------- Build alerts ----------
export function buildAlerts(patients: Patient[]): Alert[] {
  const rng = makeRng("meridian-health-alerts-v1");
  const now = NOW;
  const alerts: Alert[] = [];
  let seq = 1;
  for (const pt of patients) {
    if (pt.isolation && pt.isolation !== "NONE") {
      alerts.push({
        id: `alert-${seq++}`,
        patientId: pt.id,
        type: "isolation",
        severity: "warning",
        title: `${pt.isolation} precautions`,
        description: `${pt.isolation.toLowerCase()} isolation protocol in effect for ${pt.lastName}`,
        timestamp: new Date(now - rint(rng, 1, 48) * 3600000).toISOString(),
        acknowledged: rng() < 0.5,
      });
    }
    if (pt.fallRisk) {
      alerts.push({
        id: `alert-${seq++}`,
        patientId: pt.id,
        type: "fall-risk",
        severity: "warning",
        title: "Fall risk",
        description: "Bed alarm active, assist with ambulation",
        timestamp: new Date(now - rint(rng, 1, 24) * 3600000).toISOString(),
        acknowledged: rng() < 0.6,
      });
    }
    if (pt.status === "critical") {
      alerts.push({
        id: `alert-${seq++}`,
        patientId: pt.id,
        type: "critical-vital",
        severity: "critical",
        title: "Critical vital signs",
        description: `${pt.lastName}: vitals outside safe range, attending notified`,
        timestamp: new Date(now - rint(rng, 0, 4) * 3600000).toISOString(),
        acknowledged: rng() < 0.3,
      });
    }
  }
  return alerts;
}

// ---------- Build notifications ----------
export function buildNotifications(): Notification[] {
  return [
    { id: "n1", type: "critical-alert", title: "Critical vital signs", body: "Henderson, R. — HR 132, BP 168/96", time: "2m ago", read: false, severity: "critical", patientId: "pt-1001" },
    { id: "n2", type: "medication-overdue", title: "Medication overdue", body: "Vance, E. — Levetiracetam 500mg IV", time: "14m ago", read: false, severity: "warning", patientId: "pt-1004" },
    { id: "n3", type: "lab-result", title: "Lab result available", body: "Kowalski, D. — Blood culture resulted", time: "38m ago", read: false, severity: "info", patientId: "pt-1008" },
    { id: "n4", type: "appointment-reminder", title: "Appointment starting soon", body: "Almeida, S. — Follow-up in 15 min", time: "1h ago", read: false, severity: "info", patientId: "pt-1006" },
    { id: "n5", type: "critical-alert", title: "Code Blue called", body: "ICU-206 — Costa, I. Thyroid storm", time: "1h ago", read: true, severity: "critical", patientId: "pt-1022" },
    { id: "n6", type: "task-assigned", title: "Task assigned to you", body: "Complete fall risk assessment — Lund, B.", time: "2h ago", read: true, severity: "info", patientId: "pt-1012" },
    { id: "n7", type: "lab-result", title: "Critical lab value", body: "Lund, H. — INR 4.2 (ref 2-3)", time: "3h ago", read: true, severity: "critical", patientId: "pt-1018" },
    { id: "n8", type: "message", title: "Message from Dr. Chen", body: "Please review Reed, T. — BiPAP settings", time: "4h ago", read: true, severity: "info", patientId: "pt-1009" },
  ];
}

// ---------- Aggregate all data ----------
export interface HealthData {
  patients: Patient[];
  providers: Provider[];
  vitals: Record<string, Vital[]>;
  medications: Medication[];
  visits: VisitNode[];
  appointments: Appointment[];
  tasks: Task[];
  alerts: Alert[];
  notifications: Notification[];
}

export function buildHealthData(): HealthData {
  const patients = buildPatients();
  const providers = buildProviders(patients);
  const vitals = buildVitals(patients);
  const medications = buildMedications(patients);
  const visits = buildVisits(patients, providers);
  const appointments = buildAppointments(patients, providers);
  const tasks = buildTasks(patients);
  const alerts = buildAlerts(patients);
  const notifications = buildNotifications();
  return { patients, providers, vitals, medications, visits, appointments, tasks, alerts, notifications };
}
