// ============================================================
// Meridian Health — Clinical data models
// ============================================================

export type PatientStatus = "stable" | "watch" | "critical";
export type Sex = "M" | "F" | "X";
export type BloodType = "A+" | "A-" | "B+" | "B-" | "AB+" | "AB-" | "O+" | "O-";

export interface Patient {
  id: string;
  mrn: string;
  firstName: string;
  lastName: string;
  preferredName?: string;
  dob: string; // ISO date
  age: number;
  sex: Sex;
  bloodType: BloodType;
  avatarSeed: string;
  room: string;
  primaryCondition: string;
  secondaryConditions: string[];
  primaryDiagnosis: string;
  allergies: string[];
  attendingId: string;
  nurseId: string;
  riskScore: number; // 0-100
  status: PatientStatus;
  admitDate: string; // ISO datetime
  careTeamIds: string[];
  phone: string;
  emergencyContact: string;
  insurance: string;
  codeStatus: "FULL" | "DNR" | "DNI" | "DNR/DNI";
  isolation: "NONE" | "CONTACT" | "DROPLET" | "AIRBORNE";
  fallRisk: boolean;
}

export interface Vital {
  patientId: string;
  timestamp: string; // ISO datetime
  hr: number; // heart rate bpm
  bpSys: number; // systolic
  bpDia: number; // diastolic
  rr: number; // respiratory rate
  spo2: number; // oxygen saturation %
  temp: number; // temperature °C
  pain: number; // 0-10
}

export interface VitalReading {
  timestamp: string;
  hr: number | null;
  bpSys: number | null;
  bpDia: number | null;
  rr: number | null;
  spo2: number | null;
  temp: number | null;
}

export type MedicationStatus = "scheduled" | "due" | "overdue" | "administered" | "held" | "cancelled";
export type MedicationRoute = "PO" | "IV" | "IM" | "SC" | "SL" | "PR" | "INH" | "TOP" | "NG";

export interface Medication {
  id: string;
  patientId: string;
  name: string;
  dose: string;
  route: MedicationRoute;
  frequency: string;
  lastAdministered: string | null; // ISO
  nextDue: string; // ISO
  status: MedicationStatus;
  prescribedBy: string;
  instructions: string;
}

export type VisitType =
  | "admission"
  | "physician-note"
  | "nursing-note"
  | "medication"
  | "lab"
  | "imaging"
  | "procedure"
  | "discharge-planning";

export interface VisitNode {
  id: string;
  patientId: string;
  type: VisitType;
  timestamp: string; // ISO
  author: string;
  authorRole: string;
  department: string;
  title: string;
  note: string;
  attachments?: { name: string; type: string }[];
  priority?: "routine" | "urgent" | "critical";
}

export type AppointmentStatus = "scheduled" | "checked-in" | "in-progress" | "completed" | "cancelled" | "no-show";
export type VisitCategory = "follow-up" | "new-patient" | "procedure" | "telehealth" | "urgent" | "annual";

export interface Appointment {
  id: string;
  patientId: string;
  providerId: string;
  date: string; // ISO date
  startTime: string; // HH:mm
  durationMin: number;
  visitType: VisitCategory;
  room: string;
  status: AppointmentStatus;
  notes?: string;
}

export type ProviderRole = "physician" | "nurse" | "specialist" | "pharmacist" | "care-coordinator";
export type Shift = "day" | "night" | "evening";

export interface Provider {
  id: string;
  name: string;
  role: ProviderRole;
  specialty: string;
  avatarSeed: string;
  shift: Shift;
  phone: string;
  pager: string;
  email: string;
  patientIds: string[];
  availability: "available" | "busy" | "off-shift" | "in-procedure";
  room: string;
}

export type TaskPriority = "routine" | "urgent" | "critical";
export type TaskStatus = "pending" | "in-progress" | "completed" | "overdue";

export interface Task {
  id: string;
  patientId: string;
  title: string;
  description: string;
  dueTime: string; // ISO
  priority: TaskPriority;
  status: TaskStatus;
  assignedTo: string;
  category: "medication" | "lab" | "imaging" | "assessment" | "documentation" | "consult";
}

export type AlertType = "medication-due" | "lab-pending" | "imaging-pending" | "fall-risk" | "isolation" | "critical-vital" | "code-status";

export interface Alert {
  id: string;
  patientId: string;
  type: AlertType;
  severity: "info" | "warning" | "critical";
  title: string;
  description: string;
  timestamp: string;
  acknowledged: boolean;
}

export type NotificationType = "lab-result" | "medication-overdue" | "appointment-reminder" | "critical-alert" | "task-assigned" | "message";

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  time: string; // relative
  read: boolean;
  patientId?: string;
  severity: "info" | "warning" | "critical";
}

// Vitals reference ranges
export const VITAL_RANGES = {
  hr: { min: 60, max: 100, unit: "bpm", label: "Heart Rate" },
  bpSys: { min: 90, max: 120, unit: "mmHg", label: "Systolic BP" },
  bpDia: { min: 60, max: 80, unit: "mmHg", label: "Diastolic BP" },
  rr: { min: 12, max: 20, unit: "rpm", label: "Respiratory Rate" },
  spo2: { min: 95, max: 100, unit: "%", label: "SpO₂" },
  temp: { min: 36.1, max: 37.2, unit: "°C", label: "Temperature" },
} as const;

export function isVitalOutOfRange(key: keyof typeof VITAL_RANGES, value: number): boolean {
  const range = VITAL_RANGES[key];
  return value < range.min || value > range.max;
}
