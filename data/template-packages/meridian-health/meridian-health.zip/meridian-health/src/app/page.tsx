import { HealthApp } from "@/components/health/HealthApp";

export default function Home() {
  return <HealthApp />;
}
