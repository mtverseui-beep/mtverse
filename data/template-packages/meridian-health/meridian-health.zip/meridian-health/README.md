# Meridian Health

Clinical patient management dashboard built with Next.js 16, React 19, TypeScript, Tailwind CSS 4, and shadcn/ui. The app is designed around active hospital-shift workflows with a live patient roster, care coordination views, appointments, reports, and settings.

## Quick Start

```bash
bun install
# or: npm install

bun run dev
# or: npm run dev
```

Open `http://localhost:3000`.

## Available Scripts

```bash
bun run dev
bun run build
bun run start
bun run lint

bun run db:generate
bun run db:push
bun run db:migrate
bun run db:reset
```

## Product Highlights

- Shift-focused healthcare dashboard with a persistent sidebar, top bar, and patient detail panel
- Patient roster with search, filtering, table density controls, and CSV export actions
- Deterministic mock clinical data for patients, providers, vitals, medications, visits, appointments, tasks, alerts, and notifications
- Dedicated views for dashboard, patients, appointments, care team, reports, profile, help, and nested settings pages
- Dark and light theme support with persisted UI preferences
- Hash-based in-app routing for multi-screen navigation without a server-backed route tree

## Tech Stack

- Next.js 16 App Router
- React 19
- TypeScript 5
- Tailwind CSS 4
- shadcn/ui + Radix UI
- Zustand
- TanStack Table / TanStack Query
- Prisma with SQLite
- Framer Motion

## Project Structure

```text
src/
  app/                     # Root Next.js app shell
  components/health/       # Meridian Health app shell and domain UI
  components/ui/           # Shared shadcn/ui primitives
  hooks/                   # Hash routing, media/query helpers
  lib/health/              # Domain types, formatters, mock-data builders
  store/health-store.ts    # App state and actions
prisma/
  schema.prisma            # Prisma schema
db/
  custom.db                # Local SQLite database
scripts/
  generate-icons.py
  theme-colors.py
```

## Navigation Model

The Next.js entry route (`src/app/page.tsx`) mounts `HealthApp`, and the product experience is handled client-side through `useHashRoute()`. Main sections currently include:

- `#/dashboard`
- `#/patients`
- `#/appointments`
- `#/care-team`
- `#/reports`
- `#/settings/...`
- `#/profile`
- `#/help`

## Notes

- Theme preference is stored under `localStorage["meridian-health-theme"]`.
- Sidebar collapse state is stored under `localStorage["meridian-health-sidebar"]`.
- Prisma is configured for SQLite through `DATABASE_URL` in `.env`.

