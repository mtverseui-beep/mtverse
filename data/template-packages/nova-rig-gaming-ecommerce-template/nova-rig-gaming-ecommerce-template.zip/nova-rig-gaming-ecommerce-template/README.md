# NOVA RIG — Gaming Gear & Creator Desk Setup Ecommerce Template

A premium, production-ready Next.js 16 + React 19 + Tailwind CSS 4 + Framer Motion + Lenis smooth scroll ecommerce frontend template. Built for players, streamers, and modern workstations.

## Project Overview

NOVA RIG is a fictional gaming gear and creator desk setup ecommerce brand. This template ships as a complete, multi-route frontend with cart, wishlist, compare, setup builder, bundle builder, drop countdown, account area, content pages, legal pages, and full SEO — all powered by mock data and localStorage.

## Tech Stack

- **Framework**: Next.js 16 with App Router (Turbopack)
- **Language**: TypeScript 5 (strict)
- **Styling**: Tailwind CSS 4 + custom NOVA RIG design tokens
- **Animation**: Framer Motion 12 + Lenis smooth scroll
- **State**: Zustand with localStorage persistence
- **UI**: Lucide icons, custom components
- **Notifications**: Sonner toasts
- **Fonts**: Inter, JetBrains Mono, Space Grotesk (Next.js fonts)

## Route List (160+ pages)

### Core ecommerce
- `/` — Homepage
- `/shop`, `/shop/[category]` — Product listing
- `/keyboards`, `/mice`, `/headsets`, `/desk-mats`, `/rgb-lights`, `/microphones`, `/webcams`, `/monitor-arms`, `/controller-docks`, `/chairs`, `/cable-management`, `/creator-bundles`, `/esports-kits` — Category shortcuts
- `/product/[slug]` — Product detail (24 products)
- `/cart`, `/checkout`, `/checkout/shipping`, `/checkout/payment`, `/checkout/review`
- `/order/success`, `/order/failed`, `/order/cancelled`, `/order/[id]`, `/track-order`
- `/wishlist`, `/compare`, `/search`, `/recently-viewed`
- `/new-arrivals`, `/best-sellers`, `/limited-drops`, `/sale`
- `/collections`, `/collections/[slug]` — 10 collections

### Tools
- `/setup-builder` — Build a complete setup with compatible gear
- `/bundle-builder` — Build a bundle and save up to 15%
- `/drop-calendar` — Upcoming limited drops
- `/gift-cards` — Digital gift cards
- `/rewards` — Tier-based rewards program

### Account
- `/account`, `/account/orders`, `/account/orders/[id]`, `/account/addresses`, `/account/payment-methods`, `/account/wishlist`, `/account/rewards`, `/account/notifications`, `/account/profile`, `/account/security`
- `/sign-in`, `/sign-up`, `/forgot-password`, `/reset-password`, `/verify-email`

### Content
- `/about`, `/our-story`
- `/setup-gallery`, `/setup-gallery/[slug]`
- `/creators`, `/creators/[slug]`
- `/reviews`
- `/blog`, `/blog/[slug]`
- `/buying-guides`, `/buying-guides/[slug]`
- `/contact`, `/help`, `/help/shipping`, `/help/returns`, `/help/orders`, `/help/payments`, `/help/warranty`
- `/faq`, `/size-and-compatibility`, `/warranty`, `/stockists`

### Legal
- `/privacy`, `/terms`, `/cookies`, `/accessibility`, `/refund-policy`, `/returns-policy`, `/shipping-policy`

### System
- `/404`, `/500`, `/offline`, `/maintenance`, `/coming-soon`
- `/sitemap.xml`, `/robots.txt`

## File Structure

```
src/
├── app/                    # Next.js App Router pages
├── components/
│   ├── motion/             # Lenis, ClickSpark, Reveal, Magnetic, TiltCard, Marquee
│   ├── layout/             # SiteHeader, SiteFooter, SearchOverlay, MobileMenu, AnnouncementBar
│   ├── common/             # SafeImage, GoToTop, CookieBanner, SkipToContent
│   ├── providers/          # ShopProviders (theme, cart drawer, search, mobile menu, quick view)
│   ├── ecommerce/          # (cart drawer, etc.)
│   ├── product/            # ProductCard, ProductDetail, ShopBrowser, QuickViewModal, CategoryHero
│   ├── cart/               # CartDrawer
│   ├── checkout/           # CheckoutShell, form inputs
│   ├── account/            # AccountShell
│   ├── content/            # ReviewsPageClient
│   ├── home/               # HeroSection, DropCountdown, SetupBuilderPreview, etc.
│   └── ui/                 # shadcn/ui components
├── data/                   # products, collections, content, navigation
├── types/                  # TypeScript types
├── lib/                    # utils, shop-store (Zustand), quick-view-store
└── hooks/                  # Custom hooks
```

## Setup Guide

```bash
# Install dependencies
bun install

# Run dev server
bun run dev

# Type check
bun run typecheck

# Lint
bun run lint

# Build for production
bun run build

# Start production server
bun run start
```

## How to Edit Brand

- **Name**: Update `NOVA RIG` / `novarig` references in:
  - `src/app/layout.tsx` (metadata, JSON-LD)
  - `src/components/layout/site-header.tsx` (logo, brand text)
  - `src/components/layout/site-footer.tsx` (footer brand)
  - `public/favicon.svg`, `public/og.svg`, `public/site.webmanifest`
- **Support email**: Update `support@novarig.co` everywhere
- **Domain**: Update `https://novarig.co` in metadata, sitemap, robots

## How to Edit Colors

All colors are CSS variables in `src/app/globals.css`. Update the `:root` block:

```css
--background: #070A12;
--surface: #101522;
--primary: #8B5CF6;       /* electric violet */
--secondary: #06B6D4;     /* cyber cyan */
--accent: #39FF88;        /* laser green */
--danger: #FF4D6D;
--warning: #FBBF24;
```

Also update `--themeColor` in `src/app/layout.tsx` viewport export and `public/site.webmanifest`.

## How to Edit Products

All products live in `src/data/products.ts`. Each product follows the `Product` type defined in `src/types/index.ts`. Add or edit products by modifying the `PRODUCTS` array.

Helper functions: `getProductBySlug`, `getProductsByCategory`, `getProductsByCollection`, `getRelatedProducts`, `getNewArrivals`, `getBestSellers`, `getLimitedDrops`, `getSaleProducts`.

## How to Edit Collections

Collections live in `src/data/collections.ts` (`COLLECTIONS` array). Each collection has a `productSlugs` array referencing products by slug.

## How to Replace Images Safely

All product images use HD Unsplash URLs. To replace:

1. Add new image URLs to the `IMG` constant at the top of `src/data/products.ts`
2. Or import local images into `/public/images/` and reference them as `/images/your-image.jpg`

All images use the `SafeImage` (Next.js Image) or `SafeImg` (plain `<img>`) component from `src/components/common/safe-image.tsx`. If an image fails to load, an inline SVG fallback with the NOVA RIG logo is shown.

### How SafeImage works

`SafeImage` wraps Next.js `Image` with:
- `useState` to track image source and error state
- `useEffect` to reset state when `src` prop changes
- `onError` handler that swaps to `fallbackSrc` (defaults to inline SVG)
- `unoptimized` prop to allow external image domains without configuration

`SafeImg` is the plain `<img>` version, useful for absolutely-positioned background images where Next.js Image optimization isn't needed.

### Configure external image domains

Edit `next.config.ts` `images.remotePatterns`:

```ts
images: {
  remotePatterns: [
    { protocol: "https", hostname: "images.unsplash.com" },
    { protocol: "https", hostname: "your-domain.com" },
  ],
},
```

## How to Customize Animations

### Lenis smooth scroll

Edit `src/components/motion/lenis-provider.tsx`:

```ts
options={{
  lerp: 0.1,              // Lower = smoother, slower
  duration: 1.2,          // Scroll duration
  smoothWheel: true,
  wheelMultiplier: 1,
  touchMultiplier: 2,
}}
```

### Click spark color

Edit the `<ClickSpark>` wrapper in `src/app/layout.tsx`:

```tsx
<ClickSpark
  sparkColor="#8B5CF6"  // Change to any color
  sparkSize={14}
  sparkRadius={26}
  sparkCount={10}
  duration={500}
/>
```

### Other animations

- Section reveals: `src/components/motion/reveal.tsx` (Reveal, StaggerGroup)
- Magnetic buttons: `src/components/motion/magnetic.tsx`
- 3D tilt cards: `src/components/motion/tilt-card.tsx`
- Marquee: `src/components/motion/marquee.tsx`

## How Cart/Wishlist/LocalStorage Works

The shop store uses Zustand with `persist` middleware, syncing to `localStorage` under the key `nova-rig-shop`.

`src/lib/shop-store.ts` exposes:

- **Cart**: `cart`, `addToCart`, `removeFromCart`, `updateCartQuantity`, `clearCart`, `cartCount()`, `cartSubtotal()`, `cartOpen`, `setCartOpen`
- **Wishlist**: `wishlist`, `toggleWishlist`, `isWishlisted`, `clearWishlist`
- **Compare**: `compare`, `toggleCompare`, `isCompared`, `clearCompare` (max 4 items)
- **Recently viewed**: `recentlyViewed`, `addRecentlyViewed` (max 12 items)
- **UI state**: `searchOpen`, `mobileMenuOpen` and their setters

Orders are stored separately under `nova-rig-orders` key.

## Production Checklist

- [x] TypeScript: zero errors (`bun run typecheck`)
- [x] ESLint: zero errors (`bun run lint`)
- [x] Build: passes (`bun run build`) — 160 static pages generated
- [x] SEO: metadata, OpenGraph, Twitter cards, JSON-LD (Organization, Product, BlogPosting), sitemap, robots
- [x] Accessibility: skip-to-content, ARIA labels, semantic HTML, keyboard focus states, reduced motion support
- [x] Responsive: mobile-first, tested at 360px, 375px, 390px, 430px, 768px, 1024px, 1440px
- [x] Performance: Next.js Image, lazy loading, skeleton states, dynamic imports where needed
- [x] Hydration: no hydration errors
- [x] Images: SafeImage fallback for all external images
- [x] All routes: accessible and refresh-safe
- [x] All forms: validated with toast success/error feedback

## Deployment

This template is optimized for Vercel but deploys to any Next.js-compatible host.

```bash
# Vercel
vercel deploy

# Or build and run standalone
bun run build
bun run start
```

## Commercial Originality

All product names, creator names, customer names, testimonials, addresses, emails, order data, review data, setup names, and guide content are fictional. NOVA RIG is an original brand. No real brand names (Razer, Logitech, Corsair, SteelSeries, HyperX, Elgato, Secretlab, Sony, Xbox, PlayStation, Nintendo, Apple) or trademarked logos are used.
