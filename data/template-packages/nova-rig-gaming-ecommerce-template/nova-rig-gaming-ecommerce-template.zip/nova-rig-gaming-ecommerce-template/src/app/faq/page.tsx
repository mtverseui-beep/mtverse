"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, HelpCircle } from "lucide-react";

const FAQS = [
  { q: "When will my order ship?", a: "Most orders ship within 1–2 business days from our Austin, TX warehouse. You'll receive a tracking number by email as soon as your order ships." },
  { q: "How long does shipping take?", a: "Standard shipping takes 3–5 business days within the contiguous US. Express (2 business days) and Overnight (next business day) are available at checkout." },
  { q: "Do you ship internationally?", a: "Yes, we ship to 80+ countries worldwide. International shipping typically takes 7–14 business days. Customs duties and import taxes are the responsibility of the recipient." },
  { q: "What is your return policy?", a: "We offer a 30-day return policy on all NOVA RIG gear. Items must be in original condition with all accessories and packaging. Email support@novarig.co to start a return." },
  { q: "What is your warranty?", a: "All NOVA RIG products come with a 2-year limited warranty. Monitor arms and chairs have a 5-year warranty. The warranty covers manufacturing defects in materials and workmanship." },
  { q: "How do I file a warranty claim?", a: "Email support@novarig.co with your order number, a description of the issue, and photos or video showing the defect. We'll respond within 24 hours with next steps." },
  { q: "Can I change or cancel my order?", a: "Yes, if you contact us within 1 hour of placing your order. After that, your order enters our fulfillment queue and changes may not be possible." },
  { q: "What payment methods do you accept?", a: "We accept Visa, Mastercard, American Express, Discover, PayPal, Apple Pay, Google Pay, and NOVA RIG gift cards." },
  { q: "Are your products compatible with Mac?", a: "Yes, all NOVA RIG gear is compatible with both Windows and macOS. Some software features (like NOVA Sync desktop app) are available on both platforms." },
  { q: "Do your products work with consoles?", a: "Most NOVA RIG products work with PS5, Xbox Series X|S, and Switch via USB-C. Check each product's compatibility list for specifics." },
  { q: "What is NOVA Sync?", a: "NOVA Sync is our unified RGB lighting system. All NOVA RIG RGB products pair through NOVA Sync for coordinated lighting presets and screen sampling." },
  { q: "Are NOVA RIG products hot-swap?", a: "Yes, all NOVA RIG mechanical keyboards have hot-swap PCBs, compatible with both 3-pin and 5-pin switches." },
  { q: "How long do the batteries last?", a: "Battery life varies by product: NovaMouse X1 Wireless: 90 hours. NovaKeys TKL Pro: 120 hours (RGB off). ClutchHead Pro: 60 hours. See each product page for specifics." },
  { q: "Can I use multiple NOVA RIG products at once?", a: "Absolutely. NOVA RIG products are designed to work together — multiple USB receivers can be replaced by a single NOVA Sync hub (included in bundles)." },
  { q: "Do you offer student or military discounts?", a: "Yes, we offer 10% off for students, teachers, military, and first responders. Verify your status at checkout via ID.me." },
  { q: "Where are NOVA RIG products made?", a: "NOVA RIG products are designed in Austin, TX and manufactured in our partner facilities in Shenzhen, China and Taiwan." },
];

export default function FAQPage() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center justify-center gap-2">
          <HelpCircle className="h-3.5 w-3.5" /> FAQ
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Frequently asked questions
        </h1>
      </div>

      <div className="space-y-2">
        {FAQS.map((item, i) => (
          <div key={i} className="rounded-xl border border-white/10 bg-[#0B0F1A] overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="flex w-full items-center justify-between p-4 text-left"
            >
              <span className="text-sm font-semibold text-foreground">{item.q}</span>
              <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${open === i ? "rotate-180" : ""}`} />
            </button>
            <AnimatePresence>
              {open === i && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="overflow-hidden"
                >
                  <p className="px-4 pb-4 text-sm text-muted-foreground">{item.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}
