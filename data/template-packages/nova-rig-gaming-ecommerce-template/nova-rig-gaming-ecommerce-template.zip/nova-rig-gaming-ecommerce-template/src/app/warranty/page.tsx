import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Warranty",
  description: "Warranty for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/warranty" },
};

export default function WarrantyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Warranty</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Warranty summary</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">All NOVA RIG products come with a 2-year limited warranty. Monitor arms and chairs have a 5-year warranty. The warranty covers manufacturing defects in materials and workmanship under normal use.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">What's covered</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Manufacturing defects, faulty switches, dead pixels, sensor failures, battery degradation beyond 50% in the first 2 years, RGB LED failures, frame cracks, and cable failures.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">What's not covered</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Damage from drops, spills, unauthorized modifications, normal wear and tear (keycap shine, PTFE foot wear), damage from using non-standard chargers or cables, and damage from natural disasters.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">How to file a claim</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Email support@novarig.co with: your order number, a description of the issue, and photos or video showing the defect. We'll respond within 24 hours with next steps.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Replacement process</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Approved warranty claims receive a replacement at no cost. We'll send a prepaid return label for the defective item and ship the replacement once we receive it. For high-priority cases (e.g. tournament in 3 days), we ship the replacement immediately.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Warranty transfers</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Warranties are tied to the original purchaser and order number. If you received a NOVA RIG product as a gift, the warranty is still valid — contact us with the gift-giver's order number.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Extended warranty</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Extended warranties (up to 5 years on all products) are available for purchase at checkout. Extended warranties add 3 years to the standard warranty period.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
