"use client";

import Link from "next/link";
import { useShopStore } from "@/lib/shop-store";
import { PRODUCTS } from "@/data/products";
import { ProductCard } from "@/components/product/product-card";
import { useQuickView } from "@/lib/quick-view-store";
import { Heart, ArrowRight, Trash2 } from "lucide-react";
import { motion } from "framer-motion";

export default function WishlistPage() {
  const { wishlist, toggleWishlist, clearWishlist } = useShopStore();
  const { openQuickView } = useQuickView();
  const items = wishlist
    .map((w) => PRODUCTS.find((p) => p.slug === w.productSlug))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-end justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl flex items-center gap-3">
            <Heart className="h-7 w-7 text-primary" /> Wishlist
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {items.length === 0 ? "No items yet." : `${items.length} ${items.length === 1 ? "item" : "items"} saved`}
          </p>
        </div>
        {items.length > 0 && (
          <button onClick={clearWishlist} className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-xs font-semibold text-foreground hover:bg-white/10">
            <Trash2 className="h-3.5 w-3.5" /> Clear all
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="grid place-items-center rounded-2xl border border-white/10 bg-[#0B0F1A] py-20 text-center">
          <div>
            <Heart className="mx-auto h-16 w-16 text-muted-foreground" />
            <h2 className="mt-4 text-xl font-bold text-foreground">Your wishlist is empty</h2>
            <p className="mt-2 text-sm text-muted-foreground">Tap the heart on any product to save it here.</p>
            <Link href="/shop" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
              Shop gear <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      ) : (
        <motion.div layout className="grid gap-4 grid-cols-2 lg:grid-cols-4">
          {items.map((p, i) => (
            <motion.div
              key={p.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: i * 0.05 }}
            >
              <ProductCard product={p} onQuickView={openQuickView} />
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
