"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { toast } from "sonner";
import Link from "next/link";

export default function Page() {
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const handleChange = (i: number, v: string) => {
    if (!/^d?$/.test(v)) return;
    setCode((prev) => {
      const next = [...prev];
      next[i] = v;
      return next;
    });
    if (v && i < 5) {
      const next = document.getElementById(`otp-${i + 1}`) as HTMLInputElement;
      next?.focus();
    }
  };
  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-8">
        <h1 className="font-display text-2xl font-black uppercase tracking-tight text-foreground text-center">Verify your email</h1>
        <p className="mt-2 text-sm text-muted-foreground text-center">Enter the 6-digit code we sent to your inbox.</p>
        <form
          onSubmit={(e) => { e.preventDefault(); toast.success("Email verified"); }}
          className="mt-6 space-y-4"
        >
          <div className="flex justify-center gap-2">
            {code.map((c, i) => (
              <input
                key={i}
                id={`otp-${i}`}
                value={c}
                onChange={(e) => handleChange(i, e.target.value)}
                maxLength={1}
                inputMode="numeric"
                className="h-12 w-12 rounded-lg border border-white/10 bg-white/5 text-center text-lg font-bold text-foreground outline-none focus:border-primary"
              />
            ))}
          </div>
          <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
            Verify email <ArrowRight className="h-4 w-4" />
          </button>
        </form>
        <p className="mt-4 text-center text-xs text-muted-foreground">
          Didn't get the code? <button onClick={() => toast.success("Code resent")} className="text-primary hover:underline">Resend</button>
        </p>
      </motion.div>
    </div>
  );
}
