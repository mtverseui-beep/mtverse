import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { PRODUCTS } from "@/data/products";

export const metadata: Metadata = {
  title: "Limited Drops — Exclusive Gaming Gear",
  description: "Shop limited-run NOVA RIG drops: exclusive colorways, limited bundles, and rare gear before they're gone.",
  alternates: { canonical: `https://novarig.co/limited-drops` },
};

export default function Page() {
  const products = PRODUCTS.filter((p) => p.badge === 'limited');
  return (
    <ShopBrowser
      products={products}
      title={"Limited drops"}
      description={"Limited-run colorways and exclusive items. Once they're gone, they're gone."}
      showCategoryFilter
    />
  );
}
