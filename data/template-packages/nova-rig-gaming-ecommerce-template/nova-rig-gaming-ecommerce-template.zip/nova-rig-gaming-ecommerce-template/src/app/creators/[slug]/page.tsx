import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { CREATORS, getCreatorBySlug } from "@/data/content";
import { getProductBySlug } from "@/data/products";
import { SafeImg } from "@/components/common/safe-image";
import { ProductCard } from "@/components/product/product-card";
import { Reveal } from "@/components/motion/reveal";
import { ArrowLeft, ArrowRight, MapPin, Users } from "lucide-react";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return CREATORS.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const c = getCreatorBySlug(slug);
  if (!c) return { title: "Creator not found" };
  return { title: `${c.name} — NOVA RIG Creator`, description: c.bio, alternates: { canonical: `https://novarig.co/creators/${c.slug}` } };
}

export default async function CreatorDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const creator = getCreatorBySlug(slug);
  if (!creator) notFound();
  const gear = creator!.gearSlugs.map((s) => getProductBySlug(s)).filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <div>
      <section className="relative h-[50vh] overflow-hidden border-b border-white/10">
        <SafeImg src={creator!.cover} alt={creator!.name} className="absolute inset-0 h-full w-full object-cover" width={1600} height={900} loading="eager" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/70 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <Link href="/creators" className="inline-flex items-center gap-1.5 text-xs font-semibold text-foreground/80 hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to creators
          </Link>
          <div className="mt-4 flex items-end gap-4">
            <SafeImg src={creator!.avatar} alt={creator!.name} className="h-20 w-20 rounded-2xl border-2 border-primary object-cover sm:h-24 sm:w-24" width={96} height={96} />
            <div>
              <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-5xl">
                {creator!.name}
              </h1>
              <p className="text-sm text-muted-foreground">{creator!.handle} · {creator!.role}</p>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground mb-3">Bio</h2>
              <p className="text-muted-foreground">{creator!.bio}</p>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-4">
                <Users className="h-5 w-5 text-primary" />
                <div className="mt-2 text-lg font-bold text-foreground">{creator!.followers}</div>
                <div className="text-xs text-muted-foreground">Followers</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-4">
                <MapPin className="h-5 w-5 text-primary" />
                <div className="mt-2 text-lg font-bold text-foreground">{creator!.location}</div>
                <div className="text-xs text-muted-foreground">Based in</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-4">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Setup type</div>
                <div className="mt-2 text-lg font-bold text-foreground">{creator!.setupType}</div>
              </div>
            </div>
          </div>

          <aside>
            <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 sticky top-32">
              <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground mb-3">Follow</h2>
              <div className="space-y-2">
                {creator!.socials.map((s) => (
                  <a key={s.label} href={s.href} className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] p-3 hover:border-primary/30">
                    <span className="text-sm font-semibold text-foreground">{s.label}</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </a>
                ))}
              </div>
              {creator!.bundleSlug && (
                <Link href={`/collections/${creator!.bundleSlug}`} className="mt-4 block rounded-lg bg-primary px-4 py-3 text-center text-sm font-bold text-white">
                  Shop {creator!.name}'s bundle
                </Link>
              )}
            </div>
          </aside>
        </div>

        <section className="mt-12 border-t border-white/10 pt-8">
          <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground mb-6">
            {creator!.name}'s gear
          </h2>
          <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
            {gear.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
