import type { Metadata } from "next";
import Link from "next/link";
import { CREATORS } from "@/data/content";
import { Reveal } from "@/components/motion/reveal";
import { TiltCard } from "@/components/motion/tilt-card";
import { SafeImg } from "@/components/common/safe-image";
import { Users, ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Creators — NOVA RIG Creator Program",
  description: "Meet the NOVA RIG creators — streamers, esports pros, and builders using our gear. Shop their setups.",
  alternates: { canonical: "https://novarig.co/creators" },
};

export default function CreatorsPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
          <Users className="h-3.5 w-3.5" /> Creators
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Meet the NOVA RIG creators
        </h1>
        <p className="mt-3 max-w-xl text-muted-foreground">
          Streamers, esports pros, and builders who use NOVA RIG gear every day. Tap any creator to shop their setup.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {CREATORS.map((c, i) => (
          <Reveal key={c.slug} delay={i * 0.06}>
            <TiltCard className="group relative aspect-[4/5] overflow-hidden rounded-2xl border border-white/10" maxTilt={8}>
              <Link href={`/creators/${c.slug}`} className="block h-full w-full">
                { }
                <img src={c.cover} alt={c.name} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/40 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <div className="flex items-center gap-3">
                    <SafeImg src={c.avatar} alt={c.name} className="h-12 w-12 rounded-full border-2 border-primary object-cover" width={48} height={48} />
                    <div className="flex-1 min-w-0">
                      <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">{c.name}</h2>
                      <p className="text-xs text-muted-foreground">{c.handle}</p>
                    </div>
                  </div>
                  <p className="mt-3 text-xs text-muted-foreground line-clamp-2">{c.bio}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-[10px] text-muted-foreground">{c.followers} followers · {c.location}</span>
                    <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-primary">
                      Shop setup <ArrowRight className="h-3 w-3" />
                    </span>
                  </div>
                </div>
              </Link>
            </TiltCard>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
