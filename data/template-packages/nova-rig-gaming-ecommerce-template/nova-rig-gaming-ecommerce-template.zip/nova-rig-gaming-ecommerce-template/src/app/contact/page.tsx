"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, MapPin, Phone, Send, MessageSquare } from "lucide-react";
import { toast } from "sonner";

const SUBJECTS = ["Order question", "Product question", "Warranty claim", "Returns", "Partnership", "Press", "Other"];

export default function ContactPage() {
  const [submitting, setSubmitting] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Message sent", { description: "We'll reply within 24 hours." });
      (e.target as HTMLFormElement).reset();
    }, 1200);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center justify-center gap-2">
          <MessageSquare className="h-3.5 w-3.5" /> Contact us
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Get in touch
        </h1>
        <p className="mt-3 max-w-xl mx-auto text-muted-foreground">
          Real human support. We reply to every email within 24 hours, Monday through Friday.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-3">
          <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-5">
            <Mail className="h-5 w-5 text-primary" />
            <h2 className="mt-2 font-bold text-foreground">Email</h2>
            <a href="mailto:support@novarig.co" className="text-sm text-primary hover:underline">support@novarig.co</a>
            <p className="mt-1 text-xs text-muted-foreground">Replies within 24h, M–F</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-5">
            <Phone className="h-5 w-5 text-primary" />
            <h2 className="mt-2 font-bold text-foreground">Phone</h2>
            <a href="tel:+1-512-555-0142" className="text-sm text-primary hover:underline">+1 (512) 555-0142</a>
            <p className="mt-1 text-xs text-muted-foreground">Mon–Fri, 9am–6pm CT</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-5">
            <MapPin className="h-5 w-5 text-primary" />
            <h2 className="mt-2 font-bold text-foreground">Mailing address</h2>
            <p className="text-sm text-muted-foreground">NOVA RIG<br />PO Box 14210<br />Austin, TX 78701</p>
          </div>
        </div>

        <motion.form
          onSubmit={submit}
          className="lg:col-span-2 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 space-y-4"
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">First name</span>
              <input required className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
            </label>
            <label className="block">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Last name</span>
              <input required className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
            </label>
          </div>
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Email</span>
            <input type="email" required className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          </label>
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Subject</span>
            <select required className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary">
              {SUBJECTS.map((s) => <option key={s} value={s} className="bg-[#101522]">{s}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Order number (optional)</span>
            <input placeholder="NR-12345678" className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          </label>
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Message</span>
            <textarea required rows={6} className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary resize-none" />
          </label>
          <button type="submit" disabled={submitting} className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white hover:bg-primary/90 disabled:opacity-60">
            {submitting ? <><span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> Sending...</> : <><Send className="h-4 w-4" /> Send message</>}
          </button>
        </motion.form>
      </div>
    </div>
  );
}
