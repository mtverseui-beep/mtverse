"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Gift, ArrowRight, Mail } from "lucide-react";
import { toast } from "sonner";
import { formatPrice } from "@/lib/utils";

const PRESETS = [25, 50, 100, 150, 250, 500];

export default function GiftCardsPage() {
  const [amount, setAmount] = useState(50);
  const [custom, setCustom] = useState("");
  const [recipient, setRecipient] = useState("");
  const [sender, setSender] = useState("");
  const [message, setMessage] = useState("");

  const finalAmount = custom ? Math.max(10, Math.min(1000, Number(custom))) : amount;

  const purchase = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Gift card purchased", { description: `${formatPrice(finalAmount)} gift card will be emailed to ${recipient || "the recipient"}.` });
    setCustom("");
    setRecipient("");
    setSender("");
    setMessage("");
  };

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-accent flex items-center justify-center gap-2">
          <Gift className="h-3.5 w-3.5" /> Gift cards
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Give the gift of gear
        </h1>
        <p className="mt-3 max-w-xl mx-auto text-muted-foreground">
          Digital gift cards delivered by email. Redeemable on any NOVA RIG gear, bundles, and drops.
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Preview card */}
        <div className="lg:sticky lg:top-32 lg:self-start">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative aspect-[3/2] overflow-hidden rounded-2xl border border-white/20 bg-gradient-to-br from-[#101522] via-[#0B0F1A] to-[#101522] p-8 shadow-2xl"
          >
            <div className="absolute inset-0 grid-bg opacity-30" />
            <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-primary/30 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-secondary/20 blur-3xl" />

            <div className="relative z-10 flex h-full flex-col justify-between">
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-display text-2xl font-bold text-foreground">
                    NOVA<span className="text-gradient-violet">RIG</span>
                  </div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">Digital gift card</div>
                </div>
                <Gift className="h-8 w-8 text-accent" />
              </div>

              <div>
                <div className="font-display text-5xl font-black text-foreground">{formatPrice(finalAmount)}</div>
                <div className="mt-2 text-xs text-muted-foreground">
                  {sender ? `From: ${sender}` : "From: NOVA RIG"}
                </div>
                {message && (
                  <p className="mt-3 text-sm italic text-muted-foreground line-clamp-2">&ldquo;{message}&rdquo;</p>
                )}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Form */}
        <form onSubmit={purchase} className="space-y-4 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Amount</label>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {PRESETS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    setAmount(p);
                    setCustom("");
                  }}
                  className={`rounded-lg border px-3 py-2 text-sm font-bold transition-colors ${
                    !custom && amount === p ? "border-primary bg-primary/15 text-primary" : "border-white/10 text-foreground hover:bg-white/5"
                  }`}
                >
                  ${p}
                </button>
              ))}
            </div>
            <input
              type="number"
              min={10}
              max={1000}
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="Custom amount ($10–$1000)"
              className="mt-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Recipient email</label>
            <input
              type="email"
              required
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="recipient@example.com"
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Your name (optional)</label>
            <input
              value={sender}
              onChange={(e) => setSender(e.target.value)}
              placeholder="From you"
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Message (optional)</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
              placeholder="Add a personal note..."
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary resize-none"
            />
          </div>

          <button
            type="submit"
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-accent px-6 py-3 text-sm font-bold text-black hover:bg-accent/90"
          >
            <Mail className="h-4 w-4" /> Purchase gift card · {formatPrice(finalAmount)}
          </button>

          <p className="text-xs text-muted-foreground">
            Gift cards are digital only and delivered by email within minutes. No expiration date.
          </p>
        </form>
      </div>
    </div>
  );
}
