"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function NotFoundPage() {
  return (
    <div className="grid min-h-[70vh] place-items-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="font-display text-7xl font-black uppercase tracking-tighter text-gradient-violet sm:text-9xl">
          404
        </div>
        <h1 className="mt-4 font-display text-2xl font-bold uppercase tracking-tight text-foreground sm:text-3xl">
          Page not found
        </h1>
        <p className="mt-2 max-w-md mx-auto text-muted-foreground">
          The page you're looking for doesn't exist or has been moved. Let's get you back on track.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white"
        >
          Back to home <ArrowRight className="h-4 w-4" />
        </Link>
      </motion.div>
    </div>
  );
}
