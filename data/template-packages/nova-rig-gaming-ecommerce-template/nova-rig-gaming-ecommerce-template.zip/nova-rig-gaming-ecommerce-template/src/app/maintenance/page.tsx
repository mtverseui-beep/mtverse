"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Wrench, ArrowRight } from "lucide-react";

export default function MaintenancePage() {
  return (
    <div className="grid min-h-[70vh] place-items-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <Wrench className="mx-auto h-16 w-16 text-warning" />
        <h1 className="mt-4 font-display text-3xl font-bold uppercase tracking-tight text-foreground sm:text-4xl">
          Under maintenance
        </h1>
        <p className="mt-2 max-w-md mx-auto text-muted-foreground">
          We're doing some quick maintenance. We'll be back in a few minutes. Thanks for your patience.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white"
        >
          Retry <ArrowRight className="h-4 w-4" />
        </Link>
      </motion.div>
    </div>
  );
}
