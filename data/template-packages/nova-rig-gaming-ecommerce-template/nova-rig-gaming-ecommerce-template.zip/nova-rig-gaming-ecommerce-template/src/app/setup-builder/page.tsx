"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { Wand2, Check, ArrowRight, RotateCcw, ShoppingCart, Plus, Minus } from "lucide-react";
import { PRODUCTS, getProductBySlug } from "@/data/products";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice, cn } from "@/lib/utils";
import { toast } from "sonner";

const SETUP_TYPES = [
  { id: "gaming", label: "Gaming", desc: "Competitive FPS, MOBA, and battle royale gear" },
  { id: "streaming", label: "Streaming", desc: "Mic, cam, lighting, and cable management" },
  { id: "creator", label: "Creator desk", desc: "Productivity, content, and editing gear" },
  { id: "minimal", label: "Minimal workspace", desc: "Carbon-only, clean, and quiet" },
];

const STEPS = [
  { id: "keyboard", label: "Keyboard", category: "keyboards" as const },
  { id: "mouse", label: "Mouse", category: "mice" as const },
  { id: "headset", label: "Headset", category: "headsets" as const },
  { id: "mat", label: "Desk mat", category: "desk-mats" as const },
  { id: "mic", label: "Microphone", category: "microphones" as const },
  { id: "light", label: "RGB light", category: "rgb-lights" as const },
];

function SetupBuilderContent() {
  const params = useSearchParams();
  const initialType = params.get("type");
  const [setupType, setSetupType] = useState<string | null>(initialType);
  const [stepIdx, setStepIdx] = useState(0);
  const [selections, setSelections] = useState<Record<string, string | null>>({});
  const { addToCart } = useShopStore();

  useEffect(() => {
    if (initialType) setSetupType(initialType);
  }, [initialType]);

  const currentStep = STEPS[stepIdx];
  const availableProducts = PRODUCTS.filter((p) => p.category === currentStep.category);

  const selectedProducts = Object.entries(selections)
    .map(([_, slug]) => (slug ? getProductBySlug(slug) : null))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));
  const totalPrice = selectedProducts.reduce((acc, p) => acc + p.price, 0);

  const handleSelect = (slug: string) => {
    setSelections((prev) => ({ ...prev, [currentStep.id]: prev[currentStep.id] === slug ? null : slug }));
  };

  const nextStep = () => setStepIdx((i) => Math.min(STEPS.length - 1, i + 1));
  const prevStep = () => setStepIdx((i) => Math.max(0, i - 1));
  const reset = () => {
    setSelections({});
    setStepIdx(0);
    setSetupType(null);
  };

  const addAllToCart = () => {
    selectedProducts.forEach((p) => {
      addToCart({
        productSlug: p.slug,
        name: p.name,
        image: p.images[0],
        price: p.price,
        quantity: 1,
        variant: p.variants[0]?.value,
        color: p.colors[0]?.name,
      });
    });
    toast.success(`Added ${selectedProducts.length} items to cart`);
  };

  // Setup type selection
  if (!setupType) {
    return (
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center justify-center gap-2">
            <Wand2 className="h-3.5 w-3.5" /> Setup builder
          </span>
          <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
            Pick your setup type
          </h1>
          <p className="mt-3 max-w-xl mx-auto text-muted-foreground">
            We'll recommend a complete, compatible gear list. Adjust as you go.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {SETUP_TYPES.map((t, i) => (
            <motion.button
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              onClick={() => setSetupType(t.id)}
              className="group text-left rounded-2xl border border-white/10 bg-[#101522] p-6 hover:border-primary/40 transition-colors"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">{t.label}</h2>
                <ArrowRight className="h-5 w-5 text-primary opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{t.desc}</p>
            </motion.button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
            <Wand2 className="h-3.5 w-3.5" /> {SETUP_TYPES.find((t) => t.id === setupType)?.label} setup
          </span>
          <h1 className="mt-2 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
            Build your rig
          </h1>
        </div>
        <button onClick={reset} className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-foreground hover:bg-white/10">
          <RotateCcw className="h-4 w-4" /> Reset
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Step + products */}
        <div className="lg:col-span-2">
          {/* Stepper */}
          <div className="mb-6 flex items-center gap-2 overflow-x-auto pb-2">
            {STEPS.map((s, i) => {
              const isDone = selections[s.id];
              const isActive = i === stepIdx;
              return (
                <button
                  key={s.id}
                  onClick={() => setStepIdx(i)}
                  className={cn(
                    "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors",
                    isActive ? "border-primary bg-primary/15 text-primary" : isDone ? "border-accent/40 bg-accent/10 text-accent" : "border-white/10 text-muted-foreground hover:text-foreground",
                  )}
                >
                  <div className={cn(
                    "grid h-5 w-5 place-items-center rounded-full text-[10px]",
                    isActive ? "bg-primary text-white" : isDone ? "bg-accent text-black" : "bg-white/10",
                  )}>
                    {isDone ? <Check className="h-3 w-3" /> : i + 1}
                  </div>
                  {s.label}
                </button>
              );
            })}
          </div>

          <h2 className="mb-4 text-xl font-bold text-foreground">
            Choose your {currentStep.label.toLowerCase()}
          </h2>

          <div className="grid gap-3 sm:grid-cols-2">
            <AnimatePresence mode="popLayout">
              {availableProducts.map((p, i) => {
                const selected = selections[currentStep.id] === p.slug;
                return (
                  <motion.button
                    key={p.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ delay: i * 0.04 }}
                    onClick={() => handleSelect(p.slug)}
                    className={cn(
                      "group relative flex gap-3 rounded-xl border p-4 text-left transition-colors",
                      selected ? "border-primary bg-primary/10" : "border-white/10 bg-[#101522] hover:border-white/30",
                    )}
                  >
                    <SafeImg src={p.images[0]} alt={p.name} className="h-20 w-20 shrink-0 rounded-lg object-cover" width={80} height={80} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-foreground line-clamp-1">{p.name}</div>
                      <div className="mt-0.5 text-xs text-muted-foreground line-clamp-2">{p.shortDescription}</div>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="font-bold text-primary">{formatPrice(p.price)}</span>
                        {selected && (
                          <span className="inline-flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-white">
                            <Check className="h-3 w-3" /> Selected
                          </span>
                        )}
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </AnimatePresence>
          </div>

          {/* Navigation */}
          <div className="mt-6 flex justify-between">
            <button
              onClick={prevStep}
              disabled={stepIdx === 0}
              className="rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-foreground hover:bg-white/10 disabled:opacity-50"
            >
              Previous
            </button>
            {stepIdx < STEPS.length - 1 ? (
              <button
                onClick={nextStep}
                className="rounded-lg bg-primary px-6 py-2 text-sm font-bold text-white hover:bg-primary/90"
              >
                Next step
              </button>
            ) : (
              <button
                onClick={addAllToCart}
                disabled={selectedProducts.length === 0}
                className="inline-flex items-center gap-2 rounded-lg bg-accent px-6 py-2 text-sm font-bold text-black hover:bg-accent/90 disabled:opacity-50"
              >
                <ShoppingCart className="h-4 w-4" /> Add setup to cart
              </button>
            )}
          </div>
        </div>

        {/* Summary */}
        <aside>
          <div className="sticky top-32 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground mb-4">
              Your setup
            </h2>

            {selectedProducts.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Select gear to start building your setup. Your selections will appear here.
              </p>
            ) : (
              <div className="space-y-3">
                {selectedProducts.map((p) => (
                  <motion.div
                    key={p.id}
                    layout
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-3 rounded-lg border border-white/10 bg-white/[0.02] p-2"
                  >
                    <SafeImg src={p.images[0]} alt={p.name} className="h-12 w-12 rounded-md object-cover" width={48} height={48} />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-foreground line-clamp-1">{p.name}</div>
                      <div className="text-xs text-primary">{formatPrice(p.price)}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}

            <div className="mt-4 border-t border-white/10 pt-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">{selectedProducts.length} items</span>
                <span className="font-display text-xl font-black text-foreground">{formatPrice(totalPrice)}</span>
              </div>
              {selectedProducts.length >= 3 && (
                <p className="mt-2 text-xs text-accent">
                  <Check className="inline h-3 w-3" /> Setup looks great. Ready to add to cart.
                </p>
              )}
            </div>

            <Link
              href="/bundle-builder"
              className="mt-4 block rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-center text-xs font-semibold text-foreground hover:bg-white/10"
            >
              Or try bundle builder
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}

export default function SetupBuilderPage() {
  return (
    <Suspense fallback={<div className="py-20 text-center text-muted-foreground">Loading...</div>}>
      <SetupBuilderContent />
    </Suspense>
  );
}
