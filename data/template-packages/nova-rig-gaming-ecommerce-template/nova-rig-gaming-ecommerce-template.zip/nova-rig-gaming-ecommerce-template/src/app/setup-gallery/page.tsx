import type { Metadata } from "next";
import { SETUP_GALLERY } from "@/data/content";
import { SafeImg } from "@/components/common/safe-image";
import { Reveal } from "@/components/motion/reveal";
import { TiltCard } from "@/components/motion/tilt-card";
import Link from "next/link";
import { ArrowRight, Images } from "lucide-react";

export const metadata: Metadata = {
  title: "Setup Gallery — Real NOVA RIG Setups",
  description: "Browse real gaming, streaming, and creator setups built with NOVA RIG gear. Tap any setup to shop the gear.",
  alternates: { canonical: "https://novarig.co/setup-gallery" },
};

export default function SetupGalleryPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-accent flex items-center gap-2">
          <Images className="h-3.5 w-3.5" /> Setup gallery
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Real NOVA RIG setups
        </h1>
        <p className="mt-3 max-w-xl text-muted-foreground">
          Browse setups built by NOVA RIG creators and the community. Tap any setup to shop the gear.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {SETUP_GALLERY.map((s, i) => (
          <Reveal key={s.slug} delay={i * 0.06}>
            <TiltCard className="group relative aspect-[4/5] overflow-hidden rounded-2xl border border-white/10" maxTilt={8}>
              <Link href={`/setup-gallery/${s.slug}`} className="block h-full w-full">
                { }
                <img src={s.image} alt={s.title} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-transparent to-transparent" />
                <div className="absolute top-4 left-4 flex gap-1.5">
                  <span className="rounded-full border border-white/20 bg-black/50 backdrop-blur px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-foreground">
                    {s.type}
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h2 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">{s.title}</h2>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{s.description}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-[10px] text-muted-foreground">{s.gearSlugs.length} pieces · by {s.creator}</span>
                    <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-accent">
                      Shop <ArrowRight className="h-3 w-3" />
                    </span>
                  </div>
                </div>
              </Link>
            </TiltCard>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
