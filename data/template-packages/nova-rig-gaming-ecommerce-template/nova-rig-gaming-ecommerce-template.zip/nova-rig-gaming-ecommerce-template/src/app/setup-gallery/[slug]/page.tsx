import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { SETUP_GALLERY, getSetupBySlug } from "@/data/content";
import { getProductBySlug } from "@/data/products";
import { SafeImg } from "@/components/common/safe-image";
import { ProductCard } from "@/components/product/product-card";
import { ArrowRight, ArrowLeft, Check } from "lucide-react";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return SETUP_GALLERY.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const s = getSetupBySlug(slug);
  if (!s) return { title: "Setup not found" };
  return { title: s.title, description: s.description, alternates: { canonical: `https://novarig.co/setup-gallery/${s.slug}` } };
}

export default async function SetupDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const setup = getSetupBySlug(slug);
  if (!setup) notFound();
  const gear = setup!.gearSlugs.map((s) => getProductBySlug(s)).filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <div>
      <section className="relative h-[60vh] overflow-hidden border-b border-white/10">
        <SafeImg src={setup!.image} alt={setup!.title} className="absolute inset-0 h-full w-full object-cover" width={1600} height={900} loading="eager" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <Link href="/setup-gallery" className="inline-flex items-center gap-1.5 text-xs font-semibold text-foreground/80 hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to gallery
          </Link>
          <div className="mt-4 flex flex-wrap gap-2">
            {setup!.tags.map((t) => (
              <span key={t} className="rounded-full border border-white/20 bg-black/50 backdrop-blur px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-foreground">
                {t}
              </span>
            ))}
          </div>
          <h1 className="mt-4 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
            {setup!.title}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">by {setup!.creator}</p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground mb-3">About this setup</h2>
              <p className="text-muted-foreground">{setup!.description}</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-5">
              <h3 className="font-bold text-foreground mb-2">Creator notes</h3>
              <p className="text-sm text-muted-foreground">{setup!.notes}</p>
            </div>
          </div>

          <aside>
            <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 sticky top-32">
              <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground mb-3">Setup summary</h2>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2 text-foreground">
                  <Check className="h-4 w-4 text-accent" /> {gear.length} pieces of gear
                </li>
                <li className="flex items-center gap-2 text-foreground">
                  <Check className="h-4 w-4 text-accent" /> Setup type: {setup!.type}
                </li>
                <li className="flex items-center gap-2 text-foreground">
                  <Check className="h-4 w-4 text-accent" /> NOVA Sync compatible
                </li>
              </ul>
              <Link href="/setup-builder" className="mt-5 block rounded-lg bg-primary px-4 py-3 text-center text-sm font-bold text-white">
                Build this setup
              </Link>
            </div>
          </aside>
        </div>

        <section className="mt-12 border-t border-white/10 pt-8">
          <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground mb-6">
            Shop this setup
          </h2>
          <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
            {gear.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
