import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "desk-mats" as const;

export const metadata: Metadata = {
  title: "Desk Mats",
  description: "Tournament-grade desk pads with hybrid speed-control weave and spill-proof coating.",
  alternates: { canonical: `https://novarig.co/desk-mats` },
};

export default function DeskmatsPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Desk Mats"} description={`${products.length} products in the Desk Mats collection.`} showCategoryFilter={false} />
    </>
  );
}
