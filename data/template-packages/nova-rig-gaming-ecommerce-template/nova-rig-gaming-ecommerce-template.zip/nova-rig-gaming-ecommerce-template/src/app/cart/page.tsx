"use client";

import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, Truck, ShieldCheck, RotateCcw, X } from "lucide-react";
import { useState } from "react";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice } from "@/lib/utils";
import { PRODUCTS } from "@/data/products";
import { ProductCard } from "@/components/product/product-card";
import { useQuickView } from "@/lib/quick-view-store";

const FREE_SHIPPING_THRESHOLD = 99;
const TAX_RATE = 0.0825;

export default function CartPage() {
  const { cart, updateCartQuantity, removeFromCart, cartSubtotal } = useShopStore();
  const { openQuickView } = useQuickView();
  const [coupon, setCoupon] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [giftCard, setGiftCard] = useState("");
  const [notes, setNotes] = useState("");

  const subtotal = cartSubtotal();
  const discount = appliedCoupon === "NOVA10" ? subtotal * 0.1 : 0;
  const shipping = subtotal - discount >= FREE_SHIPPING_THRESHOLD ? 0 : 9.99;
  const tax = Math.max(0, (subtotal - discount) * TAX_RATE);
  const total = subtotal - discount + shipping + tax;
  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - (subtotal - discount));
  const progress = Math.min(100, ((subtotal - discount) / FREE_SHIPPING_THRESHOLD) * 100);

  const recommended = PRODUCTS.filter((p) => !cart.find((c) => c.productSlug === p.slug)).slice(0, 4);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl mb-6">
        Your cart
      </h1>

      {cart.length === 0 ? (
        <div className="grid place-items-center rounded-2xl border border-white/10 bg-[#0B0F1A] py-20 text-center">
          <div>
            <ShoppingBag className="mx-auto h-16 w-16 text-muted-foreground" />
            <h2 className="mt-4 text-xl font-bold text-foreground">Your cart is empty</h2>
            <p className="mt-2 text-sm text-muted-foreground">Add gear to start building your rig.</p>
            <Link
              href="/shop"
              className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white"
            >
              Shop gear <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Items */}
          <div className="lg:col-span-2 space-y-4">
            {/* Free shipping progress */}
            <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-4">
              <div className="flex items-center gap-2 text-sm mb-2">
                <Truck className="h-4 w-4 text-primary" />
                {remaining > 0 ? (
                  <span className="text-muted-foreground">
                    Add <span className="font-bold text-accent">{formatPrice(remaining)}</span> for free shipping
                  </span>
                ) : (
                  <span className="text-accent font-semibold">You unlocked free shipping</span>
                )}
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-primary via-secondary to-accent"
                  animate={{ width: `${progress}%` }}
                  transition={{ type: "spring", stiffness: 100, damping: 20 }}
                />
              </div>
            </div>

            <AnimatePresence>
              {cart.map((item) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="flex gap-4 rounded-2xl border border-white/10 bg-[#0B0F1A] p-4"
                >
                  <SafeImg
                    src={item.image}
                    alt={item.name}
                    className="h-24 w-24 shrink-0 rounded-lg object-cover bg-white/5"
                    width={96}
                    height={96}
                  />
                  <div className="flex-1 min-w-0">
                    <Link href={`/product/${item.productSlug}`} className="font-bold text-foreground hover:text-primary">
                      {item.name}
                    </Link>
                    {(item.variant || item.color) && (
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {[item.variant, item.color].filter(Boolean).join(" · ")}
                      </p>
                    )}
                    <div className="mt-2 flex items-center gap-3">
                      <div className="flex items-center rounded-md border border-white/10">
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                          className="grid h-8 w-8 place-items-center text-foreground hover:bg-white/5"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-10 text-center text-sm font-bold text-foreground">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                          className="grid h-8 w-8 place-items-center text-foreground hover:bg-white/5"
                          aria-label="Increase quantity"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-xs text-muted-foreground hover:text-danger flex items-center gap-1"
                      >
                        <Trash2 className="h-3 w-3" /> Remove
                      </button>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-foreground">{formatPrice(item.price * item.quantity)}</div>
                    <div className="text-xs text-muted-foreground">{formatPrice(item.price)} each</div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Order notes */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Order notes (optional)</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Gift wrap, delivery instructions, etc."
                rows={3}
                className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary resize-none"
              />
            </div>
          </div>

          {/* Summary */}
          <div className="space-y-4">
            <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 sticky top-32">
              <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground mb-4">
                Order summary
              </h2>

              {/* Coupon */}
              <div className="mb-4">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                  <Tag className="h-3 w-3" /> Coupon code
                </label>
                <div className="mt-1 flex gap-2">
                  <input
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value.toUpperCase())}
                    placeholder="Try NOVA10"
                    className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
                  />
                  <button
                    onClick={() => {
                      if (coupon === "NOVA10") {
                        setAppliedCoupon(coupon);
                      } else if (coupon) {
                        import("sonner").then(({ toast }) => toast.error("Invalid coupon code"));
                      }
                    }}
                    className="rounded-lg bg-white/10 px-4 py-2 text-sm font-semibold text-foreground hover:bg-white/20"
                  >
                    Apply
                  </button>
                </div>
                {appliedCoupon && (
                  <div className="mt-2 flex items-center justify-between rounded-md bg-accent/10 px-3 py-1.5 text-xs">
                    <span className="text-accent font-semibold">{appliedCoupon} applied (10% off)</span>
                    <button
                      onClick={() => setAppliedCoupon(null)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>

              {/* Gift card */}
              <div className="mb-4">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Gift card</label>
                <div className="mt-1 flex gap-2">
                  <input
                    value={giftCard}
                    onChange={(e) => setGiftCard(e.target.value)}
                    placeholder="Gift card number"
                    className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
                  />
                  <button className="rounded-lg bg-white/10 px-4 py-2 text-sm font-semibold text-foreground hover:bg-white/20">
                    Apply
                  </button>
                </div>
              </div>

              {/* Totals */}
              <div className="space-y-2 text-sm border-t border-white/10 pt-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-semibold text-foreground">{formatPrice(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-accent">
                    <span>Discount</span>
                    <span>-{formatPrice(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="font-semibold text-foreground">
                    {shipping === 0 ? <span className="text-accent">Free</span> : formatPrice(shipping)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Estimated tax</span>
                  <span className="font-semibold text-foreground">{formatPrice(tax)}</span>
                </div>
                <div className="flex justify-between border-t border-white/10 pt-3 text-base">
                  <span className="font-bold text-foreground">Total</span>
                  <span className="font-display text-xl font-black text-foreground">{formatPrice(total)}</span>
                </div>
              </div>

              <Link
                href="/checkout"
                className="mt-5 flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 hover:bg-primary/90"
              >
                Checkout · {formatPrice(total)} <ArrowRight className="h-4 w-4" />
              </Link>

              <div className="mt-4 space-y-1 text-xs text-muted-foreground">
                <div className="flex items-center gap-2"><ShieldCheck className="h-3.5 w-3.5 text-primary" /> Secure encrypted checkout</div>
                <div className="flex items-center gap-2"><RotateCcw className="h-3.5 w-3.5 text-primary" /> 30-day returns</div>
                <div className="flex items-center gap-2"><Truck className="h-3.5 w-3.5 text-primary" /> Ships in 1–2 business days</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Recommended */}
      {cart.length > 0 && recommended.length > 0 && (
        <section className="mt-12 border-t border-white/10 pt-8">
          <h2 className="font-display text-xl font-bold uppercase tracking-tight text-foreground mb-4">
            Complete your setup
          </h2>
          <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
            {recommended.map((p) => (
              <ProductCard key={p.id} product={p} onQuickView={openQuickView} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
