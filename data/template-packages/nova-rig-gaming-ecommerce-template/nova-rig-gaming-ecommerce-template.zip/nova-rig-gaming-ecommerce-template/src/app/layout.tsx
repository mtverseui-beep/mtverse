import type { Metadata, Viewport } from "next";
import { Inter, JetBrains_Mono, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { LenisProvider } from "@/components/motion/lenis-provider";
import { ClickSpark } from "@/components/motion/click-spark";
import { ShopProviders } from "@/components/providers/shop-providers";
import { SiteHeader } from "@/components/layout/site-header";
import { SiteFooter } from "@/components/layout/site-footer";
import { GoToTop } from "@/components/common/go-to-top";
import { CookieBanner } from "@/components/common/cookie-banner";
import { SkipToContent } from "@/components/common/skip-to-content";

const inter = Inter({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-display-fam",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://novarig.co"),
  title: {
    default: "NOVA RIG — Gaming Gear & Creator Desk Setup Store",
    template: "%s | NOVA RIG",
  },
  description:
    "Shop premium gaming keyboards, mice, headsets, RGB desk lights, microphones, webcams, creator bundles, and esports setup gear from NOVA RIG. Built for players, streamers, and modern workstations.",
  keywords: [
    "gaming keyboard",
    "gaming mouse",
    "gaming headset",
    "RGB desk lights",
    "streaming microphone",
    "creator desk setup",
    "esports gear",
    "NOVA RIG",
    "desk mat",
    "monitor arm",
    "webcam",
    "controller dock",
  ],
  authors: [{ name: "NOVA RIG" }],
  creator: "NOVA RIG",
  publisher: "NOVA RIG",
  applicationName: "NOVA RIG",
  formatDetection: { telephone: false, address: false, email: false },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/favicon.svg",
  },
  manifest: "/site.webmanifest",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://novarig.co",
    siteName: "NOVA RIG",
    title: "NOVA RIG — Gaming Gear & Creator Desk Setup Store",
    description:
      "Shop premium gaming keyboards, mice, headsets, RGB desk lights, microphones, webcams, creator bundles, and esports setup gear from NOVA RIG.",
    images: [
      {
        url: "/og.svg",
        width: 1200,
        height: 630,
        alt: "NOVA RIG — Gaming Gear & Creator Desk Setup Store",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "NOVA RIG — Gaming Gear & Creator Desk Setup Store",
    description:
      "Premium gaming gear, creator desk upgrades, and limited setup drops built for players, streamers, and modern workstations.",
    images: ["/og.svg"],
    creator: "@novarig",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  category: "technology",
  alternates: { canonical: "https://novarig.co" },
};

export const viewport: Viewport = {
  themeColor: "#070A12",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  colorScheme: "dark",
};

const orgJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "NOVA RIG",
  url: "https://novarig.co",
  logo: "https://novarig.co/favicon.svg",
  description:
    "Premium gaming gear, creator desk upgrades, and limited setup drops for players, streamers, and modern workstations.",
  email: "support@novarig.co",
  sameAs: [
    "https://twitter.com/novarig",
    "https://instagram.com/novarig",
    "https://youtube.com/@novarig",
    "https://tiktok.com/@novarig",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }}
        />
      </head>
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} ${spaceGrotesk.variable} antialiased`}
      >
        <ClickSpark
          sparkColor="#8B5CF6"
          sparkSize={14}
          sparkRadius={26}
          sparkCount={10}
          duration={500}
          easing="ease-out"
        >
          <LenisProvider>
            <ShopProviders>
              <SkipToContent />
              <SiteHeader />
              <main id="main-content" className="min-h-screen relative">
                {children}
              </main>
              <SiteFooter />
              <GoToTop />
              <CookieBanner />
            </ShopProviders>
          </LenisProvider>
        </ClickSpark>
        <Toaster />
        <SonnerToaster position="bottom-right" theme="dark" />
      </body>
    </html>
  );
}
