import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "webcams" as const;

export const metadata: Metadata = {
  title: "Webcams",
  description: "4K streaming webcams with Sony STARVIS sensors and AI autofocus.",
  alternates: { canonical: `https://novarig.co/webcams` },
};

export default function WebcamsPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Webcams"} description={`${products.length} products in the Webcams collection.`} showCategoryFilter={false} />
    </>
  );
}
