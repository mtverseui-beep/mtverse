import { HeroSection } from "@/components/home/hero-section";
import { DropCountdown } from "@/components/home/drop-countdown";
import { FeaturedGearCarousel } from "@/components/home/featured-carousel";
import { BentoFeatures } from "@/components/home/bento-features";
import { PerformanceSpecs } from "@/components/home/performance-specs";
import { RgbSetupGallery } from "@/components/home/rgb-setup-gallery";
import { CreatorBundleSection } from "@/components/home/creator-bundle-section";
import { ReviewsSocialProof } from "@/components/home/reviews-social-proof";
import { NewsletterSection } from "@/components/home/newsletter-section";
import { getBestSellers, getNewArrivals, getLimitedDrops } from "@/data/products";

export default function HomePage() {
  const featured = [
    ...getNewArrivals(2),
    ...getBestSellers(4),
    ...getLimitedDrops(2),
  ];

  return (
    <>
      <HeroSection />
      <DropCountdown />
      <FeaturedGearCarousel products={featured} eyebrow="Featured gear" title="Built for the next match" />
      <BentoFeatures />
      <PerformanceSpecs />
      <RgbSetupGallery />
      <CreatorBundleSection />
      <ReviewsSocialProof />
      <NewsletterSection />
    </>
  );
}
