import type { Metadata } from "next";
import Link from "next/link";
import { Truck, ArrowRight, ChevronLeft } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Shipping — Help Center",
  description: "Shipping help and FAQ from NOVA RIG support.",
  alternates: { canonical: "https://novarig.co/help/shipping" },
};

export default function HelpShippingPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/help" className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="h-3.5 w-3.5" /> Help center
      </Link>
      <div className="flex items-center gap-3 mb-8">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary">
          <Truck className="h-6 w-6" />
        </div>
        <h1 className="font-display text-3xl font-black uppercase tracking-tighter text-foreground sm:text-4xl">Shipping</h1>
      </div>

      <div className="space-y-6">
        
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Shipping times</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Most orders ship within 1–2 business days from our Austin, TX warehouse. Standard shipping takes 3–5 business days within the contiguous US. Express shipping (2 business days) and Overnight (next business day) are available at checkout.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Free shipping</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Free standard shipping is included on all orders over $99 within the contiguous US. Orders under $99 ship for a flat $9.99.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">International shipping</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We ship to 80+ countries worldwide. International shipping times vary by destination, typically 7–14 business days. Customs duties and import taxes are the responsibility of the recipient.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Tracking your order</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">You'll receive a tracking number by email as soon as your order ships. You can also track your order anytime at /track-order.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Order changes</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Need to change your shipping address? Contact us within 1 hour of placing your order. After that, the order enters our fulfillment queue and changes may not be possible.</p>
          </section>
        </Reveal>
      </div>

      <div className="mt-10 rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] to-[#0B0F1A] p-6 text-center">
        <h2 className="font-bold text-foreground">Still need help?</h2>
        <p className="mt-1 text-sm text-muted-foreground">Our support team replies within 24 hours.</p>
        <Link href="/contact" className="mt-3 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-bold text-white">
          Contact us <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
