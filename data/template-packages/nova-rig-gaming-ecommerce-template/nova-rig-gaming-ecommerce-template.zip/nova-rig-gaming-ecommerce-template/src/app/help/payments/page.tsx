import type { Metadata } from "next";
import Link from "next/link";
import { CreditCard, ArrowRight, ChevronLeft } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Payments — Help Center",
  description: "Payments help and FAQ from NOVA RIG support.",
  alternates: { canonical: "https://novarig.co/help/payments" },
};

export default function HelpPaymentsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/help" className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="h-3.5 w-3.5" /> Help center
      </Link>
      <div className="flex items-center gap-3 mb-8">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary">
          <CreditCard className="h-6 w-6" />
        </div>
        <h1 className="font-display text-3xl font-black uppercase tracking-tighter text-foreground sm:text-4xl">Payments</h1>
      </div>

      <div className="space-y-6">
        
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Accepted payment methods</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We accept Visa, Mastercard, American Express, Discover, PayPal, Apple Pay, Google Pay, and NOVA RIG gift cards.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">When am I charged?</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Your card is charged at the time of order placement. For pre-orders, your card is charged immediately to reserve your item.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Sales tax</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Sales tax is collected where required by law, based on your shipping address. The exact amount is shown at checkout before you place your order.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Currency</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">All prices are in USD. International orders may be charged a currency conversion fee by your bank.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Payment failed</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">If your payment fails, check that your card details are correct and that your bank isn't blocking the transaction. Try a different card or payment method if the issue persists.</p>
          </section>
        </Reveal>
      </div>

      <div className="mt-10 rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] to-[#0B0F1A] p-6 text-center">
        <h2 className="font-bold text-foreground">Still need help?</h2>
        <p className="mt-1 text-sm text-muted-foreground">Our support team replies within 24 hours.</p>
        <Link href="/contact" className="mt-3 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-bold text-white">
          Contact us <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
