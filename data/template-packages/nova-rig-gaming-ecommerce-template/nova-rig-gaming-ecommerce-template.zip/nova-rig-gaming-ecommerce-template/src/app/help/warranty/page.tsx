import type { Metadata } from "next";
import Link from "next/link";
import { ShieldCheck, ArrowRight, ChevronLeft } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Warranty — Help Center",
  description: "Warranty help and FAQ from NOVA RIG support.",
  alternates: { canonical: "https://novarig.co/help/warranty" },
};

export default function HelpWarrantyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/help" className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="h-3.5 w-3.5" /> Help center
      </Link>
      <div className="flex items-center gap-3 mb-8">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary">
          <ShieldCheck className="h-6 w-6" />
        </div>
        <h1 className="font-display text-3xl font-black uppercase tracking-tighter text-foreground sm:text-4xl">Warranty</h1>
      </div>

      <div className="space-y-6">
        
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Warranty coverage</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">All NOVA RIG products come with a 2-year limited warranty. Monitor arms and chairs have a 5-year warranty. The warranty covers manufacturing defects in materials and workmanship.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">What's covered</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Manufacturing defects, faulty switches, dead pixels, sensor failures, battery degradation beyond 50% in the first 2 years, and RGB LED failures.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">What's not covered</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Damage from drops, spills, unauthorized modifications, normal wear and tear, and damage from using non-standard chargers or cables.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">How to file a claim</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Email support@novarig.co with your order number, a description of the issue, and photos or video showing the defect. We'll respond within 24 hours with next steps.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Replacement process</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Approved warranty claims receive a replacement at no cost. We'll send a prepaid return label for the defective item and ship the replacement once we receive it (or immediately for high-priority cases).</p>
          </section>
        </Reveal>
      </div>

      <div className="mt-10 rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] to-[#0B0F1A] p-6 text-center">
        <h2 className="font-bold text-foreground">Still need help?</h2>
        <p className="mt-1 text-sm text-muted-foreground">Our support team replies within 24 hours.</p>
        <Link href="/contact" className="mt-3 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-bold text-white">
          Contact us <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
