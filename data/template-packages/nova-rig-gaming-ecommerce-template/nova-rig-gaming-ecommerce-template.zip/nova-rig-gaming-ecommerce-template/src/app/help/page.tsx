"use client";

import { useState } from "react";
import Link from "next/link";
import { Search, Truck, RotateCcw, Package, CreditCard, ShieldCheck, LifeBuoy, ArrowRight } from "lucide-react";

const CATEGORIES = [
  { href: "/help/shipping", icon: Truck, label: "Shipping", desc: "Tracking, delivery times, international", color: "#8B5CF6" },
  { href: "/help/returns", icon: RotateCcw, label: "Returns", desc: "30-day returns, refund timelines", color: "#06B6D4" },
  { href: "/help/orders", icon: Package, label: "Orders", desc: "Order status, changes, cancellations", color: "#39FF88" },
  { href: "/help/payments", icon: CreditCard, label: "Payments", desc: "Payment methods, billing, taxes", color: "#FBBF24" },
  { href: "/help/warranty", icon: ShieldCheck, label: "Warranty", desc: "2–5 year warranty, claims", color: "#FF4D6D" },
];

const POPULAR = [
  "When will my order ship?",
  "How do I return an item?",
  "What is your warranty?",
  "Do you ship internationally?",
  "How do I track my order?",
  "Can I change or cancel my order?",
];

export default function HelpCenterPage() {
  const [query, setQuery] = useState("");

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center justify-center gap-2">
          <LifeBuoy className="h-3.5 w-3.5" /> Help center
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          How can we help?
        </h1>
      </div>

      <div className="mx-auto max-w-xl mb-10">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for help..."
            className="w-full rounded-full border border-white/10 bg-white/5 pl-12 pr-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
          />
        </div>
        <div className="mt-3 flex flex-wrap justify-center gap-2">
          <span className="text-xs text-muted-foreground">Popular:</span>
          {POPULAR.slice(0, 4).map((p) => (
            <Link key={p} href="/faq" className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-foreground hover:bg-white/10">
              {p}
            </Link>
          ))}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {CATEGORIES.map((c) => (
          <Link key={c.href} href={c.href} className="group flex items-start gap-3 rounded-2xl border border-white/10 bg-[#0B0F1A] p-5 hover:border-primary/30">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg" style={{ backgroundColor: `${c.color}20`, color: c.color }}>
              <c.icon className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-bold text-foreground">{c.label}</h2>
              <p className="text-xs text-muted-foreground">{c.desc}</p>
              <div className="mt-2 inline-flex items-center gap-1 text-xs font-semibold" style={{ color: c.color }}>
                View articles <ArrowRight className="h-3 w-3" />
              </div>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-10 rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] to-[#0B0F1A] p-8 text-center">
        <h2 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">Still need help?</h2>
        <p className="mt-2 text-sm text-muted-foreground">Our support team replies within 24 hours.</p>
        <Link href="/contact" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
          Contact support <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
