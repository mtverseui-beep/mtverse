import type { Metadata } from "next";
import Link from "next/link";
import { Package, ArrowRight, ChevronLeft } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Orders — Help Center",
  description: "Orders help and FAQ from NOVA RIG support.",
  alternates: { canonical: "https://novarig.co/help/orders" },
};

export default function HelpOrdersPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/help" className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="h-3.5 w-3.5" /> Help center
      </Link>
      <div className="flex items-center gap-3 mb-8">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary">
          <Package className="h-6 w-6" />
        </div>
        <h1 className="font-display text-3xl font-black uppercase tracking-tighter text-foreground sm:text-4xl">Orders</h1>
      </div>

      <div className="space-y-6">
        
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Order status</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Check your order status anytime at /track-order using your order ID and email. You can also view all your orders in your account at /account/orders.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Order changes</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Need to change or cancel your order? Email us within 1 hour of placing it. After 1 hour, your order enters our fulfillment queue and changes may not be possible.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Pre-orders</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Pre-ordered items are charged immediately and ship as soon as they arrive at our warehouse. You'll receive an email with a revised shipping estimate if there are delays.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Backorders</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">If an item is on backorder, you can choose to wait or cancel for a full refund. Backordered items typically ship within 2–3 weeks.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Missing items</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">If your order arrived with missing items, email us within 7 days of delivery with photos of the box and packing slip. We'll resolve it immediately.</p>
          </section>
        </Reveal>
      </div>

      <div className="mt-10 rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] to-[#0B0F1A] p-6 text-center">
        <h2 className="font-bold text-foreground">Still need help?</h2>
        <p className="mt-1 text-sm text-muted-foreground">Our support team replies within 24 hours.</p>
        <Link href="/contact" className="mt-3 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-bold text-white">
          Contact us <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
