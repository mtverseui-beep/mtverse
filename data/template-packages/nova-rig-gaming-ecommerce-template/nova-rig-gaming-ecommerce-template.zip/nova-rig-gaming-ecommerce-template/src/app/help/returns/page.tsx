import type { Metadata } from "next";
import Link from "next/link";
import { RotateCcw, ArrowRight, ChevronLeft } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Returns — Help Center",
  description: "Returns help and FAQ from NOVA RIG support.",
  alternates: { canonical: "https://novarig.co/help/returns" },
};

export default function HelpReturnsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/help" className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="h-3.5 w-3.5" /> Help center
      </Link>
      <div className="flex items-center gap-3 mb-8">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary/15 text-primary">
          <RotateCcw className="h-6 w-6" />
        </div>
        <h1 className="font-display text-3xl font-black uppercase tracking-tighter text-foreground sm:text-4xl">Returns</h1>
      </div>

      <div className="space-y-6">
        
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">30-day return policy</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Not happy with your gear? Return it within 30 days of delivery for a full refund. Items must be in original condition with all accessories and packaging.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">How to start a return</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Email support@novarig.co with your order number and the item(s) you'd like to return. We'll send you a prepaid return label within 24 hours.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Refund timeline</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Refunds are processed within 3 business days of receiving your return at our warehouse. The refund will appear on your original payment method within 5–10 business days.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Exchanges</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Want a different color or size? Email us within 30 days and we'll arrange an exchange. You only pay shipping on the new item if the price is higher.</p>
          </section>
        </Reveal>
        <Reveal>
          <section className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Non-returnable items</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Gift cards, downloadable software, and items marked 'final sale' cannot be returned. Bundles can be returned as a whole, not as individual items.</p>
          </section>
        </Reveal>
      </div>

      <div className="mt-10 rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] to-[#0B0F1A] p-6 text-center">
        <h2 className="font-bold text-foreground">Still need help?</h2>
        <p className="mt-1 text-sm text-muted-foreground">Our support team replies within 24 hours.</p>
        <Link href="/contact" className="mt-3 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-bold text-white">
          Contact us <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
