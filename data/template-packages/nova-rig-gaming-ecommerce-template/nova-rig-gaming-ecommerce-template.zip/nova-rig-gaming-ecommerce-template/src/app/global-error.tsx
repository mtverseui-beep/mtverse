"use client";

import Link from "next/link";
import { AlertTriangle, Home } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html>
      <body>
        <div className="grid min-h-screen place-items-center px-4 bg-[#070A12]">
          <div className="text-center">
            <AlertTriangle className="mx-auto h-16 w-16 text-warning" />
            <h1 className="mt-6 font-display text-3xl font-black uppercase tracking-tighter text-foreground">
              Something went wrong
            </h1>
            <p className="mt-2 max-w-md mx-auto text-muted-foreground">
              An unexpected error occurred. Try again, or head back home.
            </p>
            <div className="mt-6 flex justify-center gap-3">
              <button
                onClick={reset}
                className="rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white"
              >
                Try again
              </button>
              <Link
                href="/"
                className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-foreground"
              >
                <Home className="h-4 w-4" /> Home
              </Link>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
