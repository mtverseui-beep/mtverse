"use client";

import { useState } from "react";
import { AccountShell } from "@/components/account/account-shell";
import { toast } from "sonner";

export default function AccountProfilePage() {
  const [form, setForm] = useState({ firstName: "Demo", lastName: "Customer", email: "demo@novarig.co", phone: "+1 (555) 123-4567", dob: "1995-08-15" });

  return (
    <AccountShell title="Profile">
      <form
        onSubmit={(e) => { e.preventDefault(); toast.success("Profile updated"); }}
        className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 space-y-4"
      >
        <h2 className="font-bold text-foreground">Personal information</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">First name</span>
            <input value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          </label>
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Last name</span>
            <input value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          </label>
        </div>
        <label className="block">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Email</span>
          <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
        </label>
        <label className="block">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Phone (optional)</span>
          <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
        </label>
        <label className="block">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Date of birth (for birthday rewards)</span>
          <input type="date" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
        </label>
        <button type="submit" className="rounded-lg bg-primary px-6 py-2.5 text-sm font-bold text-white">Save changes</button>
      </form>
    </AccountShell>
  );
}