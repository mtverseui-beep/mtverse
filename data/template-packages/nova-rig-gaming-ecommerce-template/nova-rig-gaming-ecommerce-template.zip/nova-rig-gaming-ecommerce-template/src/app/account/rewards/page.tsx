"use client";

import { AccountShell } from "@/components/account/account-shell";
import { Award, Star, ArrowRight } from "lucide-react";

export default function AccountRewardsPage() {
  return (
    <AccountShell title="Rewards">
      <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] via-[#0B0F1A] to-[#101522] p-6 mb-6">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Your points</div>
            <div className="font-display text-5xl font-black text-foreground">1,240</div>
          </div>
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
            <Award className="h-3 w-3" /> Silver tier
          </div>
        </div>
        <div className="mt-4">
          <div className="mb-1 text-xs text-muted-foreground">760 points to Gold</div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
            <div className="h-full rounded-full bg-primary" style={{ width: "62%" }} />
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
        <h2 className="font-bold text-foreground mb-4">How to earn points</h2>
        <ul className="space-y-3 text-sm">
          <li className="flex items-center justify-between border-b border-white/5 pb-3">
            <span className="text-foreground">Every $1 spent</span>
            <span className="font-bold text-primary">1.5 points</span>
          </li>
          <li className="flex items-center justify-between border-b border-white/5 pb-3">
            <span className="text-foreground">Write a product review</span>
            <span className="font-bold text-primary">50 points</span>
          </li>
          <li className="flex items-center justify-between border-b border-white/5 pb-3">
            <span className="text-foreground">Refer a friend who buys</span>
            <span className="font-bold text-primary">500 points</span>
          </li>
          <li className="flex items-center justify-between">
            <span className="text-foreground">Follow on social</span>
            <span className="font-bold text-primary">25 points</span>
          </li>
        </ul>
        <a href="/rewards" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
          View rewards catalog <ArrowRight className="h-3.5 w-3.5" />
        </a>
      </div>
    </AccountShell>
  );
}