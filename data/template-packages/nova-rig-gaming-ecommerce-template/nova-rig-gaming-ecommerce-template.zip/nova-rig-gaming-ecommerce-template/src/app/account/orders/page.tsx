"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AccountShell } from "@/components/account/account-shell";
import { Package, ArrowRight, ChevronRight } from "lucide-react";
import { formatPrice, formatDate } from "@/lib/utils";

export default function AccountOrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  useEffect(() => {
    try {
      setOrders(JSON.parse(localStorage.getItem("nova-rig-orders") ?? "[]"));
    } catch {}
  }, []);

  return (
    <AccountShell title="Orders">
      {orders.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] py-16 text-center">
          <Package className="mx-auto h-12 w-12 text-muted-foreground" />
          <h2 className="mt-3 text-lg font-bold text-foreground">No orders yet</h2>
          <p className="mt-1 text-sm text-muted-foreground">Your order history will appear here.</p>
          <Link href="/shop" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-xs font-bold text-white">
            Shop gear <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <Link
              key={o.id}
              href={`/account/orders/${o.id}`}
              className="block rounded-2xl border border-white/10 bg-[#0B0F1A] p-5 hover:border-primary/30"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-foreground">Order #{o.id}</div>
                  <div className="text-xs text-muted-foreground">{formatDate(o.date)}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-foreground">{formatPrice(o.total)}</div>
                  <div className="text-[10px] uppercase tracking-wider text-accent">{o.status}</div>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="mt-3 text-xs text-muted-foreground">{o.items.length} items</div>
            </Link>
          ))}
        </div>
      )}
    </AccountShell>
  );
}