"use client";

import { useState } from "react";
import { AccountShell } from "@/components/account/account-shell";
import { Shield, Key, Smartphone, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

export default function AccountSecurityPage() {
  const [twoFA, setTwoFA] = useState(false);

  return (
    <AccountShell title="Security">
      <div className="space-y-4">
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <h2 className="font-bold text-foreground mb-4 flex items-center gap-2"><Key className="h-5 w-5 text-primary" /> Password</h2>
          <form onSubmit={(e) => { e.preventDefault(); toast.success("Password updated"); (e.target as HTMLFormElement).reset(); }} className="space-y-3">
            <input type="password" required placeholder="Current password" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
            <input type="password" required placeholder="New password" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
            <input type="password" required placeholder="Confirm new password" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
            <button type="submit" className="rounded-lg bg-primary px-6 py-2 text-sm font-bold text-white">Update password</button>
          </form>
        </div>

        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary"><Smartphone className="h-5 w-5" /></div>
              <div>
                <h3 className="font-bold text-foreground">Two-factor authentication</h3>
                <p className="text-xs text-muted-foreground">Add an extra layer of security to your account.</p>
              </div>
            </div>
            <button
              onClick={() => { setTwoFA(!twoFA); toast.success(twoFA ? "2FA disabled" : "2FA enabled"); }}
              className={`relative h-6 w-11 rounded-full transition-colors ${twoFA ? "bg-accent" : "bg-white/10"}`}
            >
              <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${twoFA ? "translate-x-5" : "translate-x-0.5"}`} />
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-danger/30 bg-danger/5 p-6">
          <h2 className="font-bold text-danger mb-2 flex items-center gap-2"><AlertTriangle className="h-5 w-5" /> Danger zone</h2>
          <p className="text-sm text-muted-foreground mb-3">Permanently delete your account and all associated data. This cannot be undone.</p>
          <button onClick={() => toast.error("Account deletion requires confirmation email")} className="rounded-lg border border-danger/40 bg-danger/10 px-4 py-2 text-sm font-bold text-danger hover:bg-danger/20">
            Delete account
          </button>
        </div>
      </div>
    </AccountShell>
  );
}