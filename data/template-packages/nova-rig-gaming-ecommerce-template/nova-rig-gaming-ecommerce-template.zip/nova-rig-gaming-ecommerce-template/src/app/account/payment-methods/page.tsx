"use client";

import { AccountShell } from "@/components/account/account-shell";
import { CreditCard, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

const CARDS = [
  { id: "c1", brand: "Visa", last4: "4242", exp: "12/27", default: true },
  { id: "c2", brand: "Mastercard", last4: "5555", exp: "08/26" },
];

export default function PaymentMethodsPage() {
  return (
    <AccountShell title="Payment methods">
      <div className="mb-4 flex justify-end">
        <button onClick={() => toast.success("Add card flow would open here")} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-bold text-white">
          <Plus className="h-4 w-4" /> Add card
        </button>
      </div>
      <div className="space-y-3">
        {CARDS.map((c) => (
          <div key={c.id} className="flex items-center justify-between rounded-2xl border border-white/10 bg-[#0B0F1A] p-5">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary">
                <CreditCard className="h-5 w-5" />
              </div>
              <div>
                <div className="font-semibold text-foreground">{c.brand} ending in {c.last4}</div>
                <div className="text-xs text-muted-foreground">Expires {c.exp}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {c.default && <span className="rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-bold text-accent">Default</span>}
              <button onClick={() => toast.success("Card removed")} className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-white/5 hover:text-danger">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-muted-foreground">Demo only. No real payment methods are stored.</p>
    </AccountShell>
  );
}