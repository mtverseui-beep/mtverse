"use client";

import { useState } from "react";
import { AccountShell } from "@/components/account/account-shell";
import { Plus, Edit, Trash2, MapPin, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

interface Addr {
  id: string;
  label: string;
  fullName: string;
  line1: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  isDefault?: boolean;
}

const INITIAL: Addr[] = [
  { id: "a1", label: "Home", fullName: "Demo Customer", line1: "1234 Main St", city: "Austin", state: "TX", zip: "78701", country: "United States", isDefault: true },
];

export default function AccountAddressesPage() {
  const [addresses, setAddresses] = useState<Addr[]>(INITIAL);
  const [editing, setEditing] = useState<Addr | null>(null);
  const [open, setOpen] = useState(false);

  const save = (a: Addr) => {
    setAddresses((prev) => {
      const exists = prev.find((x) => x.id === a.id);
      if (exists) return prev.map((x) => (x.id === a.id ? a : x));
      return [...prev, a];
    });
    setOpen(false);
    setEditing(null);
    toast.success("Address saved");
  };

  const remove = (id: string) => {
    setAddresses((prev) => prev.filter((a) => a.id !== id));
    toast.success("Address removed");
  };

  return (
    <AccountShell title="Addresses">
      <div className="mb-4 flex justify-end">
        <button
          onClick={() => { setEditing(null); setOpen(true); }}
          className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-bold text-white"
        >
          <Plus className="h-4 w-4" /> Add address
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {addresses.map((a) => (
          <div key={a.id} className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                <span className="text-sm font-bold text-foreground">{a.label}</span>
                {a.isDefault && <span className="rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-bold text-accent">Default</span>}
              </div>
              <div className="flex gap-1">
                <button onClick={() => { setEditing(a); setOpen(true); }} className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-white/5 hover:text-foreground">
                  <Edit className="h-3.5 w-3.5" />
                </button>
                <button onClick={() => remove(a.id)} className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-white/5 hover:text-danger">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
            <div className="mt-3 text-sm text-muted-foreground">
              <div className="font-semibold text-foreground">{a.fullName}</div>
              <div>{a.line1}</div>
              <div>{a.city}, {a.state} {a.zip}</div>
              <div>{a.country}</div>
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {open && (
          <AddressModal
            address={editing}
            onSave={save}
            onClose={() => { setOpen(false); setEditing(null); }}
          />
        )}
      </AnimatePresence>
    </AccountShell>
  );
}

function AddressModal({ address, onSave, onClose }: { address: Addr | null; onSave: (a: Addr) => void; onClose: () => void }) {
  const [form, setForm] = useState<Addr>(address ?? { id: `a-${Date.now()}`, label: "", fullName: "", line1: "", city: "", state: "", zip: "", country: "United States" });

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 z-[80] bg-black/60" />
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.98 }}
        className="fixed left-1/2 top-1/2 z-[90] w-full max-w-md -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-bold text-foreground">{address ? "Edit address" : "Add address"}</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-white/5">
            <X className="h-4 w-4" />
          </button>
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); onSave(form); }}
          className="space-y-3"
        >
          <input required placeholder="Label (Home, Work)" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          <input required placeholder="Full name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          <input required placeholder="Street address" value={form.line1} onChange={(e) => setForm({ ...form, line1: e.target.value })} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          <div className="grid grid-cols-2 gap-2">
            <input required placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
            <input required placeholder="State" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input required placeholder="ZIP" value={form.zip} onChange={(e) => setForm({ ...form, zip: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
            <input required placeholder="Country" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
          </div>
          <button type="submit" className="w-full rounded-lg bg-primary px-4 py-2 text-sm font-bold text-white">Save address</button>
        </form>
      </motion.div>
    </>
  );
}