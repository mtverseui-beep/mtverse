"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AccountShell } from "@/components/account/account-shell";
import { useShopStore } from "@/lib/shop-store";
import { Package, Heart, Award, Bell, ArrowRight, Truck, Star } from "lucide-react";
import { formatPrice, formatDate } from "@/lib/utils";
import { motion } from "framer-motion";

export default function AccountDashboardPage() {
  const { wishlist } = useShopStore();
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem("nova-rig-orders") ?? "[]");
      setOrders(stored);
    } catch {}
  }, []);

  const totalSpent = orders.reduce((acc, o) => acc + o.total, 0);

  return (
    <AccountShell title="Dashboard">
      {/* Stats */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        {[
          { label: "Orders", value: orders.length, icon: Package, color: "#8B5CF6" },
          { label: "Wishlist", value: wishlist.length, icon: Heart, color: "#FF4D6D" },
          { label: "Reward points", value: 1240, icon: Award, color: "#39FF88" },
          { label: "Total spent", value: formatPrice(totalSpent), icon: Star, color: "#06B6D4" },
        ].map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            className="rounded-xl border border-white/10 bg-[#0B0F1A] p-4"
          >
            <div className="grid h-9 w-9 place-items-center rounded-lg" style={{ backgroundColor: `${s.color}20`, color: s.color }}>
              <s.icon className="h-4 w-4" />
            </div>
            <div className="mt-3 text-2xl font-black text-foreground">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Recent orders */}
      <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-foreground">Recent orders</h2>
          <Link href="/account/orders" className="text-xs font-semibold text-primary hover:underline">
            View all
          </Link>
        </div>
        {orders.length === 0 ? (
          <div className="py-8 text-center">
            <Package className="mx-auto h-12 w-12 text-muted-foreground" />
            <p className="mt-2 text-sm text-muted-foreground">No orders yet.</p>
            <Link href="/shop" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-xs font-bold text-white">
              Shop gear <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        ) : (
          <div className="space-y-2">
            {orders.slice(0, 3).map((o) => (
              <Link
                key={o.id}
                href={`/account/orders/${o.id}`}
                className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] p-3 hover:border-primary/30"
              >
                <div>
                  <div className="text-sm font-semibold text-foreground">Order #{o.id}</div>
                  <div className="text-xs text-muted-foreground">{formatDate(o.date)} · {o.items.length} items</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-sm font-bold text-foreground">{formatPrice(o.total)}</div>
                    <div className="text-[10px] uppercase tracking-wider text-accent">{o.status}</div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="grid gap-3 sm:grid-cols-2">
        <Link href="/track-order" className="flex items-center gap-3 rounded-xl border border-white/10 bg-[#0B0F1A] p-4 hover:border-primary/30">
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary">
            <Truck className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <div className="text-sm font-bold text-foreground">Track an order</div>
            <div className="text-xs text-muted-foreground">See real-time shipment status</div>
          </div>
          <ArrowRight className="h-4 w-4 text-muted-foreground" />
        </Link>
        <Link href="/rewards" className="flex items-center gap-3 rounded-xl border border-white/10 bg-[#0B0F1A] p-4 hover:border-primary/30">
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-accent/15 text-accent">
            <Award className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <div className="text-sm font-bold text-foreground">Rewards program</div>
            <div className="text-xs text-muted-foreground">Redeem points for gear</div>
          </div>
          <ArrowRight className="h-4 w-4 text-muted-foreground" />
        </Link>
      </div>
    </AccountShell>
  );
}
