"use client";

import { AccountShell } from "@/components/account/account-shell";
import { Bell, Mail, MessageSquare, Star } from "lucide-react";
import { toast } from "sonner";

const NOTIFS = [
  { id: "orders", label: "Order updates", desc: "Shipping, delivery, and order status", icon: Bell, default: true },
  { id: "drops", label: "Drop alerts", desc: "Early access to limited drops", icon: Star, default: true },
  { id: "newsletter", label: "Newsletter", desc: "Weekly gear guides and deals", icon: Mail, default: false },
  { id: "sms", label: "SMS alerts", desc: "Text messages for time-sensitive alerts", icon: MessageSquare, default: false },
];

export default function AccountNotificationsPage() {
  return (
    <AccountShell title="Notifications">
      <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
        <h2 className="font-bold text-foreground mb-4">Notification preferences</h2>
        <div className="space-y-3">
          {NOTIFS.map((n) => (
            <label key={n.id} className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] p-4">
              <div className="flex items-start gap-3">
                <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary/15 text-primary">
                  <n.icon className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-sm font-bold text-foreground">{n.label}</div>
                  <div className="text-xs text-muted-foreground">{n.desc}</div>
                </div>
              </div>
              <input type="checkbox" defaultChecked={n.default} onChange={() => toast.success("Preference saved")} className="h-5 w-5 rounded border-white/20 bg-white/5 text-primary" />
            </label>
          ))}
        </div>
      </div>
    </AccountShell>
  );
}