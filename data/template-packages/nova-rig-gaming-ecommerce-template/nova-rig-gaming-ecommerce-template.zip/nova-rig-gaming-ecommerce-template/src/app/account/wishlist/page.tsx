"use client";

import Link from "next/link";
import { AccountShell } from "@/components/account/account-shell";
import { useShopStore } from "@/lib/shop-store";
import { PRODUCTS } from "@/data/products";
import { ProductCard } from "@/components/product/product-card";
import { useQuickView } from "@/lib/quick-view-store";
import { Heart, ArrowRight } from "lucide-react";

export default function AccountWishlistPage() {
  const { wishlist } = useShopStore();
  const { openQuickView } = useQuickView();
  const items = wishlist.map((w) => PRODUCTS.find((p) => p.slug === w.productSlug)).filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <AccountShell title="Wishlist">
      {items.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] py-16 text-center">
          <Heart className="mx-auto h-12 w-12 text-muted-foreground" />
          <h2 className="mt-3 text-lg font-bold text-foreground">No wishlist items</h2>
          <Link href="/shop" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-xs font-bold text-white">
            Shop gear <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-2 lg:grid-cols-3">
          {items.map((p) => <ProductCard key={p.id} product={p} onQuickView={openQuickView} />)}
        </div>
      )}
    </AccountShell>
  );
}