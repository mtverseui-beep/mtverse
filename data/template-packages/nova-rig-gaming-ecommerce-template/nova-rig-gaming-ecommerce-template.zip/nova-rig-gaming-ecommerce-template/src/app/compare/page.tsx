"use client";

import Link from "next/link";
import { useShopStore } from "@/lib/shop-store";
import { PRODUCTS } from "@/data/products";
import { SafeImg } from "@/components/common/safe-image";
import { GitCompare, X, ArrowRight, Check } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";

export default function ComparePage() {
  const { compare, toggleCompare, clearCompare } = useShopStore();
  const items = compare
    .map((c) => PRODUCTS.find((p) => p.slug === c.productSlug))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <GitCompare className="mx-auto h-16 w-16 text-muted-foreground" />
        <h1 className="mt-4 font-display text-3xl font-black uppercase tracking-tight text-foreground">Compare gear</h1>
        <p className="mt-2 text-muted-foreground">Add up to 4 products to compare specs side by side.</p>
        <Link href="/shop" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
          Shop gear <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    );
  }

  const specs = ["price", "rating", "categoryLabel", "stock", "weight", "dimensions", ...items[0].specs.map((s) => s.label)];

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-end justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl flex items-center gap-3">
            <GitCompare className="h-7 w-7 text-secondary" /> Compare gear
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">{items.length} of 4 products</p>
        </div>
        <button onClick={clearCompare} className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-xs font-semibold text-foreground hover:bg-white/10">
          <X className="h-3.5 w-3.5" /> Clear all
        </button>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-white/10 bg-[#0B0F1A]">
        <table className="w-full min-w-[640px] text-sm">
          <thead>
            <tr className="border-b border-white/10">
              <th className="p-4 text-left text-xs font-bold uppercase tracking-wider text-muted-foreground">Spec</th>
              {items.map((p) => (
                <th key={p.id} className="p-4 text-left align-top">
                  <div className="relative">
                    <button
                      onClick={() => toggleCompare(p.slug)}
                      aria-label={`Remove ${p.name}`}
                      className="absolute -right-2 -top-2 grid h-6 w-6 place-items-center rounded-full bg-white/10 text-foreground hover:bg-danger/20 hover:text-danger"
                    >
                      <X className="h-3 w-3" />
                    </button>
                    <SafeImg src={p.images[0]} alt={p.name} className="h-24 w-full rounded-lg object-cover" width={120} height={96} />
                    <Link href={`/product/${p.slug}`} className="mt-2 block font-bold text-foreground hover:text-primary">
                      {p.name}
                    </Link>
                    <div className="text-xs text-muted-foreground">{p.categoryLabel}</div>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {specs.map((spec) => (
              <tr key={spec} className="border-b border-white/5">
                <td className="p-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">{spec}</td>
                {items.map((p) => {
                  let value: any;
                  if (spec === "price") value = formatPrice(p.price);
                  else if (spec === "rating") value = `★ ${p.rating} (${p.reviewCount})`;
                  else if (spec === "stock") value = p.stock > 0 ? <span className="text-accent">In stock</span> : <span className="text-danger">Sold out</span>;
                  else if (spec === "categoryLabel") value = p.categoryLabel;
                  else if (spec === "weight") value = p.weight ?? "—";
                  else if (spec === "dimensions") value = p.dimensions ?? "—";
                  else {
                    const s = p.specs.find((x) => x.label === spec);
                    value = s ? s.value : "—";
                  }
                  return <td key={p.id} className="p-4 text-foreground">{value}</td>;
                })}
              </tr>
            ))}
            <tr>
              <td className="p-4"></td>
              {items.map((p) => (
                <td key={p.id} className="p-4">
                  <Link
                    href={`/product/${p.slug}`}
                    className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-xs font-bold text-white hover:bg-primary/90"
                  >
                    View product <ArrowRight className="h-3 w-3" />
                  </Link>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-6">
        <Link href="/shop" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
          <ArrowRight className="h-4 w-4 rotate-180" /> Continue shopping
        </Link>
      </div>
    </div>
  );
}
