import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { BLOG_POSTS, getBlogPostBySlug } from "@/data/content";
import { getProductBySlug } from "@/data/products";
import { SafeImg } from "@/components/common/safe-image";
import { ProductCard } from "@/components/product/product-card";
import { Reveal } from "@/components/motion/reveal";
import { ArrowLeft, ArrowRight, Clock, Calendar } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return BLOG_POSTS.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const post = getBlogPostBySlug(slug);
  if (!post) return { title: "Post not found" };
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `https://novarig.co/blog/${post.slug}` },
    openGraph: { title: post.title, description: post.excerpt, images: [post.cover], type: "article" },
  };
}

export default async function BlogPostPage({ params }: PageProps) {
  const { slug } = await params;
  const post = getBlogPostBySlug(slug);
  if (!post) notFound();
  const relatedProducts = (post.relatedProductSlugs ?? []).map((s) => getProductBySlug(s)).filter((p): p is NonNullable<typeof p> => Boolean(p));
  const relatedPosts = (post.relatedPostSlugs ?? []).map((s) => getBlogPostBySlug(s)).filter((p): p is NonNullable<typeof p> => Boolean(p));

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post!.title,
    image: post!.cover,
    datePublished: post!.date,
    author: { "@type": "Person", name: post!.author },
    publisher: { "@type": "Organization", name: "NOVA RIG" },
    description: post!.excerpt,
  };

  return (
    <div>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <article>
        {/* Hero */}
        <section className="relative h-[50vh] overflow-hidden border-b border-white/10">
          <SafeImg src={post!.cover} alt={post!.title} className="absolute inset-0 h-full w-full object-cover" width={1600} height={900} loading="eager" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/70 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
            <Link href="/blog" className="inline-flex items-center gap-1.5 text-xs font-semibold text-foreground/80 hover:text-foreground">
              <ArrowLeft className="h-3.5 w-3.5" /> Back to blog
            </Link>
            <div className="mt-4 flex flex-wrap items-center gap-3 text-xs">
              <span className="rounded-full bg-primary/15 px-2 py-0.5 font-bold uppercase tracking-wider text-primary">{post!.category}</span>
              <span className="flex items-center gap-1 text-muted-foreground"><Calendar className="h-3 w-3" /> {formatDate(post!.date)}</span>
              <span className="flex items-center gap-1 text-muted-foreground"><Clock className="h-3 w-3" /> {post!.readingTime}</span>
            </div>
            <h1 className="mt-4 font-display text-3xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
              {post!.title}
            </h1>
            <div className="mt-4 flex items-center gap-2">
              <SafeImg src={post!.authorAvatar} alt={post!.author} className="h-8 w-8 rounded-full object-cover" width={32} height={32} />
              <span className="text-sm text-muted-foreground">{post!.author}</span>
            </div>
          </div>
        </section>

        {/* Body */}
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="space-y-6">
            {post!.content.map((block, i) => (
              <Reveal key={i}>
                {block.heading ? (
                  <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground">{block.heading}</h2>
                ) : null}
                <p className="text-base text-foreground/90 leading-relaxed">{block.body}</p>
              </Reveal>
            ))}
          </div>

          {/* Tags */}
          <div className="mt-8 flex flex-wrap gap-2">
            {post!.tags.map((t) => (
              <Link key={t} href={`/search?q=${encodeURIComponent(t)}`} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-muted-foreground hover:text-foreground">
                #{t}
              </Link>
            ))}
          </div>
        </div>
      </article>

      {/* Related products */}
      {relatedProducts.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 border-t border-white/10">
          <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground mb-6">Gear mentioned</h2>
          <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
            {relatedProducts.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      {/* Related posts */}
      {relatedPosts.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 border-t border-white/10">
          <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground mb-6">Related articles</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {relatedPosts.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="group flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#0B0F1A] hover:border-primary/30">
                <div className="aspect-video overflow-hidden bg-[#101522]">
                  <SafeImg src={p.cover} alt={p.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" width={400} height={225} />
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-foreground line-clamp-2 group-hover:text-primary">{p.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{p.excerpt}</p>
                  <div className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary">
                    Read more <ArrowRight className="h-3 w-3" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
