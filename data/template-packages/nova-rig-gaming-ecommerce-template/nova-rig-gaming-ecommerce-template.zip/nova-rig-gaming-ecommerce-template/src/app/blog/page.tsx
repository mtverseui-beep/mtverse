import type { Metadata } from "next";
import { BLOG_POSTS } from "@/data/content";
import { Reveal } from "@/components/motion/reveal";
import { SafeImg } from "@/components/common/safe-image";
import Link from "next/link";
import { Newspaper, ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Blog — NOVA RIG",
  description: "Setup guides, gear deep-dives, and stories from the NOVA RIG community.",
  alternates: { canonical: "https://novarig.co/blog" },
};

export default function BlogPage() {
  const [featured, ...rest] = BLOG_POSTS;
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
          <Newspaper className="h-3.5 w-3.5" /> Blog
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          From NOVA RIG
        </h1>
      </div>

      {/* Featured */}
      <Reveal>
        <Link href={`/blog/${featured.slug}`} className="group grid gap-6 rounded-3xl border border-white/10 bg-[#0B0F1A] p-6 sm:grid-cols-2 mb-8 hover:border-primary/30">
          <div className="aspect-video overflow-hidden rounded-2xl bg-[#101522]">
            <SafeImg src={featured.cover} alt={featured.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" width={800} height={450} />
          </div>
          <div className="flex flex-col justify-center">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="rounded-full bg-primary/15 px-2 py-0.5 font-bold uppercase tracking-wider text-primary">{featured.category}</span>
              <span>{featured.readingTime}</span>
            </div>
            <h2 className="mt-3 font-display text-2xl font-black uppercase tracking-tight text-foreground sm:text-3xl group-hover:text-primary">
              {featured.title}
            </h2>
            <p className="mt-2 text-sm text-muted-foreground line-clamp-3">{featured.excerpt}</p>
            <div className="mt-3 flex items-center gap-2">
              <SafeImg src={featured.authorAvatar} alt={featured.author} className="h-7 w-7 rounded-full object-cover" width={28} height={28} />
              <span className="text-xs text-muted-foreground">{featured.author}</span>
            </div>
          </div>
        </Link>
      </Reveal>

      {/* Grid */}
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {rest.map((post, i) => (
          <Reveal key={post.slug} delay={i * 0.06}>
            <Link href={`/blog/${post.slug}`} className="group flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#0B0F1A] hover:border-primary/30">
              <div className="aspect-video overflow-hidden bg-[#101522]">
                <SafeImg src={post.cover} alt={post.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" width={400} height={225} />
              </div>
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-xs">
                  <span className="rounded-full bg-primary/15 px-2 py-0.5 font-bold uppercase tracking-wider text-primary">{post.category}</span>
                  <span className="text-muted-foreground">{post.readingTime}</span>
                </div>
                <h3 className="mt-3 font-bold text-foreground line-clamp-2 group-hover:text-primary">{post.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground line-clamp-2 flex-1">{post.excerpt}</p>
                <div className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary">
                  Read more <ArrowRight className="h-3 w-3" />
                </div>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
