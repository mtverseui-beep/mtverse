import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "headsets" as const;

export const metadata: Metadata = {
  title: "Gaming Headsets",
  description: "Wireless gaming headsets with spatial 3D audio, 50mm drivers, and marathon battery life.",
  alternates: { canonical: `https://novarig.co/headsets` },
};

export default function HeadsetsPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Gaming Headsets"} description={`${products.length} products in the Gaming Headsets collection.`} showCategoryFilter={false} />
    </>
  );
}
