import type { Metadata } from "next";
import { DROP_EVENTS } from "@/data/content";
import { Calendar, Flame, ArrowRight } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Drop Calendar — Upcoming Gear Drops",
  description: "See upcoming NOVA RIG limited drops. Join the waitlist for early access to exclusive colorways and bundles.",
  alternates: { canonical: "https://novarig.co/drop-calendar" },
};

export default function DropCalendarPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-warning flex items-center justify-center gap-2">
          <Calendar className="h-3.5 w-3.5" /> Drop calendar
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Upcoming drops
        </h1>
        <p className="mt-3 max-w-xl mx-auto text-muted-foreground">
          Plan ahead. Join the waitlist for early access to limited drops and exclusive colorways.
        </p>
      </div>

      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-4 sm:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-warning via-primary to-secondary sm:-translate-x-1/2" />

        <div className="space-y-8">
          {DROP_EVENTS.map((drop, i) => (
            <div key={drop.id} className={`relative pl-12 sm:pl-0 ${i % 2 === 0 ? "sm:pr-1/2" : "sm:pl-1/2"}`}>
              {/* Dot */}
              <div className="absolute left-2.5 sm:left-1/2 top-2 grid h-3 w-3 -translate-x-1/2 place-items-center rounded-full bg-warning glow-acid">
                <span className="absolute h-3 w-3 animate-ping rounded-full bg-warning opacity-50" />
              </div>

              <div className={`rounded-2xl border border-white/10 bg-[#0B0F1A] p-5 ${i % 2 === 0 ? "sm:mr-8" : "sm:ml-8"}`}>
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-warning">
                  <Flame className="h-3.5 w-3.5" /> {drop.status}
                </div>
                <h2 className="mt-2 font-display text-xl font-bold text-foreground">{drop.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{drop.description}</p>
                <div className="mt-3 flex items-center justify-between">
                  <div>
                    <div className="text-xs text-muted-foreground">Drop date</div>
                    <div className="text-sm font-bold text-foreground">
                      {new Date(drop.date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Price</div>
                    <div className="text-sm font-bold text-primary">${drop.price}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Stock</div>
                    <div className="text-sm font-bold text-warning">{drop.stock}</div>
                  </div>
                </div>
                <Link
                  href={`/product/${drop.productSlug}`}
                  className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-warning hover:underline"
                >
                  View product <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
