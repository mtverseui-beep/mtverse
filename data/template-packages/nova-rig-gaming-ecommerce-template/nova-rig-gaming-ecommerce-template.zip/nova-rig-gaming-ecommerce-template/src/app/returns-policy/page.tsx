import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Returns Policy",
  description: "Returns Policy for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/returns-policy" },
};

export default function ReturnspolicyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Returns Policy</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">30-day return window</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">You have 30 days from delivery to return any NOVA RIG product. No questions asked, no restocking fees. Items must be in original condition with all accessories and packaging.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">How to start a return</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Email support@novarig.co with your order number and the item(s) you'd like to return. We'll send you a prepaid return label within 24 hours.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Return shipping</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Return shipping is free for orders shipped within the contiguous US. For international returns, the customer is responsible for return shipping.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Refund timeline</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Refunds are processed within 3 business days of receiving your return at our warehouse. The refund will appear on your original payment method within 5–10 business days.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Exchanges</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Want a different color or size? Email us within 30 days and we'll arrange an exchange. You only pay shipping on the new item if the price is higher.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Damaged or defective items</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">If your item arrived damaged or defective, email us within 7 days of delivery with photos. We'll send a replacement at no cost and provide a prepaid return label for the defective item.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Bundle returns</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Bundles must be returned as a complete set, not as individual items. If you want to keep part of a bundle, the bundle discount will be removed and you'll be charged the difference.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
