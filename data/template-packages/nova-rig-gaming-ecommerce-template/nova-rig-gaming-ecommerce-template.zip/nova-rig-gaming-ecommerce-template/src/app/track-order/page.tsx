"use client";

import { useState } from "react";
import Link from "next/link";
import { Search, Truck, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function TrackOrderPage() {
  const [orderId, setOrderId] = useState("");
  const [email, setEmail] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderId || !email) return;
    try {
      const orders = JSON.parse(localStorage.getItem("nova-rig-orders") ?? "[]");
      const found = orders.find((o: any) => o.id === orderId);
      if (found) {
        window.location.href = `/order/${orderId}`;
      } else {
        toast.error("Order not found", { description: "Check your order ID and try again." });
      }
    } catch {
      toast.error("Order not found");
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <div className="text-center mb-8">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-primary/15 text-primary">
          <Truck className="h-8 w-8" />
        </div>
        <h1 className="mt-4 font-display text-3xl font-black uppercase tracking-tight text-foreground">Track your order</h1>
        <p className="mt-2 text-muted-foreground">Enter your order ID and email to see your delivery status.</p>
      </div>

      <motion.form
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={submit}
        className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 space-y-4"
      >
        <label className="block">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Order ID</span>
          <input
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            placeholder="NR-12345678"
            required
            className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
          />
        </label>
        <label className="block">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Email</span>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            placeholder="you@example.com"
            required
            className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
          />
        </label>
        <button
          type="submit"
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white hover:bg-primary/90"
        >
          <Search className="h-4 w-4" /> Track order
        </button>
        <p className="text-center text-xs text-muted-foreground">
          Don't have your order ID? <Link href="/contact" className="text-primary hover:underline">Contact support</Link>.
        </p>
      </motion.form>

      <div className="mt-6 text-center">
        <Link href="/account/orders" className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline">
          View all your orders <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  );
}
