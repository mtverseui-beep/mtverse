"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function ServerErrorPage() {
  return (
    <div className="grid min-h-[70vh] place-items-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="font-display text-7xl font-black uppercase tracking-tighter text-gradient-violet sm:text-9xl">
          500
        </div>
        <h1 className="mt-4 font-display text-2xl font-bold uppercase tracking-tight text-foreground sm:text-3xl">
          Server error
        </h1>
        <p className="mt-2 max-w-md mx-auto text-muted-foreground">
          Something went wrong on our end. We've been notified and are working on it.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white"
        >
          Try again <ArrowRight className="h-4 w-4" />
        </Link>
      </motion.div>
    </div>
  );
}
