import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "mice" as const;

export const metadata: Metadata = {
  title: "Gaming Mice",
  description: "Lightweight wireless gaming mice with 36K optical sensors and 8000Hz polling.",
  alternates: { canonical: `https://novarig.co/mice` },
};

export default function MicePage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Gaming Mice"} description={`${products.length} products in the Gaming Mice collection.`} showCategoryFilter={false} />
    </>
  );
}
