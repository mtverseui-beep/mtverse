import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Refund Policy",
  description: "Refund Policy for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/refund-policy" },
};

export default function RefundpolicyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Refund Policy</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Refund eligibility</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Refunds are available for 30 days after delivery. Items must be in original condition with all accessories and packaging. Some items (gift cards, software downloads, items marked 'final sale') are non-refundable.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">How to request a refund</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Email support@novarig.co with your order number and reason for refund. We'll send a prepaid return label within 24 hours. Refunds are processed within 3 business days of receiving your return.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Refund method</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Refunds are issued to the original payment method. Credit card refunds appear within 5–10 business days. PayPal refunds appear within 1–3 business days. Gift card refunds are issued as new gift cards.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Partial refunds</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Partial refunds may be issued for: items returned with missing accessories, items with visible wear beyond what's expected from a 30-day trial, and bundled items returned individually (we recommend returning the full bundle).</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Refund exceptions</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We cannot refund: items damaged by misuse, items modified by the customer, items returned after 30 days, and shipping costs (unless the return is due to our error).</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
