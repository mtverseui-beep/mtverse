import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Accessibility Statement",
  description: "Accessibility Statement for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/accessibility" },
};

export default function AccessibilityPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Accessibility Statement</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Our commitment</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">NOVA RIG is committed to making our website accessible to everyone, including people with disabilities. We aim to comply with WCAG 2.1 Level AA standards.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">What we've done</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We've implemented: semantic HTML structure, ARIA labels for interactive elements, keyboard navigation support, sufficient color contrast (4.5:1 minimum), alt text for all images, and a skip-to-content link at the top of every page.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">What we're working on</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We're continuously improving accessibility. Current projects include: improved screen reader support for dynamic content, simplified checkout flow, and additional keyboard shortcuts.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Feedback</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Found an accessibility issue? Email us at support@novarig.co with a description of the issue and the page URL. We take accessibility feedback seriously and respond within 24 hours.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Third-party content</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Some content on our site (like embedded videos or product images from manufacturers) may not be fully accessible. We're working with our partners to improve this.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
