"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Mail, Lock, User } from "lucide-react";
import { toast } from "sonner";

export default function Page() {
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Demo mode", { description: "Authentication is not wired to a backend in this template." });
  };

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-8"
      >
        <div className="mb-6 text-center">
          <Link href="/" className="inline-block">
            <svg viewBox="0 0 32 32" className="mx-auto h-10 w-10">
              <defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#8B5CF6" /><stop offset="50%" stopColor="#06B6D4" /><stop offset="100%" stopColor="#39FF88" /></linearGradient></defs>
              <path d="M9 6 L16 16 L9 26 Z" fill="url(#lg)" />
              <path d="M23 6 L16 16 L23 26 Z" fill="url(#lg)" opacity="0.5" />
              <circle cx="16" cy="16" r="1.5" fill="#F8FAFC" />
            </svg>
          </Link>
          <h1 className="mt-4 font-display text-2xl font-black uppercase tracking-tight text-foreground">Sign in to NOVA RIG</h1>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <label className="block">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Email</span>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  name="email"
                  required
                  placeholder="you@example.com"
                  className="w-full rounded-lg border border-white/10 bg-white/5 pl-10 pr-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
                />
              </div>
            </label>
          <label className="block">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Password</span>
              <div className="relative mt-1">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="password"
                  name="password"
                  required
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-white/10 bg-white/5 pl-10 pr-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
                />
              </div>
            </label>
          <div className="flex items-center justify-between"><label className="flex items-center gap-2 text-xs text-muted-foreground"><input type="checkbox" className="rounded border-white/20 bg-white/5 text-primary" /> Remember me</label><a href="/forgot-password" className="text-xs text-primary hover:underline">Forgot password?</a></div>
          <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white hover:bg-primary/90">
            Sign in <ArrowRight className="h-4 w-4" />
          </button>
        </form>
        <p className="mt-6 text-center text-xs text-muted-foreground">
          Don't have an account?{" "}
          <Link href="/sign-up" className="text-primary hover:underline font-semibold">Sign up</Link>
        </p>
      </motion.div>
    </div>
  );
}
