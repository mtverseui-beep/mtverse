import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Size & Compatibility Guide",
  description: "Size & Compatibility Guide for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/size-and-compatibility" },
};

export default function SizeandcompatibilityPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Size & Compatibility Guide</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Keyboard sizes</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Full-size (100%): includes number pad, function row, and nav cluster. Best for productivity users. TKL (87 keys): drops the number pad but keeps function row, arrows, and nav cluster. The NovaKeys TKL Pro is our flagship TKL — most flexible layout. 75%: compresses the function row and drops the nav cluster. The NovaKeys 75 Motion includes a rotary knob. 60%: drops the function row and arrows entirely (accessed via layers). The NightOps 60 maximizes mouse room for FPS players.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Mouse grip styles</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Palm grip (full hand on mouse): prefers larger mice. The NovaMouse X1 fits palm grip well. Claw grip (arched hand, fingers arched): prefers medium mice. Both NovaMouse X1 and Air 58 work for claw. Fingertip grip (only fingertips touch mouse): prefers small, light mice. The NovaMouse Air 58 (48g) is ideal.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Desk mat sizing</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">XXL (900 × 400 mm): covers most of a 160 cm desk. Fits keyboard, mouse, and full arm range. XL (800 × 300 mm): for 140 cm desks. Fits keyboard and mouse with normal arm range. L (500 × 400 mm): mouse-only pads. M (400 × 300 mm): compact mouse pad for laptop users.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Monitor arm compatibility</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">VESA mount: 75 × 75 mm or 100 × 100 mm (FocusArm supports both). Monitor weight: FocusArm supports up to 9 kg per arm. FocusArm Dual Pro supports up to 18 kg total. Desk thickness: 10–90 mm. Curved monitor compatibility: FocusArm supports curved monitors up to 1000R.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Operating system compatibility</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Windows 10/11: full compatibility for all NOVA RIG products. macOS (Monterey and later): full compatibility. Some NOVA Sync features limited. Linux: most products work as generic HID devices. NOVA Sync desktop app not available. Chrome OS: basic compatibility, no software features.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Console compatibility</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">PS5/PS5 Pro: USB-C and 3.5mm audio supported. 2.4GHz wireless depends on product (see product page). Xbox Series X|S: USB-C and 3.5mm audio supported. Nintendo Switch: USB-C in docked mode. Steam Deck: full compatibility for all USB-C and Bluetooth products.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">RGB sync compatibility</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">NOVA Sync works with: all NOVA RIG RGB products (NovaKeys, NovaMouse with RGB, GlowBar, PulseMat Violet Edge, StreamMic). NOVA Sync is not compatible with: third-party RGB products (Razer Chroma, Corsair iCUE, etc.) at this time.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
