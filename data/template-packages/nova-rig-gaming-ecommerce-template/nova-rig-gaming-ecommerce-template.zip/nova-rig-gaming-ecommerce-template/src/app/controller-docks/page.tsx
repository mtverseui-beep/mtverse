import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "controller-docks" as const;

export const metadata: Metadata = {
  title: "Controller Docks",
  description: "Universal controller stands with USB-C passthrough charging.",
  alternates: { canonical: `https://novarig.co/controller-docks` },
};

export default function ControllerdocksPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Controller Docks"} description={`${products.length} products in the Controller Docks collection.`} showCategoryFilter={false} />
    </>
  );
}
