import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { COLLECTIONS, getCollectionBySlug } from "@/data/collections";
import { getProductBySlug } from "@/data/products";
import { ShopBrowser } from "@/components/product/shop-browser";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return COLLECTIONS.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const c = getCollectionBySlug(slug);
  if (!c) return { title: "Collection not found" };
  return {
    title: c.name,
    description: c.description,
    alternates: { canonical: `https://novarig.co/collections/${c.slug}` },
  };
}

export default async function CollectionDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const c = getCollectionBySlug(slug);
  if (!c) notFound();
  const products = c!.productSlugs.map((s) => getProductBySlug(s)).filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <>
      <section className="relative overflow-hidden border-b border-white/10">
        { }
        <img src={c!.heroImage} alt="" className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/80 to-[#070A12]/60" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
          <span className="text-xs font-bold uppercase tracking-wider" style={{ color: c!.accentColor }}>{c!.tagline}</span>
          <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
            {c!.name}
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground">{c!.description}</p>
        </div>
      </section>
      <ShopBrowser products={products} title={c!.name} description={`${products.length} products in this collection.`} />
    </>
  );
}
