import type { Metadata } from "next";
import { COLLECTIONS } from "@/data/collections";
import { SafeImg } from "@/components/common/safe-image";
import { Reveal } from "@/components/motion/reveal";
import { TiltCard } from "@/components/motion/tilt-card";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Collections",
  description: "Browse curated NOVA RIG collections: Aim Lab Essentials, Streamer Desk Kit, RGB Night Setup, and more.",
  alternates: { canonical: "https://novarig.co/collections" },
};

export default function CollectionsPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-primary">Curated gear</span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Collections
        </h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Each NOVA RIG collection is a curated gear list for a specific play style or use case. Buy the bundle, save versus buying separately.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {COLLECTIONS.map((c, i) => (
          <Reveal key={c.slug} delay={i * 0.05}>
            <TiltCard className="group relative aspect-[4/5] overflow-hidden rounded-2xl border border-white/10" maxTilt={8} scale={1.02}>
              <Link href={`/collections/${c.slug}`} className="block h-full w-full">
                { }
                <img src={c.coverImage} alt={c.name} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/60 to-transparent" />
                <div className="absolute top-4 left-4">
                  <span className="rounded-full border px-3 py-1 text-[10px] font-bold uppercase tracking-wider" style={{ color: c.accentColor, borderColor: `${c.accentColor}66`, backgroundColor: `${c.accentColor}1A` }}>
                    {c.productSlugs.length} products
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h2 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">{c.name}</h2>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-1">{c.tagline}</p>
                  <p className="mt-2 text-xs text-muted-foreground line-clamp-2">{c.description}</p>
                  <div className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider" style={{ color: c.accentColor }}>
                    View collection <ArrowRight className="h-3 w-3" />
                  </div>
                </div>
              </Link>
            </TiltCard>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
