import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "Terms of Service for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/terms" },
};

export default function TermsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Terms of Service</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Agreement to terms</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">By accessing or using novarig.co, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Use license</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Permission is granted to temporarily download one copy of the materials on NOVA RIG's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Disclaimer</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">The materials on NOVA RIG's website are provided on an 'as is' basis. NOVA RIG makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Limitations</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">In no event shall NOVA RIG or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on NOVA RIG's website.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Accuracy of materials</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">The materials appearing on NOVA RIG's website could include technical, typographical, or photographic errors. NOVA RIG does not warrant that any of the materials on its website are accurate, complete, or current.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Links</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">NOVA RIG has not reviewed all of the sites linked to its website and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by NOVA RIG of the site.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Modifications</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">NOVA RIG may revise these terms of service for its website at any time without notice. By using this website you are agreeing to be bound by the then current version of these Terms of Service.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Governing law</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">These terms and conditions are governed by and construed in accordance with the laws of Texas, and you irrevocably submit to the exclusive jurisdiction of the courts in that State or location.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Contact</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Questions about these Terms? Email support@novarig.co.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
