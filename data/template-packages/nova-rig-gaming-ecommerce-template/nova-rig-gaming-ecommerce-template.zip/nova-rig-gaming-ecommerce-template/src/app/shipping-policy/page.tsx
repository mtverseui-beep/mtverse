import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Shipping Policy",
  description: "Shipping Policy for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/shipping-policy" },
};

export default function ShippingpolicyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Shipping Policy</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Processing time</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Orders are processed within 1–2 business days from our Austin, TX warehouse. Processing time does not include weekends or holidays.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Domestic shipping (US)</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Standard shipping (3–5 business days): Free on orders over $99, otherwise $9.99. Express shipping (2 business days): $14.99. Overnight (next business day): $29.99.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">International shipping</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We ship to 80+ countries. International shipping times vary: Canada: 5–10 business days. EU/UK: 7–14 business days. Australia/NZ: 10–21 business days. Other: 14–28 business days.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Customs and duties</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">International orders may be subject to customs duties and import taxes. These are the responsibility of the recipient. We cannot mark orders as 'gift' or declare a lower value.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Tracking</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">All orders include tracking. You'll receive a tracking number by email as soon as your order ships. Track your order at /track-order.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Shipping restrictions</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We cannot ship to PO boxes for overnight delivery. Some products (batteries, magnets) have shipping restrictions to certain countries. Restricted items will be noted on the product page.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Address accuracy</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Please double-check your shipping address at checkout. We are not responsible for orders shipped to incorrect addresses provided by the customer. If your order is returned to us due to an incorrect address, we'll re-ship after you confirm the correct address and pay re-shipping costs.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
