import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "creator-bundles" as const;

export const metadata: Metadata = {
  title: "Creator Bundles",
  description: "Curated bundles of mic, cam, lights, and accessories. Save up to $136.",
  alternates: { canonical: `https://novarig.co/creator-bundles` },
};

export default function CreatorbundlesPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Creator Bundles"} description={`${products.length} products in the Creator Bundles collection.`} showCategoryFilter={false} />
    </>
  );
}
