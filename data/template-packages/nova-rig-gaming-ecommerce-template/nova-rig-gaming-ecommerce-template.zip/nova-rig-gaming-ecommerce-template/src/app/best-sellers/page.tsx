import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { PRODUCTS } from "@/data/products";

export const metadata: Metadata = {
  title: "Best Sellers — Top Gaming Gear",
  description: "Shop NOVA RIG best sellers: the keyboards, mice, headsets, and creator gear most loved by our community.",
  alternates: { canonical: `https://novarig.co/best-sellers` },
};

export default function Page() {
  const products = PRODUCTS.filter((p) => p.badge === 'best-seller');
  return (
    <ShopBrowser
      products={products}
      title={"Best sellers"}
      description={"Our most popular gear, ranked by what players, streamers, and creators actually buy."}
      showCategoryFilter
    />
  );
}
