import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "cable-management" as const;

export const metadata: Metadata = {
  title: "Cable Management",
  description: "Under-desk raceways, sleeves, and magnetic clips for a clean setup.",
  alternates: { canonical: `https://novarig.co/cable-management` },
};

export default function CablemanagementPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Cable Management"} description={`${products.length} products in the Cable Management collection.`} showCategoryFilter={false} />
    </>
  );
}
