"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { toast } from "sonner";

export default function Page() {
  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-8">
        <h1 className="font-display text-2xl font-black uppercase tracking-tight text-foreground text-center">Set a new password</h1>
        <p className="mt-2 text-sm text-muted-foreground text-center">Choose a new password for your account.</p>
        <form
          onSubmit={(e) => { e.preventDefault(); toast.success("Demo mode", { description: "This action is not wired to a backend." }); }}
          className="mt-6 space-y-4"
        >
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">New password</span>
            <input
              type="password"
              name="password"
              required
              placeholder="At least 8 characters"
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
            />
          </label>
          <label className="block">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Confirm password</span>
            <input
              type="password"
              name="confirm"
              required
              placeholder="Re-enter new password"
              className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
            />
          </label>
          <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
            Update password <ArrowRight className="h-4 w-4" />
          </button>
        </form>
      </motion.div>
    </div>
  );
}
