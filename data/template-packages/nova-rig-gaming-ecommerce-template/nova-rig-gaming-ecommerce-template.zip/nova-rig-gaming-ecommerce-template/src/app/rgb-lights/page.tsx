import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "rgb-lights" as const;

export const metadata: Metadata = {
  title: "RGB Lights",
  description: "Addressable RGB lighting bars with NOVA Sync pairing and screen sampling.",
  alternates: { canonical: `https://novarig.co/rgb-lights` },
};

export default function RgblightsPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"RGB Lights"} description={`${products.length} products in the RGB Lights collection.`} showCategoryFilter={false} />
    </>
  );
}
