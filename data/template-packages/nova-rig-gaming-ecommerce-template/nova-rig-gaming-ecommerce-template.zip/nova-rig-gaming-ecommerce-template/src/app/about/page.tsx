import type { Metadata } from "next";
import Link from "next/link";
import { Cpu, Users, Trophy, Sparkles, ArrowRight, Target, Zap, Shield } from "lucide-react";
import { PRODUCT_IMAGES } from "@/data/products";
import { Reveal } from "@/components/motion/reveal";
import { SafeImg } from "@/components/common/safe-image";

export const metadata: Metadata = {
  title: "About NOVA RIG",
  description: "NOVA RIG builds premium gaming gear, creator desk upgrades, and limited setup drops for players, streamers, and modern workstations.",
  alternates: { canonical: "https://novarig.co/about" },
};

const VALUES = [
  { icon: Target, title: "Performance first", desc: "Every product is engineered around measurable performance advantages. We publish specs, not promises." },
  { icon: Zap, title: "No compromise wireless", desc: "Modern wireless gear should match wired performance. We built our wireless stack to prove it." },
  { icon: Shield, title: "Built to last", desc: "2–5 year warranties on every product. Cold-cure foam, gas-strut arms, magnesium shells — gear that survives." },
  { icon: Users, title: "Community-driven", desc: "Our drops, bundles, and colors come from creator partnerships and community feedback. We listen." },
];

const STATS = [
  { value: "120K+", label: "Players equipped" },
  { value: "4.8", label: "Average rating" },
  { value: "80+", label: "Countries shipped" },
  { value: "2-year", label: "Standard warranty" },
];

export default function AboutPage() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-white/10">
        <SafeImg src={PRODUCT_IMAGES.setup1} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" width={1600} height={900} />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/80 to-[#070A12]/60" />
        <div className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-20 text-center">
          <Reveal>
            <span className="text-xs font-bold uppercase tracking-wider text-primary">Our story</span>
            <h1 className="mt-3 font-display text-5xl font-black uppercase tracking-tighter text-foreground sm:text-6xl">
              Built for players,<br />streamers, and<br /><span className="text-gradient-violet">modern workstations.</span>
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-base text-muted-foreground">
              NOVA RIG started with a single question: why is premium gaming gear split between expensive keyboards, cheap-feeling mice, and add-on RGB strips that don't talk to each other? We built NOVA RIG to fix that — one ecosystem, one sync, one warranty, one support team.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-b border-white/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {STATS.map((s, i) => (
              <Reveal key={s.label} delay={i * 0.06}>
                <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 text-center">
                  <div className="font-display text-3xl font-black text-foreground sm:text-4xl">{s.value}</div>
                  <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{s.label}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="text-center mb-10">
              <span className="text-xs font-bold uppercase tracking-wider text-primary">What we stand for</span>
              <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
                Four principles
              </h2>
            </div>
          </Reveal>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {VALUES.map((v, i) => (
              <Reveal key={v.title} delay={i * 0.06}>
                <div className="rounded-2xl border border-white/10 bg-[#101522] p-6">
                  <div className="grid h-12 w-12 place-items-center rounded-lg bg-primary/15 text-primary">
                    <v.icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-4 text-base font-bold text-foreground">{v.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{v.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 bg-[#0B0F1A] border-y border-white/10">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="text-center mb-10">
              <span className="text-xs font-bold uppercase tracking-wider text-primary">Our journey</span>
              <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
                How we got here
              </h2>
            </div>
          </Reveal>
          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-secondary to-accent" />
            <div className="space-y-8">
              {[
                { year: "2022", title: "First prototype", desc: "NovaKeys TKL v1 built in a garage in Austin. 12 switches, 12 mistakes, 1 working keyboard." },
                { year: "2023", title: "Launch", desc: "NovaKeys TKL Pro ships. 500 units sell out in 8 hours. Waitlist grows to 4,000." },
                { year: "2024", title: "Ecosystem", desc: "NovaMouse X1, ClutchHead Pro, and GlowBar launch with NOVA Sync pairing." },
                { year: "2025", title: "Creator focus", desc: "StreamMic Mini, Creator Cam 4K, and the first NOVA RIG creator bundles ship." },
                { year: "2026", title: "Today", desc: "120K+ players equipped. 80+ countries shipped. 4.8 average rating across all products." },
              ].map((item, i) => (
                <Reveal key={item.year} delay={i * 0.06}>
                  <div className="relative pl-12">
                    <div className="absolute left-2.5 top-1 grid h-3 w-3 place-items-center rounded-full bg-primary">
                      <span className="absolute h-3 w-3 animate-ping rounded-full bg-primary opacity-50" />
                    </div>
                    <div className="text-xs font-bold uppercase tracking-wider text-primary">{item.year}</div>
                    <h3 className="mt-1 text-base font-bold text-foreground">{item.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#101522] to-[#0B0F1A] p-8 sm:p-12 text-center">
              <Sparkles className="mx-auto h-10 w-10 text-primary" />
              <h2 className="mt-4 font-display text-3xl font-black uppercase tracking-tight text-foreground">
                Build your rig with us
              </h2>
              <p className="mt-2 max-w-xl mx-auto text-muted-foreground">
                Try our setup builder, browse the collection, or join the waitlist for the next drop.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Link href="/setup-builder" className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
                  Build setup <ArrowRight className="h-4 w-4" />
                </Link>
                <Link href="/shop" className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-foreground">
                  Shop gear
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
