import type { MetadataRoute } from "next";
import { PRODUCTS } from "@/data/products";
import { COLLECTIONS, CATEGORIES } from "@/data/collections";
import { BLOG_POSTS, BUYING_GUIDES, CREATORS, SETUP_GALLERY } from "@/data/content";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://novarig.co";
  const now = new Date();

  const staticRoutes = [
    "", "/shop", "/cart", "/checkout", "/wishlist", "/compare", "/search",
    "/new-arrivals", "/best-sellers", "/limited-drops", "/sale", "/collections",
    "/setup-builder", "/bundle-builder", "/drop-calendar", "/gift-cards", "/rewards",
    "/track-order", "/recently-viewed", "/about", "/our-story", "/setup-gallery",
    "/creators", "/reviews", "/blog", "/buying-guides", "/contact", "/help",
    "/faq", "/size-and-compatibility", "/warranty", "/shipping-policy",
    "/returns-policy", "/refund-policy", "/privacy", "/terms", "/cookies",
    "/accessibility", "/stockists", "/sign-in", "/sign-up",
    // Category routes
    ...CATEGORIES.map((c) => `/${c.slug}`),
    // Help sub-routes
    "/help/shipping", "/help/returns", "/help/orders", "/help/payments", "/help/warranty",
  ];

  const productRoutes = PRODUCTS.map((p) => `/product/${p.slug}`);
  const collectionRoutes = COLLECTIONS.map((c) => `/collections/${c.slug}`);
  const blogRoutes = BLOG_POSTS.map((p) => `/blog/${p.slug}`);
  const guideRoutes = BUYING_GUIDES.map((g) => `/buying-guides/${g.slug}`);
  const creatorRoutes = CREATORS.map((c) => `/creators/${c.slug}`);
  const setupRoutes = SETUP_GALLERY.map((s) => `/setup-gallery/${s.slug}`);

  const allRoutes = [
    ...staticRoutes,
    ...productRoutes,
    ...collectionRoutes,
    ...blogRoutes,
    ...guideRoutes,
    ...creatorRoutes,
    ...setupRoutes,
  ];

  return allRoutes.map((route) => ({
    url: `${base}${route}`,
    lastModified: now,
    changeFrequency: "weekly" as const,
    priority: route === "" ? 1 : route.startsWith("/product/") ? 0.8 : 0.6,
  }));
}
