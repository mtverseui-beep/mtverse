import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { BUYING_GUIDES, getBuyingGuideBySlug } from "@/data/content";
import { getProductBySlug } from "@/data/products";
import { SafeImg } from "@/components/common/safe-image";
import { ProductCard } from "@/components/product/product-card";
import { Reveal } from "@/components/motion/reveal";
import { ArrowLeft, ArrowRight, Clock, Calendar } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return BUYING_GUIDES.map((g) => ({ slug: g.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const g = getBuyingGuideBySlug(slug);
  if (!g) return { title: "Guide not found" };
  return { title: g.title, description: g.excerpt, alternates: { canonical: `https://novarig.co/buying-guides/${g.slug}` } };
}

export default async function BuyingGuideDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const guide = getBuyingGuideBySlug(slug);
  if (!guide) notFound();
  const relatedProducts = guide!.relatedProductSlugs.map((s) => getProductBySlug(s)).filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <div>
      <section className="relative h-[50vh] overflow-hidden border-b border-white/10">
        <SafeImg src={guide!.cover} alt={guide!.title} className="absolute inset-0 h-full w-full object-cover" width={1600} height={900} loading="eager" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/70 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
          <Link href="/buying-guides" className="inline-flex items-center gap-1.5 text-xs font-semibold text-foreground/80 hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to buying guides
          </Link>
          <div className="mt-4 flex flex-wrap items-center gap-3 text-xs">
            <span className="rounded-full bg-accent/15 border border-accent/30 px-2 py-0.5 font-bold uppercase tracking-wider text-accent">{guide!.difficulty}</span>
            <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 font-bold uppercase tracking-wider text-foreground">{guide!.category}</span>
            <span className="flex items-center gap-1 text-muted-foreground"><Clock className="h-3 w-3" /> {guide!.readingTime}</span>
            <span className="flex items-center gap-1 text-muted-foreground"><Calendar className="h-3 w-3" /> Updated {formatDate(guide!.updated)}</span>
          </div>
          <h1 className="mt-4 font-display text-3xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
            {guide!.title}
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">{guide!.excerpt}</p>
        </div>
      </section>

      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="space-y-6">
          {guide!.content.map((block, i) => (
            <Reveal key={i}>
              {block.heading ? <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground">{block.heading}</h2> : null}
              <p className="text-base text-foreground/90 leading-relaxed">{block.body}</p>
            </Reveal>
          ))}
        </div>
      </div>

      {relatedProducts.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 border-t border-white/10">
          <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-foreground mb-6">Recommended gear</h2>
          <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
            {relatedProducts.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  );
}
