import type { Metadata } from "next";
import { BUYING_GUIDES } from "@/data/content";
import { Reveal } from "@/components/motion/reveal";
import { SafeImg } from "@/components/common/safe-image";
import Link from "next/link";
import { BookOpen, ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Buying Guides — NOVA RIG",
  description: "In-depth buying guides for gaming keyboards, mice, microphones, webcams, and complete desk setups.",
  alternates: { canonical: "https://novarig.co/buying-guides" },
};

export default function BuyingGuidesPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-accent flex items-center gap-2">
          <BookOpen className="h-3.5 w-3.5" /> Buying guides
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Pick the right gear
        </h1>
        <p className="mt-3 max-w-xl text-muted-foreground">
          In-depth guides on every category. Specs, trade-offs, and recommendations based on real use.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {BUYING_GUIDES.map((g, i) => (
          <Reveal key={g.slug} delay={i * 0.06}>
            <Link href={`/buying-guides/${g.slug}`} className="group flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#0B0F1A] hover:border-accent/30">
              <div className="aspect-video overflow-hidden bg-[#101522]">
                <SafeImg src={g.cover} alt={g.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" width={400} height={225} />
              </div>
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-xs">
                  <span className="rounded-full bg-accent/15 border border-accent/30 px-2 py-0.5 font-bold uppercase tracking-wider text-accent">{g.difficulty}</span>
                  <span className="text-muted-foreground">{g.readingTime}</span>
                </div>
                <h3 className="mt-3 font-bold text-foreground line-clamp-2 group-hover:text-accent">{g.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground line-clamp-2 flex-1">{g.excerpt}</p>
                <div className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-accent">
                  Read guide <ArrowRight className="h-3 w-3" />
                </div>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
