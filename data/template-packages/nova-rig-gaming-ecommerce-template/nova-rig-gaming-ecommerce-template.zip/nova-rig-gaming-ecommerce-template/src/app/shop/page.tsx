import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { PRODUCTS } from "@/data/products";

export const metadata: Metadata = {
  title: "Shop All Gaming Gear",
  description:
    "Browse all NOVA RIG gaming gear: keyboards, mice, headsets, desk mats, RGB lights, microphones, webcams, monitor arms, and creator bundles.",
  alternates: { canonical: "https://novarig.co/shop" },
};

export default function ShopPage() {
  return <ShopBrowser products={PRODUCTS} title="Shop all gear" description="Premium gaming gear, creator desk upgrades, and limited drops. Filter by category, price, compatibility, and setup type." />;
}
