import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ShopBrowser } from "@/components/product/shop-browser";
import { PRODUCTS, getProductsByCategory } from "@/data/products";
import { CATEGORIES, getCategoryBySlug } from "@/data/collections";

interface PageProps {
  params: Promise<{ category: string }>;
}

export async function generateStaticParams() {
  return CATEGORIES.map((c) => ({ category: c.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { category } = await params;
  const cat = getCategoryBySlug(category);
  if (!cat) return { title: "Category not found" };
  return {
    title: `${cat.name} — ${cat.tagline}`,
    description: cat.description,
    alternates: { canonical: `https://novarig.co/${cat.slug}` },
  };
}

export default async function CategoryPage({ params }: PageProps) {
  const { category } = await params;
  const cat = getCategoryBySlug(category);
  if (!cat) notFound();
  const products = getProductsByCategory(category);

  return (
    <>
      {/* Hero header */}
      <section className="relative overflow-hidden border-b border-white/10">
        { }
        <img src={cat!.heroImage} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/80 to-[#070A12]/60" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
          <span className="text-xs font-bold uppercase tracking-wider text-primary">{cat!.tagline}</span>
          <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl lg:text-6xl">
            {cat!.name}
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground">{cat!.description}</p>
        </div>
      </section>
      <ShopBrowser
        products={products}
        title={`${cat!.name} gear`}
        description={`${products.length} products in the ${cat!.name} collection.`}
        showCategoryFilter={false}
      />
    </>
  );
}
