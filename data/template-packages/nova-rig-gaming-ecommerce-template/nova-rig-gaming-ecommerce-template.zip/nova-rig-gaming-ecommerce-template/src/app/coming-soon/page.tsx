"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Sparkles, ArrowRight } from "lucide-react";

export default function ComingSoonPage() {
  return (
    <div className="grid min-h-[70vh] place-items-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <Sparkles className="mx-auto h-16 w-16 text-primary" />
        <h1 className="mt-4 font-display text-3xl font-bold uppercase tracking-tight text-foreground sm:text-4xl">
          Coming soon
        </h1>
        <p className="mt-2 max-w-md mx-auto text-muted-foreground">
          This page is in the works. Check back soon for updates.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white"
        >
          Back to home <ArrowRight className="h-4 w-4" />
        </Link>
      </motion.div>
    </div>
  );
}
