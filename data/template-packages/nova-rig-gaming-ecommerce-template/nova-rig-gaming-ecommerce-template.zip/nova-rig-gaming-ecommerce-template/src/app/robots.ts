import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/", disallow: ["/checkout", "/account", "/cart"] },
    sitemap: "https://novarig.co/sitemap.xml",
  };
}
