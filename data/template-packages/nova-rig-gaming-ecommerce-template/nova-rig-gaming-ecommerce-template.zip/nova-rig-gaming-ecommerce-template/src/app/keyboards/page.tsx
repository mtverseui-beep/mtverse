import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "keyboards" as const;

export const metadata: Metadata = {
  title: "Gaming Keyboards",
  description: "Mechanical keyboards with hot-swap PCBs, 8000Hz polling, and tri-mode wireless. TKL, 75%, and 60% layouts from NOVA RIG.",
  alternates: { canonical: "https://novarig.co/keyboards" },
};

export default function KeyboardsPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title="Keyboards" description={`${products.length} mechanical keyboards with hot-swap PCBs, 8000Hz polling, and tri-mode wireless.`} showCategoryFilter={false} />
    </>
  );
}
