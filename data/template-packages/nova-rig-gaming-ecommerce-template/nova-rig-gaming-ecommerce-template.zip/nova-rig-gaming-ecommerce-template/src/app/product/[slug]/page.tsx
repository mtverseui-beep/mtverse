import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ProductDetail } from "@/components/product/product-detail";
import { ProductCard } from "@/components/product/product-card";
import { PRODUCTS, getProductBySlug, getRelatedProducts } from "@/data/products";
import { Reveal } from "@/components/motion/reveal";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return PRODUCTS.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = getProductBySlug(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: `${product.name} — ${product.shortDescription}`,
    description: product.description.slice(0, 160),
    alternates: { canonical: `https://novarig.co/product/${product.slug}` },
    openGraph: {
      title: product.name,
      description: product.shortDescription,
      images: product.images,
      type: "website",
    },
  };
}

export default async function ProductPage({ params }: PageProps) {
  const { slug } = await params;
  const product = getProductBySlug(slug);
  if (!product) notFound();
  const related = getRelatedProducts(product, 4);

  // JSON-LD product schema
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    image: product.images,
    description: product.description,
    sku: product.id,
    brand: { "@type": "Brand", name: "NOVA RIG" },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: product.rating,
      reviewCount: product.reviewCount,
    },
    offers: {
      "@type": "Offer",
      price: product.price,
      priceCurrency: product.currency,
      availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      url: `https://novarig.co/product/${product.slug}`,
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <ProductDetail product={product} />

      {/* Related products */}
      {related.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 border-t border-white/10 mt-12">
          <Reveal>
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-primary">You may also like</span>
              <h2 className="mt-2 font-display text-2xl font-black uppercase tracking-tight text-foreground">
                Related gear
              </h2>
            </div>
          </Reveal>
          <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* Complete the setup */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 border-t border-white/10">
        <Reveal>
          <div className="rounded-2xl border border-primary/30 bg-primary/5 p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-primary">Complete the setup</span>
                <h2 className="mt-1 font-display text-xl font-bold uppercase tracking-tight text-foreground">
                  Build a full setup with this gear
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Use our setup builder to add compatible gear and save on bundles.
                </p>
              </div>
              <Link
                href="/setup-builder"
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-bold text-white hover:bg-primary/90"
              >
                Open setup builder
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
