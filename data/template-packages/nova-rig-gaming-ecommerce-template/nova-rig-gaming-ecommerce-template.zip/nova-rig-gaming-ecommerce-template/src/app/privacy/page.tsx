import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "Privacy Policy for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/privacy" },
};

export default function PrivacyPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Privacy Policy</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Introduction</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">This Privacy Policy explains how NOVA RIG (“we”, “us”, “our”) collects, uses, and protects your personal information when you visit novarig.co or purchase our products. By using our website, you agree to the practices described in this policy.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Information we collect</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We collect information you provide directly: name, email, shipping address, phone number, and payment information. We also collect information automatically: IP address, browser type, pages visited, and order history through cookies and similar technologies.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">How we use your information</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We use your information to process orders, ship products, respond to support inquiries, send order updates, prevent fraud, and improve our products and services. With your consent, we may send marketing emails about new products, drops, and guides.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Information sharing</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We share information with service providers who help us run our business: payment processors (Stripe, PayPal), shipping carriers (UPS, FedEx, USPS), email service providers, and analytics providers. We never sell your personal information to third parties.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Data retention</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We retain order information for 7 years for tax and legal purposes. Marketing preferences are retained until you opt out. You can request deletion of your account data at any time by emailing support@novarig.co.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Your rights</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">You have the right to access, correct, or delete your personal information. You can also opt out of marketing emails at any time using the unsubscribe link in any email. To exercise these rights, email support@novarig.co.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Cookies</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We use cookies to power your cart, wishlist, recently viewed items, and to analyze website traffic. See our Cookie Policy for details. You can control cookies through your browser settings.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Security</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We use industry-standard encryption (TLS 1.3) for all data transmission. Payment information is processed by PCI-DSS compliant processors and never stored on our servers. Access to personal information is restricted to authorized personnel only.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Children's privacy</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Our website is not directed at children under 13. We do not knowingly collect personal information from children under 13. If you believe we have collected such information, please contact us.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Changes to this policy</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We may update this Privacy Policy from time to time. We'll notify you of significant changes by email or by posting a notice on our website. The effective date is shown at the top of this policy.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Contact us</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Questions about this Privacy Policy? Email us at support@novarig.co or write to NOVA RIG, PO Box 14210, Austin, TX 78701.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
