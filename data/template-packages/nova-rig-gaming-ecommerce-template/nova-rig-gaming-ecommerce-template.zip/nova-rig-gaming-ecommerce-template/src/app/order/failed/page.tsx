import Link from "next/link";
import { XCircle, ArrowRight, LifeBuoy } from "lucide-react";

export const metadata = { title: "Order failed", robots: { index: false, follow: false } };

export default function OrderFailedPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-20 text-center">
      <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-danger/20 text-danger">
        <XCircle className="h-10 w-10" />
      </div>
      <h1 className="mt-6 font-display text-3xl font-black uppercase tracking-tight text-foreground">Payment failed</h1>
      <p className="mt-2 text-muted-foreground">
        Your payment could not be processed. No charges have been made. Please try again or use a different payment method.
      </p>
      <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
        <Link href="/checkout" className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
          Try again <ArrowRight className="h-4 w-4" />
        </Link>
        <Link href="/help/payments" className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-foreground">
          <LifeBuoy className="h-4 w-4" /> Get help
        </Link>
      </div>
    </div>
  );
}
