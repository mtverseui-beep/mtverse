"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { motion } from "framer-motion";
import { CheckCircle2, Truck, Package, Clock, ArrowRight } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface OrderData {
  id: string;
  date: string;
  status: string;
  items: any[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  estimatedDelivery: string;
  paymentMethod: string;
  shippingAddress: any;
}

export default function OrderDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [order, setOrder] = useState<OrderData | null>(null);

  useEffect(() => {
    try {
      const orders = JSON.parse(localStorage.getItem("nova-rig-orders") ?? "[]");
      const found = orders.find((o: OrderData) => o.id === id);
      if (found) setOrder(found);
    } catch {}
  }, [id]);

  if (!order) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-black uppercase tracking-tight text-foreground">Order not found</h1>
        <p className="mt-2 text-muted-foreground">We couldn't find an order with ID {id}.</p>
        <Link href="/track-order" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
          Track another order
        </Link>
      </div>
    );
  }

  const timeline = [
    { label: "Order placed", date: order.date, done: true, icon: CheckCircle2 },
    { label: "Processing", date: null, done: order.status !== "processing" || true, icon: Package },
    { label: "Shipped", date: null, done: false, icon: Truck },
    { label: "Delivered", date: order.estimatedDelivery, done: false, icon: Clock },
  ];

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="mb-6">
        <span className="text-xs font-bold uppercase tracking-wider text-primary">Order</span>
        <h1 className="mt-1 font-display text-3xl font-black uppercase tracking-tight text-foreground">#{order.id}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Placed on {formatDate(order.date)}</p>
      </div>

      {/* Timeline */}
      <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 mb-6">
        <h2 className="font-bold text-foreground mb-4">Delivery timeline</h2>
        <div className="space-y-4">
          {timeline.map((step, i) => (
            <motion.div
              key={step.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-3"
            >
              <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-full ${step.done ? "bg-accent text-black" : "bg-white/5 text-muted-foreground"}`}>
                <step.icon className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <div className={`text-sm font-semibold ${step.done ? "text-foreground" : "text-muted-foreground"}`}>{step.label}</div>
                {step.date && <div className="text-xs text-muted-foreground">{formatDate(step.date)}</div>}
              </div>
              {step.done && <CheckCircle2 className="h-4 w-4 text-accent" />}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Items */}
      <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 mb-6">
        <h2 className="font-bold text-foreground mb-4">Items</h2>
        <div className="space-y-3">
          {order.items.map((item: any) => (
            <div key={item.id} className="flex justify-between text-sm">
              <div>
                <div className="font-semibold text-foreground">{item.quantity}× {item.name}</div>
                {(item.variant || item.color) && (
                  <div className="text-xs text-muted-foreground">{[item.variant, item.color].filter(Boolean).join(" · ")}</div>
                )}
              </div>
              <div className="font-bold text-foreground">${(item.price * item.quantity).toFixed(2)}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-1 border-t border-white/10 pt-3 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>${order.subtotal.toFixed(2)}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span>{order.shipping === 0 ? "Free" : `$${order.shipping.toFixed(2)}`}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Tax</span><span>${order.tax.toFixed(2)}</span></div>
          <div className="flex justify-between border-t border-white/10 pt-2 text-base font-bold"><span>Total</span><span>${order.total.toFixed(2)}</span></div>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <h3 className="font-bold text-foreground mb-2">Shipping address</h3>
          <p className="text-sm text-muted-foreground">
            {order.shippingAddress?.fullName ?? "Demo Customer"}<br />
            {order.shippingAddress?.line1 ?? "1234 Main St"}<br />
            {order.shippingAddress?.city ?? "Austin"}, {order.shippingAddress?.state ?? "TX"} {order.shippingAddress?.zip ?? "78701"}<br />
            {order.shippingAddress?.country ?? "United States"}
          </p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <h3 className="font-bold text-foreground mb-2">Payment</h3>
          <p className="text-sm text-muted-foreground">{order.paymentMethod}</p>
          <Link href="/help/payments" className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline">
            Payment help <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
      </div>

      <div className="mt-6 flex justify-center">
        <Link href="/shop" className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-foreground hover:bg-white/10">
          Continue shopping <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
