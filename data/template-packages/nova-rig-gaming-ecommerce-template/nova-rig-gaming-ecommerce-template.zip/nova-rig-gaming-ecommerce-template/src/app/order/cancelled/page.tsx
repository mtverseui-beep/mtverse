import Link from "next/link";
import { Ban, ArrowRight } from "lucide-react";

export const metadata = { title: "Order cancelled", robots: { index: false, follow: false } };

export default function OrderCancelledPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-20 text-center">
      <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-warning/20 text-warning">
        <Ban className="h-10 w-10" />
      </div>
      <h1 className="mt-6 font-display text-3xl font-black uppercase tracking-tight text-foreground">Order cancelled</h1>
      <p className="mt-2 text-muted-foreground">
        Your order has been cancelled. No charges have been made. Your cart has been saved if you'd like to try again later.
      </p>
      <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
        <Link href="/cart" className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
          Return to cart <ArrowRight className="h-4 w-4" />
        </Link>
        <Link href="/shop" className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-foreground">
          Continue shopping
        </Link>
      </div>
    </div>
  );
}
