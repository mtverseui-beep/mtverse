"use client";

import { useEffect, useState, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { CheckCircle2, Truck, Mail, ArrowRight, Package } from "lucide-react";

function SuccessContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get("id") ?? "NR-DEMO1234";
  const [order, setOrder] = useState<any>(null);

  useEffect(() => {
    try {
      const orders = JSON.parse(localStorage.getItem("nova-rig-orders") ?? "[]");
      const found = orders.find((o: any) => o.id === orderId);
      if (found) setOrder(found);
    } catch {}
  }, [orderId]);

  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
        className="text-center"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.2 }}
          className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-accent/20 text-accent glow-acid"
        >
          <CheckCircle2 className="h-10 w-10" />
        </motion.div>
        <h1 className="mt-6 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
          Order confirmed
        </h1>
        <p className="mt-2 text-muted-foreground">
          Thank you. Your order is being prepared for shipment.
        </p>
        <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm font-bold text-primary">
          <Package className="h-4 w-4" /> Order #{orderId}
        </div>
      </motion.div>

      {/* Email confirmation */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-8 rounded-xl border border-white/10 bg-[#0B0F1A] p-4 flex items-center gap-3"
      >
        <Mail className="h-5 w-5 text-primary shrink-0" />
        <p className="text-sm text-muted-foreground">
          A confirmation email has been sent to your inbox with your order details and tracking information once it ships.
        </p>
      </motion.div>

      {/* Order summary */}
      {order && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-6 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6"
        >
          <h2 className="font-bold text-foreground mb-4">Order summary</h2>
          <div className="space-y-2 text-sm">
            {order.items.map((item: any) => (
              <div key={item.id} className="flex justify-between">
                <span className="text-muted-foreground">{item.quantity}× {item.name}</span>
                <span className="font-semibold text-foreground">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-1 border-t border-white/10 pt-3 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>${order.subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span>{order.shipping === 0 ? "Free" : `$${order.shipping.toFixed(2)}`}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Tax</span><span>${order.tax.toFixed(2)}</span></div>
            <div className="flex justify-between border-t border-white/10 pt-2 text-base font-bold"><span>Total</span><span>${order.total.toFixed(2)}</span></div>
          </div>
        </motion.div>
      )}

      {/* Delivery timeline */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-6 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6"
      >
        <h2 className="font-bold text-foreground mb-4 flex items-center gap-2">
          <Truck className="h-5 w-5 text-primary" /> Estimated delivery
        </h2>
        <div className="grid grid-cols-4 gap-2 text-center">
          {[
            { label: "Ordered", active: true, done: true },
            { label: "Processing", active: true, done: false },
            { label: "Shipped", active: false, done: false },
            { label: "Delivered", active: false, done: false },
          ].map((s, i) => (
            <div key={s.label} className="relative">
              <div className={`mx-auto grid h-10 w-10 place-items-center rounded-full ${s.done ? "bg-accent text-black" : s.active ? "bg-primary text-white" : "bg-white/5 text-muted-foreground"}`}>
                {s.done ? <CheckCircle2 className="h-5 w-5" /> : i + 1}
              </div>
              <div className={`mt-2 text-xs font-semibold ${s.active ? "text-foreground" : "text-muted-foreground"}`}>{s.label}</div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* CTAs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-6 flex flex-col sm:flex-row gap-3 justify-center"
      >
        <Link
          href={`/order/${orderId}`}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white"
        >
          Track order <ArrowRight className="h-4 w-4" />
        </Link>
        <Link
          href="/shop"
          className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-foreground hover:bg-white/10"
        >
          Continue shopping
        </Link>
      </motion.div>
    </div>
  );
}

export default function OrderSuccessPage() {
  return (
    <Suspense fallback={<div className="py-20 text-center text-muted-foreground">Loading...</div>}>
      <SuccessContent />
    </Suspense>
  );
}
