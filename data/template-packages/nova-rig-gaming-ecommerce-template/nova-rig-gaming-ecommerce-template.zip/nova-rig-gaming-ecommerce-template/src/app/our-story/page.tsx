import type { Metadata } from "next";
import Link from "next/link";
import { Reveal } from "@/components/motion/reveal";
import { SafeImg } from "@/components/common/safe-image";
import { PRODUCT_IMAGES } from "@/data/products";
import { ArrowRight, Quote, Target, Eye, Heart } from "lucide-react";

export const metadata: Metadata = {
  title: "Our Story",
  description: "The NOVA RIG story — from garage prototype to a global gaming gear ecosystem.",
  alternates: { canonical: "https://novarig.co/our-story" },
};

export default function OurStoryPage() {
  return (
    <div>
      <section className="relative overflow-hidden border-b border-white/10">
        <SafeImg src={PRODUCT_IMAGES.setup2} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" width={1600} height={900} />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/80 to-[#070A12]/60" />
        <div className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-20 text-center">
          <Reveal>
            <span className="text-xs font-bold uppercase tracking-wider text-primary">Our story</span>
            <h1 className="mt-3 font-display text-5xl font-black uppercase tracking-tighter text-foreground sm:text-6xl">
              From garage to global
            </h1>
          </Reveal>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 prose prose-invert prose-lg max-w-none">
          <Reveal>
            <p className="text-lg text-foreground">
              In 2022, our founder was a competitive FPS player who couldn't find a keyboard that felt right, a mouse that wasn't too heavy, and RGB lighting that didn't look like a kid's toy aisle. So he built his own.
            </p>
          </Reveal>
          <Reveal>
            <p className="text-muted-foreground">
              The first NovaKeys TKL was built in an Austin garage over six months. Twelve prototypes. Twelve mistakes. The thirteenth felt right — a deep, confident thock on every press, an 8000Hz polling rate that made aim feel snappier, and a CNC aluminum shell that could survive a tournament flight.
            </p>
          </Reveal>
          <Reveal>
            <p className="text-muted-foreground">
              We sold 500 units in 8 hours. The waitlist grew to 4,000. We knew we had something.
            </p>
          </Reveal>
          <Reveal>
            <Quote className="mx-auto my-8 h-10 w-10 text-primary/40" />
          </Reveal>
          <Reveal>
            <blockquote className="border-l-4 border-primary pl-4 text-xl italic text-foreground">
              "We don't make gear for everyone. We make gear for players who measure advantage in milliseconds, streamers who need broadcast-quality audio without broadcast-complexity setup, and creators who refuse to choose between performance and aesthetics."
            </blockquote>
          </Reveal>
        </div>
      </section>

      {/* Mission / Vision / Values */}
      <section className="py-16 bg-[#0B0F1A] border-y border-white/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              { icon: Target, title: "Mission", desc: "Build the most coherent gaming gear ecosystem on the market — one sync, one warranty, one support team." },
              { icon: Eye, title: "Vision", desc: "A world where every player's setup feels custom-engineered, regardless of budget or skill level." },
              { icon: Heart, title: "Values", desc: "Performance first, no compromise wireless, built to last, community-driven. Always." },
            ].map((v, i) => (
              <Reveal key={v.title} delay={i * 0.08}>
                <div className="rounded-2xl border border-white/10 bg-[#101522] p-6">
                  <div className="grid h-12 w-12 place-items-center rounded-lg bg-primary/15 text-primary">
                    <v.icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-4 text-lg font-bold text-foreground">{v.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{v.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 text-center">
        <Reveal>
          <div className="mx-auto max-w-2xl px-4">
            <h2 className="font-display text-3xl font-black uppercase tracking-tight text-foreground">
              Join the journey
            </h2>
            <p className="mt-3 text-muted-foreground">
              Be part of the next chapter. Try our gear, join the waitlist, or follow along.
            </p>
            <div className="mt-6 flex justify-center gap-3">
              <Link href="/shop" className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
                Shop gear <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/creators" className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-bold text-foreground">
                Meet our creators
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
