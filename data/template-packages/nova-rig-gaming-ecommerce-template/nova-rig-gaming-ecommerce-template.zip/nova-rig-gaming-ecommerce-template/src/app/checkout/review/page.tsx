"use client";

import { useState } from "react";
import { CheckoutShell } from "@/components/checkout/checkout-shell";
import { useRouter } from "next/navigation";
import { useShopStore } from "@/lib/shop-store";
import { formatPrice, safeId } from "@/lib/utils";
import { Check, ShieldCheck, Truck, RotateCcw, Lock } from "lucide-react";

export default function CheckoutReviewPage() {
  const router = useRouter();
  const { cart, cartSubtotal, clearCart } = useShopStore();
  const [loading, setLoading] = useState(false);

  const subtotal = cartSubtotal();
  const shipping = subtotal >= 99 ? 0 : 9.99;
  const tax = subtotal * 0.0825;
  const total = subtotal + shipping + tax;

  const placeOrder = () => {
    setLoading(true);
    setTimeout(() => {
      const orderId = `NR-${Date.now().toString().slice(-8)}`;
      try {
        const orders = JSON.parse(localStorage.getItem("nova-rig-orders") ?? "[]");
        orders.push({
          id: orderId,
          date: new Date().toISOString(),
          status: "processing",
          items: cart,
          subtotal,
          shipping,
          tax,
          total,
          shippingAddress: { city: "—", state: "—", country: "United States" },
          estimatedDelivery: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
          paymentMethod: "Card ending in 4242",
        });
        localStorage.setItem("nova-rig-orders", JSON.stringify(orders));
      } catch {}
      clearCart();
      router.push(`/order/success?id=${orderId}`);
    }, 1400);
  };

  return (
    <CheckoutShell step="review" title="Review & place order">
      <div className="space-y-4">
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <h2 className="font-bold text-foreground mb-3">Review your order</h2>
          <div className="space-y-2 text-sm">
            {cart.map((item) => (
              <div key={item.id} className="flex justify-between">
                <span className="text-muted-foreground">
                  {item.quantity}× {item.name}
                </span>
                <span className="font-semibold text-foreground">{formatPrice(item.price * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-2 border-t border-white/10 pt-4 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatPrice(subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span>{shipping === 0 ? "Free" : formatPrice(shipping)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Tax</span><span>{formatPrice(tax)}</span></div>
            <div className="flex justify-between border-t border-white/10 pt-2 text-base font-bold">
              <span>Total</span><span>{formatPrice(total)}</span>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <h2 className="font-bold text-foreground mb-3">Ship to</h2>
          <p className="text-sm text-muted-foreground">
            Demo Customer<br />
            1234 Main St<br />
            Austin, TX 78701<br />
            United States
          </p>
        </div>

        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <h2 className="font-bold text-foreground mb-3">Payment</h2>
          <p className="text-sm text-muted-foreground flex items-center gap-2">
            <Lock className="h-3.5 w-3.5 text-accent" /> Card ending in 4242
          </p>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
            <ShieldCheck className="mx-auto h-5 w-5 text-accent" />
            <div className="mt-1 text-muted-foreground">2-year warranty</div>
          </div>
          <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
            <RotateCcw className="mx-auto h-5 w-5 text-primary" />
            <div className="mt-1 text-muted-foreground">30-day returns</div>
          </div>
          <div className="rounded-lg border border-white/10 bg-white/[0.02] p-3">
            <Truck className="mx-auto h-5 w-5 text-secondary" />
            <div className="mt-1 text-muted-foreground">Ships in 1–2 days</div>
          </div>
        </div>

        <button
          onClick={placeOrder}
          disabled={loading}
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-primary/30 hover:bg-primary/90 disabled:opacity-60"
        >
          {loading ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
              Placing order...
            </>
          ) : (
            <>
              <Check className="h-4 w-4" /> Place order · {formatPrice(total)}
            </>
          )}
        </button>

        <p className="text-center text-xs text-muted-foreground">
          By placing your order, you agree to our <a href="/terms" className="text-primary hover:underline">Terms</a> and <a href="/privacy" className="text-primary hover:underline">Privacy Policy</a>.
        </p>
      </div>
    </CheckoutShell>
  );
}
