import type { Metadata } from "next";
import { CheckoutShell, CheckoutButton } from "@/components/checkout/checkout-shell";
import { Truck, Zap, Clock } from "lucide-react";

export const metadata: Metadata = {
  title: "Checkout — Shipping method",
  description: "Choose your shipping method.",
  robots: { index: false, follow: false },
};

const METHODS = [
  { id: "standard", label: "Standard shipping", desc: "3–5 business days", price: "Free over $99", icon: Truck, default: true },
  { id: "express", label: "Express shipping", desc: "2 business days", price: "+$14.99", icon: Zap },
  { id: "overnight", label: "Overnight", desc: "Next business day", price: "+$29.99", icon: Clock },
];

export default function CheckoutShippingPage() {
  return (
    <CheckoutShell step="shipping" title="Shipping method">
      <form action="/checkout/payment" className="space-y-4">
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 space-y-3">
          <h2 className="font-bold text-foreground mb-2">Choose a shipping method</h2>
          {METHODS.map((m) => (
            <label
              key={m.id}
              className="flex cursor-pointer items-center gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-4 hover:border-primary/40 has-[:checked]:border-primary has-[:checked]:bg-primary/5"
            >
              <input type="radio" name="method" value={m.id} defaultChecked={m.default} className="text-primary" />
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary">
                <m.icon className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <div className="font-bold text-foreground">{m.label}</div>
                <div className="text-xs text-muted-foreground">{m.desc}</div>
              </div>
              <div className="text-sm font-bold text-foreground">{m.price}</div>
            </label>
          ))}
        </div>

        <CheckoutButton href="/checkout/payment">Continue to payment</CheckoutButton>
      </form>
    </CheckoutShell>
  );
}
