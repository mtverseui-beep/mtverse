import type { Metadata } from "next";
import { CheckoutShell, CheckoutInput, CheckoutButton } from "@/components/checkout/checkout-shell";
import { CreditCard, Lock } from "lucide-react";

export const metadata: Metadata = {
  title: "Checkout — Payment",
  description: "Enter your payment details securely.",
  robots: { index: false, follow: false },
};

export default function CheckoutPaymentPage() {
  return (
    <CheckoutShell step="payment" title="Payment">
      <form action="/checkout/review" className="space-y-4">
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-foreground">Payment method</h2>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Lock className="h-3.5 w-3.5 text-accent" /> Encrypted
            </div>
          </div>

          {/* Method tabs */}
          <div className="grid grid-cols-3 gap-2">
            {["Card", "PayPal", "Apple Pay"].map((m, i) => (
              <label
                key={m}
                className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-white/10 bg-white/[0.02] p-3 text-sm font-semibold text-foreground hover:border-primary/40 has-[:checked]:border-primary has-[:checked]:bg-primary/5"
              >
                <input type="radio" name="method" defaultChecked={i === 0} className="sr-only" />
                <CreditCard className="h-4 w-4 text-primary" />
                {m}
              </label>
            ))}
          </div>

          <CheckoutInput label="Card number" name="card" placeholder="1234 5678 9012 3456" inputMode="numeric" required />
          <div className="grid gap-3 sm:grid-cols-3">
            <CheckoutInput label="Expiry" name="exp" placeholder="MM/YY" required />
            <CheckoutInput label="CVC" name="cvc" placeholder="123" inputMode="numeric" required />
            <CheckoutInput label="ZIP" name="zip" placeholder="12345" required />
          </div>
          <CheckoutInput label="Name on card" name="name" required />

          <p className="text-xs text-muted-foreground">
            This is a demo store. No real payment will be processed. Use any card details to test.
          </p>
        </div>

        <CheckoutButton href="/checkout/review">Review order</CheckoutButton>
      </form>
    </CheckoutShell>
  );
}
