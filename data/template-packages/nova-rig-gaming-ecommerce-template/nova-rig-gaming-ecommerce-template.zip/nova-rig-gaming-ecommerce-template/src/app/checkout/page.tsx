import type { Metadata } from "next";
import { CheckoutShell, CheckoutInput, CheckoutButton } from "@/components/checkout/checkout-shell";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Checkout — Information",
  description: "Enter your shipping information to continue checkout.",
  robots: { index: false, follow: false },
};

export default function CheckoutInfoPage() {
  return (
    <CheckoutShell step="info" title="Contact & shipping">
      <form action="/checkout/shipping" className="space-y-6" method="get">
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 space-y-4">
          <h2 className="font-bold text-foreground">Contact information</h2>
          <CheckoutInput label="Email" type="email" name="email" placeholder="you@example.com" required />
          <div className="flex items-center gap-2">
            <input type="checkbox" id="news" className="rounded border-white/20 bg-white/5 text-primary" />
            <label htmlFor="news" className="text-sm text-muted-foreground">Email me about drops, deals, and guides</label>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-foreground">Shipping address</h2>
            <Link href="/sign-in" className="text-xs text-primary hover:underline">Already have an account? Sign in</Link>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <CheckoutInput label="First name" name="firstName" required />
            <CheckoutInput label="Last name" name="lastName" required />
          </div>
          <CheckoutInput label="Address" name="address1" placeholder="1234 Main St" required />
          <CheckoutInput label="Apartment, suite, etc. (optional)" name="address2" />
          <div className="grid gap-3 sm:grid-cols-3">
            <CheckoutInput label="City" name="city" required />
            <CheckoutInput label="State / Province" name="state" required />
            <CheckoutInput label="ZIP / Postal code" name="zip" required />
          </div>
          <CheckoutInput label="Phone (optional)" name="phone" type="tel" />
          <div className="flex items-center gap-2">
            <input type="checkbox" id="billing" defaultChecked className="rounded border-white/20 bg-white/5 text-primary" />
            <label htmlFor="billing" className="text-sm text-muted-foreground">Billing address same as shipping</label>
          </div>
        </div>

        <CheckoutButton href="/checkout/shipping">Continue to shipping</CheckoutButton>
      </form>
    </CheckoutShell>
  );
}
