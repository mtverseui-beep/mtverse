"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Award, Gift, Star, Trophy, ArrowRight, Sparkles } from "lucide-react";
import { toast } from "sonner";

const TIERS = [
  { name: "Bronze", min: 0, max: 499, color: "#CD7F32", perks: ["1 point per $1 spent", "Early sale access"] },
  { name: "Silver", min: 500, max: 1999, color: "#C0C0C0", perks: ["1.5 points per $1", "Free shipping always", "Birthday gift"] },
  { name: "Gold", min: 2000, max: 4999, color: "#FFD700", perks: ["2 points per $1", "Exclusive drops access", "Free returns"] },
  { name: "Nova", min: 5000, max: Infinity, color: "#8B5CF6", perks: ["3 points per $1", "Personal setup concierge", "VIP support", "Annual gift"] },
];

const REWARDS = [
  { points: 250, label: "$10 off any order", icon: Gift },
  { points: 500, label: "$25 off any order", icon: Gift },
  { points: 1000, label: "Free PulseMat XXL Desk Pad", icon: Award },
  { points: 2500, label: "Free NovaMouse X1 Wireless", icon: Trophy },
  { points: 5000, label: "Free NovaKeys TKL Pro", icon: Sparkles },
];

export default function RewardsPage() {
  const [points] = useState(1240);
  const currentTier = TIERS.find((t) => points >= t.min && points <= t.max) ?? TIERS[0];
  const nextTier = TIERS.find((t) => t.min > points);
  const toNext = nextTier ? nextTier.min - points : 0;

  const redeem = (reward: (typeof REWARDS)[number]) => {
    if (points < reward.points) {
      toast.error("Not enough points", { description: `You need ${reward.points - points} more points.` });
      return;
    }
    toast.success("Reward redeemed", { description: reward.label });
  };

  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center justify-center gap-2">
          <Award className="h-3.5 w-3.5" /> NOVA RIG Rewards
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Earn gear. Get rewarded.
        </h1>
        <p className="mt-3 max-w-xl mx-auto text-muted-foreground">
          Earn points on every purchase, redeem for gear, and unlock tier-based perks.
        </p>
      </div>

      {/* Points balance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-white/10 bg-gradient-to-br from-[#101522] via-[#0B0F1A] to-[#101522] p-8 mb-8"
      >
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Your points</div>
            <div className="font-display text-5xl font-black text-foreground">{points.toLocaleString()}</div>
            <div className="mt-2 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-bold text-foreground">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: currentTier.color }} />
              {currentTier.name} tier
            </div>
          </div>
          {nextTier && (
            <div className="text-right">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">{toNext} points to {nextTier.name}</div>
              <div className="mt-1 h-2 w-48 overflow-hidden rounded-full bg-white/5">
                <div className="h-full rounded-full bg-primary" style={{ width: `${(points / nextTier.min) * 100}%` }} />
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Tiers */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        {TIERS.map((t) => (
          <div
            key={t.name}
            className={`rounded-2xl border p-5 ${currentTier.name === t.name ? "border-primary bg-primary/5" : "border-white/10 bg-[#0B0F1A]"}`}
          >
            <div className="flex items-center justify-between">
              <div className="font-display text-lg font-bold text-foreground">{t.name}</div>
              <div className="h-3 w-3 rounded-full" style={{ backgroundColor: t.color }} />
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              {t.min.toLocaleString()}{t.max === Infinity ? "+" : `–${t.max.toLocaleString()}`} points
            </div>
            <ul className="mt-3 space-y-1">
              {t.perks.map((perk) => (
                <li key={perk} className="text-xs text-muted-foreground flex items-start gap-1.5">
                  <Star className="mt-0.5 h-3 w-3 shrink-0 text-accent" /> {perk}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Redeem rewards */}
      <h2 className="font-display text-xl font-bold uppercase tracking-tight text-foreground mb-4">Redeem points</h2>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {REWARDS.map((r) => {
          const canRedeem = points >= r.points;
          return (
            <div key={r.label} className="rounded-xl border border-white/10 bg-[#0B0F1A] p-5">
              <div className="grid h-12 w-12 place-items-center rounded-lg bg-primary/15 text-primary">
                <r.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-3 text-sm font-bold text-foreground">{r.label}</h3>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-sm font-bold text-primary">{r.points.toLocaleString()} pts</span>
                <button
                  onClick={() => redeem(r)}
                  disabled={!canRedeem}
                  className="inline-flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-white hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Redeem <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
