"use client";

import { useShopStore } from "@/lib/shop-store";
import { PRODUCTS } from "@/data/products";
import { ProductCard } from "@/components/product/product-card";
import { useQuickView } from "@/lib/quick-view-store";
import { History, ArrowRight } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function RecentlyViewedPage() {
  const { recentlyViewed } = useShopStore();
  const { openQuickView } = useQuickView();
  const items = recentlyViewed
    .map((slug) => PRODUCTS.find((p) => p.slug === slug))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl flex items-center gap-3">
          <History className="h-7 w-7 text-primary" /> Recently viewed
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {items.length === 0 ? "No items viewed yet." : `${items.length} recently viewed ${items.length === 1 ? "item" : "items"}`}
        </p>
      </div>

      {items.length === 0 ? (
        <div className="grid place-items-center rounded-2xl border border-white/10 bg-[#0B0F1A] py-20 text-center">
          <div>
            <History className="mx-auto h-16 w-16 text-muted-foreground" />
            <h2 className="mt-4 text-xl font-bold text-foreground">No recently viewed items</h2>
            <p className="mt-2 text-sm text-muted-foreground">Browse gear and your history will appear here.</p>
            <Link href="/shop" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
              Shop gear <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      ) : (
        <motion.div layout className="grid gap-4 grid-cols-2 lg:grid-cols-4">
          {items.map((p, i) => (
            <motion.div
              key={p.id}
              layout
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <ProductCard product={p} onQuickView={openQuickView} />
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
