"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Package, Check, ArrowRight, ShoppingCart, RotateCcw, BadgePercent } from "lucide-react";
import { PRODUCTS } from "@/data/products";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice, cn } from "@/lib/utils";
import { toast } from "sonner";

const BUNDLE_SIZES = [
  { id: "starter", label: "Starter (3 items)", min: 3, max: 3, discount: 0.05 },
  { id: "pro", label: "Pro (4–5 items)", min: 4, max: 5, discount: 0.1 },
  { id: "ultimate", label: "Ultimate (6+ items)", min: 6, max: 99, discount: 0.15 },
];

export default function BundleBuilderPage() {
  const [bundleSize, setBundleSize] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const { addToCart } = useShopStore();

  const selectedSize = BUNDLE_SIZES.find((b) => b.id === bundleSize);
  const selectedProducts = selected
    .map((s) => PRODUCTS.find((p) => p.slug === s))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  const subtotal = selectedProducts.reduce((acc, p) => acc + p.price, 0);
  const discount = selectedSize ? subtotal * selectedSize.discount : 0;
  const total = subtotal - discount;

  const toggleProduct = (slug: string) => {
    if (!bundleSize) {
      toast.error("Pick a bundle size first");
      return;
    }
    setSelected((prev) => {
      if (prev.includes(slug)) return prev.filter((s) => s !== slug);
      if (prev.length >= selectedSize!.max) {
        toast.error(`Maximum ${selectedSize!.max} items for this bundle`);
        return prev;
      }
      return [...prev, slug];
    });
  };

  const addBundleToCart = () => {
    if (selectedProducts.length < (selectedSize?.min ?? 0)) {
      toast.error(`Pick at least ${selectedSize?.min} items`);
      return;
    }
    selectedProducts.forEach((p) => {
      addToCart({
        productSlug: p.slug,
        name: p.name,
        image: p.images[0],
        price: p.price,
        quantity: 1,
        variant: p.variants[0]?.value,
        color: p.colors[0]?.name,
      });
    });
    toast.success(`Added ${selectedProducts.length}-item bundle to cart`, {
      description: `You saved ${formatPrice(discount)} on this bundle.`,
    });
  };

  const reset = () => {
    setSelected([]);
    setBundleSize(null);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-secondary flex items-center gap-2">
            <Package className="h-3.5 w-3.5" /> Bundle builder
          </span>
          <h1 className="mt-2 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
            Build your bundle
          </h1>
          <p className="mt-2 text-sm text-muted-foreground max-w-xl">
            Pick a bundle size, then add gear. The more you add, the more you save — up to 15% off.
          </p>
        </div>
        {(bundleSize || selected.length > 0) && (
          <button onClick={reset} className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-foreground hover:bg-white/10">
            <RotateCcw className="h-4 w-4" /> Reset
          </button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Step 1: Bundle size */}
          <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="mb-4 text-base font-bold text-foreground">1. Pick your bundle size</h2>
            <div className="grid gap-3 sm:grid-cols-3">
              {BUNDLE_SIZES.map((b) => (
                <button
                  key={b.id}
                  onClick={() => {
                    setBundleSize(b.id);
                    if (selected.length > b.max) setSelected(selected.slice(0, b.max));
                  }}
                  className={cn(
                    "rounded-xl border p-4 text-left transition-colors",
                    bundleSize === b.id ? "border-secondary bg-secondary/10" : "border-white/10 bg-white/[0.02] hover:border-white/30",
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-bold text-foreground">{b.label}</div>
                    {bundleSize === b.id && <Check className="h-4 w-4 text-secondary" />}
                  </div>
                  <div className="mt-2 inline-flex items-center gap-1 rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-bold text-accent">
                    <BadgePercent className="h-3 w-3" /> {Math.round(b.discount * 100)}% off
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Pick products */}
          <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-base font-bold text-foreground">2. Add gear to your bundle</h2>
              {bundleSize && (
                <span className="text-xs text-muted-foreground">
                  {selected.length} / {selectedSize?.max} items
                </span>
              )}
            </div>
            {!bundleSize ? (
              <p className="py-8 text-center text-sm text-muted-foreground">Pick a bundle size first.</p>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {PRODUCTS.filter((p) => p.category !== "creator-bundles" && p.category !== "esports-kits").map((p) => {
                  const isSelected = selected.includes(p.slug);
                  return (
                    <motion.button
                      key={p.id}
                      layout
                      onClick={() => toggleProduct(p.slug)}
                      className={cn(
                        "group relative rounded-xl border p-3 text-left transition-colors",
                        isSelected ? "border-secondary bg-secondary/10" : "border-white/10 bg-white/[0.02] hover:border-white/30",
                      )}
                    >
                      <div className="relative aspect-square overflow-hidden rounded-lg bg-[#0B0F1A] mb-2">
                        <SafeImg src={p.images[0]} alt={p.name} className="h-full w-full object-cover" width={200} height={200} />
                        {isSelected && (
                          <div className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-secondary text-black">
                            <Check className="h-3.5 w-3.5" />
                          </div>
                        )}
                      </div>
                      <div className="text-xs font-semibold text-foreground line-clamp-1">{p.name}</div>
                      <div className="mt-0.5 text-xs font-bold text-primary">{formatPrice(p.price)}</div>
                    </motion.button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Summary */}
        <aside>
          <div className="sticky top-32 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground mb-4">
              Bundle summary
            </h2>

            {selectedProducts.length === 0 ? (
              <p className="text-sm text-muted-foreground">Your bundle is empty. Start adding gear.</p>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto">
                <AnimatePresence>
                  {selectedProducts.map((p) => (
                    <motion.div
                      key={p.id}
                      layout
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="flex items-center gap-2 text-xs"
                    >
                      <SafeImg src={p.images[0]} alt={p.name} className="h-10 w-10 rounded-md object-cover" width={40} height={40} />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-foreground line-clamp-1">{p.name}</div>
                        <div className="text-primary">{formatPrice(p.price)}</div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}

            {bundleSize && (
              <div className="mt-4 space-y-2 border-t border-white/10 pt-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground">{formatPrice(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-accent">
                    <span>Bundle discount ({Math.round(selectedSize!.discount * 100)}%)</span>
                    <span>-{formatPrice(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between border-t border-white/10 pt-2 text-base font-bold">
                  <span className="text-foreground">Total</span>
                  <span className="font-display text-xl font-black text-foreground">{formatPrice(total)}</span>
                </div>
              </div>
            )}

            <button
              onClick={addBundleToCart}
              disabled={selectedProducts.length === 0 || !bundleSize}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-secondary px-4 py-3 text-sm font-bold text-black hover:bg-secondary/90 disabled:opacity-50"
            >
              <ShoppingCart className="h-4 w-4" /> Add bundle to cart
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
