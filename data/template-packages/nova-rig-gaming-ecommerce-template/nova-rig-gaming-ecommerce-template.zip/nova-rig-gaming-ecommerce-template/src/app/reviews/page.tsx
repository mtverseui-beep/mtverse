import type { Metadata } from "next";
import { ReviewsPageClient } from "@/components/content/reviews-page-client";
import { REVIEWS } from "@/data/content";

export const metadata: Metadata = {
  title: "Reviews — Verified Buyer Reviews",
  description: "Read verified buyer reviews of NOVA RIG gaming gear. Filter by rating, product, and date.",
  alternates: { canonical: "https://novarig.co/reviews" },
};

export default function ReviewsPage() {
  return <ReviewsPageClient reviews={REVIEWS} />;
}
