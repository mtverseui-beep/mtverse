import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "chairs" as const;

export const metadata: Metadata = {
  title: "Gaming Chairs",
  description: "Premium gaming chairs with 4-way lumbar and cold-cure memory foam.",
  alternates: { canonical: `https://novarig.co/chairs` },
};

export default function ChairsPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Gaming Chairs"} description={`${products.length} products in the Gaming Chairs collection.`} showCategoryFilter={false} />
    </>
  );
}
