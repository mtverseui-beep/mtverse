import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { PRODUCTS } from "@/data/products";

export const metadata: Metadata = {
  title: "New Arrivals — Latest Gaming Gear",
  description: "Shop the latest NOVA RIG gear: new keyboards, mice, headsets, microphones, webcams, and creator bundles.",
  alternates: { canonical: `https://novarig.co/new-arrivals` },
};

export default function Page() {
  const products = PRODUCTS.filter((p) => p.badge === 'new');
  return (
    <ShopBrowser
      products={products}
      title={"New arrivals"}
      description={"The latest gear from NOVA RIG — new keyboards, mice, headsets, and creator equipment."}
      showCategoryFilter
    />
  );
}
