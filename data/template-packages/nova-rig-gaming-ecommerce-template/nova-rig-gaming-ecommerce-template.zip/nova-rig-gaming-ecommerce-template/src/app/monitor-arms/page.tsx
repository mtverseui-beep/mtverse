import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "monitor-arms" as const;

export const metadata: Metadata = {
  title: "Monitor Arms",
  description: "Gas-strut monitor arms with full motion and integrated cable routing.",
  alternates: { canonical: `https://novarig.co/monitor-arms` },
};

export default function MonitorarmsPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Monitor Arms"} description={`${products.length} products in the Monitor Arms collection.`} showCategoryFilter={false} />
    </>
  );
}
