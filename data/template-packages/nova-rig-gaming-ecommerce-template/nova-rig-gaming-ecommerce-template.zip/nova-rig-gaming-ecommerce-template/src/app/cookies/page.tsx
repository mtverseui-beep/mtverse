import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Cookie Policy",
  description: "Cookie Policy for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/cookies" },
};

export default function CookiesPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Cookie Policy</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">What are cookies</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Cookies are small text files stored on your device when you visit a website. They allow the website to remember your actions and preferences over a period of time, so you don't have to re-enter them every time you visit.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">How we use cookies</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We use cookies to: power your shopping cart and wishlist, remember recently viewed products, remember your login session, analyze website traffic, and measure the effectiveness of marketing campaigns.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Types of cookies we use</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Essential cookies: required for the website to function (cart, checkout, security). Preference cookies: remember your settings (currency, language). Analytics cookies: help us understand how visitors use our site. Marketing cookies: track visitors across websites to display relevant ads.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Managing cookies</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">You can control and delete cookies through your browser settings. Note that disabling cookies may affect functionality of the website — your cart, wishlist, and recently viewed items will not persist between sessions.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Third-party cookies</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We use third-party services that may set cookies: Google Analytics (traffic analysis), Stripe (payment processing), Facebook Pixel (advertising), and our email service provider. These third parties have their own privacy policies.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Updates</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We may update this Cookie Policy from time to time. The updated version will be posted on this page with a new effective date.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
