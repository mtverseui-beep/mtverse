import type { Metadata } from "next";
import { Reveal } from "@/components/motion/reveal";

export const metadata: Metadata = {
  title: "Stockists",
  description: "Stockists for NOVA RIG — last updated June 2026.",
  alternates: { canonical: "https://novarig.co/stockists" },
};

export default function StockistsPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-black uppercase tracking-tighter text-foreground">Stockists</h1>
        <p className="mt-2 text-xs text-muted-foreground">Last updated: June 2026</p>
      </div>
      <div className="space-y-6">
        
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Find a stockist</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">NOVA RIG is sold direct through novarig.co and through authorized retail partners. Buying direct supports our team and gives you the full warranty, fastest shipping, and direct support.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Authorized retailers</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">We currently partner with select retailers in the US, Canada, EU, and UK. Authorized retailers carry a subset of our catalog and may have different pricing and warranty terms.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Become a stockist</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">Interested in carrying NOVA RIG products? Email wholesale@novarig.co with: your business name, location, website, and a brief description of your store. We respond to qualified inquiries within 5 business days.</p>
          </section>
        </Reveal>
        <Reveal>
          <section>
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground">Verify a stockist</h2>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">To verify if a retailer is an authorized NOVA RIG stockist, email support@novarig.co with the retailer's name. We do not warranty products purchased from unauthorized retailers.</p>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
