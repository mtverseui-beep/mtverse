import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { getProductsByCategory } from "@/data/products";
import { getCategoryBySlug } from "@/data/collections";
import { CategoryHero } from "@/components/product/category-hero";

const SLUG = "microphones" as const;

export const metadata: Metadata = {
  title: "Streaming Microphones",
  description: "USB-C and XLR streaming microphones with 24-bit/96kHz capture.",
  alternates: { canonical: `https://novarig.co/microphones` },
};

export default function MicrophonesPage() {
  const cat = getCategoryBySlug(SLUG)!;
  const products = getProductsByCategory(SLUG);
  return (
    <>
      <CategoryHero cat={cat} />
      <ShopBrowser products={products} title={"Streaming Microphones"} description={`${products.length} products in the Streaming Microphones collection.`} showCategoryFilter={false} />
    </>
  );
}
