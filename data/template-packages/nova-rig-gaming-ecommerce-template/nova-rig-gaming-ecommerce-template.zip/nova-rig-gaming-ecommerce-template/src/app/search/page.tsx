"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useMemo } from "react";
import { ShopBrowser } from "@/components/product/shop-browser";
import { PRODUCTS } from "@/data/products";
import { COLLECTIONS } from "@/data/collections";
import { BLOG_POSTS, BUYING_GUIDES } from "@/data/content";

function SearchContent() {
  const params = useSearchParams();
  const q = params.get("q") ?? "";
  const query = q.toLowerCase();
  const products = useMemo(() => {
    if (!query) return PRODUCTS;
    return PRODUCTS.filter(
      (p) =>
        p.name.toLowerCase().includes(query) ||
        p.categoryLabel.toLowerCase().includes(query) ||
        p.shortDescription.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.tags?.some((t) => t.toLowerCase().includes(query)),
    );
  }, [query]);
  return (
    <ShopBrowser
      products={products}
      title={`Search: ${q}`}
      description={`${products.length} ${products.length === 1 ? "result" : "results"} for "${q}"`}
    />
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="py-20 text-center text-muted-foreground">Loading...</div>}>
      <SearchContent />
    </Suspense>
  );
}
