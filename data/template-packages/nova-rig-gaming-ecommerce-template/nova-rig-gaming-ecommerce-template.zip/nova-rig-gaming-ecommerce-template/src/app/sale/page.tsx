import type { Metadata } from "next";
import { ShopBrowser } from "@/components/product/shop-browser";
import { PRODUCTS } from "@/data/products";

export const metadata: Metadata = {
  title: "Sale — Save on Gaming Gear",
  description: "Save on premium NOVA RIG gaming gear. Limited-time sale prices on keyboards, mice, headsets, and more.",
  alternates: { canonical: `https://novarig.co/sale` },
};

export default function Page() {
  const products = PRODUCTS.filter((p) => Boolean(p.compareAtPrice));
  return (
    <ShopBrowser
      products={products}
      title={"On sale"}
      description={"Save on premium gaming gear. Limited-time sale prices on select NOVA RIG products."}
      showCategoryFilter
    />
  );
}
