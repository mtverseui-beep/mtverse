"use client";

import { create } from "zustand";
import type { Product } from "@/types";

interface QuickViewState {
  product: Product | null;
  open: boolean;
  openQuickView: (product: Product) => void;
  closeQuickView: () => void;
}

export const useQuickView = create<QuickViewState>((set) => ({
  product: null,
  open: false,
  openQuickView: (product) => set({ product, open: true }),
  closeQuickView: () => set({ open: false, product: null }),
}));
