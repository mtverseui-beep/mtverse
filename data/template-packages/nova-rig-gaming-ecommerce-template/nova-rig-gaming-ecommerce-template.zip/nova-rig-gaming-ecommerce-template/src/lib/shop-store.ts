"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { CartItem, WishItem, CompareItem } from "@/types";
import { toast } from "sonner";

interface ShopState {
  // Cart
  cart: CartItem[];
  cartOpen: boolean;
  addToCart: (item: Omit<CartItem, "id">) => void;
  removeFromCart: (id: string) => void;
  updateCartQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  setCartOpen: (open: boolean) => void;
  cartCount: () => number;
  cartSubtotal: () => number;

  // Wishlist
  wishlist: WishItem[];
  toggleWishlist: (productSlug: string) => void;
  isWishlisted: (productSlug: string) => boolean;
  clearWishlist: () => void;

  // Compare
  compare: CompareItem[];
  toggleCompare: (productSlug: string) => void;
  isCompared: (productSlug: string) => boolean;
  clearCompare: () => void;

  // Recently viewed
  recentlyViewed: string[];
  addRecentlyViewed: (productSlug: string) => void;

  // Search
  searchOpen: boolean;
  setSearchOpen: (open: boolean) => void;

  // Mobile menu
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

const MAX_COMPARE = 4;
const MAX_RECENTLY_VIEWED = 12;

export const useShopStore = create<ShopState>()(
  persist(
    (set, get) => ({
      cart: [],
      cartOpen: false,
      wishlist: [],
      compare: [],
      recentlyViewed: [],
      searchOpen: false,
      mobileMenuOpen: false,

      addToCart: (item) => {
        const id = `${item.productSlug}-${item.variant ?? "default"}-${item.color ?? "default"}`;
        const existing = get().cart.find((c) => c.id === id);
        if (existing) {
          set({
            cart: get().cart.map((c) =>
              c.id === id ? { ...c, quantity: c.quantity + item.quantity } : c,
            ),
            cartOpen: true,
          });
        } else {
          set({ cart: [...get().cart, { ...item, id }], cartOpen: true });
        }
        toast.success("Added to cart", { description: item.name });
      },

      removeFromCart: (id) => {
        set({ cart: get().cart.filter((c) => c.id !== id) });
        toast.success("Removed from cart");
      },

      updateCartQuantity: (id, quantity) => {
        if (quantity < 1) {
          get().removeFromCart(id);
          return;
        }
        set({
          cart: get().cart.map((c) => (c.id === id ? { ...c, quantity } : c)),
        });
      },

      clearCart: () => set({ cart: [] }),
      setCartOpen: (open) => set({ cartOpen: open }),

      cartCount: () => get().cart.reduce((acc, c) => acc + c.quantity, 0),
      cartSubtotal: () =>
        get().cart.reduce((acc, c) => acc + c.price * c.quantity, 0),

      toggleWishlist: (productSlug) => {
        const exists = get().wishlist.find((w) => w.productSlug === productSlug);
        if (exists) {
          set({ wishlist: get().wishlist.filter((w) => w.productSlug !== productSlug) });
          toast.success("Removed from wishlist");
        } else {
          set({ wishlist: [...get().wishlist, { productSlug, addedAt: Date.now() }] });
          toast.success("Added to wishlist");
        }
      },
      isWishlisted: (productSlug) =>
        Boolean(get().wishlist.find((w) => w.productSlug === productSlug)),
      clearWishlist: () => set({ wishlist: [] }),

      toggleCompare: (productSlug) => {
        const exists = get().compare.find((c) => c.productSlug === productSlug);
        if (exists) {
          set({ compare: get().compare.filter((c) => c.productSlug !== productSlug) });
          toast.success("Removed from compare");
        } else {
          if (get().compare.length >= MAX_COMPARE) {
            toast.error(`You can compare up to ${MAX_COMPARE} products`);
            return;
          }
          set({ compare: [...get().compare, { productSlug, addedAt: Date.now() }] });
          toast.success("Added to compare");
        }
      },
      isCompared: (productSlug) =>
        Boolean(get().compare.find((c) => c.productSlug === productSlug)),
      clearCompare: () => set({ compare: [] }),

      addRecentlyViewed: (productSlug) => {
        const filtered = get().recentlyViewed.filter((s) => s !== productSlug);
        set({
          recentlyViewed: [productSlug, ...filtered].slice(0, MAX_RECENTLY_VIEWED),
        });
      },

      setSearchOpen: (open) => set({ searchOpen: open }),
      setMobileMenuOpen: (open) => set({ mobileMenuOpen: open }),
    }),
    {
      name: "nova-rig-shop",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        cart: state.cart,
        wishlist: state.wishlist,
        compare: state.compare,
        recentlyViewed: state.recentlyViewed,
      }),
    },
  ),
);
