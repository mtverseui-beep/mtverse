"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutGrid, Package, MapPin, CreditCard, Heart, Award, Bell, User, Shield, ChevronRight, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { useShopStore } from "@/lib/shop-store";

const ACCOUNT_NAV = [
  { label: "Dashboard", href: "/account", icon: LayoutGrid },
  { label: "Orders", href: "/account/orders", icon: Package },
  { label: "Addresses", href: "/account/addresses", icon: MapPin },
  { label: "Payment methods", href: "/account/payment-methods", icon: CreditCard },
  { label: "Wishlist", href: "/account/wishlist", icon: Heart },
  { label: "Rewards", href: "/account/rewards", icon: Award },
  { label: "Notifications", href: "/account/notifications", icon: Bell },
  { label: "Profile", href: "/account/profile", icon: User },
  { label: "Security", href: "/account/security", icon: Shield },
];

export function AccountShell({ children, title }: { children: React.ReactNode; title: string }) {
  const pathname = usePathname();
  const [orders, setOrders] = useState<any[]>([]);
  const { wishlist } = useShopStore();

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem("nova-rig-orders") ?? "[]");
      setOrders(stored);
    } catch {}
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
          {title}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">Welcome back, Player.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Sidebar */}
        <aside className="lg:col-span-1">
          <div className="sticky top-32 rounded-2xl border border-white/10 bg-[#0B0F1A] p-3">
            <nav className="space-y-1">
              {ACCOUNT_NAV.map((item) => {
                const isActive = pathname === item.href || (item.href !== "/account" && pathname.startsWith(item.href));
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold transition-colors",
                      isActive ? "bg-primary/15 text-primary" : "text-foreground hover:bg-white/5",
                    )}
                  >
                    <span className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      {item.label}
                    </span>
                    {item.label === "Orders" && orders.length > 0 && (
                      <span className="rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-bold text-primary">{orders.length}</span>
                    )}
                    {item.label === "Wishlist" && wishlist.length > 0 && (
                      <span className="rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-bold text-primary">{wishlist.length}</span>
                    )}
                  </Link>
                );
              })}
              <Link
                href="/sign-in"
                className="flex items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-muted-foreground hover:bg-white/5"
              >
                <span className="flex items-center gap-2">
                  <LogOut className="h-4 w-4" /> Sign out
                </span>
              </Link>
            </nav>
          </div>
        </aside>

        {/* Content */}
        <div className="lg:col-span-3">
          {children}
        </div>
      </div>
    </div>
  );
}
