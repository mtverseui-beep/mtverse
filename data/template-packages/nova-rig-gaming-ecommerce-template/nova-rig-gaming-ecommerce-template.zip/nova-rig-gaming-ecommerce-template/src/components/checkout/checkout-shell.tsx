"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { Check, ChevronRight, ArrowLeft, Truck, CreditCard, ClipboardCheck, Lock, ShieldCheck } from "lucide-react";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice, cn, safeId } from "@/lib/utils";
import { toast } from "sonner";

const STEPS = [
  { id: "info", label: "Information", href: "/checkout", icon: ClipboardCheck },
  { id: "shipping", label: "Shipping", href: "/checkout/shipping", icon: Truck },
  { id: "payment", label: "Payment", href: "/checkout/payment", icon: CreditCard },
  { id: "review", label: "Review", href: "/checkout/review", icon: ShieldCheck },
];

export function CheckoutShell({
  step,
  title,
  children,
}: {
  step: string;
  title: string;
  children: React.ReactNode;
}) {
  const router = useRouter();
  const { cart, cartSubtotal } = useShopStore();
  const subtotal = cartSubtotal();
  const shipping = subtotal >= 99 ? 0 : 9.99;
  const tax = subtotal * 0.0825;
  const total = subtotal + shipping + tax;
  const stepIdx = STEPS.findIndex((s) => s.id === step);

  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-black uppercase tracking-tight text-foreground">
          Your cart is empty
        </h1>
        <p className="mt-2 text-muted-foreground">Add gear before checking out.</p>
        <Link href="/shop" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white">
          Shop gear
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <Link href="/cart" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Back to cart
      </Link>

      <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl mb-2">
        {title}
      </h1>

      {/* Stepper */}
      <div className="mb-8 flex items-center gap-2 overflow-x-auto pb-2">
        {STEPS.map((s, i) => {
          const isDone = i < stepIdx;
          const isActive = i === stepIdx;
          return (
            <Link
              key={s.id}
              href={s.href}
              className={cn(
                "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors",
                isActive
                  ? "border-primary bg-primary/15 text-primary"
                  : isDone
                  ? "border-accent/40 bg-accent/10 text-accent"
                  : "border-white/10 text-muted-foreground hover:text-foreground",
              )}
            >
              <div className={cn(
                "grid h-5 w-5 place-items-center rounded-full text-[10px]",
                isActive ? "bg-primary text-white" : isDone ? "bg-accent text-black" : "bg-white/10 text-muted-foreground",
              )}>
                {isDone ? <Check className="h-3 w-3" /> : i + 1}
              </div>
              {s.label}
              {i < STEPS.length - 1 && <ChevronRight className="h-3 w-3 ml-1 opacity-50" />}
            </Link>
          );
        })}
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Order summary */}
        <aside className="lg:col-span-1">
          <div className="sticky top-32 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <h2 className="font-display text-lg font-bold uppercase tracking-tight text-foreground mb-4">
              Order summary
            </h2>
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {cart.map((item) => (
                <div key={item.id} className="flex gap-3">
                  <div className="relative h-14 w-14 shrink-0">
                    <SafeImg src={item.image} alt={item.name} className="h-full w-full rounded-lg object-cover" width={56} height={56} />
                    <span className="absolute -right-1 -top-1 grid h-5 w-5 place-items-center rounded-full bg-primary text-[10px] font-bold text-white">
                      {item.quantity}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold text-foreground line-clamp-1">{item.name}</div>
                    {(item.variant || item.color) && (
                      <div className="text-[10px] text-muted-foreground">{[item.variant, item.color].filter(Boolean).join(" · ")}</div>
                    )}
                  </div>
                  <div className="text-xs font-bold text-foreground">{formatPrice(item.price * item.quantity)}</div>
                </div>
              ))}
            </div>

            <div className="mt-4 space-y-2 border-t border-white/10 pt-4 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span className="text-foreground">{shipping === 0 ? <span className="text-accent">Free</span> : formatPrice(shipping)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax</span>
                <span className="text-foreground">{formatPrice(tax)}</span>
              </div>
              <div className="flex justify-between border-t border-white/10 pt-3 text-base">
                <span className="font-bold text-foreground">Total</span>
                <span className="font-display text-xl font-black text-foreground">{formatPrice(total)}</span>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <Lock className="h-3.5 w-3.5 text-accent" /> Secure encrypted checkout
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

export function CheckoutInput({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{label}</span>
      <input
        {...props}
        className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
      />
    </label>
  );
}

export function CheckoutButton({
  children,
  onClick,
  loading,
  href,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  loading?: boolean;
  href?: string;
}) {
  const button = (
    <button
      onClick={onClick}
      disabled={loading}
      className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 hover:bg-primary/90 disabled:opacity-60"
    >
      {loading ? (
        <>
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
          Processing...
        </>
      ) : (
        children
      )}
    </button>
  );
  return href ? <Link href={href}>{button}</Link> : button;
}
