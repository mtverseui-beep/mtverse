"use client";

import { type ReactNode } from "react";
import { ThemeProvider } from "next-themes";
import { CartDrawer } from "@/components/cart/cart-drawer";
import { SearchOverlay } from "@/components/layout/search-overlay";
import { MobileMenu } from "@/components/layout/mobile-menu";
import { QuickViewModal } from "@/components/product/quick-view-modal";

export function ShopProviders({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" forcedTheme="dark" enableSystem={false}>
      {children}
      <CartDrawer />
      <SearchOverlay />
      <MobileMenu />
      <QuickViewModal />
    </ThemeProvider>
  );
}
