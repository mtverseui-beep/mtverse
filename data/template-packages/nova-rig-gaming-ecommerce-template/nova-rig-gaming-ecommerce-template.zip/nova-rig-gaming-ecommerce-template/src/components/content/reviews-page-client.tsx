"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Star, Search, Quote, CheckCircle2, ArrowRight } from "lucide-react";
import type { ReviewItem } from "@/types";
import { SafeImg } from "@/components/common/safe-image";
import { formatDate, cn } from "@/lib/utils";

export function ReviewsPageClient({ reviews }: { reviews: ReviewItem[] }) {
  const [filter, setFilter] = useState<number | "all">("all");
  const [sort, setSort] = useState<"recent" | "rating-high" | "rating-low" | "helpful">("helpful");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    let result = [...reviews];
    if (filter !== "all") result = result.filter((r) => r.rating === filter);
    if (query) {
      const q = query.toLowerCase();
      result = result.filter((r) => r.title.toLowerCase().includes(q) || r.body.toLowerCase().includes(q) || r.productName.toLowerCase().includes(q));
    }
    switch (sort) {
      case "recent":
        result.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        break;
      case "rating-high":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "rating-low":
        result.sort((a, b) => a.rating - b.rating);
        break;
      case "helpful":
        result.sort((a, b) => b.helpful - a.helpful);
        break;
    }
    return result;
  }, [reviews, filter, sort, query]);

  const avg = (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1);
  const counts = [5, 4, 3, 2, 1].map((s) => ({ star: s, count: reviews.filter((r) => r.rating === s).length }));
  const total = reviews.length;

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-warning flex items-center gap-2">
          <Star className="h-3.5 w-3.5 fill-warning" /> Reviews
        </span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl">
          Verified buyer reviews
        </h1>
      </div>

      <div className="grid gap-8 lg:grid-cols-3 mb-8">
        {/* Summary */}
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <div className="flex items-baseline gap-3">
            <span className="font-display text-5xl font-black text-foreground">{avg}</span>
            <div>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className={cn("h-4 w-4", s <= Math.round(Number(avg)) ? "fill-warning text-warning" : "text-white/20")} />
                ))}
              </div>
              <span className="text-xs text-muted-foreground">{total} reviews</span>
            </div>
          </div>
          <div className="mt-4 space-y-1.5">
            {counts.map((c) => {
              const pct = total > 0 ? (c.count / total) * 100 : 0;
              return (
                <button
                  key={c.star}
                  onClick={() => setFilter(filter === c.star ? "all" : c.star)}
                  className={cn("flex w-full items-center gap-2 text-xs", filter === c.star ? "text-primary" : "text-muted-foreground hover:text-foreground")}
                >
                  <span className="w-3">{c.star}</span>
                  <Star className="h-3 w-3 fill-warning text-warning" />
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/5">
                    <div className="h-full rounded-full bg-warning" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-8 text-right">{c.count}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Filters */}
        <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search reviews..."
                className="w-full rounded-lg border border-white/10 bg-white/5 pl-10 pr-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
              />
            </div>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as any)}
              className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground outline-none focus:border-primary"
            >
              <option value="helpful" className="bg-[#101522]">Most helpful</option>
              <option value="recent" className="bg-[#101522]">Most recent</option>
              <option value="rating-high" className="bg-[#101522]">Highest rated</option>
              <option value="rating-low" className="bg-[#101522]">Lowest rated</option>
            </select>
          </div>
        </div>
      </div>

      {/* Reviews list */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-[#0B0F1A] py-16 text-center">
          <p className="text-muted-foreground">No reviews match your filters.</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {filtered.map((r, i) => (
            <motion.article
              key={r.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className="rounded-2xl border border-white/10 bg-[#0B0F1A] p-5"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <SafeImg src={r.avatar} alt={r.author} className="h-10 w-10 rounded-full object-cover" width={40} height={40} />
                  <div>
                    <div className="text-sm font-semibold text-foreground">{r.author}</div>
                    {r.verified && (
                      <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-accent">
                        <CheckCircle2 className="h-3 w-3" /> Verified buyer
                      </div>
                    )}
                  </div>
                </div>
                <Quote className="h-5 w-5 text-primary/40" />
              </div>
              <div className="mt-3 flex">
                {Array.from({ length: 5 }).map((_, idx) => (
                  <Star key={idx} className={cn("h-3.5 w-3.5", idx < r.rating ? "fill-warning text-warning" : "text-white/20")} />
                ))}
              </div>
              <h3 className="mt-2 text-sm font-bold text-foreground">{r.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{r.body}</p>
              <div className="mt-3 flex items-center justify-between text-[10px] text-muted-foreground">
                <Link href={`/product/${r.productSlug}`} className="text-primary hover:underline">
                  {r.productName}
                </Link>
                <span>{formatDate(r.date)}</span>
              </div>
            </motion.article>
          ))}
        </div>
      )}
    </div>
  );
}
