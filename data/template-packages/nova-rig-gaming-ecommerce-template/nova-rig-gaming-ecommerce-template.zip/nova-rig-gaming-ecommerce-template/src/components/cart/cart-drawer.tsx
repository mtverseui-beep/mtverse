"use client";

import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Truck } from "lucide-react";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice } from "@/lib/utils";

const FREE_SHIPPING_THRESHOLD = 99;

export function CartDrawer() {
  const { cart, cartOpen, setCartOpen, updateCartQuantity, removeFromCart, cartSubtotal } = useShopStore();
  const subtotal = cartSubtotal();
  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const progress = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  return (
    <AnimatePresence>
      {cartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm"
            onClick={() => setCartOpen(false)}
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 260, damping: 30 }}
            className="fixed inset-y-0 right-0 z-[90] w-full max-w-md bg-[#0B0F1A] border-l border-white/10 flex flex-col"
          >
            <div className="flex items-center justify-between border-b border-white/10 p-4">
              <div className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-primary" />
                <h2 className="font-display text-lg font-bold text-foreground">Your Cart</h2>
                <span className="rounded-full bg-white/5 px-2 py-0.5 text-xs text-muted-foreground">
                  {cart.reduce((a, c) => a + c.quantity, 0)} items
                </span>
              </div>
              <button
                onClick={() => setCartOpen(false)}
                className="grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5"
                aria-label="Close cart"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="flex-1 grid place-items-center p-8">
                <div className="text-center">
                  <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-white/5">
                    <ShoppingBag className="h-7 w-7 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">Your cart is empty</h3>
                  <p className="mt-1 text-sm text-muted-foreground">Add gear to start building your rig.</p>
                  <Link
                    href="/shop"
                    onClick={() => setCartOpen(false)}
                    className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white"
                  >
                    Shop gear <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            ) : (
              <>
                {/* Free shipping progress */}
                <div className="border-b border-white/10 p-4">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                    <Truck className="h-3.5 w-3.5" />
                    {remaining > 0 ? (
                      <span>
                        Add <span className="font-bold text-accent">{formatPrice(remaining)}</span> for free shipping
                      </span>
                    ) : (
                      <span className="text-accent font-semibold">You unlocked free shipping</span>
                    )}
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                    <motion.div
                      className="h-full rounded-full bg-gradient-to-r from-primary via-secondary to-accent"
                      animate={{ width: `${progress}%` }}
                      transition={{ type: "spring", stiffness: 100, damping: 20 }}
                    />
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {cart.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: 50 }}
                      className="flex gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-3"
                    >
                      <SafeImg
                        src={item.image}
                        alt={item.name}
                        className="h-16 w-16 shrink-0 rounded-lg object-cover bg-white/5"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <Link
                            href={`/product/${item.productSlug}`}
                            onClick={() => setCartOpen(false)}
                            className="text-sm font-semibold text-foreground hover:text-primary line-clamp-1"
                          >
                            {item.name}
                          </Link>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:text-danger"
                            aria-label={`Remove ${item.name}`}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        {(item.variant || item.color) && (
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {[item.variant, item.color].filter(Boolean).join(" · ")}
                          </p>
                        )}
                        <div className="mt-2 flex items-center justify-between">
                          <div className="flex items-center gap-1 rounded-md border border-white/10">
                            <button
                              onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                              className="grid h-7 w-7 place-items-center text-foreground hover:bg-white/5"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="w-8 text-center text-sm font-semibold text-foreground">{item.quantity}</span>
                            <button
                              onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                              className="grid h-7 w-7 place-items-center text-foreground hover:bg-white/5"
                              aria-label="Increase quantity"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>
                          <span className="text-sm font-bold text-primary">{formatPrice(item.price * item.quantity)}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="border-t border-white/10 p-4 space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-bold text-foreground">{formatPrice(subtotal)}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Shipping and taxes calculated at checkout.</p>
                  <Link
                    href="/checkout"
                    onClick={() => setCartOpen(false)}
                    className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 hover:bg-primary/90 transition-colors"
                  >
                    Checkout · {formatPrice(subtotal)} <ArrowRight className="h-4 w-4" />
                  </Link>
                  <Link
                    href="/cart"
                    onClick={() => setCartOpen(false)}
                    className="block text-center text-sm text-muted-foreground hover:text-foreground"
                  >
                    View full cart
                  </Link>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
