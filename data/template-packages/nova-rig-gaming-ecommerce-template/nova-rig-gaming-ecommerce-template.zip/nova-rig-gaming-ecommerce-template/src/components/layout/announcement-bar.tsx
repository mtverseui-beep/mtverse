"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Truck, Sparkles, ShieldCheck, X } from "lucide-react";

const MESSAGES = [
  { icon: Truck, text: "Free shipping over $99 — ships in 1–2 business days" },
  { icon: Sparkles, text: "New Acid Edge NovaMouse Air 58 drop — limited to 500 units" },
  { icon: ShieldCheck, text: "2-year warranty on all gear · 30-day returns" },
];

export function AnnouncementBar() {
  const [idx, setIdx] = useState(0);
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setIdx((i) => (i + 1) % MESSAGES.length), 4500);
    return () => clearInterval(t);
  }, []);

  if (closed) return null;
  const Current = MESSAGES[idx];

  return (
    <div className="relative z-[60] bg-gradient-to-r from-[#8B5CF6] via-[#06B6D4] to-[#39FF88] text-[#070A12]">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2 text-xs sm:text-sm font-medium">
        <div className="flex-1" />
        <AnimatePresence mode="wait">
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.3 }}
            className="flex items-center justify-center gap-2 font-semibold tracking-wide"
          >
            <Current.icon className="h-3.5 w-3.5" aria-hidden />
            <span>{Current.text}</span>
          </motion.div>
        </AnimatePresence>
        <button
          aria-label="Dismiss announcement"
          onClick={() => setClosed(true)}
          className="ml-auto flex h-6 w-6 items-center justify-center rounded-full bg-black/15 hover:bg-black/30 transition-colors"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}
