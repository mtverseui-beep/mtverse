"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Mail, MapPin, Truck, ShieldCheck, RotateCcw, Headphones } from "lucide-react";
import { FOOTER_LINKS } from "@/data/navigation";
import { Marquee } from "@/components/motion/marquee";

const TRUST_BADGES = [
  { icon: Truck, label: "Free shipping over $99" },
  { icon: RotateCcw, label: "30-day returns" },
  { icon: ShieldCheck, label: "2-year warranty" },
  { icon: Headphones, label: "Real human support" },
];

const SOCIALS = [
  { label: "Twitch", href: "#", icon: "Twitch" },
  { label: "Twitter", href: "#", icon: "Twitter" },
  { label: "YouTube", href: "#", icon: "Youtube" },
  { label: "Instagram", href: "#", icon: "Instagram" },
  { label: "TikTok", href: "#", icon: "Music" },
  { label: "Discord", href: "#", icon: "MessageCircle" },
];

export function SiteFooter() {
  return (
    <footer className="relative mt-auto border-t border-white/10 bg-[#070A12]">
      {/* Trust marquee */}
      <div className="border-b border-white/10 py-3">
        <Marquee speed={28}>
          {[...TRUST_BADGES, ...TRUST_BADGES].map((badge, i) => (
            <div key={i} className="mx-6 flex items-center gap-2 text-sm font-semibold text-foreground/80">
              <badge.icon className="h-4 w-4 text-primary" />
              {badge.label}
            </div>
          ))}
        </Marquee>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-3 lg:grid-cols-6">
          {/* Brand column */}
          <div className="col-span-2 lg:col-span-2">
            <Link href="/" className="flex items-center gap-2">
              <svg viewBox="0 0 32 32" className="h-8 w-8">
                <defs>
                  <linearGradient id="lg-foot" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#8B5CF6" />
                    <stop offset="50%" stopColor="#06B6D4" />
                    <stop offset="100%" stopColor="#39FF88" />
                  </linearGradient>
                </defs>
                <path d="M9 6 L16 16 L9 26 Z" fill="url(#lg-foot)" />
                <path d="M23 6 L16 16 L23 26 Z" fill="url(#lg-foot)" opacity="0.5" />
                <circle cx="16" cy="16" r="1.5" fill="#F8FAFC" />
              </svg>
              <span className="font-display text-xl font-bold text-foreground">
                NOVA<span className="text-gradient-violet">RIG</span>
              </span>
            </Link>
            <p className="mt-3 text-sm text-muted-foreground max-w-xs">
              Premium gaming gear, creator desk upgrades, and limited setup drops built for players, streamers, and modern workstations.
            </p>

            <div className="mt-4 space-y-2 text-sm">
              <a href="mailto:support@novarig.co" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
                <Mail className="h-4 w-4 text-primary" />
                support@novarig.co
              </a>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-4 w-4 text-primary" />
                Austin, TX · Worldwide shipping
              </div>
            </div>

            {/* Newsletter */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                const input = form.querySelector("input") as HTMLInputElement;
                if (input?.value) {
                  import("sonner").then(({ toast }) => toast.success("Subscribed", { description: "Check your inbox for early access." }));
                  input.value = "";
                }
              }}
              className="mt-5 flex gap-2"
            >
              <input
                type="email"
                required
                placeholder="Get early access"
                className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
              />
              <button
                type="submit"
                className="rounded-lg bg-primary px-4 py-2 text-sm font-bold text-white hover:bg-primary/90"
              >
                Subscribe
              </button>
            </form>
          </div>

          {/* Links columns */}
          {FOOTER_LINKS.map((group) => (
            <div key={group.title}>
              <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-foreground">{group.title}</h3>
              <ul className="space-y-2">
                {group.links.map((link) => (
                  <li key={`${group.title}-${link.label}`}>
                    <Link href={link.href} className="text-sm text-muted-foreground hover:text-primary transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Socials */}
        <div className="mt-10 flex flex-wrap items-center gap-3 border-t border-white/10 pt-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Follow us</span>
          {SOCIALS.map((s) => (
            <a
              key={s.label}
              href={s.href}
              aria-label={s.label}
              className="grid h-9 w-9 place-items-center rounded-full border border-white/10 bg-white/5 text-foreground hover:bg-primary/20 hover:border-primary/40 transition-colors"
            >
              <span className="text-xs font-bold uppercase">{s.label[0]}</span>
            </a>
          ))}
        </div>

        {/* Bottom */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} NOVA RIG. All rights reserved.</p>
          <p className="flex items-center gap-3">
            <Link href="/privacy" className="hover:text-foreground">Privacy</Link>
            <span aria-hidden>·</span>
            <Link href="/terms" className="hover:text-foreground">Terms</Link>
            <span aria-hidden>·</span>
            <Link href="/cookies" className="hover:text-foreground">Cookies</Link>
            <span aria-hidden>·</span>
            <Link href="/accessibility" className="hover:text-foreground">Accessibility</Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
