"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useLenis } from "lenis/react";
import {
  Search,
  Heart,
  GitCompare,
  ShoppingCart,
  User,
  Menu,
  ChevronDown,
  Wand2,
  Flame,
  Sparkles,
  Star,
  Truck,
  Package,
  Images,
  Users,
  Calendar,
  TrendingUp,
  BadgePercent,
  Trophy,
  Gift,
  Award,
  Newspaper,
  BookOpen,
  Info,
  LifeBuoy,
  RotateCcw,
  ShieldCheck,
  Mail,
  HelpCircle,
  LayoutGrid,
  Keyboard,
  MousePointer2,
  Headphones,
  RectangleHorizontal,
  Lightbulb,
  Mic,
  Camera,
  MonitorDot,
  Gamepad2,
} from "lucide-react";
import { useShopStore } from "@/lib/shop-store";
import { PRIMARY_NAV } from "@/data/navigation";
import { AnnouncementBar } from "./announcement-bar";
import { cn } from "@/lib/utils";

const NAV_ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutGrid,
  Keyboard,
  MousePointer2,
  Headphones,
  RectangleHorizontal,
  Lightbulb,
  Mic,
  Camera,
  MonitorDot,
  Gamepad2,
  Wand2,
  Package,
  Images,
  Users,
  Flame,
  Calendar,
  Sparkles,
  TrendingUp,
  BadgePercent,
  Trophy,
  Gift,
  Award,
  Newspaper,
  BookOpen,
  Star,
  Info,
  LifeBuoy,
  Truck,
  RotateCcw,
  ShieldCheck,
  Mail,
  HelpCircle,
};

export function SiteHeader() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const lenis = useLenis();

  const { cart, wishlist, compare, setCartOpen, setSearchOpen, setMobileMenuOpen } = useShopStore();
  const cartCount = cart.reduce((acc, c) => acc + c.quantity, 0);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24);
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setHoveredItem(null);
  }, [pathname]);

  const scrollToTop = () => {
    if (lenis) lenis.scrollTo(0, { immediate: true });
    else window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <header className="sticky top-0 z-50">
      <AnnouncementBar />
      <motion.nav
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 25 }}
        className={cn(
          "relative transition-all duration-500",
          scrolled ? "bg-[#0B0F1A] border-b border-white/10" : "bg-[#070A12]",
        )}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
          {/* Mobile menu trigger */}
          <button
            className="grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5 lg:hidden"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group" onClick={scrollToTop}>
            <div className="relative grid h-9 w-9 place-items-center">
              <svg viewBox="0 0 32 32" className="h-9 w-9">
                <defs>
                  <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#8B5CF6" />
                    <stop offset="50%" stopColor="#06B6D4" />
                    <stop offset="100%" stopColor="#39FF88" />
                  </linearGradient>
                </defs>
                <path d="M9 6 L16 16 L9 26 Z" fill="url(#lg)" />
                <path d="M23 6 L16 16 L23 26 Z" fill="url(#lg)" opacity="0.5" />
                <circle cx="16" cy="16" r="1.5" fill="#F8FAFC" />
              </svg>
              <motion.div
                aria-hidden
                className="absolute inset-0 blur-lg opacity-50"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <svg viewBox="0 0 32 32" className="h-9 w-9">
                  <path d="M9 6 L16 16 L9 26 Z" fill="#8B5CF6" />
                  <path d="M23 6 L16 16 L23 26 Z" fill="#06B6D4" opacity="0.5" />
                </svg>
              </motion.div>
            </div>
            <span className="font-display text-lg font-bold tracking-tight text-foreground hidden sm:block">
              NOVA<span className="text-gradient-violet">RIG</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1" aria-label="Primary">
            {PRIMARY_NAV.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
              return (
                <div
                  key={item.label}
                  className="relative"
                  onMouseEnter={() => setHoveredItem(item.label)}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  <Link
                    href={item.href}
                    className={cn(
                      "flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                      isActive ? "text-primary" : "text-foreground/80 hover:text-foreground",
                    )}
                  >
                    {item.label}
                    {item.children && <ChevronDown className="h-3 w-3 opacity-60" />}
                  </Link>
                  {item.children && hoveredItem === item.label && (
                    <AnimatePresence>
                      <motion.div
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 8 }}
                        transition={{ duration: 0.2 }}
                        className="absolute left-0 top-full mt-1 w-[560px] rounded-xl border border-white/10 bg-[#0B0F1A] p-3 shadow-2xl"
                      >
                        <div className="grid grid-cols-2 gap-1">
                          {item.children.map((child) => {
                            const Icon = NAV_ICON_MAP[child.icon ?? "ChevronDown"] ?? ChevronDown;
                            return (
                              <Link
                                key={child.href}
                                href={child.href}
                                className="group flex items-start gap-3 rounded-lg p-2 hover:bg-white/5 transition-colors"
                              >
                                <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
                                  <Icon className="h-4 w-4" />
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm font-semibold text-foreground">{child.label}</span>
                                    {child.badge && (
                                      <span className="rounded-full bg-accent/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
                                        {child.badge}
                                      </span>
                                    )}
                                  </div>
                                  {child.description && (
                                    <p className="mt-0.5 text-xs text-muted-foreground truncate">{child.description}</p>
                                  )}
                                </div>
                              </Link>
                            );
                          })}
                        </div>
                      </motion.div>
                    </AnimatePresence>
                  )}
                </div>
              );
            })}
          </nav>

          {/* Header actions */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setSearchOpen(true)}
              className="grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5 transition-colors"
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </button>

            <Link
              href="/wishlist"
              className="relative hidden sm:grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5 transition-colors"
              aria-label={`Wishlist (${wishlist.length} items)`}
            >
              <Heart className="h-5 w-5" />
              {wishlist.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-white">
                  {wishlist.length}
                </span>
              )}
            </Link>

            <Link
              href="/compare"
              className="relative hidden sm:grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5 transition-colors"
              aria-label={`Compare (${compare.length} items)`}
            >
              <GitCompare className="h-5 w-5" />
              {compare.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-secondary px-1 text-[10px] font-bold text-black">
                  {compare.length}
                </span>
              )}
            </Link>

            <Link
              href="/account"
              className="hidden sm:grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5 transition-colors"
              aria-label="Account"
            >
              <User className="h-5 w-5" />
            </Link>

            <button
              onClick={() => setCartOpen(true)}
              className="relative grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5 transition-colors"
              aria-label={`Cart (${cartCount} items)`}
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-black">
                  {cartCount}
                </span>
              )}
            </button>

            <Link
              href="/setup-builder"
              className="ml-2 hidden md:inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-white shadow-lg shadow-primary/30 hover:bg-primary/90 transition-colors"
            >
              <Wand2 className="h-4 w-4" />
              Build setup
            </Link>
          </div>
        </div>
      </motion.nav>
    </header>
  );
}
