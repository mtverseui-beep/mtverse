"use client";

import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useEffect, useMemo } from "react";
import { Search, X, TrendingUp, Clock, ArrowRight } from "lucide-react";
import { useShopStore } from "@/lib/shop-store";
import { PRODUCTS } from "@/data/products";
import { COLLECTIONS } from "@/data/collections";
import { BLOG_POSTS, BUYING_GUIDES } from "@/data/content";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice } from "@/lib/utils";

const TRENDING_SEARCHES = ["NovaKeys TKL Pro", "wireless mouse", "streaming mic", "RGB", "desk mat"];
const RECENT_KEY = "nova-rig-recent-searches";

export function SearchOverlay() {
  const router = useRouter();
  const { searchOpen, setSearchOpen } = useShopStore();
  const [query, setQuery] = useState("");
  const [recent, setRecent] = useState<string[]>([]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const stored = window.localStorage.getItem(RECENT_KEY);
      if (stored) setRecent(JSON.parse(stored));
    } catch {}
  }, [searchOpen]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [setSearchOpen]);

  const results = useMemo(() => {
    if (!query.trim()) return { products: [], collections: [], guides: [] };
    const q = query.toLowerCase();
    return {
      products: PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.categoryLabel.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q) ||
          p.tags?.some((t) => t.toLowerCase().includes(q)),
      ).slice(0, 6),
      collections: COLLECTIONS.filter(
        (c) => c.name.toLowerCase().includes(q) || c.tagline.toLowerCase().includes(q),
      ).slice(0, 3),
      guides: [...BLOG_POSTS, ...BUYING_GUIDES.map((g) => ({ ...g, category: g.category as string, slug: g.slug, title: g.title, excerpt: g.excerpt }))]
        .filter((g) => g.title.toLowerCase().includes(q) || g.excerpt.toLowerCase().includes(q))
        .slice(0, 3),
    };
  }, [query]);

  const submitSearch = (q: string) => {
    if (!q.trim()) return;
    const newRecent = [q, ...recent.filter((r) => r !== q)].slice(0, 5);
    setRecent(newRecent);
    try {
      window.localStorage.setItem(RECENT_KEY, JSON.stringify(newRecent));
    } catch {}
    setSearchOpen(false);
    setQuery("");
    router.push(`/search?q=${encodeURIComponent(q)}`);
  };

  return (
    <AnimatePresence>
      {searchOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-md"
          onClick={() => setSearchOpen(false)}
        >
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 260, damping: 25 }}
            className="mx-auto mt-20 max-w-2xl px-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-[#0B0F1A] rounded-2xl border border-white/10 overflow-hidden shadow-2xl">
              <div className="flex items-center gap-3 border-b border-white/10 px-4 py-3">
                <Search className="h-5 w-5 text-muted-foreground" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") submitSearch(query);
                  }}
                  placeholder="Search gear, collections, guides..."
                  className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground outline-none text-base"
                />
                <button
                  onClick={() => setSearchOpen(false)}
                  className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-white/5"
                  aria-label="Close search"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="max-h-[60vh] overflow-y-auto p-4 space-y-6">
                {!query.trim() && (
                  <>
                    {recent.length > 0 && (
                      <div>
                        <h3 className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                          <Clock className="h-3.5 w-3.5" /> Recent searches
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {recent.map((r) => (
                            <button
                              key={r}
                              onClick={() => submitSearch(r)}
                              className="rounded-full bg-white/5 px-3 py-1.5 text-sm text-foreground hover:bg-white/10"
                            >
                              {r}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    <div>
                      <h3 className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        <TrendingUp className="h-3.5 w-3.5" /> Trending searches
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {TRENDING_SEARCHES.map((t) => (
                          <button
                            key={t}
                            onClick={() => submitSearch(t)}
                            className="rounded-full bg-primary/10 px-3 py-1.5 text-sm text-primary hover:bg-primary/20"
                          >
                            {t}
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                {query.trim() && results.products.length === 0 && results.collections.length === 0 && results.guides.length === 0 && (
                  <div className="py-12 text-center">
                    <p className="text-muted-foreground">No results for &ldquo;{query}&rdquo;</p>
                    <button
                      onClick={() => submitSearch(query)}
                      className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white"
                    >
                      Search all products <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                )}

                {results.products.length > 0 && (
                  <div>
                    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Products</h3>
                    <div className="space-y-1">
                      {results.products.map((p) => (
                        <Link
                          key={p.id}
                          href={`/product/${p.slug}`}
                          onClick={() => setSearchOpen(false)}
                          className="flex items-center gap-3 rounded-lg p-2 hover:bg-white/5"
                        >
                          <SafeImg
                            src={p.images[0]}
                            alt={p.name}
                            className="h-12 w-12 rounded-md object-cover"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-semibold text-foreground truncate">{p.name}</div>
                            <div className="text-xs text-muted-foreground">{p.categoryLabel}</div>
                          </div>
                          <div className="text-sm font-bold text-primary">{formatPrice(p.price)}</div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {results.collections.length > 0 && (
                  <div>
                    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Collections</h3>
                    <div className="space-y-1">
                      {results.collections.map((c) => (
                        <Link
                          key={c.slug}
                          href={`/collections/${c.slug}`}
                          onClick={() => setSearchOpen(false)}
                          className="flex items-center gap-3 rounded-lg p-2 hover:bg-white/5"
                        >
                          <div className="flex-1">
                            <div className="text-sm font-semibold text-foreground">{c.name}</div>
                            <div className="text-xs text-muted-foreground">{c.tagline}</div>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground" />
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {results.guides.length > 0 && (
                  <div>
                    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Guides & Articles</h3>
                    <div className="space-y-1">
                      {results.guides.map((g) => (
                        <Link
                          key={g.slug}
                          href={`/blog/${g.slug}`}
                          onClick={() => setSearchOpen(false)}
                          className="flex items-center gap-3 rounded-lg p-2 hover:bg-white/5"
                        >
                          <div className="flex-1">
                            <div className="text-sm font-semibold text-foreground line-clamp-1">{g.title}</div>
                            <div className="text-xs text-muted-foreground line-clamp-1">{g.excerpt}</div>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground" />
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
