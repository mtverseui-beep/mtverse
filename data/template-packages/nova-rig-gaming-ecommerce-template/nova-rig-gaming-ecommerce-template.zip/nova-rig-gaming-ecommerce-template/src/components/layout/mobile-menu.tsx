"use client";

import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { X, ChevronRight, ChevronDown } from "lucide-react";
import { useState } from "react";
import { useShopStore } from "@/lib/shop-store";
import { PRIMARY_NAV } from "@/data/navigation";

export function MobileMenu() {
  const pathname = usePathname();
  const { mobileMenuOpen, setMobileMenuOpen } = useShopStore();
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <AnimatePresence>
      {mobileMenuOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 260, damping: 30 }}
            className="fixed inset-y-0 right-0 z-[90] w-full max-w-sm bg-[#0B0F1A] border-l border-white/10 lg:hidden overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-white/10 p-4">
              <span className="font-display text-lg font-bold text-foreground">
                NOVA<span className="text-gradient-violet">RIG</span>
              </span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <nav className="p-2" aria-label="Mobile">
              {PRIMARY_NAV.map((item) => {
                const isOpen = expanded === item.label;
                return (
                  <div key={item.label} className="border-b border-white/5">
                    <button
                      onClick={() => setExpanded(isOpen ? null : item.label)}
                      className="flex w-full items-center justify-between px-3 py-3 text-left font-semibold text-foreground hover:bg-white/5 rounded-lg"
                    >
                      <span>{item.label}</span>
                      {item.children && (
                        <ChevronDown
                          className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`}
                        />
                      )}
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && item.children && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.25 }}
                          className="overflow-hidden"
                        >
                          <Link
                            href={item.href}
                            className="block px-6 py-2 text-sm text-foreground/80 hover:bg-white/5"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            View all
                          </Link>
                          {item.children.map((child) => (
                            <Link
                              key={child.href}
                              href={child.href}
                              className="flex items-center justify-between px-6 py-2 text-sm text-foreground/80 hover:bg-white/5"
                              onClick={() => setMobileMenuOpen(false)}
                            >
                              <span>{child.label}</span>
                              <ChevronRight className="h-3 w-3 opacity-50" />
                            </Link>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                    {!item.children && (
                      <Link
                        href={item.href}
                        className="block px-3 py-3 text-sm text-foreground/80 hover:bg-white/5"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {item.label}
                      </Link>
                    )}
                  </div>
                );
              })}
            </nav>

            <div className="p-4 space-y-2 border-t border-white/10">
              <Link
                href="/account"
                className="block rounded-lg bg-white/5 px-4 py-3 text-sm font-semibold text-foreground text-center"
                onClick={() => setMobileMenuOpen(false)}
              >
                Account
              </Link>
              <Link
                href="/sign-in"
                className="block rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-white text-center"
                onClick={() => setMobileMenuOpen(false)}
              >
                Sign In
              </Link>
              <Link
                href="/setup-builder"
                className="block rounded-lg border border-primary/40 bg-primary/10 px-4 py-3 text-sm font-semibold text-primary text-center"
                onClick={() => setMobileMenuOpen(false)}
              >
                Build my setup
              </Link>
            </div>

            <p className="px-4 pb-6 pt-2 text-xs text-muted-foreground">
              Need help? <Link href="/contact" className="text-primary hover:underline">Contact support</Link>
            </p>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
