"use client";

import { motion } from "framer-motion";
import type { Category } from "@/types";

export function CategoryHero({ cat }: { cat: Category }) {
  return (
    <section className="relative overflow-hidden border-b border-white/10">
      { }
      <img src={cat.heroImage} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/80 to-[#070A12]/60" />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16"
      >
        <span className="text-xs font-bold uppercase tracking-wider text-primary">{cat.tagline}</span>
        <h1 className="mt-3 font-display text-4xl font-black uppercase tracking-tighter text-foreground sm:text-5xl lg:text-6xl">
          {cat.name}
        </h1>
        <p className="mt-4 max-w-2xl text-base text-muted-foreground">{cat.description}</p>
      </motion.div>
    </section>
  );
}
