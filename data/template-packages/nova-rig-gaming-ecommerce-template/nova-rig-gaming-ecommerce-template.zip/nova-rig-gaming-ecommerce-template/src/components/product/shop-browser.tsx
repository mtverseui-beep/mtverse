"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Filter, Grid2x2, List, X, SlidersHorizontal, ChevronDown, Check } from "lucide-react";
import { ProductCard } from "@/components/product/product-card";
import { useQuickView } from "@/lib/quick-view-store";
import type { Product, ProductCategory } from "@/types";
import { cn } from "@/lib/utils";

interface ShopBrowserProps {
  products: Product[];
  title: string;
  description?: string;
  showCategoryFilter?: boolean;
  showCollectionFilter?: boolean;
}

type SortOption = "featured" | "price-asc" | "price-desc" | "rating" | "newest";

const SORT_LABELS: Record<SortOption, string> = {
  featured: "Featured",
  "price-asc": "Price: low to high",
  "price-desc": "Price: high to low",
  rating: "Top rated",
  newest: "Newest",
};

const PRICE_RANGES = [
  { id: "p1", label: "Under $50", min: 0, max: 50 },
  { id: "p2", label: "$50 – $100", min: 50, max: 100 },
  { id: "p3", label: "$100 – $200", min: 100, max: 200 },
  { id: "p4", label: "$200 – $500", min: 200, max: 500 },
  { id: "p5", label: "$500+", min: 500, max: Infinity },
];

const COMPATIBILITY_OPTIONS = ["PC", "Mac", "Console", "USB-C", "Bluetooth", "2.4GHz"];
const SETUP_TYPES = ["gaming", "streaming", "creator", "minimal", "esports"];

export function ShopBrowser({
  products,
  title,
  description,
  showCategoryFilter = true,
  showCollectionFilter = false,
}: ShopBrowserProps) {
  const { openQuickView } = useQuickView();
  const [view, setView] = useState<"grid" | "list">("grid");
  const [sort, setSort] = useState<SortOption>("featured");
  const [priceFilters, setPriceFilters] = useState<string[]>([]);
  const [compatFilters, setCompatFilters] = useState<string[]>([]);
  const [setupFilters, setSetupFilters] = useState<string[]>([]);
  const [categoryFilters, setCategoryFilters] = useState<string[]>([]);
  const [collectionFilters, setCollectionFilters] = useState<string[]>([]);
  const [stockOnly, setStockOnly] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(12);

  const categories = useMemo(() => {
    const set = new Set(products.map((p) => p.category));
    return Array.from(set);
  }, [products]);
  const collections = useMemo(() => {
    const set = new Set(products.map((p) => p.collection));
    return Array.from(set);
  }, [products]);

  const filtered = useMemo(() => {
    let result = [...products];
    if (priceFilters.length > 0) {
      result = result.filter((p) =>
        priceFilters.some((id) => {
          const range = PRICE_RANGES.find((r) => r.id === id);
          return range ? p.price >= range.min && p.price < range.max : false;
        }),
      );
    }
    if (compatFilters.length > 0) {
      result = result.filter((p) => compatFilters.every((c) => p.compatibility.includes(c)));
    }
    if (setupFilters.length > 0) {
      result = result.filter((p) => p.setupType?.some((s) => setupFilters.includes(s)));
    }
    if (categoryFilters.length > 0) {
      result = result.filter((p) => categoryFilters.includes(p.category));
    }
    if (collectionFilters.length > 0) {
      result = result.filter((p) => collectionFilters.includes(p.collection));
    }
    if (stockOnly) {
      result = result.filter((p) => p.stock > 0);
    }
    switch (sort) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        result.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "newest":
        result.sort((a, b) => (b.badge === "new" ? 1 : 0) - (a.badge === "new" ? 1 : 0));
        break;
      default:
        // featured: best-sellers first, then new, then limited
        result.sort((a, b) => {
          const order = (b: Product) => (b.badge === "best-seller" ? 3 : b.badge === "new" ? 2 : b.badge === "limited" ? 1 : 0);
          return order(b) - order(a);
        });
    }
    return result;
  }, [products, priceFilters, compatFilters, setupFilters, categoryFilters, collectionFilters, stockOnly, sort]);

  const activeFilterCount =
    priceFilters.length + compatFilters.length + setupFilters.length + categoryFilters.length + collectionFilters.length + (stockOnly ? 1 : 0);

  const toggleArray = (arr: string[], v: string): string[] =>
    arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v];

  const clearAll = () => {
    setPriceFilters([]);
    setCompatFilters([]);
    setSetupFilters([]);
    setCategoryFilters([]);
    setCollectionFilters([]);
    setStockOnly(false);
  };

  const FilterPanel = () => (
    <div className="space-y-6">
      {showCategoryFilter && categories.length > 1 && (
        <FilterGroup title="Category">
          {categories.map((c) => (
            <CheckOption
              key={c}
              label={products.find((p) => p.category === c)?.categoryLabel ?? c}
              checked={categoryFilters.includes(c)}
              onChange={() => setCategoryFilters((prev) => toggleArray(prev, c))}
            />
          ))}
        </FilterGroup>
      )}
      {showCollectionFilter && collections.length > 1 && (
        <FilterGroup title="Collection">
          {collections.map((c) => (
            <CheckOption
              key={c}
              label={products.find((p) => p.collection === c)?.collectionLabel ?? c}
              checked={collectionFilters.includes(c)}
              onChange={() => setCollectionFilters((prev) => toggleArray(prev, c))}
            />
          ))}
        </FilterGroup>
      )}
      <FilterGroup title="Price">
        {PRICE_RANGES.map((r) => (
          <CheckOption
            key={r.id}
            label={r.label}
            checked={priceFilters.includes(r.id)}
            onChange={() => setPriceFilters((prev) => toggleArray(prev, r.id))}
          />
        ))}
      </FilterGroup>
      <FilterGroup title="Compatibility">
        {COMPATIBILITY_OPTIONS.map((c) => (
          <CheckOption
            key={c}
            label={c}
            checked={compatFilters.includes(c)}
            onChange={() => setCompatFilters((prev) => toggleArray(prev, c))}
          />
        ))}
      </FilterGroup>
      <FilterGroup title="Setup type">
        {SETUP_TYPES.map((s) => (
          <CheckOption
            key={s}
            label={s.charAt(0).toUpperCase() + s.slice(1)}
            checked={setupFilters.includes(s)}
            onChange={() => setSetupFilters((prev) => toggleArray(prev, s))}
          />
        ))}
      </FilterGroup>
      <FilterGroup title="Availability">
        <CheckOption
          label="In stock only"
          checked={stockOnly}
          onChange={() => setStockOnly((v) => !v)}
        />
      </FilterGroup>
      {activeFilterCount > 0 && (
        <button
          onClick={clearAll}
          className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-foreground hover:bg-white/10"
        >
          Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
          {title}
        </h1>
        {description && <p className="mt-2 max-w-2xl text-muted-foreground">{description}</p>}
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar - desktop */}
        <aside className="hidden lg:block w-64 shrink-0">
          <div className="sticky top-32 rounded-2xl border border-white/10 bg-[#0B0F1A] p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold uppercase tracking-wider text-foreground flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4 text-primary" /> Filters
              </h2>
              {activeFilterCount > 0 && (
                <span className="rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-bold text-primary">
                  {activeFilterCount}
                </span>
              )}
            </div>
            <FilterPanel />
          </div>
        </aside>

        {/* Main content */}
        <div className="flex-1 min-w-0">
          {/* Toolbar */}
          <div className="flex items-center justify-between gap-3 mb-4 rounded-xl border border-white/10 bg-[#0B0F1A] p-3">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDrawerOpen(true)}
                className="lg:hidden inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-foreground"
              >
                <Filter className="h-4 w-4" /> Filters
                {activeFilterCount > 0 && (
                  <span className="grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-white">
                    {activeFilterCount}
                  </span>
                )}
              </button>
              <span className="text-xs text-muted-foreground">
                {filtered.length} {filtered.length === 1 ? "item" : "items"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value as SortOption)}
                  className="appearance-none rounded-lg border border-white/10 bg-white/5 pl-3 pr-8 py-2 text-xs font-semibold text-foreground outline-none focus:border-primary"
                >
                  {Object.entries(SORT_LABELS).map(([v, l]) => (
                    <option key={v} value={v} className="bg-[#101522]">
                      {l}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              </div>

              <div className="hidden sm:flex items-center rounded-lg border border-white/10 bg-white/5 p-0.5">
                <button
                  onClick={() => setView("grid")}
                  aria-label="Grid view"
                  className={cn(
                    "grid h-8 w-8 place-items-center rounded-md",
                    view === "grid" ? "bg-primary text-white" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  <Grid2x2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setView("list")}
                  aria-label="List view"
                  className={cn(
                    "grid h-8 w-8 place-items-center rounded-md",
                    view === "list" ? "bg-primary text-white" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  <List className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Active filter chips */}
          {activeFilterCount > 0 && (
            <div className="mb-4 flex flex-wrap gap-2">
              {priceFilters.map((id) => {
                const r = PRICE_RANGES.find((x) => x.id === id);
                return (
                  <Chip key={`price-${id}`} label={r?.label ?? id} onRemove={() => setPriceFilters((p) => p.filter((x) => x !== id))} />
                );
              })}
              {compatFilters.map((c) => (
                <Chip key={`compat-${c}`} label={c} onRemove={() => setCompatFilters((p) => p.filter((x) => x !== c))} />
              ))}
              {setupFilters.map((s) => (
                <Chip key={`setup-${s}`} label={s} onRemove={() => setSetupFilters((p) => p.filter((x) => x !== s))} />
              ))}
              {categoryFilters.map((c) => (
                <Chip key={`cat-${c}`} label={products.find((p) => p.category === c)?.categoryLabel ?? c} onRemove={() => setCategoryFilters((p) => p.filter((x) => x !== c))} />
              ))}
              {collectionFilters.map((c) => (
                <Chip key={`col-${c}`} label={products.find((p) => p.collection === c)?.collectionLabel ?? c} onRemove={() => setCollectionFilters((p) => p.filter((x) => x !== c))} />
              ))}
              {stockOnly && <Chip label="In stock" onRemove={() => setStockOnly(false)} />}
              <button onClick={clearAll} className="text-xs text-primary hover:underline">
                Clear all
              </button>
            </div>
          )}

          {/* Grid */}
          {filtered.length === 0 ? (
            <div className="grid place-items-center rounded-2xl border border-white/10 bg-[#0B0F1A] py-20 text-center">
              <div>
                <h3 className="text-lg font-bold text-foreground">No results</h3>
                <p className="mt-1 text-sm text-muted-foreground">Try adjusting your filters.</p>
                <button
                  onClick={clearAll}
                  className="mt-4 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white"
                >
                  Clear filters
                </button>
              </div>
            </div>
          ) : (
            <div
              className={cn(
                "grid gap-4",
                view === "grid"
                  ? "grid-cols-2 lg:grid-cols-3"
                  : "grid-cols-1",
              )}
            >
              {filtered.slice(0, visibleCount).map((p, i) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: Math.min(i * 0.03, 0.4) }}
                  className={view === "list" ? "sm:col-span-1" : ""}
                >
                  <ProductCard product={p} onQuickView={openQuickView} />
                </motion.div>
              ))}
            </div>
          )}

          {/* Load more */}
          {visibleCount < filtered.length && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={() => setVisibleCount((c) => c + 12)}
                className="rounded-lg border border-white/15 bg-white/5 px-6 py-3 text-sm font-semibold text-foreground hover:bg-white/10"
              >
                Load more ({filtered.length - visibleCount} remaining)
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile filter drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[80] bg-black/60 lg:hidden"
              onClick={() => setDrawerOpen(false)}
            />
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", stiffness: 260, damping: 30 }}
              className="fixed inset-y-0 left-0 z-[90] w-full max-w-sm overflow-y-auto bg-[#0B0F1A] border-r border-white/10 lg:hidden p-5"
            >
              <div className="mb-5 flex items-center justify-between">
                <h2 className="text-base font-bold uppercase tracking-wider text-foreground flex items-center gap-2">
                  <SlidersHorizontal className="h-4 w-4 text-primary" /> Filters
                </h2>
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="grid h-10 w-10 place-items-center rounded-lg text-foreground hover:bg-white/5"
                  aria-label="Close filters"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <FilterPanel />
              <button
                onClick={() => setDrawerOpen(false)}
                className="mt-6 w-full rounded-lg bg-primary px-4 py-3 text-sm font-bold text-white"
              >
                Show {filtered.length} results
              </button>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function CheckOption({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-sm text-foreground hover:text-primary">
      <button
        type="button"
        onClick={onChange}
        aria-pressed={checked}
        className={cn(
          "grid h-4 w-4 place-items-center rounded border",
          checked ? "border-primary bg-primary text-white" : "border-white/20 bg-transparent",
        )}
      >
        {checked && <Check className="h-3 w-3" />}
      </button>
      <span className="flex-1">{label}</span>
    </label>
  );
}

function Chip({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-[11px] font-semibold text-primary">
      {label}
      <button onClick={onRemove} aria-label={`Remove ${label}`} className="hover:text-white">
        <X className="h-3 w-3" />
      </button>
    </span>
  );
}
