"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Heart, GitCompare, Eye, ShoppingCart, Star } from "lucide-react";
import type { Product } from "@/types";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice, calcDiscount, cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  className?: string;
  onQuickView?: (product: Product) => void;
}

const BADGE_STYLES: Record<string, string> = {
  new: "bg-accent/20 text-accent border-accent/40",
  "best-seller": "bg-primary/20 text-primary border-primary/40",
  limited: "bg-warning/20 text-warning border-warning/40",
  sale: "bg-danger/20 text-danger border-danger/40",
  preorder: "bg-secondary/20 text-secondary border-secondary/40",
  restock: "bg-success/20 text-success border-success/40",
  exclusive: "bg-primary/30 text-primary border-primary/60",
};

export function ProductCard({ product, className, onQuickView }: ProductCardProps) {
  const { addToCart, toggleWishlist, isWishlisted, toggleCompare, isCompared } = useShopStore();

  const discount = calcDiscount(product.price, product.compareAtPrice);
  const wished = isWishlisted(product.slug);
  const compared = isCompared(product.slug);
  const lowStock = product.lowStockThreshold && product.stock <= product.lowStockThreshold;

  return (
    <motion.article
      whileHover={{ y: -4 }}
      transition={{ type: "spring", stiffness: 300, damping: 25 }}
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#101522] transition-colors hover:border-primary/30",
        className,
      )}
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-[#0B0F1A]">
        <Link href={`/product/${product.slug}`}>
          <SafeImg
            src={product.images[0]}
            alt={`${product.name} — ${product.shortDescription}`}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            width={500}
            height={500}
          />
        </Link>

        {/* Badges */}
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {product.badge && (
            <span
              className={cn(
                "rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider",
                BADGE_STYLES[product.badge] ?? "bg-white/10 text-foreground border-white/20",
              )}
            >
              {product.badge.replace("-", " ")}
            </span>
          )}
          {discount > 0 && (
            <span className="rounded-full border border-danger/40 bg-danger/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-danger">
              -{discount}%
            </span>
          )}
        </div>

        {/* Action buttons */}
        <div className="absolute right-3 top-3 flex flex-col gap-1.5">
          <button
            onClick={() => toggleWishlist(product.slug)}
            aria-label={wished ? "Remove from wishlist" : "Add to wishlist"}
            className={cn(
              "grid h-9 w-9 place-items-center rounded-full backdrop-blur-md transition-colors",
              wished ? "bg-primary text-white" : "bg-black/40 text-foreground hover:bg-black/60",
            )}
          >
            <Heart className={cn("h-4 w-4", wished && "fill-current")} />
          </button>
          <button
            onClick={() => toggleCompare(product.slug)}
            aria-label={compared ? "Remove from compare" : "Add to compare"}
            className={cn(
              "grid h-9 w-9 place-items-center rounded-full backdrop-blur-md transition-colors",
              compared ? "bg-secondary text-black" : "bg-black/40 text-foreground hover:bg-black/60",
            )}
          >
            <GitCompare className="h-4 w-4" />
          </button>
          {onQuickView && (
            <button
              onClick={() => onQuickView(product)}
              aria-label="Quick view"
              className="grid h-9 w-9 place-items-center rounded-full bg-black/40 text-foreground backdrop-blur-md transition-colors hover:bg-black/60"
            >
              <Eye className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Quick add (desktop) */}
        <div className="absolute inset-x-3 bottom-3 hidden translate-y-2 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 sm:block">
          <button
            onClick={() =>
              addToCart({
                productSlug: product.slug,
                name: product.name,
                image: product.images[0],
                price: product.price,
                quantity: 1,
                variant: product.variants[0]?.value,
                color: product.colors[0]?.name,
              })
            }
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-3 py-2 text-sm font-bold text-white shadow-lg shadow-primary/30 hover:bg-primary/90"
          >
            <ShoppingCart className="h-4 w-4" /> Quick add
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            {product.categoryLabel}
          </span>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-warning text-warning" />
            <span className="font-semibold text-foreground">{product.rating}</span>
            <span>({product.reviewCount.toLocaleString()})</span>
          </div>
        </div>

        <Link
          href={`/product/${product.slug}`}
          className="mt-1 text-sm font-bold text-foreground hover:text-primary line-clamp-2"
        >
          {product.name}
        </Link>

        <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{product.shortDescription}</p>

        {/* Colors */}
        {product.colors.length > 0 && (
          <div className="mt-3 flex items-center gap-1.5">
            {product.colors.slice(0, 4).map((c) => (
              <span
                key={c.name}
                title={c.name}
                className="h-4 w-4 rounded-full border border-white/20"
                style={{ backgroundColor: c.hex }}
              />
            ))}
            {product.colors.length > 4 && (
              <span className="text-[10px] text-muted-foreground">+{product.colors.length - 4}</span>
            )}
          </div>
        )}

        <div className="mt-3 flex items-end justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-foreground">{formatPrice(product.price)}</span>
            {product.compareAtPrice && (
              <span className="text-xs text-muted-foreground line-through">{formatPrice(product.compareAtPrice)}</span>
            )}
          </div>
          {lowStock && (
            <span className="text-[10px] font-bold uppercase tracking-wider text-warning">Only {product.stock} left</span>
          )}
        </div>

        {/* Quick add (mobile) */}
        <button
          onClick={() =>
            addToCart({
              productSlug: product.slug,
              name: product.name,
              image: product.images[0],
              price: product.price,
              quantity: 1,
              variant: product.variants[0]?.value,
              color: product.colors[0]?.name,
            })
          }
          className="mt-3 flex items-center justify-center gap-2 rounded-lg bg-primary px-3 py-2 text-sm font-bold text-white sm:hidden"
        >
          <ShoppingCart className="h-4 w-4" /> Add
        </button>
      </div>
    </motion.article>
  );
}
