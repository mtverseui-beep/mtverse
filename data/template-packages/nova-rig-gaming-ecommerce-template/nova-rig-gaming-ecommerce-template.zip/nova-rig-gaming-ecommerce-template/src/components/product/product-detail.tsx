"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  Star,
  Heart,
  GitCompare,
  Share2,
  ShoppingCart,
  Check,
  Truck,
  ShieldCheck,
  ChevronRight,
  Plus,
  Minus,
  ZoomIn,
  X,
  Package,
  RotateCcw,
} from "lucide-react";
import type { Product } from "@/types";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice, calcDiscount, cn } from "@/lib/utils";
import { toast } from "sonner";
import { Reveal } from "@/components/motion/reveal";

interface ProductDetailProps {
  product: Product;
}

export function ProductDetail({ product }: ProductDetailProps) {
  const { addToCart, toggleWishlist, isWishlisted, toggleCompare, isCompared, addRecentlyViewed } = useShopStore();
  const [activeImage, setActiveImage] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState(0);
  const [selectedColor, setSelectedColor] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [zoomOpen, setZoomOpen] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<string | null>("materials");

  useEffect(() => {
    addRecentlyViewed(product.slug);
  }, [product.slug, addRecentlyViewed]);

  const wished = isWishlisted(product.slug);
  const compared = isCompared(product.slug);
  const discount = calcDiscount(product.price, product.compareAtPrice);
  const lowStock = product.lowStockThreshold && product.stock <= product.lowStockThreshold;
  const inStock = product.stock > 0;

  const share = async () => {
    try {
      if (typeof navigator !== "undefined" && navigator.share) {
        await navigator.share({ title: product.name, url: window.location.href });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success("Link copied to clipboard");
      }
    } catch {
      // ignore
    }
  };

  const buyNow = () => {
    addToCart({
      productSlug: product.slug,
      name: product.name,
      image: product.images[0],
      price: product.price,
      quantity,
      variant: product.variants[selectedVariant]?.value,
      color: product.colors[selectedColor]?.name,
    });
    window.location.href = "/checkout";
  };

  const accordions = [
    { id: "materials", label: "Materials & build", icon: Package, content: product.specs.map((s) => `${s.label}: ${s.value}`).join("\n") },
    { id: "compatibility", label: "Compatibility", icon: Check, content: `Compatible with: ${product.compatibility.join(", ")}` },
    { id: "warranty", label: "Warranty", icon: ShieldCheck, content: `${product.warranty}\n${product.shipping}` },
    { id: "shipping", label: "Shipping & returns", icon: Truck, content: `${product.shipping}\n30-day return policy. See our Returns Policy page for details.` },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumbs */}
      <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1 text-xs text-muted-foreground">
        <Link href="/" className="hover:text-foreground">Home</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/shop" className="hover:text-foreground">Shop</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href={`/${product.category}`} className="hover:text-foreground capitalize">{product.categoryLabel}</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground truncate">{product.name}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Image gallery */}
        <div className="space-y-3">
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="relative aspect-square overflow-hidden rounded-2xl border border-white/10 bg-[#0B0F1A] group"
          >
            <SafeImg
              src={product.gallery[activeImage]}
              alt={`${product.name} image ${activeImage + 1}`}
              className="h-full w-full object-cover"
              width={800}
              height={800}
              loading="eager"
            />
            <button
              onClick={() => setZoomOpen(true)}
              aria-label="Zoom image"
              className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full bg-black/40 text-foreground backdrop-blur hover:bg-black/60"
            >
              <ZoomIn className="h-4 w-4" />
            </button>
            {product.badge && (
              <span className="absolute left-3 top-3 rounded-full border border-primary/40 bg-primary/20 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-primary">
                {product.badge.replace("-", " ")}
              </span>
            )}
          </motion.div>

          {product.gallery.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-2">
              {product.gallery.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={cn(
                    "relative h-20 w-20 shrink-0 overflow-hidden rounded-lg border-2 transition-colors",
                    activeImage === i ? "border-primary" : "border-white/10 hover:border-white/30",
                  )}
                >
                  <SafeImg src={img} alt={`${product.name} thumbnail ${i + 1}`} className="h-full w-full object-cover" width={80} height={80} />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-primary">{product.categoryLabel}</span>
          <h1 className="mt-2 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
            {product.name}
          </h1>

          <div className="mt-3 flex items-center gap-3 text-sm">
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={cn("h-4 w-4", i < Math.round(product.rating) ? "fill-warning text-warning" : "text-white/20")}
                />
              ))}
              <span className="ml-1 font-bold text-foreground">{product.rating}</span>
            </div>
            <span className="text-muted-foreground">·</span>
            <a href="#reviews" className="text-muted-foreground hover:text-primary">
              {product.reviewCount.toLocaleString()} reviews
            </a>
          </div>

          <div className="mt-5 flex items-baseline gap-3">
            <span className="font-display text-4xl font-black text-foreground">{formatPrice(product.price)}</span>
            {product.compareAtPrice && (
              <>
                <span className="text-lg text-muted-foreground line-through">{formatPrice(product.compareAtPrice)}</span>
                <span className="rounded-full bg-danger/20 px-2 py-0.5 text-xs font-bold text-danger">Save {discount}%</span>
              </>
            )}
          </div>

          <p className="mt-4 text-base text-muted-foreground">{product.shortDescription}</p>

          {/* Variants */}
          {product.variants.length > 0 && (
            <div className="mt-6">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                {product.variants[0].label}
              </span>
              <div className="mt-2 flex flex-wrap gap-2">
                {product.variants.map((v, i) => (
                  <button
                    key={v.id}
                    onClick={() => setSelectedVariant(i)}
                    className={cn(
                      "rounded-lg border px-4 py-2 text-sm font-semibold",
                      selectedVariant === i
                        ? "border-primary bg-primary/15 text-primary"
                        : "border-white/10 text-foreground hover:bg-white/5",
                    )}
                  >
                    {v.value}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Colors */}
          {product.colors.length > 0 && (
            <div className="mt-4">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Color · <span className="text-foreground">{product.colors[selectedColor]?.name}</span>
              </span>
              <div className="mt-2 flex flex-wrap gap-2">
                {product.colors.map((c, i) => (
                  <button
                    key={c.name}
                    onClick={() => setSelectedColor(i)}
                    aria-label={c.name}
                    className={cn(
                      "h-10 w-10 rounded-full border-2 transition-transform",
                      selectedColor === i ? "border-primary scale-110" : "border-white/20 hover:border-white/40",
                    )}
                    style={{ backgroundColor: c.hex }}
                  >
                    {selectedColor === i && (
                      <Check className="mx-auto h-4 w-4 text-white drop-shadow" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity + add to cart */}
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <div className="flex items-center rounded-lg border border-white/10">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="grid h-12 w-12 place-items-center text-foreground hover:bg-white/5"
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-12 text-center text-base font-bold text-foreground">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="grid h-12 w-12 place-items-center text-foreground hover:bg-white/5"
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <button
              onClick={() =>
                addToCart({
                  productSlug: product.slug,
                  name: product.name,
                  image: product.images[0],
                  price: product.price,
                  quantity,
                  variant: product.variants[selectedVariant]?.value,
                  color: product.colors[selectedColor]?.name,
                })
              }
              disabled={!inStock}
              className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingCart className="h-4 w-4" />
              {inStock ? "Add to cart" : "Sold out"}
            </button>
            <button
              onClick={buyNow}
              disabled={!inStock}
              className="rounded-lg border border-accent/40 bg-accent/10 px-6 py-3 text-sm font-bold text-accent hover:bg-accent/20 disabled:opacity-50"
            >
              Buy now
            </button>
          </div>

          {/* Secondary actions */}
          <div className="mt-3 flex gap-2">
            <button
              onClick={() => toggleWishlist(product.slug)}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-lg border px-4 py-2.5 text-sm font-semibold",
                wished ? "border-primary bg-primary/10 text-primary" : "border-white/10 text-foreground hover:bg-white/5",
              )}
            >
              <Heart className={cn("h-4 w-4", wished && "fill-current")} />
              {wished ? "Wishlisted" : "Wishlist"}
            </button>
            <button
              onClick={() => toggleCompare(product.slug)}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-lg border px-4 py-2.5 text-sm font-semibold",
                compared ? "border-secondary bg-secondary/10 text-secondary" : "border-white/10 text-foreground hover:bg-white/5",
              )}
            >
              <GitCompare className="h-4 w-4" />
              {compared ? "Comparing" : "Compare"}
            </button>
            <button
              onClick={share}
              className="grid h-11 w-11 place-items-center rounded-lg border border-white/10 text-foreground hover:bg-white/5"
              aria-label="Share"
            >
              <Share2 className="h-4 w-4" />
            </button>
          </div>

          {/* Stock + shipping */}
          <div className="mt-6 space-y-2 rounded-xl border border-white/10 bg-white/[0.02] p-4">
            <div className="flex items-center gap-2 text-sm">
              {inStock ? (
                <>
                  <Check className="h-4 w-4 text-accent" />
                  <span className="font-semibold text-accent">
                    {lowStock ? `Only ${product.stock} left in stock` : "In stock"}
                  </span>
                </>
              ) : (
                <>
                  <X className="h-4 w-4 text-danger" />
                  <span className="font-semibold text-danger">Sold out</span>
                </>
              )}
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Truck className="h-4 w-4 text-primary" />
              <span>{product.shipping}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <ShieldCheck className="h-4 w-4 text-primary" />
              <span>{product.warranty}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <RotateCcw className="h-4 w-4 text-primary" />
              <span>30-day returns</span>
            </div>
          </div>

          {/* Compatibility badges */}
          <div className="mt-4 flex flex-wrap gap-1.5">
            {product.compatibility.map((c) => (
              <span
                key={c}
                className="rounded-full bg-white/5 border border-white/10 px-2.5 py-1 text-[11px] font-semibold text-foreground"
              >
                <Check className="mr-1 inline h-3 w-3 text-accent" />
                {c}
              </span>
            ))}
          </div>

          {/* Accordions */}
          <div className="mt-6 space-y-2">
            {accordions.map((a) => (
              <div key={a.id} className="rounded-lg border border-white/10 bg-white/[0.02]">
                <button
                  onClick={() => setOpenAccordion((prev) => (prev === a.id ? null : a.id))}
                  className="flex w-full items-center justify-between p-4 text-left"
                >
                  <span className="flex items-center gap-2 text-sm font-semibold text-foreground">
                    <a.icon className="h-4 w-4 text-primary" />
                    {a.label}
                  </span>
                  <Plus className={cn("h-4 w-4 text-muted-foreground transition-transform", openAccordion === a.id && "rotate-45")} />
                </button>
                <AnimatePresence>
                  {openAccordion === a.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 text-sm text-muted-foreground whitespace-pre-line">
                        {a.content}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features grid */}
      <section className="mt-16">
        <Reveal>
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-foreground mb-6">
            Key features
          </h2>
        </Reveal>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {product.features.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.06}>
              <div className="rounded-xl border border-white/10 bg-[#101522] p-5">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary">
                  {/* Use a generic icon */}
                  <Star className="h-5 w-5" />
                </div>
                <h3 className="mt-3 text-sm font-bold text-foreground">{f.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground line-clamp-3">{f.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* What's in the box */}
      <section className="mt-12 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
        <h2 className="font-display text-xl font-bold uppercase tracking-tight text-foreground flex items-center gap-2">
          <Package className="h-5 w-5 text-primary" /> What's in the box
        </h2>
        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
          {product.inTheBox.map((item) => (
            <li key={item} className="flex items-center gap-2 text-sm text-foreground">
              <Check className="h-4 w-4 text-accent shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </section>

      {/* Specs table */}
      <section className="mt-12">
        <Reveal>
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-foreground mb-6">
            Technical specs
          </h2>
        </Reveal>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {product.specs.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.03}>
              <div className="rounded-lg border border-white/10 bg-white/[0.02] p-4">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</div>
                <div className="mt-1 text-sm font-bold text-foreground">{s.value}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Reviews preview */}
      {product.reviews && product.reviews.length > 0 && (
        <section id="reviews" className="mt-12">
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-foreground mb-6">
            Customer reviews
          </h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {product.reviews.map((r) => (
              <div key={r.id} className="rounded-xl border border-white/10 bg-[#101522] p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <SafeImg src={r.avatar} alt={r.author} className="h-9 w-9 rounded-full object-cover" width={36} height={36} />
                    <div>
                      <div className="text-sm font-semibold text-foreground">{r.author}</div>
                      {r.verified && <div className="text-[10px] uppercase tracking-wider text-accent">Verified buyer</div>}
                    </div>
                  </div>
                  <div className="flex">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={cn("h-3.5 w-3.5", i < r.rating ? "fill-warning text-warning" : "text-white/20")} />
                    ))}
                  </div>
                </div>
                <h3 className="mt-2 text-sm font-bold text-foreground">{r.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{r.body}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Zoom modal */}
      <AnimatePresence>
        {zoomOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] grid place-items-center bg-black/90 p-4"
            onClick={() => setZoomOpen(false)}
          >
            <button
              onClick={() => setZoomOpen(false)}
              className="absolute right-4 top-4 grid h-12 w-12 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20"
              aria-label="Close zoom"
            >
              <X className="h-6 w-6" />
            </button>
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="max-h-[90vh] max-w-[90vw]"
              onClick={(e) => e.stopPropagation()}
            >
              <SafeImg
                src={product.gallery[activeImage]}
                alt={`${product.name} zoomed view`}
                className="max-h-[90vh] max-w-[90vw] object-contain"
                width={1200}
                height={1200}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
