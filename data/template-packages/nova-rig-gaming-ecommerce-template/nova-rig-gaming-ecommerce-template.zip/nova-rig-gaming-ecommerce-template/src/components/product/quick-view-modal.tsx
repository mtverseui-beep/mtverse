"use client";

import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { X, Star, ShoppingCart, Heart, GitCompare, Check } from "lucide-react";
import { useState } from "react";
import { useQuickView } from "@/lib/quick-view-store";
import { useShopStore } from "@/lib/shop-store";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice, calcDiscount, cn } from "@/lib/utils";

export function QuickViewModal() {
  const { product, open, closeQuickView } = useQuickView();
  const { addToCart, toggleWishlist, isWishlisted, toggleCompare, isCompared } = useShopStore();
  const [activeImage, setActiveImage] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState(0);
  const [selectedColor, setSelectedColor] = useState(0);

  if (!product) return null;

  const wished = isWishlisted(product.slug);
  const compared = isCompared(product.slug);
  const discount = calcDiscount(product.price, product.compareAtPrice);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[80] grid place-items-center bg-black/70 backdrop-blur-md p-4"
          onClick={closeQuickView}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", stiffness: 240, damping: 22 }}
            className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#0B0F1A] border border-white/10 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={closeQuickView}
              className="absolute right-3 top-3 z-10 grid h-10 w-10 place-items-center rounded-full bg-black/40 text-foreground backdrop-blur hover:bg-black/60"
              aria-label="Close quick view"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="grid gap-0 md:grid-cols-2">
              {/* Image gallery */}
              <div className="relative">
                <div className="aspect-square overflow-hidden bg-[#0B0F1A]">
                  <SafeImg
                    src={product.gallery[activeImage]}
                    alt={product.name}
                    className="h-full w-full object-cover"
                    width={600}
                    height={600}
                  />
                </div>
                {product.gallery.length > 1 && (
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
                    {product.gallery.slice(0, 4).map((img, i) => (
                      <button
                        key={i}
                        onClick={() => setActiveImage(i)}
                        className={cn(
                          "h-12 w-12 overflow-hidden rounded-md border-2",
                          activeImage === i ? "border-primary" : "border-white/10",
                        )}
                      >
                        <SafeImg src={img} alt="" className="h-full w-full object-cover" width={48} height={48} />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Details */}
              <div className="p-6 space-y-4">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {product.categoryLabel}
                  </span>
                  <h2 className="mt-1 text-xl font-bold text-foreground">{product.name}</h2>
                  <div className="mt-1 flex items-center gap-2 text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="h-3.5 w-3.5 fill-warning text-warning" />
                      <span className="font-semibold text-foreground">{product.rating}</span>
                    </div>
                    <span className="text-muted-foreground">({product.reviewCount.toLocaleString()} reviews)</span>
                  </div>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-foreground">{formatPrice(product.price)}</span>
                  {product.compareAtPrice && (
                    <>
                      <span className="text-sm text-muted-foreground line-through">{formatPrice(product.compareAtPrice)}</span>
                      <span className="rounded-full bg-danger/20 px-2 py-0.5 text-xs font-bold text-danger">-{discount}%</span>
                    </>
                  )}
                </div>

                <p className="text-sm text-muted-foreground line-clamp-3">{product.shortDescription}</p>

                {/* Variants */}
                {product.variants.length > 0 && (
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      {product.variants[0].label}
                    </span>
                    <div className="mt-1.5 flex flex-wrap gap-2">
                      {product.variants.map((v, i) => (
                        <button
                          key={v.id}
                          onClick={() => setSelectedVariant(i)}
                          className={cn(
                            "rounded-lg border px-3 py-1.5 text-xs font-semibold",
                            selectedVariant === i
                              ? "border-primary bg-primary/15 text-primary"
                              : "border-white/10 text-foreground hover:bg-white/5",
                          )}
                        >
                          {v.value}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Colors */}
                {product.colors.length > 0 && (
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Color</span>
                    <div className="mt-1.5 flex flex-wrap gap-2">
                      {product.colors.map((c, i) => (
                        <button
                          key={c.name}
                          onClick={() => setSelectedColor(i)}
                          aria-label={c.name}
                          className={cn(
                            "h-8 w-8 rounded-full border-2 transition-transform",
                            selectedColor === i ? "border-primary scale-110" : "border-white/20",
                          )}
                          style={{ backgroundColor: c.hex }}
                        />
                      ))}
                    </div>
                    <span className="mt-1 block text-xs text-muted-foreground">{product.colors[selectedColor]?.name}</span>
                  </div>
                )}

                {/* Specs preview */}
                <div className="grid grid-cols-2 gap-2 rounded-lg border border-white/10 bg-white/[0.02] p-3">
                  {product.specs.slice(0, 4).map((spec) => (
                    <div key={spec.label}>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{spec.label}</div>
                      <div className="text-xs font-semibold text-foreground">{spec.value}</div>
                    </div>
                  ))}
                </div>

                {/* Compatibility */}
                <div className="flex flex-wrap gap-1.5">
                  {product.compatibility.slice(0, 5).map((c) => (
                    <span
                      key={c}
                      className="rounded-full bg-white/5 px-2 py-1 text-[10px] font-semibold text-foreground"
                    >
                      <Check className="mr-1 inline h-3 w-3 text-accent" />
                      {c}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      addToCart({
                        productSlug: product.slug,
                        name: product.name,
                        image: product.images[0],
                        price: product.price,
                        quantity: 1,
                        variant: product.variants[selectedVariant]?.value,
                        color: product.colors[selectedColor]?.name,
                      });
                      closeQuickView();
                    }}
                    className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-bold text-white hover:bg-primary/90"
                  >
                    <ShoppingCart className="h-4 w-4" /> Add to cart
                  </button>
                  <button
                    onClick={() => toggleWishlist(product.slug)}
                    aria-label="Wishlist"
                    className={cn(
                      "grid h-12 w-12 place-items-center rounded-lg border",
                      wished ? "border-primary bg-primary/15 text-primary" : "border-white/10 text-foreground hover:bg-white/5",
                    )}
                  >
                    <Heart className={cn("h-4 w-4", wished && "fill-current")} />
                  </button>
                  <button
                    onClick={() => toggleCompare(product.slug)}
                    aria-label="Compare"
                    className={cn(
                      "grid h-12 w-12 place-items-center rounded-lg border",
                      compared ? "border-secondary bg-secondary/15 text-secondary" : "border-white/10 text-foreground hover:bg-white/5",
                    )}
                  >
                    <GitCompare className="h-4 w-4" />
                  </button>
                </div>

                <Link
                  href={`/product/${product.slug}`}
                  onClick={closeQuickView}
                  className="block text-center text-sm font-semibold text-primary hover:underline"
                >
                  View full details
                </Link>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
