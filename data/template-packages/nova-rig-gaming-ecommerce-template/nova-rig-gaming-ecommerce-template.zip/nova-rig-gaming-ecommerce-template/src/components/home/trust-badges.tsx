"use client";

import { motion } from "framer-motion";
import { Truck, RotateCcw, ShieldCheck, Headphones, CreditCard, Globe } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

const BADGES = [
  { icon: Truck, title: "Free shipping", desc: "On orders over $99. Ships in 1–2 business days." },
  { icon: RotateCcw, title: "30-day returns", desc: "Not the right fit? Send it back, no questions." },
  { icon: ShieldCheck, title: "2–5 year warranty", desc: "Every NOVA RIG product is backed by warranty." },
  { icon: Headphones, title: "Real human support", desc: "Email support@novarig.co — replies in 24h." },
  { icon: CreditCard, title: "Secure checkout", desc: "Encrypted payment. Multiple methods." },
  { icon: Globe, title: "Worldwide shipping", desc: "We ship to 80+ countries with tracking." },
];

export function TrustBadges() {
  return (
    <section className="py-12 border-y border-white/10 bg-[#0B0F1A]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {BADGES.map((b, i) => (
            <Reveal key={b.title} delay={i * 0.05}>
              <motion.div
                whileHover={{ y: -2 }}
                className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-4"
              >
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-primary/15 text-primary">
                  <b.icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-foreground">{b.title}</h3>
                  <p className="mt-0.5 text-xs text-muted-foreground">{b.desc}</p>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
