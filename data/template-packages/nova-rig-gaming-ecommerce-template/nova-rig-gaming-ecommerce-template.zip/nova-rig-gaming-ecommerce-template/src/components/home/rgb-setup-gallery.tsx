"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Images, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { TiltCard } from "@/components/motion/tilt-card";
import { SETUP_GALLERY } from "@/data/content";

export function RgbSetupGallery() {
  return (
    <section className="py-16 sm:py-24 bg-[#0B0F1A] border-y border-white/10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-accent flex items-center gap-2">
                <Images className="h-3.5 w-3.5" /> Setup gallery
              </span>
              <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
                Real NOVA RIG setups
              </h2>
              <p className="mt-2 max-w-xl text-muted-foreground">
                Browse setups built by NOVA RIG creators and the community. Tap any setup to shop the gear.
              </p>
            </div>
            <Link
              href="/setup-gallery"
              className="inline-flex items-center gap-2 self-start rounded-lg border border-accent/40 bg-accent/10 px-4 py-2 text-sm font-bold text-accent hover:bg-accent/20"
            >
              View all setups <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SETUP_GALLERY.slice(0, 6).map((setup, i) => (
            <Reveal key={setup.slug} delay={i * 0.06}>
              <TiltCard
                className="group relative aspect-[4/5] overflow-hidden rounded-2xl border border-white/10"
                maxTilt={8}
                scale={1.02}
              >
                <Link href={`/setup-gallery/${setup.slug}`} className="block h-full w-full">
                  { }
                  <img
                    src={setup.image}
                    alt={setup.title}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-transparent to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="rounded-full border border-white/20 bg-black/50 backdrop-blur px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-foreground">
                      {setup.type}
                    </span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <h3 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">
                      {setup.title}
                    </h3>
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{setup.description}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex -space-x-2">
                        {/* mini gear thumbnails */}
                        {setup.gearSlugs.slice(0, 3).map((_, idx) => (
                          <div
                            key={idx}
                            className="h-5 w-5 rounded-full border-2 border-[#070A12] bg-gradient-to-br from-primary to-secondary"
                          />
                        ))}
                      </div>
                      <span className="text-[10px] text-muted-foreground">
                        {setup.gearSlugs.length} pieces of gear
                      </span>
                    </div>
                  </div>
                </Link>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
