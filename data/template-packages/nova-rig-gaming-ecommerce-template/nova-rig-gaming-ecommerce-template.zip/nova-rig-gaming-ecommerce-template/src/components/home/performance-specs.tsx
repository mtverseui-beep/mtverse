"use client";

import { motion } from "framer-motion";
import { Gauge, BatteryCharging, Radio, Layers, AudioLines, Lightbulb, ShieldCheck, Cpu } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { useState } from "react";

const SPECS = [
  { icon: Radio, label: "Polling rate", value: "8000", unit: "Hz", desc: "Quarter-millisecond input reporting", color: "#8B5CF6" },
  { icon: Gauge, label: "Wireless latency", value: "<0.5", unit: "ms", desc: "Sub-frame input lag over 2.4GHz", color: "#06B6D4" },
  { icon: BatteryCharging, label: "Battery life", value: "120", unit: "hrs", desc: "Three-day LANs on one charge", color: "#39FF88" },
  { icon: Layers, label: "Key switch", value: "Hot-swap", unit: "PCB", desc: "Swap switches without soldering", color: "#FBBF24" },
  { icon: AudioLines, label: "Mic capture", value: "32-bit", unit: "float", desc: "Recover clipped audio in post", color: "#FF4D6D" },
  { icon: Lightbulb, label: "RGB zones", value: "84", unit: "addr.", desc: "Per-LED control on GlowBar Pro", color: "#8B5CF6" },
  { icon: Cpu, label: "Optical sensor", value: "36K", unit: "DPI", desc: "Tracks at 750 IPS, 50G accel", color: "#06B6D4" },
  { icon: ShieldCheck, label: "Warranty", value: "2–5", unit: "yr", desc: "Backed by NOVA RIG support", color: "#39FF88" },
];

const TABS = [
  { id: "all", label: "All specs" },
  { id: "input", label: "Input" },
  { id: "audio", label: "Audio" },
  { id: "lighting", label: "Lighting" },
  { id: "build", label: "Build" },
];

const FILTERS: Record<string, (s: typeof SPECS[number]) => boolean> = {
  all: () => true,
  input: (s) => ["Polling rate", "Wireless latency", "Battery life", "Key switch", "Optical sensor"].includes(s.label),
  audio: (s) => ["Mic capture"].includes(s.label),
  lighting: (s) => ["RGB zones"].includes(s.label),
  build: (s) => ["Warranty"].includes(s.label),
};

export function PerformanceSpecs() {
  const [tab, setTab] = useState("all");
  const filtered = SPECS.filter(FILTERS[tab]);

  return (
    <section className="py-16 sm:py-24 bg-[#0B0F1A] border-y border-white/10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="text-center mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">Performance specs</span>
            <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
              Numbers that matter
            </h2>
            <p className="mt-2 max-w-2xl mx-auto text-muted-foreground">
              Every NOVA RIG product is engineered around measurable performance advantages. Here's what that looks like.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="flex justify-center mb-8">
            <div className="inline-flex flex-wrap justify-center gap-1 rounded-full border border-white/10 bg-white/5 p-1">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`relative rounded-full px-4 py-1.5 text-xs font-semibold transition-colors ${
                    tab === t.id ? "text-white" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {tab === t.id && (
                    <motion.div
                      layoutId="spec-tab"
                      className="absolute inset-0 rounded-full bg-primary"
                      transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    />
                  )}
                  <span className="relative z-10">{t.label}</span>
                </button>
              ))}
            </div>
          </div>
        </Reveal>

        <motion.div layout className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {filtered.map((s, i) => (
            <motion.div
              key={s.label}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-[#101522] p-5 hover:border-primary/30 transition-colors"
            >
              <div
                className="absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-10 blur-2xl transition-opacity group-hover:opacity-20"
                style={{ backgroundColor: s.color }}
              />
              <div
                className="inline-grid h-10 w-10 place-items-center rounded-lg"
                style={{ backgroundColor: `${s.color}20`, color: s.color }}
              >
                <s.icon className="h-5 w-5" />
              </div>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="font-display text-3xl font-black text-foreground">{s.value}</span>
                <span className="text-sm font-bold text-muted-foreground">{s.unit}</span>
              </div>
              <div className="mt-1 text-sm font-semibold text-foreground">{s.label}</div>
              <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{s.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
