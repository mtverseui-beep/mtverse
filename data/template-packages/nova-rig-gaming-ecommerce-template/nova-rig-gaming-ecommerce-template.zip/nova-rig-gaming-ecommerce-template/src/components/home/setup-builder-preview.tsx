"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Wand2 } from "lucide-react";
import { TiltCard } from "@/components/motion/tilt-card";
import { Reveal } from "@/components/motion/reveal";
import { PRODUCT_IMAGES } from "@/data/products";

const SETUP_TYPES = [
  {
    slug: "gaming",
    label: "Gaming",
    description: "Low-latency keyboard, mouse, headset, and pad for competitive play.",
    image: PRODUCT_IMAGES.setup1,
    accent: "#8B5CF6",
  },
  {
    slug: "streaming",
    label: "Streaming",
    description: "Mic, webcam, RGB lighting, and cable management for pro streams.",
    image: PRODUCT_IMAGES.setup2,
    accent: "#06B6D4",
  },
  {
    slug: "creator",
    label: "Creator Desk",
    description: "75% keyboard, monitor arm, and creator accessories for content work.",
    image: PRODUCT_IMAGES.setup4,
    accent: "#39FF88",
  },
  {
    slug: "minimal",
    label: "Minimal Workspace",
    description: "Carbon-only gear that doubles as a clean productivity setup.",
    image: PRODUCT_IMAGES.lifestyle3,
    accent: "#94A3B8",
  },
];

export function SetupBuilderPreview() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
                <Wand2 className="h-3.5 w-3.5" /> Build your rig
              </span>
              <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
                Start with a setup type
              </h2>
              <p className="mt-2 max-w-xl text-muted-foreground">
                Pick a setup type and we'll recommend a complete, compatible gear list — adjustable as you go.
              </p>
            </div>
            <Link
              href="/setup-builder"
              className="inline-flex items-center gap-2 self-start rounded-lg border border-primary/40 bg-primary/10 px-4 py-2 text-sm font-bold text-primary hover:bg-primary/20"
            >
              Open setup builder <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {SETUP_TYPES.map((s, i) => (
            <Reveal key={s.slug} delay={i * 0.08}>
              <TiltCard
                className="group relative aspect-[4/5] overflow-hidden rounded-2xl border border-white/10 bg-[#101522]"
                maxTilt={8}
                scale={1.03}
              >
                <Link href={`/setup-builder?type=${s.slug}`} className="block h-full w-full">
                  { }
                  <img
                    src={s.image}
                    alt={s.label}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-[#070A12]/40 to-transparent" />
                  <div
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{
                      background: `linear-gradient(180deg, transparent 40%, ${s.accent}33 100%)`,
                    }}
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <div
                      className="mb-2 inline-block h-1 w-10 rounded-full"
                      style={{ backgroundColor: s.accent }}
                    />
                    <h3 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">
                      {s.label}
                    </h3>
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{s.description}</p>
                    <div className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider" style={{ color: s.accent }}>
                      Build this <ArrowRight className="h-3 w-3" />
                    </div>
                  </div>
                </Link>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
