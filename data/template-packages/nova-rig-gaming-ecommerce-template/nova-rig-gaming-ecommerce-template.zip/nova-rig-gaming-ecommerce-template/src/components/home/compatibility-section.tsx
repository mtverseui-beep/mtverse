"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Monitor, Smartphone, Headphones, Radio, Bluetooth, Usb, Gamepad2, Laptop } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";

const TABS = [
  { id: "gaming", label: "Gaming", icon: Gamepad2 },
  { id: "streaming", label: "Streaming", icon: Headphones },
  { id: "creator", label: "Creator", icon: Monitor },
  { id: "workstation", label: "Workstation", icon: Laptop },
  { id: "console", label: "Console", icon: Gamepad2 },
] as const;

const COMPAT: Record<string, { label: string; icon: React.ComponentType<{ className?: string }>; status: "native" | "supported" | "via-adapter" }[]> = {
  gaming: [
    { label: "PC (Windows 11)", icon: Monitor, status: "native" },
    { label: "PC (Linux / SteamOS)", icon: Monitor, status: "supported" },
    { label: "2.4GHz wireless dongle", icon: Radio, status: "native" },
    { label: "USB-C wired", icon: Usb, status: "native" },
    { label: "Bluetooth 5.3", icon: Bluetooth, status: "native" },
    { label: "Steam Input", icon: Gamepad2, status: "supported" },
  ],
  streaming: [
    { label: "OBS Studio", icon: Monitor, status: "native" },
    { label: "Streamlabs", icon: Monitor, status: "native" },
    { label: "Twitch / YouTube / Kick", icon: Radio, status: "native" },
    { label: "NOVA Sync RGB", icon: Bluetooth, status: "native" },
    { label: "Discord voice", icon: Headphones, status: "supported" },
    { label: "Mac (USB-C)", icon: Laptop, status: "supported" },
  ],
  creator: [
    { label: "Final Cut Pro", icon: Monitor, status: "native" },
    { label: "Premiere Pro", icon: Monitor, status: "native" },
    { label: "DaVinci Resolve", icon: Monitor, status: "native" },
    { label: "Logic Pro / Ableton", icon: Headphones, status: "native" },
    { label: "USB-C webcam", icon: Usb, status: "native" },
    { label: "XLR adapter (Pro X)", icon: Radio, status: "via-adapter" },
  ],
  workstation: [
    { label: "Windows / macOS", icon: Laptop, status: "native" },
    { label: "USB-C multi-device", icon: Usb, status: "native" },
    { label: "Bluetooth 5.3 (3 devices)", icon: Bluetooth, status: "native" },
    { label: "Monitor arms (VESA 75/100)", icon: Monitor, status: "native" },
    { label: "CableCore under-desk", icon: Radio, status: "native" },
    { label: "Ergonomic chair", icon: Smartphone, status: "supported" },
  ],
  console: [
    { label: "PS5 / PS5 Pro (USB)", icon: Gamepad2, status: "native" },
    { label: "Xbox Series X|S (USB)", icon: Gamepad2, status: "native" },
    { label: "Switch (USB-C)", icon: Gamepad2, status: "supported" },
    { label: "Headset 3.5mm", icon: Headphones, status: "native" },
    { label: "Controller docks (universal)", icon: Gamepad2, status: "native" },
    { label: "2.4GHz (limited)", icon: Radio, status: "via-adapter" },
  ],
};

const STATUS_LABEL: Record<string, string> = {
  native: "Native",
  supported: "Supported",
  "via-adapter": "Via adapter",
};
const STATUS_COLOR: Record<string, string> = {
  native: "text-accent border-accent/40 bg-accent/10",
  supported: "text-primary border-primary/40 bg-primary/10",
  "via-adapter": "text-warning border-warning/40 bg-warning/10",
};

export function CompatibilitySection() {
  const [tab, setTab] = useState<string>("gaming");
  const items = COMPAT[tab];

  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="text-center mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">Compatibility</span>
            <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
              Works with your setup
            </h2>
            <p className="mt-2 max-w-2xl mx-auto text-muted-foreground">
              NOVA RIG gear is built to work across gaming, streaming, creator, workstation, and console environments.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="flex justify-center mb-8">
            <div className="inline-flex flex-wrap justify-center gap-1 rounded-full border border-white/10 bg-white/5 p-1">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`relative flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold transition-colors ${
                    tab === t.id ? "text-white" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {tab === t.id && (
                    <motion.div
                      layoutId="compat-tab"
                      className="absolute inset-0 rounded-full bg-primary"
                      transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    />
                  )}
                  <t.icon className="relative z-10 h-3.5 w-3.5" />
                  <span className="relative z-10">{t.label}</span>
                </button>
              ))}
            </div>
          </div>
        </Reveal>

        <motion.div
          layout
          className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl mx-auto"
        >
          <AnimatePresence mode="popLayout">
            {items.map((item, i) => (
              <motion.div
                key={`${tab}-${item.label}`}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, delay: i * 0.04 }}
                className="flex items-center justify-between rounded-xl border border-white/10 bg-[#101522] p-4"
              >
                <div className="flex items-center gap-3">
                  <div className="grid h-9 w-9 place-items-center rounded-lg bg-white/5 text-foreground">
                    <item.icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-semibold text-foreground">{item.label}</span>
                </div>
                <span
                  className={`rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${STATUS_COLOR[item.status]}`}
                >
                  {STATUS_LABEL[item.status]}
                </span>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
