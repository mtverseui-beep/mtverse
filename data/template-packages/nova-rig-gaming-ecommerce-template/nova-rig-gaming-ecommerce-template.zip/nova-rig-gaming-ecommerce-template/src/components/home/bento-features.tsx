"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Wand2,
  Gauge,
  Package,
  Lightbulb,
  Plug,
  ShieldCheck,
  ArrowRight,
  Cpu,
  BatteryCharging,
  Radio,
  Layers,
} from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { TiltCard } from "@/components/motion/tilt-card";
import { PRODUCT_IMAGES } from "@/data/products";

const BENTO = [
  {
    title: "Setup Builder",
    description: "Build a complete gaming or creator setup with compatible gear recommendations.",
    icon: Wand2,
    accent: "#8B5CF6",
    href: "/setup-builder",
    span: "lg:col-span-2 lg:row-span-2",
    image: PRODUCT_IMAGES.setup1,
    visual: "builder",
  },
  {
    title: "Low-Latency Gear",
    description: "8000Hz polling, sub-0.5ms input lag, tri-mode wireless.",
    icon: Gauge,
    accent: "#06B6D4",
    href: "/shop?sort=polling",
    span: "",
    visual: "specs",
  },
  {
    title: "Creator Bundles",
    description: "Mic, cam, lights, and monitor arms in one pre-paired kit.",
    icon: Package,
    accent: "#39FF88",
    href: "/creator-bundles",
    span: "",
    visual: "bundles",
  },
  {
    title: "RGB Control",
    description: "NOVA Sync unifies lighting across every NOVA RIG device.",
    icon: Lightbulb,
    accent: "#FBBF24",
    href: "/rgb-lights",
    span: "lg:col-span-2",
    visual: "rgb",
  },
  {
    title: "Compatibility Guide",
    description: "Match gear with desk size, console, PC, and streaming workflows.",
    icon: Plug,
    accent: "#06B6D4",
    href: "/size-and-compatibility",
    span: "",
    visual: "compat",
  },
  {
    title: "Warranty & Support",
    description: "2–5 year warranty, 30-day returns, real human support.",
    icon: ShieldCheck,
    accent: "#39FF88",
    href: "/warranty",
    span: "",
    visual: "warranty",
  },
];

export function BentoFeatures() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="mb-10 text-center">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">Why NOVA RIG</span>
            <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
              A complete gear system
            </h2>
            <p className="mt-2 max-w-2xl mx-auto text-muted-foreground">
              From setup builder to warranty support — every piece of NOVA RIG gear is designed to work together.
            </p>
          </div>
        </Reveal>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:auto-rows-[220px]">
          {BENTO.map((card, i) => (
            <Reveal key={card.title} delay={i * 0.06} className={card.span}>
              <TiltCard
                className="group relative h-full overflow-hidden rounded-2xl border border-white/10 bg-[#101522] animated-border"
                maxTilt={6}
                scale={1.01}
              >
                <Link href={card.href} className="block h-full w-full p-6">
                  {/* Background visual */}
                  {card.image && (
                    <div
                      className="absolute inset-0 opacity-20 transition-opacity duration-500 group-hover:opacity-30"
                      style={{
                        backgroundImage: `url(${card.image})`,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                      }}
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101522] via-[#101522]/85 to-transparent" />

                  {/* Visual: builder preview */}
                  {card.visual === "builder" && (
                    <div className="absolute top-6 right-6 grid grid-cols-2 gap-1.5">
                      {PRODUCT_IMAGES.keyboard1 && (
                        <>
                          <div className="h-12 w-12 rounded-lg border border-white/10 bg-cover bg-center" style={{ backgroundImage: `url(${PRODUCT_IMAGES.keyboard1})` }} />
                          <div className="h-12 w-12 rounded-lg border border-white/10 bg-cover bg-center" style={{ backgroundImage: `url(${PRODUCT_IMAGES.mouse1})` }} />
                          <div className="h-12 w-12 rounded-lg border border-white/10 bg-cover bg-center" style={{ backgroundImage: `url(${PRODUCT_IMAGES.headset1})` }} />
                          <div className="h-12 w-12 rounded-lg border border-white/10 bg-cover bg-center" style={{ backgroundImage: `url(${PRODUCT_IMAGES.deskmat1})` }} />
                        </>
                      )}
                    </div>
                  )}

                  {/* Visual: specs */}
                  {card.visual === "specs" && (
                    <div className="absolute top-6 right-6 flex flex-col items-end gap-1">
                      <div className="flex items-center gap-1 text-xs font-mono text-secondary">
                        <Cpu className="h-3 w-3" /> 36K DPI
                      </div>
                      <div className="flex items-center gap-1 text-xs font-mono text-accent">
                        <Radio className="h-3 w-3" /> 8000Hz
                      </div>
                      <div className="flex items-center gap-1 text-xs font-mono text-primary">
                        <BatteryCharging className="h-3 w-3" /> 90h
                      </div>
                    </div>
                  )}

                  {/* Visual: bundles */}
                  {card.visual === "bundles" && (
                    <div className="absolute top-6 right-6 grid h-16 w-16 place-items-center rounded-xl bg-accent/20 border border-accent/40">
                      <Package className="h-7 w-7 text-accent" />
                    </div>
                  )}

                  {/* Visual: rgb */}
                  {card.visual === "rgb" && (
                    <div className="absolute inset-x-6 bottom-6 h-2 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full w-full"
                        animate={{ background: ["linear-gradient(90deg,#8B5CF6,#06B6D4,#39FF88,#FBBF24,#8B5CF6)"] }}
                        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                      />
                    </div>
                  )}

                  {/* Visual: compat */}
                  {card.visual === "compat" && (
                    <div className="absolute top-6 right-6 flex flex-col gap-1">
                      {["PC", "Mac", "PS5", "Xbox"].map((p) => (
                        <div key={p} className="rounded-full bg-white/5 border border-white/10 px-2 py-0.5 text-[10px] font-bold text-foreground">
                          {p}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Visual: warranty */}
                  {card.visual === "warranty" && (
                    <div className="absolute top-6 right-6 grid h-16 w-16 place-items-center rounded-xl bg-accent/20 border border-accent/40">
                      <ShieldCheck className="h-7 w-7 text-accent" />
                    </div>
                  )}

                  <div className="relative z-10 flex h-full flex-col justify-end">
                    <div
                      className="mb-3 inline-grid h-10 w-10 place-items-center rounded-lg"
                      style={{ backgroundColor: `${card.accent}20`, color: card.accent }}
                    >
                      <card.icon className="h-5 w-5" />
                    </div>
                    <h3 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">
                      {card.title}
                    </h3>
                    <p className="mt-1 text-sm text-muted-foreground line-clamp-2 max-w-md">
                      {card.description}
                    </p>
                    <div
                      className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider transition-transform group-hover:translate-x-1"
                      style={{ color: card.accent }}
                    >
                      Explore <ArrowRight className="h-3 w-3" />
                    </div>
                  </div>
                </Link>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
