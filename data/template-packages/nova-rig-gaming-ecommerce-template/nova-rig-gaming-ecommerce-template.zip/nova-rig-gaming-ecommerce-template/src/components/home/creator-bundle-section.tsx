"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Star, Package, ArrowRight, BadgePercent } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { SafeImg } from "@/components/common/safe-image";
import { getBestSellers } from "@/data/products";
import { formatPrice, calcDiscount } from "@/lib/utils";

const BUNDLES = [
  {
    slug: "streamvault-creator-bundle",
    name: "StreamVault Creator Bundle",
    tag: "Pro streamer",
    description: "5-piece kit: keyboard, mic, cam, RGB light, and desk pad.",
    image: "https://images.unsplash.com/photo-1542435503-956c469947f6?auto=format&fit=crop&w=1200&q=80",
    price: 649,
    compareAt: 785,
    accent: "#06B6D4",
  },
  {
    slug: "neonrig-starter-bundle",
    name: "NeonRig Starter Bundle",
    tag: "New creator",
    description: "4-piece kit: mic, cam, RGB light, and cable management.",
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=1200&q=80",
    price: 449,
    compareAt: 526,
    accent: "#8B5CF6",
  },
  {
    slug: "zerolag-wireless-kit",
    name: "ZeroLag Wireless Kit",
    tag: "Esports",
    description: "3-piece kit: wireless mouse, keyboard, and headset.",
    image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=1200&q=80",
    price: 299,
    compareAt: 358,
    accent: "#39FF88",
  },
];

export function CreatorBundleSection() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="text-center mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-secondary flex items-center justify-center gap-2">
              <Package className="h-3.5 w-3.5" /> Creator bundles
            </span>
            <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
              Pre-paired kits. Real savings.
            </h2>
            <p className="mt-2 max-w-2xl mx-auto text-muted-foreground">
              Buy a bundle and save up to $136 versus buying each piece separately. Every bundle ships NOVA Sync-ready.
            </p>
          </div>
        </Reveal>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {BUNDLES.map((b, i) => {
            const discount = calcDiscount(b.price, b.compareAt);
            return (
              <Reveal key={b.slug} delay={i * 0.08}>
                <motion.div
                  whileHover={{ y: -4 }}
                  transition={{ type: "spring", stiffness: 300, damping: 25 }}
                  className="group relative flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#101522]"
                >
                  <Link href={`/product/${b.slug}`} className="block">
                    <div className="relative aspect-[16/10] overflow-hidden bg-[#0B0F1A]">
                      <SafeImg
                        src={b.image}
                        alt={b.name}
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        width={500}
                        height={312}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#101522] via-transparent to-transparent" />
                      <div className="absolute left-3 top-3 inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/15 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-accent">
                        <BadgePercent className="h-3 w-3" /> Save {discount}%
                      </div>
                      <div className="absolute right-3 top-3">
                        <span
                          className="rounded-full border px-3 py-1 text-[10px] font-bold uppercase tracking-wider"
                          style={{
                            color: b.accent,
                            borderColor: `${b.accent}66`,
                            backgroundColor: `${b.accent}1A`,
                          }}
                        >
                          {b.tag}
                        </span>
                      </div>
                    </div>
                    <div className="flex-1 p-5">
                      <h3 className="font-display text-xl font-bold uppercase tracking-tight text-foreground">
                        {b.name}
                      </h3>
                      <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{b.description}</p>
                      <div className="mt-4 flex items-baseline gap-2">
                        <span className="text-2xl font-bold text-foreground">{formatPrice(b.price)}</span>
                        <span className="text-sm text-muted-foreground line-through">{formatPrice(b.compareAt)}</span>
                      </div>
                      <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider" style={{ color: b.accent }}>
                        View bundle <ArrowRight className="h-3 w-3" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              </Reveal>
            );
          })}
        </div>

        {/* Best sellers strip */}
        <Reveal delay={0.2}>
          <div className="mt-12 rounded-2xl border border-white/10 bg-[#0B0F1A] p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-xl font-bold uppercase tracking-tight text-foreground flex items-center gap-2">
                <Star className="h-5 w-5 fill-warning text-warning" /> Best-selling gear
              </h3>
              <Link href="/best-sellers" className="text-sm font-semibold text-primary hover:underline">
                View all
              </Link>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {getBestSellers(4).map((p) => (
                <Link
                  key={p.id}
                  href={`/product/${p.slug}`}
                  className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-3 hover:border-primary/30"
                >
                  <SafeImg
                    src={p.images[0]}
                    alt={p.name}
                    className="h-14 w-14 shrink-0 rounded-lg object-cover"
                    width={56}
                    height={56}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold text-foreground line-clamp-1 group-hover:text-primary">
                      {p.name}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                      <Star className="h-3 w-3 fill-warning text-warning" />
                      <span>{p.rating}</span>
                      <span>·</span>
                      <span>{p.reviewCount.toLocaleString()} reviews</span>
                    </div>
                    <div className="mt-1 text-sm font-bold text-primary">{formatPrice(p.price)}</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
