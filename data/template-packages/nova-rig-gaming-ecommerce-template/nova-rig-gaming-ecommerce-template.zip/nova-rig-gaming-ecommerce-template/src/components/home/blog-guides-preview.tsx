"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, BookOpen, Newspaper } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { SafeImg } from "@/components/common/safe-image";
import { BLOG_POSTS, BUYING_GUIDES } from "@/data/content";

export function BlogGuidesPreview() {
  const posts = BLOG_POSTS.slice(0, 2);
  const guides = BUYING_GUIDES.slice(0, 2);

  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Blog */}
          <div>
            <Reveal>
              <div className="mb-6 flex items-end justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
                    <Newspaper className="h-3.5 w-3.5" /> From the blog
                  </span>
                  <h2 className="mt-2 font-display text-2xl font-black uppercase tracking-tight text-foreground sm:text-3xl">
                    Latest from NOVA RIG
                  </h2>
                </div>
                <Link href="/blog" className="text-sm font-semibold text-primary hover:underline">
                  All posts
                </Link>
              </div>
            </Reveal>

            <div className="space-y-3">
              {posts.map((post, i) => (
                <Reveal key={post.slug} delay={i * 0.08}>
                  <Link
                    href={`/blog/${post.slug}`}
                    className="group grid gap-4 rounded-2xl border border-white/10 bg-[#101522] p-4 hover:border-primary/30 transition-colors sm:grid-cols-[160px_1fr]"
                  >
                    <div className="aspect-video overflow-hidden rounded-lg bg-[#0B0F1A] sm:aspect-square">
                      <SafeImg
                        src={post.cover}
                        alt={post.title}
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        width={160}
                        height={160}
                      />
                    </div>
                    <div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-primary">
                        {post.category} · {post.readingTime}
                      </div>
                      <h3 className="mt-1 font-bold text-foreground line-clamp-2 group-hover:text-primary">
                        {post.title}
                      </h3>
                      <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{post.excerpt}</p>
                      <div className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                        Read more <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>

          {/* Buying guides */}
          <div>
            <Reveal>
              <div className="mb-6 flex items-end justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-accent flex items-center gap-2">
                    <BookOpen className="h-3.5 w-3.5" /> Buying guides
                  </span>
                  <h2 className="mt-2 font-display text-2xl font-black uppercase tracking-tight text-foreground sm:text-3xl">
                    Pick the right gear
                  </h2>
                </div>
                <Link href="/buying-guides" className="text-sm font-semibold text-accent hover:underline">
                  All guides
                </Link>
              </div>
            </Reveal>

            <div className="space-y-3">
              {guides.map((g, i) => (
                <Reveal key={g.slug} delay={i * 0.08}>
                  <Link
                    href={`/buying-guides/${g.slug}`}
                    className="group grid gap-4 rounded-2xl border border-white/10 bg-[#101522] p-4 hover:border-accent/30 transition-colors sm:grid-cols-[160px_1fr]"
                  >
                    <div className="aspect-video overflow-hidden rounded-lg bg-[#0B0F1A] sm:aspect-square">
                      <SafeImg
                        src={g.cover}
                        alt={g.title}
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        width={160}
                        height={160}
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="rounded-full bg-accent/15 border border-accent/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
                          {g.difficulty}
                        </span>
                        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                          {g.readingTime}
                        </span>
                      </div>
                      <h3 className="mt-1 font-bold text-foreground line-clamp-2 group-hover:text-accent">
                        {g.title}
                      </h3>
                      <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{g.excerpt}</p>
                      <div className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-accent">
                        Read guide <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
