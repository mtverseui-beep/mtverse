"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Star, Quote, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/motion/reveal";
import { SafeImg } from "@/components/common/safe-image";
import { REVIEWS } from "@/data/content";
import { formatDate } from "@/lib/utils";

export function ReviewsSocialProof() {
  const avg = (REVIEWS.reduce((a, r) => a + r.rating, 0) / REVIEWS.length).toFixed(1);
  const counts = [5, 4, 3, 2, 1].map((s) => ({
    star: s,
    count: REVIEWS.filter((r) => r.rating === s).length,
  }));
  const total = REVIEWS.length;

  return (
    <section className="py-16 sm:py-24 bg-[#0B0F1A] border-y border-white/10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Summary */}
          <Reveal>
            <div className="rounded-2xl border border-white/10 bg-[#101522] p-6">
              <span className="text-xs font-bold uppercase tracking-wider text-warning flex items-center gap-2">
                <Star className="h-3.5 w-3.5 fill-warning" /> Reviews
              </span>
              <div className="mt-4 flex items-baseline gap-3">
                <span className="font-display text-6xl font-black text-foreground">{avg}</span>
                <div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`h-4 w-4 ${s <= Math.round(Number(avg)) ? "fill-warning text-warning" : "text-white/20"}`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">{total.toLocaleString()}+ verified reviews</span>
                </div>
              </div>
              <div className="mt-4 space-y-1.5">
                {counts.map((c) => {
                  const pct = (c.count / total) * 100;
                  return (
                    <div key={c.star} className="flex items-center gap-2 text-xs">
                      <span className="w-3 text-muted-foreground">{c.star}</span>
                      <Star className="h-3 w-3 fill-warning text-warning" />
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/5">
                        <motion.div
                          className="h-full rounded-full bg-warning"
                          initial={{ width: 0 }}
                          whileInView={{ width: `${pct}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.8, delay: 0.1 }}
                        />
                      </div>
                      <span className="w-8 text-right text-muted-foreground">{c.count}</span>
                    </div>
                  );
                })}
              </div>
              <Link
                href="/reviews"
                className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline"
              >
                Read all reviews <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </Reveal>

          {/* Top reviews */}
          <div className="lg:col-span-2">
            <Reveal>
              <div className="grid gap-3 sm:grid-cols-2">
                {REVIEWS.slice(0, 4).map((r, i) => (
                  <motion.article
                    key={r.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.06 }}
                    className="rounded-2xl border border-white/10 bg-[#101522] p-5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <SafeImg
                          src={r.avatar}
                          alt={r.author}
                          className="h-9 w-9 rounded-full object-cover"
                          width={36}
                          height={36}
                        />
                        <div>
                          <div className="text-sm font-semibold text-foreground">{r.author}</div>
                          <div className="text-[10px] uppercase tracking-wider text-accent">
                            Verified buyer
                          </div>
                        </div>
                      </div>
                      <Quote className="h-5 w-5 text-primary/40" />
                    </div>
                    <div className="mt-3 flex">
                      {Array.from({ length: 5 }).map((_, idx) => (
                        <Star
                          key={idx}
                          className={`h-3.5 w-3.5 ${idx < r.rating ? "fill-warning text-warning" : "text-white/20"}`}
                        />
                      ))}
                    </div>
                    <h4 className="mt-2 text-sm font-bold text-foreground">{r.title}</h4>
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-3">{r.body}</p>
                    <div className="mt-3 flex items-center justify-between text-[10px] text-muted-foreground">
                      <Link href={`/product/${r.productSlug}`} className="text-primary hover:underline">
                        {r.productName}
                      </Link>
                      <span>{formatDate(r.date)}</span>
                    </div>
                  </motion.article>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
