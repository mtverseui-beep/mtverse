"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { Flame, Bell, Clock, ArrowRight } from "lucide-react";
import { getActiveDrop } from "@/data/content";
import { getProductBySlug } from "@/data/products";
import { SafeImg } from "@/components/common/safe-image";
import { formatPrice } from "@/lib/utils";
import { toast } from "sonner";

function calcRemaining(target: string) {
  const now = Date.now();
  const targetMs = new Date(target).getTime();
  const diff = Math.max(0, targetMs - now);
  return {
    days: Math.floor(diff / 86400000),
    hours: Math.floor((diff % 86400000) / 3600000),
    minutes: Math.floor((diff % 3600000) / 60000),
    seconds: Math.floor((diff % 60000) / 1000),
    done: diff === 0,
  };
}

export function DropCountdown() {
  const drop = getActiveDrop();
  const product = getProductBySlug(drop.productSlug);
  const [remaining, setRemaining] = useState(() => calcRemaining(drop.date));
  const [email, setEmail] = useState("");

  useEffect(() => {
    const t = setInterval(() => setRemaining(calcRemaining(drop.date)), 1000);
    return () => clearInterval(t);
  }, [drop.date]);

  if (!product) return null;

  const units = [
    { label: "Days", value: remaining.days },
    { label: "Hours", value: remaining.hours },
    { label: "Min", value: remaining.minutes },
    { label: "Sec", value: remaining.seconds },
  ];

  return (
    <section className="relative py-16 sm:py-24 border-y border-white/10 bg-[#0B0F1A]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2 items-center">
          {/* Left visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-warning/30 glow-acid"
          >
            <SafeImg
              src={drop.image}
              alt={drop.title}
              className="h-full w-full object-cover"
              width={600}
              height={450}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F1A] via-transparent to-transparent" />
            <div className="absolute left-4 top-4 inline-flex items-center gap-2 rounded-full bg-warning/20 border border-warning/40 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-warning">
              <Flame className="h-3.5 w-3.5" /> Limited drop
            </div>
            <div className="absolute bottom-4 left-4 right-4">
              <h3 className="text-xl font-bold text-foreground">{drop.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{drop.description}</p>
            </div>
          </motion.div>

          {/* Right content */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <span className="text-xs font-bold uppercase tracking-wider text-warning flex items-center gap-2">
                <Clock className="h-3.5 w-3.5" /> Drop goes live in
              </span>
              <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
                {drop.title}
              </h2>
              <p className="mt-3 text-base text-muted-foreground">
                Only {drop.stock} units produced. When they're gone, they're gone. Join the waitlist to get notified the moment the drop goes live.
              </p>
            </motion.div>

            {/* Countdown */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mt-6 grid grid-cols-4 gap-2"
            >
              {units.map((u) => (
                <div
                  key={u.label}
                  className="rounded-xl border border-white/10 bg-white/[0.02] p-3 text-center"
                >
                  <motion.div
                    key={u.value}
                    initial={{ y: -10, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 200, damping: 20 }}
                    className="font-display text-2xl font-black tabular-nums text-foreground sm:text-3xl"
                  >
                    {String(u.value).padStart(2, "0")}
                  </motion.div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{u.label}</div>
                </div>
              ))}
            </motion.div>

            {/* Price + stock */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-4 flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.02] p-4"
            >
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Drop price</div>
                <div className="text-2xl font-bold text-foreground">{formatPrice(drop.price)}</div>
              </div>
              <div className="text-right">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Stock</div>
                <div className="text-2xl font-bold text-warning">{drop.stock}</div>
              </div>
            </motion.div>

            {/* Waitlist form */}
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              onSubmit={(e) => {
                e.preventDefault();
                if (!email) return;
                toast.success("You're on the waitlist", {
                  description: `We'll email ${email} the moment this drop goes live.`,
                });
                setEmail("");
              }}
              className="mt-4 flex flex-col sm:flex-row gap-2"
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email for early access"
                className="flex-1 rounded-lg border border-white/10 bg-white/5 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-warning px-5 py-3 text-sm font-bold text-black hover:bg-warning/90"
              >
                <Bell className="h-4 w-4" /> Notify me
              </button>
            </motion.form>

            <Link
              href={`/drop-calendar`}
              className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:underline"
            >
              View drop calendar <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
