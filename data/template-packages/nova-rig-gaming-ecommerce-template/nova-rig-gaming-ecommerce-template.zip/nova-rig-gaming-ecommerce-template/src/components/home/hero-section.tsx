"use client";

import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import { useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Wand2, Truck, ShieldCheck, Boxes } from "lucide-react";
import { PRODUCT_IMAGES } from "@/data/products";
import { Magnetic } from "@/components/motion/magnetic";
import { Marquee } from "@/components/motion/marquee";

const springConfig = { stiffness: 100, damping: 30, restDelta: 0.001 };

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.8, ease: [0.25, 0.4, 0.25, 1] as const },
  }),
};

const HERO_BADGES = [
  { label: "New drop live", tone: "accent" },
  { label: "Free shipping over $99", tone: "muted" },
  { label: "Creator bundles available", tone: "muted" },
  { label: "2-year warranty", tone: "muted" },
];

const PARTNER_TERMS = ["8000Hz POLLING", "SUB-0.5MS LATENCY", "TRI-MODE WIRELESS", "HOT-SWAP PCB", "PBT DOUBLE-SHOT", "MAGNESIUM SHELL", "NOVA SYNC", "GAS-STRUT ARMS", "32-BIT FLOAT AUDIO"];

export function HeroSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const rawY = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const y = useSpring(rawY, springConfig);

  const rawTextX1 = useTransform(scrollYProgress, [0, 1], [0, -80]);
  const textX1 = useSpring(rawTextX1, springConfig);
  const rawTextX2 = useTransform(scrollYProgress, [0, 1], [0, 80]);
  const textX2 = useSpring(rawTextX2, springConfig);

  const rawScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.92]);
  const scale = useSpring(rawScale, springConfig);
  const rawOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const opacity = useSpring(rawOpacity, springConfig);

  return (
    <section
      ref={ref}
      className="relative min-h-[92vh] flex items-center overflow-hidden noise-overlay"
      aria-label="Hero"
    >
      {/* Background layers */}
      <div className="absolute inset-0 bg-[#070A12]" />
      <div className="absolute inset-0 grid-bg opacity-50" />
      <div className="absolute inset-0 radial-fade" />

      {/* Floating glow blobs */}
      <motion.div
        className="absolute top-32 left-10 w-72 h-72 rounded-full bg-[#8B5CF6]/25 blur-[100px]"
        animate={{ x: [0, 40, 0], y: [0, -30, 0], scale: [1, 1.15, 1] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-96 h-96 rounded-full bg-[#06B6D4]/20 blur-[120px]"
        animate={{ x: [0, -50, 0], y: [0, 30, 0], scale: [1, 1.1, 1] }}
        transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-[#39FF88]/12 blur-[110px]"
        animate={{ scale: [1, 1.3, 1] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Marquee strip at top */}
      <motion.div
        style={{ opacity }}
        className="absolute top-0 left-0 right-0 border-y border-white/5 py-2"
      >
        <Marquee speed={36}>
          {PARTNER_TERMS.map((t) => (
            <span key={t} className="mx-6 text-xs font-bold tracking-[0.2em] text-muted-foreground uppercase">
              {t}
            </span>
          ))}
        </Marquee>
      </motion.div>

      <motion.div
        style={{ scale, opacity }}
        className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-20 pb-12 w-full"
      >
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
          {/* Left content */}
          <div className="text-center lg:text-left">
            <motion.div
              variants={fadeUp}
              custom={0}
              initial="hidden"
              animate="visible"
              className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-primary"
            >
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
              </span>
              New Acid Edge NovaMouse Air drop
            </motion.div>

            <motion.h1
              variants={fadeUp}
              custom={1}
              initial="hidden"
              animate="visible"
              className="mt-5 font-display text-5xl font-black uppercase tracking-tighter leading-[0.95] sm:text-6xl md:text-7xl lg:text-[5.5rem]"
            >
              <motion.span style={{ x: textX1 }} className="block text-foreground">
                Build your rig.
              </motion.span>
              <motion.span style={{ x: textX2 }} className="block">
                <span className="text-gradient-violet">Own</span>{" "}
                <span className="text-gradient-cyan">the</span>{" "}
                <span className="text-gradient-acid">match.</span>
              </motion.span>
            </motion.h1>

            <motion.p
              variants={fadeUp}
              custom={2}
              initial="hidden"
              animate="visible"
              className="mt-5 mx-auto lg:mx-0 max-w-xl text-base text-muted-foreground sm:text-lg"
            >
              Premium gaming gear, creator desk upgrades, and limited setup drops built for players, streamers, and modern workstations.
            </motion.p>

            {/* CTAs */}
            <motion.div
              variants={fadeUp}
              custom={3}
              initial="hidden"
              animate="visible"
              className="mt-7 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start"
            >
              <Magnetic>
                <Link
                  href="/shop"
                  className="group inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-sm font-bold uppercase tracking-wider text-white shadow-lg shadow-primary/40 hover:bg-primary/90 transition-colors"
                >
                  Shop gear
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Magnetic>
              <Magnetic>
                <Link
                  href="/setup-builder"
                  className="group inline-flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-6 py-3.5 text-sm font-bold uppercase tracking-wider text-foreground hover:bg-white/10 transition-colors"
                >
                  <Wand2 className="h-4 w-4 text-accent" />
                  Build my setup
                </Link>
              </Magnetic>
            </motion.div>

            {/* Hero badges */}
            <motion.div
              variants={fadeUp}
              custom={4}
              initial="hidden"
              animate="visible"
              className="mt-8 flex flex-wrap gap-2 justify-center lg:justify-start"
            >
              {HERO_BADGES.map((b) => (
                <span
                  key={b.label}
                  className={
                    b.tone === "accent"
                      ? "rounded-full border border-accent/40 bg-accent/10 px-3 py-1 text-xs font-semibold text-accent"
                      : "rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-semibold text-muted-foreground"
                  }
                >
                  {b.label}
                </span>
              ))}
            </motion.div>
          </div>

          {/* Right visual */}
          <motion.div
            style={{ y }}
            className="relative"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.4, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <div className="relative aspect-[4/5] sm:aspect-[5/4] lg:aspect-[4/5] rounded-3xl overflow-hidden border border-white/10 glow-violet">
              <Image
                src={PRODUCT_IMAGES.setup1}
                alt="Premium gaming desk setup with NOVA RIG gear"
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-transparent to-transparent" />

              {/* Floating spec card */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1, duration: 0.6 }}
                className="absolute left-4 top-4 bg-[#0B0F1A] rounded-xl p-3 border border-white/10"
              >
                <div className="flex items-center gap-2">
                  <div className="grid h-8 w-8 place-items-center rounded-lg bg-accent/20 text-accent">
                    <Truck className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Ships in</div>
                    <div className="text-sm font-bold text-foreground">1–2 days</div>
                  </div>
                </div>
              </motion.div>

              {/* Floating stat card */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.2, duration: 0.6 }}
                className="absolute right-4 bottom-20 bg-[#0B0F1A] rounded-xl p-3 border border-white/10"
              >
                <div className="flex items-center gap-2">
                  <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary/20 text-primary">
                    <Boxes className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">From the</div>
                    <div className="text-sm font-bold text-foreground">Aim Lab collection</div>
                  </div>
                </div>
              </motion.div>

              {/* Floating warranty card */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.4, duration: 0.6 }}
                className="absolute left-1/2 -translate-x-1/2 bottom-4 bg-[#0B0F1A] rounded-xl px-4 py-2 border border-white/10"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-accent" />
                  <span className="text-xs font-bold text-foreground">2-year warranty</span>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Bottom scroll indicator */}
      <motion.div
        style={{ opacity }}
        className="absolute bottom-4 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center gap-1 text-muted-foreground"
      >
        <span className="text-[10px] uppercase tracking-[0.3em]">Scroll</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="h-8 w-px bg-gradient-to-b from-primary to-transparent"
        />
      </motion.div>
    </section>
  );
}
