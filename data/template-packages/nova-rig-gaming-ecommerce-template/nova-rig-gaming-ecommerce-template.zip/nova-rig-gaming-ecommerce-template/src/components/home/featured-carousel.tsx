"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Sparkles } from "lucide-react";
import { ProductCard } from "@/components/product/product-card";
import { useQuickView } from "@/lib/quick-view-store";
import type { Product } from "@/types";

interface FeaturedGearCarouselProps {
  products: Product[];
  title?: string;
  eyebrow?: string;
}

export function FeaturedGearCarousel({
  products,
  title = "Featured gear",
  eyebrow = "Hand-picked",
}: FeaturedGearCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [direction, setDirection] = useState<"left" | "right">("right");
  const { openQuickView } = useQuickView();

  const scroll = (dir: "left" | "right") => {
    if (!scrollRef.current) return;
    setDirection(dir);
    const amount = scrollRef.current.clientWidth * 0.7;
    scrollRef.current.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  };

  return (
    <section className="py-16 sm:py-24 bg-[#0B0F1A] border-y border-white/10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5" /> {eyebrow}
            </span>
            <h2 className="mt-3 font-display text-3xl font-black uppercase tracking-tight text-foreground sm:text-4xl">
              {title}
            </h2>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => scroll("left")}
              aria-label="Previous"
              className="grid h-11 w-11 place-items-center rounded-full border border-white/10 bg-white/5 text-foreground hover:bg-white/10 transition-colors"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={() => scroll("right")}
              aria-label="Next"
              className="grid h-11 w-11 place-items-center rounded-full border border-white/10 bg-white/5 text-foreground hover:bg-white/10 transition-colors"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory scroll-smooth -mx-4 px-4 lg:mx-0 lg:px-0"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          <style>{`div::-webkit-scrollbar{display:none}`}</style>
          <AnimatePresence initial={false} custom={direction}>
            {products.map((p, i) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: Math.min(i * 0.05, 0.4) }}
                className="shrink-0 w-[260px] sm:w-[300px] snap-start"
              >
                <ProductCard product={p} onQuickView={openQuickView} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
