"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { X, Cookie } from "lucide-react";

const KEY = "nova-rig-cookie-consent";

export function CookieBanner() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(KEY);
      if (!stored) setShow(true);
    } catch {
      // ignore
    }
  }, []);

  const dismiss = (value: "accepted" | "rejected") => {
    try {
      localStorage.setItem(KEY, value);
    } catch {
      // ignore
    }
    setShow(false);
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ type: "spring", stiffness: 200, damping: 25 }}
          className="fixed bottom-4 left-4 right-4 z-40 mx-auto max-w-3xl rounded-2xl bg-[#0B0F1A] border border-white/10 p-4 shadow-2xl md:p-5"
        >
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-3">
              <div className="hidden sm:grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary/15 text-primary">
                <Cookie className="h-5 w-5" />
              </div>
              <p className="text-sm text-foreground">
                We use cookies to power your cart, wishlist, and recently viewed gear. See our{" "}
                <Link href="/cookies" className="text-primary hover:underline">Cookie Policy</Link>.
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <button
                onClick={() => dismiss("rejected")}
                className="rounded-lg border border-white/15 px-3 py-2 text-sm font-semibold text-foreground hover:bg-white/5"
              >
                Decline
              </button>
              <button
                onClick={() => dismiss("accepted")}
                className="rounded-lg bg-primary px-4 py-2 text-sm font-bold text-white hover:bg-primary/90"
              >
                Accept all
              </button>
              <button
                onClick={() => dismiss("rejected")}
                aria-label="Dismiss"
                className="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground hover:bg-white/5"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
