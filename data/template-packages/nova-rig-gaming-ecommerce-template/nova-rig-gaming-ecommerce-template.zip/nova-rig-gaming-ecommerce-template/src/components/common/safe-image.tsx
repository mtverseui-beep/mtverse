"use client";

import { useState, useEffect, type ReactNode } from "react";
import Image, { type ImageProps } from "next/image";

interface SafeImageProps extends Omit<ImageProps, "onError" | "src"> {
  fallbackSrc?: string;
  alt: string;
  src: string;
}

// Inline SVG fallback - shows a stylized NOVA RIG placeholder
const FALLBACK_DATA_URI =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="600" height="400">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#0B0F1A"/>
          <stop offset="100%" stop-color="#151B2E"/>
        </linearGradient>
        <linearGradient id="accent" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#8B5CF6"/>
          <stop offset="100%" stop-color="#06B6D4"/>
        </linearGradient>
      </defs>
      <rect width="600" height="400" fill="url(#bg)"/>
      <g transform="translate(270,170)">
        <path d="M0 0 L30 40 L0 80 Z" fill="url(#accent)"/>
        <path d="M60 0 L30 40 L60 80 Z" fill="url(#accent)" opacity="0.5"/>
        <circle cx="30" cy="40" r="3" fill="#F8FAFC"/>
      </g>
      <text x="300" y="290" text-anchor="middle" font-family="monospace" font-size="14" fill="#94A3B8">NOVA RIG</text>
    </svg>`,
  );

export function SafeImage({
  src,
  fallbackSrc = FALLBACK_DATA_URI,
  alt,
  className,
  ...props
}: SafeImageProps) {
  const [imgSrc, setImgSrc] = useState<string>(src);
  const [errored, setErrored] = useState(false);

  useEffect(() => {
    setImgSrc(src);
    setErrored(false);
  }, [src]);

  return (
    <Image
      src={errored ? fallbackSrc : imgSrc}
      alt={alt}
      className={className}
      onError={() => {
        if (!errored) setErrored(true);
      }}
      unoptimized
      {...props}
    />
  );
}

interface SafeImgProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackSrc?: string;
  src?: string;
}

export function SafeImg({
  src,
  fallbackSrc = FALLBACK_DATA_URI,
  alt,
  className,
  ...props
}: SafeImgProps) {
  const [imgSrc, setImgSrc] = useState<string>(src ?? FALLBACK_DATA_URI);
  const [errored, setErrored] = useState(false);

  useEffect(() => {
    if (src) {
      setImgSrc(src);
      setErrored(false);
    }
  }, [src]);

  return (
     
    <img
      src={errored ? fallbackSrc : imgSrc}
      alt={alt ?? ""}
      className={className}
      onError={() => {
        if (!errored) setErrored(true);
      }}
      {...props}
    />
  );
}

export function Fallback({ children }: { children?: ReactNode }) {
  return (
    <div className="flex items-center justify-center bg-gradient-to-br from-[#0B0F1A] to-[#151B2E] text-muted-foreground">
      {children ?? "NOVA RIG"}
    </div>
  );
}

