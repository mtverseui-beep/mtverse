// Centralized navigation data for NOVA RIG

export interface NavChild {
  label: string;
  href: string;
  description?: string;
  icon?: string;
  badge?: string;
}

export interface NavItem {
  label: string;
  href: string;
  children?: NavChild[];
}

export const PRIMARY_NAV: NavItem[] = [
  {
    label: "Shop",
    href: "/shop",
    children: [
      {
        label: "Shop by Gear",
        href: "/shop",
        description: "Browse all gaming gear categories",
        icon: "LayoutGrid",
      },
      { label: "Keyboards", href: "/keyboards", icon: "Keyboard", description: "Mechanical keyboards with hot-swap PCBs" },
      { label: "Mice", href: "/mice", icon: "MousePointer2", description: "Lightweight wireless gaming mice" },
      { label: "Headsets", href: "/headsets", icon: "Headphones", description: "Spatial 3D audio headsets" },
      { label: "Desk Mats", href: "/desk-mats", icon: "RectangleHorizontal", description: "XXL desk pads and mousepads" },
      { label: "RGB Lights", href: "/rgb-lights", icon: "Lightbulb", description: "Addressable RGB lighting bars" },
      { label: "Microphones", href: "/microphones", icon: "Mic", description: "USB-C and XLR streaming mics" },
      { label: "Webcams", href: "/webcams", icon: "Camera", description: "4K webcams with AI autofocus" },
      { label: "Monitor Arms", href: "/monitor-arms", icon: "MonitorDot", description: "Gas-strut monitor mounts" },
      { label: "Controller Docks", href: "/controller-docks", icon: "Gamepad2", description: "Universal controller stands" },
    ],
  },
  {
    label: "Setups",
    href: "/collections",
    children: [
      { label: "All Collections", href: "/collections", icon: "LayoutGrid", description: "Curated gear collections" },
      { label: "Setup Builder", href: "/setup-builder", icon: "Wand2", description: "Build a complete setup", badge: "Tool" },
      { label: "Bundle Builder", href: "/bundle-builder", icon: "Package", description: "Build a custom bundle", badge: "Tool" },
      { label: "Setup Gallery", href: "/setup-gallery", icon: "Images", description: "Real NOVA RIG setups" },
      { label: "Creators", href: "/creators", icon: "Users", description: "Featured NOVA RIG creators" },
    ],
  },
  {
    label: "Drops",
    href: "/limited-drops",
    children: [
      { label: "Limited Drops", href: "/limited-drops", icon: "Flame", description: "Limited-run colorways" },
      { label: "Drop Calendar", href: "/drop-calendar", icon: "Calendar", description: "Upcoming gear drops" },
      { label: "New Arrivals", href: "/new-arrivals", icon: "Sparkles", description: "Latest gear" },
      { label: "Best Sellers", href: "/best-sellers", icon: "TrendingUp", description: "Most popular gear" },
      { label: "Sale", href: "/sale", icon: "BadgePercent", description: "On sale now" },
    ],
  },
  {
    label: "Bundles",
    href: "/creator-bundles",
    children: [
      { label: "Creator Bundles", href: "/creator-bundles", icon: "Package", description: "Streaming and creator kits" },
      { label: "Esports Kits", href: "/esports-kits", icon: "Trophy", description: "Tournament-ready kits" },
      { label: "Gift Cards", href: "/gift-cards", icon: "Gift", description: "Digital gift cards" },
      { label: "Rewards", href: "/rewards", icon: "Award", description: "Earn and redeem points" },
    ],
  },
  {
    label: "Guides",
    href: "/blog",
    children: [
      { label: "Blog", href: "/blog", icon: "Newspaper", description: "Latest from NOVA RIG" },
      { label: "Buying Guides", href: "/buying-guides", icon: "BookOpen", description: "In-depth gear guides" },
      { label: "Reviews", href: "/reviews", icon: "Star", description: "Verified buyer reviews" },
      { label: "About", href: "/about", icon: "Info", description: "Our story" },
    ],
  },
  {
    label: "Support",
    href: "/help",
    children: [
      { label: "Help Center", href: "/help", icon: "LifeBuoy", description: "Find answers fast" },
      { label: "Track Order", href: "/track-order", icon: "Truck", description: "Track your shipment" },
      { label: "Shipping Policy", href: "/shipping-policy", icon: "Package", description: "Shipping times and rates" },
      { label: "Returns", href: "/returns-policy", icon: "RotateCcw", description: "30-day return policy" },
      { label: "Warranty", href: "/warranty", icon: "ShieldCheck", description: "2-5 year warranty" },
      { label: "Contact", href: "/contact", icon: "Mail", description: "Get in touch" },
      { label: "FAQ", href: "/faq", icon: "HelpCircle", description: "Frequently asked questions" },
    ],
  },
];

export const MOBILE_NAV = [
  ...PRIMARY_NAV,
  { label: "Account", href: "/account" },
  { label: "Sign In", href: "/sign-in" },
];

export const FOOTER_LINKS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Shop",
    links: [
      { label: "All Products", href: "/shop" },
      { label: "Keyboards", href: "/keyboards" },
      { label: "Mice", href: "/mice" },
      { label: "Headsets", href: "/headsets" },
      { label: "Desk Mats", href: "/desk-mats" },
      { label: "RGB Lights", href: "/rgb-lights" },
      { label: "Microphones", href: "/microphones" },
      { label: "Webcams", href: "/webcams" },
      { label: "Monitor Arms", href: "/monitor-arms" },
      { label: "Controller Docks", href: "/controller-docks" },
      { label: "Chairs", href: "/chairs" },
      { label: "Cable Management", href: "/cable-management" },
    ],
  },
  {
    title: "Setups",
    links: [
      { label: "All Collections", href: "/collections" },
      { label: "Setup Builder", href: "/setup-builder" },
      { label: "Bundle Builder", href: "/bundle-builder" },
      { label: "Setup Gallery", href: "/setup-gallery" },
      { label: "Creators", href: "/creators" },
      { label: "Reviews", href: "/reviews" },
      { label: "New Arrivals", href: "/new-arrivals" },
      { label: "Best Sellers", href: "/best-sellers" },
      { label: "Limited Drops", href: "/limited-drops" },
      { label: "Sale", href: "/sale" },
    ],
  },
  {
    title: "Account",
    links: [
      { label: "Sign In", href: "/sign-in" },
      { label: "Sign Up", href: "/sign-up" },
      { label: "My Account", href: "/account" },
      { label: "Orders", href: "/account/orders" },
      { label: "Wishlist", href: "/wishlist" },
      { label: "Compare", href: "/compare" },
      { label: "Track Order", href: "/track-order" },
      { label: "Gift Cards", href: "/gift-cards" },
      { label: "Rewards", href: "/rewards" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Help Center", href: "/help" },
      { label: "Shipping", href: "/help/shipping" },
      { label: "Returns", href: "/help/returns" },
      { label: "Orders", href: "/help/orders" },
      { label: "Payments", href: "/help/payments" },
      { label: "Warranty", href: "/help/warranty" },
      { label: "Contact Us", href: "/contact" },
      { label: "FAQ", href: "/faq" },
      { label: "Size & Compatibility", href: "/size-and-compatibility" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Our Story", href: "/our-story" },
      { label: "Blog", href: "/blog" },
      { label: "Buying Guides", href: "/buying-guides" },
      { label: "Stockists", href: "/stockists" },
      { label: "Careers", href: "/coming-soon" },
      { label: "Press", href: "/coming-soon" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "Cookie Policy", href: "/cookies" },
      { label: "Accessibility", href: "/accessibility" },
      { label: "Refund Policy", href: "/refund-policy" },
      { label: "Returns Policy", href: "/returns-policy" },
      { label: "Shipping Policy", href: "/shipping-policy" },
      { label: "Warranty", href: "/warranty" },
    ],
  },
];
