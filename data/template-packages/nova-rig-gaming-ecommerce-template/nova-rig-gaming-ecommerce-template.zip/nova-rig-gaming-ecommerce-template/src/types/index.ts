// NOVA RIG — Shared ecommerce types

export type ProductCategory =
  | "keyboards"
  | "mice"
  | "headsets"
  | "desk-mats"
  | "rgb-lights"
  | "microphones"
  | "webcams"
  | "monitor-arms"
  | "controller-docks"
  | "chairs"
  | "cable-management"
  | "creator-bundles"
  | "esports-kits";

export type CollectionSlug =
  | "aim-lab-essentials"
  | "streamer-desk-kit"
  | "rgb-night-setup"
  | "minimal-blackout"
  | "esports-travel-kit"
  | "creator-starter-pack"
  | "wireless-control"
  | "desk-upgrade-series"
  | "limited-neon-drop"
  | "pro-setup-bundle";

export type Badge = "new" | "best-seller" | "limited" | "sale" | "preorder" | "restock" | "exclusive";

export interface ProductColor {
  name: string;
  hex: string;
}

export interface ProductVariant {
  id: string;
  label: string;
  value: string;
}

export interface ProductSpec {
  label: string;
  value: string;
}

export interface ProductFeature {
  title: string;
  description: string;
  icon: string; // lucide icon name
}

export interface Review {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  title: string;
  body: string;
  verified: boolean;
  helpful: number;
}

export interface QAItem {
  id: string;
  question: string;
  answer: string;
  author: string;
  date: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: ProductCategory;
  categoryLabel: string;
  collection: CollectionSlug;
  collectionLabel: string;
  price: number;
  compareAtPrice?: number;
  currency: string;
  images: string[];
  gallery: string[];
  badge?: Badge;
  rating: number;
  reviewCount: number;
  stock: number;
  lowStockThreshold?: number;
  colors: ProductColor[];
  variants: ProductVariant[];
  compatibility: string[];
  dimensions?: string;
  weight?: string;
  specs: ProductSpec[];
  features: ProductFeature[];
  inTheBox: string[];
  warranty: string;
  shipping: string;
  shortDescription: string;
  description: string;
  relatedSlugs: string[];
  bundleSlugs: string[];
  reviews?: Review[];
  qa?: QAItem[];
  setupType?: string[];
  tags?: string[];
}

export interface Collection {
  slug: CollectionSlug;
  name: string;
  tagline: string;
  description: string;
  heroImage: string;
  coverImage: string;
  productSlugs: string[];
  accentColor: string;
}

export interface Category {
  slug: ProductCategory;
  name: string;
  tagline: string;
  description: string;
  heroImage: string;
  icon: string;
}

export interface SetupGalleryItem {
  slug: string;
  title: string;
  type: "gaming" | "streaming" | "creator" | "minimal" | "rgb" | "wireless";
  image: string;
  thumbnail: string;
  description: string;
  gearSlugs: string[];
  creator: string;
  tags: string[];
  notes: string;
}

export interface Creator {
  slug: string;
  name: string;
  handle: string;
  avatar: string;
  cover: string;
  role: string;
  bio: string;
  setupType: string;
  bundleSlug?: string;
  socials: { label: string; href: string; icon: string }[];
  gearSlugs: string[];
  followers: string;
  location: string;
}

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  category: "guides" | "news" | "stories" | "tech";
  author: string;
  authorAvatar: string;
  date: string;
  readingTime: string;
  cover: string;
  tags: string[];
  content: { heading?: string; body: string }[];
  relatedProductSlugs?: string[];
  relatedPostSlugs?: string[];
}

export interface BuyingGuide {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  cover: string;
  readingTime: string;
  updated: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  content: { heading?: string; body: string }[];
  relatedProductSlugs: string[];
}

export interface DropEvent {
  id: string;
  slug: string;
  title: string;
  productSlug: string;
  description: string;
  date: string;
  image: string;
  price: number;
  stock: number;
  status: "upcoming" | "live" | "ended";
}

export interface CartItem {
  id: string;
  productSlug: string;
  name: string;
  image: string;
  price: number;
  quantity: number;
  variant?: string;
  color?: string;
}

export interface WishItem {
  productSlug: string;
  addedAt: number;
}

export interface CompareItem {
  productSlug: string;
  addedAt: number;
}

export interface Address {
  id: string;
  label: string;
  fullName: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  phone?: string;
  isDefault?: boolean;
}

export interface Order {
  id: string;
  date: string;
  status: "processing" | "shipped" | "delivered" | "cancelled" | "failed";
  items: CartItem[];
  total: number;
  subtotal: number;
  shipping: number;
  tax: number;
  shippingAddress: Address;
  estimatedDelivery: string;
  trackingNumber?: string;
  paymentMethod: string;
}

export interface ReviewItem {
  id: string;
  productSlug: string;
  productName: string;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  title: string;
  body: string;
  verified: boolean;
  helpful: number;
  images?: string[];
}
