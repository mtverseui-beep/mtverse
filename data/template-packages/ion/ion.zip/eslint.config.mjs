import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";

/**
 * ESLint config — Ion template.
 *
 * Per spec §10.1: ESLint uses sane defaults (eslint-config-next + typescript-eslint
 * recommended). No blanket-disabling of no-explicit-any, no-unused-vars, no-undef,
 * exhaustive-deps, or no-console. If a specific line genuinely needs an exception,
 * use a scoped inline disable comment with a reason.
 */
const eslintConfig = [
  // Ignore generated/build/scaffold dirs
  {
    ignores: [
      "node_modules/**",
      ".next/**",
      "out/**",
      "build/**",
      "next-env.d.ts",
      "scripts/**",
      "tests/**",
      "mini-services/**",
      "public/**",
    ],
  },
  ...nextCoreWebVitals,
  ...nextTypescript,
];

export default eslintConfig;
