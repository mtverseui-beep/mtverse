import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Output standalone build for production deployment.
  output: "standalone",

  // Per Ion template spec §10.1 — do NOT silence safety nets.
  // reactStrictMode: true surfaces potential issues in dev.
  // ignoreBuildErrors: false (default) — TypeScript and ESLint errors fail the build.
  reactStrictMode: true,

  images: {
    // Allow SVG images via next/image. Safe because all SVGs are self-hosted
    // under /public — no user-uploaded SVGs are ever rendered.
    dangerouslyAllowSVG: true,
    // Use 'inline' (not 'attachment') so browsers actually render SVG images
    // instead of trying to download them.
    contentDispositionType: "inline",
    // Minimal CSP — no scripts, allow inline styles for SVG <style> blocks.
    contentSecurityPolicy: "default-src 'self'; style-src 'unsafe-inline';",
  },
};

export default nextConfig;
