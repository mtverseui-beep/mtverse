// convert-pngs.mjs — converts SVG assets to PNG using sharp (already installed).
// Run: node /home/z/my-project/scripts/convert-pngs.mjs

import sharp from "sharp";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = "/home/z/my-project/public";

async function svgToPng(svgPath, pngPath, width, height) {
  const svg = readFileSync(join(ROOT, svgPath));
  await sharp(svg, { density: 144 })
    .resize(width, height, { fit: "cover" })
    .png()
    .toFile(join(ROOT, pngPath));
  console.log("✓", pngPath);
}

// Apple touch icon: 180×180 PNG
await svgToPng("apple-touch-icon.svg", "apple-touch-icon.png", 180, 180);

// OG image: 1200×630 PNG
await svgToPng("og-image.svg", "og-image.png", 1200, 630);

// Favicon as PNG fallback (modern browsers handle SVG; this is for older ones)
await svgToPng("apple-touch-icon.svg", "icon.png", 32, 32);

// Generate a small favicon.ico by wrapping the 32px PNG.
// Note: real .ico generation requires a dedicated lib; we ship icon.svg + icon.png
// which covers all modern browsers. If you need a true .ico for legacy IE,
// run `npx real-favicon generate` and replace the file.

console.log("\n✅ PNG conversions complete.");
