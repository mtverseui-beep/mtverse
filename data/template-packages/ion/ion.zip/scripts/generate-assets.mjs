// generate-assets.mjs — generates all self-hosted placeholder SVG/PNG assets for Ion.
// Run: node /home/z/my-project/scripts/generate-assets.mjs
//
// Why SVG: tiny, theme-aware (currentColor), infinitely scalable, no licensing risk.
// All assets are deliberately generic "placeholder brand-style" — buyers swap them.

import { mkdirSync, writeFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";

const ROOT = "/home/z/my-project/public";
const ensure = (p) => mkdirSync(p, { recursive: true });

function write(path, content) {
  ensure(dirname(path));
  writeFileSync(path, content, "utf8");
  console.log("✓", path);
}

/* ─────────────────── BRAND LOGO ─────────────────── */

function logoSvg() {
  // Favicon: solid lime background + dark mark — visible in any browser tab
  // regardless of light/dark tab bar. Does NOT use currentColor.
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" fill="none">
  <rect width="28" height="28" rx="7" fill="#C6FF3D"/>
  <path d="M9 8.5C9 7.67 9.67 7 10.5 7H17.5C18.33 7 19 7.67 19 8.5V19.5C19 20.33 18.33 21 17.5 21H10.5C9.67 21 9 20.33 9 19.5V8.5Z" fill="#0B0C10" opacity="0.18"/>
  <path d="M11 11H17M11 14H17M11 17H15" stroke="#0B0C10" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="19" cy="9" r="2.5" fill="#0B0C10"/>
</svg>`;
}
write(join(ROOT, "icon.svg"), logoSvg());

/* ─────────────────── COMPANY LOGOS (logo cloud) ─────────────────── */
/* NOTE: SVGs loaded via <img> are isolated documents — currentColor and
   CSS variables from the page DON'T apply. Use explicit hex colors that
   read well on both light (#FAFAF8) and dark (#0B0C10) backgrounds.
   #6B7280 (medium gray) hits ~4.5:1 on both. */

const companies = [
  { name: "Vertex", shape: "triangle" },
  { name: "Northwind", shape: "wave" },
  { name: "Lumen", shape: "circle" },
  { name: "Quanta", shape: "hex" },
  { name: "Helio", shape: "sun" },
  { name: "Cobalt", shape: "square" },
  { name: "Forge", shape: "anvil" },
  { name: "Aperture", shape: "aperture" },
];

const LOGO_COLOR = "#6B7280"; // works on both light and dark backgrounds
const LOGO_KNOCKOUT = "#FAFAF8"; // for holes/cutouts (matches light bg; on dark it reads as a subtle highlight)

function companyLogo(name, shape) {
  let mark = "";
  switch (shape) {
    case "triangle":
      mark = `<path d="M12 4L20 18H4L12 4Z" fill="${LOGO_COLOR}"/>`;
      break;
    case "wave":
      mark = `<path d="M2 14C5 11 7 11 10 14C13 17 15 17 18 14C19.5 12.5 20.5 12 22 12" stroke="${LOGO_COLOR}" stroke-width="2.5" stroke-linecap="round" fill="none"/>`;
      break;
    case "circle":
      mark = `<circle cx="12" cy="12" r="8" fill="${LOGO_COLOR}"/><circle cx="12" cy="12" r="3.5" fill="${LOGO_KNOCKOUT}"/>`;
      break;
    case "hex":
      mark = `<path d="M12 3L20 7.5V16.5L12 21L4 16.5V7.5L12 3Z" stroke="${LOGO_COLOR}" stroke-width="2" fill="none" stroke-linejoin="round"/>`;
      break;
    case "sun":
      mark = `<circle cx="12" cy="12" r="4" fill="${LOGO_COLOR}"/><g stroke="${LOGO_COLOR}" stroke-width="2" stroke-linecap="round"><path d="M12 2V4"/><path d="M12 20V22"/><path d="M2 12H4"/><path d="M20 12H22"/><path d="M4.93 4.93L6.34 6.34"/><path d="M17.66 17.66L19.07 19.07"/><path d="M4.93 19.07L6.34 17.66"/><path d="M17.66 6.34L19.07 4.93"/></g>`;
      break;
    case "square":
      mark = `<rect x="4" y="4" width="16" height="16" rx="3" fill="${LOGO_COLOR}"/><rect x="9" y="9" width="6" height="6" rx="1" fill="${LOGO_KNOCKOUT}"/>`;
      break;
    case "anvil":
      mark = `<path d="M3 9H17V13C17 16 14.5 18 12 18H10C7 18 5 16 5 14V13H3V9Z" fill="${LOGO_COLOR}"/><rect x="3" y="18" width="14" height="3" rx="1" fill="${LOGO_COLOR}"/>`;
      break;
    case "aperture":
      mark = `<circle cx="12" cy="12" r="9" stroke="${LOGO_COLOR}" stroke-width="2" fill="none"/><path d="M12 3L15 9M21 12L15 11M12 21L9 15M3 12L9 13M5 5L11 9M19 5L13 9" stroke="${LOGO_COLOR}" stroke-width="1.5" stroke-linecap="round"/>`;
      break;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="120" height="32" fill="none">
  <g transform="translate(0, 4)">${mark}</g>
  <text x="32" y="20" font-family="ui-sans-serif, system-ui, -apple-system, sans-serif" font-size="14" font-weight="600" fill="${LOGO_COLOR}">${name}</text>
</svg>`;
}

for (const { name, shape } of companies) {
  write(join(ROOT, "logos", `${name.toLowerCase()}.svg`), companyLogo(name, shape));
}

/* ─────────────────── AVATARS (initials on gradient) ─────────────────── */

const avatarPeople = [
  // hero stacked avatars
  { file: "a1.svg", initials: "MO", c1: "#C6FF3D", c2: "#84CC16" },
  { file: "a2.svg", initials: "DP", c1: "#FF8A3D", c2: "#F97316" },
  { file: "a3.svg", initials: "SL", c1: "#60A5FA", c2: "#3B82F6" },
  { file: "a4.svg", initials: "MR", c1: "#F472B6", c2: "#EC4899" },
  { file: "a5.svg", initials: "PA", c1: "#A78BFA", c2: "#8B5CF6" },
  // testimonial avatars
  { file: "t1.svg", initials: "MO", c1: "#C6FF3D", c2: "#65A30D" },
  { file: "t2.svg", initials: "DP", c1: "#FF8A3D", c2: "#C2410C" },
  { file: "t3.svg", initials: "SL", c1: "#60A5FA", c2: "#1D4ED8" },
  { file: "t4.svg", initials: "MR", c1: "#F472B6", c2: "#BE185D" },
  { file: "t5.svg", initials: "PA", c1: "#A78BFA", c2: "#6D28D9" },
  { file: "t6.svg", initials: "JW", c1: "#34D399", c2: "#047857" },
  { file: "t7.svg", initials: "AT", c1: "#FBBF24", c2: "#B45309" },
  { file: "t8.svg", initials: "CM", c1: "#22D3EE", c2: "#0E7490" },
];

function avatarSvg(initials, c1, c2) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="64" height="64" rx="32" fill="url(#g)"/>
  <text x="32" y="32" text-anchor="middle" dominant-baseline="central" font-family="ui-sans-serif, system-ui, sans-serif" font-size="22" font-weight="600" fill="#0B0C10">${initials}</text>
</svg>`;
}

for (const p of avatarPeople) {
  write(join(ROOT, "avatars", p.file), avatarSvg(p.initials, p.c1, p.c2));
}

/* ─────────────────── INTEGRATION ICONS (placeholder brand-style) ─────────────────── */
/* NOTE: SVGs loaded via <img> are isolated documents — currentColor and
   CSS variables DON'T apply. All colors must be explicit hex. */

const integrations = [
  { name: "slack", glyph: "<rect x='6' y='6' width='4' height='4' rx='1' fill='#E01E5A'/><rect x='14' y='6' width='4' height='4' rx='1' fill='#36C5F0'/><rect x='6' y='14' width='4' height='4' rx='1' fill='#2EB67D'/><rect x='14' y='14' width='4' height='4' rx='1' fill='#ECB22E'/>" },
  { name: "github", glyph: "<path d='M12 2C6.48 2 2 6.58 2 12.25c0 4.5 2.87 8.32 6.84 9.67.5.1.68-.22.68-.49v-1.7c-2.78.62-3.37-1.36-3.37-1.36-.45-1.18-1.11-1.5-1.11-1.5-.91-.64.07-.62.07-.62 1 .07 1.53 1.06 1.53 1.06.9 1.57 2.34 1.12 2.91.86.09-.67.35-1.12.63-1.38-2.22-.26-4.55-1.14-4.55-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.71 0 0 .84-.27 2.75 1.05A9.36 9.36 0 0 1 12 6.84c.85 0 1.71.12 2.51.35 1.91-1.32 2.75-1.05 2.75-1.05.55 1.41.2 2.45.1 2.71.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.81-4.57 5.06.36.32.68.94.68 1.9v2.82c0 .27.18.6.69.49A10.26 10.26 0 0 0 22 12.25C22 6.58 17.52 2 12 2Z' fill='#181717'/>" },
  { name: "notion", glyph: "<rect x='4' y='4' width='16' height='16' rx='2' fill='#FFFFFF' stroke='#181717' stroke-width='1'/><path d='M7 8h5l5 8M7 8v8m5-8v8' stroke='#181717' stroke-width='1.5' stroke-linecap='round' fill='none'/>" },
  { name: "linear", glyph: "<path d='M3 12L12 3l9 9-9 9-9-9Z' fill='#5E6AD2'/><path d='M7 12l5-5 5 5-5 5-5-5Z' fill='#FFFFFF'/>" },
  { name: "figma", glyph: "<circle cx='9' cy='8' r='3' fill='#F24E1E'/><circle cx='9' cy='16' r='3' fill='#1ABCFE'/><rect x='12' y='5' width='6' height='6' rx='3' fill='#FF7262'/><rect x='12' y='13' width='6' height='6' rx='3' fill='#A259FF'/>" },
  { name: "zapier", glyph: "<path d='M12 2L13 11L22 12L13 13L12 22L11 13L2 12L11 11L12 2Z' fill='#FF4F00'/>" },
  { name: "postgres", glyph: "<ellipse cx='12' cy='12' rx='8' ry='9' fill='none' stroke='#336791' stroke-width='1.5'/><path d='M8 9c1 2 4 3 6 2M9 14c2 1 5 0 6-2' stroke='#336791' stroke-width='1.2' fill='none' stroke-linecap='round'/>" },
  { name: "s3", glyph: "<path d='M5 7l7-3 7 3v10l-7 3-7-3V7Z' fill='none' stroke='#FF9900' stroke-width='1.5' stroke-linejoin='round'/><path d='M5 7l7 3 7-3M12 10v10' stroke='#FF9900' stroke-width='1.2' fill='none'/>" },
  { name: "stripe", glyph: "<path d='M14 7c-3 0-5 1-5 3 0 4 7 2 7 5 0 1.5-1.5 2-4 2-1.5 0-3-.5-3.5-1' stroke='#635BFF' stroke-width='2' fill='none' stroke-linecap='round'/>" },
  { name: "vercel", glyph: "<path d='M12 4L22 20H2L12 4Z' fill='#181717'/>" },
  { name: "openai", glyph: "<circle cx='12' cy='12' r='8' fill='none' stroke='#10A37F' stroke-width='1.5'/><path d='M12 8v8M8 12h8M9.5 9.5l5 5M9.5 14.5l5-5' stroke='#10A37F' stroke-width='1' stroke-linecap='round'/>" },
  { name: "anthropic", glyph: "<path d='M7 4l5 16 5-16M9 9h6' stroke='#D97757' stroke-width='2' fill='none' stroke-linecap='round' stroke-linejoin='round'/>" },
];

function integrationSvg(glyph) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
  <rect width="24" height="24" rx="6" fill="#FFFFFF" stroke="#E5E7EB" stroke-width="1"/>
  ${glyph}
</svg>`;
}

for (const i of integrations) {
  write(join(ROOT, "integrations", `${i.name}.svg`), integrationSvg(i.glyph));
}

/* ─────────────────── PRODUCT MOCKUPS (browser-chrome-framed) ─────────────────── */

function browserChrome(content, w = 1200, h = 750) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0B0C10"/>
      <stop offset="100%" stop-color="#1A1D24"/>
    </linearGradient>
    <linearGradient id="accent" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#C6FF3D"/>
      <stop offset="100%" stop-color="#FF8A3D"/>
    </linearGradient>
  </defs>
  <rect width="${w}" height="${h}" fill="url(#bg)"/>
  <!-- browser chrome -->
  <rect x="0" y="0" width="${w}" height="36" fill="#000" opacity="0.4"/>
  <circle cx="20" cy="18" r="5" fill="#FF5F57"/>
  <circle cx="40" cy="18" r="5" fill="#FEBC2E"/>
  <circle cx="60" cy="18" r="5" fill="#28C840"/>
  <rect x="100" y="9" width="${w - 200}" height="18" rx="9" fill="#fff" opacity="0.06"/>
  <text x="120" y="22" font-family="ui-sans-serif, system-ui, sans-serif" font-size="10" fill="#888">ion.app/workspace</text>
  ${content}
</svg>`;
}

// 1. Workspace mockup — three-pane app (W=1200, H=750)
const workspaceContent = `
  <!-- sidebar -->
  <rect x="0" y="36" width="200" height="714" fill="#000" opacity="0.3"/>
  <rect x="16" y="56" width="32" height="32" rx="8" fill="url(#accent)"/>
  <text x="56" y="76" font-family="sans-serif" font-size="13" font-weight="600" fill="#fff">Ion</text>
  ${["Inbox", "Drafts", "Automations", "Insights", "Docs", "Settings"].map((label, i) => `
    <rect x="16" y="${110 + i * 36}" width="168" height="28" rx="6" fill="${i === 0 ? "#C6FF3D" : "transparent"}" opacity="${i === 0 ? 0.1 : 1}"/>
    <text x="28" y="${128 + i * 36}" font-family="sans-serif" font-size="11" fill="${i === 0 ? "#C6FF3D" : "#888"}">${label}</text>
  `).join("")}
  <!-- main -->
  <text x="240" y="80" font-family="sans-serif" font-size="22" font-weight="600" fill="#fff">Inbox</text>
  <text x="240" y="100" font-family="sans-serif" font-size="11" fill="#666">12 threads · 3 waiting on you</text>
  ${[0, 1, 2, 3, 4].map(i => `
    <rect x="240" y="${130 + i * 80}" width="920" height="68" rx="10" fill="#fff" opacity="0.04"/>
    <circle cx="${270}" cy="${164 + i * 80}" r="14" fill="${["#C6FF3D", "#FF8A3D", "#60A5FA", "#F472B6", "#A78BFA"][i]}"/>
    <text x="296" y="${158 + i * 80}" font-family="sans-serif" font-size="12" font-weight="600" fill="#fff">${["Maya Okafor", "Dev Patel", "Sara Lindqvist", "Marcus Reyes", "Priya Anand"][i]}</text>
    <text x="296" y="${174 + i * 80}" font-family="sans-serif" font-size="10" fill="#999">Re: launch readiness — Ion drafted a response</text>
    <rect x="1070" y="${158 + i * 80}" width="60" height="14" rx="7" fill="#C6FF3D" opacity="0.15"/>
    <text x="1100" y="${168 + i * 80}" font-family="sans-serif" font-size="9" fill="#C6FF3D" text-anchor="middle">AI</text>
  `).join("")}
`;
write(join(ROOT, "products", "workspace.svg"), browserChrome(workspaceContent));

// 2. Automations mockup — visual flow
const automationsContent = `
  <text x="240" y="80" font-family="sans-serif" font-size="22" font-weight="600" fill="#fff">Automations</text>
  <text x="240" y="100" font-family="sans-serif" font-size="11" fill="#666">When PR merged → notify → close ticket → update dashboard</text>
  ${[
    { x: 280, y: 200, label: "GitHub", sub: "PR merged", c: "#fff" },
    { x: 540, y: 200, label: "Filter", sub: "is main branch", c: "#C6FF3D" },
    { x: 800, y: 200, label: "Slack", sub: "#launches", c: "#FF8A3D" },
    { x: 540, y: 400, label: "Linear", sub: "close ticket", c: "#60A5FA" },
    { x: 800, y: 400, label: "Dashboard", sub: "increment", c: "#A78BFA" },
  ].map(n => `
    <rect x="${n.x}" y="${n.y}" width="180" height="80" rx="12" fill="#fff" opacity="0.06" stroke="${n.c}" stroke-width="1.5"/>
    <text x="${n.x + 20}" y="${n.y + 32}" font-family="sans-serif" font-size="13" font-weight="600" fill="#fff">${n.label}</text>
    <text x="${n.x + 20}" y="${n.y + 52}" font-family="sans-serif" font-size="10" fill="#999">${n.sub}</text>
  `).join("")}
  <!-- connectors -->
  <path d="M460 240 L540 240" stroke="#444" stroke-width="2" stroke-dasharray="4 4"/>
  <path d="M720 240 L800 240" stroke="#444" stroke-width="2" stroke-dasharray="4 4"/>
  <path d="M630 280 L630 400" stroke="#444" stroke-width="2" stroke-dasharray="4 4"/>
  <path d="M720 440 L800 440" stroke="#444" stroke-width="2" stroke-dasharray="4 4"/>
`;
write(join(ROOT, "products", "automations.svg"), browserChrome(automationsContent));

// 3. Insights mockup — dashboard with charts
const insightsContent = `
  <text x="240" y="80" font-family="sans-serif" font-size="22" font-weight="600" fill="#fff">Insights</text>
  <text x="240" y="100" font-family="sans-serif" font-size="11" fill="#666">Last 30 days · auto-refreshed 4 min ago</text>
  ${[
    { x: 240, label: "Cycle time", value: "2.4d", delta: "-18%" },
    { x: 460, label: "Throughput", value: "47", delta: "+12%" },
    { x: 680, label: "Stuck work", value: "3", delta: "-50%" },
    { x: 900, label: "AI handled", value: "184", delta: "+32%" },
  ].map(s => `
    <rect x="${s.x}" y="130" width="200" height="100" rx="12" fill="#fff" opacity="0.04"/>
    <text x="${s.x + 20}" y="160" font-family="sans-serif" font-size="10" fill="#888">${s.label}</text>
    <text x="${s.x + 20}" y="195" font-family="sans-serif" font-size="26" font-weight="600" fill="#fff">${s.value}</text>
    <text x="${s.x + 20}" y="215" font-family="sans-serif" font-size="11" fill="#C6FF3D">${s.delta} vs last period</text>
  `).join("")}
  <!-- line chart -->
  <rect x="240" y="260" width="920" height="220" rx="12" fill="#fff" opacity="0.04"/>
  <text x="260" y="290" font-family="sans-serif" font-size="13" font-weight="600" fill="#fff">Cycle time trend</text>
  <path d="M 260 440 Q 350 420 400 410 T 540 380 T 680 350 T 820 340 T 960 320 T 1080 310" stroke="url(#accent)" stroke-width="3" fill="none" stroke-linecap="round"/>
  <path d="M 260 440 Q 350 420 400 410 T 540 380 T 680 350 T 820 340 T 960 320 T 1080 310 L 1080 470 L 260 470 Z" fill="url(#accent)" opacity="0.1"/>
  <!-- bar chart -->
  <rect x="240" y="500" width="920" height="200" rx="12" fill="#fff" opacity="0.04"/>
  <text x="260" y="530" font-family="sans-serif" font-size="13" font-weight="600" fill="#fff">Throughput by day</text>
  ${Array.from({ length: 14 }).map((_, i) => {
    const h = 40 + Math.round(Math.abs(Math.sin(i * 0.7)) * 100);
    return `<rect x="${260 + i * 60}" y="${680 - h}" width="40" height="${h}" rx="4" fill="${i % 7 === 6 ? "#FF8A3D" : "#C6FF3D"}" opacity="${0.5 + (i / 14) * 0.5}"/>`;
  }).join("")}
`;
write(join(ROOT, "products", "insights.svg"), browserChrome(insightsContent));

/* ─────────────────── OG IMAGE (1200×630) ─────────────────── */

const og = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630" width="1200" height="630">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0B0C10"/>
      <stop offset="100%" stop-color="#1A1D24"/>
    </linearGradient>
    <radialGradient id="glow" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0%" stop-color="#C6FF3D" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="#C6FF3D" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="accent" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#C6FF3D"/>
      <stop offset="100%" stop-color="#FF8A3D"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="630" fill="url(#bg)"/>
  <ellipse cx="600" cy="200" rx="600" ry="300" fill="url(#glow)"/>
  <!-- logo -->
  <rect x="100" y="80" width="48" height="48" rx="12" fill="url(#accent)"/>
  <text x="100" y="160" font-family="ui-sans-serif, system-ui, sans-serif" font-size="20" font-weight="600" fill="#fff">Ion</text>
  <!-- headline -->
  <text x="100" y="320" font-family="ui-sans-serif, system-ui, sans-serif" font-size="76" font-weight="700" fill="#fff" letter-spacing="-2">Stop wrestling tools.</text>
  <text x="100" y="400" font-family="ui-sans-serif, system-ui, sans-serif" font-size="76" font-weight="700" fill="url(#accent)" letter-spacing="-2">Start shipping outcomes.</text>
  <!-- subhead -->
  <text x="100" y="470" font-family="ui-sans-serif, system-ui, sans-serif" font-size="24" fill="#888">The AI workspace that unifies your tools, automates the busywork, and</text>
  <text x="100" y="500" font-family="ui-sans-serif, system-ui, sans-serif" font-size="24" fill="#888">surfaces what matters — so your team ships faster without the noise.</text>
  <!-- social proof -->
  <circle cx="120" cy="565" r="20" fill="#C6FF3D"/>
  <circle cx="148" cy="565" r="20" fill="#FF8A3D"/>
  <circle cx="176" cy="565" r="20" fill="#60A5FA"/>
  <text x="220" y="572" font-family="ui-sans-serif, system-ui, sans-serif" font-size="20" fill="#aaa">Trusted by 4,000+ teams</text>
</svg>`;
write(join(ROOT, "og-image.svg"), og);

// Apple touch icon (180×180) — solid lime with brand mark
const appleIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 180" width="180" height="180">
  <rect width="180" height="180" rx="40" fill="#C6FF3D"/>
  <path d="M55 65C55 58 60 52 67 52H113C120 52 125 58 125 65V115C125 122 120 128 113 128H67C60 128 55 122 55 115V65Z" fill="#0B0C10" opacity="0.18"/>
  <path d="M70 80H110M70 95H110M70 110H100" stroke="#0B0C10" stroke-width="6" stroke-linecap="round"/>
  <circle cx="125" cy="65" r="10" fill="#0B0C10"/>
</svg>`;
write(join(ROOT, "apple-touch-icon.svg"), appleIcon);

console.log("\n✅ All assets generated.");
