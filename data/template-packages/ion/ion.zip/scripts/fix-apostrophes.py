#!/usr/bin/env python3
"""Fix unescaped apostrophes in JSX text content.
Replaces ' with &apos; only when it appears as JSX text (between > and <),
NOT inside JS string literals or attribute values.
"""
import re
import sys
from pathlib import Path

# Files to process (from lint errors)
FILES = [
    "src/app/changelog/page.tsx",
    "src/app/not-found.tsx",
    "src/app/pricing/page.tsx",
    "src/components/sections/contact-form.tsx",
    "src/components/sections/feature-grid.tsx",
    "src/components/sections/hero.tsx",
    "src/components/sections/how-it-works.tsx",
    "src/components/sections/pricing.tsx",
    "src/components/sections/problem-solution.tsx",
    "src/components/sections/testimonials.tsx",
    "src/app/contact/page.tsx",
]

ROOT = Path("/home/z/my-project")

def fix_apostrophes_in_jsx_text(content: str) -> str:
    """Replace ' with &apos; in JSX text content (between > and <)."""
    # Match: >...text with apostrophes...<
    # The text between > and < that contains apostrophes
    # We need to be careful not to match inside {expressions}
    def replace_in_text(match):
        text = match.group(1)
        # Don't touch content inside curly braces
        # Just replace apostrophes that are in plain text
        return ">" + text.replace("'", "&apos;") + "<"
    
    # Match text between > and < that's not inside {}
    # This regex captures text that has an apostrophe and isn't wrapped in braces
    # Pattern: > followed by text containing ' followed by <
    # But we need to handle multi-line and {expressions}
    
    # Simpler approach: process line by line, only fix apostrophes that appear
    # after a > and before a < on the same line, and aren't inside {}
    lines = content.split("\n")
    fixed_lines = []
    for line in lines:
        # Find JSX text segments (between > and <)
        # Skip lines that are pure JS (no JSX)
        if ">" not in line or "<" not in line:
            fixed_lines.append(line)
            continue
        
        # Find all text segments between > and <
        def replace_segment(m):
            text = m.group(1)
            # Skip if it contains { (likely an expression)
            if "{" in text or "}" in text:
                return m.group(0)
            # Skip if no apostrophe
            if "'" not in text:
                return m.group(0)
            return ">" + text.replace("'", "&apos;") + "<"
        
        # Match >text< where text doesn't contain > or <
        new_line = re.sub(r'>([^<>]*)<', replace_segment, line)
        fixed_lines.append(new_line)
    
    return "\n".join(fixed_lines)

for rel_path in FILES:
    path = ROOT / rel_path
    if not path.exists():
        print(f"  skip (not found): {rel_path}")
        continue
    original = path.read_text()
    fixed = fix_apostrophes_in_jsx_text(original)
    if fixed != original:
        path.write_text(fixed)
        # Count changes
        changes = original.count("'") - fixed.count("'")
        print(f"  fixed {rel_path}: {changes} apostrophe(s) escaped")
    else:
        print(f"  no change: {rel_path}")

print("\nDone.")
