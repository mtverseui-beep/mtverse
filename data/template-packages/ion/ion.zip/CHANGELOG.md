# Changelog

All notable changes to the Ion template will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-08-01

### Added

- Initial release of the Ion premium AI-SaaS landing page template.
- One long-scroll landing page with 14 sections: hero (with animated product mockup and demo dialog), logo cloud marquee, problem→solution with animated stat counters, asymmetric bento feature grid (with real embedded interactivity — live recharts chart, toggle, code snippet, search), how-it-works with scroll-progress line, product showcase with Radix Tabs and crossfade, hero testimonial + marquee of shorter testimonials, 3-tier pricing with animated monthly/yearly toggle and tooltips, comparison table, integrations grid, Radix FAQ accordion, final CTA banner, multi-column footer with newsletter form.
- Four supporting routes: `/pricing`, `/changelog`, `/contact` (with real validated form + API route), custom `404`.
- Dark-mode-primary design system with fully designed light mode. Accent palette: electric lime `#C6FF3D` + deep amber `#FF8A3D`.
- Glassmorphism, ambient glow, and subtle grain noise overlay per 2026 premium visual language.
- Full accessibility: semantic HTML, keyboard navigation, focus traps, visible focus rings, ARIA labels, form labels and error associations, `prefers-reduced-motion` support, WCAG AA color contrast in both modes.
- Full SEO: metadata, Open Graph, Twitter card, JSON-LD `SoftwareApplication` schema, sitemap, robots, webmanifest, favicon set, real 1200×630 OG image.
- Easy customization layer: `src/config/site.ts`, `src/config/content.ts`, `src/config/theme.ts` — all copy and data as typed arrays.
- Self-hosted assets: Geist Sans + Mono via `next/font`, all images as SVG placeholders under `/public`.
- Real contact form backend: zod validation, idle/loading/success/error states, documented integration points for Resend / Formspree / Prisma DB.
- No-flash theme toggle via blocking inline script + `next-themes`.
- Smoke tests for every route (render-smoke-tests).
- GitHub Actions CI workflow: lint + typecheck + build + tests on push.
- README with "Customize in 10 minutes" guide, LICENSE (single + unlimited tiers), .env.example, this CHANGELOG.

### Technical

- Next.js 16.1.3 (App Router, Turbopack).
- TypeScript 5 with `strict: true` and no weakening overrides.
- Tailwind CSS 4 with CSS variables for all design tokens.
- Framer Motion 12 for all animations (scroll-reveal, hover, page transitions).
- Radix UI primitives via shadcn/ui conventions.
- `eslint .` passes with default `eslint-config-next` + typescript-eslint recommended rules.
- `npx tsc --noEmit` passes with zero errors.
- Every dependency in `package.json` is imported and used somewhere in `src/`.

[1.0.0]: https://github.com/your-org/ion-template/releases/tag/v1.0.0
