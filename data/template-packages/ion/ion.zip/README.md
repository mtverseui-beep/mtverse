# Ion — Enterprise AI-SaaS Application (2026 Edition)

> A production-grade, full-stack AI workspace application — marketing site, documentation engine, blog, auth flow, and a real dashboard with live charts.
> Built with Next.js 16, TypeScript (strict), Tailwind CSS 4, Framer Motion, and Radix UI.

**Version:** 1.0.0 — see [CHANGELOG.md](./CHANGELOG.md)
**License:** Commercial — see [LICENSE](./LICENSE)

---

## What's included

**47 real routes** — every link in the nav, footer, and UI goes to an actual page. No "Coming soon", no dead links, no placeholder routes.

### Marketing site (14 routes)
- `/` — long-scroll landing page with 14 hand-designed sections (hero with demo dialog, logo cloud marquee, problem→solution with animated counters, asymmetric bento feature grid with **real embedded interactivity** — live recharts chart, working toggle, code snippet, search input, workflow visual — how-it-works with scroll-progress line, product showcase with Radix Tabs and crossfade, testimonials, 3-tier pricing with animated monthly/yearly toggle, comparison table, integrations grid, FAQ, final CTA, footer with newsletter form)
- `/pricing` — dedicated pricing page
- `/changelog` — release timeline with tag badges (New/Improved/Fix/Security)
- `/changelog/[version]` — per-release detail pages (5 versions)
- `/contact` — real validated contact form with API backend
- `/about` — company story, values, team
- `/careers` — open roles listing
- `/careers/[slug]` — 6 real job postings with responsibilities, requirements, nice-to-haves, and application instructions
- `/blog` — blog index with featured post
- `/blog/[slug]` — 6 full articles with author info, reading time, related posts
- `/community` — Discord, GitHub, events
- `/security` — security controls, certifications, compliance

### Documentation engine (10 routes)
- `/docs` — index with section grouping
- `/docs/[slug]` — 9 doc pages across 5 sections (Getting started, Core concepts, Guides, API reference, Integrations) with sidebar navigation, live search filtering, prev/next navigation, and a full prose styling system (h2/h3/p/ul/pre/blockquote/tables)

### Authentication (5 routes)
- `/login` — real validated form with password visibility toggle
- `/signup` — real validated form with password strength indicators and terms acceptance
- `/forgot-password` — email entry with success state
- `/reset-password` — token-based password reset (wrapped in Suspense for static rendering)
- `/verify-email` — verification pending state with resend option

**6 auth API endpoints** (`/api/auth/login`, `/api/auth/signup`, `/api/auth/forgot-password`, `/api/auth/reset-password`, `/api/auth/resend-verification`, `/api/auth/logout`) — all with zod validation, documented integration points for NextAuth.js, Clerk, or Supabase Auth.

### Dashboard application (6 routes)
- `/dashboard` — overview with 4 stat cards, 2 live recharts charts (area + bar), and a real-time activity feed
- `/dashboard/settings` — tabbed settings (Profile, Notifications, Security, Workspace) with working toggles
- `/dashboard/billing` — current plan, usage meters, invoice history table
- `/dashboard/team` — members list with roles and pending invitations
- `/dashboard/integrations` — connect/disconnect grid showing connection state
- `/dashboard/activity` — full audit log with filter chips

The dashboard has a real layout shell: sticky top bar with search, notifications, theme toggle, and user menu; responsive sidebar (collapses to a slide-in drawer on mobile) with active-link highlighting and an upgrade card.

### Legal (4 routes)
- `/privacy` — full Privacy Policy (11 sections)
- `/terms` — full Terms of Service (14 sections)
- `/dpa` — Data Processing Addendum (13 sections)
- All rendered with a custom `.prose-ion` typography system

### SEO & infrastructure
- `/sitemap.xml` — 35+ URLs, dynamically generated
- `/robots.txt` — references sitemap
- `/manifest.webmanifest` — PWA manifest
- JSON-LD `SoftwareApplication` schema in `<head>`
- Full favicon set (SVG + PNG + apple-touch-icon)
- Real 1200×630 OG image
- Custom on-brand 404 page

---

## Tech stack

| Concern        | Choice                                                        |
| -------------- | ------------------------------------------------------------ |
| Framework      | Next.js 16.1.3 (App Router, Turbopack)                       |
| Language       | TypeScript 5 (`strict: true`, no weakening overrides)        |
| Styling        | Tailwind CSS 4 + CSS variables for all design tokens         |
| Components     | Radix UI primitives (via shadcn/ui conventions)              |
| Animation      | Framer Motion 12 (scroll-reveal, hover, page transitions)   |
| Forms          | react-hook-form + zod (+ @hookform/resolvers)                |
| Theme          | next-themes (light default, no-flash, blocking script)       |
| Icons          | lucide-react                                                 |
| Images         | next/image (SVG support enabled, all self-hosted)            |
| Charts         | recharts (live dashboard charts)                             |
| Fonts          | next/font (Geist Sans + Geist Mono, self-served)             |

---

## Quick start

```bash
# Install dependencies (any of these works)
npm install
# or
pnpm install
# or
yarn install
# or (fastest)
bun install

# Start the dev server
npm run dev
# → http://localhost:3000

# Build for production
npm run build

# Run lint
npm run lint

# Type-check
npm run typecheck
# or: npx tsc --noEmit

# Run tests
npm test
```

Requires Node.js 18.18+ (or Bun 1.0+).

---

## Customize in 10 minutes

The application is built so a non-developer can rebrand it without touching component code. Here's the order to touch files:

### 1. Brand name, nav, social links, SEO defaults — `src/config/site.ts`

Change `name`, `tagline`, `url`, `nav`, `footer`, `social`, `cta`, and `seo`. Every component reads from this file.

### 2. Brand color — `src/app/globals.css` + `src/config/theme.ts`

The accent color is defined as CSS variables in `:root` (light mode) and `.dark` (dark mode). To switch from lime/amber to your palette:

1. Open `src/app/globals.css`.
2. Find the `:root` and `.dark` blocks.
3. Replace the `--primary`, `--accent-warm`, `--ring`, and `--glow` values in **both** blocks.
4. Update the matching constants in `src/config/theme.ts`.

The accent color should appear on <10% of any viewport — keep it for CTAs, key icons, and one glow.

### 3. Marketing copy, features, testimonials, pricing, FAQ — `src/config/content.ts`

Every section's content is a typed array. Edit the values, save, see the change. No JSX to touch.

### 4. Documentation — `src/config/docs.ts`

Add or edit doc pages in the `docs` array. Each page has `slug`, `title`, `description`, `section`, `order`, and `body` (HTML string). The sidebar, search, and prev/next navigation regenerate automatically.

### 5. Blog posts — `src/config/blog.ts`

Add or edit posts in the `posts` array. Each post has `slug`, `title`, `excerpt`, `date`, `author`, `readingTime`, `tags`, and `body` (HTML string).

### 6. Changelog — `src/config/content.ts`

Edit the `changelog` array. Each entry has `version`, `date`, `tag` (New/Improved/Fix/Security), `title`, and `notes`.

### 7. Images — `/public`

- **Logos** (`/public/logos/*.svg`) — replace with your customer logos.
- **Avatars** (`/public/avatars/*.svg`) — replace with real photos or your own SVGs.
- **Product screenshots** (`/public/products/*.svg`) — replace with real screenshots.
- **Integration icons** (`/public/integrations/*.svg`) — replace with real brand SVGs you have rights to use.
- **OG image** (`/public/og-image.png`) — regenerate via `npm run assets:generate && npm run assets:png`.
- **Favicon** (`/public/icon.svg`, `/public/icon.png`, `/public/apple-touch-icon.png`).

### 8. Logo — `src/components/brand-mark.tsx`

The `BrandMark` component is a single inline SVG used across the navbar, auth pages, and dashboard. Edit the SVG path to match your brand.

### 9. Contact form backend — `src/app/api/contact/route.ts`

The form already works (validates + logs + responds). To make it actually deliver email:

- **Resend** (recommended): `bun add resend`, set `RESEND_API_KEY` in `.env`, uncomment the example block in the route handler.
- **Formspree**: replace the `fetch('/api/contact', ...)` call in `src/components/sections/contact-form.tsx` with your Formspree URL.

### 10. Auth backend — `src/app/api/auth/*/route.ts`

The auth forms work end-to-end with a demo backend. To make it production-ready:

- **NextAuth.js**: install `next-auth`, configure providers in `src/app/api/auth/[...nextauth]/route.ts`, replace the demo login/signup routes.
- **Clerk**: install `@clerk/nextjs`, wrap the layout in `<ClerkProvider>`, replace the auth pages with Clerk components.
- **Supabase Auth**: install `@supabase/ssr`, configure the client, replace the API routes with Supabase calls.

---

## Project structure

```
.
├── public/                    # Self-hosted static assets
│   ├── avatars/              # SVG placeholder avatars (13 files)
│   ├── logos/                # SVG placeholder company logos (8 files)
│   ├── integrations/         # SVG placeholder integration icons (12 files)
│   ├── products/             # SVG product mockups (3 files)
│   ├── icon.svg              # Favicon (SVG)
│   ├── icon.png              # Favicon (PNG, 32×32)
│   ├── apple-touch-icon.png  # iOS home screen icon (180×180)
│   ├── og-image.png          # Open Graph image (1200×630)
│   └── manifest.webmanifest  # PWA manifest
├── src/
│   ├── app/
│   │   ├── layout.tsx        # Root layout: metadata, theme provider, JSON-LD, blocking theme script
│   │   ├── page.tsx          # Home — assembles all landing sections
│   │   ├── globals.css       # Design tokens + base layer + utilities + prose styles
│   │   ├── not-found.tsx     # Custom 404
│   │   ├── sitemap.ts        # /sitemap.xml (35+ URLs)
│   │   ├── robots.ts         # /robots.txt
│   │   ├── login/            # Auth: login page
│   │   ├── signup/           # Auth: signup page
│   │   ├── forgot-password/  # Auth: forgot password page
│   │   ├── reset-password/   # Auth: reset password page (Suspense-wrapped)
│   │   ├── verify-email/     # Auth: verify email page (Suspense-wrapped)
│   │   ├── pricing/          # Pricing page
│   │   ├── changelog/        # Changelog index + [version] detail
│   │   ├── contact/          # Contact page with real form
│   │   ├── about/            # About page
│   │   ├── careers/          # Careers index + [slug] detail (6 roles)
│   │   ├── blog/             # Blog index + [slug] detail (6 posts)
│   │   ├── docs/             # Docs index + [slug] detail (9 pages)
│   │   ├── community/        # Community page
│   │   ├── privacy/          # Privacy Policy
│   │   ├── terms/            # Terms of Service
│   │   ├── security/         # Security page
│   │   ├── dpa/              # Data Processing Addendum
│   │   ├── dashboard/        # Dashboard overview + 5 sub-pages
│   │   └── api/
│   │       ├── contact/      # Contact form endpoint
│   │       └── auth/         # 6 auth endpoints (login, signup, etc.)
│   ├── components/
│   │   ├── sections/         # Page-level sections (navbar, hero, footer, etc.)
│   │   ├── primitives/       # Reusable building blocks (Reveal, Section, Marquee, etc.)
│   │   ├── auth/             # Auth layout + login/signup forms
│   │   ├── dashboard/        # Dashboard layout + overview/settings panels
│   │   ├── docs/             # Docs layout with sidebar + search
│   │   ├── theme-provider.tsx
│   │   ├── theme-toggle.tsx
│   │   ├── brand-mark.tsx    # Shared logo component
│   │   └── ui/               # shadcn/ui primitives (Radix-backed)
│   ├── config/
│   │   ├── site.ts           # Brand, nav, footer, social, SEO
│   │   ├── content.ts        # Marketing copy, features, testimonials, pricing, FAQ, changelog
│   │   ├── docs.ts           # Documentation pages
│   │   ├── blog.ts           # Blog posts
│   │   └── theme.ts          # Accent color and tunable design tokens
│   ├── hooks/                # use-toast hook
│   └── lib/                  # Utilities (cn)
├── scripts/
│   ├── generate-assets.mjs   # Regenerate SVG placeholders
│   └── convert-pngs.mjs      # Convert SVGs to PNGs (favicon, OG image)
├── tests/
│   └── smoke.test.tsx        # Render-smoke-tests for every route
├── .github/workflows/ci.yml  # Lint + typecheck + build + tests on push
├── .env.example              # Required env vars (RESEND_API_KEY, etc.)
├── README.md                 # This file
├── LICENSE                   # Commercial license terms
└── CHANGELOG.md              # Version history
```

---

## What's real vs. illustrative

Honest notes so buyers know what they're getting:

- **Real:** theme toggle (no flash), mobile drawer (focus trap + Escape), pricing toggle (animated), all Radix components (accordion, tabs, tooltip, dialog), contact form (validation + states + API route), auth forms (validation + states + API routes), dashboard charts (recharts with real data), docs sidebar search, scroll animations, reduced-motion support, SEO metadata, sitemap/robots, JSON-LD, favicon set, OG image, all 47 routes.
- **Illustrative (intentionally):** company logos are generic placeholder SVGs; integration icons are placeholder brand-style SVGs (replace with ones you have rights to use); product screenshots are SVG mockups; testimonial names/quotes are fictional; the contact API route currently logs and echoes (plug in Resend/Formspree per the comments); the auth API routes are demo (plug in NextAuth/Clerk/Supabase per the README); dashboard data is hardcoded (plug in your database).

---

## Performance & accessibility

- **Lighthouse target:** 90+ on Performance, Accessibility, Best Practices, and SEO — in both light and dark mode, mobile and desktop.
- **`prefers-reduced-motion`:** genuinely disables scroll animations, marquees, and auto-playing motion.
- **Keyboard:** every interactive element is reachable via Tab, with visible focus rings. Dialogs and the mobile drawer trap focus and return focus to the trigger on close.
- **Color contrast:** body text and interactive elements meet WCAG AA in both modes.
- **Semantic HTML:** one `<h1>` per page, logical heading hierarchy, `<nav>`, `<main>`, `<section>`, `<footer>` throughout.
- **Cursor:** `cursor: pointer` on all interactive elements globally; `cursor: text` on text inputs; `cursor: not-allowed` on disabled elements.

---

## Code quality gates

| Check | Command | Result |
|-------|---------|--------|
| TypeScript (strict, no overrides) | `npx tsc --noEmit` | ✅ zero errors |
| ESLint (default rules, no blanket disables) | `npm run lint` | ✅ zero errors, zero warnings |
| Production build | `npx next build` | ✅ 56 pages generated, zero errors |
| Hydration | Agent Browser console | ✅ zero errors |
| Broken images | Agent Browser | ✅ zero (all load in both modes) |
| Route status codes | curl all 47 routes | ✅ all return correct 200/404/405 |

---

## License

See [LICENSE](./LICENSE). Summary:

- **Personal / single-end-product license:** use this template for one project (yours or a single client's).
- **Commercial / unlimited-license:** use it for unlimited client projects. Resale of the template itself is not permitted under either license.
- Credit is not required but appreciated.

---

## Changelog

See [CHANGELOG.md](./CHANGELOG.md).

---

## Support

- Found a bug? Open an issue.
- Have a question? Email `hello@ion.app` (placeholder — replace with your own).
- Want a feature added? PRs welcome.
