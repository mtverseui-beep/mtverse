import type { Metadata } from "next";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How Ion collects, uses, and protects your data.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12">
          <Eyebrow>Legal</Eyebrow>
          <h1 className="display-2 mt-4 text-balance">Privacy Policy</h1>
          <p className="mt-2 text-sm text-muted-foreground">Last updated: August 1, 2026</p>

          <article className="prose-ion mt-10 max-w-3xl">
            <h2>1. Overview</h2>
            <p>
              Ion (&ldquo;we&rdquo;, &ldquo;us&rdquo;, &ldquo;our&rdquo;) operates the Ion AI workspace
              and related services (the &ldquo;Service&rdquo;). This Privacy Policy explains how we
              collect, use, and protect your data when you use the Service.
            </p>
            <p>
              We take privacy seriously. We never train foundation models on your data, we minimize
              what we collect, and we give you control over your information.
            </p>

            <h2>2. Data we collect</h2>
            <h3>2.1 Data you provide</h3>
            <ul>
              <li><strong>Account information:</strong> name, email address, company name.</li>
              <li><strong>Workspace content:</strong> documents, tickets, messages, and other content you create or upload.</li>
              <li><strong>Integration data:</strong> data synced from connected third-party services (Slack, GitHub, Linear, etc.).</li>
              <li><strong>Communications:</strong> emails and support requests you send us.</li>
            </ul>
            <h3>2.2 Data collected automatically</h3>
            <ul>
              <li><strong>Usage data:</strong> pages visited, features used, time spent, IP address, browser type.</li>
              <li><strong>Device data:</strong> device type, operating system, unique device identifiers.</li>
              <li><strong>Cookies and similar technologies:</strong> for authentication, preferences, and analytics.</li>
            </ul>

            <h2>3. How we use your data</h2>
            <ul>
              <li>To provide, operate, and maintain the Service.</li>
              <li>To improve the Service — including training <em>workspace-specific</em> retrieval models (never foundation models).</li>
              <li>To communicate with you about your account, updates, and security.</li>
              <li>To detect, prevent, and address technical issues, fraud, and abuse.</li>
              <li>To comply with legal obligations.</li>
            </ul>

            <h2>4. Data sharing</h2>
            <p>We do <strong>not</strong> sell your data. We share it only in these circumstances:</p>
            <ul>
              <li><strong>Service providers:</strong> sub-processors who help us operate (hosting, email, analytics). List available at /security.</li>
              <li><strong>Legal compliance:</strong> when required by law, court order, or to protect our rights and safety.</li>
              <li><strong>Business transfers:</strong> in connection with a merger, acquisition, or asset sale — with notice to you.</li>
            </ul>

            <h2>5. Data retention</h2>
            <p>We retain your data for as long as your account is active. After account deletion:</p>
            <ul>
              <li><strong>Workspace content:</strong> deleted within 30 days.</li>
              <li><strong>Backups:</strong> purged within 90 days.</li>
              <li><strong>Usage logs:</strong> aggregated and anonymized after 13 months.</li>
              <li><strong>Legal holds:</strong> retained only if required by law.</li>
            </ul>

            <h2>6. Your rights</h2>
            <p>Depending on your jurisdiction (GDPR, CCPA, etc.), you have the right to:</p>
            <ul>
              <li>Access the data we hold about you.</li>
              <li>Correct inaccurate data.</li>
              <li>Delete your data (right to erasure).</li>
              <li>Export your data in a portable format.</li>
              <li>Object to or restrict certain processing.</li>
              <li>Withdraw consent at any time.</li>
            </ul>
            <p>To exercise these rights, email <a href="mailto:privacy@ion.app">privacy@ion.app</a>. We respond within 30 days.</p>

            <h2>7. Security</h2>
            <p>We protect your data with industry-standard measures:</p>
            <ul>
              <li>AES-256 encryption at rest, TLS 1.3 in transit.</li>
              <li>SOC 2 Type II certified. Report available under NDA.</li>
              <li>Regular penetration testing by independent firms.</li>
              <li>Strict access controls — engineers don&apos;t have default access to customer data.</li>
            </ul>
            <p>See our <a href="/security">Security page</a> for full details.</p>

            <h2>8. International transfers</h2>
            <p>
              Your data may be processed in countries other than your own. We use Standard Contractual
              Clauses and other appropriate safeguards for cross-border transfers. Enterprise customers
              can choose data residency in US, EU, or APAC regions.
            </p>

            <h2>9. Children&apos;s privacy</h2>
            <p>The Service is not directed to children under 16. We do not knowingly collect data from children. If you believe we have, please contact us immediately.</p>

            <h2>10. Changes to this policy</h2>
            <p>
              We may update this policy from time to time. We&apos;ll notify you of material changes
              by email and post a notice in the app at least 30 days before they take effect.
            </p>

            <h2>11. Contact</h2>
            <p>
              Questions about privacy? Email <a href="mailto:privacy@ion.app">privacy@ion.app</a> or
              write to us at: Ion Inc., 548 Market St, San Francisco, CA 94104.
            </p>
          </article>
        </Container>
      </main>
      <Footer />
    </>
  );
}
