"use client";

import * as React from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2, ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AuthLayout } from "@/components/auth/auth-layout";
import { NoiseOverlay } from "@/components/primitives/glow";
import { useToast } from "@/hooks/use-toast";

/**
 * ResetPasswordPage — wraps the form in a <Suspense> boundary so that
 * useSearchParams() works during static prerendering (Next.js requirement).
 */
export default function ResetPasswordPage() {
  return (
    <React.Suspense fallback={null}>
      <ResetPasswordContent />
    </React.Suspense>
  );
}

function ResetPasswordContent() {
  const router = useRouter();
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const token = searchParams.get("token") ?? "";

  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [status, setStatus] = React.useState<"idle" | "loading" | "done" | "error">("idle");
  const [error, setError] = React.useState("");

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords don't match.");
      return;
    }
    setError("");
    setStatus("loading");
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      if (!res.ok) throw new Error("Reset failed");
      setStatus("done");
      toast({
        title: "Password updated",
        description: "You can now log in with your new password.",
      });
      setTimeout(() => router.push("/login"), 1500);
    } catch {
      setError("Reset failed. The link may have expired — request a new one.");
      setStatus("error");
    }
  };

  if (!token) {
    return (
      <>
        <NoiseOverlay />
        <AuthLayout title="Invalid link" subtitle="This reset link is missing or invalid.">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              The reset link you followed is missing a token. Please request a new password reset.
            </p>
            <Button asChild className="mt-4" size="sm">
              <a href="/forgot-password">Request new link</a>
            </Button>
          </div>
        </AuthLayout>
      </>
    );
  }

  return (
    <>
      <NoiseOverlay />
      <AuthLayout title="Set a new password" subtitle="Choose a strong password for your account.">
        {status === "done" ? (
          <div className="text-center">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-success/15 text-success">
              <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
            </div>
            <h2 className="mt-4 text-lg font-semibold text-foreground">Password updated</h2>
            <p className="mt-2 text-sm text-muted-foreground">Redirecting you to login…</p>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="space-y-4" noValidate>
            <div className="space-y-2">
              <Label htmlFor="password">New password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                autoComplete="new-password"
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={status === "loading"}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm">Confirm password</Label>
              <Input
                id="confirm"
                type="password"
                placeholder="••••••••"
                autoComplete="new-password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                disabled={status === "loading"}
              />
            </div>
            {error && (
              <p className="text-xs text-destructive" role="alert">
                {error}
              </p>
            )}
            <Button type="submit" className="w-full" disabled={status === "loading"}>
              {status === "loading" ? (
                <>
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden="true" />
                  Updating…
                </>
              ) : (
                <>
                  Update password
                  <ArrowRight className="ml-1.5 h-4 w-4" aria-hidden="true" />
                </>
              )}
            </Button>
          </form>
        )}
      </AuthLayout>
    </>
  );
}
