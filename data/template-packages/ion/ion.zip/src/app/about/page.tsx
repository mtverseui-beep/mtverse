import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Target, Heart, Zap, Globe, Users } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { GlowOrb } from "@/components/primitives/glow";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "About",
  description: "The story behind Ion — what we're building and why.",
  alternates: { canonical: "/about" },
};

const values = [
  { icon: Target, title: "Outcomes over output", desc: "We measure success by what our users ship, not by how busy we look." },
  { icon: Heart, title: "Care is a feature", desc: "The little things — copy, loading states, error messages — are the product." },
  { icon: Zap, title: "Default to shipping", desc: "Small bets, weekly releases, honest changelogs. Imperfect and out > perfect and stalled." },
  { icon: Globe, title: "Remote-first, async-default", desc: "We hire across timezones and write things down. Meetings are the last resort." },
];

const stats = [
  { value: "4,000+", label: "Teams using Ion" },
  { value: "28", label: "Team members" },
  { value: "11", label: "Countries" },
  { value: "$0", label: "VC money taken" },
];

const team = [
  { name: "Maya Okafor", role: "CEO & Co-founder", initials: "MO", color: "bg-primary" },
  { name: "Dev Patel", role: "CTO & Co-founder", initials: "DP", color: "bg-accent-warm" },
  { name: "Sara Lindqvist", role: "Head of Design", initials: "SL", color: "bg-info" },
  { name: "Marcus Reyes", role: "Head of Engineering", initials: "MR", color: "bg-destructive" },
  { name: "Priya Anand", role: "Head of Product", initials: "PA", color: "bg-accent-warm" },
  { name: "Jonas Weber", role: "Head of Growth", initials: "JW", color: "bg-success" },
];

export default function AboutPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        {/* Hero */}
        <section className="relative overflow-hidden py-16 md:py-24">
          <GlowOrb className="left-1/2 top-0 -translate-x-1/2" color="var(--primary)" opacity={0.12} size={600} />
          <Container className="relative text-center">
            <Reveal><Eyebrow>About Ion</Eyebrow></Reveal>
            <Reveal delay={0.05}>
              <h1 className="display-1 mt-6 text-balance">
                We&apos;re building the workspace we always wanted.
              </h1>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
                Ion started as a side project in 2023 — a script that summarized our Slack every morning.
                Three years and a few thousand users later, it&apos;s a full workspace that thousands of
                teams rely on every day. We&apos;re still independent, still small, and still shipping weekly.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <Button asChild size="lg" className="mt-8 group">
                <Link href="/careers">
                  Join the team
                  <ArrowRight className="ml-1.5 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </Link>
              </Button>
            </Reveal>
          </Container>
        </section>

        {/* Stats */}
        <section className="border-y border-border bg-muted/30 py-12">
          <Container>
            <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
              {stats.map((s, i) => (
                <Reveal key={s.label} delay={i * 0.08} className="text-center">
                  <div className="text-3xl font-semibold text-foreground md:text-4xl">{s.value}</div>
                  <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
                </Reveal>
              ))}
            </div>
          </Container>
        </section>

        {/* Values */}
        <section className="py-20 md:py-28">
          <Container>
            <div className="mx-auto max-w-3xl text-center">
              <Reveal><Eyebrow>What we believe</Eyebrow></Reveal>
              <Reveal delay={0.05}>
                <h2 className="display-2 mt-4 text-balance">Four things we refuse to compromise on.</h2>
              </Reveal>
            </div>
            <div className="mt-14 grid gap-6 md:grid-cols-2">
              {values.map((v, i) => {
                const Icon = v.icon;
                return (
                  <Reveal key={v.title} delay={i * 0.08}>
                    <div className="rounded-2xl border border-border bg-card p-6">
                      <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                        <Icon className="h-5 w-5" aria-hidden="true" />
                      </div>
                      <h3 className="mt-4 text-lg font-semibold text-foreground">{v.title}</h3>
                      <p className="mt-2 text-sm text-muted-foreground">{v.desc}</p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </Container>
        </section>

        {/* Team */}
        <section className="border-t border-border bg-muted/30 py-20 md:py-28">
          <Container>
            <div className="mx-auto max-w-3xl text-center">
              <Reveal><Eyebrow>The team</Eyebrow></Reveal>
              <Reveal delay={0.05}>
                <h2 className="display-2 mt-4 text-balance">Small, senior, and shipping.</h2>
              </Reveal>
              <Reveal delay={0.1}>
                <p className="mt-6 text-lg text-muted-foreground">
                  28 people across 11 countries. No middle management. Everyone ships.
                </p>
              </Reveal>
            </div>
            <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {team.map((m, i) => (
                <Reveal key={m.name} delay={i * 0.05}>
                  <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-5">
                    <div className={`grid h-12 w-12 shrink-0 place-items-center rounded-full text-sm font-semibold text-primary-foreground ${m.color}`}>
                      {m.initials}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">{m.name}</p>
                      <p className="text-xs text-muted-foreground">{m.role}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </Container>
        </section>

        {/* CTA */}
        <section className="py-20 text-center">
          <Container>
            <Reveal>
              <h2 className="display-2 text-balance">Want to build with us?</h2>
              <p className="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
                We&apos;re hiring across engineering, design, and product.
              </p>
              <Button asChild size="lg" className="mt-8 group">
                <Link href="/careers">
                  <Users className="mr-1.5 h-4 w-4" aria-hidden="true" />
                  See open roles
                </Link>
              </Button>
            </Reveal>
          </Container>
        </section>
      </main>
      <Footer />
    </>
  );
}
