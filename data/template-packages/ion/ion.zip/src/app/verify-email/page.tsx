"use client";

import * as React from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { MailCheck, Loader2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AuthLayout } from "@/components/auth/auth-layout";
import { NoiseOverlay } from "@/components/primitives/glow";
import { useToast } from "@/hooks/use-toast";

/**
 * VerifyEmailPage — wraps the form in a <Suspense> boundary so that
 * useSearchParams() works during static prerendering (Next.js requirement).
 */
export default function VerifyEmailPage() {
  return (
    <React.Suspense fallback={null}>
      <VerifyEmailContent />
    </React.Suspense>
  );
}

function VerifyEmailContent() {
  const searchParams = useSearchParams();
  const email = searchParams.get("email") ?? "your inbox";
  const { toast } = useToast();
  const [resending, setResending] = React.useState(false);

  const onResend = async () => {
    setResending(true);
    try {
      await fetch("/api/auth/resend-verification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      toast({
        title: "Email resent",
        description: `Check ${email} for the verification link.`,
      });
    } finally {
      setResending(false);
    }
  };

  return (
    <>
      <NoiseOverlay />
      <AuthLayout title="Verify your email" subtitle="One last step before you can start building.">
        <div className="text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-primary/15 text-primary">
            <MailCheck className="h-6 w-6" aria-hidden="true" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-foreground">Check your inbox</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            We sent a verification link to{" "}
            <span className="font-medium text-foreground">{email}</span>. Click the link to activate
            your account.
          </p>
          <div className="mt-6 space-y-3">
            <Button onClick={onResend} variant="outline" className="w-full" disabled={resending}>
              {resending ? (
                <>
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden="true" />
                  Resending…
                </>
              ) : (
                "Resend verification email"
              )}
            </Button>
            <Button asChild className="w-full">
              <Link href="/dashboard">
                Continue to dashboard
                <ArrowRight className="ml-1.5 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>
          </div>
          <p className="mt-6 text-xs text-muted-foreground">
            Wrong email?{" "}
            <Link href="/signup" className="text-primary hover:underline">
              Sign up again
            </Link>
          </p>
        </div>
      </AuthLayout>
    </>
  );
}
