import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container } from "@/components/primitives/section";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Badge } from "@/components/ui/badge";
import { changelog, type ChangelogEntry } from "@/config/content";

type Props = { params: Promise<{ version: string }> };

const tagVariant: Record<ChangelogEntry["tag"], "default" | "secondary" | "destructive" | "outline"> = {
  New: "default",
  Improved: "secondary",
  Fix: "outline",
  Security: "destructive",
};

export async function generateStaticParams() {
  return changelog.map((c) => ({ version: c.version }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { version } = await params;
  const entry = changelog.find((c) => c.version === version);
  if (!entry) return { title: "Not found" };
  return {
    title: `v${entry.version} — ${entry.title}`,
    description: entry.notes[0],
    alternates: { canonical: `/changelog/${entry.version}` },
  };
}

export default async function ChangelogDetailPage({ params }: Props) {
  const { version } = await params;
  const entry = changelog.find((c) => c.version === version);
  if (!entry) notFound();

  const idx = changelog.findIndex((c) => c.version === version);
  const prev = idx > 0 ? changelog[idx - 1] : null;
  const next = idx < changelog.length - 1 ? changelog[idx + 1] : null;

  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12">
          <Link
            href="/changelog"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            All releases
          </Link>

          <article className="mx-auto mt-8 max-w-3xl">
            <div className="flex flex-wrap items-center gap-3">
              <Badge variant={tagVariant[entry.tag]}>{entry.tag}</Badge>
              <time className="text-sm text-muted-foreground" dateTime={entry.date}>
                {new Date(entry.date).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </time>
            </div>

            <div className="mt-4 flex items-baseline gap-3">
              <span className="font-mono text-sm text-muted-foreground">v</span>
              <h1 className="display-2 text-balance">{entry.version}</h1>
            </div>
            <p className="mt-4 text-xl text-foreground">{entry.title}</p>

            <div className="prose-ion mt-8">
              <h2>What&apos;s in this release</h2>
              <ul>
                {entry.notes.map((n) => (
                  <li key={n}>{n}</li>
                ))}
              </ul>
            </div>

            {/* Prev / next */}
            <nav
              className="mt-12 grid gap-4 border-t border-border pt-8 sm:grid-cols-2"
              aria-label="Release navigation"
            >
              {prev ? (
                <Link
                  href={`/changelog/${prev.version}`}
                  className="group rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <ArrowLeft className="h-3 w-3" aria-hidden="true" />
                    Previous
                  </span>
                  <span className="mt-1 block text-sm font-medium text-foreground group-hover:text-primary">
                    v{prev.version} — {prev.title}
                  </span>
                </Link>
              ) : (
                <div />
              )}
              {next ? (
                <Link
                  href={`/changelog/${next.version}`}
                  className="group rounded-xl border border-border bg-card p-4 text-right transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
                    Next
                    <ArrowRight className="h-3 w-3" aria-hidden="true" />
                  </span>
                  <span className="mt-1 block text-sm font-medium text-foreground group-hover:text-primary">
                    v{next.version} — {next.title}
                  </span>
                </Link>
              ) : (
                <div />
              )}
            </nav>
          </article>
        </Container>
      </main>
      <Footer />
    </>
  );
}
