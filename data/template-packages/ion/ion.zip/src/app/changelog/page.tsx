import type { Metadata } from "next";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { FinalCTA } from "@/components/sections/final-cta";
import { Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Badge } from "@/components/ui/badge";
import { changelog, type ChangelogEntry } from "@/config/content";

export const metadata: Metadata = {
  title: "Changelog",
  description:
    "Every Ion release, with dates and tags. See what's new, what's improved, and what we fixed.",
  alternates: { canonical: "/changelog" },
};

const tagVariant: Record<ChangelogEntry["tag"], "default" | "secondary" | "destructive" | "outline"> = {
  New: "default",
  Improved: "secondary",
  Fix: "outline",
  Security: "destructive",
};

export default function ChangelogPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12 text-center">
          <Eyebrow>Changelog</Eyebrow>
          <h1 className="display-1 mt-4 text-balance">We ship every week.</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
            Real entries, real dates, real tags. This page is itself a demo of the changelog
            component — buyers can populate it from <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">src/config/content.ts</code>.
          </p>
        </Container>

        <Container className="py-12">
          <div className="mx-auto max-w-3xl">
            <ol className="relative space-y-12 border-l border-border pl-8">
              {changelog.map((entry, i) => (
                <Reveal as="li" key={entry.version} delay={i * 0.05} className="relative">
                  {/* node */}
                  <span
                    className="absolute -left-[41px] top-1 grid h-8 w-8 place-items-center rounded-full border-2 border-primary bg-background font-mono text-xs font-semibold text-primary"
                    aria-hidden="true"
                  >
                    {entry.version.charAt(0)}
                  </span>
                  <div className="rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40">
                    <a
                      href={`/changelog/${entry.version}`}
                      className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-2xl -m-6 p-6"
                      aria-label={`v${entry.version} — ${entry.title}`}
                    >
                    <div className="flex flex-wrap items-center gap-3">
                      <h2 className="text-lg font-semibold text-foreground">
                        v{entry.version}
                      </h2>
                      <Badge variant={tagVariant[entry.tag]}>{entry.tag}</Badge>
                      <time
                        dateTime={entry.date}
                        className="ml-auto text-xs text-muted-foreground"
                      >
                        {new Date(entry.date).toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </time>
                    </div>
                    <h3 className="mt-2 text-base font-medium text-foreground hover:text-primary">
                      {entry.title}
                    </h3>
                    <ul className="mt-4 space-y-2">
                      {entry.notes.map((note) => (
                        <li
                          key={note}
                          className="flex items-start gap-2 text-sm text-muted-foreground"
                        >
                          <span
                            className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-primary"
                            aria-hidden="true"
                          />
                          {note}
                        </li>
                      ))}
                    </ul>
                    </a>
                  </div>
                </Reveal>
              ))}
            </ol>
          </div>
        </Container>

        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
