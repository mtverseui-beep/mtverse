import type { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { SignupForm } from "@/components/auth/signup-form";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Sign up",
  description: "Create your free Ion workspace. No credit card required.",
  alternates: { canonical: "/signup" },
  robots: { index: false, follow: false },
};

export default function SignupPage() {
  return (
    <>
      <NoiseOverlay />
      <AuthLayout
        title="Create your account"
        subtitle="Free for 14 days. No credit card required."
      >
        <SignupForm />
      </AuthLayout>
    </>
  );
}
