import type { Metadata } from "next";
import Link from "next/link";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The terms and conditions for using Ion.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12">
          <Eyebrow>Legal</Eyebrow>
          <h1 className="display-2 mt-4 text-balance">Terms of Service</h1>
          <p className="mt-2 text-sm text-muted-foreground">Last updated: August 1, 2026</p>

          <article className="prose-ion mt-10 max-w-3xl">
            <h2>1. Acceptance of terms</h2>
            <p>
              By creating an Ion account or using the Service, you agree to these Terms and our{" "}
              <Link href="/privacy">Privacy Policy</Link>. If you&apos;re using Ion on behalf of an
              organization, you represent that you have authority to bind that organization.
            </p>

            <h2>2. Your account</h2>
            <ul>
              <li>You must be 16 or older to use Ion.</li>
              <li>You&apos;re responsible for keeping your credentials secure.</li>
              <li>You&apos;re responsible for all activity under your account.</li>
              <li>You must provide accurate information at registration.</li>
            </ul>

            <h2>3. Acceptable use</h2>
            <p>You agree <strong>not</strong> to:</p>
            <ul>
              <li>Use Ion for any illegal purpose or in violation of any law.</li>
              <li>Upload content that infringes others&apos; intellectual property.</li>
              <li>Attempt to access data you don&apos;t have permission to access.</li>
              <li>Reverse-engineer, decompile, or disassemble the Service.</li>
              <li>Use the Service to build a competing product.</li>
              <li>Resell or sublicense access to the Service without our written consent.</li>
              <li>Use the Service in a way that could damage, overload, or impair it.</li>
            </ul>

            <h2>4. Your content</h2>
            <p>
              You retain all ownership rights to content you create or upload to Ion. You grant us a
              limited license to host, process, and display your content solely to provide the Service
              to you.
            </p>
            <p>
              You&apos;re responsible for ensuring you have the rights to upload content to Ion and
              that doing so complies with your organization&apos;s policies and applicable law.
            </p>

            <h2>5. AI processing</h2>
            <p>
              Ion uses AI models (including third-party models from Anthropic and OpenAI) to process
              your content and generate responses. We never train foundation models on your data. Your
              content is processed in your tenant and is not shared with other customers.
            </p>
            <p>
              AI-generated outputs may be inaccurate. You&apos;re responsible for reviewing and
              validating any output before acting on it.
            </p>

            <h2>6. Subscriptions and billing</h2>
            <ul>
              <li>Paid plans are billed in advance, monthly or annually.</li>
              <li>You can upgrade or downgrade at any time; changes prorate automatically.</li>
              <li>You can cancel anytime; cancellation takes effect at the end of the current billing period.</li>
              <li>Refunds within 30 days of initial purchase are available — see our <Link href="/pricing">refund policy</Link>.</li>
              <li>We may change pricing with 30 days&apos; notice. Existing subscribers keep their current rate for the current term.</li>
            </ul>

            <h2>7. Service availability</h2>
            <p>
              We target 99.95% uptime for Enterprise customers (99.9% for Pro). We don&apos;t guarantee
              uninterrupted service and are not liable for downtime. Service credits are available per
              our SLA — see your plan details.
            </p>

            <h2>8. Intellectual property</h2>
            <p>
              The Service, including its design, code, and brand, is owned by Ion and protected by
              intellectual property laws. These Terms don&apos;t grant you any rights to our trademarks
              or proprietary technology.
            </p>

            <h2>9. Termination</h2>
            <p>
              You can delete your account at any time. We may suspend or terminate your account if you
              violate these Terms. Upon termination, your data will be deleted within 30 days (subject
              to legal holds).
            </p>

            <h2>10. Disclaimers</h2>
            <p>
              The Service is provided &ldquo;as is&rdquo; without warranties of any kind. We don&apos;t
              warrant that the Service will be error-free, secure, or available at all times.
            </p>

            <h2>11. Limitation of liability</h2>
            <p>
              To the maximum extent permitted by law, Ion&apos;s total liability for any claim is
              limited to the amount you paid us in the 12 months preceding the claim. We are not
              liable for indirect, incidental, or consequential damages.
            </p>

            <h2>12. Governing law</h2>
            <p>
              These Terms are governed by the laws of the State of California, without regard to
              conflict of law principles. Disputes will be resolved in the courts of San Francisco
              County, California.
            </p>

            <h2>13. Changes</h2>
            <p>
              We may update these Terms. We&apos;ll notify you of material changes by email and post a
              notice in the app at least 30 days before they take effect.
            </p>

            <h2>14. Contact</h2>
            <p>
              Questions about these Terms? Email <a href="mailto:legal@ion.app">legal@ion.app</a>.
            </p>
          </article>
        </Container>
      </main>
      <Footer />
    </>
  );
}
