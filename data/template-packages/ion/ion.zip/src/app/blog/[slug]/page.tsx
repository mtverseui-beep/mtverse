import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, Clock, Calendar } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { NoiseOverlay } from "@/components/primitives/glow";
import { posts, getRelatedPosts } from "@/config/blog";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return posts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = posts.find((p) => p.slug === slug);
  if (!post) return { title: "Not found" };
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      type: "article",
      title: post.title,
      description: post.excerpt,
      publishedTime: post.date,
      authors: [post.author.name],
    },
  };
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  const post = posts.find((p) => p.slug === slug);
  if (!post) notFound();

  const related = getRelatedPosts(slug, 2);

  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12">
          <Link
            href="/blog"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            All posts
          </Link>

          <article className="mx-auto mt-8 max-w-3xl">
            <Reveal>
              <div className="flex flex-wrap gap-2">
                {post.tags.map((t) => (
                  <span
                    key={t}
                    className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary"
                  >
                    {t}
                  </span>
                ))}
              </div>
              <h1 className="display-2 mt-4 text-balance">{post.title}</h1>
              <p className="mt-4 text-lg text-muted-foreground">{post.excerpt}</p>

              <div className="mt-6 flex items-center gap-4 border-y border-border py-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="grid h-8 w-8 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                    {post.author.initials}
                  </div>
                  <div>
                    <div className="font-medium text-foreground">{post.author.name}</div>
                    <div className="text-xs text-muted-foreground">{post.author.role}</div>
                  </div>
                </div>
                <span className="ml-auto flex items-center gap-3 text-xs">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" aria-hidden="true" />
                    {new Date(post.date).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" aria-hidden="true" />
                    {post.readingTime}
                  </span>
                </span>
              </div>
            </Reveal>

            <div
              className="prose-ion mt-8"
              dangerouslySetInnerHTML={{ __html: post.body }}
            />
          </article>

          {/* Related posts */}
          {related.length > 0 && (
            <section className="mx-auto mt-16 max-w-3xl">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Read next
              </h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {related.map((p) => (
                  <Link
                    key={p.slug}
                    href={`/blog/${p.slug}`}
                    className="group rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <h3 className="text-sm font-semibold text-foreground group-hover:text-primary">
                      {p.title}
                    </h3>
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{p.excerpt}</p>
                    <span className="mt-3 flex items-center gap-1 text-xs text-primary">
                      Read
                      <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                    </span>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </Container>
      </main>
      <Footer />
    </>
  );
}
