import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { NoiseOverlay } from "@/components/primitives/glow";
import { posts } from "@/config/blog";

export const metadata: Metadata = {
  title: "Blog",
  description: "Essays on building Ion, AI-native product design, and shipping software weekly.",
  alternates: { canonical: "/blog" },
};

export default function BlogIndexPage() {
  const [featured, ...rest] = posts;

  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12">
          <Reveal><Eyebrow>Blog</Eyebrow></Reveal>
          <Reveal delay={0.05}>
            <h1 className="display-1 mt-4 text-balance">Essays on building Ion.</h1>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
              Product updates, engineering deep-dives, and lessons from running an async-first,
              remote-first AI company. We publish when we have something to say — not on a schedule.
            </p>
          </Reveal>

          {/* Featured post */}
          <Reveal delay={0.15} className="mt-12">
            <Link
              href={`/blog/${featured.slug}`}
              className="group block overflow-hidden rounded-3xl border border-border bg-card transition-all hover:border-primary/40 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <div className="grid md:grid-cols-2">
                <div className="relative aspect-[16/10] md:aspect-auto bg-gradient-to-br from-primary/20 via-accent-warm/10 to-transparent">
                  <div className="absolute inset-0 grid place-items-center p-8">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-foreground/30">
                        {new Date(featured.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                      </div>
                      <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">
                        Featured
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-6 md:p-8">
                  <div className="flex flex-wrap gap-2">
                    {featured.tags.map((t) => (
                      <span
                        key={t}
                        className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                  <h2 className="mt-3 text-xl font-semibold text-foreground group-hover:text-primary md:text-2xl">
                    {featured.title}
                  </h2>
                  <p className="mt-2 text-sm text-muted-foreground">{featured.excerpt}</p>
                  <div className="mt-4 flex items-center gap-3 text-xs text-muted-foreground">
                    <div className="grid h-7 w-7 place-items-center rounded-full bg-primary text-[10px] font-semibold text-primary-foreground">
                      {featured.author.initials}
                    </div>
                    <span>{featured.author.name}</span>
                    <span>·</span>
                    <span>{featured.readingTime} read</span>
                  </div>
                </div>
              </div>
            </Link>
          </Reveal>

          {/* Rest of posts */}
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {rest.map((p, i) => (
              <Reveal key={p.slug} delay={i * 0.05}>
                <Link
                  href={`/blog/${p.slug}`}
                  className="group flex h-full flex-col rounded-2xl border border-border bg-card p-5 transition-all hover:border-primary/40 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <div className="flex flex-wrap gap-2">
                    {p.tags.slice(0, 2).map((t) => (
                      <span
                        key={t}
                        className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                  <h3 className="mt-3 text-base font-semibold text-foreground group-hover:text-primary">
                    {p.title}
                  </h3>
                  <p className="mt-2 flex-1 text-sm text-muted-foreground line-clamp-3">
                    {p.excerpt}
                  </p>
                  <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                    <span>{p.author.name}</span>
                    <span className="flex items-center gap-1">
                      {p.readingTime} read
                      <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </Container>
      </main>
      <Footer />
    </>
  );
}
