import { NextResponse } from "next/server";

/** POST /api/auth/logout — demo endpoint. Clears session. */
export async function POST() {
  return NextResponse.json({ ok: true });
}
