import { NextResponse } from "next/server";
import { z } from "zod";

/** POST /api/auth/resend-verification — demo endpoint. */
const schema = z.object({ email: z.string().email() });

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Please enter a valid email." }, { status: 422 });
  }
  console.log("[auth] resend verification to:", parsed.data.email);
  await new Promise((r) => setTimeout(r, 400));
  return NextResponse.json({ ok: true });
}
