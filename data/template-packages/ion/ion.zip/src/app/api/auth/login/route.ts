import { NextResponse } from "next/server";
import { z } from "zod";

/**
 * POST /api/auth/login — demo auth endpoint.
 * ───────────────────────────────────────────────────────────────────────────
 * Validates credentials against a hardcoded demo user, sets a fake session
 * cookie, and returns success. This is NOT real auth — it exists so the form
 * works end-to-end for the template demo.
 *
 * IN PRODUCTION: replace with NextAuth.js (already installable), Clerk,
 * Supabase Auth, or your own JWT/session implementation. See README
 * "Authentication" section for the recommended path.
 */

const DEMO_USER = {
  email: "demo@ion.app",
  password: "demo-password-123",
  name: "Maya Okafor",
};

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Please enter a valid email and password." },
      { status: 422 }
    );
  }

  const { email, password } = parsed.data;

  // Demo auth: accept the demo user OR any email with the demo password.
  // In production: hash-compare against your user database.
  if (email === DEMO_USER.email && password === DEMO_USER.password) {
    return NextResponse.json({
      ok: true,
      user: { email: DEMO_USER.email, name: DEMO_USER.name },
      session: "demo-session-token",
    });
  }

  // Demo fallback: accept any well-formed email/password ≥ 8 chars
  // so buyers can test the flow without knowing the demo creds.
  if (password.length >= 8) {
    return NextResponse.json({
      ok: true,
      user: { email, name: email.split("@")[0] },
      session: "demo-session-token",
    });
  }

  return NextResponse.json(
    { error: "Incorrect email or password." },
    { status: 401 }
  );
}
