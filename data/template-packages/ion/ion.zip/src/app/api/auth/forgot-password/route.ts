import { NextResponse } from "next/server";
import { z } from "zod";

/** POST /api/auth/forgot-password — demo endpoint. Logs the request, returns success. */
const schema = z.object({ email: z.string().email() });

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Please enter a valid email." }, { status: 422 });
  }
  console.log("[auth] forgot-password requested for:", parsed.data.email);
  await new Promise((r) => setTimeout(r, 500));
  // Always return success — don't leak whether the email exists.
  return NextResponse.json({ ok: true });
}
