import { NextResponse } from "next/server";
import { z } from "zod";

/** POST /api/auth/reset-password — demo endpoint. Validates token + new password. */
const schema = z.object({
  token: z.string().min(1),
  password: z.string().min(8),
});

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid input." },
      { status: 422 }
    );
  }
  console.log("[auth] password reset for token:", parsed.data.token.slice(0, 8) + "…");
  await new Promise((r) => setTimeout(r, 500));
  return NextResponse.json({ ok: true });
}
