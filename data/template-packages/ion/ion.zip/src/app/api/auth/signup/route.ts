import { NextResponse } from "next/server";
import { z } from "zod";

/**
 * POST /api/auth/signup — demo signup endpoint.
 * Validates input, "creates" an account (logs to console), returns success.
 * In production: hash password with bcrypt/argon2, persist to DB, send verification email.
 */

const schema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  password: z.string().min(8),
  company: z.string().max(100).optional().or(z.literal("")),
  terms: z.boolean().refine((v) => v === true),
});

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    const firstError = parsed.error.issues[0];
    return NextResponse.json(
      { error: firstError?.message ?? "Validation failed." },
      { status: 422 }
    );
  }

  const { name, email, company } = parsed.data;

  // Demo: log the signup. In production: insert into DB, send verification email.
  console.log("[auth] signup:", { name, email, company, timestamp: new Date().toISOString() });

  // Simulate async work
  await new Promise((r) => setTimeout(r, 600));

  return NextResponse.json({
    ok: true,
    user: { email, name, company },
    message: "Verification email sent. Check your inbox.",
  });
}
