import { NextResponse } from "next/server";
import { z } from "zod";

/**
 * POST /api/contact
 * ───────────────────────────────────────────────────────────────────────────
 * Real working example backend for the contact form, newsletter signup, and
 * waitlist. Validates input with zod, then handles it per `type`.
 *
 * BUYERS: This route currently just validates + logs + echoes the payload.
 * To make it actually deliver email or persist to a DB, plug in ONE of:
 *
 *   1. Resend (recommended for transactional email):
 *      `bun add resend`
 *      import { Resend } from 'resend';
 *      const resend = new Resend(process.env.RESEND_API_KEY);
 *      await resend.emails.send({
 *        from: 'Ion <hello@ion.app>',
 *        to: 'hello@ion.app',
 *        reply_to: body.email,
 *        subject: `New ${body.type}: ${body.name ?? body.email}`,
 *        text: body.message ?? '',
 *      });
 *
 *   2. Formspree (no backend needed — point the client form at their URL):
 *      Replace the `fetch('/api/contact', ...)` in contact-form.tsx with
 *      `fetch('https://formspree.io/f/YOUR_ID', ...)`.
 *
 *   3. Your own DB (Prisma is already installed):
 *      import { db } from '@/lib/db';
 *      await db.contactSubmission.create({ data: { ... } });
 *      (Add the model in prisma/schema.prisma, run `bun run db:push`.)
 *
 * Required env vars for production (see .env.example):
 *   - RESEND_API_KEY (if using Resend)
 */

const contactSchema = z.object({
  type: z.enum(["contact", "newsletter", "waitlist"]),
  email: z.string().email(),
  name: z.string().min(2).max(100).optional(),
  company: z.string().max(100).optional(),
  message: z.string().min(10).max(2000).optional(),
});

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = contactSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Validation failed.",
        issues: parsed.error.issues.map((i) => ({ path: i.path, message: i.message })),
      },
      { status: 422 }
    );
  }

  const data = parsed.data;

  // Type-specific required-field checks
  if (data.type === "contact" && (!data.name || !data.message)) {
    return NextResponse.json(
      { error: "Contact submissions require name and message." },
      { status: 422 }
    );
  }

  // ─── INTEGRATION POINT ───────────────────────────────────────────────
  // Replace this block with your real handler (Resend / Formspree / DB).
  // For now: log on the server (visible in `bun run dev` output) and
  // simulate async work so loading states are visible to buyers.
  console.log(`[contact] received ${data.type} submission:`, {
    email: data.email,
    name: data.name,
    company: data.company,
    messageLength: data.message?.length ?? 0,
    timestamp: new Date().toISOString(),
  });

  // Simulate network latency (300-600ms) so loading states are visible.
  // Remove in production.
  await new Promise((resolve) => setTimeout(resolve, 400));
  // ─── END INTEGRATION POINT ───────────────────────────────────────────

  return NextResponse.json(
    {
      ok: true,
      type: data.type,
      receivedAt: new Date().toISOString(),
    },
    { status: 200 }
  );
}

/** GET — simple health check. Useful for uptime monitors. */
export async function GET() {
  return NextResponse.json({ ok: true, route: "/api/contact" });
}
