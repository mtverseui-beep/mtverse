import type { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { LoginForm } from "@/components/auth/login-form";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Log in",
  description: "Log in to your Ion workspace.",
  alternates: { canonical: "/login" },
  robots: { index: false, follow: false },
};

export default function LoginPage() {
  return (
    <>
      <NoiseOverlay />
      <AuthLayout title="Welcome back" subtitle="Log in to your Ion workspace.">
        <LoginForm />
      </AuthLayout>
    </>
  );
}
