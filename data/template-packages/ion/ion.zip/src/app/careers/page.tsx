import type { Metadata } from "next";
import Link from "next/link";
import { MapPin, Briefcase, ArrowRight, Clock } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Careers",
  description: "Join the Ion team. We're hiring across engineering, design, and product.",
  alternates: { canonical: "/careers" },
};

const roles = [
  { title: "Senior Product Engineer", team: "Engineering", location: "Remote (Americas)", type: "Full-time", slug: "senior-product-engineer" },
  { title: "Staff Engineer, Platform", team: "Engineering", location: "Remote (EU)", type: "Full-time", slug: "staff-engineer-platform" },
  { title: "Product Designer", team: "Design", location: "Remote (Global)", type: "Full-time", slug: "product-designer" },
  { title: "Developer Advocate", team: "Growth", location: "Remote (Americas)", type: "Full-time", slug: "developer-advocate" },
  { title: "Customer Engineer", team: "Support", location: "Remote (EU)", type: "Full-time", slug: "customer-engineer" },
  { title: "Technical Writer", team: "Product", location: "Remote (Global)", type: "Contract", slug: "technical-writer" },
];

const perks = [
  { title: "Async-first", desc: "Write things down. Meetings are the last resort. Deep work is the default." },
  { title: "Real equity", desc: "Every full-time hire gets meaningful equity. We're all owners." },
  { title: "Unlimited PTO", desc: "With a 4-week minimum. We track it to make sure you actually take it." },
  { title: "$3k setup budget", desc: "Spend it on whatever makes you productive — chair, monitor, keyboard." },
  { title: "Twice-yearly retreats", desc: "We meet in person twice a year. Past spots: Lisbon, Mexico City, Tokyo." },
  { title: "Ship weekly", desc: "You'll ship something users see every week. No quarterly release cycles." },
];

export default function CareersPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        {/* Hero */}
        <section className="py-16 md:py-24">
          <Container className="text-center">
            <Reveal><Eyebrow>Careers</Eyebrow></Reveal>
            <Reveal delay={0.05}>
              <h1 className="display-1 mt-6 text-balance">Build the workspace you wish existed.</h1>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
                28 people. 11 countries. Zero middle management. If you want to ship real things
                to real users every week — and have the autonomy to decide what those things are —
                we should talk.
              </p>
            </Reveal>
          </Container>
        </section>

        {/* Open roles */}
        <section className="border-t border-border py-16 md:py-24">
          <Container>
            <div className="mx-auto max-w-3xl">
              <Reveal>
                <h2 className="display-3 text-balance">Open roles</h2>
                <p className="mt-2 text-muted-foreground">{roles.length} positions · all remote</p>
              </Reveal>
              <ul className="mt-8 space-y-3">
                {roles.map((r, i) => (
                  <Reveal as="li" key={r.slug} delay={i * 0.05}>
                    <Link
                      href={`/careers/${r.slug}`}
                      className="group flex flex-wrap items-center justify-between gap-4 rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/40 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <div>
                        <h3 className="text-base font-semibold text-foreground">{r.title}</h3>
                        <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Briefcase className="h-3 w-3" aria-hidden="true" />
                            {r.team}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" aria-hidden="true" />
                            {r.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" aria-hidden="true" />
                            {r.type}
                          </span>
                        </div>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" aria-hidden="true" />
                    </Link>
                  </Reveal>
                ))}
              </ul>
            </div>
          </Container>
        </section>

        {/* Perks */}
        <section className="border-t border-border bg-muted/30 py-16 md:py-24">
          <Container>
            <div className="mx-auto max-w-3xl text-center">
              <Reveal><Eyebrow>Working here</Eyebrow></Reveal>
              <Reveal delay={0.05}>
                <h2 className="display-2 mt-4 text-balance">How we work, in practice.</h2>
              </Reveal>
            </div>
            <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {perks.map((p, i) => (
                <Reveal key={p.title} delay={i * 0.05}>
                  <div className="rounded-2xl border border-border bg-card p-5">
                    <h3 className="text-sm font-semibold text-foreground">{p.title}</h3>
                    <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </Container>
        </section>

        {/* CTA */}
        <section className="py-20 text-center">
          <Container>
            <Reveal>
              <h2 className="display-3 text-balance">Don&apos;t see your role?</h2>
              <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
                Tell us what you want to build. We hire for aptitude, not open reqs.
              </p>
              <Button asChild size="lg" className="mt-8">
                <Link href="/contact">Email us</Link>
              </Button>
            </Reveal>
          </Container>
        </section>
      </main>
      <Footer />
    </>
  );
}
