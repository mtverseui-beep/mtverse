import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, MapPin, Briefcase, Clock, Check } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";

const roles: Record<string, {
  title: string;
  team: string;
  location: string;
  type: string;
  description: string;
  responsibilities: string[];
  requirements: string[];
  niceToHave: string[];
}> = {
  "senior-product-engineer": {
    title: "Senior Product Engineer",
    team: "Engineering",
    location: "Remote (Americas)",
    type: "Full-time",
    description: "You'll own end-to-end features — from idea to ship — that touch thousands of teams. We're looking for someone who thinks like an owner, writes maintainable TypeScript, and has opinions about product.",
    responsibilities: [
      "Ship user-facing features end-to-end (design, code, ship, iterate).",
      "Own major areas of the product — workspace, automations, or insights.",
      "Partner with design and product on scoping and tradeoffs.",
      "Mentor mid-level engineers and review code with kindness.",
      "Participate in on-call rotation (1 week every ~6 weeks).",
    ],
    requirements: [
      "5+ years building production web apps in TypeScript/React.",
      "Strong product instincts — you care about the user, not just the code.",
      "Experience with Next.js App Router and server components.",
      "Comfortable with SQL, basic infra (Vercel/AWS), and CI/CD.",
      "Excellent written communication — we're async-first.",
    ],
    niceToHave: [
      "Experience building developer tools or SaaS products.",
      "Open-source contributions.",
      "Experience with Framer Motion and Radix UI.",
    ],
  },
  "staff-engineer-platform": {
    title: "Staff Engineer, Platform",
    team: "Engineering",
    location: "Remote (EU)",
    type: "Full-time",
    description: "Lead the platform that powers Ion's automations, integrations, and AI. You'll set technical direction for the platform team and partner closely with the CTO.",
    responsibilities: [
      "Architect and build the platform: integrations engine, queue system, AI gateway.",
      "Set technical direction and standards for the platform team.",
      "Drive reliability — 99.95% uptime SLA, observability, incident response.",
      "Partner with product engineers to design clean internal APIs.",
      "Mentor senior engineers and grow the platform team.",
    ],
    requirements: [
      "8+ years building production systems at scale.",
      "Deep experience with distributed systems, queues, and event-driven architectures.",
      "Strong TypeScript/Node.js skills — our backend is TypeScript end-to-end.",
      "Experience with Postgres, Redis, and infrastructure-as-code.",
      "Track record of leading technical direction, not just executing it.",
    ],
    niceToHave: [
      "Experience building integration platforms (Zapier, Workato, etc.).",
      "Experience with LLM infrastructure and prompt management at scale.",
      "Open-source maintainer.",
    ],
  },
  "product-designer": {
    title: "Product Designer",
    team: "Design",
    location: "Remote (Global)",
    type: "Full-time",
    description: "Own the end-to-end design of features that thousands of teams use daily. You'll partner with engineers and product from idea to ship.",
    responsibilities: [
      "Design features end-to-end: research, flows, wireframes, high-fidelity, prototype.",
      "Maintain and evolve our design system.",
      "Run usability tests with real customers.",
      "Partner with engineering on implementation details.",
      "Contribute to product strategy, not just execution.",
    ],
    requirements: [
      "5+ years designing SaaS or developer tools.",
      "Strong portfolio showing shipped work, not just concepts.",
      "Fluent in Figma, prototyping tools, and design systems.",
      "Comfortable with the technical side — you can read React/TS.",
      "Excellent written communication.",
    ],
    niceToHave: [
      "Experience designing AI products.",
      "Front-end coding skills (you can ship a prototype yourself).",
      "Motion design experience.",
    ],
  },
  "developer-advocate": {
    title: "Developer Advocate",
    team: "Growth",
    location: "Remote (Americas)",
    type: "Full-time",
    description: "Be the bridge between Ion and the developer community. Create content, build demos, run events, and bring developer feedback back to the product team.",
    responsibilities: [
      "Create technical content: blog posts, videos, demos, talks.",
      "Build and maintain sample apps and integrations.",
      "Run community events (office hours, workshops, meetups).",
      "Engage on Discord, GitHub, X — wherever developers are.",
      "Bring developer feedback into product decisions.",
    ],
    requirements: [
      "3+ years in dev rel, developer advocacy, or as a practicing engineer.",
      "Excellent writing and presenting skills (samples required).",
      "Strong TypeScript/React skills — you can build real demos.",
      "Genuine interest in AI/developer tools space.",
      "Comfortable on camera.",
    ],
    niceToHave: [
      "Existing audience in the dev tools space.",
      "Experience building with LLMs.",
      "Conference speaking experience.",
    ],
  },
  "customer-engineer": {
    title: "Customer Engineer",
    team: "Support",
    location: "Remote (EU)",
    type: "Full-time",
    description: "Be the technical expert our customers rely on. Help them set up, integrate, and succeed with Ion — and feed their pain points back to product.",
    responsibilities: [
      "Own technical support for EU timezone customers.",
      "Help customers design and build automations.",
      "Debug integration issues and write fix PRs when needed.",
      "Create internal docs and runbooks from common questions.",
      "Bring customer feedback into product prioritization.",
    ],
    requirements: [
      "3+ years in technical support, solutions engineering, or SRE.",
      "Strong debugging skills across web stacks.",
      "Comfortable reading and writing TypeScript.",
      "Excellent written communication — empathy is non-negotiable.",
      "EU timezone (UTC±3).",
    ],
    niceToHave: [
      "Experience with Zapier, Workato, or similar automation tools.",
      "Experience supporting SaaS products at scale.",
    ],
  },
  "technical-writer": {
    title: "Technical Writer",
    team: "Product",
    location: "Remote (Global)",
    type: "Contract",
    description: "Help us build the best docs in the AI tools space. 6-month contract with potential to convert to full-time.",
    responsibilities: [
      "Write and maintain user-facing docs, API reference, and guides.",
      "Create code samples and tutorials.",
      "Work with engineering to document new features as they ship.",
      "Improve information architecture of the docs site.",
    ],
    requirements: [
      "3+ years writing technical docs for developer tools.",
      "Can read TypeScript and write working code samples.",
      "Portfolio of shipped docs (please include links).",
      "Excellent at structuring complex information.",
    ],
    niceToHave: [
      "Experience with docs-as-code workflows.",
      "Experience building with LLMs or AI tools.",
    ],
  },
};

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const role = roles[slug];
  if (!role) return { title: "Role not found" };
  return {
    title: role.title,
    description: role.description.slice(0, 160),
    alternates: { canonical: `/careers/${slug}` },
  };
}

export default async function CareerDetailPage({ params }: Props) {
  const { slug } = await params;
  const role = roles[slug];
  if (!role) notFound();

  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12">
          <Link
            href="/careers"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            All roles
          </Link>

          <div className="mt-8 grid gap-12 lg:grid-cols-[1fr_320px]">
            {/* Main */}
            <article>
              <Eyebrow>{role.team} · {role.type}</Eyebrow>
              <h1 className="display-2 mt-4 text-balance">{role.title}</h1>

              <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4" aria-hidden="true" />
                  {role.location}
                </span>
                <span className="flex items-center gap-1.5">
                  <Briefcase className="h-4 w-4" aria-hidden="true" />
                  {role.team}
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4" aria-hidden="true" />
                  {role.type}
                </span>
              </div>

              <div className="prose-ion mt-10">
                <h2>The role</h2>
                <p>{role.description}</p>

                <h2>What you&apos;ll do</h2>
                <ul>
                  {role.responsibilities.map((r) => (
                    <li key={r}>{r}</li>
                  ))}
                </ul>

                <h2>We&apos;re looking for</h2>
                <ul>
                  {role.requirements.map((r) => (
                    <li key={r}>{r}</li>
                  ))}
                </ul>

                <h2>Nice to have</h2>
                <ul>
                  {role.niceToHave.map((r) => (
                    <li key={r}>{r}</li>
                  ))}
                </ul>

                <h2>How to apply</h2>
                <p>
                  Send us an email at <a href="mailto:careers@ion.app">careers@ion.app</a> with
                  your resume and a short note on why you&apos;re interested. No cover letter
                  templates — just tell us what you want to build.
                </p>
                <p>
                  We respond to every application within 5 business days. The process is: intro
                  call (30min) → take-home or work sample (paid) → pair session (1hr) → offer.
                  Total time: ~2 weeks.
                </p>
              </div>

              <div className="mt-10">
                <Button asChild size="lg">
                  <a href="mailto:careers@ion.app">Apply for this role</a>
                </Button>
              </div>
            </article>

            {/* Sidebar */}
            <aside className="lg:sticky lg:top-32 lg:h-fit">
              <div className="rounded-2xl border border-border bg-card p-6">
                <h3 className="text-sm font-semibold text-foreground">At a glance</h3>
                <dl className="mt-4 space-y-3 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Team</dt>
                    <dd className="font-medium text-foreground">{role.team}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Location</dt>
                    <dd className="font-medium text-foreground">{role.location}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Type</dt>
                    <dd className="font-medium text-foreground">{role.type}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Salary</dt>
                    <dd className="font-medium text-foreground">Competitive</dd>
                  </div>
                </dl>
                <div className="mt-6">
                  <Button asChild className="w-full">
                    <a href="mailto:careers@ion.app">Apply now</a>
                  </Button>
                </div>
              </div>

              <div className="mt-4 rounded-2xl border border-border bg-card p-6">
                <h3 className="text-sm font-semibold text-foreground">Our process</h3>
                <ol className="mt-3 space-y-2 text-sm text-muted-foreground">
                  <li className="flex gap-2"><Check className="mt-0.5 h-3.5 w-3.5 text-success" />Intro call (30min)</li>
                  <li className="flex gap-2"><Check className="mt-0.5 h-3.5 w-3.5 text-success" />Work sample (paid)</li>
                  <li className="flex gap-2"><Check className="mt-0.5 h-3.5 w-3.5 text-success" />Pair session (1hr)</li>
                  <li className="flex gap-2"><Check className="mt-0.5 h-3.5 w-3.5 text-success" />Offer (~2 weeks total)</li>
                </ol>
              </div>
            </aside>
          </div>
        </Container>
      </main>
      <Footer />
    </>
  );
}
