import Link from "next/link";
import { ArrowLeft, Home } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { GlowOrb } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";
import { NoiseOverlay } from "@/components/primitives/glow";

/**
 * not-found — on-brand 404. Catches unknown routes and the explicit /404.
 */
export default function NotFound() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative flex min-h-[70vh] items-center overflow-hidden pt-32">
        <GlowOrb
          className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          color="var(--primary)"
          opacity={0.15}
          size={600}
        />
        <Container className="relative text-center">
          <Eyebrow>Error 404</Eyebrow>
          <h1 className="display-1 mt-4 text-balance">
            <span className="text-gradient-accent">Page not found.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-md text-lg text-muted-foreground">
            The page you&apos;re looking for doesn&apos;t exist — or it moved.
            Head back to the home page, or get in touch and we&apos;ll help you find what you need.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" className="group w-full sm:w-auto">
              <Link href="/">
                <Home className="mr-1.5 h-4 w-4" />
                Back to home
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="w-full sm:w-auto">
              <Link href="/contact">
                <ArrowLeft className="mr-1.5 h-4 w-4" />
                Contact support
              </Link>
            </Button>
          </div>
        </Container>
      </main>
      <Footer />
    </>
  );
}
