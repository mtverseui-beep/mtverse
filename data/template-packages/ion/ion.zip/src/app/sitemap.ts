import type { MetadataRoute } from "next";
import { siteConfig } from "@/config/site";
import { docs } from "@/config/docs";
import { posts } from "@/config/blog";
import { changelog } from "@/config/content";

/**
 * sitemap.ts — Next.js sitemap route.
 * Automatically served at /sitemap.xml. Includes all real pages.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const base = siteConfig.url;

  // Static top-level pages
  const staticPages: MetadataRoute.Sitemap = [
    { url: `${base}/`, lastModified: now, changeFrequency: "weekly", priority: 1 },
    { url: `${base}/pricing`, lastModified: now, changeFrequency: "monthly", priority: 0.9 },
    { url: `${base}/changelog`, lastModified: now, changeFrequency: "weekly", priority: 0.7 },
    { url: `${base}/contact`, lastModified: now, changeFrequency: "yearly", priority: 0.6 },
    { url: `${base}/about`, lastModified: now, changeFrequency: "monthly", priority: 0.7 },
    { url: `${base}/careers`, lastModified: now, changeFrequency: "weekly", priority: 0.6 },
    { url: `${base}/blog`, lastModified: now, changeFrequency: "weekly", priority: 0.8 },
    { url: `${base}/docs`, lastModified: now, changeFrequency: "weekly", priority: 0.8 },
    { url: `${base}/community`, lastModified: now, changeFrequency: "monthly", priority: 0.6 },
    { url: `${base}/security`, lastModified: now, changeFrequency: "monthly", priority: 0.5 },
    { url: `${base}/privacy`, lastModified: now, changeFrequency: "yearly", priority: 0.4 },
    { url: `${base}/terms`, lastModified: now, changeFrequency: "yearly", priority: 0.4 },
    { url: `${base}/dpa`, lastModified: now, changeFrequency: "yearly", priority: 0.4 },
    { url: `${base}/login`, lastModified: now, changeFrequency: "yearly", priority: 0.3 },
    { url: `${base}/signup`, lastModified: now, changeFrequency: "yearly", priority: 0.3 },
    // No-indexed auth-adjacent pages
    { url: `${base}/forgot-password`, lastModified: now, changeFrequency: "yearly", priority: 0.1 },
    { url: `${base}/verify-email`, lastModified: now, changeFrequency: "yearly", priority: 0.1 },
  ];

  // Dynamic doc pages
  const docPages: MetadataRoute.Sitemap = docs.map((d) => ({
    url: `${base}/docs/${d.slug}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.6,
  }));

  // Dynamic blog pages
  const blogPages: MetadataRoute.Sitemap = posts.map((p) => ({
    url: `${base}/blog/${p.slug}`,
    lastModified: new Date(p.date),
    changeFrequency: "monthly",
    priority: 0.6,
  }));

  // Dynamic changelog pages
  const changelogPages: MetadataRoute.Sitemap = changelog.map((c) => ({
    url: `${base}/changelog/${c.version}`,
    lastModified: new Date(c.date),
    changeFrequency: "yearly",
    priority: 0.4,
  }));

  return [...staticPages, ...docPages, ...blogPages, ...changelogPages];
}
