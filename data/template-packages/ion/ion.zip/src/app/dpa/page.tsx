import type { Metadata } from "next";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Data Processing Addendum",
  description: "DPA for Ion — terms governing the processing of customer personal data.",
  alternates: { canonical: "/dpa" },
};

export default function DpaPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12">
          <Eyebrow>Legal</Eyebrow>
          <h1 className="display-2 mt-4 text-balance">Data Processing Addendum</h1>
          <p className="mt-2 text-sm text-muted-foreground">Last updated: August 1, 2026</p>

          <article className="prose-ion mt-10 max-w-3xl">
            <p>
              This Data Processing Addendum (&ldquo;DPA&rdquo;) forms part of the Ion Terms of
              Service and reflects the parties&apos; agreement with respect to the processing of
              personal data under the GDPR, CCPA, and other applicable data protection laws.
            </p>

            <h2>1. Definitions</h2>
            <ul>
              <li><strong>&ldquo;Controller&rdquo;</strong> means the customer who determines the purposes and means of processing personal data.</li>
              <li><strong>&ldquo;Processor&rdquo;</strong> means Ion, which processes personal data on behalf of the Controller.</li>
              <li><strong>&ldquo;Personal Data&rdquo;</strong> means any information relating to an identified or identifiable natural person.</li>
              <li><strong>&ldquo;Sub-processor&rdquo;</strong> means a third party engaged by Ion to process Personal Data.</li>
            </ul>

            <h2>2. Roles and scope</h2>
            <p>
              Ion acts as Processor on behalf of the Controller (customer). The subject matter,
              duration, nature, and purpose of processing, types of Personal Data, and categories of
              data subjects are described in the Terms of Service and this DPA.
            </p>

            <h2>3. Processing instructions</h2>
            <p>
              Ion will process Personal Data only on documented instructions from the Controller,
              including with regard to international transfers, unless required by law. Ion will not
              process Personal Data for its own purposes.
            </p>

            <h2>4. Confidentiality</h2>
            <p>
              Ion ensures that personnel authorized to process Personal Data are bound by
              confidentiality obligations and have received appropriate training on data protection.
            </p>

            <h2>5. Security measures</h2>
            <p>Ion implements appropriate technical and organizational measures, including:</p>
            <ul>
              <li>AES-256 encryption at rest, TLS 1.3 in transit.</li>
              <li>Strict access controls with least-privilege defaults.</li>
              <li>Regular security assessments and penetration testing.</li>
              <li>Incident detection and response procedures.</li>
              <li>Employee background checks and security training.</li>
            </ul>
            <p>See our <a href="/security">Security page</a> for full details.</p>

            <h2>6. Sub-processors</h2>
            <p>
              Ion engages the following categories of sub-processors: cloud hosting (AWS), email
              delivery, error monitoring, and analytics. The current list of sub-processors is
              maintained at <a href="/security">our security page</a> and is updated with 30 days&apos;
              notice for new additions.
            </p>
            <p>
              Ion is liable for the performance of its sub-processors to the same extent as if Ion
              were performing the services directly.
            </p>

            <h2>7. Data subject rights</h2>
            <p>
              Ion assists the Controller in responding to data subject requests (access, correction,
              deletion, portability) by providing tools to export and delete data via the Ion API and
              dashboard. Additional assistance is available on request.
            </p>

            <h2>8. Personal data breach</h2>
            <p>
              Ion will notify the Controller of a personal data breach without undue delay, and in
              any case within 72 hours of becoming aware of it. Notification will include the nature
              of the breach, likely consequences, and measures taken or proposed.
            </p>

            <h2>9. Data protection impact assessments</h2>
            <p>
              Ion provides reasonable assistance to the Controller in conducting data protection
              impact assessments, where required by the GDPR.
            </p>

            <h2>10. Return and deletion</h2>
            <p>
              Upon termination of the Service, Ion will, at the Controller&apos;s choice, return or
              delete all Personal Data. Deletion occurs within 30 days of account closure, with
              backups purged within 90 days.
            </p>

            <h2>11. Audit rights</h2>
            <p>
              The Controller may audit Ion&apos;s compliance with this DPA, upon reasonable notice
              and not more than once per year. Ion will provide relevant documentation (including our
              SOC 2 Type II report) to reduce the need for direct audits.
            </p>

            <h2>12. International transfers</h2>
            <p>
              For transfers of Personal Data outside the EEA, UK, or Switzerland, Ion relies on the
              European Commission&apos;s Standard Contractual Clauses (SCCs), the UK International
              Data Transfer Addendum, or other recognized transfer mechanisms.
            </p>

            <h2>13. Contact</h2>
            <p>
              Our Data Protection Officer can be reached at <a href="mailto:dpo@ion.app">dpo@ion.app</a>.
            </p>
          </article>
        </Container>
      </main>
      <Footer />
    </>
  );
}
