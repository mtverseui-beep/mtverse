import type { MetadataRoute } from "next";
import { siteConfig } from "@/config/site";

/**
 * robots.ts — Next.js robots route.
 * Automatically served at /robots.txt.
 */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/"],
      },
    ],
    sitemap: `${siteConfig.url}/sitemap.xml`,
    host: siteConfig.url,
  };
}
