import type { Metadata } from "next";
import { Mail, MessageSquare, Clock, Shield } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { ContactForm } from "@/components/sections/contact-form";
import { Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Get in touch with the Ion team. Sales, support, partnerships, or just to say hi — we usually reply within a few hours.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12 md:py-20">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
            {/* Left: copy + trust signals */}
            <div>
              <Reveal>
                <Eyebrow>Contact</Eyebrow>
              </Reveal>
              <Reveal delay={0.05}>
                <h1 className="display-2 mt-4 text-balance">
                  Let&apos;s talk.
                </h1>
              </Reveal>
              <Reveal delay={0.1}>
                <p className="mt-6 text-lg text-muted-foreground">
                  Whether you&apos;re evaluating Ion for a 500-person org, need a security review,
                  or want to brainstorm an integration — we&apos;d love to hear from you.
                  Real humans on the other end, usually replying within a few hours.
                </p>
              </Reveal>

              <Reveal delay={0.15}>
                <dl className="mt-10 grid gap-4 sm:grid-cols-2">
                  <TrustCard
                    icon={<Clock className="h-5 w-5" />}
                    title="Reply time"
                    body="Under 4 hours on weekdays. Under 24 hours on weekends."
                  />
                  <TrustCard
                    icon={<Shield className="h-5 w-5" />}
                    title="Security"
                    body="SOC 2 Type II. Happy to share our report under NDA."
                  />
                  <TrustCard
                    icon={<Mail className="h-5 w-5" />}
                    title="Email"
                    body="hello@ion.app — for anything, anytime."
                  />
                  <TrustCard
                    icon={<MessageSquare className="h-5 w-5" />}
                    title="Community"
                    body="Join 4,000+ builders in our Discord — usually the fastest answer."
                  />
                </dl>
              </Reveal>
            </div>

            {/* Right: form */}
            <Reveal delay={0.2}>
              <div className="rounded-3xl border border-border bg-card p-6 md:p-8">
                <h2 className="text-lg font-semibold text-foreground">Send us a message</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  We&apos;ll get back to you within one business day.
                </p>
                <div className="mt-6">
                  <ContactForm />
                </div>
              </div>
            </Reveal>
          </div>
        </Container>
      </main>
      <Footer />
    </>
  );
}

function TrustCard({
  icon,
  title,
  body,
}: {
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card/40 p-4">
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary/15 text-primary">
          {icon}
        </span>
        <dt className="text-sm font-semibold text-foreground">{title}</dt>
      </div>
      <dd className="mt-2 text-sm text-muted-foreground">{body}</dd>
    </div>
  );
}
