import type { Metadata } from "next";
import { MessageCircle, Github, ArrowRight, Users } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { GlowOrb } from "@/components/primitives/glow";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "Community",
  description: "Join the Ion community — Discord, GitHub, and events for builders.",
  alternates: { canonical: "/community" },
};

const channels = [
  {
    icon: MessageCircle,
    title: "Discord",
    desc: "4,000+ builders helping each other ship. Get help in #help, share automations in #showcase, and meet the team in #ama.",
    cta: "Join Discord",
    href: siteConfig.social.discord,
    color: "text-info",
  },
  {
    icon: Github,
    title: "GitHub",
    desc: "Open-source projects, sample apps, and integrations. File issues, submit PRs, and star the repos you use.",
    cta: "Browse GitHub",
    href: siteConfig.social.github,
    color: "text-foreground",
  },
  {
    icon: Users,
    title: "Events",
    desc: "Office hours every Thursday, monthly workshops, and twice-yearly meetups. Past meetups: SF, NYC, London, Tokyo.",
    cta: "See upcoming events",
    href: "#events",
    color: "text-accent-warm",
  },
];

const events = [
  { name: "Office Hours", date: "Every Thursday", time: "11am PT", type: "Weekly" },
  { name: "Automation Workshop: Building a PR pipeline", date: "Aug 14, 2026", time: "10am PT", type: "Workshop" },
  { name: "Ion Meetup SF", date: "Sep 12, 2026", time: "6pm PT", type: "In-person" },
  { name: "Ion Meetup London", date: "Oct 3, 2026", time: "6pm BST", type: "In-person" },
];

export default function CommunityPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        {/* Hero */}
        <section className="relative overflow-hidden py-16 md:py-24">
          <GlowOrb className="left-1/2 top-0 -translate-x-1/2" color="var(--primary)" opacity={0.12} size={600} />
          <Container className="relative text-center">
            <Reveal><Eyebrow>Community</Eyebrow></Reveal>
            <Reveal delay={0.05}>
              <h1 className="display-1 mt-6 text-balance">
                Build with <span className="text-gradient-accent">4,000+ people</span> who get it.
              </h1>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
                The Ion community is where builders help each other ship — share automations, debug
                integrations, and shape the product roadmap. No sales pitches, no recruiter spam.
              </p>
            </Reveal>
          </Container>
        </section>

        {/* Channels */}
        <section className="py-16 md:py-24">
          <Container>
            <div className="grid gap-6 md:grid-cols-3">
              {channels.map((c, i) => {
                const Icon = c.icon;
                return (
                  <Reveal key={c.title} delay={i * 0.05}>
                    <div className="flex h-full flex-col rounded-2xl border border-border bg-card p-6">
                      <div className={`grid h-10 w-10 place-items-center rounded-xl bg-muted ${c.color}`}>
                        <Icon className="h-5 w-5" aria-hidden="true" />
                      </div>
                      <h3 className="mt-4 text-base font-semibold text-foreground">{c.title}</h3>
                      <p className="mt-2 flex-1 text-sm text-muted-foreground">{c.desc}</p>
                      <Button asChild variant="outline" size="sm" className="mt-4">
                        <a href={c.href} target="_blank" rel="noopener noreferrer">
                          {c.cta}
                          <ArrowRight className="ml-1.5 h-3.5 w-3.5" aria-hidden="true" />
                        </a>
                      </Button>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </Container>
        </section>

        {/* Events */}
        <section id="events" className="border-t border-border bg-muted/30 py-16 md:py-24">
          <Container>
            <div className="mx-auto max-w-3xl">
              <Reveal>
                <Eyebrow>Events</Eyebrow>
                <h2 className="display-2 mt-4 text-balance">Upcoming events</h2>
                <p className="mt-4 text-muted-foreground">
                  Office hours, workshops, and meetups. All online events are recorded and posted within 24 hours.
                </p>
              </Reveal>
              <ul className="mt-8 space-y-3">
                {events.map((e, i) => (
                  <Reveal as="li" key={e.name} delay={i * 0.05}>
                    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-card p-4">
                      <div>
                        <h3 className="text-sm font-semibold text-foreground">{e.name}</h3>
                        <p className="mt-0.5 text-xs text-muted-foreground">{e.date} · {e.time}</p>
                      </div>
                      <span className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
                        {e.type}
                      </span>
                    </div>
                  </Reveal>
                ))}
              </ul>
            </div>
          </Container>
        </section>

        {/* CTA */}
        <section className="py-20 text-center">
          <Container>
            <Reveal>
              <h2 className="display-3 text-balance">Ready to join?</h2>
              <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
                Discord is where it happens. Come say hi.
              </p>
              <Button asChild size="lg" className="mt-8">
                <a href={siteConfig.social.discord} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="mr-1.5 h-4 w-4" aria-hidden="true" />
                  Join the Discord
                </a>
              </Button>
            </Reveal>
          </Container>
        </section>
      </main>
      <Footer />
    </>
  );
}
