import type { Metadata } from "next";
import { Shield, Lock, FileCheck, Server, KeyRound, Eye, CheckCircle2 } from "lucide-react";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { GlowOrb } from "@/components/primitives/glow";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const metadata: Metadata = {
  title: "Security",
  description: "How Ion protects your data — encryption, compliance, access controls, and incident response.",
  alternates: { canonical: "/security" },
};

const controls = [
  { icon: Lock, title: "Encryption", desc: "AES-256 at rest, TLS 1.3 in transit. Customer-managed encryption keys available on Enterprise." },
  { icon: KeyRound, title: "Access control", desc: "SSO/SAML, SCIM provisioning, RBAC. Engineers don't have default access to customer data." },
  { icon: Eye, title: "Audit logging", desc: "Every action — user, API, and admin — is logged and retained for 13 months. Exportable via API." },
  { icon: Server, title: "Infrastructure", desc: "Hosted on AWS in US, EU, and APAC regions. Private VPC deployment available for Enterprise." },
  { icon: FileCheck, title: "Compliance", desc: "SOC 2 Type II, GDPR, CCPA. HIPAA available with BAA. Penetration tested quarterly by independent firms." },
  { icon: Shield, title: "Incident response", desc: "24/7 monitoring, sub-15-minute detection, public incident reports within 72 hours of resolution." },
];

const certifications = [
  { name: "SOC 2 Type II", status: "Current", date: "Renewed March 2026" },
  { name: "GDPR", status: "Compliant", date: "Ongoing" },
  { name: "CCPA", status: "Compliant", date: "Ongoing" },
  { name: "ISO 27001", status: "In progress", date: "Expected Q4 2026" },
  { name: "HIPAA", status: "Available with BAA", date: "On request" },
];

export default function SecurityPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        {/* Hero */}
        <section className="relative overflow-hidden py-16 md:py-24">
          <GlowOrb className="left-1/2 top-0 -translate-x-1/2" color="var(--primary)" opacity={0.10} size={600} />
          <Container className="relative text-center">
            <Reveal><Eyebrow>Security</Eyebrow></Reveal>
            <Reveal delay={0.05}>
              <h1 className="display-1 mt-6 text-balance">
                Your data, <span className="text-gradient-accent">protected by design.</span>
              </h1>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
                Security isn&apos;t a feature we added — it&apos;s the foundation we built on. From
                encryption to access controls to incident response, every layer of Ion is designed
                to keep your data safe.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <div className="mt-8 flex flex-wrap justify-center gap-2">
                <Badge variant="outline" className="border-success/30 text-success">
                  <CheckCircle2 className="mr-1 h-3 w-3" aria-hidden="true" /> SOC 2 Type II
                </Badge>
                <Badge variant="outline">GDPR</Badge>
                <Badge variant="outline">CCPA</Badge>
                <Badge variant="outline">HIPAA-ready</Badge>
              </div>
            </Reveal>
          </Container>
        </section>

        {/* Controls grid */}
        <section className="py-16 md:py-24">
          <Container>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {controls.map((c, i) => {
                const Icon = c.icon;
                return (
                  <Reveal key={c.title} delay={i * 0.05}>
                    <div className="h-full rounded-2xl border border-border bg-card p-6">
                      <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary">
                        <Icon className="h-5 w-5" aria-hidden="true" />
                      </div>
                      <h3 className="mt-4 text-base font-semibold text-foreground">{c.title}</h3>
                      <p className="mt-2 text-sm text-muted-foreground">{c.desc}</p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </Container>
        </section>

        {/* Certifications table */}
        <section className="border-t border-border bg-muted/30 py-16 md:py-24">
          <Container>
            <div className="mx-auto max-w-3xl">
              <Reveal>
                <Eyebrow>Certifications</Eyebrow>
                <h2 className="display-2 mt-4 text-balance">Compliance status</h2>
              </Reveal>
              <Reveal delay={0.1}>
                <div className="mt-8 overflow-hidden rounded-2xl border border-border bg-card">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border text-left text-xs text-muted-foreground">
                        <th className="p-4 font-medium">Standard</th>
                        <th className="p-4 font-medium">Status</th>
                        <th className="p-4 font-medium">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {certifications.map((c) => (
                        <tr key={c.name} className="border-b border-border last:border-0 text-sm">
                          <td className="p-4 font-medium text-foreground">{c.name}</td>
                          <td className="p-4">
                            <span className="inline-flex items-center gap-1 text-success">
                              <CheckCircle2 className="h-3 w-3" aria-hidden="true" />
                              {c.status}
                            </span>
                          </td>
                          <td className="p-4 text-muted-foreground">{c.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Reveal>
              <Reveal delay={0.15}>
                <p className="mt-4 text-sm text-muted-foreground">
                  Need our SOC 2 report or a custom security review?{" "}
                  <a href="/contact" className="text-primary hover:underline">Contact us</a> — we respond
                  within one business day.
                </p>
              </Reveal>
            </div>
          </Container>
        </section>

        {/* Trust CTA */}
        <section className="py-20 text-center">
          <Container>
            <Reveal>
              <h2 className="display-3 text-balance">Have a security question?</h2>
              <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
                Email us at <a href="mailto:security@ion.app" className="text-primary hover:underline">security@ion.app</a> or
                reach out via our contact form.
              </p>
              <Button asChild size="lg" className="mt-8">
                <a href="/contact">Contact our security team</a>
              </Button>
            </Reveal>
          </Container>
        </section>
      </main>
      <Footer />
    </>
  );
}
