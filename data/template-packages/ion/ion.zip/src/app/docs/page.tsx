import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Book, Code, Zap, Plug } from "lucide-react";
import { DocsLayout } from "@/components/docs/docs-layout";
import { NoiseOverlay } from "@/components/primitives/glow";
import { getDocsBySection } from "@/config/docs";

export const metadata: Metadata = {
  title: "Documentation",
  description: "Everything you need to build with Ion — guides, API reference, and integration docs.",
  alternates: { canonical: "/docs" },
};

const sectionIcons: Record<string, typeof Book> = {
  "Getting started": Book,
  "Core concepts": Zap,
  "Guides": ArrowRight,
  "API reference": Code,
  "Integrations": Plug,
};

export default function DocsIndexPage() {
  const sections = getDocsBySection();

  return (
    <>
      <NoiseOverlay />
      <DocsLayout>
        <div className="py-8">
          <h1 className="text-3xl font-semibold tracking-tight text-foreground">Documentation</h1>
          <p className="mt-2 text-muted-foreground">
            Everything you need to build with Ion — guides, API reference, and integration docs.
          </p>

          <div className="mt-10 space-y-10">
            {Object.entries(sections).map(([section, pages]) => {
              const Icon = sectionIcons[section] ?? Book;
              return (
                <section key={section}>
                  <div className="flex items-center gap-2">
                    <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary">
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <h2 className="text-lg font-semibold text-foreground">{section}</h2>
                  </div>
                  <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                    {pages.map((p) => (
                      <li key={p.slug}>
                        <Link
                          href={`/docs/${p.slug}`}
                          className="group block rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/40 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        >
                          <h3 className="text-sm font-semibold text-foreground group-hover:text-primary">
                            {p.title}
                          </h3>
                          <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
                            {p.description}
                          </p>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              );
            })}
          </div>
        </div>
      </DocsLayout>
    </>
  );
}
