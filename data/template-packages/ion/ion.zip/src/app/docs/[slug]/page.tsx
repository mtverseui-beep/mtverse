import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, Clock } from "lucide-react";
import { DocsLayout } from "@/components/docs/docs-layout";
import { NoiseOverlay } from "@/components/primitives/glow";
import { docs, getDocNav } from "@/config/docs";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return docs.map((d) => ({ slug: d.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const doc = docs.find((d) => d.slug === slug);
  if (!doc) return { title: "Not found" };
  return {
    title: doc.title,
    description: doc.description,
    alternates: { canonical: `/docs/${doc.slug}` },
  };
}

export default async function DocPage({ params }: Props) {
  const { slug } = await params;
  const doc = docs.find((d) => d.slug === slug);
  if (!doc) notFound();

  const { prev, next } = getDocNav(slug);

  return (
    <>
      <NoiseOverlay />
      <DocsLayout>
        <article className="py-8">
          <Link
            href="/docs"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            All docs
          </Link>

          <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
            <span className="rounded-full bg-primary/10 px-2 py-0.5 font-medium text-primary">
              {doc.section}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" aria-hidden="true" />
              5 min read
            </span>
          </div>

          <h1 className="mt-4 text-3xl font-semibold tracking-tight text-foreground">
            {doc.title}
          </h1>
          <p className="mt-2 text-lg text-muted-foreground">{doc.description}</p>

          <div
            className="prose-ion mt-8"
            dangerouslySetInnerHTML={{ __html: doc.body }}
          />

          {/* Prev / next nav */}
          <nav
            className="mt-12 grid gap-4 border-t border-border pt-8 sm:grid-cols-2"
            aria-label="Doc navigation"
          >
            {prev ? (
              <Link
                href={`/docs/${prev.slug}`}
                className="group rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <ArrowLeft className="h-3 w-3" aria-hidden="true" />
                  Previous
                </span>
                <span className="mt-1 block text-sm font-medium text-foreground group-hover:text-primary">
                  {prev.title}
                </span>
              </Link>
            ) : (
              <div />
            )}
            {next ? (
              <Link
                href={`/docs/${next.slug}`}
                className="group rounded-xl border border-border bg-card p-4 text-right transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <span className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
                  Next
                  <ArrowRight className="h-3 w-3" aria-hidden="true" />
                </span>
                <span className="mt-1 block text-sm font-medium text-foreground group-hover:text-primary">
                  {next.title}
                </span>
              </Link>
            ) : (
              <div />
            )}
          </nav>
        </article>
      </DocsLayout>
    </>
  );
}
