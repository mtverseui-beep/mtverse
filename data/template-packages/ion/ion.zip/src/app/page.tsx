import { Navbar } from "@/components/sections/navbar";
import { Hero } from "@/components/sections/hero";
import { LogoCloud } from "@/components/sections/logo-cloud";
import { ProblemSolution } from "@/components/sections/problem-solution";
import { FeatureGrid } from "@/components/sections/feature-grid";
import { HowItWorks } from "@/components/sections/how-it-works";
import { ProductShowcase } from "@/components/sections/product-showcase";
import { Testimonials } from "@/components/sections/testimonials";
import { Pricing } from "@/components/sections/pricing";
import { ComparisonTable } from "@/components/sections/comparison-table";
import { Integrations } from "@/components/sections/integrations";
import { FAQ } from "@/components/sections/faq";
import { FinalCTA } from "@/components/sections/final-cta";
import { Footer } from "@/components/sections/footer";
import { NoiseOverlay } from "@/components/primitives/glow";

/**
 * Home — Ion landing page.
 * One long-scroll page with all sections, in the order defined by spec §4.
 */
export default function Home() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative">
        <Hero />
        <LogoCloud />
        <ProblemSolution />
        <FeatureGrid />
        <HowItWorks />
        <ProductShowcase />
        <Testimonials />
        <Pricing />
        <ComparisonTable />
        <Integrations />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
