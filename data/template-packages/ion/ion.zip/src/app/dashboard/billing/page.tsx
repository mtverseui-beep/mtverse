import type { Metadata } from "next";
import { CreditCard, Download, Check } from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/dashboard-layout";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const metadata: Metadata = {
  title: "Billing",
  description: "Manage your subscription and invoices.",
  alternates: { canonical: "/dashboard/billing" },
  robots: { index: false, follow: false },
};

const invoices = [
  { date: "Jul 22, 2026", amount: "$57.00", plan: "Pro (3 seats)", id: "INV-2026-0722" },
  { date: "Jun 22, 2026", amount: "$57.00", plan: "Pro (3 seats)", id: "INV-2026-0622" },
  { date: "May 22, 2026", amount: "$38.00", plan: "Pro (2 seats)", id: "INV-2026-0522" },
  { date: "Apr 22, 2026", amount: "$38.00", plan: "Pro (2 seats)", id: "INV-2026-0422" },
  { date: "Mar 22, 2026", amount: "$19.00", plan: "Pro (1 seat)", id: "INV-2026-0322" },
];

export default function BillingPage() {
  return (
    <>
      <NoiseOverlay />
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">Billing</h1>
            <p className="text-sm text-muted-foreground">Manage your subscription and payment method.</p>
          </div>

          {/* Current plan */}
          <div className="rounded-xl border border-primary/30 bg-primary/5 p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-semibold text-foreground">Pro plan</h2>
                  <Badge>Active</Badge>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  $19 / seat / month · billed yearly · 3 seats
                </p>
                <p className="mt-1 text-xs text-primary">Renews on Aug 22, 2026</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">Change plan</Button>
                <Button variant="ghost" size="sm">Cancel</Button>
              </div>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              <div>
                <p className="text-xs text-muted-foreground">Monthly cost</p>
                <p className="mt-1 text-xl font-semibold text-foreground">$57.00</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Next invoice</p>
                <p className="mt-1 text-xl font-semibold text-foreground">Aug 22, 2026</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Payment method</p>
                <p className="mt-1 flex items-center gap-1.5 text-sm font-medium text-foreground">
                  <CreditCard className="h-4 w-4" aria-hidden="true" />
                  •••• 4242
                </p>
              </div>
            </div>
          </div>

          {/* Usage */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border border-border bg-card p-5">
              <h3 className="text-sm font-semibold text-foreground">Seats</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="text-2xl font-semibold text-foreground">3</span>
                <span className="text-sm text-muted-foreground">/ 10 included</span>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-primary" style={{ width: "30%" }} />
              </div>
            </div>
            <div className="rounded-xl border border-border bg-card p-5">
              <h3 className="text-sm font-semibold text-foreground">AI queries this month</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="text-2xl font-semibold text-foreground">4,127</span>
                <span className="text-sm text-muted-foreground">/ 10,000 included</span>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-accent-warm" style={{ width: "41%" }} />
              </div>
            </div>
          </div>

          {/* Invoices */}
          <div className="rounded-xl border border-border bg-card">
            <div className="border-b border-border p-5">
              <h2 className="text-sm font-semibold text-foreground">Invoice history</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border text-left text-xs text-muted-foreground">
                    <th className="p-4 font-medium">Date</th>
                    <th className="p-4 font-medium">Plan</th>
                    <th className="p-4 font-medium">Amount</th>
                    <th className="p-4 font-medium">Status</th>
                    <th className="p-4 font-medium text-right">Receipt</th>
                  </tr>
                </thead>
                <tbody>
                  {invoices.map((inv) => (
                    <tr key={inv.id} className="border-b border-border last:border-0 text-sm">
                      <td className="p-4 text-foreground">{inv.date}</td>
                      <td className="p-4 text-muted-foreground">{inv.plan}</td>
                      <td className="p-4 text-foreground">{inv.amount}</td>
                      <td className="p-4">
                        <span className="inline-flex items-center gap-1 text-xs text-success">
                          <Check className="h-3 w-3" aria-hidden="true" />
                          Paid
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <Button variant="ghost" size="sm">
                          <Download className="mr-1 h-3.5 w-3.5" aria-hidden="true" />
                          PDF
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </DashboardLayout>
    </>
  );
}
