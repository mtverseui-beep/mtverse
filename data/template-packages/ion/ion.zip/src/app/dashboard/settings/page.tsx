import type { Metadata } from "next";
import { DashboardLayout } from "@/components/dashboard/dashboard-layout";
import { SettingsPanel } from "@/components/dashboard/settings-panel";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Settings",
  description: "Manage your Ion workspace settings.",
  alternates: { canonical: "/dashboard/settings" },
  robots: { index: false, follow: false },
};

export default function DashboardSettingsPage() {
  return (
    <>
      <NoiseOverlay />
      <DashboardLayout>
        <SettingsPanel />
      </DashboardLayout>
    </>
  );
}
