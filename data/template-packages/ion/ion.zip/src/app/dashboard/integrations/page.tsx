import type { Metadata } from "next";
import Image from "next/image";
import { Plus, Check, Settings as SettingsIcon } from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/dashboard-layout";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { integrations } from "@/config/content";

export const metadata: Metadata = {
  title: "Integrations",
  description: "Connect Ion to your tools.",
  alternates: { canonical: "/dashboard/integrations" },
  robots: { index: false, follow: false },
};

// Mark a few as connected for the dashboard view
const connected = new Set(["slack", "github", "notion", "linear"]);

export default function IntegrationsPage() {
  return (
    <>
      <NoiseOverlay />
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">Integrations</h1>
            <p className="text-sm text-muted-foreground">
              {connected.size} of {integrations.length} shown · 80+ available via the API
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {integrations.map((i) => {
              const isConnected = connected.has(i.name.toLowerCase());
              return (
                <div
                  key={i.name}
                  className="flex flex-col rounded-xl border border-border bg-card p-5"
                >
                  <div className="flex items-start justify-between">
                    <Image
                      src={i.src}
                      alt={`${i.name} integration icon`}
                      width={40}
                      height={40}
                      className="h-10 w-10"
                    />
                    {isConnected && (
                      <Badge variant="outline" className="border-success/30 text-success">
                        <Check className="mr-1 h-3 w-3" aria-hidden="true" />
                        Connected
                      </Badge>
                    )}
                  </div>
                  <h3 className="mt-3 text-sm font-semibold text-foreground">{i.name}</h3>
                  <p className="mt-1 flex-1 text-xs text-muted-foreground">
                    {isConnected
                      ? "Syncing data and events in real-time."
                      : `Connect ${i.name} to bring its data into Ion.`}
                  </p>
                  <div className="mt-4">
                    {isConnected ? (
                      <Button variant="outline" size="sm" className="w-full">
                        <SettingsIcon className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
                        Configure
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm" className="w-full">
                        <Plus className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
                        Connect
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </DashboardLayout>
    </>
  );
}
