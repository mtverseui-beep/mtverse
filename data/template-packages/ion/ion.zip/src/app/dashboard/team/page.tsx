import type { Metadata } from "next";
import { Plus, MoreHorizontal } from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/dashboard-layout";
import { NoiseOverlay } from "@/components/primitives/glow";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const metadata: Metadata = {
  title: "Team",
  description: "Manage your workspace members.",
  alternates: { canonical: "/dashboard/team" },
  robots: { index: false, follow: false },
};

const members = [
  {
    name: "Maya Okafor",
    email: "maya@northwind.com",
    role: "Owner",
    initials: "MO",
    color: "bg-primary",
    lastActive: "Online now",
  },
  {
    name: "Dev Patel",
    email: "dev@northwind.com",
    role: "Admin",
    initials: "DP",
    color: "bg-accent-warm",
    lastActive: "2 hours ago",
  },
  {
    name: "Sara Lindqvist",
    email: "sara@northwind.com",
    role: "Member",
    initials: "SL",
    color: "bg-info",
    lastActive: "Yesterday",
  },
  {
    name: "Marcus Reyes",
    email: "marcus@northwind.com",
    role: "Member",
    initials: "MR",
    color: "bg-destructive",
    lastActive: "3 days ago",
  },
  {
    name: "Priya Anand",
    email: "priya@northwind.com",
    role: "Member",
    initials: "PA",
    color: "bg-accent-warm",
    lastActive: "1 week ago",
  },
];

export default function TeamPage() {
  return (
    <>
      <NoiseOverlay />
      <DashboardLayout>
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-foreground">Team</h1>
              <p className="text-sm text-muted-foreground">3 of 10 seats used on the Pro plan.</p>
            </div>
            <Button size="sm">
              <Plus className="mr-1.5 h-4 w-4" aria-hidden="true" />
              Invite member
            </Button>
          </div>

          {/* Pending invitations */}
          <div className="rounded-xl border border-dashed border-border bg-muted/30 p-4">
            <p className="text-sm font-medium text-foreground">2 invitations pending</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Sent to jonas@northwind.com and aisha@northwind.com · expires in 5 days
            </p>
          </div>

          {/* Members table */}
          <div className="rounded-xl border border-border bg-card">
            <div className="border-b border-border p-5">
              <h2 className="text-sm font-semibold text-foreground">Members</h2>
            </div>
            <ul className="divide-y divide-border">
              {members.map((m) => (
                <li key={m.email} className="flex items-center gap-4 p-4">
                  <div
                    className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-xs font-semibold text-primary-foreground ${m.color}`}
                  >
                    {m.initials}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="truncate text-sm font-medium text-foreground">{m.name}</p>
                      {m.role === "Owner" && <Badge variant="outline">Owner</Badge>}
                      {m.role === "Admin" && <Badge variant="secondary">Admin</Badge>}
                    </div>
                    <p className="truncate text-xs text-muted-foreground">{m.email}</p>
                  </div>
                  <div className="hidden text-xs text-muted-foreground sm:block">{m.lastActive}</div>
                  <button
                    type="button"
                    aria-label={`Actions for ${m.name}`}
                    className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </DashboardLayout>
    </>
  );
}
