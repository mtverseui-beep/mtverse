import type { Metadata } from "next";
import { DashboardLayout } from "@/components/dashboard/dashboard-layout";
import { DashboardOverview } from "@/components/dashboard/overview";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Dashboard",
  description: "Your Ion workspace overview.",
  alternates: { canonical: "/dashboard" },
  robots: { index: false, follow: false },
};

export default function DashboardPage() {
  return (
    <>
      <NoiseOverlay />
      <DashboardLayout>
        <DashboardOverview />
      </DashboardLayout>
    </>
  );
}
