import type { Metadata } from "next";
import { Zap, CheckCircle2, Users, Activity as ActivityIcon, FileText, GitPullRequest } from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/dashboard-layout";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Activity",
  description: "Full activity log for your workspace.",
  alternates: { canonical: "/dashboard/activity" },
  robots: { index: false, follow: false },
};

const fullFeed = [
  { icon: Zap, color: "text-primary", title: "Automation ran: Standup summary", desc: "Posted #engineering-standup with 3 updates", time: "2 min ago", user: "Ion AI" },
  { icon: CheckCircle2, color: "text-success", title: "Draft approved", desc: "Maya approved the Q3 PRD draft", time: "18 min ago", user: "Maya Okafor" },
  { icon: Users, color: "text-info", title: "New team member", desc: "Dev Patel joined the workspace", time: "1 hour ago", user: "System" },
  { icon: Zap, color: "text-primary", title: "Automation ran: Slack triage", desc: "Categorized 14 messages in #support", time: "2 hours ago", user: "Ion AI" },
  { icon: ActivityIcon, color: "text-accent-warm", title: "Integration health", desc: "GitHub reconnected after brief outage", time: "4 hours ago", user: "System" },
  { icon: FileText, color: "text-info", title: "Doc created", desc: "Sara created 'Launch readiness checklist'", time: "5 hours ago", user: "Sara Lindqvist" },
  { icon: GitPullRequest, color: "text-accent-warm", title: "PR linked", desc: "PR #2847 linked to ticket ENG-1203", time: "Yesterday", user: "Marcus Reyes" },
  { icon: Zap, color: "text-primary", title: "Automation ran: Weekly digest", desc: "Emailed digest to 28 members", time: "Yesterday", user: "Ion AI" },
  { icon: CheckCircle2, color: "text-success", title: "Automation recovered", desc: "Linear step retried and succeeded after 2 failures", time: "Yesterday", user: "Ion AI" },
  { icon: FileText, color: "text-info", title: "Doc updated", desc: "Priya updated 'API reference v2'", time: "2 days ago", user: "Priya Anand" },
];

export default function ActivityPage() {
  return (
    <>
      <NoiseOverlay />
      <DashboardLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">Activity</h1>
            <p className="text-sm text-muted-foreground">Everything happening in your workspace.</p>
          </div>

          {/* Filter chips (visual) */}
          <div className="flex flex-wrap gap-2">
            {["All", "Automations", "Documents", "Team", "Integrations"].map((f, i) => (
              <button
                key={f}
                type="button"
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                  i === 0
                    ? "bg-primary text-primary-foreground"
                    : "border border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          {/* Activity feed — full */}
          <div className="rounded-xl border border-border bg-card">
            <ul className="divide-y divide-border">
              {fullFeed.map((item, i) => {
                const Icon = item.icon;
                return (
                  <li key={i} className="flex items-start gap-3 p-4">
                    <div className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-muted ${item.color}`}>
                      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-foreground">{item.title}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{item.desc}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-xs text-muted-foreground">{item.time}</p>
                      <p className="mt-0.5 text-xs font-medium text-foreground">{item.user}</p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </DashboardLayout>
    </>
  );
}
