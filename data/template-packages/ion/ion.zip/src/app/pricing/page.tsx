import type { Metadata } from "next";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Pricing } from "@/components/sections/pricing";
import { FAQ } from "@/components/sections/faq";
import { FinalCTA } from "@/components/sections/final-cta";
import { Container, Eyebrow } from "@/components/primitives/section";
import { NoiseOverlay } from "@/components/primitives/glow";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Simple, transparent pricing for teams of every size. Start free, upgrade when you're ready, cancel anytime.",
  alternates: { canonical: "/pricing" },
};

export default function PricingPage() {
  return (
    <>
      <NoiseOverlay />
      <Navbar />
      <main id="main" className="relative pt-32">
        <Container className="py-12 text-center">
          <Eyebrow>Pricing</Eyebrow>
          <h1 className="display-1 mt-4 text-balance">
            Pricing that scales with you.
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
            Start free. Upgrade when you&apos;re ready. Cancel anytime. No credit card required to start.
            Every plan includes the full feature set — the difference is scale and support.
          </p>
        </Container>

        <Pricing />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
