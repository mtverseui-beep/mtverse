/**
 * content.ts — Ion marketing copy & data, typed.
 * ───────────────────────────────────────────────────────────────────────────
 * Every section's copy, features, testimonials, pricing tiers, FAQ entries,
 * and changelog entries live here as exported typed arrays.
 * Buyers: change the COPY without touching component code.
 *
 * Avatar images are self-hosted under /public/avatars/*.svg.
 * See scripts/generate-assets.mjs to regenerate placeholders.
 */

import {
  Sparkles,
  Zap,
  Workflow,
  Shield,
  LineChart,
  Bot,
  Plug,
  type LucideIcon,
} from "lucide-react";

/* ───────────────────────── HERO ───────────────────────── */

export const hero = {
  eyebrow: "Introducing Ion 2.0",
  /** Two-line oversized H1. Plain text — line break via CSS, not \n. */
  headlineLead: "Stop wrestling tools.",
  headlineHighlight: "Start shipping outcomes.",
  subhead:
    "Ion is the AI workspace that unifies your apps, automates the busywork, and surfaces what actually matters — so your team moves faster without the noise.",
  primaryCta: { label: "Start free", href: "/contact" },
  secondaryCta: { label: "Watch demo", href: "#demo" },
  socialProof: {
    label: "Trusted by 4,000+ teams",
    avatars: [
      "/avatars/a1.svg",
      "/avatars/a2.svg",
      "/avatars/a3.svg",
      "/avatars/a4.svg",
      "/avatars/a5.svg",
    ],
  },
} as const;

/* ─────────────────── LOGO CLOUD / SOCIAL PROOF ───────── */

export const logoCloud: { name: string; src: string }[] = [
  { name: "Vertex", src: "/logos/vertex.svg" },
  { name: "Northwind", src: "/logos/northwind.svg" },
  { name: "Lumen", src: "/logos/lumen.svg" },
  { name: "Quanta", src: "/logos/quanta.svg" },
  { name: "Helio", src: "/logos/helio.svg" },
  { name: "Cobalt", src: "/logos/cobalt.svg" },
  { name: "Forge", src: "/logos/forge.svg" },
  { name: "Aperture", src: "/logos/aperture.svg" },
];

/* ─────────────────── PROBLEM → SOLUTION ─────────────── */

export const problemSolution = {
  problems: [
    "20+ tabs open, none of them talking to each other.",
    "Status meetings that could have been a sentence.",
    "An inbox that punishes you for taking a weekend.",
  ],
  solution:
    "Ion replaces the patchwork with one workspace — your tools, your context, and a genuinely useful AI, all in one place.",
  stats: [
    { label: "Hours saved per week", value: 12.5, suffix: " hrs", decimals: 1 },
    { label: "Faster cycle time", value: 2.4, suffix: "×", decimals: 1 },
    { label: "Apps consolidated", value: 9, suffix: "+", decimals: 0 },
  ],
} as const;

/* ─────────────────── FEATURE GRID (BENTO) ───────────── */

export interface Feature {
  /** lucide icon component */
  icon: LucideIcon;
  title: string;
  description: string;
  /** bento span — controls card size in the asymmetric grid */
  span: "1x1" | "2x1" | "1x2" | "2x2";
  /** optional embedded visual kind — drives which mini-component renders */
  visual?: "chart" | "toggle" | "code" | "search" | "workflow" | "none";
}

export const features: Feature[] = [
  {
    icon: Bot,
    title: "An AI that knows your context",
    description:
      "Ion reads your docs, tickets, and chats — so when you ask, it already knows what 'the launch' means.",
    span: "2x2",
    visual: "search",
  },
  {
    icon: Workflow,
    title: "Automations that don't break",
    description:
      "Wire up multi-step flows visually. Ion recovers gracefully when an API hiccups.",
    span: "2x1",
    visual: "workflow",
  },
  {
    icon: Zap,
    title: "Instant answers",
    description: "Sub-200ms semantic search across everything your team has ever written.",
    span: "1x1",
    visual: "none",
  },
  {
    icon: LineChart,
    title: "Live metrics that matter",
    description: "Real-time dashboards built from the work you're already doing — no manual entry.",
    span: "2x1",
    visual: "chart",
  },
  {
    icon: Shield,
    title: "SOC 2 from day one",
    description: "Audit logs, SSO/SAML, and granular roles. Enterprise-ready out of the box.",
    span: "1x1",
    visual: "none",
  },
  {
    icon: Plug,
    title: "Connects to everything",
    description: "Native integrations with 80+ tools — and a typed API for the rest.",
    span: "1x1",
    visual: "none",
  },
  {
    icon: Sparkles,
    title: "Drafts that don't suck",
    description: "Ion writes the first 80% — PRDs, release notes, standups — in your team's voice.",
    span: "2x1",
    visual: "code",
  },
];

/* ─────────────────── HOW IT WORKS ───────────────────── */

export const howItWorks: { step: number; title: string; description: string }[] = [
  {
    step: 1,
    title: "Connect your stack",
    description: "OAuth into Slack, GitHub, Notion, Linear, and 80+ more in under two minutes.",
  },
  {
    step: 2,
    title: "Let Ion learn",
    description: "Ion indexes your context — docs, threads, tickets — and builds a living knowledge graph.",
  },
  {
    step: 3,
    title: "Automate the busywork",
    description: "Describe the outcome. Ion wires up the workflow, schedules it, and watches it for you.",
  },
  {
    step: 4,
    title: "Ship and observe",
    description: "Live dashboards show what's moving, what's stuck, and what Ion handled while you slept.",
  },
];

/* ─────────────────── PRODUCT SHOWCASE TABS ──────────── */

export interface ShowcaseTab {
  id: string;
  label: string;
  title: string;
  description: string;
  bullets: string[];
  /** product screenshot — self-hosted SVG mockup */
  image: string;
}

export const showcase: ShowcaseTab[] = [
  {
    id: "workspace",
    label: "Workspace",
    title: "One pane for everything",
    description:
      "Docs, tickets, chats, and metrics in a single keyboard-driven surface — no more tab Tetris.",
    bullets: [
      "Command palette on ⌘K opens anything in 2 keystrokes",
      "Pin live views next to long-form docs",
      "Inline AI edits with track-changes",
    ],
    image: "/products/workspace.svg",
  },
  {
    id: "automations",
    label: "Automations",
    title: "Visual flows, real reliability",
    description:
      "Drag together triggers, conditions, and actions. Ion retries failed steps and tells you why.",
    bullets: [
      "80+ native triggers and actions",
      "Branching, loops, and error paths",
      "Per-step audit log and rollback",
    ],
    image: "/products/automations.svg",
  },
  {
    id: "insights",
    label: "Insights",
    title: "Metrics from motion",
    description:
      "Dashboards that update themselves from the work your team is already doing in Ion.",
    bullets: [
      "Cycle time, throughput, and stuck work — live",
      "Custom charts without SQL",
      "Weekly digest emailed every Monday",
    ],
    image: "/products/insights.svg",
  },
];

/* ─────────────────── TESTIMONIALS ───────────────────── */

export interface Testimonial {
  quote: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  rating?: number;
  metric?: { value: string; label: string };
}

export const heroTestimonial: Testimonial = {
  quote:
    "We replaced four tools with Ion and got a fifth one free — an AI that actually knows what we're working on. Our cycle time dropped by a third in the first month, and the team stopped dreading Mondays.",
  name: "Maya Okafor",
  role: "VP Engineering",
  company: "Northwind",
  avatar: "/avatars/t1.svg",
  rating: 5,
};

export const testimonials: Testimonial[] = [
  {
    quote: "Ion's command palette is faster than my muscle memory for Slack. That's saying something.",
    name: "Dev Patel",
    role: "Staff Engineer",
    company: "Quanta",
    avatar: "/avatars/t2.svg",
    rating: 5,
    metric: { value: "2.4×", label: "faster cycle time" },
  },
  {
    quote: "The automations recovered from a GitHub outage without me touching anything. I didn't even know it broke.",
    name: "Sara Lindqvist",
    role: "Eng Manager",
    company: "Lumen",
    avatar: "/avatars/t3.svg",
    rating: 5,
  },
  {
    quote: "Onboarding a new engineer used to take two weeks. Now it's two days — Ion answers the dumb questions.",
    name: "Marcus Reyes",
    role: "CTO",
    company: "Forge",
    avatar: "/avatars/t4.svg",
    rating: 5,
    metric: { value: "85%", label: "faster onboarding" },
  },
  {
    quote: "I trust Ion's weekly digest more than I trust my own status updates. It's that accurate.",
    name: "Priya Anand",
    role: "Head of Product",
    company: "Helio",
    avatar: "/avatars/t5.svg",
    rating: 5,
  },
  {
    quote: "We finally retired our internal Slack bot. Ion does what three of our scripts used to do.",
    name: "Jonas Weber",
    role: "Platform Lead",
    company: "Cobalt",
    avatar: "/avatars/t6.svg",
    rating: 5,
  },
  {
    quote: "The AI drafts are good enough that I just edit instead of writing from scratch. Saved me hours every week.",
    name: "Aisha Traoré",
    role: "PM",
    company: "Aperture",
    avatar: "/avatars/t7.svg",
    rating: 5,
    metric: { value: "12 hrs", label: "saved weekly" },
  },
  {
    quote: "Migrated 8,000 docs in an afternoon. Ion reorganized them better than we ever had.",
    name: "Chen Mei",
    role: "Knowledge Manager",
    company: "Vertex",
    avatar: "/avatars/t8.svg",
    rating: 5,
  },
];

/* ─────────────────── PRICING ────────────────────────── */

export interface PricingTier {
  name: string;
  description: string;
  monthly: number;
  yearly: number;
  highlighted?: boolean;
  badge?: string;
  cta: { label: string; href: string };
  features: string[];
}

export const pricingTiers: PricingTier[] = [
  {
    name: "Starter",
    description: "For solo builders and small side-projects.",
    monthly: 0,
    yearly: 0,
    cta: { label: "Start free", href: "/contact" },
    features: [
      "Up to 3 collaborators",
      "5 active automations",
      "7-day context history",
      "Community support",
      "10 integrations",
    ],
  },
  {
    name: "Pro",
    description: "For growing teams that live in Ion all day.",
    monthly: 24,
    yearly: 19,
    highlighted: true,
    badge: "Most popular",
    cta: { label: "Start free", href: "/contact" },
    features: [
      "Unlimited collaborators",
      "Unlimited automations",
      "Full context history",
      "Priority support",
      "All 80+ integrations",
      "Custom AI prompts",
      "Advanced dashboards",
    ],
  },
  {
    name: "Enterprise",
    description: "For organizations with security and scale needs.",
    monthly: -1, // -1 = "Contact us"
    yearly: -1,
    cta: { label: "Contact sales", href: "/contact" },
    features: [
      "Everything in Pro",
      "SAML SSO & SCIM",
      "SOC 2 Type II report",
      "Dedicated success manager",
      "99.95% uptime SLA",
      "Custom data residency",
    ],
  },
];

export const pricingFaq: { q: string; a: string }[] = [
  {
    q: "Can I change plans later?",
    a: "Yes — upgrade or downgrade anytime. Changes prorate automatically, no contracts.",
  },
  {
    q: "Is there a free trial of Pro?",
    a: "Every account starts on the Pro plan free for 14 days. No credit card required.",
  },
  {
    q: "What counts as a collaborator?",
    a: "Anyone with login access to your workspace. Read-only viewers are always free.",
  },
];

/* ─────────────────── COMPARISON TABLE ───────────────── */

export const comparison = {
  features: [
    { label: "Unified workspace (docs, tickets, chat)", ion: true, manual: false, legacy: false },
    { label: "Context-aware AI assistant", ion: true, manual: false, legacy: "partial" },
    { label: "Visual automation builder", ion: true, manual: false, legacy: true },
    { label: "Auto-recovery on integration failures", ion: true, manual: false, legacy: false },
    { label: "Live dashboards from team activity", ion: true, manual: false, legacy: false },
    { label: "SOC 2 Type II", ion: true, manual: "n/a", legacy: "partial" },
    { label: "Setup time", ion: "< 2 min", manual: "weeks", legacy: "days" },
    { label: "Monthly cost per seat (typical)", ion: "$19", manual: "$60+", legacy: "$35" },
  ] as { label: string; ion: boolean | string; manual: boolean | string; legacy: boolean | string }[],
};

/* ─────────────────── INTEGRATIONS ───────────────────── */

export const integrations: { name: string; src: string }[] = [
  { name: "Slack", src: "/integrations/slack.svg" },
  { name: "GitHub", src: "/integrations/github.svg" },
  { name: "Notion", src: "/integrations/notion.svg" },
  { name: "Linear", src: "/integrations/linear.svg" },
  { name: "Figma", src: "/integrations/figma.svg" },
  { name: "Zapier", src: "/integrations/zapier.svg" },
  { name: "Postgres", src: "/integrations/postgres.svg" },
  { name: "S3", src: "/integrations/s3.svg" },
  { name: "Stripe", src: "/integrations/stripe.svg" },
  { name: "Vercel", src: "/integrations/vercel.svg" },
  { name: "OpenAI", src: "/integrations/openai.svg" },
  { name: "Anthropic", src: "/integrations/anthropic.svg" },
];

/* ─────────────────── FAQ ────────────────────────────── */

export const faq: { q: string; a: string }[] = [
  {
    q: "How is Ion different from a chat bot bolted onto my existing tools?",
    a: "Chat bots are stateless — they forget everything between messages. Ion maintains a living knowledge graph of your team's context: every doc, ticket, and thread is indexed and queryable. When you ask Ion something, it answers with citations from your actual work, not the open internet.",
  },
  {
    q: "What does deployment look like?",
    a: "Ion is fully managed — sign up, OAuth into your tools, and you're running in under two minutes. Enterprise customers can choose data residency in US, EU, or APAC regions, and we offer a private VPC deployment option for regulated industries.",
  },
  {
    q: "How do you handle data security and privacy?",
    a: "Ion is SOC 2 Type II certified. All data is encrypted at rest (AES-256) and in transit (TLS 1.3). We never train foundation models on your data — your context stays in your tenant. Full audit logs, SSO/SAML, SCIM provisioning, and granular role-based access control are available on Pro and Enterprise plans.",
  },
  {
    q: "Can I migrate from my current setup without losing history?",
    a: "Yes. Ion imports docs, tickets, and chat history from Notion, Confluence, Jira, Linear, Slack, and GitHub. Most migrations complete in under an hour. We preserve timestamps, authors, and threading. Enterprise customers get white-glove migration support included.",
  },
  {
    q: "What are the technical requirements?",
    a: "For users: any modern browser (Chrome, Firefox, Safari, Edge — last 2 versions). For integrations: admin access to the tools you want to connect. Ion is fully server-side — there's nothing to install on user devices. Native desktop apps for macOS and Windows are in beta.",
  },
  {
    q: "What happens to my automations if an integration goes down?",
    a: "Ion retries failed steps with exponential backoff, queues subsequent steps, and notifies you only if a step can't recover within your configured window. Every automation has a per-step audit log and one-click rollback to the last known good state.",
  },
  {
    q: "Do you offer educational or non-profit discounts?",
    a: "Yes — 50% off Pro for accredited educational institutions and registered non-profits. Reach out via the contact form with your details and we'll set it up within one business day.",
  },
  {
    q: "What's your refund policy?",
    a: "If Ion isn't working for you in the first 30 days, we'll refund 100% — no questions, no exit interviews. After 30 days, refunds are pro-rated for unused time on annual plans.",
  },
];

/* ─────────────────── CHANGELOG ──────────────────────── */

export interface ChangelogEntry {
  version: string;
  date: string; // ISO date
  tag: "New" | "Improved" | "Fix" | "Security";
  title: string;
  notes: string[];
}

export const changelog: ChangelogEntry[] = [
  {
    version: "2.0.0",
    date: "2026-07-22",
    tag: "New",
    title: "Ion 2.0 — the workspace rebuild",
    notes: [
      "Brand-new unified workspace surface with command palette (⌘K).",
      "Context-aware AI assistant with citations.",
      "Visual automation builder with branching and error paths.",
      "Live dashboards rebuilt on a streaming metrics engine.",
    ],
  },
  {
    version: "1.9.3",
    date: "2026-07-08",
    tag: "Improved",
    title: "Faster semantic search",
    notes: [
      "Median query latency dropped from 340ms to 180ms.",
      "Index rebuilds now run incrementally — no more nightly pauses.",
    ],
  },
  {
    version: "1.9.2",
    date: "2026-06-30",
    tag: "Fix",
    title: "Slack thread deep-links",
    notes: [
      "Fixed a regression where Slack thread links opened the channel instead of the thread.",
      "Backfilled the last 30 days of thread references for affected workspaces.",
    ],
  },
  {
    version: "1.9.1",
    date: "2026-06-21",
    tag: "Security",
    title: "Quarterly dependency audit",
    notes: [
      "Patched 3 medium-severity dev-dependencies (no production impact).",
      "Rotated internal signing keys per our 90-day policy.",
    ],
  },
  {
    version: "1.9.0",
    date: "2026-06-12",
    tag: "New",
    title: "Native Anthropic integration",
    notes: [
      "Added Claude as a first-class AI provider — switch in workspace settings.",
      "Per-workspace model routing: use different providers for different tasks.",
    ],
  },
];
