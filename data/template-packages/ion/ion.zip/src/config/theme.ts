/**
 * theme.ts — Ion accent color & tunable design tokens.
 * ───────────────────────────────────────────────────────────────────────────
 * Buyers: this is "the one place" to change the brand color.
 *
 * The CSS variables in src/app/globals.css are the source of truth at runtime
 * (so Tailwind utilities like `bg-primary` resolve correctly). This file
 * exists to (a) document those tokens in plain JS, and (b) expose a
 * `accentColor` constant for places that need the literal hex (e.g. inline
 * SVG fills, the OG image generator, JSON-LD).
 *
 * To switch to Option B (cobalt + coral): change ACCENT and ACCENT_WARM here,
 * then update the matching `--primary`, `--accent-warm`, `--ring`, and
 * `--glow` variables in globals.css. That's it — every component picks it up.
 */

export const accentColor = {
  /** Primary hero accent — used for CTAs, key icons, one gradient glow. */
  primary: "#C6FF3D",
  /** Secondary warm accent — used sparingly for warmth (gradient endpoints). */
  warm: "#FF8A3D",
  /** Near-black base (dark mode primary identity). */
  baseDark: "#0B0C10",
  /** Warm off-white base (light mode). */
  baseLight: "#FAFAF8",
} as const;

export type AccentColor = typeof accentColor;

/**
 * Tunable design tokens — mirrored from globals.css for documentation.
 * Change in globals.css to take effect at runtime.
 */
export const designTokens = {
  radius: "0.75rem",
  containerMaxWidth: "80rem", // max-w-7xl
  containerPadding: "1.5rem", // px-6
  glassBlur: "16px",
  glowBlur: "80px",
  glowOpacity: 0.12,
  noiseOpacity: 0.025,
  motionDuration: {
    fast: "200ms",
    normal: "400ms",
    slow: "600ms",
  },
  motionEasing: "cubic-bezier(0.22, 1, 0.36, 1)", // ease-out-quint
  revealStagger: 80, // ms between sibling reveals
} as const;
