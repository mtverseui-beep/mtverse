/**
 * blog.ts — Ion blog content.
 * Each post is a standalone object with title, excerpt, date, author,
 * reading time, tags, and HTML body. In a real app, swap this for MDX files
 * or a CMS — the page components don't care where the data comes from.
 */

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  date: string; // ISO date
  author: { name: string; role: string; initials: string };
  readingTime: string;
  tags: string[];
  body: string;
}

export const posts: BlogPost[] = [
  {
    slug: "ion-2-0-the-workspace-rebuild",
    title: "Ion 2.0: the workspace rebuild",
    excerpt:
      "Why we threw away our v1 UI, what we built instead, and the three principles that guided every decision.",
    date: "2026-07-22",
    author: { name: "Maya Okafor", role: "CEO", initials: "MO" },
    readingTime: "8 min",
    tags: ["Product", "Release"],
    body: `
<h2>Why we threw it all away</h2>
<p>In March, we looked at our usage data and admitted what we'd been avoiding: v1 wasn't working. People signed up, connected their tools, asked one question, and never came back. The activation funnel had a cliff at day 2.</p>
<p>We talked to 40 users who churned. The pattern was the same: Ion was useful for one-off questions, but it wasn't where they <em>worked</em>. It was a fancy search box bolted onto their existing stack — not a replacement for it.</p>
<p>So we decided to start over. Not a redesign — a rebuild. A single surface where you could actually do your work, with an AI that knew what you were working on.</p>

<h2>The three principles</h2>
<p>Everything in v2 traces back to three decisions we made in week one:</p>

<h3>1. One surface, not many</h3>
<p>v1 had separate views for docs, tickets, chats, and insights. You had to know which one to look in. v2 has one workspace surface — everything you care about, in one keyboard-driven place. Hit ⌘K and you're anywhere in 2 keystrokes.</p>

<h3>2. The AI has to know your context</h3>
<p>A chatbot that doesn't know your work is just a slower Google. v2's AI reads your docs, tickets, and threads — so when you ask "what's blocking the launch?", it answers with citations from your actual work, not the open internet.</p>

<h3>3. Automations have to be reliable</h3>
<p>v1 automations broke constantly. A GitHub API change, a renamed Slack channel, a rate limit — and the whole thing fell over silently. v2 has per-step audit logs, automatic retries with exponential backoff, and one-click rollback to the last known good state. It's boring engineering, but it's the difference between trusting an automation and dreading it.</p>

<h2>What we shipped</h2>
<p>Four months, 28 people, zero feature freezes. Here's what's new in v2:</p>
<ul>
  <li>The unified workspace surface with command palette (⌘K).</li>
  <li>Context-aware AI with citations.</li>
  <li>Visual automation builder with branching and error paths.</li>
  <li>Live dashboards rebuilt on a streaming metrics engine.</li>
  <li>Native Anthropic integration with per-workspace model routing.</li>
</ul>

<h2>What's next</h2>
<p>We're already working on v2.1 — native desktop apps, a public API for automations, and a bunch of quality-of-life improvements our users have been asking for. Shipping weekly, as always.</p>
<p>If you've been away from Ion for a while, now's a good time to come back. The product you remember is gone. We think you'll like what replaced it.</p>
`,
  },
  {
    slug: "how-we-built-our-context-engine",
    title: "How we built our context engine",
    excerpt:
      "The technical story behind Ion's knowledge graph — indexing 4M+ docs, tickets, and threads with sub-200ms query latency.",
    date: "2026-07-08",
    author: { name: "Dev Patel", role: "CTO", initials: "DP" },
    readingTime: "12 min",
    tags: ["Engineering", "AI"],
    body: `
<h2>The problem</h2>
<p>Ion's AI is only as good as the context it can draw from. If you ask "what's blocking the launch?", the AI needs to find every relevant doc, ticket, and thread in your workspace — fast. For a 200-person engineering org, that's 4M+ documents and growing.</p>
<p>Our constraint: <strong>p95 query latency under 200ms</strong>, with fresh data (no more than 60 seconds stale), across a graph that updates in real-time as your team works.</p>

<h2>Why we didn't use a vector database</h2>
<p>We started with Pinecone. It worked fine for semantic search, but it couldn't do the structured filtering we needed (e.g., "only docs from the last 30 days, in the engineering channel, that mention the launch"). We'd have to fetch a large candidate set and filter in application code — slow and expensive.</p>
<p>We tried Postgres + pgvector next. Better — we could combine semantic and structured filters in a single query. But as our corpus grew past 1M docs, query latency crept up. Index rebuilds became painful.</p>

<h2>The architecture we settled on</h2>
<p>Three pieces:</p>
<ol>
  <li><strong>Postgres for structured data</strong> — doc metadata, ticket metadata, thread metadata. Indexed on workspace_id, channel, author, created_at.</li>
  <li><strong>pgvector for embeddings</strong> — stored in the same Postgres instance, queried with HNSW indexes.</li>
  <li><strong>Redis for real-time updates</strong> — when a new message lands in Slack, we update Redis immediately (so the next query sees it), and asynchronously write to Postgres + recompute embeddings.</li>
</ol>

<h2>The query path</h2>
<p>When you ask Ion a question:</p>
<ol>
  <li>We embed your query with a small, fast model (50ms).</li>
  <li>We do a hybrid query in Postgres: semantic similarity (HNSW) + structured filters (B-tree). Returns top 50 candidates in 80–120ms.</li>
  <li>We re-rank with a cross-encoder model (30ms) and return the top 10 to the AI.</li>
  <li>The AI generates an answer with citations.</li>
</ol>
<p>Total: 160–200ms. We're happy with it for now.</p>

<h2>What we'd do differently</h2>
<p>Three things, in hindsight:</p>
<ul>
  <li><strong>Start with Postgres + pgvector.</strong> We wasted two months on Pinecone. Vector DBs are great if you only need semantic search, but they're bad at the hybrid queries real products need.</li>
  <li><strong>Don't embed everything.</strong> Half our corpus was noise — automated messages, bot spam, one-word replies. A simple quality filter before embedding cut our index size by 40% and improved result quality.</li>
  <li><strong>Cache aggressively.</strong> 80% of queries in a workspace are the same 20 questions. A 5-minute cache hit rate of 60% drops your effective p95 from 200ms to 80ms.</li>
</ul>

<h2>What's next</h2>
<p>We're experimenting with fine-tuned retrieval models per workspace — early results suggest a 15–20% lift in retrieval quality for technical vocabularies. More to come.</p>
`,
  },
  {
    slug: "shipping-weekly-without-burning-out",
    title: "Shipping weekly without burning out",
    excerpt:
      "Our process for releasing every week — without the death march. Async-first, small batches, and a strict 'no heroics' rule.",
    date: "2026-06-24",
    author: { name: "Sara Lindqvist", role: "Head of Design", initials: "SL" },
    readingTime: "6 min",
    tags: ["Culture", "Process"],
    body: `
<h2>The shipping cadence</h2>
<p>We ship to production every Wednesday. Not a "release window" — actual production, actual users, actual consequences. It's the most important thing we do as a company, and we've designed our entire process around making it sustainable.</p>

<h2>The week</h2>
<p>Here's what a typical week looks like:</p>
<ul>
  <li><strong>Monday</strong> — async planning. Everyone writes a short post: "here's what I'm shipping this week, here's what I need from others." No meeting.</li>
  <li><strong>Tuesday</strong> — code freeze at 5pm. Feature flags on for new stuff. Final review.</li>
  <li><strong>Wednesday</strong> — ship at 10am. Pair on rollout. Monitor for 2 hours. Roll back if anything's wrong.</li>
  <li><strong>Thursday/Friday</strong> — fix bugs from the release. Start the next week's work.</li>
</ul>

<h2>Small batches</h2>
<p>The secret to shipping weekly is shipping small. A 2-week feature is a 1-week feature that took twice as long. We break work into chunks that fit in a week — if it can't fit, it's too big and we split it further.</p>
<p>This is uncomfortable at first. Designers want to ship a complete redesign, not a piece of one. Engineers want to ship the full refactor, not a first step. But small ships compound — 50 small ships in a year is more progress than 4 big ones, and the team stays sane.</p>

<h2>The "no heroics" rule</h2>
<p>If shipping this week requires someone to work late, we don't ship this week. Period. The release slips to next week. We've never regretted this rule.</p>
<p>Heroics are a tax on next week's shipping. The person who pulled the all-nighter is useless for 3 days afterwards. The bug they introduced at 2am takes twice as long to fix as it would have taken to ship it fresh on Monday.</p>

<h2>What we don't do</h2>
<ul>
  <li><strong>No release meetings.</strong> The release goes out via a script. If you need a meeting to release, your process is too risky.</li>
  <li><strong>No change approval boards.</strong> The engineer shipping the change is the approver. We trust our people.</li>
  <li><strong>No "release candidates."</strong> Production is the release candidate. Feature flags + gradual rollout + fast rollback beat staging environments every time.</li>
</ul>

<h2>The honest part</h2>
<p>This process works for us, at our size (28 people), in our market. It's not a prescription. But the underlying principles — small batches, no heroics, async-first — are universally applicable. Steal what's useful, ignore what's not.</p>
`,
  },
  {
    slug: "designing-for-ai-native-interfaces",
    title: "Designing for AI-native interfaces",
    excerpt:
      "What changes when your product's primary interaction is conversational — and what stays the same.",
    date: "2026-06-10",
    author: { name: "Sara Lindqvist", role: "Head of Design", initials: "SL" },
    readingTime: "7 min",
    tags: ["Design", "AI"],
    body: `
<h2>The shift</h2>
<p>For 40 years, software design has been about <em>surfaces</em> — buttons, menus, forms, layouts. You design the thing the user sees, and they figure out how to use it.</p>
<p>AI-native products flip this. The primary interaction is conversational. The user says what they want in natural language, and the product does it. The "surface" is whatever the AI decides to render in response.</p>
<p>This breaks most of our design instincts. Here's what we've learned building Ion.</p>

<h2>1. The input matters more than the output</h2>
<p>In a traditional app, you spend 90% of your design time on the output — the dashboard, the list, the form. The input is just buttons and clicks.</p>
<p>In an AI-native product, the input <em>is</em> the product. If users can't articulate what they want, nothing else matters. We spend more time on the command palette, the prompt suggestions, the example queries, and the error states than on any single output surface.</p>

<h2>2. Citations are non-negotiable</h2>
<p>An AI that answers without citations is a magic 8-ball. Users don't trust it, and they shouldn't. Every answer in Ion links back to the source doc, ticket, or thread it came from. This is a UX decision, not a technical one — we could ship answers without citations and save 200ms of latency. We don't, because trust is more important than speed.</p>

<h2>3. Show your work</h2>
<p>When the AI takes an action — drafts a doc, closes a ticket, posts a message — show the user what it did, immediately, with a way to undo. This is the equivalent of a confirmation dialog in a traditional app, but more transparent. Users need to see the AI's reasoning, not just its output.</p>

<h2>4. Defaults still matter</h2>
<p>Even in a conversational product, most users will take the default action 90% of the time. Spend disproportionate effort on what the default is — which model, which tone, which format, which length. The conversational interface is the escape hatch; the defaults are the product.</p>

<h2>5. Failure states are the product</h2>
<p>The AI will fail. It'll misunderstand, hallucinate, time out, or refuse. These moments are where users decide whether they trust the product. Design failure states with the same care you design the happy path — explain what happened, offer a fix, and let the user retry without retyping everything.</p>

<h2>What stays the same</h2>
<p>The fundamentals don't change: clear hierarchy, good typography, fast feedback, accessibility. AI-native doesn't mean throwing out 40 years of design craft. It means applying it to a new interaction model.</p>
`,
  },
  {
    slug: "open-sourcing-our-design-system",
    title: "Open-sourcing our design system",
    excerpt:
      "Why we're open-sourcing the Ion design system — and what we learned building it.",
    date: "2026-05-28",
    author: { name: "Marcus Reyes", role: "Head of Engineering", initials: "MR" },
    readingTime: "5 min",
    tags: ["Engineering", "Design", "Open source"],
    body: `
<h2>Why open-source it</h2>
<p>Our design system started as an internal tool — the components, tokens, and patterns we use to build Ion. Over the last year, it's matured into something we're proud of. So we're open-sourcing it.</p>
<p>The reasons are mostly selfish:</p>
<ul>
  <li><strong>Recruiting.</strong> Engineers who care about craft want to see your code. A public design system is a recruiting magnet.</li>
  <li><strong>Quality.</strong> Knowing the world can read your code makes you write better code.</li>
  <li><strong>Ecosystem.</strong> If your design system is good, other teams adopt it. That's free QA and free feature requests.</li>
</ul>

<h2>What's included</h2>
<p>The open-source release includes:</p>
<ul>
  <li>60+ React components built on Radix UI.</li>
  <li>A complete token system (colors, typography, spacing, motion) with light + dark mode.</li>
  <li>Documentation site with live examples.</li>
  <li>Figma library matching the code 1:1.</li>
</ul>

<h2>What we learned</h2>
<h3>Tokens before components</h3>
<p>We spent the first 3 months on tokens alone — getting the color system, typography scale, and spacing right before building a single component. It felt slow at the time, but it meant every component we built afterwards was consistent by default.</p>
<h3>Accessibility is a feature, not a chore</h3>
<p>We treated WCAG AA as the floor, not the ceiling. Every component is keyboard-navigable, screen-reader-tested, and respects prefers-reduced-motion. This isn't just ethical — it's good product sense. Users who can't use your product because of an accessibility bug are users you've lost forever.</p>
<h3>Document everything</h3>
<p>Undocumented components are useless components. Every component in the system has a doc page with usage guidelines, do's and don'ts, and live examples. The docs took as long to write as the components took to build.</p>

<h2>Where to find it</h2>
<p>The design system is at <a href="https://github.com/ion/design-system">github.com/ion/design-system</a>. MIT licensed. We'd love your feedback.</p>
`,
  },
  {
    slug: "the-economics-of-ai-pricing",
    title: "The economics of AI pricing",
    excerpt:
      "How we thought about pricing Ion — per-seat, per-query, or something else entirely?",
    date: "2026-05-14",
    author: { name: "Maya Okafor", role: "CEO", initials: "MO" },
    readingTime: "9 min",
    tags: ["Business", "Pricing"],
    body: `
<h2>The pricing problem</h2>
<p>AI products have a weird cost structure. The marginal cost of a query isn't zero — every API call to Claude or GPT-4 costs real money. This breaks the traditional SaaS pricing model (per-seat, all-you-can-eat) in subtle ways.</p>
<p>When we launched Ion, we picked the obvious option: per-seat pricing, $19/seat/month, unlimited queries. Three months in, we noticed a problem: 5% of our users were consuming 60% of our AI compute. We were effectively subsidizing power users at the expense of everyone else.</p>

<h2>The options we considered</h2>
<h3>Option A: Hard usage caps</h3>
<p>Limit each seat to N queries per month. Simple, but feels hostile — users hate hitting limits, and it punishes the power users who get the most value from your product.</p>
<h3>Option B: Usage-based pricing</h3>
<p>Charge per query. Aligns cost with value, but creates anxiety — users think twice before every query, which kills the exploratory use cases that make AI products valuable.</p>
<h3>Option C: Tiered allowances + overages</h3>
<p>What we ended up with: each plan includes a generous allowance (10,000 queries/month on Pro), with soft overages that warn but don't block. Power users who consistently exceed can upgrade to Enterprise with a custom allowance.</p>

<h2>Why option C won</h2>
<p>Three reasons:</p>
<ol>
  <li><strong>Predictable billing.</strong> 95% of users never hit the cap, so their bill is the same every month. No anxiety.</li>
  <li><strong>Rewarding power users.</strong> The 5% who hit the cap are getting massive value from Ion — they're the most likely to upgrade to Enterprise, not churn.</li>
  <li><strong>Cost discipline.</strong> We can forecast AI compute costs per workspace and price accordingly. No surprises.</li>
</ol>

<h2>What we'd do differently</h2>
<p>We should have started with tiered allowances from day one. The "unlimited" pricing was a marketing decision, not a business one — it sounded good in the pricing table but created a structural problem we had to unwind later.</p>
<p>If you're launching an AI product, price for the unit economics from day one. Your future self will thank you.</p>
`,
  },
];

export function getPostBySlug(slug: string) {
  return posts.find((p) => p.slug === slug);
}

export function getRelatedPosts(slug: string, limit = 3) {
  return posts.filter((p) => p.slug !== slug).slice(0, limit);
}
