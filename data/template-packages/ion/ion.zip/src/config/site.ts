/**
 * site.ts — Ion site-wide configuration.
 * ───────────────────────────────────────────────────────────────────────────
 * This is the SINGLE SOURCE OF TRUTH for brand name, logo, nav, footer links,
 * social profiles, and SEO defaults. Buyers: edit this file to rebrand.
 *
 * Every link in nav/footer points to a REAL route. See the route map below.
 */

export const siteConfig = {
  /** Brand name — used in <title>, nav, footer, OG metadata. */
  name: "Ion",
  /** One-line tagline shown in hero subhead and meta description. */
  tagline: "The AI workspace that thinks ahead.",
  /** Default OG image (1200×630). */
  ogImage: "/og-image.png",
  /** Canonical production URL — used for metadataBase, sitemap, robots. */
  url: "https://ion-template.demo",
  /** Default locale. */
  locale: "en_US",

  /** Primary navigation (top-level routes + anchors). */
  nav: [
    { label: "Product", href: "/#product" },
    { label: "Features", href: "/#features" },
    { label: "Pricing", href: "/pricing" },
    { label: "Changelog", href: "/changelog" },
    { label: "Docs", href: "/docs" },
    { label: "Blog", href: "/blog" },
  ] as const,

  /** Footer link columns — every link points to a real route. */
  footer: {
    product: [
      { label: "Features", href: "/#features" },
      { label: "Pricing", href: "/pricing" },
      { label: "Changelog", href: "/changelog" },
      { label: "Integrations", href: "/#integrations" },
      { label: "Dashboard", href: "/dashboard" },
    ],
    company: [
      { label: "About", href: "/about" },
      { label: "Blog", href: "/blog" },
      { label: "Careers", href: "/careers" },
      { label: "Contact", href: "/contact" },
    ],
    resources: [
      { label: "Documentation", href: "/docs" },
      { label: "API reference", href: "/docs/api-reference" },
      { label: "Guides", href: "/docs/guides" },
      { label: "Community", href: "/community" },
    ],
    legal: [
      { label: "Privacy", href: "/privacy" },
      { label: "Terms", href: "/terms" },
      { label: "Security", href: "/security" },
      { label: "DPA", href: "/dpa" },
    ],
  },

  /** Social links — used in footer. Replace with your real profiles. */
  social: {
    x: "https://x.com",
    github: "https://github.com",
    linkedin: "https://linkedin.com",
    discord: "https://discord.com",
  },

  /** SEO metadata template — %s is replaced with the page title. */
  seo: {
    titleTemplate: "%s · Ion",
    defaultTitle: "Ion — The AI workspace that thinks ahead",
    description:
      "Ion is the AI workspace that unifies your tools, automates the busywork, and surfaces what matters — so your team ships faster without the noise.",
    keywords: [
      "AI workspace",
      "AI SaaS",
      "productivity",
      "team collaboration",
      "AI automation",
      "Ion",
    ],
  },

  /** Primary CTAs — used across nav, hero, footer. */
  cta: {
    primary: { label: "Start free", href: "/signup" },
    secondary: { label: "Log in", href: "/login" },
  },
} as const;

export type SiteConfig = typeof siteConfig;
