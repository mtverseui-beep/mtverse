/**
 * docs.ts — Ion documentation content.
 * ───────────────────────────────────────────────────────────────────────────
 * All docs pages as a flat array with section grouping. The /docs route
 * renders a sidebar from this data and /docs/[slug] renders the page.
 */

export interface DocPage {
  slug: string;
  title: string;
  description: string;
  section: "Getting started" | "Core concepts" | "Guides" | "API reference" | "Integrations";
  order: number;
  /** Rendered as HTML in the page — supports h2, h3, p, ul, pre, blockquote. */
  body: string;
}

export const docs: DocPage[] = [
  {
    slug: "introduction",
    title: "Introduction",
    description: "What Ion is, who it's for, and how to think about it.",
    section: "Getting started",
    order: 1,
    body: `
<h2>What is Ion?</h2>
<p>Ion is an AI workspace that unifies your tools, automates the busywork, and surfaces what matters. It's not a chatbot bolted onto your existing stack — it's a single surface where docs, tickets, chats, and metrics live together, with an AI that actually knows your context.</p>
<p><strong>Who it's for:</strong> engineering, product, and design teams of 5–500 people who are tired of stitching together 10+ tools and want a single place to do their work.</p>

<h2>How it's different</h2>
<ul>
  <li><strong>Context-aware AI.</strong> Ion reads your docs, tickets, and chats — so when you ask, it already knows what "the launch" means.</li>
  <li><strong>Visual automations.</strong> Wire up multi-step flows without code. Ion recovers gracefully when an API hiccups.</li>
  <li><strong>One surface.</strong> Docs, tickets, chats, and metrics in a single keyboard-driven workspace.</li>
  <li><strong>Real reliability.</strong> SOC 2 Type II, 99.95% uptime SLA on Enterprise, and per-step audit logs for every automation.</li>
</ul>

<h2>Next steps</h2>
<ul>
  <li>Read <a href="/docs/quickstart">Quickstart</a> to get a workspace running in 2 minutes.</li>
  <li>Skim <a href="/docs/core-concepts">Core concepts</a> to understand the mental model.</li>
  <li>Browse <a href="/docs/guides">Guides</a> for common workflows.</li>
</ul>
`,
  },
  {
    slug: "quickstart",
    title: "Quickstart",
    description: "Get a working Ion workspace in under 2 minutes.",
    section: "Getting started",
    order: 2,
    body: `
<h2>1. Create a workspace</h2>
<p>Sign up at <a href="/signup">ion.app/signup</a> with your work email. You'll start on a 14-day Pro trial — no credit card required.</p>

<h2>2. Connect your tools</h2>
<p>From the workspace setup screen, OAuth into the tools you use. The most common integrations:</p>
<ul>
  <li><strong>Slack</strong> — for chat, mentions, and notifications.</li>
  <li><strong>GitHub</strong> — for PRs, issues, and commits.</li>
  <li><strong>Linear</strong> — for tickets and cycle time.</li>
  <li><strong>Notion</strong> — for docs and knowledge base.</li>
</ul>
<p>Ion indexes your existing data in the background — most workspaces finish initial sync in under 30 minutes.</p>

<h2>3. Ask your first question</h2>
<p>Hit <code>⌘K</code> anywhere in Ion to open the command palette. Try:</p>
<pre><code>What's blocking the launch?</code></pre>
<p>Ion will return an answer with citations from your actual docs, tickets, and threads — not the open internet.</p>

<h2>4. Build your first automation</h2>
<p>Go to <strong>Automations → New</strong> and describe what you want in plain English:</p>
<pre><code>When a PR is merged into main, post a summary in #launches and close the linked Linear ticket.</code></pre>
<p>Ion will draft the automation visually. Review it, click <strong>Enable</strong>, and you're done.</p>
`,
  },
  {
    slug: "core-concepts",
    title: "Core concepts",
    description: "The mental model: workspace, context, automations, insights.",
    section: "Core concepts",
    order: 3,
    body: `
<h2>Workspace</h2>
<p>A <strong>workspace</strong> is your team's home in Ion. It contains your members, integrations, docs, automations, and activity. Workspaces are isolated — data never crosses between them.</p>

<h2>Context</h2>
<p><strong>Context</strong> is everything Ion knows about your work: docs, tickets, threads, commits, and the relationships between them. Ion builds a living knowledge graph that updates in real-time as your team works.</p>
<p>Context is what makes Ion's AI useful. When you ask a question, Ion answers from your context — with citations — rather than from a foundation model's training data.</p>

<h2>Automations</h2>
<p>An <strong>automation</strong> is a multi-step workflow: <em>when X happens, do Y, then Z.</em> Automations have:</p>
<ul>
  <li><strong>Triggers</strong> — events from your integrations (PR merged, ticket created, message posted).</li>
  <li><strong>Steps</strong> — actions Ion takes (filter, transform, call an API, post a message, update a ticket).</li>
  <li><strong>Error paths</strong> — what to do when a step fails (retry, skip, notify).</li>
</ul>
<p>Every automation has a per-step audit log and one-click rollback to the last known good state.</p>

<h2>Insights</h2>
<p><strong>Insights</strong> are dashboards built from the work your team is already doing. Cycle time, throughput, stuck work — all auto-calculated, no manual data entry.</p>
`,
  },
  {
    slug: "automations-guide",
    title: "Building automations",
    description: "A practical guide to building reliable multi-step automations.",
    section: "Guides",
    order: 4,
    body: `
<h2>The anatomy of an automation</h2>
<p>Every automation has three parts: a <strong>trigger</strong>, one or more <strong>steps</strong>, and an <strong>error path</strong>. Let's build one together.</p>

<h2>Example: PR merged → notify → close ticket</h2>
<p>This is the most common automation in Ion. Here's how to build it:</p>
<ol>
  <li>Go to <strong>Automations → New automation</strong>.</li>
  <li>Choose the <strong>GitHub</strong> trigger: <code>Pull request merged</code>.</li>
  <li>Add a <strong>Filter</strong> step: <code>branch == "main"</code>.</li>
  <li>Add a <strong>Slack</strong> step: <code>Post message</code> to <code>#launches</code> with the PR title and summary.</li>
  <li>Add a <strong>Linear</strong> step: <code>Close ticket</code> linked in the PR description.</li>
  <li>Configure the <strong>error path</strong>: notify <code>#engineering</code> if any step fails after 3 retries.</li>
  <li>Click <strong>Enable</strong>.</li>
</ol>

<h2>Best practices</h2>
<ul>
  <li><strong>Start narrow.</strong> Filter early — don't run an automation on every event when you only care about 5% of them.</li>
  <li><strong>Idempotency.</strong> Automations can fire multiple times for the same event. Design steps to be safe to re-run.</li>
  <li><strong>Test before enabling.</strong> Use the <strong>Test run</strong> button with a real past event before going live.</li>
  <li><strong>Watch the audit log.</strong> Every run is logged per-step. If something breaks, you'll see exactly where.</li>
</ul>

<h2>Common patterns</h2>
<h3>Rate limiting</h3>
<p>Add a <strong>Debounce</strong> step to batch rapid-fire events. Useful for things like "notify on every commit" without spamming.</p>
<h3>Conditional branching</h3>
<p>Use the <strong>If/else</strong> step to route based on data. Each branch can have its own steps and error paths.</p>
<h3>Loops</h3>
<p>Use the <strong>For each</strong> step to iterate over arrays — e.g., close every ticket linked in a PR.</p>
`,
  },
  {
    slug: "ai-features",
    title: "Working with the AI",
    description: "How to get the most out of Ion's context-aware AI.",
    section: "Guides",
    order: 5,
    body: `
<h2>Asking good questions</h2>
<p>Ion's AI is only as good as the question you ask. The key: be specific about what you want, and reference real things in your workspace.</p>
<p><strong>Bad:</strong> "What's the status of the project?"</p>
<p><strong>Good:</strong> "What's blocking the v2.0 launch? Cite the specific tickets and threads."</p>

<h2>What the AI can do</h2>
<ul>
  <li><strong>Answer questions</strong> with citations from your docs, tickets, and threads.</li>
  <li><strong>Draft documents</strong> — PRDs, release notes, standups — in your team's voice.</li>
  <li><strong>Summarize threads</strong> — long Slack discussions into 3-bullet summaries.</li>
  <li><strong>Suggest automations</strong> — describe the outcome, Ion drafts the flow.</li>
</ul>

<h2>Model routing</h2>
<p>Ion supports multiple AI providers (Claude, GPT-4, etc.) and lets you route per-task. For example:</p>
<ul>
  <li><strong>Drafting docs</strong> → Claude (better long-form writing).</li>
  <li><strong>Code analysis</strong> → GPT-4 (better at code).</li>
  <li><strong>Quick lookups</strong> → a smaller, faster model (lower cost).</li>
</ul>
<p>Configure this in <strong>Workspace settings → AI</strong>.</p>

<h2>Privacy</h2>
<p>We never train foundation models on your data. Your context stays in your tenant. See our <a href="/security">security page</a> for the full picture.</p>
`,
  },
  {
    slug: "api-reference",
    title: "API reference",
    description: "REST API for programmatically managing Ion resources.",
    section: "API reference",
    order: 6,
    body: `
<h2>Authentication</h2>
<p>All API requests require an API key. Generate one in <strong>Workspace settings → API keys</strong>.</p>
<pre><code>curl https://api.ion.app/v1/workspaces \\
  -H "Authorization: Bearer ion_sk_..."</code></pre>

<h2>Base URL</h2>
<pre><code>https://api.ion.app/v1</code></pre>

<h2>Endpoints</h2>
<h3>List workspaces</h3>
<pre><code>GET /v1/workspaces</code></pre>
<p>Returns the workspaces your API key has access to.</p>
<pre><code>{
  "data": [
    {
      "id": "ws_abc123",
      "name": "Northwind",
      "slug": "northwind",
      "plan": "pro",
      "created_at": "2024-01-15T10:30:00Z"
    }
  ]
}</code></pre>

<h3>Create an automation</h3>
<pre><code>POST /v1/automations</code></pre>
<p>Body:</p>
<pre><code>{
  "name": "PR merged notification",
  "trigger": {
    "type": "github.pull_request.merged",
    "filter": { "branch": "main" }
  },
  "steps": [
    { "type": "slack.post", "channel": "#launches", "text": "{{pr.title}}" },
    { "type": "linear.ticket.close", "match": "{{pr.description}}" }
  ]
}</code></pre>

<h3>Trigger an automation manually</h3>
<pre><code>POST /v1/automations/:id/run</code></pre>
<p>Triggers an automation with a synthetic event. Useful for testing.</p>

<h3>List activity</h3>
<pre><code>GET /v1/activity?limit=50</code></pre>
<p>Returns the most recent activity in your workspace.</p>

<h2>Rate limits</h2>
<p>API requests are rate-limited per workspace:</p>
<ul>
  <li><strong>Pro:</strong> 100 requests/minute</li>
  <li><strong>Enterprise:</strong> 1,000 requests/minute</li>
</ul>
<p>Rate limit headers are included on every response:</p>
<pre><code>X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1698764400</code></pre>

<h2>Webhooks</h2>
<p>Configure webhooks in <strong>Workspace settings → Webhooks</strong> to receive real-time events. We sign every payload with HMAC-SHA256 — verify the <code>X-Ion-Signature</code> header.</p>
`,
  },
  {
    slug: "webhooks",
    title: "Webhooks",
    description: "Receive real-time events from Ion in your own backend.",
    section: "API reference",
    order: 7,
    body: `
<h2>Configuring webhooks</h2>
<p>Go to <strong>Workspace settings → Webhooks → Add endpoint</strong>. Enter your URL and select which events you want to receive.</p>

<h2>Event types</h2>
<ul>
  <li><code>automation.run</code> — an automation finished running (success or failure).</li>
  <li><code>automation.failed</code> — an automation failed and couldn't recover.</li>
  <li><code>integration.connected</code> — a new integration was connected.</li>
  <li><code>integration.disconnected</code> — an integration was disconnected (manually or due to auth failure).</li>
  <li><code>member.invited</code> — a new member was invited to the workspace.</li>
  <li><code>member.joined</code> — an invited member accepted.</li>
</ul>

<h2>Payload format</h2>
<pre><code>{
  "id": "evt_abc123",
  "type": "automation.run",
  "created_at": "2026-08-01T10:30:00Z",
  "data": {
    "automation_id": "aut_xyz",
    "automation_name": "PR merged notification",
    "status": "success",
    "duration_ms": 1240
  }
}</code></pre>

<h2>Verifying signatures</h2>
<p>Every webhook is signed with your endpoint's signing secret. Verify the <code>X-Ion-Signature</code> header:</p>
<pre><code>import crypto from "crypto";

function verifySignature(payload: string, signature: string, secret: string) {
  const expected = crypto
    .createHmac("sha256", secret)
    .update(payload)
    .digest("hex");
  return crypto.timingSafeEqual(
    Buffer.from(expected),
    Buffer.from(signature)
  );
}</code></pre>

<h2>Retries</h2>
<p>If your endpoint returns a non-2xx response, we retry with exponential backoff: 1min, 5min, 30min, 2hr, 6hr. After 5 failed attempts, the webhook is disabled and you'll get an email.</p>
`,
  },
  {
    slug: "slack-integration",
    title: "Slack integration",
    description: "Connect Slack to bring your channels and DMs into Ion's context.",
    section: "Integrations",
    order: 8,
    body: `
<h2>What it does</h2>
<p>The Slack integration lets Ion:</p>
<ul>
  <li>Read messages from channels you select (read-only — Ion never posts without an automation).</li>
  <li>Post messages via automations.</li>
  <li>Index threads for AI search.</li>
  <li>React to mentions and DMs.</li>
</ul>

<h2>Connecting</h2>
<ol>
  <li>Go to <strong>Integrations → Slack → Connect</strong>.</li>
  <li>Authorize Ion in your Slack workspace.</li>
  <li>Select which channels Ion should index.</li>
</ol>

<h2>Permissions</h2>
<p>Ion requests the minimum Slack scopes needed:</p>
<ul>
  <li><code>channels:read</code> — list channels.</li>
  <li><code>channels:history</code> — read messages in selected channels.</li>
  <li><code>chat:write</code> — post messages (only via automations you configure).</li>
  <li><code>commands</code> — enable the <code>/ion</code> slash command.</li>
</ul>

<h2>The /ion slash command</h2>
<p>Once connected, you can use <code>/ion</code> in any Slack channel:</p>
<pre><code>/ion What's blocking the launch?</code></pre>
<p>Ion responds in a thread with citations from your workspace.</p>
`,
  },
  {
    slug: "github-integration",
    title: "GitHub integration",
    description: "Connect GitHub to track PRs, issues, and commits in Ion.",
    section: "Integrations",
    order: 9,
    body: `
<h2>What it does</h2>
<ul>
  <li>Indexes PRs, issues, and commits from selected repositories.</li>
  <li>Provides triggers for automations (PR opened, merged, closed).</li>
  <li>Links PRs to Linear tickets automatically.</li>
  <li>Posts PR summaries to Slack via automations.</li>
</ul>

<h2>Connecting</h2>
<ol>
  <li>Go to <strong>Integrations → GitHub → Connect</strong>.</li>
  <li>Authorize the Ion GitHub app.</li>
  <li>Select which repositories Ion can access.</li>
</ol>

<h2>Recommended repositories</h2>
<p>Start with your main application repos. Don't connect forks, mirrors, or archived repos — they'll just add noise to your context.</p>

<h2>Privacy</h2>
<p>Ion never writes to your repositories. The GitHub app is read-only by default. Automations that need to write (e.g., comment on a PR) require explicit additional scopes you grant per-automation.</p>
`,
  },
];

/** Grouped docs for sidebar rendering. */
export function getDocsBySection() {
  const sections: Record<string, DocPage[]> = {};
  for (const d of docs) {
    if (!sections[d.section]) sections[d.section] = [];
    sections[d.section].push(d);
  }
  for (const k of Object.keys(sections)) {
    sections[k].sort((a, b) => a.order - b.order);
  }
  return sections;
}

/** Get the previous and next doc for navigation. */
export function getDocNav(slug: string) {
  const sorted = [...docs].sort((a, b) => a.order - b.order);
  const idx = sorted.findIndex((d) => d.slug === slug);
  return {
    prev: idx > 0 ? sorted[idx - 1] : null,
    next: idx < sorted.length - 1 ? sorted[idx + 1] : null,
  };
}
