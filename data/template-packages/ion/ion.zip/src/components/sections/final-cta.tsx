"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { GlowOrb } from "@/components/primitives/glow";
import { siteConfig } from "@/config/site";

/**
 * FinalCTA — full-width high-contrast banner right before the footer.
 * Bold restatement of value prop, single primary CTA, ambient glow, trust line.
 */
export function FinalCTA() {
  return (
    <section className="relative overflow-hidden py-24 md:py-32" aria-labelledby="final-cta-heading">
      {/* Ambient glow background */}
      <GlowOrb
        className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        color="var(--primary)"
        opacity={0.2}
        size={800}
      />
      <GlowOrb
        className="right-0 top-0"
        color="var(--accent-warm)"
        opacity={0.10}
        size={500}
      />

      <Container className="relative">
        <Reveal className="mx-auto max-w-3xl text-center">
          <h2
            id="final-cta-heading"
            className="display-1 text-balance text-foreground"
          >
            Stop wrestling tools.{" "}
            <span className="text-gradient-accent">Start shipping outcomes.</span>
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">
            Join 4,000+ teams using Ion to unify their stack and ship faster.
            Free for 14 days — no credit card required.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" className="group w-full sm:w-auto">
              <Link href={siteConfig.cta.primary.href}>
                {siteConfig.cta.primary.label}
                <ArrowRight className="ml-1.5 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Link>
            </Button>
            <span className="text-sm text-muted-foreground">
              No credit card · 14-day Pro trial · Cancel anytime
            </span>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
