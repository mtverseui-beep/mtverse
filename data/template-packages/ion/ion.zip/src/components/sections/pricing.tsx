"use client";

import * as React from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Check, HelpCircle, ArrowRight } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { cn } from "@/lib/utils";
import { pricingTiers, pricingFaq, type PricingTier } from "@/config/content";

type Billing = "monthly" | "yearly";

/**
 * Pricing — 3-tier table with monthly/yearly toggle, animated price transitions,
 * highlighted "Pro" tier with glow, tooltips on ambiguous line items, micro-FAQ.
 */
export function Pricing() {
  const [billing, setBilling] = React.useState<Billing>("yearly");

  return (
    <Section id="pricing" className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>Pricing</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">
              Pricing that scales with you.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              Start free. Upgrade when you&apos;re ready. Cancel anytime. No credit card required to start.
            </p>
          </Reveal>
        </div>

        {/* Billing toggle */}
        <Reveal delay={0.15} className="mt-10 flex justify-center">
          <BillingToggle billing={billing} onChange={setBilling} />
        </Reveal>

        {/* Tiers */}
        <Reveal delay={0.2}>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {pricingTiers.map((tier) => (
              <PricingCard key={tier.name} tier={tier} billing={billing} />
            ))}
          </div>
        </Reveal>

        {/* Micro-FAQ */}
        <Reveal delay={0.25} className="mx-auto mt-14 max-w-2xl">
          <Accordion type="single" collapsible className="w-full">
            {pricingFaq.map((item) => (
              <AccordionItem key={item.q} value={item.q}>
                <AccordionTrigger className="text-left">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </Container>
    </Section>
  );
}

function BillingToggle({
  billing,
  onChange,
}: {
  billing: Billing;
  onChange: (b: Billing) => void;
}) {
  return (
    <div
      role="radiogroup"
      aria-label="Billing period"
      className="glass inline-flex items-center gap-1 rounded-full p-1"
    >
      {(["monthly", "yearly"] as const).map((b) => (
        <button
          key={b}
          type="button"
          role="radio"
          aria-checked={billing === b}
          onClick={() => onChange(b)}
          className={cn(
            "relative rounded-full px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            billing === b
              ? "text-primary-foreground"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          {billing === b && (
            <motion.div
              layoutId="billing-pill"
              className="absolute inset-0 rounded-full bg-primary"
              transition={{ type: "spring", damping: 24, stiffness: 320 }}
            />
          )}
          <span className="relative z-10">
            {b === "monthly" ? "Monthly" : "Yearly"}
            {b === "yearly" && (
              <span className="ml-2 rounded-full bg-primary/15 px-1.5 py-0.5 text-xs text-primary">
                −20%
              </span>
            )}
          </span>
        </button>
      ))}
    </div>
  );
}

function PricingCard({ tier, billing }: { tier: PricingTier; billing: Billing }) {
  const isContact = tier.monthly === -1;
  const price = billing === "monthly" ? tier.monthly : tier.yearly;
  const highlighted = tier.highlighted;

  return (
    <div
      className={cn(
        "relative flex flex-col rounded-3xl border p-8 transition-all",
        highlighted
          ? "border-primary/40 bg-card shadow-[0_0_0_1px_var(--primary),0_24px_48px_-12px_rgba(198,255,61,0.25)] lg:scale-[1.03]"
          : "border-border bg-card hover:border-border-strong"
      )}
    >
      {highlighted && tier.badge && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
            {tier.badge}
          </span>
        </div>
      )}

      <h3 className="text-lg font-semibold text-foreground">{tier.name}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{tier.description}</p>

      {/* Price — animated transition */}
      <div className="mt-6 flex items-baseline gap-1">
        {isContact ? (
          <span className="text-4xl font-semibold text-foreground">Custom</span>
        ) : (
          <>
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={`${price}-${billing}`}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
                className="text-4xl font-semibold tracking-tight text-foreground"
              >
                ${price}
              </motion.span>
            </AnimatePresence>
            <span className="text-sm text-muted-foreground">
              {price === 0 ? "forever" : `/ seat / mo`}
            </span>
          </>
        )}
      </div>
      {billing === "yearly" && !isContact && price > 0 && (
        <p className="mt-1 text-xs text-primary">Billed annually</p>
      )}

      <Button
        asChild
        size="lg"
        variant={highlighted ? "default" : "outline"}
        className="mt-6 w-full"
      >
        <Link href={tier.cta.href}>
          {tier.cta.label}
          <ArrowRight className="ml-1.5 h-4 w-4" />
        </Link>
      </Button>

      {/* Features */}
      <ul className="mt-8 space-y-3">
        {tier.features.map((feat) => (
          <li key={feat} className="flex items-start gap-2.5">
            <Check
              className="mt-0.5 h-4 w-4 shrink-0 text-primary"
              aria-hidden="true"
            />
            <span className="text-sm text-foreground">
              {feat}
              {feat.includes("SAML") && <TooltipHint text="Single Sign-On via SAML 2.0 — works with Okta, Google Workspace, Azure AD, and most IdPs." />}
              {feat.includes("SOC 2") && <TooltipHint text="Type II report available under NDA. Request via contact form." />}
              {feat.includes("uptime SLA") && <TooltipHint text="Service credits issued if monthly uptime falls below 99.95%." />}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function TooltipHint({ text }: { text: string }) {
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            className="ml-1 inline-flex align-middle text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
            aria-label="More information"
          >
            <HelpCircle className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </TooltipTrigger>
        <TooltipContent className="max-w-xs">{text}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
