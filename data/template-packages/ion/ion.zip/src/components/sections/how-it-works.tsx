"use client";

import * as React from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { howItWorks } from "@/config/content";

/**
 * HowItWorks — 3-4 numbered steps connected by an animated progress line
 * that fills as you scroll through the section.
 */
export function HowItWorks() {
  const ref = React.useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 70%", "end 30%"],
  });
  const scaleY = useTransform(scrollYProgress, [0, 1], [0, 1]);

  return (
    <Section id="how" muted className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>How it works</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">
              From zero to shipping in <span className="text-gradient-accent">four steps</span>.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              Most teams are running Ion in under two minutes. Here&apos;s what those two minutes
              (and the days that follow) actually look like.
            </p>
          </Reveal>
        </div>

        <div ref={ref} className="relative mt-16">
          {/* Animated vertical progress line (mobile + centered on desktop) */}
          <div className="absolute left-6 top-0 h-full w-px bg-border md:left-1/2 md:-translate-x-1/2">
            <motion.div
              className="h-full w-full origin-top bg-gradient-to-b from-primary to-accent-warm"
              style={{ scaleY }}
            />
          </div>

          <ol className="space-y-12">
            {howItWorks.map((step, i) => (
              <Reveal
                key={step.step}
                delay={i * 0.1}
                className={cnStep(i)}
              >
                <StepCard step={step} index={i} />
              </Reveal>
            ))}
          </ol>
        </div>
      </Container>
    </Section>
  );
}

function cnStep(i: number) {
  // Alternate left/right on desktop; always full width on mobile
  return i % 2 === 0
    ? "relative pl-16 md:w-1/2 md:pl-0 md:pr-12 md:text-right"
    : "relative pl-16 md:ml-auto md:w-1/2 md:pl-12";
}

function StepCard({
  step,
  index,
}: {
  step: { step: number; title: string; description: string };
  index: number;
}) {
  const isLeft = index % 2 === 0;
  return (
    <div className="relative">
      {/* Numbered node on the line */}
      <div
        className={cnNode(isLeft)}
      >
        <span className="grid h-10 w-10 place-items-center rounded-full border-2 border-primary bg-background font-mono text-sm font-semibold text-primary">
          {step.step}
        </span>
      </div>

      <div className="rounded-2xl border border-border bg-card p-6">
        <h3 className="text-lg font-semibold text-foreground">{step.title}</h3>
        <p className="mt-2 text-sm text-muted-foreground">{step.description}</p>
      </div>
    </div>
  );
}

function cnNode(isLeft: boolean) {
  return [
    "absolute -left-16 top-0 md:top-0",
    // mobile: always left of card (line is at left-6)
    "left-0",
    // desktop: position relative to the card's outer edge
    isLeft
      ? "md:-right-5 md:left-auto md:top-0"
      : "md:-left-5 md:right-auto md:top-0",
  ].join(" ");
}
