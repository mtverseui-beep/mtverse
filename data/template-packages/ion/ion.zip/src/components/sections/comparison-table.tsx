"use client";

import { Check, X, Minus } from "lucide-react";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { comparison } from "@/config/content";

/** CellValue — render booleans as check/x, partial as minus, strings as text. */
function CellValue({ value }: { value: boolean | string }) {
  if (value === true)
    return (
      <span className="inline-grid h-6 w-6 place-items-center rounded-full bg-primary/15 text-primary">
        <Check className="h-4 w-4" aria-hidden="true" />
        <span className="sr-only">Yes</span>
      </span>
    );
  if (value === false)
    return (
      <span className="inline-grid h-6 w-6 place-items-center rounded-full bg-muted text-muted-foreground">
        <X className="h-4 w-4" aria-hidden="true" />
        <span className="sr-only">No</span>
      </span>
    );
  if (value === "partial")
    return (
      <span className="inline-grid h-6 w-6 place-items-center rounded-full bg-accent-warm/15 text-accent-warm">
        <Minus className="h-4 w-4" aria-hidden="true" />
        <span className="sr-only">Partial</span>
      </span>
    );
  return <span className="text-sm font-medium text-foreground">{value}</span>;
}

/**
 * ComparisonTable — Ion vs. Manual vs. Legacy.
 * Factual-feeling comparison, not a competitor smear.
 */
export function ComparisonTable() {
  return (
    <Section id="comparison" muted className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>Compare</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">
              Ion vs. the old way.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              What changes when your team stops stitching tools together by hand.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.15} className="mt-12">
          <div className="overflow-hidden rounded-2xl border border-border">
            <table className="w-full border-collapse">
              <caption className="sr-only">
                Feature comparison between Ion, doing it manually, and legacy tools
              </caption>
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th
                    scope="col"
                    className="p-4 text-left text-sm font-medium text-muted-foreground"
                  >
                    Capability
                  </th>
                  <th
                    scope="col"
                    className="p-4 text-center text-sm font-semibold text-primary"
                  >
                    Ion
                  </th>
                  <th
                    scope="col"
                    className="p-4 text-center text-sm font-medium text-muted-foreground"
                  >
                    Doing it manually
                  </th>
                  <th
                    scope="col"
                    className="p-4 text-center text-sm font-medium text-muted-foreground"
                  >
                    Legacy tools
                  </th>
                </tr>
              </thead>
              <tbody>
                {comparison.features.map((row, i) => (
                  <tr
                    key={row.label}
                    className={i % 2 === 0 ? "bg-card/30" : "bg-transparent"}
                  >
                    <th
                      scope="row"
                      className="p-4 text-left text-sm font-medium text-foreground"
                    >
                      {row.label}
                    </th>
                    <td className="p-4 text-center">
                      <CellValue value={row.ion} />
                    </td>
                    <td className="p-4 text-center">
                      <CellValue value={row.manual} />
                    </td>
                    <td className="p-4 text-center">
                      <CellValue value={row.legacy} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>
      </Container>
    </Section>
  );
}
