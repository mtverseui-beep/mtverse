"use client";

import Image from "next/image";
import Link from "next/link";
import { Plus } from "lucide-react";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { integrations } from "@/config/content";

/**
 * Integrations — grid of placeholder brand-style SVGs + "+40 more" tile.
 * SVGs are generic placeholders (not literal ripped logos) per spec §10.4.
 */
export function Integrations() {
  return (
    <Section id="integrations" className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>Integrations</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">
              Plays well with everything you already use.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              80+ native integrations and a typed REST API for everything else.
              OAuth in seconds, no scripts required.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.15} className="mt-12">
          <ul className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6">
            {integrations.map((integration) => (
              <li
                key={integration.name}
                className="card-lift group flex flex-col items-center justify-center gap-2 rounded-2xl border border-border bg-card p-4"
              >
                <Image
                  src={integration.src}
                  alt={`${integration.name} integration icon`}
                  width={48}
                  height={48}
                  className="h-12 w-12"
                />
                <span className="text-xs font-medium text-muted-foreground">
                  {integration.name}
                </span>
              </li>
            ))}
            <li>
              <Link
                href="/#"
                className="flex h-full min-h-[88px] flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-border-strong bg-card/40 text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Plus className="h-6 w-6" aria-hidden="true" />
                <span className="text-xs font-medium">+40 more</span>
              </Link>
            </li>
          </ul>
        </Reveal>
      </Container>
    </Section>
  );
}
