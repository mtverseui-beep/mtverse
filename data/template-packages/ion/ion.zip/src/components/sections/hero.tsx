"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Play, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Eyebrow } from "@/components/primitives/section";
import { GlowOrb } from "@/components/primitives/glow";
import { StackedAvatars } from "@/components/primitives/stacked-avatars";
import { hero } from "@/config/content";

export function Hero() {
  const reduceMotion = useReducedMotion();

  return (
    <section
      className="relative overflow-hidden pt-32 pb-16 md:pt-40 md:pb-24"
      aria-labelledby="hero-heading"
    >
      {/* Ambient glow — static, no scroll-linked transform */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <GlowOrb
          className="left-1/2 top-0 -translate-x-1/2"
          color="var(--primary)"
          opacity={0.18}
          size={800}
        />
        <GlowOrb
          className="right-0 top-1/3"
          color="var(--accent-warm)"
          opacity={0.10}
          size={500}
        />
      </div>

      <div className="container-ion relative">
        {/* Headline cluster */}
        <div className="mx-auto max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            <Eyebrow>{hero.eyebrow}</Eyebrow>
          </motion.div>

          <motion.h1
            id="hero-heading"
            className="display-1 mt-6 text-balance"
            initial={{ opacity: 0, y: 24, filter: "blur(8px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 0.7, delay: 0.05, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="block text-foreground">{hero.headlineLead}</span>
            <span className="block text-gradient-accent">{hero.headlineHighlight}</span>
          </motion.h1>

          <motion.p
            className="mx-auto mt-6 max-w-2xl text-balance text-lg text-muted-foreground md:text-xl"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          >
            {hero.subhead}
          </motion.p>

          <motion.div
            className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            <Button asChild size="lg" className="group w-full sm:w-auto">
              <Link href={hero.primaryCta.href}>
                {hero.primaryCta.label}
                <ArrowRight className="ml-1.5 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Link>
            </Button>

            {/* Demo dialog */}
            <Dialog>
              <DialogTrigger asChild>
                <Button size="lg" variant="outline" className="group w-full sm:w-auto">
                  <Play className="mr-1.5 h-4 w-4 transition-transform group-hover:scale-110" />
                  {hero.secondaryCta.label}
                </Button>
              </DialogTrigger>
              <DemoDialogContent />
            </Dialog>
          </motion.div>

          {/* Micro social proof */}
          <motion.div
            className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            <StackedAvatars
              avatars={[...hero.socialProof.avatars]}
              alt={hero.socialProof.label}
              size={36}
              overlap={10}
            />
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">Trusted by 4,000+ teams</span>{" "}
              from solo founders to public companies
            </p>
          </motion.div>
        </div>

        {/* Hero visual — entrance animation only, no scroll-linked parallax (caused scroll jank) */}
        <motion.div
          className="relative mx-auto mt-16 max-w-6xl"
          initial={reduceMotion ? false : { opacity: 0, y: 40, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="relative">
            {/* glow under mockup */}
            <div
              aria-hidden="true"
              className="absolute -inset-x-12 -bottom-8 top-1/2 -z-10 rounded-full bg-primary/20 blur-3xl"
            />
            <HeroMockup />
          </div>

          {/* Floating AI chips — pure CSS animation (no JS per-frame work) */}
          {!reduceMotion && (
            <div className="hero-chip hero-chip-left glass-strong rounded-xl p-3 shadow-xl">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
                </span>
                <span className="text-xs font-medium text-foreground">AI handled 184 tasks</span>
              </div>
            </div>
          )}

          {!reduceMotion && (
            <div className="hero-chip hero-chip-right glass-strong rounded-xl p-3 shadow-xl">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-accent-warm" aria-hidden="true" />
                <span className="text-xs font-medium text-foreground">Draft ready in 8s</span>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}

/** HeroMockup — the browser-chrome-framed product screenshot. */
function HeroMockup() {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-card shadow-2xl">
      {/* browser chrome */}
      <div className="flex items-center gap-2 border-b border-border bg-background/50 px-4 py-3">
        <div className="flex gap-1.5" aria-hidden="true">
          <div className="h-3 w-3 rounded-full bg-red-400/70" />
          <div className="h-3 w-3 rounded-full bg-yellow-400/70" />
          <div className="h-3 w-3 rounded-full bg-green-400/70" />
        </div>
        <div className="mx-auto flex items-center gap-2 rounded-md border border-border bg-card/50 px-3 py-1 text-xs text-muted-foreground">
          <span className="text-green-500">●</span>
          <span className="font-mono">ion.app/workspace</span>
        </div>
      </div>
      <div className="relative aspect-[16/10] w-full bg-background">
        <Image
          src="/products/workspace.svg"
          alt="Ion workspace showing a unified inbox with AI-drafted responses, sidebar navigation, and team activity"
          fill
          priority
          loading="eager"
          sizes="(min-width: 1024px) 1024px, 100vw"
          className="object-cover"
        />
      </div>
    </div>
  );
}

/** DemoDialogContent — opens an embedded animated walkthrough. */
function DemoDialogContent() {
  return (
    <DialogContent className="max-w-4xl overflow-hidden p-0 sm:rounded-2xl">
      <div className="sr-only">
        <DialogTitle>Ion product demo</DialogTitle>
        <DialogDescription>
          A 60-second walkthrough of Ion&apos;s workspace, automations, and insights.
        </DialogDescription>
      </div>
      <div className="relative aspect-video w-full bg-background">
        <DemoAnimation />
        <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-muted-foreground">
          <span className="glass rounded-md px-2 py-1 font-mono">demo · 0:60</span>
          <span className="glass rounded-md px-2 py-1">Replace with your real video embed</span>
        </div>
      </div>
    </DialogContent>
  );
}

function DemoAnimation() {
  const reduceMotion = useReducedMotion();
  return (
    <div className="absolute inset-0 grid place-items-center bg-gradient-to-br from-background via-card to-background p-8">
      <div className="grid w-full max-w-2xl gap-3">
        {["Connect Slack, GitHub, Linear", "Ion indexes your context", "Ask — Ion answers with citations", "Automate the busywork", "Ship faster every week"].map((label, i) => (
          <motion.div
            key={label}
            className="flex items-center gap-3 rounded-lg border border-border bg-card/50 p-3"
            initial={{ opacity: 0, x: -20 }}
            animate={
              reduceMotion
                ? { opacity: 1, x: 0 }
                : {
                    opacity: 1,
                    x: 0,
                    transition: {
                      duration: 0.4,
                      delay: i * 1.2,
                      repeat: Infinity,
                      repeatDelay: 1,
                      repeatType: "loop",
                    },
                  }
            }
          >
            <div className="grid h-7 w-7 place-items-center rounded-md bg-primary/15 text-primary">
              <span className="font-mono text-xs">{i + 1}</span>
            </div>
            <span className="text-sm text-foreground">{label}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
