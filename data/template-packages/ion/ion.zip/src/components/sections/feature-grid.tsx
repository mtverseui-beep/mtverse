"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip as RTooltip,
} from "recharts";
import { cn } from "@/lib/utils";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal, RevealGroup, revealItemVariants } from "@/components/primitives/reveal";
import { features, type Feature } from "@/config/content";

/**
 * FeatureGrid — asymmetric bento grid.
 * At least one card has REAL embedded interactivity (live recharts chart, toggle, code).
 * Cards lift + colored shadow on hover.
 */
export function FeatureGrid() {
  return (
    <Section id="features" className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>What&apos;s inside</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">
              Everything your team needs.{" "}
              <span className="text-muted-foreground">Nothing it doesn&apos;t.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              Seven features that replace the patchwork of tools your team is currently paying for.
              Each one is genuinely useful on its own — together they&apos;re a different way of working.
            </p>
          </Reveal>
        </div>

        <RevealGroup
          as="ul"
          className="mt-14 grid auto-rows-[minmax(180px,auto)] grid-cols-1 gap-4 md:grid-cols-4 lg:grid-cols-6"
          stagger={0.06}
        >
          {features.map((feature) => (
            <motion.li
              key={feature.title}
              variants={revealItemVariants}
              className={cn(
                "card-lift group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card p-6",
                spanClasses(feature.span)
              )}
            >
              <FeatureCardInner feature={feature} />
            </motion.li>
          ))}
        </RevealGroup>
      </Container>
    </Section>
  );
}

function spanClasses(span: Feature["span"]) {
  switch (span) {
    case "2x2":
      return "md:col-span-2 md:row-span-2 lg:col-span-3 lg:row-span-2";
    case "2x1":
      return "md:col-span-2 lg:col-span-3";
    case "1x2":
      return "md:col-span-1 md:row-span-2 lg:col-span-2 lg:row-span-2";
    case "1x1":
    default:
      return "md:col-span-1 lg:col-span-2";
  }
}

function FeatureCardInner({ feature }: { feature: Feature }) {
  const Icon = feature.icon;
  const hasVisual = feature.visual && feature.visual !== "none";

  return (
    <>
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl border border-border bg-primary/10 text-primary transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
          <Icon className="h-5 w-5" aria-hidden="true" />
        </div>
      </div>
      <h3 className="mt-4 text-lg font-semibold text-foreground">{feature.title}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{feature.description}</p>

      {hasVisual && (
        <div className="mt-auto pt-4">
          <FeatureVisual kind={feature.visual!} />
        </div>
      )}
    </>
  );
}

/** FeatureVisual — real embedded interactivity per the bento card's `visual` kind. */
function FeatureVisual({ kind }: { kind: NonNullable<Feature["visual"]> }) {
  switch (kind) {
    case "chart":
      return <LiveChart />;
    case "toggle":
      return <ToggleDemo />;
    case "code":
      return <CodeSnippet />;
    case "search":
      return <SearchDemo />;
    case "workflow":
      return <WorkflowDemo />;
    case "none":
    default:
      return null;
  }
}

/* Live recharts mini chart — animates on hover */
function LiveChart() {
  const [hover, setHover] = React.useState(false);
  // Generate stable-ish demo data
  const data = React.useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => ({
        day: i,
        v: 30 + Math.round(Math.abs(Math.sin(i * 0.7)) * 60),
      })),
    []
  );

  return (
    <div
      className="h-28 w-full rounded-lg border border-border bg-background/50 p-2"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id="featChart" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.5} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="day" hide />
          <YAxis hide />
          <RTooltip
            cursor={{ stroke: "var(--primary)", strokeWidth: 1 }}
            contentStyle={{
              background: "var(--card)",
              border: "1px solid var(--border)",
              borderRadius: 8,
              fontSize: 12,
              color: "var(--foreground)",
            }}
            labelFormatter={(label) => `Day ${Number(label) + 1}`}
          />
          <Area
            type="monotone"
            dataKey="v"
            stroke="var(--primary)"
            strokeWidth={2}
            fill="url(#featChart)"
            animationDuration={hover ? 600 : 1200}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* Real toggle that controls a label */
function ToggleDemo() {
  const [on, setOn] = React.useState(true);
  return (
    <div className="flex items-center justify-between rounded-lg border border-border bg-background/50 px-3 py-2.5">
      <span className="text-xs text-muted-foreground">Auto-summarize threads</span>
      <button
        type="button"
        role="switch"
        aria-checked={on}
        aria-label="Toggle auto-summarize"
        onClick={() => setOn((v) => !v)}
        className={cn(
          "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
          on ? "bg-primary" : "bg-muted"
        )}
      >
        <span
          className={cn(
            "pointer-events-none inline-block h-4 w-4 translate-y-0.5 transform rounded-full bg-background shadow ring-0 transition-transform",
            on ? "translate-x-4" : "translate-x-0.5"
          )}
        />
      </button>
    </div>
  );
}

function CodeSnippet() {
  return (
    <div className="rounded-lg border border-border bg-background/80 p-3 font-mono text-xs leading-relaxed">
      <div className="text-muted-foreground">{"// ion.draft()"}</div>
      <div>
        <span className="text-primary">const</span> prd ={" "}
        <span className="text-accent-warm">await</span> ion.draft(&#123;
      </div>
      <div className="pl-3">
        type: <span className="text-info">&quot;PRD&quot;</span>,
      </div>
      <div className="pl-3">
        from: <span className="text-info">&quot;#launch-readiness&quot;</span>,
      </div>
      <div>&#125;);</div>
      <div className="mt-1 text-muted-foreground">{"// ✓ drafted in 8.2s"}</div>
    </div>
  );
}

function SearchDemo() {
  const [q, setQ] = React.useState("launch blockers");
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 rounded-lg border border-border bg-background/80 px-3 py-2">
        <span className="text-muted-foreground" aria-hidden="true">⌘K</span>
        <input
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Search demo input"
          className="w-full bg-transparent text-xs text-foreground outline-none placeholder:text-muted-foreground"
          placeholder="Search across everything…"
        />
      </div>
      <div className="rounded-lg border border-border bg-background/50 p-2 text-xs">
        <div className="font-medium text-foreground">3 results · 184ms</div>
        <div className="mt-1 text-muted-foreground">Showing matches in docs, tickets, threads</div>
      </div>
    </div>
  );
}

function WorkflowDemo() {
  const steps = ["Trigger", "Filter", "Action"];
  return (
    <div className="flex items-center gap-2">
      {steps.map((s, i) => (
        <React.Fragment key={s}>
          <div className="rounded-md border border-border bg-background/60 px-2 py-1.5 text-xs text-foreground">
            {s}
          </div>
          {i < steps.length - 1 && (
            <div className="text-muted-foreground" aria-hidden="true">→</div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}
