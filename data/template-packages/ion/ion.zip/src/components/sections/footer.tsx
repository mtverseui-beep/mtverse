"use client";

import * as React from "react";
import Link from "next/link";
import { Github, Linkedin, Twitter, MessageCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Container } from "@/components/primitives/section";
import { siteConfig } from "@/config/site";
import { useToast } from "@/hooks/use-toast";

/**
 * Footer — multi-column with brand blurb, social icons (accessible SVGs with aria-labels),
 * link columns, newsletter signup (real validated form with submit states),
 * and a dynamic copyright year (never goes stale).
 */
export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-background">
      <Container className="py-16">
        <div className="grid gap-12 lg:grid-cols-12">
          {/* Brand + newsletter */}
          <div className="lg:col-span-5">
            <Link
              href="/"
              className="inline-flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md"
              aria-label={`${siteConfig.name} — home`}
            >
              <span className="text-xl font-semibold tracking-tight">{siteConfig.name}</span>
            </Link>
            <p className="mt-4 max-w-sm text-sm text-muted-foreground">
              {siteConfig.tagline} Built for teams that ship — not for teams that maintain tools.
            </p>

            {/* Newsletter form — wired to /api/contact with type=newsletter */}
            <NewsletterForm />

            {/* Social icons */}
            <div className="mt-8 flex items-center gap-2">
              <SocialLink
                href={siteConfig.social.x}
                label="X (Twitter)"
                icon={<Twitter className="h-4 w-4" aria-hidden="true" />}
              />
              <SocialLink
                href={siteConfig.social.github}
                label="GitHub"
                icon={<Github className="h-4 w-4" aria-hidden="true" />}
              />
              <SocialLink
                href={siteConfig.social.linkedin}
                label="LinkedIn"
                icon={<Linkedin className="h-4 w-4" aria-hidden="true" />}
              />
              <SocialLink
                href={siteConfig.social.discord}
                label="Discord"
                icon={<MessageCircle className="h-4 w-4" aria-hidden="true" />}
              />
            </div>
          </div>

          {/* Link columns */}
          <nav className="grid grid-cols-2 gap-8 sm:grid-cols-4 lg:col-span-7" aria-label="Footer">
            <FooterColumn title="Product" links={siteConfig.footer.product} />
            <FooterColumn title="Company" links={siteConfig.footer.company} />
            <FooterColumn title="Resources" links={siteConfig.footer.resources} />
            <FooterColumn title="Legal" links={siteConfig.footer.legal} />
          </nav>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-border pt-8 sm:flex-row sm:items-center">
          <p className="text-xs text-muted-foreground">
            © {year} {siteConfig.name}. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Built with Next.js, Tailwind CSS, and Framer Motion.
          </p>
        </div>
      </Container>
    </footer>
  );
}

function FooterColumn({
  title,
  links,
}: {
  title: string;
  links: readonly { label: string; href: string }[];
}) {
  return (
    <div>
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      <ul className="mt-4 space-y-2">
        {links.map((link) => (
          <li key={link.label}>
            <Link
              href={link.href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SocialLink({
  href,
  label,
  icon,
}: {
  href: string;
  label: string;
  icon: React.ReactNode;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-card/50 text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {icon}
    </a>
  );
}

function NewsletterForm() {
  const { toast } = useToast();
  const [email, setEmail] = React.useState("");
  const [status, setStatus] = React.useState<"idle" | "loading" | "success" | "error">("idle");
  const inputId = "newsletter-email";
  const errorId = "newsletter-error";

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setStatus("error");
      return;
    }
    setStatus("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "newsletter", email }),
      });
      if (!res.ok) throw new Error("Request failed");
      setStatus("success");
      setEmail("");
      toast({
        title: "Subscribed",
        description: "You'll hear from us when we ship something worth your time.",
      });
    } catch {
      setStatus("error");
      toast({
        title: "Something went wrong",
        description: "Please try again in a moment.",
        variant: "destructive",
      });
    }
  };

  return (
    <form className="mt-6 max-w-sm" onSubmit={onSubmit} noValidate>
      <Label htmlFor={inputId} className="text-xs text-muted-foreground">
        Get product updates
      </Label>
      <div className="mt-2 flex gap-2">
        <Input
          id={inputId}
          type="email"
          placeholder="you@company.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            if (status === "error") setStatus("idle");
          }}
          aria-invalid={status === "error"}
          aria-describedby={status === "error" ? errorId : undefined}
          disabled={status === "loading" || status === "success"}
          className="flex-1"
        />
        <Button
          type="submit"
          size="sm"
          disabled={status === "loading" || status === "success"}
          aria-label="Subscribe"
        >
          {status === "loading" ? (
            <span className="flex items-center gap-2">
              <span className="h-3 w-3 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground" />
              Subscribing
            </span>
          ) : status === "success" ? (
            "Subscribed"
          ) : (
            <ArrowRight className="h-4 w-4" />
          )}
        </Button>
      </div>
      {status === "error" && (
        <p id={errorId} className="mt-2 text-xs text-destructive" role="alert">
          Please enter a valid email address.
        </p>
      )}
    </form>
  );
}
