"use client";

import Image from "next/image";
import { Section, Container } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { Marquee } from "@/components/primitives/marquee";
import { logoCloud } from "@/config/content";

/**
 * LogoCloud — "Trusted by teams at" + auto-scrolling marquee of company logos.
 * - Pause on hover
 * - Reduced-motion: static wrapped grid
 * - Logos are monochrome SVGs that use currentColor — automatically theme-aware
 */
export function LogoCloud() {
  return (
    <Section className="py-14 md:py-16">
      <Container>
        <Reveal className="text-center">
          <p className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Trusted by fast-moving teams at
          </p>
        </Reveal>
        <Reveal delay={0.1} className="mt-8">
          <Marquee>
            {logoCloud.map((logo) => (
              <div
                key={logo.name}
                className="flex h-12 w-32 items-center justify-center text-muted-foreground/60 transition-colors hover:text-foreground"
              >
                <Image
                  src={logo.src}
                  alt={`${logo.name} logo`}
                  width={120}
                  height={32}
                  loading="eager"
                  className="h-7 w-auto opacity-70"
                />
              </div>
            ))}
          </Marquee>
        </Reveal>
      </Container>
    </Section>
  );
}
