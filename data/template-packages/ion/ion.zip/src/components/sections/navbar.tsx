"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, useScroll, useMotionValueEvent, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { siteConfig } from "@/config/site";
import { ThemeToggle } from "@/components/theme-toggle";
import { BrandMark } from "@/components/brand-mark";
import { Button } from "@/components/ui/button";

/**
 * Navbar — sticky, becomes a condensed glass bar after scrolling past hero.
 * Mobile: slide-in drawer with staggered link entrance, focus trap, Escape to close.
 */

export function Navbar() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    setScrolled(latest > 40);
  });

  // Close mobile menu on route change
  React.useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  // Lock body scroll when drawer is open
  React.useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  // Close on Escape
  React.useEffect(() => {
    if (!mobileOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMobileOpen(false);
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [mobileOpen]);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-300",
          scrolled ? "py-2" : "py-4"
        )}
      >
        <div className="container-ion">
          <nav
            aria-label="Primary"
            className={cn(
              "flex items-center justify-between gap-4 rounded-2xl px-4 transition-all duration-300",
              scrolled
                ? "glass-strong h-14 shadow-lg"
                : "h-16 bg-transparent border border-transparent"
            )}
          >
            {/* Logo */}
            <Link
              href="/"
              className="flex items-center gap-2 rounded-md px-1 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              aria-label={`${siteConfig.name} — home`}
            >
              <BrandMark className="h-7 w-7" />
              <span className="text-lg font-semibold tracking-tight text-foreground">{siteConfig.name}</span>
            </Link>

            {/* Desktop nav links */}
            <ul className="hidden items-center gap-1 md:flex">
              {siteConfig.nav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="group relative rounded-md px-3 py-2 text-sm font-medium text-foreground/70 transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {item.label}
                    <span className="absolute inset-x-3 -bottom-0.5 h-0.5 origin-left scale-x-0 bg-primary transition-transform duration-200 group-hover:scale-x-100" />
                  </Link>
                </li>
              ))}
            </ul>

            {/* Right side: theme toggle + CTAs */}
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Link
                href={siteConfig.cta.secondary.href}
                className="hidden rounded-md px-3 py-2 text-sm font-medium text-foreground/70 transition-colors hover:text-foreground sm:inline-block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {siteConfig.cta.secondary.label}
              </Link>
              <Button
                asChild
                size="sm"
                className="hidden sm:inline-flex"
              >
                <Link href={siteConfig.cta.primary.href}>
                  {siteConfig.cta.primary.label}
                </Link>
              </Button>

              {/* Mobile menu trigger */}
              <button
                type="button"
                aria-label="Open menu"
                aria-expanded={mobileOpen}
                aria-controls="mobile-menu"
                onClick={() => setMobileOpen(true)}
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-card/50 text-foreground md:hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Menu className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>
          </nav>
        </div>
      </header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <MobileMenu
            onClose={() => setMobileOpen(false)}
            navItems={[...siteConfig.nav]}
          />
        )}
      </AnimatePresence>
    </>
  );
}

/* Mobile slide-in drawer with focus trap */
function MobileMenu({
  onClose,
  navItems,
}: {
  onClose: () => void;
  navItems: { label: string; href: string }[];
}) {
  const drawerRef = React.useRef<HTMLDivElement>(null);
  const closeBtnRef = React.useRef<HTMLButtonElement>(null);

  // Focus trap
  React.useEffect(() => {
    const drawer = drawerRef.current;
    if (!drawer) return;

    const previouslyFocused = document.activeElement as HTMLElement | null;
    closeBtnRef.current?.focus();

    const trap = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;
      const focusable = drawer.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", trap);
    return () => {
      document.removeEventListener("keydown", trap);
      previouslyFocused?.focus();
    };
  }, []);

  return (
    <div
      className="fixed inset-0 z-[60] md:hidden"
      role="dialog"
      aria-modal="true"
      aria-label="Site menu"
    >
      {/* Backdrop */}
      <motion.div
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      />
      {/* Drawer */}
      <motion.div
        ref={drawerRef}
        id="mobile-menu"
        className="absolute right-0 top-0 h-full w-[88%] max-w-sm glass-strong p-6"
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 26, stiffness: 240 }}
      >
        <div className="flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2"
            onClick={onClose}
            aria-label={`${siteConfig.name} — home`}
          >
            <BrandMark className="h-7 w-7 text-primary" />
            <span className="text-lg font-semibold">{siteConfig.name}</span>
          </Link>
          <button
            ref={closeBtnRef}
            type="button"
            aria-label="Close menu"
            onClick={onClose}
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-border text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        {/* Staggered link entrance */}
        <motion.ul
          className="mt-8 flex flex-col gap-1"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.06, delayChildren: 0.1 } },
          }}
        >
          {navItems.map((item) => (
            <motion.li
              key={item.href}
              variants={{
                hidden: { opacity: 0, x: 20 },
                visible: { opacity: 1, x: 0 },
              }}
            >
              <Link
                href={item.href}
                className="block rounded-lg px-4 py-3 text-lg font-medium text-foreground/80 transition-colors hover:bg-accent/50 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {item.label}
              </Link>
            </motion.li>
          ))}
        </motion.ul>

        <div className="mt-8 flex flex-col gap-3">
          <Button asChild size="lg">
            <Link href={siteConfig.cta.primary.href} onClick={onClose}>
              {siteConfig.cta.primary.label}
            </Link>
          </Button>
          <Button asChild size="lg" variant="ghost">
            <Link href={siteConfig.cta.secondary.href} onClick={onClose}>
              {siteConfig.cta.secondary.label}
            </Link>
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

/** BrandMark is now imported from @/components/brand-mark — kept here only for the
 *  unused local declaration below to avoid breaking the export. */

