"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, AlertCircle, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { cn } from "@/lib/utils";

/**
 * ContactForm — full validated form with react-hook-form + zod.
 * States: idle → loading → success (replaces form) / error (retry affordance).
 *
 * Submitting to /api/contact — see that route for where to plug in Resend/Formspree/your DB.
 */

const contactSchema = z.object({
  name: z
    .string()
    .min(2, "Please enter your name (2+ characters).")
    .max(100, "That's a bit long. Please keep it under 100 characters."),
  email: z
    .string()
    .min(1, "Email is required.")
    .email("Please enter a valid email address."),
  company: z
    .string()
    .max(100, "Please keep it under 100 characters.")
    .optional()
    .or(z.literal("")),
  message: z
    .string()
    .min(10, "Tell us a bit more — at least 10 characters.")
    .max(2000, "Please keep it under 2000 characters."),
});

type ContactFormValues = z.infer<typeof contactSchema>;

type Status = "idle" | "loading" | "success" | "error";

export function ContactForm({ className }: { className?: string }) {
  const [status, setStatus] = React.useState<Status>("idle");
  const [errorMessage, setErrorMessage] = React.useState<string>("");

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      message: "",
    },
    mode: "onBlur",
  });

  const onSubmit = async (values: ContactFormValues) => {
    setStatus("loading");
    setErrorMessage("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "contact", ...values }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };

      if (!res.ok) {
        throw new Error(data.error || "Request failed");
      }
      setStatus("success");
    } catch (err) {
      setStatus("error");
      setErrorMessage(
        err instanceof Error && err.message
          ? err.message
          : "Something went wrong. Please try again, or email us directly at hello@ion.app."
      );
    }
  };

  return (
    <div className={cn("relative", className)}>
      <AnimatePresence mode="wait">
        {status === "success" ? (
          <SuccessState
            key="success"
            onReset={() => {
              form.reset();
              setStatus("idle");
            }}
          />
        ) : (
          <motion.div
            key="form"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -8 }}
          >
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(onSubmit)}
                className="space-y-5"
                noValidate
                aria-busy={status === "loading"}
              >
                <div className="grid gap-5 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Maya Okafor"
                            autoComplete="name"
                            disabled={status === "loading"}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            type="email"
                            placeholder="maya@northwind.com"
                            autoComplete="email"
                            disabled={status === "loading"}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Company <span className="text-muted-foreground">(optional)</span>
                      </FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Northwind"
                          autoComplete="organization"
                          disabled={status === "loading"}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>How can we help?</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="We're a 30-person team evaluating Ion for our engineering org. Curious about SSO and bulk import…"
                          rows={5}
                          disabled={status === "loading"}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {status === "error" && (
                  <div
                    role="alert"
                    className="flex items-start gap-3 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive"
                  >
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                    <div className="flex-1">
                      <p>{errorMessage}</p>
                      <button
                        type="button"
                        onClick={() => setStatus("idle")}
                        className="mt-1 text-xs underline hover:no-underline"
                      >
                        Try again
                      </button>
                    </div>
                  </div>
                )}

                <Button
                  type="submit"
                  size="lg"
                  disabled={status === "loading"}
                  className="w-full sm:w-auto"
                >
                  {status === "loading" ? (
                    <>
                      <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden="true" />
                      Sending…
                    </>
                  ) : (
                    <>
                      <Send className="mr-1.5 h-4 w-4" aria-hidden="true" />
                      Send message
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SuccessState({ onReset }: { onReset: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0 }}
      className="rounded-2xl border border-primary/30 bg-primary/5 p-8 text-center"
    >
      <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-primary text-primary-foreground">
        <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
      </div>
      <h3 className="mt-4 text-lg font-semibold text-foreground">Message sent</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        Thanks for reaching out. We&apos;ll get back to you within one business day — usually much faster.
      </p>
      <Button variant="ghost" size="sm" className="mt-4" onClick={onReset}>
        Send another
      </Button>
    </motion.div>
  );
}

/** Lightweight waitlist variant — email only. */
const waitlistSchema = z.object({
  email: z.string().min(1, "Email is required.").email("Please enter a valid email."),
});

export function WaitlistForm({ className }: { className?: string }) {
  const [status, setStatus] = React.useState<Status>("idle");
  const [email, setEmail] = React.useState("");
  const inputId = React.useId();

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = waitlistSchema.safeParse({ email });
    if (!parsed.success) {
      setStatus("error");
      return;
    }
    setStatus("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "waitlist", email: parsed.data.email }),
      });
      if (!res.ok) throw new Error("Request failed");
      setStatus("success");
    } catch {
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <div className={cn("flex items-center gap-2 text-sm text-primary", className)}>
        <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
        You&apos;re on the list — we&apos;ll be in touch.
      </div>
    );
  }

  return (
    <form className={cn("flex gap-2", className)} onSubmit={onSubmit} noValidate>
      <Label htmlFor={inputId} className="sr-only">
        Email address
      </Label>
      <Input
        id={inputId}
        type="email"
        placeholder="you@company.com"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value);
          if (status === "error") setStatus("idle");
        }}
        aria-invalid={status === "error"}
        disabled={status === "loading"}
        className="flex-1"
      />
      <Button type="submit" disabled={status === "loading"}>
        {status === "loading" ? "Joining…" : "Join waitlist"}
      </Button>
    </form>
  );
}
