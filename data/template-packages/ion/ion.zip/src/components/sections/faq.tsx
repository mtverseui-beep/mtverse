"use client";

import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { faq } from "@/config/content";

/**
 * FAQ — Radix Accordion, single-open (consistent interaction model).
 * 8 real, specific questions covering pricing, security, migration, support, technical.
 */
export function FAQ() {
  return (
    <Section id="faq" muted className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>FAQ</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">Questions, answered.</h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              Still curious?{" "}
              <a
                href="/contact"
                className="font-medium text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
              >
                Reach out
              </a>{" "}
              — we usually reply within a few hours.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.15} className="mx-auto mt-12 max-w-3xl">
          <Accordion type="single" collapsible className="w-full">
            {faq.map((item) => (
              <AccordionItem
                key={item.q}
                value={item.q}
                className="border-b border-border"
              >
                <AccordionTrigger className="text-left text-base font-medium hover:no-underline">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </Container>
    </Section>
  );
}
