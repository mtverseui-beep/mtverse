"use client";

import { Check, X } from "lucide-react";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal, RevealGroup, revealItemVariants } from "@/components/primitives/reveal";
import { AnimatedCounter } from "@/components/primitives/animated-counter";
import { motion } from "framer-motion";
import { problemSolution } from "@/config/content";

/**
 * ProblemSolution — reframes pain points vs how Ion changes them, with animated stat counters.
 */
export function ProblemSolution() {
  return (
    <Section id="problem" muted>
      <Container>
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left: problem → solution */}
          <div>
            <Reveal>
              <Eyebrow>The shift</Eyebrow>
            </Reveal>
            <Reveal delay={0.05}>
              <h2 className="display-2 mt-4 text-balance">
                You didn&apos;t sign up to be a{" "}
                <span className="text-muted-foreground">tab-juggler</span>.
              </h2>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-6 text-lg text-muted-foreground">
                Modern teams burn hours stitching tools together. Ion replaces the patchwork
                with one workspace — and gives you the hours back.
              </p>
            </Reveal>

            <RevealGroup as="ul" className="mt-8 space-y-3" stagger={0.08}>
              {problemSolution.problems.map((problem) => (
                <motion.li
                  key={problem}
                  variants={revealItemVariants}
                  className="flex items-start gap-3 rounded-lg border border-border bg-card/40 p-3"
                >
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-destructive/15 text-destructive">
                    <X className="h-3 w-3" aria-hidden="true" />
                  </span>
                  <span className="text-sm text-muted-foreground">{problem}</span>
                </motion.li>
              ))}
            </RevealGroup>

            <Reveal delay={0.4}>
              <div className="mt-6 rounded-xl border border-primary/30 bg-primary/5 p-5">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground">
                    <Check className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <p className="text-base font-medium text-foreground">
                    {problemSolution.solution}
                  </p>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Right: stats */}
          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1 lg:gap-6">
            {problemSolution.stats.map((stat, i) => (
              <Reveal
                key={stat.label}
                delay={0.15 + i * 0.1}
                className="rounded-2xl border border-border bg-card p-6 lg:p-8"
              >
                <div className="text-4xl font-semibold tracking-tight text-foreground md:text-5xl">
                  <AnimatedCounter
                    value={stat.value}
                    decimals={stat.decimals}
                    suffix={stat.suffix}
                  />
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{stat.label}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </Container>
    </Section>
  );
}
