"use client";

import * as React from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Check } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { showcase } from "@/config/content";

/**
 * ProductShowcase — Radix Tabs, crossfade between product screenshots,
 * feature-benefit list beside each. The "proof" section.
 */
export function ProductShowcase() {
  const [active, setActive] = React.useState(showcase[0].id);
  const current = showcase.find((s) => s.id === active) ?? showcase[0];

  return (
    <Section id="product" className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>Product tour</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">
              See Ion in action.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              Three surfaces, one workspace. Switch between them with the tabs below.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.15} className="mt-12">
          <Tabs
            value={active}
            onValueChange={setActive}
            className="flex flex-col items-center gap-8"
          >
            <TabsList className="glass h-auto flex-wrap gap-1 p-1">
              {showcase.map((tab) => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="rounded-lg px-4 py-2 text-sm font-medium data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>

            {showcase.map((tab) => (
              <TabsContent
                key={tab.id}
                value={tab.id}
                className="w-full mt-0 focus-visible:outline-none"
              >
                <div className="grid items-center gap-8 lg:grid-cols-2 lg:gap-12">
                  {/* Screenshot with crossfade */}
                  <div className="relative">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={tab.id}
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 1.02 }}
                        transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                        className="overflow-hidden rounded-2xl border border-border bg-card shadow-xl"
                      >
                        <div className="relative aspect-[16/10] w-full bg-background">
                          <Image
                            src={tab.image}
                            alt={`${tab.title} — ${tab.description}`}
                            fill
                            sizes="(min-width: 1024px) 50vw, 100vw"
                            className="object-cover"
                          />
                        </div>
                      </motion.div>
                    </AnimatePresence>
                  </div>

                  {/* Feature list */}
                  <div>
                    <h3 className="display-3 text-balance">{tab.title}</h3>
                    <p className="mt-4 text-lg text-muted-foreground">{tab.description}</p>
                    <ul className="mt-6 space-y-3">
                      {tab.bullets.map((bullet) => (
                        <li key={bullet} className="flex items-start gap-3">
                          <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary/15 text-primary">
                            <Check className="h-3 w-3" aria-hidden="true" />
                          </span>
                          <span className="text-sm text-foreground">{bullet}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </Reveal>

        {/* Hidden semantic reference to current tab for screen readers */}
        <span className="sr-only">Currently viewing: {current.title}</span>
      </Container>
    </Section>
  );
}
