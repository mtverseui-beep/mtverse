"use client";

import * as React from "react";
import Image from "next/image";
import { Star, Quote } from "lucide-react";
import { Section, Container, Eyebrow } from "@/components/primitives/section";
import { Reveal } from "@/components/primitives/reveal";
import { Marquee } from "@/components/primitives/marquee";
import { heroTestimonial, testimonials, type Testimonial } from "@/config/content";

/**
 * Testimonials — 1 large "hero" testimonial + marquee of 7 shorter ones.
 * Avatars are self-hosted. Star ratings rendered where present.
 */
export function Testimonials() {
  return (
    <Section id="testimonials" muted className="py-20 md:py-28">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <Reveal>
            <Eyebrow>Loved by teams</Eyebrow>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="display-2 mt-4 text-balance">
              Don&apos;t take our word for it.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 text-lg text-muted-foreground">
              412 reviews. 4.9-star average. Here&apos;s a sampling.
            </p>
          </Reveal>
        </div>

        {/* Hero testimonial */}
        <Reveal delay={0.15} className="mt-14">
          <figure className="mx-auto max-w-4xl rounded-3xl border border-border bg-card p-8 md:p-12">
            <Quote className="h-8 w-8 text-primary" aria-hidden="true" />
            <blockquote className="mt-4 text-2xl font-medium leading-snug text-foreground md:text-3xl md:leading-snug">
              {heroTestimonial.quote}
            </blockquote>
            <figcaption className="mt-6 flex items-center gap-4">
              <Image
                src={heroTestimonial.avatar}
                alt=""
                width={48}
                height={48}
                className="h-12 w-12 rounded-full ring-2 ring-border"
              />
              <div>
                <div className="font-semibold text-foreground">{heroTestimonial.name}</div>
                <div className="text-sm text-muted-foreground">
                  {heroTestimonial.role}, {heroTestimonial.company}
                </div>
              </div>
              {heroTestimonial.rating && (
                <div
                  className="ml-auto flex items-center gap-0.5"
                  aria-label={`${heroTestimonial.rating} out of 5 stars`}
                >
                  {Array.from({ length: heroTestimonial.rating }).map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-primary text-primary"
                      aria-hidden="true"
                    />
                  ))}
                </div>
              )}
            </figcaption>
          </figure>
        </Reveal>

        {/* Marquee of shorter testimonials */}
        <div className="mt-12">
          <Marquee>
            {testimonials.map((t) => (
              <TestimonialCard key={t.name} t={t} />
            ))}
          </Marquee>
        </div>
      </Container>
    </Section>
  );
}

function TestimonialCard({ t }: { t: Testimonial }) {
  return (
    <figure className="w-80 shrink-0 rounded-2xl border border-border bg-card p-6">
      {t.rating && (
        <div
          className="flex items-center gap-0.5"
          aria-label={`${t.rating} out of 5 stars`}
        >
          {Array.from({ length: t.rating }).map((_, i) => (
            <Star key={i} className="h-3.5 w-3.5 fill-primary text-primary" aria-hidden="true" />
          ))}
        </div>
      )}
      <blockquote className="mt-3 text-sm leading-relaxed text-foreground">
        &ldquo;{t.quote}&rdquo;
      </blockquote>
      {t.metric && (
        <div className="mt-4 rounded-lg border border-primary/30 bg-primary/5 p-3">
          <div className="text-2xl font-semibold text-primary">{t.metric.value}</div>
          <div className="text-xs text-muted-foreground">{t.metric.label}</div>
        </div>
      )}
      <figcaption className="mt-4 flex items-center gap-3">
        <Image
          src={t.avatar}
          alt=""
          width={32}
          height={32}
          loading="eager"
          className="h-8 w-8 rounded-full ring-2 ring-border"
        />
        <div>
          <div className="text-sm font-semibold text-foreground">{t.name}</div>
          <div className="text-xs text-muted-foreground">
            {t.role}, {t.company}
          </div>
        </div>
      </figcaption>
    </figure>
  );
}
