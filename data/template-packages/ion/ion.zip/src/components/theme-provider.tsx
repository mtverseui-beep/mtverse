"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ThemeProviderProps } from "next-themes";

/**
 * ThemeProvider — wraps next-themes with sensible defaults.
 * - Default theme: light (per user request — light mode is the default)
 * - Respects prefers-color-scheme for returning visitors who haven't chosen
 * - enableSystem + disableTransitionOnChange = no flash on toggle/reload
 * The blocking <script> in layout.tsx sets the class BEFORE hydration,
 * so there is zero flash-of-wrong-theme on load.
 */
export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="light"
      enableSystem={false}
      disableTransitionOnChange
      {...props}
    >
      {children}
    </NextThemesProvider>
  );
}
