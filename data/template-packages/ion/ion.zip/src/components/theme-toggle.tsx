"use client";

import * as React from "react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";

/**
 * ThemeToggle — accessible dark/light switch.
 * - aria-label + aria-pressed for screen readers
 * - visible focus ring
 * - mounts cleanly (no hydration mismatch: renders a stable icon until mounted)
 */
export function ThemeToggle({ className }: { className?: string }) {
  const { resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);

  // Compute aria attributes from mounted state to avoid hydration mismatch.
  // Default theme is light, so before mount we render the light-mode state
  // (aria-label "Switch to dark mode", aria-pressed false, moon visible).
  // After mount, switch to the actual resolved theme.
  const isDark = mounted ? resolvedTheme === "dark" : false;
  const label = isDark ? "Switch to light mode" : "Switch to dark mode";

  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={isDark}
      onClick={() => setTheme(isDark ? "light" : "dark")}
      className={cn(
        "relative inline-flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-card/50 text-foreground/70 transition-colors hover:bg-card hover:text-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        className
      )}
    >
      {/* Sun: visible in dark mode (action = switch to light) */}
      <Sun
        className={cn(
          "h-[18px] w-[18px] transition-all duration-300",
          mounted && isDark ? "rotate-0 scale-100" : "-rotate-90 scale-0"
        )}
        aria-hidden="true"
      />
      {/* Moon: visible in light mode */}
      <Moon
        className={cn(
          "absolute h-[18px] w-[18px] transition-all duration-300",
          mounted && !isDark ? "rotate-0 scale-100" : "rotate-90 scale-0"
        )}
        aria-hidden="true"
      />
    </button>
  );
}
