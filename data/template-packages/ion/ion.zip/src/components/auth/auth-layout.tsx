import Link from "next/link";
import { ThemeToggle } from "@/components/theme-toggle";
import { GlowOrb } from "@/components/primitives/glow";
import { BrandMark } from "@/components/brand-mark";
import { siteConfig } from "@/config/site";

/**
 * AuthLayout — shared layout for /login, /signup, /forgot-password,
 * /reset-password, /verify-email. Two-column: left = brand panel,
 * right = form. Collapses to single column on mobile.
 */
export function AuthLayout({
  children,
  title,
  subtitle,
}: {
  children: React.ReactNode;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Ambient glow */}
      <GlowOrb
        className="left-1/4 top-0"
        color="var(--primary)"
        opacity={0.12}
        size={600}
      />

      {/* Top bar — just logo + theme toggle (no full nav on auth pages) */}
      <header className="relative z-10 flex items-center justify-between px-6 py-5 md:px-8">
        <Link
          href="/"
          className="flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={`${siteConfig.name} — home`}
        >
          <BrandMark className="h-7 w-7" />
          <span className="text-lg font-semibold tracking-tight text-foreground">
            {siteConfig.name}
          </span>
        </Link>
        <ThemeToggle />
      </header>

      <main className="relative z-10 mx-auto grid min-h-[calc(100vh-80px)] max-w-6xl grid-cols-1 items-center gap-12 px-6 py-8 md:px-8 lg:grid-cols-2 lg:gap-16">
        {/* Left: brand / testimonial panel (hidden on mobile) */}
        <div className="hidden lg:block">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            ← Back to home
          </Link>
          <h2 className="display-2 mt-8 text-balance text-foreground">
            The AI workspace that thinks ahead.
          </h2>
          <p className="mt-4 max-w-md text-lg text-muted-foreground">
            Join 4,000+ teams using Ion to unify their stack, automate the busywork, and ship faster.
          </p>

          {/* Testimonial chip */}
          <figure className="mt-10 rounded-2xl border border-border bg-card/50 p-6">
            <blockquote className="text-base text-foreground">
              &ldquo;We replaced four tools with Ion and got a fifth one free — an AI that actually
              knows what we&apos;re working on. Cycle time dropped by a third in the first month.&rdquo;
            </blockquote>
            <figcaption className="mt-4 text-sm text-muted-foreground">
              Maya Okafor · VP Engineering, Northwind
            </figcaption>
          </figure>
        </div>

        {/* Right: form card */}
        <div className="mx-auto w-full max-w-md">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-xl md:p-8">
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">{title}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>
            <div className="mt-6">{children}</div>
          </div>
        </div>
      </main>
    </div>
  );
}

/** BrandMark is imported from @/components/brand-mark at the top of this file. */

