"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, ArrowRight, Eye, EyeOff, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const signupSchema = z
  .object({
    name: z
      .string()
      .min(2, "Please enter your name (2+ characters).")
      .max(100, "Please keep it under 100 characters."),
    email: z.string().min(1, "Email is required.").email("Please enter a valid email."),
    password: z
      .string()
      .min(8, "Password must be at least 8 characters.")
      .regex(/[A-Z]/, "Include at least one uppercase letter.")
      .regex(/[0-9]/, "Include at least one number."),
    company: z.string().max(100).optional().or(z.literal("")),
    terms: z
      .boolean()
      .refine((v) => v === true, "You must accept the Terms to continue."),
  })
  .refine((data) => data.password.length >= 8, { path: ["password"], message: "" });

type SignupFormValues = z.infer<typeof signupSchema>;

export function SignupForm() {
  const router = useRouter();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = React.useState(false);
  const [status, setStatus] = React.useState<"idle" | "loading" | "error">("idle");
  const [errorMessage, setErrorMessage] = React.useState("");

  const form = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: { name: "", email: "", password: "", company: "", terms: false },
    mode: "onBlur",
  });

  const password = form.watch("password");
  const pwChecks = {
    length: password.length >= 8,
    upper: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
  };

  const onSubmit = async (values: SignupFormValues) => {
    setStatus("loading");
    setErrorMessage("");
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || "Signup failed");
      toast({
        title: "Account created",
        description: "Check your email to verify your address.",
      });
      router.push("/verify-email?email=" + encodeURIComponent(values.email));
    } catch (err) {
      setStatus("error");
      setErrorMessage(
        err instanceof Error && err.message
          ? err.message
          : "Signup failed. Please try again."
      );
    }
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" noValidate>
      <div className="space-y-2">
        <Label htmlFor="name">Full name</Label>
        <Input
          id="name"
          placeholder="Maya Okafor"
          autoComplete="name"
          autoFocus
          disabled={status === "loading"}
          {...form.register("name")}
          aria-invalid={!!form.formState.errors.name}
        />
        {form.formState.errors.name && (
          <p className="text-xs text-destructive" role="alert">
            {form.formState.errors.name.message}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Work email</Label>
        <Input
          id="email"
          type="email"
          placeholder="maya@northwind.com"
          autoComplete="email"
          disabled={status === "loading"}
          {...form.register("email")}
          aria-invalid={!!form.formState.errors.email}
        />
        {form.formState.errors.email && (
          <p className="text-xs text-destructive" role="alert">
            {form.formState.errors.email.message}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="company">
          Company <span className="text-muted-foreground">(optional)</span>
        </Label>
        <Input
          id="company"
          placeholder="Northwind"
          autoComplete="organization"
          disabled={status === "loading"}
          {...form.register("company")}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <div className="relative">
          <Input
            id="password"
            type={showPassword ? "text" : "password"}
            placeholder="Create a password"
            autoComplete="new-password"
            disabled={status === "loading"}
            {...form.register("password")}
            aria-invalid={!!form.formState.errors.password}
            className="pr-10"
          />
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={showPassword ? "Hide password" : "Show password"}
          >
            {showPassword ? (
              <EyeOff className="h-4 w-4" aria-hidden="true" />
            ) : (
              <Eye className="h-4 w-4" aria-hidden="true" />
            )}
          </button>
        </div>
        {/* Password strength indicators */}
        {password.length > 0 && (
          <ul className="mt-2 space-y-1" aria-label="Password requirements">
            <PasswordCheck ok={pwChecks.length} label="8+ characters" />
            <PasswordCheck ok={pwChecks.upper} label="Uppercase letter" />
            <PasswordCheck ok={pwChecks.number} label="Number" />
          </ul>
        )}
        {form.formState.errors.password && (
          <p className="text-xs text-destructive" role="alert">
            {form.formState.errors.password.message}
          </p>
        )}
      </div>

      <div className="flex items-start gap-2">
        <input
          id="terms"
          type="checkbox"
          className="mt-0.5 h-4 w-4 rounded border-border text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          {...form.register("terms")}
          aria-invalid={!!form.formState.errors.terms}
        />
        <Label htmlFor="terms" className="text-sm font-normal text-muted-foreground">
          I agree to the{" "}
          <Link href="/terms" className="text-primary hover:underline">
            Terms
          </Link>{" "}
          and{" "}
          <Link href="/privacy" className="text-primary hover:underline">
            Privacy Policy
          </Link>
        </Label>
      </div>
      {form.formState.errors.terms && (
        <p className="text-xs text-destructive" role="alert">
          {form.formState.errors.terms.message}
        </p>
      )}

      {status === "error" && (
        <div
          role="alert"
          className="rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive"
        >
          {errorMessage}
        </div>
      )}

      <Button type="submit" className="w-full" disabled={status === "loading"}>
        {status === "loading" ? (
          <>
            <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden="true" />
            Creating account…
          </>
        ) : (
          <>
            Create free account
            <ArrowRight className="ml-1.5 h-4 w-4" aria-hidden="true" />
          </>
        )}
      </Button>

      <p className="text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-primary hover:underline">
          Sign in
        </Link>
      </p>
    </form>
  );
}

function PasswordCheck({ ok, label }: { ok: boolean; label: string }) {
  return (
    <li
      className={`flex items-center gap-2 text-xs ${
        ok ? "text-success" : "text-muted-foreground"
      }`}
    >
      <span
        className={`grid h-3.5 w-3.5 place-items-center rounded-full ${
          ok ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"
        }`}
      >
        {ok && <Check className="h-2.5 w-2.5" aria-hidden="true" />}
      </span>
      {label}
    </li>
  );
}
