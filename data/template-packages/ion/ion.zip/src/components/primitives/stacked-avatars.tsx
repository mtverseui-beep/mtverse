import * as React from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";

/**
 * StackedAvatars — overlapping circular avatars used for social proof.
 * Self-hosted images only (per spec §10.4 — no hotlinked external images).
 */
export function StackedAvatars({
  avatars,
  alt,
  size = 32,
  overlap = 8,
  className,
}: {
  avatars: string[];
  alt: string;
  size?: number;
  overlap?: number;
  className?: string;
}) {
  return (
    <div
      className={cn("flex items-center", className)}
      style={{ paddingLeft: `${(avatars.length - 1) * overlap}px` }}
      role="img"
      aria-label={alt}
    >
      {avatars.map((src, i) => (
        <div
          key={src + i}
          className="relative rounded-full ring-2 ring-background overflow-hidden"
          style={{
            width: size,
            height: size,
            marginLeft: i === 0 ? 0 : -overlap - size + overlap,
          }}
        >
          <Image
            src={src}
            alt=""
            fill
            sizes={`${size}px`}
            className="object-cover"
          />
        </div>
      ))}
    </div>
  );
}
