"use client";

import * as React from "react";
import { motion, useReducedMotion, type Variants } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Reveal — scroll-triggered fade + rise, with full prefers-reduced-motion support.
 * When reduced motion is preferred, the content is rendered without animation
 * (just made visible immediately).
 *
 * Usage:
 *   <Reveal>content</Reveal>
 *   <Reveal delay={0.1}>staggered child</Reveal>
 *   <Reveal as="h2">headline</Reveal>
 */

type RevealProps = {
  children: React.ReactNode;
  className?: string;
  /** delay in seconds */
  delay?: number;
  /** y-offset to rise from, in px */
  y?: number;
  /** render as a different element (default: div) */
  as?: "div" | "section" | "h1" | "h2" | "h3" | "p" | "li" | "span";
  /** only animate the first time it enters viewport */
  once?: boolean;
};

export function Reveal({
  children,
  className,
  delay = 0,
  y = 16,
  as = "div",
  once = true,
}: RevealProps) {
  const reduceMotion = useReducedMotion();

  const MotionTag = motion[as] as typeof motion.div;

  const variants: Variants = {
    hidden: {
      opacity: 0,
      y: reduceMotion ? 0 : y,
      filter: reduceMotion ? "blur(0px)" : "blur(4px)",
    },
    visible: {
      opacity: 1,
      y: 0,
      filter: "blur(0px)",
      transition: {
        duration: reduceMotion ? 0 : 0.5,
        delay: reduceMotion ? 0 : delay,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  return (
    <MotionTag
      className={cn(className)}
      variants={variants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once, margin: "-80px 0px -80px 0px" }}
    >
      {children}
    </MotionTag>
  );
}

/**
 * RevealGroup — wraps a list of children and staggers their reveal.
 * Children should be <Reveal> or any motion element with variants.
 */
export function RevealGroup({
  children,
  className,
  stagger = 0.08,
  as = "div",
}: {
  children: React.ReactNode;
  className?: string;
  stagger?: number;
  as?: "div" | "ul" | "ol" | "section";
}) {
  const reduceMotion = useReducedMotion();
  const MotionTag = motion[as] as typeof motion.div;

  return (
    <MotionTag
      className={cn(className)}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-80px 0px -80px 0px" }}
      variants={{
        hidden: {},
        visible: {
          transition: {
            staggerChildren: reduceMotion ? 0 : stagger,
          },
        },
      }}
    >
      {children}
    </MotionTag>
  );
}

/** Item variant for use inside <RevealGroup> */
export const revealItemVariants: Variants = {
  hidden: { opacity: 0, y: 16, filter: "blur(4px)" },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
  },
};
