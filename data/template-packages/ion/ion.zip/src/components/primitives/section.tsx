import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Section — semantic <section> wrapper with consistent vertical rhythm.
 * - `id` for anchor navigation (#features, #pricing, etc.)
 * - `muted` switches to a slightly darker bg for alternating sections
 */
export function Section({
  id,
  className,
  children,
  muted = false,
  ...props
}: React.HTMLAttributes<HTMLElement> & { id?: string; muted?: boolean }) {
  return (
    <section
      id={id}
      className={cn(
        "relative scroll-mt-24 py-20 md:py-28",
        muted && "bg-muted/30",
        className
      )}
      {...props}
    >
      {children}
    </section>
  );
}

/** Container — max-width wrapper */
export function Container({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("container-ion", className)} {...props}>
      {children}
    </div>
  );
}

/** Eyebrow — small mono label with optional pulsing dot */
export function Eyebrow({
  children,
  className,
  pulse = true,
}: {
  children: React.ReactNode;
  className?: string;
  pulse?: boolean;
}) {
  return (
    <span className={cn("eyebrow", className)}>
      {pulse && <span className="eyebrow-dot" aria-hidden="true" />}
      {children}
    </span>
  );
}
