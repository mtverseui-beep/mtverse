import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * GlowOrb — large, very blurred radial gradient positioned behind a section.
 * Single controlled light source (per spec §3 — not a rainbow blob).
 *
 * Place as first child of a `relative` parent, behind content.
 */
export function GlowOrb({
  className,
  color = "var(--primary)",
  opacity = 0.15,
  size = 600,
}: {
  className?: string;
  color?: string;
  opacity?: number;
  size?: number;
}) {
  return (
    <div
      aria-hidden="true"
      className={cn("glow-radial", className)}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(circle, ${color} 0%, transparent 70%)`,
        opacity,
      }}
    />
  );
}

/** NoiseOverlay — fixed full-screen grain texture. Add once near root. */
export function NoiseOverlay() {
  return <div className="noise-overlay" aria-hidden="true" />;
}
