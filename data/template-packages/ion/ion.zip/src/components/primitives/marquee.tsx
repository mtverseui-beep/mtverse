"use client";

import * as React from "react";
import { useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Marquee — auto-scrolling horizontal track.
 * - Pauses on hover (CSS .marquee-paused class)
 * - Respects prefers-reduced-motion: shows static centered row instead of scrolling
 * - Children are duplicated once for seamless loop
 *
 * Usage:
 *   <Marquee>
 *     {items.map(...)}
 *   </Marquee>
 */
export function Marquee({
  children,
  className,
  itemClassName,
  pauseOnHover = true,
}: {
  children: React.ReactNode;
  className?: string;
  itemClassName?: string;
  pauseOnHover?: boolean;
}) {
  const reduceMotion = useReducedMotion();

  if (reduceMotion) {
    // Reduced motion: static, centered, wrapping row. No animation.
    return (
      <div
        className={cn(
          "flex flex-wrap items-center justify-center gap-8",
          className
        )}
      >
        {React.Children.map(children, (child, i) => (
          <div key={i} className={itemClassName}>
            {child}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className={cn("relative overflow-hidden", pauseOnHover && "marquee-paused", className)}>
      {/* edge fade masks */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-background to-transparent"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-background to-transparent"
      />
      <div className="marquee-track">
        <div className={cn("flex shrink-0 items-center gap-12", itemClassName)}>
          {children}
        </div>
        {/* duplicate for seamless loop */}
        <div className={cn("flex shrink-0 items-center gap-12", itemClassName)} aria-hidden="true">
          {children}
        </div>
      </div>
    </div>
  );
}
