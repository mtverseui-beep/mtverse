"use client";

import * as React from "react";
import { User, Bell, Shield, Globe } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const sections = [
  { id: "profile", label: "Profile", icon: User },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "security", label: "Security", icon: Shield },
  { id: "workspace", label: "Workspace", icon: Globe },
];

export function SettingsPanel() {
  const { toast } = useToast();
  const [active, setActive] = React.useState("profile");

  const onSave = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Settings saved", description: "Your changes have been applied." });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-foreground">Settings</h1>
        <p className="text-sm text-muted-foreground">Manage your workspace and preferences.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[200px_1fr]">
        {/* Section nav */}
        <nav className="flex gap-1 overflow-x-auto lg:flex-col" aria-label="Settings sections">
          {sections.map((s) => {
            const Icon = s.icon;
            const isActive = active === s.id;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setActive(s.id)}
                className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                aria-current={isActive ? "page" : undefined}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                {s.label}
              </button>
            );
          })}
        </nav>

        {/* Form */}
        <form onSubmit={onSave} className="space-y-6">
          {active === "profile" && (
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-base font-semibold text-foreground">Profile</h2>
              <p className="mt-1 text-sm text-muted-foreground">How you appear to your team.</p>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Full name</Label>
                  <Input id="name" defaultValue="Maya Okafor" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue="maya@northwind.com" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Input id="role" defaultValue="VP Engineering" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Input id="timezone" defaultValue="America/Los_Angeles" />
                </div>
              </div>
            </div>
          )}

          {active === "notifications" && (
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-base font-semibold text-foreground">Notifications</h2>
              <p className="mt-1 text-sm text-muted-foreground">When and how Ion reaches you.</p>
              <div className="mt-4 space-y-3">
                {[
                  { label: "Weekly digest (Mondays)", desc: "Summary of last week's activity", on: true },
                  { label: "Automation failures", desc: "When an automation can't recover", on: true },
                  { label: "Mentions and assignments", desc: "When someone @mentions you", on: true },
                  { label: "Product updates", desc: "New features and changes", on: false },
                ].map((n) => (
                  <ToggleRow key={n.label} label={n.label} desc={n.desc} defaultOn={n.on} />
                ))}
              </div>
            </div>
          )}

          {active === "security" && (
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-base font-semibold text-foreground">Security</h2>
              <p className="mt-1 text-sm text-muted-foreground">Protect your account.</p>
              <div className="mt-4 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="current">Current password</Label>
                  <Input id="current" type="password" placeholder="••••••••" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new">New password</Label>
                  <Input id="new" type="password" placeholder="••••••••" />
                </div>
                <ToggleRow label="Two-factor authentication" desc="Require a code from your phone" defaultOn={true} />
              </div>
            </div>
          )}

          {active === "workspace" && (
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-base font-semibold text-foreground">Workspace</h2>
              <p className="mt-1 text-sm text-muted-foreground">Settings for your whole team.</p>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="ws-name">Workspace name</Label>
                  <Input id="ws-name" defaultValue="Northwind" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ws-url">Workspace URL</Label>
                  <Input id="ws-url" defaultValue="northwind.ion.app" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="default-model">Default AI model</Label>
                  <Input id="default-model" defaultValue="Claude 3.5 Sonnet" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="retention">Context retention</Label>
                  <Input id="retention" defaultValue="90 days" />
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end">
            <Button type="submit">Save changes</Button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  desc,
  defaultOn,
}: {
  label: string;
  desc: string;
  defaultOn: boolean;
}) {
  const [on, setOn] = React.useState(defaultOn);
  return (
    <div className="flex items-center justify-between rounded-lg border border-border p-3">
      <div>
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">{desc}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={on}
        aria-label={label}
        onClick={() => setOn((v) => !v)}
        className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background ${
          on ? "bg-primary" : "bg-muted"
        }`}
      >
        <span
          className={`pointer-events-none inline-block h-4 w-4 translate-y-0.5 transform rounded-full bg-background shadow ring-0 transition-transform ${
            on ? "translate-x-4" : "translate-x-0.5"
          }`}
        />
      </button>
    </div>
  );
}
