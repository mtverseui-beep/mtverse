"use client";

import * as React from "react";
import Link from "next/link";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip as RTooltip,
  CartesianGrid,
} from "recharts";
import {
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  Clock,
  CheckCircle2,
  Users,
  Activity as ActivityIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const usageData = [
  { day: "Mon", queries: 124, automations: 18 },
  { day: "Tue", queries: 156, automations: 22 },
  { day: "Wed", queries: 142, automations: 19 },
  { day: "Thu", queries: 198, automations: 28 },
  { day: "Fri", queries: 187, automations: 24 },
  { day: "Sat", queries: 89, automations: 12 },
  { day: "Sun", queries: 76, automations: 9 },
];

const activityFeed = [
  {
    icon: Zap,
    iconColor: "text-primary",
    title: "Automation ran: Standup summary",
    desc: "Posted #engineering-standup with 3 updates",
    time: "2 min ago",
  },
  {
    icon: CheckCircle2,
    iconColor: "text-success",
    title: "Draft approved",
    desc: "Maya approved the Q3 PRD draft",
    time: "18 min ago",
  },
  {
    icon: Users,
    iconColor: "text-info",
    title: "New team member",
    desc: "Dev Patel joined the workspace",
    time: "1 hour ago",
  },
  {
    icon: Zap,
    iconColor: "text-primary",
    title: "Automation ran: Slack triage",
    desc: "Categorized 14 messages in #support",
    time: "2 hours ago",
  },
  {
    icon: ActivityIcon,
    iconColor: "text-accent-warm",
    title: "Integration health",
    desc: "GitHub reconnected after brief outage",
    time: "4 hours ago",
  },
];

const stats = [
  { label: "AI queries this week", value: "972", delta: "+18%", up: true, icon: Zap },
  { label: "Automations run", value: "132", delta: "+12%", up: true, icon: ActivityIcon },
  { label: "Hours saved", value: "47.5", delta: "+24%", up: true, icon: Clock },
  { label: "Active members", value: "28", delta: "+3", up: true, icon: Users },
];

export function DashboardOverview() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">
            Welcome back, Maya
          </h1>
          <p className="text-sm text-muted-foreground">
            Here&apos;s what Ion handled for your team this week.
          </p>
        </div>
        <Button asChild size="sm">
          <Link href="/docs/guides">New automation</Link>
        </Button>
      </div>

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div
              key={s.label}
              className="rounded-xl border border-border bg-card p-5"
            >
              <div className="flex items-center justify-between">
                <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary">
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </div>
                <span
                  className={`flex items-center gap-0.5 text-xs font-medium ${
                    s.up ? "text-success" : "text-destructive"
                  }`}
                >
                  {s.up ? (
                    <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3" aria-hidden="true" />
                  )}
                  {s.delta}
                </span>
              </div>
              <div className="mt-3 text-2xl font-semibold text-foreground">{s.value}</div>
              <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-foreground">AI queries</h2>
              <p className="text-xs text-muted-foreground">Last 7 days</p>
            </div>
            <span className="text-xs text-success">+18% vs last week</span>
          </div>
          <div className="mt-4 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={usageData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="queriesGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="day"
                  stroke="var(--muted-foreground)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="var(--muted-foreground)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <RTooltip
                  contentStyle={{
                    background: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    color: "var(--foreground)",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="queries"
                  stroke="var(--primary)"
                  strokeWidth={2}
                  fill="url(#queriesGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Automations run</h2>
              <p className="text-xs text-muted-foreground">Last 7 days</p>
            </div>
            <span className="text-xs text-success">+12% vs last week</span>
          </div>
          <div className="mt-4 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={usageData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="day"
                  stroke="var(--muted-foreground)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="var(--muted-foreground)"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <RTooltip
                  contentStyle={{
                    background: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                    color: "var(--foreground)",
                  }}
                  cursor={{ fill: "var(--muted)", opacity: 0.3 }}
                />
                <Bar dataKey="automations" fill="var(--accent-warm)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Activity feed */}
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground">Recent activity</h2>
          <Link
            href="/dashboard/activity"
            className="text-xs text-primary hover:underline"
          >
            View all
          </Link>
        </div>
        <ul className="mt-4 space-y-3">
          {activityFeed.map((item, i) => {
            const Icon = item.icon;
            return (
              <li
                key={i}
                className="flex items-start gap-3 rounded-lg p-2 transition-colors hover:bg-muted/50"
              >
                <div className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-muted ${item.iconColor}`}>
                  <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground">{item.title}</p>
                  <p className="truncate text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <span className="shrink-0 text-xs text-muted-foreground">{item.time}</span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
