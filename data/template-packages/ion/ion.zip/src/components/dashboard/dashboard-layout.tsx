"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Settings,
  CreditCard,
  Users,
  Plug,
  Activity,
  LogOut,
  Search,
  Bell,
  Menu,
  X,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThemeToggle } from "@/components/theme-toggle";
import { BrandMark } from "@/components/brand-mark";
import { siteConfig } from "@/config/site";

const navItems = [
  { label: "Overview", href: "/dashboard", icon: LayoutDashboard },
  { label: "Activity", href: "/dashboard/activity", icon: Activity },
  { label: "Integrations", href: "/dashboard/integrations", icon: Plug },
  { label: "Team", href: "/dashboard/team", icon: Users },
  { label: "Billing", href: "/dashboard/billing", icon: CreditCard },
  { label: "Settings", href: "/dashboard/settings", icon: Settings },
];

/**
 * DashboardLayout — sidebar + topbar shell for the authenticated app.
 * Responsive: sidebar collapses to a slide-in drawer on mobile.
 */
export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  // Close mobile sidebar on route change
  React.useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-md md:px-6">
        <button
          type="button"
          aria-label="Open sidebar"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen(true)}
          className="grid h-9 w-9 place-items-center rounded-lg border border-border text-foreground md:hidden"
        >
          <Menu className="h-5 w-5" aria-hidden="true" />
        </button>

        <Link
          href="/"
          className="flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={`${siteConfig.name} — home`}
        >
          <BrandMark className="h-7 w-7" />
          <span className="hidden text-base font-semibold tracking-tight text-foreground sm:inline">
            {siteConfig.name}
          </span>
        </Link>

        {/* Search */}
        <div className="relative ml-4 hidden max-w-md flex-1 sm:block">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"
            aria-hidden="true"
          />
          <Input
            type="search"
            placeholder="Search anything… (⌘K)"
            className="pl-9 bg-muted/50 border-0"
            aria-label="Search"
          />
        </div>

        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            aria-label="Notifications"
            className="relative grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Bell className="h-4 w-4" aria-hidden="true" />
            <span
              className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-primary"
              aria-hidden="true"
            />
          </button>
          <ThemeToggle />
          <div className="ml-1 flex items-center gap-2 rounded-lg border border-border bg-card px-2 py-1">
            <div className="grid h-6 w-6 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
              M
            </div>
            <span className="hidden text-sm font-medium text-foreground sm:inline">Maya</span>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar (desktop) */}
        <aside className="sticky top-14 hidden h-[calc(100vh-3.5rem)] w-64 shrink-0 border-r border-border bg-background md:block">
          <SidebarContent pathname={pathname} />
        </aside>

        {/* Sidebar (mobile drawer) */}
        {mobileOpen && (
          <div className="fixed inset-0 z-50 md:hidden">
            <div
              className="absolute inset-0 bg-background/80 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
              aria-hidden="true"
            />
            <aside className="absolute left-0 top-0 h-full w-72 border-r border-border bg-background p-4 shadow-2xl">
              <div className="mb-4 flex items-center justify-between">
                <Link href="/" className="flex items-center gap-2">
                  <BrandMark className="h-7 w-7" />
                  <span className="text-base font-semibold text-foreground">{siteConfig.name}</span>
                </Link>
                <button
                  type="button"
                  aria-label="Close sidebar"
                  onClick={() => setMobileOpen(false)}
                  className="grid h-9 w-9 place-items-center rounded-lg border border-border text-foreground"
                >
                  <X className="h-5 w-5" aria-hidden="true" />
                </button>
              </div>
              <SidebarContent pathname={pathname} />
            </aside>
          </div>
        )}

        {/* Main content */}
        <main className="min-w-0 flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}

function SidebarContent({ pathname }: { pathname: string }) {
  return (
    <nav className="flex h-full flex-col" aria-label="Dashboard">
      <div className="px-2 py-4">
        <p className="px-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Workspace
        </p>
        <ul className="mt-2 space-y-1">
          {navItems.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "group flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                    active
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                  aria-current={active ? "page" : undefined}
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                  {item.label}
                  {active && (
                    <ChevronRight
                      className="ml-auto h-4 w-4 text-primary"
                      aria-hidden="true"
                    />
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Bottom: upgrade card + logout */}
      <div className="mt-auto p-2">
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-3">
          <p className="text-sm font-semibold text-foreground">Pro trial</p>
          <p className="mt-1 text-xs text-muted-foreground">12 days left</p>
          <Button asChild size="sm" className="mt-2 w-full">
            <Link href="/pricing">Upgrade</Link>
          </Button>
        </div>
        <Link
          href="/login"
          className="mt-2 flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" />
          Sign out
        </Link>
      </div>
    </nav>
  );
}
