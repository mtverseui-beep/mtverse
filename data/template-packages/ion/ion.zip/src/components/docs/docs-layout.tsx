"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Search, Menu, X, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Navbar } from "@/components/sections/navbar";
import { Footer } from "@/components/sections/footer";
import { Input } from "@/components/ui/input";
import { getDocsBySection, type DocPage } from "@/config/docs";

/**
 * DocsLayout — sidebar + content + footer.
 * Sidebar has search, section grouping, and active-link highlighting.
 */
export function DocsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileSidebar, setMobileSidebar] = React.useState(false);
  const [query, setQuery] = React.useState("");
  const sections = getDocsBySection();

  const filteredSections = React.useMemo(() => {
    if (!query.trim()) return sections;
    const q = query.toLowerCase();
    const filtered: Record<string, DocPage[]> = {};
    for (const [section, pages] of Object.entries(sections)) {
      const matched = pages.filter(
        (p) =>
          p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
      );
      if (matched.length > 0) filtered[section] = matched;
    }
    return filtered;
  }, [query, sections]);

  return (
    <>
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 md:px-6 pt-20">
        <button
          type="button"
          onClick={() => setMobileSidebar(true)}
          className="mb-4 inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm text-foreground lg:hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label="Open docs navigation"
        >
          <Menu className="h-4 w-4" aria-hidden="true" />
          Docs menu
        </button>

        <div className="grid gap-8 lg:grid-cols-[260px_1fr] lg:gap-12">
          <aside className="hidden lg:block">
            <div className="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto pb-8">
              <DocsSidebar
                sections={filteredSections}
                pathname={pathname}
                query={query}
                setQuery={setQuery}
              />
            </div>
          </aside>

          {mobileSidebar && (
            <div className="fixed inset-0 z-50 lg:hidden">
              <div
                className="absolute inset-0 bg-background/80 backdrop-blur-sm"
                onClick={() => setMobileSidebar(false)}
                aria-hidden="true"
              />
              <aside className="absolute left-0 top-0 h-full w-80 max-w-[85%] border-r border-border bg-background p-4 overflow-y-auto">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-sm font-semibold text-foreground">Docs</span>
                  <button
                    type="button"
                    aria-label="Close docs menu"
                    onClick={() => setMobileSidebar(false)}
                    className="grid h-9 w-9 place-items-center rounded-lg border border-border text-foreground"
                  >
                    <X className="h-5 w-5" aria-hidden="true" />
                  </button>
                </div>
                <DocsSidebar
                  sections={filteredSections}
                  pathname={pathname}
                  query={query}
                  setQuery={setQuery}
                  onNavigate={() => setMobileSidebar(false)}
                />
              </aside>
            </div>
          )}

          <main className="min-w-0 pb-16">{children}</main>
        </div>
      </div>
      <Footer />
    </>
  );
}

function DocsSidebar({
  sections,
  pathname,
  query,
  setQuery,
  onNavigate,
}: {
  sections: Record<string, DocPage[]>;
  pathname: string;
  query: string;
  setQuery: (s: string) => void;
  onNavigate?: () => void;
}) {
  return (
    <nav aria-label="Documentation">
      <div className="relative mb-6">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"
          aria-hidden="true"
        />
        <Input
          type="search"
          placeholder="Search docs…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-9 bg-muted/50 border-0"
          aria-label="Search docs"
        />
      </div>

      {Object.keys(sections).length === 0 && (
        <p className="text-sm text-muted-foreground">No docs match &quot;{query}&quot;.</p>
      )}

      {Object.entries(sections).map(([section, pages]) => (
        <div key={section} className="mb-6">
          <h3 className="px-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            {section}
          </h3>
          <ul className="mt-2 space-y-0.5">
            {pages.map((p) => {
              const href = `/docs/${p.slug}`;
              const active = pathname === href;
              return (
                <li key={p.slug}>
                  <Link
                    href={href}
                    onClick={onNavigate}
                    className={cn(
                      "flex items-center gap-1.5 rounded-md px-2 py-1.5 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                      active
                        ? "bg-primary/10 font-medium text-primary"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                    aria-current={active ? "page" : undefined}
                  >
                    {active && (
                      <ChevronRight className="h-3 w-3" aria-hidden="true" />
                    )}
                    {p.title}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
}
