/**
 * BrandMark — Ion logo (matches /public/icon.svg).
 * Uses solid lime background + dark mark so it renders identically in
 * light and dark mode. No currentColor — pure fills.
 */
export function BrandMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 28 28" fill="none" className={className} aria-hidden="true">
      <rect width="28" height="28" rx="7" fill="#8FCB2A" />
      <path
        d="M9 8.5C9 7.67 9.67 7 10.5 7H17.5C18.33 7 19 7.67 19 8.5V19.5C19 20.33 18.33 21 17.5 21H10.5C9.67 21 9 20.33 9 19.5V8.5Z"
        fill="#0B0C10"
        opacity="0.18"
      />
      <path
        d="M11 11H17M11 14H17M11 17H15"
        stroke="#0B0C10"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <circle cx="19" cy="9" r="2.5" fill="#0B0C10" />
    </svg>
  );
}
