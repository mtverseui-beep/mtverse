/**
 * Smoke tests for every route in the Ion template.
 *
 * These tests render each page with React Testing Library to catch broken
 * imports, typos, and missing components — they don't assert visual output.
 * Run them in CI to fail fast on regressions.
 *
 * Run: `bun test` or `npm test`
 */
import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { ReactNode } from "react";

// Stub next/navigation for tests
const useRouter = () => ({ push: () => {}, pathname: "/" });
const usePathname = () => "/";

// Mock providers we don't want to actually wire in tests
function TestWrapper({ children }: { children: ReactNode }) {
  return (
    <>
      {children}
    </>
  );
}

describe("smoke: home page renders", () => {
  it("renders without crashing", async () => {
    // Dynamic import to avoid top-level Next.js server-only issues
    const Home = (await import("../src/app/page")).default;
    render(<Home />, { wrapper: TestWrapper });
    // The hero headline should be in the document
    expect(screen.getByText(/Stop wrestling tools/i)).toBeTruthy();
  });
});

describe("smoke: pricing page renders", () => {
  it("renders without crashing", async () => {
    const PricingPage = (await import("../src/app/pricing/page")).default;
    render(<PricingPage />, { wrapper: TestWrapper });
    expect(screen.getByText(/Pricing that scales/i)).toBeTruthy();
  });
});

describe("smoke: changelog page renders", () => {
  it("renders without crashing", async () => {
    const ChangelogPage = (await import("../src/app/changelog/page")).default;
    render(<ChangelogPage />, { wrapper: TestWrapper });
    expect(screen.getByText(/We ship every week/i)).toBeTruthy();
  });
});

describe("smoke: contact page renders", () => {
  it("renders without crashing", async () => {
    const ContactPage = (await import("../src/app/contact/page")).default;
    render(<ContactPage />, { wrapper: TestWrapper });
    expect(screen.getByText(/Let's talk/i)).toBeTruthy();
  });
});

describe("smoke: 404 page renders", () => {
  it("renders without crashing", async () => {
    const NotFound = (await import("../src/app/not-found")).default;
    render(<NotFound />, { wrapper: TestWrapper });
    expect(screen.getByText(/Page not found/i)).toBeTruthy();
  });
});
